package com.binario.treni.service

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.binario.treni.MainActivity
import com.binario.treni.R
import com.binario.treni.data.Api
import com.binario.treni.data.Sources
import com.binario.treni.data.Fmt
import com.binario.treni.data.Reminder
import com.binario.treni.data.Store
import com.binario.treni.data.TrainRef
import com.binario.treni.data.delayText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Notif {
    const val CH_TRACK = "tracking"
    const val CH_REMIND = "reminders"
    const val CH_NEWS = "news"
    const val CH_WAKE = "wake"
    const val CH_ALERT = "alerts"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_TRACK, "Treno seguito", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_REMIND, "Promemoria partenza e arrivo", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel(CH_NEWS, "Scioperi e news", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Interruzioni su tratte e linee preferite", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "Sveglia fermata", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 800, 400, 800, 400, 800, 400, 800)
            setSound(
                android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM),
                android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
        })
    }

    fun canPost(ctx: Context): Boolean = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Apre l'app, eventualmente sulla scheda di un treno. */
    fun openApp(ctx: Context, ref: TrainRef? = null, req: Int = 0, screen: String? = null): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (ref != null) i.putExtra(MainActivity.EXTRA_TRAIN, ref.toJson().toString())
        if (screen != null) i.putExtra(MainActivity.EXTRA_SCREEN, screen)
        return PendingIntent.getActivity(ctx, req, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun post(ctx: Context, id: Int, channel: String, title: String, text: String, tap: PendingIntent, vararg actions: NotificationCompat.Action) {
        if (!canPost(ctx)) return
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_train)
            .setContentTitle(title)
            .setContentText(text.lineSequence().firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(tap)
            .setAutoCancel(true)
            .setColor(0xFF2E9E44.toInt())
        actions.forEach { b.addAction(it) }
        ctx.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}

/**
 * Avvisi accessibili per persone sorde o ipoudenti: vibrazione forte con uno schema
 * riconoscibile per ogni tipo di avviso, più il lampeggio del flash.
 */
object Haptic {
    enum class Kind(val pattern: LongArray) {
        /** Sveglia fermata: tre impulsi lunghissimi, ripetuti. */
        WAKE(longArrayOf(0, 1500, 500, 1500, 500, 1500, 1000, 1500, 500, 1500, 500, 1500)),
        /** Promemoria partenza/arrivo: tre impulsi brevi, due volte. */
        REMINDER(longArrayOf(0, 300, 200, 300, 200, 300, 800, 300, 200, 300, 200, 300)),
        /** Interruzione o soppressione: due impulsi lunghi. */
        ALERT(longArrayOf(0, 1000, 400, 1000)),
        /** Sciopero/news: un impulso medio. */
        NEWS(longArrayOf(0, 600)),
    }

    fun alert(ctx: Context, kind: Kind, spoken: String? = null) {
        val store = Store(ctx)
        // Non vedenti: suono distinto + voce
        if (spoken != null && store.blindMode) {
            Speech.say(ctx, spoken, when (kind) {
                Kind.WAKE -> Speech.Sound.IMMINENT
                Kind.REMINDER -> Speech.Sound.DEPART
                Kind.ALERT -> Speech.Sound.ALERT
                Kind.NEWS -> Speech.Sound.INFO
            }, times = if (kind == Kind.WAKE) 2 else 1, essential = kind == Kind.WAKE)
        }
        if (!store.deafMode) return
        try {
            val v = ctx.getSystemService(android.os.Vibrator::class.java)
            val amps = IntArray(kind.pattern.size) { i -> if (i % 2 == 1) 255 else 0 }
            if (v != null && v.hasVibrator()) {
                v.vibrate(android.os.VibrationEffect.createWaveform(kind.pattern, amps, -1))
            }
        } catch (_: Exception) {
        }
        if (store.flashAlerts && kind != Kind.NEWS) flash(ctx, if (kind == Kind.WAKE) 10 else 4)
    }

    /** Lampeggia la torcia [times] volte (non serve il permesso fotocamera). */
    private fun flash(ctx: Context, times: Int) {
        Thread {
            try {
                val cm = ctx.getSystemService(android.hardware.camera2.CameraManager::class.java) ?: return@Thread
                val id = cm.cameraIdList.firstOrNull { cid ->
                    cm.getCameraCharacteristics(cid).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: return@Thread
                repeat(times) {
                    cm.setTorchMode(id, true); Thread.sleep(250)
                    cm.setTorchMode(id, false); Thread.sleep(250)
                }
            } catch (_: Exception) {
            }
        }.start()
    }
}

/** Notifica fissa con lo stato del treno aggiornato ogni minuto. */
class TrackingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val store = Store(this)
        if (intent?.action == ACTION_STOP) {
            store.setTracked(null)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        intent?.getStringExtra(EXTRA_REF)?.let {
            try {
                store.setTracked(TrainRef.from(JSONObject(it)))
            } catch (_: Exception) {
            }
        }
        val ref = store.tracked()
        if (ref == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val first = build(ref, ref.label, "Aggiornamento in corso…")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(ID, first)
        }
        job?.cancel()
        // Nuovo treno seguito: si riparte con gli annunci da capo
        if (announcedFor != ref.key) {
            announcedFor = ref.key
            announcedIntro = false; knownPlatforms.clear(); lastDelay = null; lastNextStop = null
            saidDepartSoon = false; saidPreWake = false; saidCancelled = false
        }
        job = scope.launch {
            val nm = getSystemService(NotificationManager::class.java)
            while (isActive) {
                var wait = 60_000L
                try {
                    val st = Api.status(ref)
                    val wake = store.wakeTarget()
                    val title = "${st.title} · ${st.origin} → ${st.destination}"
                    val board = store.boardingStation()?.let { b -> st.stops.firstOrNull { it.id == b.id || it.name.equals(b.name, true) } }
                    val boardLine = if (board != null && !board.passed) {
                        val p = board.realPlatform.ifBlank { board.schedPlatform }
                        "\n🚉 Sali a ${board.name} alle ${Fmt.time((if (board.schedDep > 0) board.schedDep else board.schedArr) + st.delay * 60_000L)}" +
                            (if (p.isNotBlank()) " · binario $p" else "")
                    } else ""
                    val extra = boardLine + (if (wake != null) "\n⏰ Sveglia prima di ${wake.name}" else "")
                    nm.notify(ID, build(st.ref, title, st.summary() + extra))
                    try { announce(st, wake) } catch (_: Exception) { }
                    if (wake != null && !store.wakeFired) checkWake(st, wake)
                    val dep = (board?.let { if (it.schedDep > 0) it.schedDep else it.schedArr } ?: st.depTime) + st.delay * 60_000L
                    if (st.arrived || st.cancelled) wait = 15 * 60_000L // dopo l'arrivo rallenta
                    else if (wake != null && !store.wakeFired) wait = 30_000L // più frequente vicino alla fermata
                    else if (dep - System.currentTimeMillis() in 0..20 * 60_000L) wait = 30_000L // poco prima di salire: più aggiornamenti
                } catch (e: Exception) {
                    nm.notify(ID, build(ref, ref.label, "Dati momentaneamente non disponibili"))
                }
                delay(wait)
            }
        }
        return START_STICKY
    }

    // ---- Annunci (voce per non vedenti, notifiche di cambio binario/ritardo per tutti) ----
    private var announcedFor: String? = null
    private var announcedIntro = false
    private val knownPlatforms = HashMap<String, String>()
    private var lastDelay: Int? = null
    private var lastNextStop: String? = null
    private var saidDepartSoon = false
    private var saidPreWake = false
    private var saidCancelled = false

    private fun platOf(s: com.binario.treni.data.TrainStop): String = s.realPlatform.ifBlank { s.schedPlatform }

    private fun announce(st: com.binario.treni.data.TrainStatus, wake: com.binario.treni.data.Station?) {
        val en = com.binario.treni.data.I18n.en
        fun t(itText: String, enText: String) = if (en) enText else itText
        val now = System.currentTimeMillis()
        // Dove salgo: la fermata scelta ("Salgo qui") oppure l'origine del treno
        val boardSt = store.boardingStation()
        val first = (if (boardSt != null) st.stops.firstOrNull { it.id == boardSt.id || it.name.equals(boardSt.name, true) } else null)
            ?: st.stops.firstOrNull()
        val boardedOrPassed = first?.passed == true
        val atOrigin = first == st.stops.firstOrNull()
        val next = st.nextStop

        // 1) Inizio: dove prendere il treno
        if (!announcedIntro) {
            announcedIntro = true
            val sb = StringBuilder("${st.title} ${t("per", "to")} ${st.destination}. ")
            if (!boardedOrPassed && first != null) {
                val at = (if (first.schedDep > 0) first.schedDep else first.schedArr)
                sb.append(if (atOrigin) t("Parte da ${first.name} alle ${Fmt.time(at)}", "Departs from ${first.name} at ${Fmt.time(at)}")
                    else t("Sali a ${first.name}: passa alle ${Fmt.time(at)}", "Board at ${first.name}: due at ${Fmt.time(at)}"))
                if (platOf(first).isNotBlank()) sb.append(t(", binario ${platOf(first)}", ", platform ${platOf(first)}"))
                else sb.append(t(", binario non ancora indicato", ", platform not yet announced"))
                sb.append(". ")
            } else if (next != null) {
                sb.append(t("Prossima fermata ${next.name}", "Next stop ${next.name}"))
                if (platOf(next).isNotBlank()) sb.append(t(", binario ${platOf(next)}", ", platform ${platOf(next)}"))
                sb.append(". ")
            }
            if (st.delay > 0) sb.append(t("Ritardo ${st.delay} minuti.", "${st.delay} minutes late."))
            if (wake != null) sb.append(t(" Ti avviserò prima di ${wake.name}.", " I will warn you before ${wake.name}."))
            Speech.say(this, sb.toString(), Speech.Sound.PLATFORM)
        }

        // 2) Soppressione
        if (st.cancelled && !saidCancelled) {
            saidCancelled = true
            Speech.say(this, t("Attenzione: il treno ${st.title} è soppresso.", "Warning: train ${st.title} is cancelled."), Speech.Sound.ALERT)
        }

        // 3) Cambio binario alla stazione di partenza o alla prossima fermata
        val watch = if (!boardedOrPassed) first else next
        if (watch != null) {
            val p = platOf(watch)
            val old = knownPlatforms[watch.id]
            if (p.isNotBlank()) {
                if (old != null && old.isNotBlank() && old != p) {
                    val msg = t("Cambio binario a ${watch.name}: il treno ${st.title} arriva al binario $p invece del $old.",
                        "Platform change at ${watch.name}: train ${st.title} now uses platform $p instead of $old.")
                    if (store.changeAlerts) Notif.post(this, ID + 2, Notif.CH_ALERT, "🔀 " + t("Cambio binario", "Platform change") + ": $old → $p",
                        msg, Notif.openApp(this, st.ref, 5))
                    Haptic.alert(this, Haptic.Kind.ALERT, msg)
                } else if (old == null && watch.realPlatform.isNotBlank() && announcedIntro && !boardedOrPassed) {
                    // Binario confermato per la prima volta
                    Speech.say(this, t("Binario confermato: ${watch.realPlatform}.", "Platform confirmed: ${watch.realPlatform}."), Speech.Sound.PLATFORM)
                }
                knownPlatforms[watch.id] = p
            }
        }

        // 4) Ritardo aumentato di almeno 5 minuti
        val ld = lastDelay
        if (ld != null && !st.arrived && !st.cancelled && st.delay - ld >= 5) {
            val msg = t("Il treno ${st.title} ora ha ${st.delay} minuti di ritardo.", "Train ${st.title} is now ${st.delay} minutes late.")
            if (store.changeAlerts) Notif.post(this, ID + 3, Notif.CH_ALERT, "⏱ ${st.title} +${st.delay}'", msg, Notif.openApp(this, st.ref, 6))
            Haptic.alert(this, Haptic.Kind.ALERT, msg)
            lastDelay = st.delay
        } else if (ld == null || st.delay < ld) {
            lastDelay = st.delay
        }

        // 5) Partenza tra 5 minuti
        if (!boardedOrPassed && !saidDepartSoon && first != null) {
            val leave = (if (first.schedDep > 0) first.schedDep else first.schedArr) + st.delay * 60_000L
            val mins = ((leave - now) / 60_000L).toInt()
            if (leave > now && mins <= 5) {
                saidDepartSoon = true
                val plat = platOf(first)
                Speech.say(this,
                    t("Il treno ${st.title} " + (if (atOrigin) "parte" else "arriva a ${first.name}") + " tra ${maxOf(mins, 1)} minuti" +
                        (if (plat.isNotBlank()) ", binario $plat." else "."),
                        "Train ${st.title} " + (if (atOrigin) "leaves" else "reaches ${first.name}") + " in ${maxOf(mins, 1)} minutes" +
                            (if (plat.isNotBlank()) ", platform $plat." else ".")),
                    Speech.Sound.DEPART)
            }
        }

        // 6) Annuncio di ogni fermata (come a bordo), solo con la voce attiva
        if (st.departed && boardedOrPassed && !st.arrived && next != null && next.id != lastNextStop) {
            if (lastNextStop != null && store.announceStops && (wake == null || next.id != wake.id)) {
                val eta = (if (next.schedArr > 0) next.schedArr else next.schedDep) + st.delay * 60_000L
                Speech.say(this, t("Prossima fermata: ${next.name}", "Next stop: ${next.name}") +
                    (if (eta > 0) t(", alle ${Fmt.time(eta)}.", ", at ${Fmt.time(eta)}.") else "."), Speech.Sound.INFO)
            }
            lastNextStop = next.id
        }

        // 7) Preavviso 10 minuti prima della fermata dove scendere
        if (wake != null && !saidPreWake && !store.wakeFired) {
            val target = st.stops.firstOrNull { it.id == wake.id || it.name.equals(wake.name, true) }
            if (target != null && !target.passed) {
                val eta = (if (target.schedArr > 0) target.schedArr else target.schedDep) + st.delay * 60_000L
                if (eta > 0 && eta - now in 4 * 60_000L..10 * 60_000L) {
                    saidPreWake = true
                    val mins = ((eta - now) / 60_000L).toInt()
                    Speech.say(this, t("Tra circa $mins minuti arrivi a ${target.name}. Inizia a prepararti.",
                        "In about $mins minutes you arrive at ${target.name}. Start getting ready."), Speech.Sound.PLATFORM, essential = true)
                }
            }
        }
    }

    /** Suona quando il treno lascia la fermata prima di quella scelta (o 4 minuti prima dell'arrivo previsto). */
    private fun checkWake(st: com.binario.treni.data.TrainStatus, wake: com.binario.treni.data.Station) {
        val idx = st.stops.indexOfFirst { it.id == wake.id || it.name.equals(wake.name, true) }
        if (idx <= 0) return
        val prev = st.stops[idx - 1]
        val target = st.stops[idx]
        val eta = (if (target.schedArr > 0) target.schedArr else target.schedDep) + st.delay * 60_000L
        val now = System.currentTimeMillis()
        val leftPrev = prev.realDep > 0 || prev.realArr > 0
        if (target.passed) {
            store.wakeFired = true; return
        }
        if (leftPrev || (eta > 0 && eta - now < 4 * 60_000L)) {
            store.wakeFired = true
            val n = NotificationCompat.Builder(this, Notif.CH_WAKE)
                .setSmallIcon(R.drawable.ic_train)
                .setContentTitle("⏰ Sveglia! Prossima fermata: ${target.name}")
                .setContentText("Arrivo previsto alle ${Fmt.time(eta)}" + (if (target.platformText.isNotBlank()) " · binario ${target.platformText}" else ""))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(Notif.openApp(this, st.ref, 3))
                .setFullScreenIntent(Notif.openApp(this, st.ref, 4), true)
                .build()
            n.flags = n.flags or Notification.FLAG_INSISTENT
            if (Notif.canPost(this)) getSystemService(NotificationManager::class.java).notify(ID + 1, n)
            val en = com.binario.treni.data.I18n.en
            val plat = target.realPlatform.ifBlank { target.schedPlatform }
            Haptic.alert(this, Haptic.Kind.WAKE,
                if (en) "Attention! Next stop: ${target.name}. Get ready to get off." + (if (plat.isNotBlank()) " Platform $plat." else "")
                else "Attenzione! Prossima fermata: ${target.name}. Preparati a scendere." + (if (plat.isNotBlank()) " Binario $plat." else ""))
        }
    }

    private val store by lazy { Store(this) }

    private fun build(ref: TrainRef, title: String, text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, Notif.CH_TRACK)
            .setSmallIcon(R.drawable.ic_train)
            .setContentTitle(title)
            .setContentText(text.lineSequence().firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(0xFF2E9E44.toInt())
            .setContentIntent(Notif.openApp(this, ref, 2))
            .addAction(0, "Smetti di seguire", stop)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ID = 4242
        const val ACTION_STOP = "com.binario.treni.STOP_TRACKING"
        const val EXTRA_REF = "ref"

        /** Segue il treno; [boarding] = stazione dove salgo (null = dall'origine o quella già scelta per lo stesso treno). */
        fun start(ctx: Context, ref: TrainRef, boarding: com.binario.treni.data.Station? = null) {
            val s = Store(ctx)
            val same = s.tracked()?.number == ref.number
            s.setTracked(ref)
            s.setWakeTarget(null)
            if (boarding != null) s.setBoardingStation(boarding) else if (!same) s.setBoardingStation(null)
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))
        }

        /** Segue il treno e suona la sveglia prima della fermata scelta. */
        fun startWake(ctx: Context, ref: TrainRef, stop: com.binario.treni.data.Station) {
            val s = Store(ctx)
            if (s.tracked()?.number != ref.number) s.setBoardingStation(null)
            s.setTracked(ref)
            s.setWakeTarget(stop)
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))
        }

        fun stop(ctx: Context) {
            Store(ctx).setTracked(null)
            ctx.startService(Intent(ctx, TrackingService::class.java).setAction(ACTION_STOP))
        }
    }
}

/** Promemoria programmati di partenza/arrivo. */
object Reminders {
    fun schedule(ctx: Context, r: Reminder) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, r.id)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
        }
    }

    fun add(ctx: Context, r: Reminder) {
        Store(ctx).addReminder(r)
        schedule(ctx, r)
    }

    fun cancel(ctx: Context, id: Int) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, id))
        Store(ctx).removeReminder(id)
    }

    fun rescheduleAll(ctx: Context) {
        val store = Store(ctx)
        val now = System.currentTimeMillis()
        store.reminders().forEach { r ->
            if (r.eventTime < now) store.removeReminder(r.id) else schedule(ctx, r.copy(at = maxOf(r.at, now + 5000)))
        }
    }

    private fun pending(ctx: Context, id: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, id, Intent(ctx, ReminderReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val store = Store(ctx)
        val r = store.reminders().firstOrNull { it.id == id } ?: return
        val pending = goAsync()
        Thread {
            try {
                val ref = TrainRef(r.number, r.originCode, 0L, r.label)
                var text = (if (r.arrival) "Arrivo previsto alle " else "Partenza prevista alle ") + Fmt.time(r.eventTime)
                var tapRef = ref
                try {
                    val st = Api.status(ref)
                    tapRef = st.ref
                    val stop = if (r.arrival) st.stops.lastOrNull() else st.stops.firstOrNull()
                    text = (if (r.arrival) "Arrivo a ${st.destination} alle " else "Partenza da ${st.origin} alle ") +
                        Fmt.time(if (r.arrival) st.arrTime else st.depTime) + delayText(st.delay, true)
                    if (stop != null && stop.platformText.isNotBlank()) text += " · binario ${stop.platformText}"
                    if (st.cancelled) text = "Attenzione: il treno risulta soppresso"
                } catch (_: Exception) {
                }
                val follow = PendingIntent.getForegroundService(
                    ctx, 10_000 + id,
                    Intent(ctx, TrackingService::class.java).putExtra(TrackingService.EXTRA_REF, tapRef.toJson().toString()),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
                Notif.post(
                    ctx, 20_000 + id, Notif.CH_REMIND, r.label, text, Notif.openApp(ctx, tapRef, 30_000 + id),
                    NotificationCompat.Action(0, "Segui treno", follow),
                )
                Haptic.alert(ctx, Haptic.Kind.REMINDER, r.label + ". " + text)
                store.removeReminder(id)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            Reminders.rescheduleAll(ctx)
        }
    }
}

/** Controlla periodicamente le news di infomobilità e notifica i nuovi scioperi. */
class StrikeWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val store = Store(ctx)
        val first = !store.newsSeeded
        val seen = store.seenNews()
        val newSeen = mutableListOf<String>()

        // Parole che identificano tratte, linee e stazioni dell'utente
        val names = (store.favRoutes().flatMap { listOf(it.from.name, it.to.name) } +
            store.favLines().flatMap { listOf(it.a.name, it.b.name) } +
            store.favStations().map { it.name } +
            (store.tracked()?.let { listOf(it.label) } ?: emptyList()))
            .map { it.trim() }.filter { it.length >= 3 }.distinct()
        val lineNames = store.favLines().map { it.name }.filter { it.isNotBlank() }
        fun mine(text: String): String? =
            names.firstOrNull { text.contains(it, true) } ?: lineNames.firstOrNull { Regex("\\b${Regex.escape(it)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) }

        // 1) Scioperi ferroviari dalla fonte ufficiale (Osservatorio MIT)
        if (store.strikeAlerts) {
            try {
                Sources.railStrikes().forEach { st ->
                    if (st.key !in seen) {
                        newSeen += st.key
                        val relevant = st.relevance.contains("nazional", true) || st.region.contains("lombard", true) ||
                            mine(st.company + " " + st.region) != null
                        if (!first && relevant) {
                            Notif.post(ctx, st.key.hashCode(), Notif.CH_NEWS, "🚫 ${st.title}",
                                "${st.modality}\n${st.unions} · ${st.region}", Notif.openApp(ctx, null, 5001, "news"))
                            Haptic.alert(ctx, Haptic.Kind.NEWS)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        // 2) Comunicati: scioperi, interruzioni programmate, circolazione bloccata
        try {
            Sources.allNotices().forEach { n ->
                val body = n.title + " " + n.text
                val key = "n:" + n.source + ":" + (n.title + "|" + n.text).hashCode()
                if (key in seen) return@forEach
                newSeen += key
                if (first) return@forEach
                val hit = mine(body)
                when (n.kind) {
                    com.binario.treni.data.Notice.Kind.STRIKE -> if (store.strikeAlerts) {
                        Notif.post(ctx, ("s" + n.title).hashCode(), Notif.CH_NEWS, "Sciopero · ${n.source}", n.title + "\n" + n.text.take(300),
                            Notif.openApp(ctx, null, 5002, "news"))
                        Haptic.alert(ctx, Haptic.Kind.NEWS)
                    }
                    com.binario.treni.data.Notice.Kind.BLOCKED -> if (store.routeAlerts && hit != null) {
                        // Stesso id per lo stesso titolo: gli aggiornamenti sostituiscono la notifica precedente
                        Notif.post(ctx, ("b" + n.source + n.title).hashCode(), Notif.CH_ALERT, "⚠️ Circolazione · $hit",
                            n.title + "\n" + n.text.take(400) + "\nAggiornato: " + Fmt.time(System.currentTimeMillis()),
                            Notif.openApp(ctx, null, 5003, "news"))
                        Haptic.alert(ctx, Haptic.Kind.ALERT)
                    }
                    com.binario.treni.data.Notice.Kind.WORKS -> if (store.routeAlerts && hit != null) {
                        Notif.post(ctx, ("w" + n.title).hashCode(), Notif.CH_ALERT, "🚧 Lavori/modifiche · $hit",
                            n.title + "\n" + n.text.take(400), Notif.openApp(ctx, null, 5004, "news"))
                        Haptic.alert(ctx, Haptic.Kind.ALERT)
                    }
                    else -> {}
                }
            }
        } catch (_: Exception) {
        }

        // 3) Treni preferiti soppressi oggi
        if (store.routeAlerts) {
            store.favTrains().forEach { r ->
                try {
                    val st = Api.status(r)
                    val key = "cancel:${st.number}:${st.date}"
                    if (st.cancelled && key !in seen) {
                        newSeen += key
                        Notif.post(ctx, 6000 + (st.number.toIntOrNull() ?: 0) % 1000, Notif.CH_ALERT,
                            "⚠️ ${st.title} soppresso", "${st.origin} → ${st.destination} · ${Fmt.time(st.depTime)}",
                            Notif.openApp(ctx, st.ref, 6000))
                        Haptic.alert(ctx, Haptic.Kind.ALERT, "${st.title} ${st.origin} → ${st.destination} " +
                            (if (com.binario.treni.data.I18n.en) "is cancelled." else "è soppresso."))
                    }
                } catch (_: Exception) {
                }
            }
        }
        // 4) Treno abituale: avvisi automatici senza premere "Segui"
        if (store.habitAlerts) {
            try {
                HabitAlerts.check(ctx, store)
            } catch (_: Exception) {
            }
        }
        store.addSeenNews(newSeen)
        store.newsSeeded = true
        // Registro "Quanto sei green": ritardi del giorno
        try {
            com.binario.treni.data.GreenCalc.autoLog(ctx)
        } catch (_: Exception) {
        }
        // Puntualità rete FerrovieNord: TrovaTreno non la pubblica, l'app raccoglie gli arrivi da ViaggiaTreno
        try {
            com.binario.treni.data.FnStats.collect(applicationContext)
        } catch (_: Exception) {
        }
        // Puntualità FFS: le FFS pubblicano solo il giorno precedente, quindi lo raccogliamo ogni giorno (3 richieste piccole)
        try {
            com.binario.treni.data.SwissStats.collect(applicationContext)
        } catch (_: Exception) {
        }
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<StrikeWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("alerts", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}

/**
 * Avvisi sul treno che prendi di solito: nei 45 minuti prima della partenza controlla ritardo, soppressione e
 * cambio di binario e, se il treno è soppresso o ha più di 15 minuti di ritardo, propone subito le alternative.
 * Una sola notifica per ogni novità (stesso id: gli aggiornamenti sostituiscono la notifica precedente).
 */
object HabitAlerts {
    fun check(ctx: Context, store: Store) {
        val now = System.currentTimeMillis()
        val due = com.binario.treni.data.Habits.dueForAlerts(store.habits(), now)
        val state = store.habitAlertState()
        val today = Fmt.midnight(now)
        state.keys().asSequence().toList().forEach { k -> if (state.optJSONObject(k)?.optLong("day") != today) state.remove(k) }
        val tracked = store.tracked()
        val en = com.binario.treni.data.I18n.en
        fun t(itText: String, enText: String) = if (en) enText else itText
        due.forEach { h ->
            // Se lo stai già seguendo, gli avvisi arrivano dalla notifica fissa
            if (tracked != null && com.binario.treni.data.Habits.digits(tracked.number) == com.binario.treni.data.Habits.digits(h.number)) return@forEach
            val live = try {
                com.binario.treni.data.NextTrain.live(h, now)
            } catch (_: Exception) {
                return@forEach
            }
            if (!live.found || live.departed) return@forEach
            val prev = state.optJSONObject(h.key) ?: JSONObject().put("day", today)
            val news = mutableListOf<String>()
            if (live.cancelled && !prev.optBoolean("cancel")) {
                news += t("È soppresso.", "It is cancelled.")
                prev.put("cancel", true)
            }
            val lastDelay = prev.optInt("delay", 0)
            if (!live.cancelled) {
                if (live.delay >= 5 && kotlin.math.abs(live.delay - lastDelay) >= 5) {
                    news += t("Ritardo previsto: ${live.delay} minuti, parte alle ", "Expected delay: ${live.delay} minutes, leaves at ") +
                        Fmt.time(live.dep + live.delay * 60_000L) + "."
                    prev.put("delay", live.delay)
                } else if (live.delay < 5 && lastDelay >= 5) {
                    news += t("Di nuovo in orario.", "Back on time.")
                    prev.put("delay", live.delay)
                }
                if (live.platformChanged && prev.optString("plat") != live.platform) {
                    news += t("Cambio binario: parte dal ${live.platform} invece del ${live.schedPlatform}.",
                        "Platform change: leaves from ${live.platform} instead of ${live.schedPlatform}.")
                    prev.put("plat", live.platform)
                }
            }
            state.put(h.key, prev)
            if (news.isEmpty()) return@forEach
            val text = StringBuilder(news.joinToString("\n"))
            if (live.needsAlternative) {
                val alts = com.binario.treni.data.NextTrain.alternatives(live, now)
                if (alts.isNotEmpty()) {
                    text.append("\n\n").append(t("Alternative:", "Alternatives:"))
                    alts.forEach { a -> text.append("\n• ").append(Fmt.time(a.dep)).append(" ").append(a.title).append(" · ").append(a.detail) }
                } else {
                    text.append("\n\n").append(t("Nessuna alternativa trovata a breve: apri l'app per altre soluzioni.",
                        "No alternative found soon: open the app for more options."))
                }
            }
            val title = "🚆 ${h.title} " + t("delle", "at") + " ${Fmt.time(live.dep)} · ${h.board.name}"
            Notif.post(ctx, 7000 + kotlin.math.abs(h.key.hashCode()) % 1000, Notif.CH_ALERT, title, text.toString(),
                Notif.openApp(ctx, live.ref, 7000))
            Haptic.alert(ctx, Haptic.Kind.ALERT, title.removePrefix("🚆 ") + ". " + news.joinToString(" "))
        }
        store.setHabitAlertState(state)
    }
}

/**
 * Ogni settimana riscarica gli elenchi ufficiali dei punti vendita (rivendite autorizzate e biglietterie Trenord
 * con orari), solo con rete disponibile. Lo stato "aperto/chiuso" viene invece letto dal vivo quando si apre la schermata.
 */
class SellersWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        com.binario.treni.data.TicketSellers.refreshAll(applicationContext)
        // L'Alto Adige solo se è già stato consultato (evita di calcolare posizioni che non servono)
        if (com.binario.treni.data.TicketSellers.hasAltoAdige(applicationContext)) {
            try { com.binario.treni.data.TicketSellers.refreshAltoAdige(applicationContext) } catch (_: Exception) { }
        }
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<SellersWorker>(7, TimeUnit.DAYS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.UNMETERED).setRequiresBatteryNotLow(true).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("ticket_sellers", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
