package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Salvataggio locale: preferiti, recenti, linee, ricerche offline, promemoria, widget, impostazioni. */
class Store(ctx: Context) {
    private val app = ctx.applicationContext
    private val p = app.getSharedPreferences("binario", Context.MODE_PRIVATE)

    /** Avvisa i widget che i dati sono cambiati. */
    private fun notifyWidgets() = com.binario.treni.widget.Widgets.refreshAll(app)

    private fun arr(k: String): JSONArray = try {
        JSONArray(p.getString(k, "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun <T> list(k: String, f: (JSONObject) -> T): List<T> {
        val a = arr(k)
        return (0 until a.length()).mapNotNull { i ->
            try {
                a.optJSONObject(i)?.let(f)
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun <T> saveList(k: String, l: List<T>, f: (T) -> JSONObject) {
        val a = JSONArray()
        l.forEach { a.put(f(it)) }
        p.edit().putString(k, a.toString()).commit()
        if (k.startsWith("fav_")) notifyWidgets()
    }

    // ---- Tratte ----
    fun favRoutes(): List<Tratta> = list("fav_routes") { Tratta.from(it) }
    fun isFavRoute(t: Tratta) = favRoutes().any { it.key == t.key }
    fun toggleFavRoute(t: Tratta): Boolean {
        val l = favRoutes().toMutableList()
        val existed = l.removeAll { it.key == t.key }
        if (!existed) l.add(0, t)
        saveList("fav_routes", l) { it.toJson() }
        return !existed
    }

    fun recentRoutes(): List<Tratta> = list("recent_routes") { Tratta.from(it) }
    fun addRecent(t: Tratta) {
        val l = recentRoutes().filter { it.key != t.key }.toMutableList()
        l.add(0, t)
        saveList("recent_routes", l.take(10)) { it.toJson() }
    }

    fun recentAndFav(): List<Pair<Tratta, Boolean>> {
        val f = favRoutes()
        return f.map { it to true } + recentRoutes().filter { r -> f.none { it.key == r.key } }.map { it to false }
    }

    // ---- Linee ----
    fun favLines(): List<Linea> = list("fav_lines") { Linea.from(it) }
    fun addLine(l: Linea) = saveList("fav_lines", favLines().filter { it.key != l.key } + l) { it.toJson() }
    fun removeLine(l: Linea) = saveList("fav_lines", favLines().filter { it.key != l.key }) { it.toJson() }

    // ---- Stazioni ----
    fun favStations(): List<Station> = list("fav_stations") { Station.from(it) }
    fun isFavStation(s: Station) = favStations().any { it.id == s.id }
    fun toggleFavStation(s: Station): Boolean {
        val l = favStations().toMutableList()
        val existed = l.removeAll { it.id == s.id }
        if (!existed) l.add(s)
        saveList("fav_stations", l) { it.toJson() }
        return !existed
    }

    // ---- Treni ----
    fun favTrains(): List<TrainRef> = list("fav_trains") { TrainRef.from(it) }
    fun isFavTrain(r: TrainRef) = favTrains().any { it.number == r.number && it.originCode == r.originCode }
    fun toggleFavTrain(r: TrainRef): Boolean {
        val l = favTrains().toMutableList()
        val existed = l.removeAll { it.number == r.number && it.originCode == r.originCode }
        // Nei preferiti non salviamo la data: ogni giorno si usa la corsa del giorno.
        if (!existed) l.add(r.copy(date = 0L))
        saveList("fav_trains", l) { it.toJson() }
        return !existed
    }

    // ---- Treno seguito (notifica fissa) e sveglia fermata ----
    fun tracked(): TrainRef? = p.getString("tracked", null)?.let {
        try {
            TrainRef.from(JSONObject(it))
        } catch (e: Exception) {
            null
        }
    }

    fun setTracked(r: TrainRef?) {
        val e = p.edit()
        if (r == null) {
            e.remove("tracked"); e.remove("wake"); e.remove("board")
        } else {
            e.putString("tracked", r.toJson().toString())
        }
        e.commit()
        notifyWidgets()
    }

    /** Fermata di destinazione per la sveglia (si suona alla partenza dalla fermata precedente). */
    /** Stazione dove salgo sul treno seguito (se diversa dall'origine): binario e avvisi si riferiscono a questa. */
    fun boardingStation(): Station? = p.getString("board", null)?.let {
        try { Station.from(JSONObject(it)) } catch (e: Exception) { null }
    }

    fun setBoardingStation(s: Station?) {
        val e = p.edit()
        if (s == null) e.remove("board") else e.putString("board", s.toJson().toString())
        e.commit()
    }

    fun wakeTarget(): Station? = p.getString("wake", null)?.let {
        try {
            Station.from(JSONObject(it))
        } catch (e: Exception) {
            null
        }
    }

    fun setWakeTarget(s: Station?) {
        val e = p.edit()
        if (s == null) e.remove("wake") else e.putString("wake", s.toJson().toString())
        e.putBoolean("wake_fired", false)
        e.commit()
    }

    var wakeFired: Boolean
        get() = p.getBoolean("wake_fired", false)
        set(v) {
            p.edit().putBoolean("wake_fired", v).commit()
        }

    // ---- Ricerche salvate offline ----
    /** Ultimi risultati di una tratta (copia automatica per l'uso senza rete). Si tengono le ultime 15 tratte. */
    fun cacheResults(routeKey: String, list: List<Solution>) {
        val a = JSONArray(); list.take(40).forEach { a.put(it.toJson()) }
        val keys = (p.getString("res_cache_keys", "") ?: "").split('|').filter { it.isNotBlank() && it != routeKey }
        val keep = (listOf(routeKey) + keys).take(15)
        val e = p.edit()
        (keys - keep.toSet()).forEach { e.remove("res_cache_$it"); e.remove("res_cache_at_$it") }
        e.putString("res_cache_$routeKey", a.toString()).putLong("res_cache_at_$routeKey", System.currentTimeMillis())
            .putString("res_cache_keys", keep.joinToString("|")).apply()
    }

    fun cachedResults(routeKey: String): Pair<Long, List<Solution>>? {
        val txt = p.getString("res_cache_$routeKey", null) ?: return null
        return try {
            val a = JSONArray(txt)
            p.getLong("res_cache_at_$routeKey", 0L) to (0 until a.length()).map { Solution.from(a.getJSONObject(it)) }
        } catch (e: Exception) {
            null
        }
    }

    fun savedSearches(): List<SavedSearch> = list("saved") { SavedSearch.from(it) }
    fun saveSearch(s: SavedSearch) {
        val l = savedSearches().filter { it.key != s.key }.toMutableList()
        l.add(0, s)
        saveList("saved", l.take(30)) { it.toJson() }
    }

    fun deleteSaved(key: String) = saveList("saved", savedSearches().filter { it.key != key }) { it.toJson() }

    // ---- Promemoria ----
    fun reminders(): List<Reminder> = list("reminders") { Reminder.from(it) }
    fun addReminder(r: Reminder) = saveList("reminders", reminders() + r) { it.toJson() }
    fun removeReminder(id: Int) = saveList("reminders", reminders().filter { it.id != id }) { it.toJson() }

    // ---- Widget: configurazione per istanza ----
    fun widgetConfig(id: Int): WidgetConfig? = p.getString("widget_$id", null)?.let {
        try {
            WidgetConfig.from(JSONObject(it))
        } catch (e: Exception) {
            null
        }
    }

    fun setWidgetConfig(id: Int, c: WidgetConfig) {
        p.edit().putString("widget_$id", c.toJson().toString()).commit()
    }

    fun removeWidgetConfig(id: Int) {
        p.edit().remove("widget_$id").commit()
    }

    // ---- Cache coordinate ----
    fun coord(id: String): Pair<Double, Double>? {
        val s = p.getString("coord_$id", null) ?: return null
        val parts = s.split(",")
        val lat = parts.getOrNull(0)?.toDoubleOrNull() ?: return null
        val lon = parts.getOrNull(1)?.toDoubleOrNull() ?: return null
        return lat to lon
    }

    fun setCoord(id: String, c: Pair<Double, Double>) {
        p.edit().putString("coord_$id", "${c.first},${c.second}").apply()
    }

    // ---- News/avvisi già notificati ----
    fun seenNews(): Set<String> = p.getStringSet("seen_news", emptySet())?.toSet() ?: emptySet()
    fun addSeenNews(titles: Collection<String>) {
        p.edit().putStringSet("seen_news", (seenNews() + titles).toList().takeLast(300).toSet()).apply()
    }

    var newsSeeded: Boolean
        get() = p.getBoolean("news_seeded", false)
        set(v) {
            p.edit().putBoolean("news_seeded", v).apply()
        }

    // ---- Treni abituali (solo sul telefono) ----
    fun habits(): List<Habit> = Habits.parse(p.getString("habits", null))
    fun saveHabits(l: List<Habit>) = p.edit().putString("habits", Habits.toText(l)).apply()
    fun recordHabit(h: Habit) {
        if (habitLearning) saveHabits(Habits.record(habits(), h, System.currentTimeMillis()))
    }
    fun removeHabit(key: String) = saveHabits(habits().filter { it.key != key })

    /** Ultimo avviso inviato per ogni treno abituale oggi (evita notifiche ripetute). */
    fun habitAlertState(): JSONObject = try {
        JSONObject(p.getString("habit_alert_state", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }
    fun setHabitAlertState(o: JSONObject) = p.edit().putString("habit_alert_state", o.toString()).apply()

    /** Impara i treni che prendi spesso (dal tabellone, dalle soluzioni, da "Segui" e dai preferiti). */
    var habitLearning: Boolean
        get() = p.getBoolean("set_habits", true)
        set(v) = p.edit().putBoolean("set_habits", v).apply()

    /** Avvisi automatici sul treno abituale (ritardo, soppressione, cambio binario) senza premere "Segui". */
    var habitAlerts: Boolean
        get() = p.getBoolean("set_habit_alerts", true)
        set(v) = p.edit().putBoolean("set_habit_alerts", v).apply()

    // ---- Impostazioni ----
    var startScreen: String
        get() = p.getString("set_start", "search") ?: "search"
        set(v) = p.edit().putString("set_start", v).apply()

    /** "system", "light", "dark" */
    var theme: String
        get() = p.getString("set_theme", "system") ?: "system"
        set(v) = p.edit().putString("set_theme", v).apply()

    /** Versione delle note legali accettata dall'utente (0 = mai). */
    var legalAccepted: Int
        get() = p.getInt("legal_accepted", 0)
        set(v) = p.edit().putInt("legal_accepted", v).apply()

    /** Lingua dell'interfaccia: "it" o "en". */
    var lang: String
        get() = p.getString("set_lang", "it") ?: "it"
        set(v) = p.edit().putString("set_lang", v).apply()

    var openKeyboard: Boolean
        get() = p.getBoolean("set_kbd", true)
        set(v) = p.edit().putBoolean("set_kbd", v).apply()

    var showBuy: Boolean
        get() = p.getBoolean("set_buy", true)
        set(v) = p.edit().putBoolean("set_buy", v).apply()

    var mapsEnabled: Boolean
        get() = p.getBoolean("set_maps", true)
        set(v) = p.edit().putBoolean("set_maps", v).apply()

    var strikeAlerts: Boolean
        get() = p.getBoolean("set_strikes", true)
        set(v) = p.edit().putBoolean("set_strikes", v).apply()

    var routeAlerts: Boolean
        get() = p.getBoolean("set_route_alerts", true)
        set(v) = p.edit().putBoolean("set_route_alerts", v).apply()

    /** Avvisi per persone non vedenti o ipovedenti: voce sintetica + suoni distinti per ogni tipo di avviso. */
    var blindMode: Boolean
        get() = blindLevel != "off"
        set(v) { blindLevel = if (v) "all" else "off" }

    /** "off", "stop" (solo fermata imminente), "all" (tutti gli avvisi vocali). */
    var blindLevel: String
        get() = p.getString("set_blind_level", null) ?: (if (p.getBoolean("set_blind", false)) "all" else "off")
        set(v) = p.edit().putString("set_blind_level", v).apply()

    /** Domanda iniziale su avvisi per sordi e non vedenti già fatta. */
    var a11yAsked: Boolean
        get() = p.getBoolean("a11y_asked", false)
        set(v) = p.edit().putBoolean("a11y_asked", v).apply()

    /** Con la voce attiva, annuncia anche ogni fermata del treno seguito (come gli annunci di bordo). */
    var announceStops: Boolean
        get() = p.getBoolean("set_announce_stops", true)
        set(v) = p.edit().putBoolean("set_announce_stops", v).apply()

    /** Velocità della voce: 0.8 lenta, 1.0 normale, 1.2 veloce. */
    var speechRate: Float
        get() = p.getFloat("set_speech_rate", 1.0f)
        set(v) = p.edit().putFloat("set_speech_rate", v).apply()

    /** Avvisi a tutti gli utenti per cambio binario e aumento del ritardo del treno seguito. */
    var changeAlerts: Boolean
        get() = p.getBoolean("set_change_alerts", true)
        set(v) = p.edit().putBoolean("set_change_alerts", v).apply()

    /** Avvisi accessibili: vibrazione forte con schema per tipo + lampeggio flash. */
    var deafMode: Boolean
        get() = p.getBoolean("set_deaf", false)
        set(v) = p.edit().putBoolean("set_deaf", v).apply()

    /** Modalità daltonici: "off", "redgreen", "tritan". */
    var colorBlind: String
        get() = p.getString("set_colorblind", "off") ?: "off"
        set(v) = p.edit().putString("set_colorblind", v).apply()

    var flashAlerts: Boolean
        get() = p.getBoolean("set_flash", true)
        set(v) = p.edit().putBoolean("set_flash", v).apply()

    var maxChanges: Int
        get() = p.getInt("set_maxchanges", -1)
        set(v) = p.edit().putInt("set_maxchanges", v).apply()

    var excluded: Set<String>
        get() = p.getStringSet("set_excluded", emptySet())?.toSet() ?: emptySet()
        set(v) = p.edit().putStringSet("set_excluded", v).apply()

    // ---- Backup ----
    fun exportJson(): String {
        val o = JSONObject()
        for ((k, v) in p.all) {
            if (k.startsWith("coord_") || k.startsWith("widget_")) continue
            when (v) {
                is Set<*> -> o.put(k, JSONObject().put("set", JSONArray(v.map { it.toString() })))
                else -> o.put(k, v)
            }
        }
        return o.put("_binario_backup", 1).toString(2)
    }

    fun importJson(text: String): Boolean {
        val o = JSONObject(text)
        if (!o.has("_binario_backup")) return false
        val e = p.edit()
        for (k in o.keys()) {
            if (k == "_binario_backup") continue
            when (val v = o.get(k)) {
                is JSONObject -> v.optJSONArray("set")?.let { a -> e.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet()) }
                is Boolean -> e.putBoolean(k, v)
                is Int -> e.putInt(k, v)
                is Long -> e.putLong(k, v)
                is Number -> e.putInt(k, v.toInt())
                else -> e.putString(k, v.toString())
            }
        }
        e.commit()
        notifyWidgets()
        return true
    }
}
