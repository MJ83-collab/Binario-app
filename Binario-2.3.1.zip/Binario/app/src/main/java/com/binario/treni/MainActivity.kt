package com.binario.treni

import android.Manifest
import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.binario.treni.data.Station
import com.binario.treni.data.Store
import com.binario.treni.data.TrainRef
import com.binario.treni.service.Notif
import com.binario.treni.service.StrikeWorker
import com.binario.treni.ui.*
import org.json.JSONObject

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        com.binario.treni.data.FnNetwork.ensure(this)
        // Registro degli errori: se l'app si chiude da sola salviamo il dettaglio (solo sul telefono) e al riavvio
        // proponiamo di inviarlo. Nessun servizio esterno.
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                java.io.File(filesDir, "crash.txt").writeText(
                    "Binario ${com.binario.treni.ui.APP_VERSION} · Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}) · " +
                        "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\n" +
                        java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", java.util.Locale.ITALY).format(java.util.Date()) +
                        " · thread ${t.name}\n\n" + sw.toString().take(12000),
                )
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(t, e)
        }
        com.binario.treni.data.I18n.lang = Store(this).lang
        com.binario.treni.data.ColorBlind.mode = Store(this).colorBlind
        Notif.createChannels(this)
        org.osmdroid.config.Configuration.getInstance().apply {
            load(this@App, getSharedPreferences("osmdroid", MODE_PRIVATE))
            // User agent riconoscibile (richiesto dai server di mappe) e cache delle tessere nella memoria dell'app:
            // senza una cartella scrivibile le tessere venivano riscaricate ogni volta.
            userAgentValue = "Binario/${com.binario.treni.ui.APP_VERSION} (Android; $packageName)"
            val base = java.io.File(cacheDir, "osmdroid")
            setOsmdroidBasePath(base)
            setOsmdroidTileCache(java.io.File(base, "tiles"))
            setTileFileSystemCacheMaxBytes(300L * 1024 * 1024)
            setTileFileSystemCacheTrimBytes(250L * 1024 * 1024)
            setTileDownloadThreads(8.toShort())
            setTileFileSystemThreads(4.toShort())
            setTileDownloadMaxQueueSize(200.toShort())
            setExpirationExtendedDuration(7L * 24 * 3600 * 1000)
        }
        StrikeWorker.schedule(this)
        com.binario.treni.service.SellersWorker.schedule(this)
    }
}

class MainActivity : ComponentActivity() {
    private var pendingIntent by mutableStateOf<Intent?>(null)
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 && !Notif.canPost(this)) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val store = Store(this)
        // Avvio diretto sull'assistente vocale, se scelto nelle impostazioni
        pendingIntent = if (store.startScreen == "voice" && savedInstanceState == null && intent?.data == null &&
            intent?.getStringExtra(EXTRA_TRAIN) == null && intent?.getStringExtra(EXTRA_STATION) == null && intent?.getStringExtra(EXTRA_SCREEN) == null)
            Intent(intent).putExtra(EXTRA_SCREEN, "voice") else intent
        setContent {
            var theme by remember { mutableStateOf(store.theme) }
            BinarioTheme(theme) {
                val nav = rememberNavController()
                val vm: MainViewModel = viewModel()
                val pi = pendingIntent
                LaunchedEffect(pi) {
                    if (pi != null) {
                        handleIntent(pi, nav)
                        pendingIntent = null
                    }
                }
                AppRoot(nav, vm, startRoute(store.startScreen)) { theme = it }
                CrashReportDialog()
                UpdateDialog()
                var legalOk by remember { mutableStateOf(store.legalAccepted == LEGAL_VERSION) }
                LegalConsent(store, onOpenLegal = { nav.navigate("legal") }, onAccepted = { legalOk = true })
                // Dopo le note legali: proposta degli avvisi per persone sorde e non vedenti
                if (legalOk) AccessibilityWelcome(store)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingIntent = intent
    }

    private fun handleIntent(i: Intent, nav: NavHostController) {
        // Collegamenti binario://voce, binario://seguito, binario://notizie (scorciatoie, riquadro rapido, assistenti)
        i.data?.takeIf { it.scheme == "binario" }?.let { u ->
            when (u.host) {
                "voce", "voice", "chiedi" -> nav.navigate("bot?voice=true")
                "seguito", "tracked" -> Store(this).tracked()?.let { nav.navigate(trainRoute(it)) } ?: nav.navigate(AppTab.TRAINS.route)
                "notizie", "news" -> nav.navigate("news")
            }
            return
        }
        i.getStringExtra(EXTRA_TRAIN)?.let {
            try {
                nav.navigate(trainRoute(TrainRef.from(JSONObject(it))))
            } catch (_: Exception) {
            }
            return
        }
        i.getStringExtra(EXTRA_STATION)?.let {
            try {
                nav.navigate(boardRoute(Station.from(JSONObject(it))))
            } catch (_: Exception) {
            }
            return
        }
        when (i.getStringExtra(EXTRA_SCREEN)) {
            "news" -> nav.navigate("news")
            "voice" -> nav.navigate("bot?voice=true")
            "favorites", "trains" -> nav.navigate(AppTab.TRAINS.route)
            "stations" -> nav.navigate(AppTab.STATIONS.route)
        }
    }

    companion object {
        const val EXTRA_TRAIN = "train"
        const val EXTRA_STATION = "station"
        const val EXTRA_SCREEN = "screen"
    }
}

enum class AppTab(val route: String, val label: String, val icon: ImageVector) {
    TIMES("times", "Cerca", Icons.Filled.Search),
    TRAINS("trains", "Treni", Icons.Filled.Train),
    STATIONS("stations", "Stazioni", Icons.Filled.SyncAlt),
    MORE("more", "Altro", Icons.Filled.MoreHoriz),
}

fun startRoute(pref: String) = when (pref) {
    "trains" -> AppTab.TRAINS.route
    "stations" -> AppTab.STATIONS.route
    else -> AppTab.TIMES.route
}

fun trainRoute(r: TrainRef) = "train?num=${Uri.encode(r.number)}&orig=${Uri.encode(r.originCode)}&date=${r.date}"
fun boardRoute(s: Station) = "board?id=${Uri.encode(s.id)}&name=${Uri.encode(s.name)}"

@Composable
fun AppRoot(nav: NavHostController, vm: MainViewModel, start: String, onTheme: (String) -> Unit) {
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val back: () -> Unit = { nav.popBackStack() }
    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                AppTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = route == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, com.binario.treni.data.tx(tab.label)) },
                        label = { Text(com.binario.treni.data.tx(tab.label), fontSize = 12.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Green, selectedTextColor = Green,
                            indicatorColor = Color(0x1F4F9447),
                        ),
                    )
                }
            }
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            NavHost(nav, startDestination = start) {
                composable(AppTab.TIMES.route) {
                    SearchScreen(vm, onSearch = { nav.navigate("results") }, onAdvanced = { nav.navigate("advanced") }, onBot = { nav.navigate("bot") },
                        go = { nav.navigate(it) }, onTrain = { nav.navigate(trainRoute(it)) })
                }
                composable(AppTab.TRAINS.route) {
                    TrainsHome(vm, onOpen = { nav.navigate(trainRoute(it)) }, onLine = { vm.currentLine = it; nav.navigate("line") },
                        onAllLines = { nav.navigate("lines") })
                }
                composable(AppTab.STATIONS.route) {
                    StationsHome(vm, onBoard = { nav.navigate(boardRoute(it)) }, onNearby = { nav.navigate("nearby") },
                        onSellers = { nav.navigate("sellers?id=&name=") }, onToilets = { nav.navigate("toilets?id=&name=") })
                }
                composable(AppTab.MORE.route) { MoreScreen(vm) { nav.navigate(it) } }

                composable("results") {
                    ResultsScreen(vm, onBack = back, onTrain = { vm.tripBoard = vm.from; vm.tripAlight = vm.to; nav.navigate(trainRoute(it)) })
                }
                composable("advanced") { AdvancedScreen(vm, onBack = back) }
                composable(
                    "train?num={num}&orig={orig}&date={date}",
                    arguments = listOf(
                        navArgument("num") { type = NavType.StringType; defaultValue = "" },
                        navArgument("orig") { type = NavType.StringType; defaultValue = "" },
                        navArgument("date") { type = NavType.LongType; defaultValue = 0L },
                    ),
                ) { e ->
                    val a = e.arguments
                    TrainDetailScreen(
                        vm, a?.getString("num") ?: "", a?.getString("orig") ?: "", a?.getLong("date") ?: 0L,
                        onBack = back, onStation = { nav.navigate(boardRoute(it)) },
                    )
                }
                composable(
                    "board?id={id}&name={name}",
                    arguments = listOf(
                        navArgument("id") { type = NavType.StringType; defaultValue = "" },
                        navArgument("name") { type = NavType.StringType; defaultValue = "" },
                    ),
                ) { e ->
                    val st = Station(e.arguments?.getString("name") ?: "", e.arguments?.getString("id") ?: "")
                    BoardScreen(vm, st, onBack = back, onTrain = { vm.tripBoard = st; vm.tripAlight = null; nav.navigate(trainRoute(it)) },
                        onSellers = { s -> nav.navigate("sellers?id=${Uri.encode(s.id)}&name=${Uri.encode(s.name)}") },
                        onToilets = { s -> nav.navigate("toilets?id=${Uri.encode(s.id)}&name=${Uri.encode(s.name)}") })
                }
                composable(
                    "toilets?id={id}&name={name}",
                    arguments = listOf(
                        navArgument("id") { type = NavType.StringType; defaultValue = "" },
                        navArgument("name") { type = NavType.StringType; defaultValue = "" },
                    ),
                ) { e ->
                    val id = e.arguments?.getString("id") ?: ""
                    ToiletsScreen(vm, if (id.isBlank()) null else Station(e.arguments?.getString("name") ?: "", id), onBack = back)
                }
                composable(
                    "sellers?id={id}&name={name}",
                    arguments = listOf(
                        navArgument("id") { type = NavType.StringType; defaultValue = "" },
                        navArgument("name") { type = NavType.StringType; defaultValue = "" },
                    ),
                ) { e ->
                    val id = e.arguments?.getString("id") ?: ""
                    SellersScreen(vm, if (id.isBlank()) null else Station(e.arguments?.getString("name") ?: "", id), onBack = back)
                }
                composable("line") {
                    val l = vm.currentLine
                    if (l != null) LineScreen(vm, l, onBack = back, onTrain = { nav.navigate(trainRoute(it)) },
                        openWeb = { t, u -> nav.navigate("web?title=${Uri.encode(t)}&url=${Uri.encode(u)}") })
                }
                composable("nearby") { NearbyScreen(onBack = back, onBoard = { nav.navigate(boardRoute(it)) }) }
                composable("saved") { SavedScreen(vm, onBack = back, onOpen = { nav.navigate("results") }) }
                composable("reminders") { RemindersScreen(vm, onBack = back) }
                composable("news") { NewsScreen(onBack = back, onGuaranteed = { nav.navigate("guaranteed") }) }
                composable("tickets") { TicketsScreen(onBack = back) }
                composable("settings") { SettingsScreen(vm, onBack = back, onThemeChange = onTheme, onLegal = { nav.navigate("legal") }) }
                composable("widgets") { InfoScreen("Widget", if (com.binario.treni.data.I18n.en) WIDGETS_TEXT_EN else WIDGETS_TEXT, onBack = back) }
                composable("help") { InfoScreen(com.binario.treni.data.tx("Aiuto e FAQ"), if (com.binario.treni.data.I18n.en) HELP_TEXT_EN else HELP_TEXT, onBack = back) }
                composable("changelog") { InfoScreen("Changelog", CHANGELOG_TEXT, onBack = back) }
                composable("railways") { RailwaysScreen(onBack = back) }
                composable("health") { HealthScreen(onBack = back) }
                composable("fixes") { InfoScreen(com.binario.treni.data.tx("Report correzioni"), FIXES_TEXT, onBack = back) }
                val openWeb: (String, String) -> Unit = { t, u -> nav.navigate("web?title=${Uri.encode(t)}&url=${Uri.encode(u)}") }
                composable(
                    "web?title={title}&url={url}",
                    arguments = listOf(
                        navArgument("title") { type = NavType.StringType; defaultValue = "" },
                        navArgument("url") { type = NavType.StringType; defaultValue = "" },
                    ),
                ) { e -> WebScreen(e.arguments?.getString("title") ?: "", e.arguments?.getString("url") ?: "", onBack = back) }
                composable("conditions") { ConditionsScreen(onBack = back, openWeb = openWeb) }
                composable("tilo") { TiloScreen(onBack = back, openWeb = openWeb, onCompare = { nav.navigate("compare") }) }
                composable("compare") { CompareScreen(vm, onBack = back, onTrain = { nav.navigate(trainRoute(it)) }) }
                composable("guaranteed") { GuaranteedScreen(onBack = back, openWeb = openWeb) }
                composable("lines") {
                    LinesScreen(vm, onBack = back, onOpen = { vm.currentLine = it; nav.navigate("line") }, openWeb = openWeb)
                }
                composable("stats") {
                    StatsScreen(vm, onBack = back, onTrain = { nav.navigate(trainRoute(it)) }, onStation = { nav.navigate(boardRoute(it)) })
                }
                composable("legal") { LegalScreen(onBack = back) }
                composable("green") { GreenScreen(vm, onBack = back) }
                composable(
                    "bot?voice={voice}",
                    arguments = listOf(navArgument("voice") { type = NavType.BoolType; defaultValue = false }),
                ) { e ->
                    BotScreen(vm, onBack = back, onTrain = { nav.navigate(trainRoute(it)) }, onStation = { nav.navigate(boardRoute(it)) },
                        startListening = e.arguments?.getBoolean("voice") == true)
                }
                composable("privacy") { InfoScreen(com.binario.treni.data.tx("Privacy e permessi"), if (com.binario.treni.data.I18n.en) PRIVACY_TEXT_EN else PRIVACY_TEXT, onBack = back) }
            }
        }
    }
}
