package com.binario.treni.ui

import com.binario.treni.data.tx
import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.Linea
import com.binario.treni.data.Reminder
import com.binario.treni.data.Station
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.TrainStop
import com.binario.treni.service.Reminders
import com.binario.treni.service.TrackingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Scheda "Treni": ricerca per numero, linee preferite, treni preferiti con stato live. */
@Composable
fun TrainsHome(vm: MainViewModel, onOpen: (TrainRef) -> Unit, onLine: (Linea) -> Unit, onAllLines: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var num by remember { mutableStateOf("") }
    var choices by remember { mutableStateOf<List<TrainRef>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var favs by remember { mutableStateOf(vm.store.favTrains()) }
    var lines by remember { mutableStateOf(vm.store.favLines()) }
    var addLine by remember { mutableStateOf(false) }
    val live = remember { mutableStateMapOf<String, TrainStatus?>() }
    val tracked = remember { vm.store.tracked() }

    LaunchedEffect(favs) {
        favs.forEach { r ->
            live[r.key] = try {
                withContext(Dispatchers.IO) { Api.status(r) }
            } catch (e: Exception) {
                null
            }
        }
    }

    fun search() {
        if (num.isBlank()) return
        searching = true
        scope.launch {
            val l = try {
                withContext(Dispatchers.IO) { Api.trainLookup(num) }
            } catch (e: Exception) {
                toast(ctx, tx("Errore di rete")); emptyList()
            }
            searching = false
            when (l.size) {
                0 -> toast(ctx, "Treno $num non trovato")
                1 -> onOpen(l[0])
                else -> choices = l
            }
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Treni"))
        LazyColumn {
            item {
                NextTrainCard(vm, onOpen) { b, a ->
                    vm.from = b
                    if (a != null) vm.to = a
                    vm.date = MainViewModel.roundToQuarter(System.currentTimeMillis())
                    toast(ctx, tx("Tratta pronta nella scheda Cerca"))
                }
            }
            item {
                WhiteCard {
                    Column(Modifier.padding(12.dp)) {
                        NumberField(num, { num = it; choices = emptyList() }) { search() }
                        if (searching) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Green)
                    }
                }
            }
            if (choices.isNotEmpty()) {
                item { SectionHeader(tx("Più corse con questo numero")) }
                items(choices) { r -> SimpleRow(Icons.Filled.Train, r.label, tx("Tocca per aprire")) { onOpen(r) } }
            }
            if (tracked != null) {
                item { SectionHeader(tx("Treno seguito")) }
                item { SimpleRow(Icons.Filled.NotificationsActive, tracked.label, tx("Notifica fissa attiva")) { onOpen(tracked) } }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionHeader(tx("Linee preferite"))
                    Spacer(Modifier.weight(1f))
                    TextButton(onAllLines) { Icon(Icons.Filled.Route, null, tint = Green); Text(tx("Tutte le linee"), color = Green) }
                    TextButton({ addLine = true }) { Icon(Icons.Filled.Add, null, tint = Green); Text(tx("Aggiungi"), color = Green) }
                }
            }
            if (lines.isEmpty()) item { MessageBox(tx("Aggiungi una linea, es. S5 Varese – Treviglio, per vedere i prossimi treni in entrambe le direzioni.")) }
            items(lines, key = { it.key }) { l ->
                WhiteCard(onClick = { onLine(l) }) {
                    Row(Modifier.padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        LineBadge(l.name.ifBlank { "•" }, l.operator)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${l.a.name} ⇄ ${l.b.name}")
                            if (l.route.isNotBlank()) Text(l.route, color = Muted, fontSize = 12.sp)
                        }
                        IconButton({ vm.store.removeLine(l); lines = vm.store.favLines() }) { Icon(Icons.Filled.Close, tx("Rimuovi"), tint = Muted) }
                    }
                }
            }
            item { SectionHeader(tx("Treni preferiti")) }
            if (favs.isEmpty()) item { MessageBox(tx("Apri un treno e tocca ★ per aggiungerlo qui.")) }
            items(favs, key = { it.key }) { r ->
                val st = live[r.key]
                WhiteCard(onClick = { onOpen(st?.ref ?: r) }) {
                    Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            if (st != null) TrainTitle(st.category, st.number, 16, operator = st.operator) else Text(r.label)
                            Text(
                                if (st != null) "${Fmt.time(st.depTime)} ${st.origin} → ${Fmt.time(st.arrTime)} ${st.destination}" else tx("Caricamento…"),
                                color = Muted, fontSize = 13.sp,
                            )
                        }
                        if (st != null) DelayText(st.delay, st.departed, st.cancelled)
                        IconButton({ vm.store.toggleFavTrain(r); favs = vm.store.favTrains() }) {
                            Icon(Icons.Filled.Star, tx("Rimuovi"), tint = Green)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
    if (addLine) AddLineDialog(onDismiss = { addLine = false }) { l ->
        vm.store.addLine(l); lines = vm.store.favLines(); addLine = false
    }
}

@Composable
private fun AddLineDialog(onDismiss: () -> Unit, onAdd: (Linea) -> Unit) {
    var name by remember { mutableStateOf("") }
    var a by remember { mutableStateOf<Station?>(null) }
    var b by remember { mutableStateOf<Station?>(null) }
    var pick by remember { mutableStateOf<Int?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Nuova linea preferita")) },
        text = {
            Column {
                OutlinedTextField(name, { name = it.take(8) }, label = { Text(tx("Nome (es. S5, RE2)")) }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedButton({ pick = 0 }, Modifier.fillMaxWidth()) { Text(a?.name ?: tx("Capolinea A (es. Varese)")) }
                OutlinedButton({ pick = 1 }, Modifier.fillMaxWidth()) { Text(b?.name ?: tx("Capolinea B (es. Treviglio)")) }
            }
        },
        confirmButton = {
            TextButton({
                val x = a; val y = b
                if (x != null && y != null) onAdd(Linea(name.trim().uppercase(), x, y))
            }) { Text(tx("Salva"), color = Green) }
        },
        dismissButton = { TextButton(onDismiss) { Text(tx("Annulla")) } },
    )
    pick?.let { w ->
        key(w) {
            StationPickerDialog(if (w == 0) tx("Capolinea A") else tx("Capolinea B"), { pick = null }) { s ->
                if (w == 0) a = s else b = s
                pick = null
            }
        }
    }
}

/** Prossimi treni di una linea nelle due direzioni, con ritardi. */
@Composable
fun LineScreen(vm: MainViewModel, line: Linea, onBack: () -> Unit, onTrain: (TrainRef) -> Unit, openWeb: (String, String) -> Unit = { _, _ -> }) {
    var dir by remember { mutableIntStateOf(0) }
    var rows by remember { mutableStateOf<List<Pair<com.binario.treni.data.Solution, TrainStatus?>>?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val t = line.direction(dir == 1)
    LaunchedEffect(dir, tick) {
        rows = null
        rows = try {
            withContext(Dispatchers.IO) {
                val now = System.currentTimeMillis()
                Api.solutions(t.from, t.to, now - 15 * 60_000L, com.binario.treni.data.SearchFilter.ALL, maxChanges = 0)
                    .take(12).mapIndexed { i, s ->
                        val st = if (i < 6) try {
                            Api.status(TrainRef(s.legs.first().number))
                        } catch (e: Exception) {
                            null
                        } else null
                        s to st
                    }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar("Linea ${line.name}", onBack) {
            IconButton({ tick++ }) { Icon(Icons.Filled.Refresh, tx("Aggiorna")) }
        }
        GreenTabs(listOf("→ ${line.b.name}", "→ ${line.a.name}"), dir) { dir = it }
        WhiteCard {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                LineBadge(line.name.ifBlank { "•" }, line.operator)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(line.route.ifBlank { "${line.a.name} – ${line.b.name}" }, fontWeight = FontWeight.SemiBold)
                    if (line.operator.isNotBlank()) Text(line.operator, color = Muted, fontSize = 12.sp)
                }
                val fav = vm.store.favLines().any { it.key == line.key }
                var isFav by remember(line.key) { mutableStateOf(fav) }
                IconButton({
                    if (isFav) vm.store.removeLine(line) else vm.store.addLine(line)
                    isFav = !isFav
                }) { Icon(if (isFav) Icons.Filled.Star else Icons.Outlined.StarBorder, tx("Preferito"), tint = Green) }
            }
            if (line.url.isNotBlank()) {
                MenuRow(Icons.Filled.Info, tx("Stato della linea, avvisi e stazioni"), tx("Pagina ufficiale") + " " + line.operator) {
                    openWeb("${line.name} ${line.route}".trim(), line.url)
                }
            }
        }
        val r = rows
        when {
            r == null -> LoadingBox()
            r.isEmpty() -> MessageBox(tx("Nessun treno diretto trovato in questa direzione"))
            else -> LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
                items(r) { (s, st) ->
                    val leg = s.legs.first()
                    val from = st?.stops?.firstOrNull { it.name.equals(t.from.name, true) }
                    WhiteCard(onClick = { onTrain(st?.ref ?: TrainRef(leg.number, label = leg.title)) }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    TrainTitle(leg.category, leg.number, 15)
                                    Spacer(Modifier.width(6.dp))
                                    CrowdBadge(com.binario.treni.data.Crowd.estimate(s.dep, leg.category, t.from.name, t.to.name))
                                }
                                Text("${Fmt.time(s.dep)} ${t.from.name}", fontWeight = FontWeight.SemiBold)
                                Text("${Fmt.time(s.arr)} ${t.to.name}", color = Muted)
                            }
                            if (from != null) PlatformPair(from.schedPlatform, from.realPlatform, compact = true)
                            Box(Modifier.width(56.dp), contentAlignment = Alignment.Center) {
                                if (st != null) DelayBadge(st.delay, st.cancelled, showZero = true)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Scheda del singolo treno: tragitto, info (affollamento) e mappa. */
@Composable
fun TrainDetailScreen(
    vm: MainViewModel, number: String, origin: String, date: Long,
    onBack: () -> Unit, onStation: (Station) -> Unit,
) {
    val ctx = LocalContext.current
    var ref by remember { mutableStateOf<TrainRef?>(if (origin.isNotBlank()) TrainRef(number, origin, date, number) else null) }
    var choices by remember { mutableStateOf<List<TrainRef>>(emptyList()) }
    var status by remember { mutableStateOf<TrainStatus?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var fav by remember { mutableStateOf(false) }
    var tracking by remember { mutableStateOf(false) }
    var reminder by remember { mutableStateOf(false) }
    var stopMenu by remember { mutableStateOf<TrainStop?>(null) }
    var crowding by remember { mutableStateOf<com.binario.treni.data.Crowd?>(null) }
    var crowdTried by remember { mutableStateOf(false) }
    var pulling by remember { mutableStateOf(false) }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    // Aperto dal tabellone o dalle soluzioni: impara il treno abituale
    val fromBoard = remember { vm.tripBoard.also { vm.tripBoard = null } }
    val fromAlight = remember { vm.tripAlight.also { vm.tripAlight = null } }
    var learned by remember { mutableStateOf(false) }
    fun learn(st: TrainStatus, board: Station?) {
        habitFrom(st, board ?: fromBoard ?: st.stops.firstOrNull()?.station, fromAlight)?.let { vm.store.recordHabit(it) }
    }

    LaunchedEffect(Unit) {
        if (ref == null) {
            loading = true
            val l = try {
                withContext(Dispatchers.IO) { Api.trainLookup(number) }
            } catch (e: Exception) {
                error = tx("Errore di rete"); emptyList()
            }
            loading = false
            when (l.size) {
                0 -> { if (error == null) error = "Treno $number non trovato" }
                1 -> ref = l[0]
                else -> choices = l
            }
        }
    }
    LaunchedEffect(ref, tick) {
        val r = ref ?: return@LaunchedEffect
        while (true) {
            loading = true
            try {
                val s = withContext(Dispatchers.IO) { Api.status(r) }
                status = s
                if (!learned && fromBoard != null) {
                    learned = true
                    habitFrom(s, fromBoard, fromAlight)?.let { vm.store.recordHabit(it) }
                }
                fav = vm.store.isFavTrain(s.ref)
                tracking = vm.store.tracked()?.let { it.number == s.number && it.originCode == s.originCode } ?: false
                error = null
            } catch (e: Exception) {
                if (status == null) error = tx("Impossibile caricare i dati del treno")
            }
            loading = false
            pulling = false
            delay(60_000)
        }
    }
    LaunchedEffect(status?.number) {
        val n = status?.number ?: return@LaunchedEffect
        val s0 = status
        crowding = withContext(Dispatchers.IO) { Api.trenordCrowding(n) }?.let { com.binario.treni.data.Crowd.fromPercent(it) }
            ?: s0?.let { com.binario.treni.data.Crowd.estimate(it.nextStop?.schedDep?.takeIf { d -> d > 0 } ?: it.depTime, it.category, it.origin, it.destination) }
        crowdTried = true
    }

    fun ensureNotif() {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val st = status
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Treno"), onBack) {
            IconButton({ tick++ }) { Icon(Icons.Filled.Refresh, tx("Aggiorna")) }
            if (st != null) IconButton({ fav = vm.store.toggleFavTrain(st.ref); if (fav) learn(st, null) }) {
                Icon(if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder, tx("Preferito"))
            }
            if (st != null) IconButton({ shareText(ctx, st.shareText()) }) { Icon(Icons.Filled.Share, tx("Condividi")) }
        }
        val tabs = if (vm.store.mapsEnabled) listOf(tx("Tragitto"), "Info", tx("Mappa")) else listOf(tx("Tragitto"), "Info")
        GreenTabs(tabs, tab) { tab = it }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        when {
            choices.isNotEmpty() && ref == null -> LazyColumn {
                item { SectionHeader(tx("Scegli la corsa")) }
                items(choices) { r -> SimpleRow(Icons.Filled.Train, r.label, "") { ref = r; choices = emptyList() } }
            }
            st == null && error != null -> MessageBox(error ?: "")
            st == null -> LoadingBox()
            tab == 0 -> PullRefresh(pulling, { pulling = true; tick++ }) { LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 6.dp)) {
                item { HeaderCards(st, crowding) }
                if (st.delay >= 30) item { CompensationCard(st) }
                item {
                    WhiteCard {
                        Column(Modifier.padding(vertical = 6.dp)) {
                            val n = st.stops.size
                            st.stops.forEachIndexed { i, s ->
                                StopRow(s, i == 0, i == n - 1, i < n - 1 && st.stops[i + 1].passed, st.lastStation) { stopMenu = s }
                            }
                        }
                    }
                }
                item {
                    Text(tx("Tocca una fermata per il tabellone o per la sveglia.") + " " + tx("Trascina giù per aggiornare."),
                        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
                }
            } }
            tab == 1 -> PullRefresh(pulling, { pulling = true; tick++ }) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                HeaderCards(st, crowding)
                InfoCard(st, crowding, crowdTried, tracking, fav,
                    onFollow = {
                        if (tracking) {
                            TrackingService.stop(ctx); tracking = false
                        } else {
                            ensureNotif(); TrackingService.start(ctx, st.ref); tracking = true; learn(st, null)
                            toast(ctx, tx("Notifica fissa attivata"))
                        }
                    },
                    onFav = { fav = vm.store.toggleFavTrain(st.ref); if (fav) learn(st, null) },
                    onRemind = { reminder = true },
                    showBuy = vm.store.showBuy,
                )
                TrainPunctuality(st.number, listOfNotNull(st.stops.firstOrNull(), st.stops.lastOrNull()).any { com.binario.treni.data.FnNetwork.isFn(it.id) })
            } }
            else -> TrainMap(vm, st)
        }
    }

    stopMenu?.let { s ->
        AlertDialog(
            onDismissRequest = { stopMenu = null },
            title = { Text(s.name) },
            text = {
                Column {
                    MenuRow(Icons.Filled.DepartureBoard, tx("Partenze e arrivi da qui")) { stopMenu = null; onStation(s.station) }
                    if (st != null && !s.passed && st.stops.indexOf(s) < st.stops.size - 1) {
                        MenuRow(Icons.Filled.DirectionsWalk, tx("Salgo qui"),
                            tx("Binario, orario e avvisi riferiti a questa fermata (anche a voce)")) {
                            stopMenu = null
                            ensureNotif()
                            TrackingService.start(ctx, st.ref, s.station)
                            tracking = true
                            learn(st, s.station)
                            toast(ctx, tx("Ti avviserò per la salita a") + " " + s.name)
                        }
                    }
                    if (st != null && !s.passed && st.stops.indexOf(s) > 0) {
                        MenuRow(Icons.Filled.Alarm, tx("Svegliami prima di questa fermata"),
                            tx("Allarme quando il treno lascia la fermata precedente")) {
                            stopMenu = null
                            ensureNotif()
                            TrackingService.startWake(ctx, st.ref, s.station)
                            tracking = true
                            toast(ctx, "Sveglia attiva per ${s.name}")
                        }
                    }
                    if (st != null && !s.passed && s.schedArr > System.currentTimeMillis() + 5 * 60_000L) {
                        MenuRow(Icons.Filled.NotificationsActive, tx("Avvisami 10 minuti prima dell'arrivo qui")) {
                            stopMenu = null
                            val ev = s.schedArr + st.delay * 60_000L
                            Reminders.add(ctx, Reminder((System.currentTimeMillis() % 1_000_000).toInt(), st.number, st.originCode,
                                ev - 10 * 60_000L, ev, "${st.title} · arrivo a ${s.name}", true))
                            ensureNotif()
                            toast(ctx, "Ti avviserò alle ${Fmt.time(ev - 10 * 60_000L)}")
                        }
                    }
                }
            },
            confirmButton = { TextButton({ stopMenu = null }) { Text(tx("Chiudi")) } },
        )
    }

    if (reminder && st != null) {
        ReminderDialog({ reminder = false }) { min, arrival ->
            val ev = if (arrival) st.arrTime else st.depTime
            val at = ev - min * 60_000L
            if (at < System.currentTimeMillis()) toast(ctx, tx("Orario già passato"))
            else {
                Reminders.add(ctx, Reminder((System.currentTimeMillis() % 1_000_000).toInt(), st.number, st.originCode, at, ev,
                    "${st.title} ${st.origin} → ${st.destination}", arrival))
                ensureNotif()
                toast(ctx, "Ti avviserò alle ${Fmt.time(at)}")
            }
            reminder = false
        }
    }
}

/** Le due schede in alto: treno con origine/destinazione e stato attuale. */
@Composable
private fun HeaderCards(st: TrainStatus, crowding: com.binario.treni.data.Crowd?) {
    WhiteCard {
        Column(Modifier.padding(14.dp)) {
            TrainTitle(st.category, st.number, 20, operator = st.operator)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.RadioButtonChecked, null, tint = Color(0xFF616161), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(10.dp))
                Text(Fmt.time(st.depTime), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.width(8.dp)); Text(st.origin, fontSize = 17.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.RadioButtonUnchecked, null, tint = Color(0xFF616161), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(10.dp))
                Text(Fmt.time(st.arrTime), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.width(8.dp)); Text(st.destination, fontSize = 17.sp)
            }
        }
    }
    WhiteCard {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Outlined.Schedule, null, tint = Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    val (num, rest) = when {
                        st.cancelled -> "" to tx("Treno soppresso")
                        !st.departed && st.delay == 0 -> "" to tx("Non ancora partito")
                        st.delay > 0 -> "${st.delay} min" to tx(" in ritardo")
                        st.delay < 0 -> "${-st.delay} min" to tx(" in anticipo")
                        else -> "" to (if (st.arrived) tx("Arrivato in orario") else tx("In orario"))
                    }
                    Row {
                        Text(num, color = if (st.delay > 0) LateRed else Green, fontSize = 16.sp)
                        Text(rest, fontSize = 16.sp, color = if (st.cancelled) LateRed else MaterialTheme.colorScheme.onSurface)
                    }
                    if (st.departed && st.lastStation.isNotBlank()) Text("${Fmt.time(st.lastTime)} ${st.lastStation}", fontSize = 16.sp)
                }
            }
            if (st.info.isNotBlank()) Row(Modifier.padding(top = 6.dp)) {
                Icon(Icons.Outlined.Info, null, tint = Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp)); Text(st.info, fontSize = 15.sp)
            }
            if (crowding != null) Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.width(1.dp))
                CrowdBadge(crowding, withLabel = true)
                if (crowding.percent != null) Text("  (${crowding.percent}%)", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

fun crowdLabel(p: Int) = when {
    p < 35 -> "basso"
    p < 70 -> "medio"
    else -> "alto"
}

fun crowdColor(p: Int) = when {
    p < 35 -> Color(com.binario.treni.data.Crowd.Level.LOW.color)
    p < 70 -> Color(com.binario.treni.data.Crowd.Level.MEDIUM.color)
    else -> Color(com.binario.treni.data.Crowd.Level.HIGH.color)
}

@Composable
private fun InfoCard(
    st: TrainStatus, crowding: com.binario.treni.data.Crowd?, crowdTried: Boolean, tracking: Boolean, fav: Boolean,
    onFollow: () -> Unit, onFav: () -> Unit, onRemind: () -> Unit, showBuy: Boolean,
) {
    val ctx = LocalContext.current
    WhiteCard {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(6.dp), horizontalArrangement = Arrangement.SpaceAround) {
            ActionChip(if (tracking) Icons.Filled.NotificationsActive else Icons.Outlined.NotificationsNone, if (tracking) tx("Seguito") else tx("Segui"), tracking, onFollow)
            ActionChip(if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder, tx("Preferito"), fav, onFav)
            ActionChip(Icons.Filled.Alarm, "Avvisami", onClick = onRemind)
            ActionChip(Icons.Filled.Event, tx("Calendario")) {
                addToCalendar(ctx, "${st.title} ${st.origin} → ${st.destination}", st.depTime, st.arrTime, st.origin)
            }
            if (showBuy) ActionChip(Icons.Filled.ShoppingCart, tx("Biglietto")) { openUrl(ctx, buyUrl(st.category)) }
        }
    }
    WhiteCard {
        CardTitle(tx("Affollamento"))
        Column(Modifier.padding(16.dp)) {
            when {
                crowding != null -> {
                    CrowdBadge(crowding, withLabel = true)
                    val frac = crowding.percent?.div(100f) ?: when (crowding.level) {
                        com.binario.treni.data.Crowd.Level.LOW -> 0.3f
                        com.binario.treni.data.Crowd.Level.MEDIUM -> 0.65f
                        com.binario.treni.data.Crowd.Level.HIGH -> 0.95f
                    }
                    LinearProgressIndicator(
                        progress = { frac }, color = Color(crowding.level.color),
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                    if (crowding.percent != null) Text("${crowding.percent}% " + tx("dei posti occupati"), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    Text(tx("Fonte") + ": " + crowding.source.label, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    if (crowding.source == com.binario.treni.data.Crowd.Source.ESTIMATE) Text(
                        tx("Dato ufficiale non disponibile: stima per fascia oraria (ore di punta feriali, treni da/verso Milano)."),
                        color = Muted, fontSize = 12.sp,
                    )
                    Text(tx("Verde: molti posti · Giallo: cerca bene i posti · Rosso: pieno, meglio attendere il treno successivo"),
                        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    TextButton({ openUrl(ctx, "https://www.trenord.it") }) { Text(tx("Affollamento in tempo reale nell'app Trenord"), color = Green) }
                }
                !crowdTried -> Text(tx("Caricamento…"), color = Muted)
                else -> {
                    Text(tx("Dato non disponibile per questo treno."), color = Muted)
                    TextButton({ openUrl(ctx, "https://www.trenord.it") }) { Text(tx("Verifica sul sito Trenord"), color = Green) }
                }
            }
        }
    }
    WhiteCard {
        CardTitle(tx("Servizi e accessibilità"))
        Column(Modifier.padding(16.dp)) {
            Text(
                tx("I servizi a bordo (bici, posti per carrozzina, classi) non sono pubblicati nei dati in tempo reale. ") +
                    tx("Puoi consultarli sull'orario ufficiale della compagnia."),
                color = Muted, fontSize = 14.sp,
            )
            TextButton({ openUrl(ctx, buyUrl(st.category)) }) { Text(tx("Apri l'orario ufficiale"), color = Green) }
            TextButton({ openUrl(ctx, "https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/le-informazioni-sull-assistenza-delle-sale-blu-in-un-click.html") }) {
                Text(tx("Assistenza Sala Blu (persone con disabilità)"), color = Green)
            }
        }
    }
}

/** Una fermata: pallino blu se transitato, orari programmati e reali, binario. */
@Composable
private fun StopRow(s: TrainStop, first: Boolean, last: Boolean, nextPassed: Boolean, lastSeen: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clickable(onClick = onClick).padding(start = 16.dp, end = 12.dp)) {
        Box(Modifier.width(18.dp).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
            Column(Modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.width(2.dp).height(12.dp).background(if (first) Color.Transparent else if (s.passed) PassedBlue else Color(0xFFD6D6D6)))
                StopDot(s.passed, if (lastSeen.isNotBlank() && s.name.equals(lastSeen, true)) 18 else 15)
                Box(Modifier.width(2.dp).weight(1f).background(if (last) Color.Transparent else if (nextPassed) PassedBlue else Color(0xFFD6D6D6)))
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f).padding(top = 6.dp, bottom = 10.dp)) {
            Text(s.name, fontSize = 18.sp)
            TimeLine(tx("Arrivo"), if (first) 0 else s.schedArr, if (first) 0 else s.realArr, s.delay, s.passed)
            TimeLine(tx("Partenza"), if (last) 0 else s.schedDep, if (last) 0 else s.realDep, s.delay, s.passed)
        }
        Box(Modifier.padding(top = 10.dp)) { PlatformPair(s.schedPlatform, s.realPlatform) }
    }
}

@Composable
private fun TimeLine(label: String, sched: Long, real: Long, delay: Int, passed: Boolean) {
    Row {
        Text(label, color = Muted, fontSize = 14.sp, modifier = Modifier.width(80.dp))
        Text(if (sched > 0) Fmt.time(sched) else "--:--", fontSize = 14.sp, color = if (sched > 0) MaterialTheme.colorScheme.onSurface else Muted)
        if (real > 0 && sched > 0) {
            val late = real - sched > 60_000
            Text("  ${Fmt.time(real)}", fontSize = 14.sp, color = if (late) LateRed else Green)
        } else if (!passed && delay > 0 && sched > 0) {
            Text("  ${Fmt.time(sched + delay * 60_000L)}", fontSize = 14.sp, color = Color(0xFFEF6C00))
        }
    }
}

/**
 * Indennizzo per ritardo (regole pubbliche): dai 60 minuti il Regolamento UE 2021/782 prevede il 25% del biglietto
 * (50% dai 120); per le Frecce Trenitalia riconosce un indennizzo già tra 30 e 59 minuti.
 */
@Composable
private fun CompensationCard(st: com.binario.treni.data.TrainStatus) {
    val ctx = LocalContext.current
    val cat = st.category.uppercase()
    val frecce = listOf("FR", "FA", "FB", "FRECCIA").any { cat.startsWith(it) }
    val italo = cat.startsWith("ITA") || cat.contains("ITALO")
    val longDistance = frecce || italo || listOf("IC", "EC", "EN", "ICN").any { cat.startsWith(it) }
    if (st.delay < 60 && !frecce) return
    WhiteCard {
        CardTitle(tx("Rimborso per il ritardo"))
        Column(Modifier.padding(16.dp)) {
            Text(
                when {
                    st.delay >= 120 -> tx("Ritardo oltre 2 ore: puoi chiedere un indennizzo del 50% del prezzo del biglietto.")
                    st.delay >= 60 -> tx("Ritardo oltre 1 ora: puoi chiedere un indennizzo del 25% del prezzo del biglietto.")
                    else -> tx("Frecce con 30–59 minuti di ritardo: Trenitalia riconosce un indennizzo. Controlla le condizioni sul sito.")
                },
                fontSize = 15.sp,
            )
            Text(tx("Vale il ritardo all'arrivo nella tua stazione; gli abbonati hanno regole proprie. Fonte: Regolamento UE 2021/782 e condizioni delle aziende."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            when {
                italo -> TextButton({ openUrl(ctx, "https://www.italotreno.com/it/contatti-supporto") }) { Text(tx("Richiedi a Italo"), color = Green) }
                longDistance -> TextButton({ openUrl(ctx, "https://www.trenitalia.com/it/informazioni/indennizzo-per-ritardodeltreno.html") }) {
                    Text(tx("Richiedi a Trenitalia"), color = Green)
                }
                else -> {
                    TextButton({ openUrl(ctx, "https://www.trenord.it/assistenza/servizi/rimborsi-e-indennizzi/") }) { Text(tx("Rimborsi Trenord"), color = Green) }
                    TextButton({ openUrl(ctx, "https://www.trenitalia.com/it/informazioni/indennizzo-per-ritardodeltreno.html") }) {
                        Text(tx("Indennizzi Trenitalia Regionale"), color = Green)
                    }
                }
            }
        }
    }
}

@Composable
private fun TrainMap(vm: MainViewModel, st: TrainStatus) {
    var points by remember(st.number) { mutableStateOf<List<MapPoint>?>(null) }
    LaunchedEffect(st.number, st.originCode) {
        points = withContext(Dispatchers.IO) {
            // Coordinate delle fermate in parallelo (8 alla volta): prima erano lette una per una e la mappa ci metteva molto
            val coords = HashMap<String, Pair<Double, Double>?>()
            st.stops.map { it.id }.distinct().chunked(8).forEach { group ->
                kotlinx.coroutines.coroutineScope {
                    group.map { id -> async { id to runCatching { Api.stationCoord(vm.store, id) }.getOrNull() } }
                        .forEach { d -> val (id, c) = d.await(); coords[id] = c }
                }
            }
            st.stops.mapNotNull { s ->
                coords[s.id]?.let { (lat, lon) ->
                    val passed = if (s.passed) "✓ " else ""
                    val arr = if (s.schedArr > 0) "Arrivo ${Fmt.time(s.schedArr)}" + (if (s.realArr > 0) " (${Fmt.time(s.realArr)})" else "") else ""
                    val dep = if (s.schedDep > 0) "Partenza ${Fmt.time(s.schedDep)}" + (if (s.realDep > 0) " (${Fmt.time(s.realDep)})" else "") else ""
                    MapPoint(lat, lon, passed + s.name,
                        listOf(arr, dep,
                            if (s.schedPlatform.isNotBlank()) tx("Binario previsto") + " ${s.schedPlatform}" else "",
                            if (s.realPlatform.isNotBlank()) tx("Binario reale") + " ${s.realPlatform}" else "").filter { it.isNotBlank() }.joinToString("\n"))
                }
            }
        }
    }
    val p = points
    if (p == null) LoadingBox()
    else if (p.isEmpty()) MessageBox(tx("Coordinate delle fermate non disponibili"))
    else OsmMap(p, drawLine = true, modifier = Modifier.fillMaxSize())
}

/** Treno abituale da una corsa: serve la stazione dove sali (deve essere una fermata del treno) e la partenza di oggi. */
fun habitFrom(st: TrainStatus, board: Station?, alight: Station?): com.binario.treni.data.Habit? {
    val x = board ?: return null
    val b = st.stops.firstOrNull { it.id == x.id } ?: st.stops.firstOrNull { it.name.equals(x.name, true) } ?: return null
    val bi = st.stops.indexOf(b)
    if (bi >= st.stops.size - 1 || st.cancelled && b.schedDep <= 0) return null
    val dep = b.schedDep.takeIf { it > 0 } ?: return null
    val now = System.currentTimeMillis()
    if (com.binario.treni.data.Habits.midnight(dep) != com.binario.treni.data.Habits.midnight(now)) return null
    val a = alight?.let { y -> st.stops.drop(bi + 1).firstOrNull { it.id == y.id || it.name.equals(y.name, true) }?.station ?: y }
    return com.binario.treni.data.Habit(
        number = st.number, category = st.category, operator = st.operator,
        originCode = if (Regex("S\\d+").matches(st.originCode)) st.originCode else "",
        board = b.station, alight = a?.takeIf { it.id != b.id },
        minute = com.binario.treni.data.Habits.minuteOfDay(dep), days = List(7) { 0 }, lastDay = 0L,
    )
}
