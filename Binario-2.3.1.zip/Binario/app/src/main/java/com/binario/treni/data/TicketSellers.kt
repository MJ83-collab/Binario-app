package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Punti vendita UFFICIALI dei biglietti (non tutte le tabaccherie):
 * - Trenord (Lombardia): rivendite autorizzate (bar, tabaccherie, edicole, agenzie) e biglietterie con orari,
 *   dal sito biglietterie.trenord.it. L'elenco si aggiorna ogni settimana; lo stato "aperto/chiuso" è letto dal vivo.
 * - FFS/SBB (Svizzera): biglietterie automatiche dai dati aperti data.sbb.ch.
 * - Trenitalia (resto d'Italia): i biglietti regionali si vendono nei punti dei circuiti PuntoLIS e Mooney;
 *   Trenitalia non pubblica un elenco scaricabile, quindi l'app apre la sua mappa ufficiale ([TRENITALIA_MAP]).
 */
object TicketSellers {
    const val TRENORD_SITE = "https://biglietterie.trenord.it/it/punti-vendita"
    const val TRENITALIA_MAP = "https://locator.ubiest.com/storeLocator/customers/trenitalia/biglietterie/"
    const val TRENITALIA_INFO = "https://www.trenitalia.com/it/informazioni/punti-vendita.html"
    const val SBB_DATA = "https://data.sbb.ch/explore/dataset/billetautomat/"
    const val BZ_SITE = "https://www.suedtirolmobil.info/it/ticket/punti-vendita/punti-vendita-altoadigemobilita"
    private const val BASE = "https://biglietterie.trenord.it"
    private const val WEEK = 7 * 24 * 3600_000L
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36 Binario/2.3"

    /** Province delle pagine Trenord con il codice usato negli indirizzi delle biglietterie. */
    private val PROVINCES = linkedMapOf(
        "bergamo" to "bg", "brescia" to "bs", "como" to "co", "cremona" to "cr", "lecco" to "lc", "lodi" to "lo",
        "mantova" to "mn", "milano" to "mi", "monza" to "mb", "pavia" to "pv", "sondrio" to "so", "varese" to "va",
    )

    private val DAYS = listOf("lunedì", "martedì", "mercoledì", "giovedì", "venerdì", "sabato", "domenica")
    private val DAYS_SHORT = listOf("Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom")

    /** Un punto vendita ufficiale. */
    data class Seller(
        val source: String,
        val kind: OsmPlace.Kind,
        val name: String,
        val lat: Double,
        val lon: Double,
        val nearStation: String = "",
        val province: String = "",
        /** Stato letto dal vivo, es. "Aperto - Chiude alle: 19:30". */
        val status: String = "",
        /** Orari settimanali in forma compatta, es. "Lun–Dom 6:00–20:00". */
        val hours: String = "",
        val address: String = "",
        val url: String = "",
        /** Cosa si può comprare (es. "Biglietti singoli · Mobilcard"). */
        val services: String = "",
    ) {
        fun toJson(): JSONObject = JSONObject().put("s", source).put("k", kind.name).put("n", name).put("la", lat).put("lo", lon)
            .put("ns", nearStation).put("p", province).put("st", status).put("h", hours).put("a", address).put("u", url)
            .put("sv", services)

        companion object {
            fun from(o: JSONObject) = Seller(o.optString("s"), OsmPlace.Kind.valueOf(o.optString("k", "RESELLER")), o.optString("n"),
                o.optDouble("la"), o.optDouble("lo"), o.optString("ns"), o.optString("p"), o.optString("st"), o.optString("h"),
                o.optString("a"), o.optString("u"), o.optString("sv"))
        }
    }

    // ---------------- Rete ----------------

    private fun http(url: String, timeout: Int = 15000): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = timeout
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept-Language", "it-IT,it;q=0.9")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun text(html: String): String = html
        .replace(Regex("(?is)<script.*?</script>|<style.*?</style>"), " ")
        .replace(Regex("<[^>]+>"), " ")
        .replace("&amp;", "&").replace("&nbsp;", " ").replace("&#x27;", "'").replace("&#39;", "'").replace("&quot;", "\"")
        .replace(Regex("\\s+"), " ").trim()

    private fun cap(s: String) = s.trim().lowercase().split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }

    // ---------------- Trenord: rivendite autorizzate (pagine di provincia) ----------------

    /** Legge le rivendite di una provincia: nome, posizione, stazione più vicina e stato attuale. */
    fun parseProvince(html: String, province: String): List<Seller> {
        val out = ArrayList<Seller>()
        val re = Regex("destination=(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)")
        val marks = re.findAll(html).toList()
        marks.forEachIndexed { i, m ->
            val end = if (i + 1 < marks.size) marks[i + 1].range.first else minOf(html.length, m.range.last + 4000)
            val card = html.substring(m.range.last, end)
            if (!card.contains("Stazione più vicina") && !card.contains("Stazione pi&ugrave; vicina")) return@forEachIndexed
            val name = Regex("<h3[^>]*>([^<]+)</h3>").find(card)?.groupValues?.get(1)?.trim() ?: return@forEachIndexed
            val near = Regex("vicina:\\s*(?:<[^>]+>\\s*)*([^<]+)<").find(card)?.groupValues?.get(1)?.trim().orEmpty()
            val statusRaw = Regex("bold-status[^>]*>([^<]+)</span>([^<]*)").find(card)?.let { s ->
                (s.groupValues[1] + s.groupValues[2]).replace(Regex("\\s+"), " ").trim()
            }.orEmpty()
            out += Seller("Trenord", OsmPlace.Kind.RESELLER, cap(text(name)), m.groupValues[1].toDouble(), m.groupValues[2].toDouble(),
                nearStation = cap(text(near)), province = province, status = statusRaw)
        }
        return out.distinctBy { "${it.name}|${it.lat}|${it.lon}" }
    }

    // ---------------- Trenord: biglietterie con orari (pagine singole) ----------------

    /** Orari settimanali in forma compatta: giorni consecutivi con lo stesso orario vengono uniti. */
    fun compactHours(byDay: List<String>): String {
        if (byDay.all { it.isBlank() }) return ""
        val groups = ArrayList<Triple<Int, Int, String>>()
        byDay.forEachIndexed { d, h ->
            val last = groups.lastOrNull()
            if (last != null && last.third == h && last.second == d - 1) groups[groups.size - 1] = Triple(last.first, d, h)
            else groups += Triple(d, d, h)
        }
        return groups.filter { it.third.isNotBlank() }.joinToString(" · ") { (a, b, h) ->
            (if (a == b) DAYS_SHORT[a] else DAYS_SHORT[a] + "–" + DAYS_SHORT[b]) + " " + h
        }
    }

    fun parseOffice(html: String, url: String): Seller? {
        val coord = Regex("destination=(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)").find(html) ?: return null
        val t = text(html)
        val title = Regex("(?is)<title>([^<|]+)").find(html)?.groupValues?.get(1)?.trim() ?: return null
        val byDay = DAYS.map { day ->
            Regex("(?i)$day\\s+((?:\\d{1,2}[:.]\\d{2}\\s*-\\s*\\d{1,2}[:.]\\d{2}[\\s,;]*)+|chiuso)").find(t)
                ?.groupValues?.get(1)?.trim()?.trimEnd(',', ';')?.replace(" - ", "–")?.replace("-", "–")?.let {
                    if (it.equals("chiuso", true)) "chiuso" else it
                }.orEmpty()
        }
        val status = Regex("(Aperto|Chiuso)\\s*-\\s*(?:Chiude|Apre)[^0-9]{0,30}\\d{1,2}[:.]\\d{2}").find(t)?.value.orEmpty()
        val address = Regex("\\d{1,2}[:.]\\d{2}\\s+([^:]{5,90}?,\\s*\\d{5},\\s*Lombardia)").find(t)?.groupValues?.get(1)?.trim().orEmpty()
        val province = PROVINCES.entries.firstOrNull { url.contains("punti-vendita-${it.value}/") }?.key.orEmpty()
        return Seller("Trenord", OsmPlace.Kind.TICKET_OFFICE, cap(title.trim()),
            coord.groupValues[1].toDouble(), coord.groupValues[2].toDouble(), province = province,
            status = status, hours = compactHours(byDay), address = address, url = url)
    }

    /** Indirizzi di tutte le biglietterie Trenord, dalla mappa del sito. */
    private fun officeUrls(): List<String> =
        Regex("<loc>([^<]+)</loc>").findAll(http("$BASE/sitemap1.xml")).map { it.groupValues[1].trim() }
            .filter { it.contains("/it/punti-vendita-") && (it.contains("/biglietteria-") || it.contains("/my-link-point")) }
            .distinct().toList()

    // ---------------- Alto Adige (altoadigemobilità / STA, treni SAD e Trenitalia) ----------------

    /** Una voce dell'elenco altoadigemobilità prima di ricavare le coordinate. */
    data class RawPoint(val town: String, val name: String, val address: String, val hours: String, val services: String)

    /** Legge l'elenco ufficiale altoadigemobilità: località, nome, indirizzo, orari e servizi venduti. */
    fun parseAltoAdige(html: String): List<RawPoint> {
        val marks = Regex("(?is)AccordionCMS__labelText\">([^<]+)<|<h2[^>]*>(.*?)</h2>").findAll(html).toList()
        val out = ArrayList<RawPoint>()
        var town = ""
        marks.forEachIndexed { i, m ->
            if (m.groupValues[1].isNotBlank()) { town = text(m.groupValues[1]); return@forEachIndexed }
            val name = text(m.groupValues[2])
            if (name.isBlank()) return@forEachIndexed
            val end = if (i + 1 < marks.size) marks[i + 1].range.first else html.length
            val block = html.substring(m.range.last + 1, end)
            val services = Regex("(?is)<li[^>]*>(.*?)</li>").findAll(block).map { text(it.groupValues[1]) }.filter { it.isNotBlank() }.joinToString(" · ")
            val t = text(block.replace(Regex("(?is)<ul.*?</ul>"), " "))
            val address = Regex("""(?i)(?:Indirizzo|Adresse):\s*(.+?)(?=\s*(?:Orari?o?\s+d|Telefono|Servizi|E-mail|$))""").find(t)?.groupValues?.get(1)?.trim().orEmpty()
            val hours = Regex("""(?i)Orari?o?\s+d[i’']\s*apertura:?\s*(.+?)(?=\s*(?:Telefono|Servizi|E-mail|$))""").find(t)?.groupValues?.get(1)
                ?.replace("ore ", "")?.trim().orEmpty()
            out += RawPoint(town, name, address, hours, services)
        }
        return out
    }

    private fun geoCacheFile(ctx: Context) = File(ctx.filesDir, "geocode_cache.json")

    /**
     * Coordinate da un indirizzo con il servizio gratuito Nominatim di OpenStreetMap (massimo 1 richiesta al secondo,
     * come chiede la sua policy). I risultati restano in memoria: le settimane successive si cercano solo gli indirizzi nuovi.
     */
    private fun geocode(ctx: Context, queries: List<String>): Map<String, Pair<Double, Double>> {
        val cache = try { JSONObject(geoCacheFile(ctx).readText()) } catch (e: Exception) { JSONObject() }
        val out = HashMap<String, Pair<Double, Double>>()
        var asked = 0
        for (q in queries.distinct()) {
            val hit = cache.optString(q)
            if (hit.isNotBlank()) {
                if (hit != "x") hit.split(",").let { p -> out[q] = p[0].toDouble() to p[1].toDouble() }
                continue
            }
            if (asked > 0) Thread.sleep(1100)
            asked++
            val r = try {
                val c = (URL("https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=it,at&q=" +
                    java.net.URLEncoder.encode(q, "UTF-8")).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000; readTimeout = 15000
                    setRequestProperty("User-Agent", "Binario/2.3 (+https://github.com/MJ83-collab/Binario; Android app com.binario.treni)")
                }
                try { JSONArray(c.inputStream.bufferedReader().use { it.readText() }) } finally { c.disconnect() }
            } catch (e: Exception) {
                null
            } ?: continue // errore di rete: si riprova la prossima volta
            val first = r.optJSONObject(0)
            if (first != null) {
                val la = first.optString("lat").toDouble(); val lo = first.optString("lon").toDouble()
                out[q] = la to lo; cache.put(q, "$la,$lo")
            } else cache.put(q, "x")
        }
        try { geoCacheFile(ctx).writeText(cache.toString()) } catch (_: Exception) { }
        return out
    }

    private fun bzCacheFile(ctx: Context) = File(ctx.filesDir, "sellers_altoadige.json")

    /** Scarica di nuovo l'elenco altoadigemobilità e ricava le coordinate (solo per gli indirizzi nuovi). */
    @Synchronized
    fun refreshAltoAdige(ctx: Context, onProgress: (String) -> Unit = {}): List<Seller> {
        onProgress(I18n.tr("Scarico i punti vendita dell'Alto Adige…", "Downloading South Tyrol ticket outlets…"))
        val raw = parseAltoAdige(http(BZ_SITE, 25000))
        if (raw.isEmpty()) throw IOException("Elenco altoadigemobilità vuoto")
        fun query(p: RawPoint) = if (p.address.isNotBlank()) p.address else "${p.town}, Alto Adige"
        onProgress(I18n.tr("Calcolo le posizioni…", "Locating outlets…"))
        val geo = geocode(ctx, raw.map { query(it) } + raw.map { "${it.town}, Alto Adige" })
        val items = raw.mapNotNull { p ->
            val c = geo[query(p)] ?: geo["${p.town}, Alto Adige"] ?: return@mapNotNull null
            val kind = if (p.name.contains("Biglietteria", true) || p.name.contains("Infopoint", true)) OsmPlace.Kind.TICKET_OFFICE
            else OsmPlace.Kind.RESELLER
            Seller("altoadigemobilità", kind, if (p.name.startsWith("Biglietteria", true)) "${p.name} · ${p.town}" else p.name,
                c.first, c.second, hours = p.hours, address = p.address.ifBlank { p.town }, url = BZ_SITE, services = p.services)
        }
        val a = JSONArray(); items.forEach { a.put(it.toJson()) }
        try { bzCacheFile(ctx).writeText(JSONObject().put("at", System.currentTimeMillis()).put("items", a).toString()) } catch (_: Exception) { }
        return items
    }

    fun hasAltoAdige(ctx: Context) = bzCacheFile(ctx).exists()

    /** In Alto Adige / Trentino settentrionale (riquadro approssimativo). */
    fun inAltoAdige(lat: Double, lon: Double) = lat in 46.0..47.15 && lon in 10.35..12.5

    fun altoAdigeNear(ctx: Context, lat: Double, lon: Double, radius: Int, onProgress: (String) -> Unit = {}): List<Pair<Seller, Int>> {
        if (!inAltoAdige(lat, lon)) return emptyList()
        val (at, cached) = try {
            val o = JSONObject(bzCacheFile(ctx).readText()); val a = o.getJSONArray("items")
            o.optLong("at") to (0 until a.length()).map { Seller.from(a.getJSONObject(it)) }
        } catch (e: Exception) {
            0L to emptyList()
        }
        var items = cached
        if (items.isEmpty()) items = refreshAltoAdige(ctx, onProgress)
        else if (System.currentTimeMillis() - at > WEEK) try { items = refreshAltoAdige(ctx, onProgress) } catch (_: Exception) { }
        return items.map { it to dist(lat, lon, it.lat, it.lon) }.filter { it.second <= radius }.sortedBy { it.second }
    }

    // ---------------- Memoria settimanale ----------------

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "ticket_sellers.json")

    private fun loadCache(ctx: Context): Pair<Long, List<Seller>> = try {
        val o = JSONObject(cacheFile(ctx).readText())
        val a = o.getJSONArray("items")
        o.optLong("at") to (0 until a.length()).map { Seller.from(a.getJSONObject(it)) }
    } catch (e: Exception) {
        0L to emptyList()
    }

    private fun saveCache(ctx: Context, items: List<Seller>) {
        val a = JSONArray()
        items.forEach { a.put(it.toJson()) }
        try {
            cacheFile(ctx).writeText(JSONObject().put("at", System.currentTimeMillis()).put("items", a).toString())
        } catch (_: Exception) {
        }
    }

    /** Data dell'ultimo aggiornamento completo (0 = mai). */
    fun updatedAt(ctx: Context): Long = loadCache(ctx).first

    /**
     * Scarica di nuovo tutti gli elenchi Trenord (12 province + biglietterie). Chiamato ogni settimana dal lavoro
     * in background e la prima volta che serve. In caso di errore tiene i dati precedenti.
     */
    @Synchronized
    fun refreshAll(ctx: Context, onProgress: (String) -> Unit = {}): List<Seller> {
        val pool = Executors.newFixedThreadPool(6)
        try {
            onProgress(I18n.tr("Scarico le rivendite Trenord…", "Downloading Trenord sellers…"))
            val provFutures = PROVINCES.keys.map { p -> pool.submit<List<Seller>> { parseProvince(http("$BASE/it/punti-vendita-$p"), p) } }
            val resellers = provFutures.flatMap { f -> try { f.get(40, TimeUnit.SECONDS) } catch (e: Exception) { emptyList() } }
            onProgress(I18n.tr("Scarico gli orari delle biglietterie…", "Downloading ticket office hours…"))
            val offices = try {
                officeUrls().map { u -> pool.submit<Seller?> { try { parseOffice(http(u), u) } catch (e: Exception) { null } } }
                    .mapNotNull { f -> try { f.get(40, TimeUnit.SECONDS) } catch (e: Exception) { null } }
            } catch (e: Exception) {
                emptyList()
            }
            val old = loadCache(ctx).second
            // Se una parte non è arrivata, teniamo quella della settimana precedente
            val all = (if (resellers.isNotEmpty()) resellers else old.filter { it.kind == OsmPlace.Kind.RESELLER }) +
                (if (offices.isNotEmpty()) offices else old.filter { it.kind == OsmPlace.Kind.TICKET_OFFICE })
            if (all.isEmpty()) throw IOException("Sito Trenord non raggiungibile")
            saveCache(ctx, all)
            return all
        } finally {
            pool.shutdownNow()
        }
    }

    private fun dist(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
        return (r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toInt()
    }

    /** Coordinate in Lombardia (riquadro approssimativo): solo lì servono gli elenchi Trenord. */
    fun inLombardy(lat: Double, lon: Double) = lat in 44.67..46.64 && lon in 8.49..11.43

    fun inSwitzerland(lat: Double, lon: Double) = lat in 45.82..47.81 && lon in 5.95..10.49 && !(lat < 46.15 && lon < 8.4)

    /**
     * Punti vendita Trenord entro [radius] metri: elenco della settimana, con lo stato aperto/chiuso aggiornato
     * rileggendo dal vivo solo le province che servono.
     */
    fun trenordNear(ctx: Context, lat: Double, lon: Double, radius: Int, onProgress: (String) -> Unit = {}): List<Pair<Seller, Int>> {
        if (!inLombardy(lat, lon)) return emptyList()
        var (at, items) = loadCache(ctx)
        if (items.isEmpty()) items = refreshAll(ctx, onProgress)
        else if (System.currentTimeMillis() - at > WEEK) try { items = refreshAll(ctx, onProgress) } catch (_: Exception) { }
        var near = items.map { it to dist(lat, lon, it.lat, it.lon) }.filter { it.second <= radius }
        // Stato dal vivo: rileggo le pagine delle province coinvolte
        val provinces = near.map { it.first.province }.filter { it.isNotBlank() }.distinct()
        if (provinces.isNotEmpty()) {
            onProgress(I18n.tr("Controllo chi è aperto adesso…", "Checking who is open now…"))
            val live = HashMap<String, String>()
            provinces.forEach { p ->
                try {
                    parseProvince(http("$BASE/it/punti-vendita-$p", 10000), p).forEach { s -> live["${s.name}|${s.lat}|${s.lon}"] = s.status }
                } catch (_: Exception) {
                }
            }
            near = near.map { (s, d) -> (live["${s.name}|${s.lat}|${s.lon}"]?.let { st -> s.copy(status = st) } ?: s) to d }
        }
        return near.sortedBy { it.second }
    }

    /** Biglietterie automatiche FFS/SBB entro [radius] metri (dati aperti, aggiornati dalle FFS). */
    fun sbbMachines(lat: Double, lon: Double, radius: Int): List<Pair<Seller, Int>> {
        if (!inSwitzerland(lat, lon)) return emptyList()
        val where = java.net.URLEncoder.encode("within_distance(geopos, geom'POINT($lon $lat)', ${radius}m)", "UTF-8")
        val o = JSONObject(http("https://data.sbb.ch/api/explore/v2.1/catalog/datasets/billetautomat/records?limit=100&where=$where"))
        val a = o.optJSONArray("results") ?: return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val r = a.getJSONObject(i)
            val g = r.optJSONObject("geopos") ?: return@mapNotNull null
            val la = g.optDouble("lat"); val lo = g.optDouble("lon")
            val station = r.optString("bps_name")
            val owner = r.optString("eigentumer_gruppe").ifBlank { "SBB" }
            Seller("FFS/SBB", OsmPlace.Kind.TICKET_MACHINE, I18n.tr("Biglietteria automatica", "Ticket machine") + " $owner",
                la, lo, nearStation = station, url = SBB_DATA) to dist(lat, lon, la, lo)
        }.distinctBy { "${it.first.lat.toString().take(8)}|${it.first.lon.toString().take(7)}" }.sortedBy { it.second }
    }

    /** Converte nel formato usato dagli elenchi e dalla mappa dell'app. */
    fun toPlace(s: Seller, distance: Int): OsmPlace {
        val tags = HashMap<String, String>()
        tags["operator"] = s.source
        if (s.hours.isNotBlank()) tags["opening_hours"] = s.hours
        tags["x_source"] = s.source
        if (s.status.isNotBlank()) tags["x_status"] = s.status
        if (s.nearStation.isNotBlank()) tags["x_near"] = s.nearStation
        if (s.address.isNotBlank()) tags["x_address"] = s.address
        if (s.url.isNotBlank()) tags["x_url"] = s.url
        if (s.services.isNotBlank()) tags["x_services"] = s.services
        tags["x_official"] = "yes"
        return OsmPlace(s.kind, s.name, s.lat, s.lon, distance, tags)
    }
}
