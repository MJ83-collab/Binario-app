import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Chiave di firma: letta da keystore.properties (escluso da git) o dalle variabili d'ambiente.
val keyProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun signCfg(prop: String, env: String): String? = keyProps.getProperty(prop) ?: System.getenv(env)
val ksPath: String? = signCfg("storeFile", "BINARIO_KEYSTORE_FILE")
val hasKey: Boolean = ksPath != null && rootProject.file(ksPath).exists()

android {
    namespace = "com.binario.treni"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.binario.treni"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "2.3.1"
    }

    // Chiave privata: NON è nel progetto. Viene letta da keystore.properties (nella cartella principale,
    // escluso da git) oppure dalle variabili d'ambiente / segreti GitHub:
    // BINARIO_KEYSTORE_FILE, BINARIO_KEYSTORE_PASSWORD, BINARIO_KEY_ALIAS, BINARIO_KEY_PASSWORD.
    // Senza la chiave la build release fallisce, così nessun altro può pubblicare aggiornamenti.
    signingConfigs {
        if (hasKey) {
            create("binario") {
                storeFile = rootProject.file(ksPath!!)
                storePassword = signCfg("storePassword", "BINARIO_KEYSTORE_PASSWORD")
                keyAlias = signCfg("keyAlias", "BINARIO_KEY_ALIAS") ?: "binario"
                keyPassword = signCfg("keyPassword", "BINARIO_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (hasKey) signingConfig = signingConfigs.getByName("binario")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    // Nei test le classi Android restituiscono valori vuoti invece di bloccarsi
    testOptions { unitTests.isReturnDefaultValues = true }
}

// I test dei lettori di dati girano prima di ogni APK firmato: se falliscono la build si ferma
tasks.matching { it.name == "assembleRelease" }.configureEach { dependsOn("testReleaseUnitTest") }

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.osmdroid:osmdroid-android:6.1.20")

    testImplementation("junit:junit:4.13.2")
    // org.json vero nei test (quello di Android nei test locali è vuoto)
    testImplementation("org.json:json:20240303")
}
