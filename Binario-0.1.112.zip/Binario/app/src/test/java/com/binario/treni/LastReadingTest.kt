package com.binario.treni

import com.binario.treni.data.LastReading
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.TrainStop
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class LastReadingTest {
    private fun stop(n: String, id: String, a: Long, d: Long, ra: Long = 0, rd: Long = 0) =
        TrainStop(n, id, a, d, ra, rd, 3, "2", true, false, "1", "2", "Trenord")

    private val st = TrainStatus("12079", "REG", "Varese", "Milano Cadorna", "S01", 1_000L, 5, "Induno Olona", 2_000L, false,
        listOf(stop("Varese", "S1", 0, 100, 0, 110), stop("Induno Olona", "S2", 200, 210)), "avviso", "Trenord")

    @Test fun roundTrip_keeps_all_fields() {
        val back = LastReading.fromJson(LastReading.toJson(st))
        assertEquals(st, back)
    }

    @Test fun cancelled_flag_survives() {
        val back = LastReading.fromJson(LastReading.toJson(st.copy(cancelled = true)))
        assertTrue(back.cancelled)
    }

    @Test fun empty_reading_is_not_saved() {
        assertFalse(LastReading.worthSaving(st.copy(stops = emptyList())))
        assertTrue(LastReading.worthSaving(st))
    }

    @Test fun freshness_window() {
        val now = 100_000_000L
        assertTrue(LastReading.isFresh(now - 60_000, now))
        assertFalse(LastReading.isFresh(now - 13 * 3600_000L, now))
        assertFalse(LastReading.isFresh(0, now))
        assertFalse(LastReading.isFresh(now + 1, now))
    }

    @Test fun train_screen_uses_saved_reading_only_when_offline() {
        val f = File("src/main/java/com/binario/treni/ui/TrainScreens.kt").takeIf { it.exists() }
            ?: File("app/src/main/java/com/binario/treni/ui/TrainScreens.kt")
        val s = f.readText()
        assertTrue(s.contains("LastReading.save(ctx, s)"))
        assertTrue(s.contains("LastReading.load(ctx, r)"))
        // Il banner compare solo quando si usa la lettura salvata
        assertTrue(s.contains("if (offlineAt > 0L && st != null)"))
        assertTrue(s.contains("offlineAt = 0L"))
    }
}
