package com.binario.treni

import com.binario.treni.data.Updater
import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 08/11/2026: l'aggiornamento finiva in «App non installata» (firma diversa): ora lo si spiega prima di aprire Android. */
class UpdateSignatureTest {
    @Test fun sameAndDifferentKeys() {
        assertTrue(Updater.sameSigners(setOf("aa"), setOf("aa")))
        assertFalse(Updater.sameSigners(setOf("aa"), setOf("bb")))
        assertTrue(Updater.sameSigners(emptySet(), setOf("bb")))   // firma illeggibile: non si blocca nulla
    }

    @Test fun dialogChecksBeforeInstalling() {
        val s = File("src/main/java/com/binario/treni/ui/UpdateDialog.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/UpdateDialog.kt") }.readText()
        assertTrue(s.indexOf("Updater.verify(") in 1 until s.indexOf("Updater.install(ctx, f)"))
    }
}
