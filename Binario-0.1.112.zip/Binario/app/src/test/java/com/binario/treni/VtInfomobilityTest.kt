package com.binario.treni

import com.binario.treni.data.VtInfomobility
import com.binario.treni.data.VtItem
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Avvisi di ViaggiaTreno: completi (infomobilitaRSS) e brevi (infomobilitaTicker), senza doppioni né «circolazione regolare». */
class VtInfomobilityTest {
    private val clean: (String) -> String = { it.replace(Regex("<[^>]+>"), " ").replace("&egrave;", "è").replace(Regex("\\s+"), " ").trim() }

    // Struttura come da documentazione non ufficiale (dltmtt/viaggiatreno-api)
    private val rss = """
        <ul id="accordionGenericInfomob">
          <li class="editModeCollapsibleElement">
            <a class="headingNewsAccordion" href="#">CIRCOLAZIONE REGOLARE</a>
            <div class="boxAcc"><div class="textComponent"><h4>09.11.2026</h4>
            <div class="info-text col-xs-12"><p><b>In questo momento la circolazione si svolge regolarmente</b></p></div></div></div>
          </li>
          <li class="editModeCollapsibleElement">
            <a class="headingNewsAccordion" href="#">LINEA MILANO - VARESE: CIRCOLAZIONE RALLENTATA</a>
            <div class="boxAcc"><div class="textComponent"><h4>9.11.2026</h4>
            <div class="info-text col-xs-12"><p><b>Ritardi fino a 30 minuti per un guasto. L'intervento &egrave; in corso.</b></p></div></div></div>
          </li>
        </ul>
    """.trimIndent()

    private val ticker = "<ul>\n  <li>CIRCOLAZIONE REGOLARE</li>\n  <li>Linea Milano - Varese: circolazione rallentata</li>\n  <li>Sciopero nazionale dalle 21 di domenica</li>\n</ul>"

    @Test fun fullNoticesAreReadWithDateAndText() {
        val items = VtInfomobility.parseRss(rss, clean)
        assertEquals(1, items.size)
        val it = items[0]
        assertEquals("LINEA MILANO - VARESE: CIRCOLAZIONE RALLENTATA", it.title)
        assertEquals("09/11/2026", it.date)
        assertEquals("Ritardi fino a 30 minuti per un guasto. L'intervento è in corso.", it.text)
    }

    @Test fun tickerSkipsRegularTraffic() {
        val items = VtInfomobility.parseTicker(ticker, clean)
        assertEquals(listOf("Linea Milano - Varese: circolazione rallentata", "Sciopero nazionale dalle 21 di domenica"), items.map { it.title })
    }

    @Test fun shortNoticeAlreadyInAFullOneIsDropped() {
        val all = VtInfomobility.parseRss(rss, clean) + VtInfomobility.parseTicker(ticker, clean)
        val out = VtInfomobility.dedupe(all)
        assertEquals(listOf("LINEA MILANO - VARESE: CIRCOLAZIONE RALLENTATA", "Sciopero nazionale dalle 21 di domenica"), out.map { it.title })
        assertEquals(1, VtInfomobility.dedupe(listOf(VtItem("Guasto a Saronno", "a", ""), VtItem("guasto a saronno!", "b", ""))).size)
    }

    @Test fun emptyOrBrokenPagesGiveNothing() {
        assertEquals(emptyList<VtItem>(), VtInfomobility.parseRss("", clean))
        assertEquals(emptyList<VtItem>(), VtInfomobility.parseRss("<html>Errore 404</html>", clean))
        assertEquals(emptyList<VtItem>(), VtInfomobility.parseTicker("", clean))
    }

    @Test fun datesCanBeSortedByTheNewsScreen() {
        // 9 novembre 2026, 09:12 UTC = 10:12 in Italia: formato «gg/mm/aaaa hh:mm» che Sources.parseItDate capisce
        assertEquals("09/11/2026 10:12", VtInfomobility.itDate(1_794_215_520_000L))
    }

    @Test fun newsSourcesUseAllThreeServicesAndRecordFailures() {
        val s = File("src/main/java/com/binario/treni/data/Sources.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/data/Sources.kt") }.readText()
        assertTrue(s.contains("Api.vtInfomobility()"))
        assertTrue(s.contains("Api.vtTicker()"))
        assertTrue(s.contains("Diag.record(\"sources/viaggiaTrenoTicker\", e)"))
        assertFalse("la data «09 nov 10:12» non si ordina", s.contains("Fmt.dayTime(n.date)"))
    }
}
