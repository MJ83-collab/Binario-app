package com.binario.treni

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * 9/11/2026, testo «enorme»: i pulsanti di Ordina/Mezzi venivano schiacciati («D-u-r-a-t-a» una lettera per riga),
 * le schede delle Notizie tagliate («CIRCOLAZI(») e i filtri finivano fuori schermo.
 */
class BigTextLayoutTest {
    private fun ui(f: String) =
        File("src/main/java/com/binario/treni/ui/$f").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/$f") }.readText()

    @Test fun chipRowWrapsWithBigText() {
        val c = ui("Common.kt")
        val body = c.substring(c.indexOf("fun ChipRow("), c.indexOf("fun GreenTabs("))
        assertTrue(body.contains("if (bigText())"))
        assertTrue(body.contains("FlowRow"))
    }

    @Test fun tabsScrollWithBigText() {
        val c = ui("Common.kt")
        val body = c.substring(c.indexOf("fun GreenTabs("), c.indexOf("fun GreenIconTabs("))
        assertTrue(body.contains("ScrollableTabRow("))
        assertTrue(body.contains("maxLines = 1, softWrap = false"))
    }

    @Test fun resultFiltersUseChipRow() {
        val r = ui("ResultsScreen.kt")
        for (l in listOf("Ordina:", "Mezzi:", "Prezzi:")) assertTrue(l, r.contains("ChipRow(Modifier.padding(horizontal = 12.dp), label = tx(\"$l\"))"))
        assertFalse(r.contains("Text(tx(\"Ordina:\"), color = Muted"))
    }

    @Test fun otherChipRowsWrap() {
        assertTrue(ui("MyRouteUi.kt").contains("ChipRow {\n            listOf(\"all\" to tr(\"Tutte\""))
        for (f in listOf("FeedbackScreen.kt", "GreenAndBot.kt", "PdfDialog.kt", "PricesScreen.kt", "ToiletsScreen.kt", "NewFeatures.kt")) {
            assertTrue(f, ui(f).contains("ChipRow"))
        }
    }
}
