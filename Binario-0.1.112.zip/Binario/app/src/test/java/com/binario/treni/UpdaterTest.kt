package com.binario.treni

import com.binario.treni.data.Updater
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UpdaterTest {
    private fun release(name: String, url: String = "https://github.com/MJ83-collab/Binario-app/releases/download/v2.4/$name", pre: Boolean = false) =
        """{"tag_name":"v2.4","prerelease":$pre,"draft":false,"body":"• Novità","assets":[
           {"name":"notes.txt","browser_download_url":"https://example.org/notes.txt","size":10},
           {"name":"$name","browser_download_url":"$url","size":1234567}]}"""

    @Test
    fun readsVersionFromAssetName() {
        val r = Updater.parse(release("Binario-2.4-9.apk"))!!
        assertEquals("2.4", r.versionName)
        assertEquals(9L, r.versionCode)
        assertEquals(1234567L, r.size)
        assertEquals("• Novità", r.notes)
    }

    @Test
    fun ignoresUnsafeOrPrerelease() {
        assertNull(Updater.parse(release("Binario-2.4-9.apk", url = "http://example.org/x.apk")))
        assertNull(Updater.parse(release("Binario-2.4-9.apk", pre = true)))
        assertNull(Updater.parse(release("Binario-2.4.apk")))
    }

    /** 9/11/2026: la 0.1.108 è uscita senza note e sotto «Novità» compariva «null». */
    @Test
    fun releaseWithoutNotesShowsNoNull() {
        val noBody = release("Binario-2.4-9.apk").replace("\"body\":\"• Novità\"", "\"body\":null")
        assertEquals("", Updater.parse(noBody)!!.notes)
        val wordNull = release("Binario-2.4-9.apk").replace("\"body\":\"• Novità\"", "\"body\":\"null\"")
        assertEquals("", Updater.parse(wordNull)!!.notes)
        val missing = release("Binario-2.4-9.apk").replace("\"body\":\"• Novità\",", "")
        assertEquals("", Updater.parse(missing)!!.notes)
    }

    /** 9/11/2026: «Download non riuscito. Controlla la connessione» per ogni errore, anche con la rete funzionante. */
    @Test
    fun downloadErrorSaysWhy() {
        assertTrue(Updater.failureReason(java.net.SocketTimeoutException("Read timed out")).contains("troppo tempo"))
        assertTrue(Updater.failureReason(java.net.UnknownHostException("github.com")).contains("non è raggiungibile"))
        assertTrue(Updater.failureReason(java.io.IOException("HTTP 404")).contains("(404)"))
        assertTrue(Updater.failureReason(java.io.IOException("Download incompleto")).contains("a metà"))
        assertTrue(Updater.failureReason(java.io.IOException("Spazio insufficiente sul telefono")).startsWith("Spazio"))
        assertFalse(Updater.failureReason(java.io.IOException("Connection reset")).contains("Controlla la connessione"))
    }

    @Test
    fun retriesOnlyWhenItCanHelp() {
        assertTrue(Updater.retriable(java.net.SocketTimeoutException("Read timed out")))
        assertTrue(Updater.retriable(java.io.IOException("Download incompleto")))
        assertTrue(Updater.retriable(java.io.IOException("HTTP 503")))
        assertFalse(Updater.retriable(java.io.IOException("HTTP 404")))
        assertFalse(Updater.retriable(java.io.IOException("Spazio insufficiente sul telefono")))
        assertFalse(Updater.retriable(java.io.IOException("Download non sicuro")))
        assertFalse(Updater.retriable(IllegalStateException("x")))
    }

    @Test
    fun dialogShowsReasonAndDownloadPage() {
        val f = java.io.File("src/main/java/com/binario/treni/ui/UpdateDialog.kt").let { if (it.exists()) it else java.io.File("app/" + it.path) }
        val ui = f.readText()
        assertTrue(ui.contains("error = Updater.failureReason(e)"))
        assertTrue(ui.contains("if (error != null) TextButton({ Updater.openDownloadPage(ctx) })"))
    }
}
