package com.binario.treni

import com.binario.treni.data.TripEntry
import com.binario.treni.data.TripLog
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** «I miei viaggi»: diario dei treni seguiti fino all'arrivo, con il riepilogo del mese. */
class TripLogTest {
    private fun trip(key: String, day: String, delay: Int, time: Long, cancelled: Boolean = false) =
        TripEntry(key, day, "R 2727", "Varese", "Milano Porta Garibaldi", time, if (cancelled) 0L else time, delay, cancelled)

    @Test fun monthsMoveAcrossTheYear() {
        assertEquals("2025-12", TripLog.shift("2026-01", -1))
        assertEquals("2027-01", TripLog.shift("2026-12", 1))
        assertEquals("2026-11", TripLog.shift("2026-11", 0))
        assertEquals("2025-11", TripLog.shift("2026-11", -12))
    }

    @Test fun dayIsItalianTime() {
        // 8 novembre 2026, 23:30 UTC = 9 novembre, 00:30 in Italia
        val ms = 1_794_180_600_000L
        assertEquals("2026-11-09", TripLog.dayOf(ms))
        assertEquals("2026-11", TripLog.monthOf(ms))
    }

    @Test fun sameTripIsCountedOnce() {
        val a = trip("2727/S01@2026-11-09", "2026-11-09", 0, 1000L, cancelled = true)
        val b = trip("2727/S01@2026-11-09", "2026-11-09", 12, 1000L)
        val list = TripLog.upsert(TripLog.upsert(emptyList(), a), b)
        assertEquals(1, list.size)
        assertEquals(12, list[0].delay)
    }

    @Test fun newestFirstAndLimited() {
        var list = emptyList<TripEntry>()
        for (i in 1..10) list = TripLog.upsert(list, trip("k$i", "2026-11-0${i % 9 + 1}", i, i * 1000L), max = 5)
        assertEquals(5, list.size)
        assertEquals(listOf("k10", "k9", "k8", "k7", "k6"), list.map { it.key })
    }

    @Test fun monthFilterDoesNotMixOctoberAndNovember() {
        val list = listOf(trip("a", "2026-11-03", 0, 3L), trip("b", "2026-10-30", 0, 2L), trip("c", "2026-01-05", 0, 1L))
        assertEquals(listOf("a"), TripLog.inMonth(list, "2026-11").map { it.key })
        assertEquals(listOf("c"), TripLog.inMonth(list, "2026-01").map { it.key })
    }

    @Test fun summaryCountsDelaysAndCancellations() {
        val list = listOf(
            trip("1", "2026-11-02", 0, 1L),
            trip("2", "2026-11-03", 5, 2L),
            trip("3", "2026-11-04", 16, 3L),
            trip("4", "2026-11-05", 75, 4L),
            trip("5", "2026-11-06", 0, 5L, cancelled = true),
        )
        val s = TripLog.summary(list)
        assertEquals(5, s.trips)
        assertEquals(4, s.ran)
        assertEquals(2, s.onTime) // fino a 5 minuti
        assertEquals(2, s.late15)
        assertEquals(1, s.late60)
        assertEquals(1, s.cancelled)
        assertEquals(96, s.delayMinutes)
    }

    @Test fun savedTextGoesBackTheSame() {
        val list = listOf(trip("x@2026-11-09", "2026-11-09", 7, 123L), trip("y@2026-11-08", "2026-11-08", 0, 100L, cancelled = true))
        assertEquals(list, TripLog.decode(TripLog.encode(list)))
        assertEquals(emptyList<TripEntry>(), TripLog.decode(null))
        assertEquals(emptyList<TripEntry>(), TripLog.decode("non è json"))
        assertEquals(emptyList<TripEntry>(), TripLog.decode("""[{"k":"","d":"2026-11-09"}]"""))
    }

    @Test fun monthExportListsTripsOldestFirstWithSummary() {
        val list = listOf(
            trip("b", "2026-11-05", 75, 5L),
            trip("a", "2026-11-02", 0, 2L),
            trip("c", "2026-11-06", 0, 6L, cancelled = true),
        )
        val text = TripLog.exportText("I miei viaggi · Novembre 2026", list) { it.day }
        val lines = text.lines()
        assertEquals("I miei viaggi · Novembre 2026", lines[0])
        assertEquals("2026-11-02 · R 2727 · Varese → Milano Porta Garibaldi · in orario", lines[2])
        assertEquals("2026-11-05 · R 2727 · Varese → Milano Porta Garibaldi · +75 min", lines[3])
        assertEquals("2026-11-06 · R 2727 · Varese → Milano Porta Garibaldi · Soppresso", lines[4])
        assertTrue(text.contains("Ritardo di 60 min o più: 1"))
        assertTrue(text.contains("Soppressi: 1"))
        assertTrue("avvertenza: non è un documento ufficiale", text.trimEnd().endsWith("non sostituiscono le attestazioni ufficiali dell'azienda."))
    }

    @Test fun tripAddedByHandIsCheckedAndMarked() {
        val now = 1_794_215_520_000L // 9/11/2026 10:12 in Italia
        val (e, err) = TripLog.manualEntry(" R  2727 ", "Varese", "Milano", "09/11/2026", "08:15", "22", false, now)
        assertEquals(null, err)
        e!!
        assertEquals("R 2727", e.train)
        assertEquals("2026-11-09", e.day)
        assertEquals(22, e.delay)
        assertEquals(e.schedArr + 22 * 60_000L, e.realArr)
        assertTrue(e.manual)
        assertEquals(e, TripLog.decode(TripLog.encode(listOf(e))).single())
        assertTrue(TripLog.exportText("x", listOf(e)) { it.day }.contains("+22 min · inserito a mano"))
        // soppresso: nessun ritardo
        val (c, _) = TripLog.manualEntry("R 2727", "Varese", "Milano", "09/11/2026", "08:15", "", true, now)
        assertTrue(c!!.cancelled && c.delay == 0 && c.realArr == 0L)
        // errori
        assertEquals(TripLog.ManualError.TRAIN, TripLog.manualEntry("Regionale", "A", "B", "09/11/2026", "08:15", "", false, now).second)
        assertEquals(TripLog.ManualError.PLACES, TripLog.manualEntry("R 1", " ", "B", "09/11/2026", "08:15", "", false, now).second)
        assertEquals(TripLog.ManualError.DATE, TripLog.manualEntry("R 1", "A", "B", "31/02/2026", "08:15", "", false, now).second)
        assertEquals(TripLog.ManualError.DATE, TripLog.manualEntry("R 1", "A", "B", "09/11/2026", "25:00", "", false, now).second)
        assertEquals(TripLog.ManualError.FUTURE, TripLog.manualEntry("R 1", "A", "B", "10/11/2026", "08:15", "", false, now).second)
        assertEquals(TripLog.ManualError.DELAY, TripLog.manualEntry("R 1", "A", "B", "09/11/2026", "08:15", "1000", false, now).second)
    }

    @Test fun monthlySummaryOnceAtTheStartOfTheMonth() {
        val oct = listOf(trip("a", "2026-10-05", 20, 1L), trip("b", "2026-10-06", 0, 2L))
        val octOk = listOf(trip("a", "2026-10-05", 3, 1L))
        val nov1 = 1_793_538_000_000L // 1/11/2026 alle 14:00 in Italia
        val nov5 = nov1 + 4 * 86_400_000L
        assertEquals("2026-10", TripLog.monthlyDue(oct, nov1, lastSent = ""))
        assertEquals("già avvisato", null, TripLog.monthlyDue(oct, nov1, lastSent = "2026-10"))
        assertEquals("dopo il 3 del mese no", null, TripLog.monthlyDue(oct, nov5, lastSent = ""))
        assertEquals("nessun ritardo: niente da dire", null, TripLog.monthlyDue(octOk, nov1, lastSent = ""))
        assertEquals(null, TripLog.monthlyDue(emptyList(), nov1, lastSent = ""))
        val svc = File("src/main/java/com/binario/treni/service/Services.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/service/Services.kt") }.readText()
        assertTrue(svc.contains("tl.markMonthlySent(applicationContext, m)"))
    }

    @Test fun csvForSpreadsheets() {
        val at = 1_794_215_520_000L // 9/11/2026 10:12 in Italia
        val list = listOf(
            TripEntry("b", "2026-11-09", "R 2727", "Varese", "Milano; P.ta Garibaldi", at, at + 12 * 60_000L, 12),
            TripEntry("a", "2026-11-02", "S5", "Varese", "Treviglio", 0L, 0L, 0, cancelled = true, manual = true),
        )
        val csv = TripLog.toCsv(list)
        assertTrue("BOM per gli accenti in Excel", csv.startsWith("\uFEFF"))
        val rows = csv.removePrefix("\uFEFF").trimEnd().split("\r\n")
        assertEquals("Data;Arrivo previsto;Treno;Da;A;Ritardo (min);Soppresso;inserito a mano", rows[0])
        assertEquals("dal più vecchio", "02/11/2026;;S5;Varese;Treviglio;;Sì;Sì", rows[1])
        assertEquals("09/11/2026;10:12;R 2727;Varese;\"Milano; P.ta Garibaldi\";12;No;No", rows[2])
    }

    @Test fun yearChartAndSpokenTexts() {
        val list = listOf(
            trip("a", "2026-11-02", 3, 3L), trip("b", "2026-11-02", 45, 4L), trip("c", "2026-11-12", 0, 5L, cancelled = true),
            trip("d", "2025-12-30", 10, 1L),
        )
        assertEquals(listOf("a", "b", "c"), TripLog.inYear(list, "2026").map { it.key })
        val bars = TripLog.dailyBars(list, "2026-11")
        assertEquals(30, bars.size)
        assertEquals(TripLog.DayBar(2, 45, false, 2), bars[1])
        assertEquals(TripLog.DayBar(12, 0, true, 1), bars[11])
        assertEquals(0, bars[0].trips)
        assertEquals("anno bisestile", 29, TripLog.dailyBars(emptyList(), "2028-02").size)
        assertEquals("Giorni con viaggi: 2. Ritardo più alto: 45 minuti il giorno 2. Soppressi: 1.", TripLog.chartDescription(bars))
        assertEquals("Giorni con viaggi: 0. Nessun ritardo. Soppressi: 0.", TripLog.chartDescription(TripLog.dailyBars(emptyList(), "2026-11")))
        assertEquals("R 2727, Varese → Milano Porta Garibaldi, 02 nov 08:00, 45 minuti di ritardo", TripLog.spoken(list[1], "02 nov 08:00"))
        assertEquals("R 2727, Varese → Milano Porta Garibaldi, ieri, Soppresso", TripLog.spoken(list[2], "ieri"))
        val ui = File("src/main/java/com/binario/treni/ui/TripLogScreen.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/TripLogScreen.kt") }.readText()
        assertTrue(ui.contains("MonthChart(TripLog.dailyBars(shown, month))"))
        assertTrue(ui.contains("title = tx(\"Anno\") + \" \" + year, advice = false"))
        assertTrue(ui.contains("contentDescription = TripLog.spoken(e, date)"))
        assertTrue("soppresso riconoscibile senza colori", ui.contains(".border(1.dp, LateRed)"))
    }

    @Test fun compensationClaimForLongDelaysAndCancellations() {
        val at = 1_794_215_520_000L // 9/11/2026 10:12 in Italia
        val late = TripEntry("x", "2026-11-09", "R 2727", "Varese", "Milano", at, at + 125 * 60_000L, 125)
        val short = late.copy(delay = 59, realArr = at + 59 * 60_000L)
        val gone = late.copy(delay = 0, realArr = 0L, cancelled = true, manual = true)
        assertTrue(TripLog.claimable(late) && TripLog.claimable(gone) && !TripLog.claimable(short))
        val t = TripLog.claimText(late)
        assertTrue(t.startsWith("Oggetto: richiesta di indennizzo per ritardo del treno R 2727"))
        assertTrue(t.contains("Data del viaggio: 09/11/2026"))
        assertTrue(t.contains("Arrivo previsto a Milano: 10:12"))
        assertTrue(t.contains("Arrivo effettivo: 12:17"))
        assertTrue(t.contains("Ritardo all'arrivo: 125 minuti"))
        assertTrue(t.contains("(50% del prezzo del biglietto)"))
        assertTrue(t.contains("Dati di marcia da ViaggiaTreno"))
        assertTrue(TripLog.claimText(late.copy(delay = 60)).contains("(25% del prezzo del biglietto)"))
        val g = TripLog.claimText(gone)
        assertTrue(g.startsWith("Oggetto: richiesta di rimborso per la soppressione del treno R 2727"))
        assertTrue(g.contains("Il treno è stato soppresso."))
        assertTrue("inserito a mano: lo dice", g.contains("Orari annotati dal passeggero."))
        val ui = File("src/main/java/com/binario/treni/ui/TripLogScreen.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/TripLogScreen.kt") }.readText()
        assertTrue(ui.contains("if (TripLog.claimable(e)) TextButton("))
        assertTrue("niente firma «via Binario» nella lettera", ui.contains("{ shareClaim(ctx, TripLog.claimText(e)) }"))
    }

    @Test fun routeFilterJoinsBothDirections() {
        fun t(k: String, from: String, to: String, time: Long) = TripEntry(k, "2026-11-0${time}", "R 1", from, to, time, time, 0)
        val list = listOf(t("a", "Varese", "Milano", 1), t("b", "Milano", "Varese", 2), t("c", "milano ", "VARESE", 3), t("d", "Como", "Lecco", 4))
        val opts = TripLog.routeOptions(list)
        assertEquals(2, opts.size)
        assertEquals("andata e ritorno insieme, senza maiuscole", 3, opts[0].trips)
        assertEquals("milano ⇄ VARESE", opts[0].label) // il nome è quello del viaggio più recente
        assertEquals(listOf("a", "b", "c"), TripLog.byRoute(list, opts[0].key).map { it.key })
        assertEquals(4, TripLog.byRoute(list, null).size)
        val ui = File("src/main/java/com/binario/treni/ui/TripLogScreen.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/TripLogScreen.kt") }.readText()
        assertTrue(ui.contains("val shown = TripLog.inMonth(mine, month)"))
        assertTrue(ui.contains("val yearTrips = TripLog.inYear(mine, year)"))
    }

    @Test fun delaysByTimeOfDay() {
        val h = 3_600_000L
        val midnight = 1_794_178_800_000L // 9/11/2026 00:00 in Italia
        fun at(hour: Int, delay: Int, cancelled: Boolean = false) =
            TripEntry("k$hour$delay", "2026-11-09", "R 1", "A", "B", midnight + hour * h, midnight + hour * h, delay, cancelled)
        assertEquals(0, TripLog.slotOf(midnight + 5 * h))
        assertEquals(1, TripLog.slotOf(midnight + 10 * h))
        assertEquals(2, TripLog.slotOf(midnight + 20 * h))
        assertEquals(3, TripLog.slotOf(midnight + 21 * h))
        assertEquals(3, TripLog.slotOf(midnight + 4 * h))
        val list = listOf(at(7, 2), at(8, 4), at(9, 6), at(18, 20), at(18, 30), at(19, 1), at(19, 0, cancelled = true), at(12, 50))
        val st = TripLog.bySlot(list)
        assertEquals(TripLog.SlotStat(0, 3, 4, 0, 0), st[0])
        assertEquals(TripLog.SlotStat(2, 4, 17, 2, 1), st[2]) // media 51/3 = 17, senza il soppresso
        assertEquals(TripLog.SlotStat(1, 1, 50, 1, 0), st[1])
        assertEquals("la sera, non il giorno con un solo viaggio", 2, TripLog.worstSlot(st))
        assertEquals("troppo pochi viaggi", null, TripLog.worstSlot(TripLog.bySlot(listOf(at(7, 30), at(8, 30)))))
    }

    @Test fun trackingServiceFillsTheLogAndScreenIsReachable() {
        fun src(p: String) = File("src/main/java/com/binario/treni/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$p") }.readText()
        val svc = src("service/Services.kt")
        assertTrue(svc.contains("recordTrip(st, stop, at, delay, cancelled = false)"))
        assertTrue("soppresso: fino alla fermata della sveglia", svc.contains("if (st.cancelled && seenRunning) recordTrip(st, target, 0L, 0, cancelled = true)"))
        assertTrue(src("MainActivity.kt").contains("composable(\"trips\") { TripLogScreen("))
        assertTrue(src("ui/OtherScreens.kt").contains("go(\"trips\")"))
        // Raggiungibile anche dalla Home (scorciatoie e riquadri) e dal menu laterale
        assertTrue(src("ui/HomeShortcuts.kt").contains("Item(\"trips\", \"I miei viaggi\", Icons.Filled.History, \"trips\")"))
        assertTrue(src("ui/HomeDrawer.kt").contains("DrawerEntry(Icons.Filled.History, tx(\"I miei viaggi\"), \"trips\")"))
        assertTrue(src("ui/StyleHome.kt").contains("Tile(\"trips\", \"I miei viaggi\""))
        // Arrivato in ritardo (15 minuti o più): la notifica apre il diario
        assertTrue(svc.contains("Notif.openApp(this, null, 7, if (delay >= 15) \"trips\" else \"capotreno\")"))
        assertTrue(src("MainActivity.kt").contains("\"trips\" -> nav.navigate(\"trips\")"))
        // L'informativa dice che il diario resta sul telefono
        assertTrue(src("ui/AppTexts.kt").contains("diario «I miei viaggi» restano solo sul telefono"))
    }
}
