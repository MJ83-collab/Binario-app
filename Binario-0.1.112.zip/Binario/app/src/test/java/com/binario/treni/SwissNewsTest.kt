package com.binario.treni

import com.binario.treni.data.SwissNews
import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Avvisi solo svizzeri: niente con la regione Lombardia; sì per la tratta solo se va in Svizzera e nomina un capolinea. */
class SwissNewsTest {
    @Test fun worksInTicinoAreSwissOnly() {
        assertTrue(SwissNews.isSwissOnly("Lavori tra Bellinzona e Lugano", "Bus sostitutivi la notte", mentionsItaly = false))
        assertTrue(SwissNews.isSwissOnly("S10: interruzione", "Tratta Mendrisio – Lugano chiusa", mentionsItaly = false))
    }

    @Test fun noticesThatAlsoNameItalyAreNotSwissOnly() {
        // Como, Milano, Varese… li riconosce chi chiama: qui arriva solo «nomina l'Italia»
        assertFalse(SwissNews.isSwissOnly("S11 Como – Chiasso – Lugano", "ritardi", mentionsItaly = true))
    }

    @Test fun riverTicinoAndBorderStationAreNotSwitzerland() {
        assertFalse(SwissNews.mentionsSwiss("Lavori sul ponte del Ticino a Turbigo"))
        assertFalse(SwissNews.mentionsSwiss("Treni limitati a Chiasso"))
        assertTrue(SwissNews.mentionsSwiss("Avviso FFS per il Canton Ticino"))
    }

    @Test fun swissStationsAreRecognised() {
        assertTrue(SwissNews.isSwissStation("CH8505300", "Lugano"))
        assertTrue(SwissNews.isSwissStation("", "Mendrisio (CH)"))
        assertFalse(SwissNews.isSwissStation("S01700", "Milano Centrale"))
    }

    @Test fun shownForTheRouteOnlyIfItGoesToSwitzerlandAndNamesAnEnd() {
        val varLug = listOf("S01205" to "Varese", "CH8505300" to "Lugano")
        val varMil = listOf("S01205" to "Varese", "S01700" to "Milano Centrale")
        assertTrue(SwissNews.forRoute("Lavori tra Mendrisio e Lugano", "", varLug, listOf("VARESE", "LUGANO")))
        assertFalse("tratta tutta in Italia", SwissNews.forRoute("Lavori tra Mendrisio e Lugano", "", varMil, listOf("VARESE", "MILANO")))
        assertFalse("non nomina i miei capolinea", SwissNews.forRoute("Lavori tra Biasca e Airolo", "", varLug, listOf("VARESE", "LUGANO")))
    }

    @Test fun newsFiltersUseTheRule() {
        val s = File("src/main/java/com/binario/treni/data/MyRoute.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/data/MyRoute.kt") }.readText()
        assertTrue(s.contains("if (isSwissOnly(n)) return setOf(\"Svizzera\")"))
        assertTrue(s.contains("if (isSwissOnly(n)) return regions.any { normRegion(it) == \"svizzera\" }"))
        assertTrue(s.contains("return SwissNews.forRoute(n.title, n.text, ends, keywords(r))"))
    }
}
