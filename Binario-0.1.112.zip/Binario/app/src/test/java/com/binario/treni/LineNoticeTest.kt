package com.binario.treni

import com.binario.treni.data.LineNotice
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 06/11/2026: toccando R38 «Circolazione con gravi criticità» deve comparire l'ultimo messaggio di Trenord. */
class LineNoticeTest {
    private val page = """
        R38
        Piacenza - Lodi - Milano
        STATO DELLA LINEA
        Ultimo aggiornamento: 06/11/2026 20:45
        Circolazione con gravi criticità
        06/11/2026 20:45
        Per un guasto agli impianti la circolazione è sospesa tra Lodi e Milano Rogoredo.
        Sono previsti bus sostitutivi.
        Vedi informazioni precedenti
        AVVISI
        Servizio modificato
        06/11/2026 18:10
        Alcuni treni sono limitati a Lodi.
        Vedi avvisi precedenti
    """.trimIndent()

    @Test fun readsLatestStatusMessage() {
        val p = LineNotice.parse(page)
        assertNotNull(p)
        val s = p!!.status!!
        assertEquals("Circolazione con gravi criticità", s.title)
        assertEquals("06/11/2026 20:45", s.date)
        assertTrue(s.body.startsWith("Per un guasto"))
        assertTrue(s.body.contains("bus sostitutivi"))
        assertEquals("06/11/2026 20:45", p.updated)
    }

    @Test fun readsLatestNoticeAndStopsAtPreviousOnes() {
        val n = LineNotice.parse(page)!!.notice!!
        assertEquals("Servizio modificato", n.title)
        assertEquals("06/11/2026 18:10", n.date)
        assertEquals("Alcuni treni sono limitati a Lodi.", n.body)
    }

    @Test fun pageWithoutStatusSectionIsNull() {
        assertNull(LineNotice.parse("Orari\nTariffe\nContatti"))
    }

    @Test fun splitRowSeparatesRouteFromStatus() {
        val (route, status) = LineNotice.splitRow("R38\nPiacenza-Lodi-Milano\nCircolazione con gravi criticità", "R38")
        assertEquals("Piacenza-Lodi-Milano", route)
        assertEquals("Circolazione con gravi criticità", status)
        assertEquals("Piacenza-Lodi-Milano" to "", LineNotice.splitRow("Piacenza-Lodi-Milano"))
    }

    @Test fun excerptCutsAtWordBoundary() {
        val long = "parola ".repeat(80)
        val e = LineNotice.excerpt(long, 50)
        assertTrue(e.endsWith("…"))
        assertTrue(e.length <= 51)
        assertEquals("breve", LineNotice.excerpt("breve"))
    }

    @Test fun levels() {
        assertEquals(LineNotice.Level.SEVERE, LineNotice.level("Circolazione con gravi criticità"))
        assertEquals(LineNotice.Level.WARNING, LineNotice.level("Circolazione rallentata"))
        assertEquals(LineNotice.Level.REGULAR, LineNotice.level("Circolazione regolare"))
        assertEquals(LineNotice.Level.OTHER, LineNotice.level("Altro"))
    }

    @Test fun onlyTrenordLinePagesAreRead() {
        assertTrue(LineNotice.isTrenordLinePage("https://www.trenord.it/linee-e-orari/le-nostre-linee/passante/?code=R38"))
        assertTrue(!LineNotice.isTrenordLinePage("https://www.tilo.ch/it/linea-s10"))
    }
}

class LineNoticePersistTest {
    @Test fun encodeDecodeRoundTrip() {
        val p = LineNotice.Page(
            LineNotice.Message("Circolazione con gravi criticità", "06/11/2026 20:45", "Corpo\nsu due righe"),
            LineNotice.Message("Servizio modificato", "06/11/2026 18:10", "Limitati a Lodi."),
            "06/11/2026 20:45",
        )
        assertEquals(p, LineNotice.decode(LineNotice.encode(p)))
    }

    @Test fun onlyStatusSurvives() {
        val p = LineNotice.Page(LineNotice.Message("Circolazione regolare", "", ""), null, "")
        assertEquals(p, LineNotice.decode(LineNotice.encode(p)))
    }

    @Test fun garbageIsIgnored() {
        assertNull(LineNotice.decode(null))
        assertNull(LineNotice.decode(""))
        assertNull(LineNotice.decode("abc"))
    }
}

class LineStatusChangesTest {
    @Test fun alertsOnlyForWatchedLinesWhoseStatusChanged() {
        val old = mapOf("a" to "Circolazione regolare", "b" to "Circolazione regolare", "c" to "Circolazione regolare")
        val now = mapOf("a" to "Circolazione con gravi criticità", "b" to "Circolazione regolare", "c" to "Circolazione rallentata")
        assertEquals(listOf("a" to "Circolazione con gravi criticità"), LineNotice.changes(old, now, setOf("a", "b")))
    }

    @Test fun firstReadingAndEmptyStatusDoNotAlert() {
        assertTrue(LineNotice.changes(emptyMap(), mapOf("a" to "Circolazione con gravi criticità"), setOf("a")).isEmpty())
        assertTrue(LineNotice.changes(mapOf("a" to "Circolazione regolare"), mapOf("a" to ""), setOf("a")).isEmpty())
    }

    @Test fun spacingAndCaseAreIgnored() {
        assertTrue(LineNotice.changes(mapOf("a" to "Circolazione  regolare"), mapOf("a" to "circolazione regolare "), setOf("a")).isEmpty())
    }
}
