package com.binario.treni

import com.binario.treni.data.TrainMerge
import com.binario.treni.data.TrainStop
import org.junit.Assert.assertEquals
import org.junit.Test

/** Caso reale 05/11/2026: treno a +13 a Gallarate, Canegrate e Parabiago (Transitous) mostravano l'orario programmato. */
class PropagateDelayTest {
    private val min = 60_000L
    private fun stop(name: String, t: Long, delay: Int, passed: Boolean, src: String) =
        TrainStop(name, name, t, t + min, if (passed) t + delay * min else 0L, 0L, delay, "", false, false, src = src)

    private val list = listOf(
        stop("Gallarate", 1_000 * min, 13, true, "Trenord"),
        stop("Busto", 1_006 * min, 13, false, "Trenord"),
        stop("Canegrate", 1_014 * min, 0, false, "Transitous"),
        stop("Parabiago", 1_017 * min, 0, false, "Transitous"),
    )

    @Test fun transitousStopsGetTheTrainDelay() {
        val r = TrainMerge.propagateDelay(list, "Transitous")
        assertEquals(listOf(13, 13, 13, 13), r.map { it.delay })
    }

    @Test fun otherSourcesAreUntouched() {
        val l = list.map { if (it.name == "Canegrate") it.copy(src = "Trenord") else it }
        assertEquals(0, TrainMerge.propagateDelay(l, "Transitous").first { it.name == "Canegrate" }.delay)
    }

    @Test fun onTimeTrainStaysOnTime() {
        val l = list.map { it.copy(delay = 0, realArr = if (it.name == "Gallarate") it.schedArr else 0L) }
        assertEquals(listOf(0, 0, 0, 0), TrainMerge.propagateDelay(l, "Transitous").map { it.delay })
    }

    @Test fun explicitEstimateOfTransitousIsKept() {
        val l = list.map { if (it.name == "Parabiago") it.copy(delay = 5) else it }
        assertEquals(listOf(13, 13, 13, 5), TrainMerge.propagateDelay(l, "Transitous").map { it.delay })
    }

    @Test fun noLabelNoChange() {
        assertEquals(list, TrainMerge.propagateDelay(list, ""))
    }
}
