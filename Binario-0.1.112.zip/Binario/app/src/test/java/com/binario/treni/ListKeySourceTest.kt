package com.binario.treni

import com.binario.treni.ui.uniqueKeys
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Migliorìa 7: ogni lista scorrevole dà una chiave stabile alle righe, e due righe uguali non producono chiavi doppie. */
class ListKeySourceTest {
    @Test fun duplicatesGetDistinctKeys() {
        assertEquals(listOf("a", "b", "a#1", "a#2"), uniqueKeys(listOf("a", "b", "a", "a")) { it })
        assertEquals(listOf("1", "2", "3"), uniqueKeys(listOf(1, 2, 3)) { it })
        assertEquals(emptyList<String>(), uniqueKeys(emptyList<String>()) { it })
    }

    @Test fun keysAreStableWhenTheListChangesAround() {
        val before = uniqueKeys(listOf("x", "y", "z")) { it }
        val after = uniqueKeys(listOf("y", "z")) { it }
        assertEquals(before[1], after[0])
        assertEquals(before[2], after[1])
    }

    @Test fun everyLazyListUsesKeys() {
        val ui = listOf("src/main/java/com/binario/treni/ui", "app/src/main/java/com/binario/treni/ui").map { File(it) }.first { it.isDirectory }
        val bad = ui.walkTopDown().filter { it.extension == "kt" && it.name != "KeyedItems.kt" }.flatMap { f ->
            f.readLines().mapIndexedNotNull { i, l ->
                if (Regex("""(?<![A-Za-z])items\(""").containsMatchIn(l) && !l.contains("key") && !l.trimStart().startsWith("//") && !l.trimStart().startsWith("*")) "${f.name}:${i + 1}" else null
            }
        }.toList()
        assertTrue("Liste senza chiave (usa keyedItems): $bad", bad.isEmpty())
    }

    @Test fun stateViewHasNoFixedWidths() {
        val ui = listOf("src/main/java/com/binario/treni/ui", "app/src/main/java/com/binario/treni/ui").map { File(it) }.first { it.isDirectory }
        val s = File(ui, "Common.kt").readText()
        val body = s.substringAfter("fun StateView(").substringBefore("fun LoadingBox")
        assertTrue(body.isNotBlank())
        assertTrue("StateView non deve avere larghezze fisse", !Regex("""\.width\(\d+\.dp\)""").containsMatchIn(body))
    }
}
