package com.binario.treni

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 06/11/2026: campi Partenza e Inverti senza margine sopra, widget con testo sul bordo, schede illeggibili sul giallo, tablet stirato. */
class LayoutFitSourceTest {
    private fun f(rel: String) = File("src/main/$rel").let { if (it.exists()) it else File("app/src/main/$rel") }.readText()

    @Test fun searchHeaderHasTopMarginAndSwapFollowsFields() {
        val s = f("java/com/binario/treni/ui/SearchScreen.kt")
        assertTrue(s.contains("top = 10.dp, bottom = 14.dp).height(IntrinsicSize.Min)"))
        assertFalse("Il tasto Inverti non deve avere altezza fissa", s.contains("height(98.dp)"))
    }

    @Test fun widgetKeepsContentInsideBorder() {
        val w = f("res/layout/widget.xml")
        assertTrue(w.contains("android:padding=\"4dp\"") && w.contains("android:clipToPadding=\"true\""))
        assertTrue(f("res/layout/widget_row.xml").contains("android:paddingStart=\"14dp\""))
    }

    @Test fun tabsUseReadableColourOnPrimary() {
        val c = f("java/com/binario/treni/ui/Common.kt")
        assertTrue(c.contains("val OnGreen"))
        val tabs = c.substring(c.indexOf("fun GreenTabs"), c.indexOf("/** Dialog di ricerca stazione"))
        assertFalse("Le schede non devono usare il bianco fisso", tabs.contains("Color.White"))
    }

    @Test fun tabletContentIsCentred() {
        val m = f("java/com/binario/treni/MainActivity.kt")
        assertTrue(m.contains("smallestScreenWidthDp >= 600") && m.contains("widthIn(max = MAX_CONTENT_WIDTH)"))
    }
}
