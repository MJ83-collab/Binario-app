package com.binario.treni

import com.binario.treni.data.Diag
import com.binario.treni.data.Http
import com.binario.treni.data.HttpStatusException
import com.binario.treni.data.Net
import com.binario.treni.data.OfflineException
import java.io.File
import org.junit.After
import org.junit.Before
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** Migliorìe 3, 4 e 10: senza rete si rinuncia subito; un solo cliente di rete; registro degli errori senza dati personali. */
class NetGuardTest {
    @Before fun clean() { Diag.clear() }
    @After fun reset() { Net.forceOffline = false; Diag.clear() }

    @Test fun withoutNetworkTheCallFailsImmediately() {
        Net.forceOffline = true
        val t0 = System.nanoTime()
        try { Http.getText("https://example.invalid/x"); fail("doveva fallire") } catch (e: OfflineException) { /* ok */ }
        assertTrue("subito, senza attese né nuovi tentativi", (System.nanoTime() - t0) / 1_000_000 < 500)
    }

    @Test fun offlineDoesNotFillTheDiagnosticLog() {
        Net.forceOffline = true
        try { Http.getText("https://example.invalid/x") } catch (_: OfflineException) { }
        assertEquals(0, Diag.count())
    }

    @Test fun logKeepsOnlyAddressWithoutQueryAndAtMostTen() {
        Diag.record("https://api.example.org/v1/trip?key=SEGRETO&q=Mario+Rossi#frag", HttpStatusException(503), now = 0L)
        val b = Diag.block()
        assertTrue(b.contains("https://api.example.org/v1/trip"))
        assertTrue(b.contains("HTTP 503"))
        assertFalse(b.contains("SEGRETO"))
        assertFalse(b.contains("Mario"))
        repeat(25) { Diag.record("https://a.example/$it", java.io.IOException("x"), now = 0L) }
        assertEquals(Diag.MAX, Diag.count())
    }

    @Test fun emptyLogAddsNothingToTheFeedback() {
        assertEquals("", Diag.block())
    }

    @Test fun noEmailInTheNetworkClient() {
        assertFalse(Http.DEFAULT_UA.contains("@"))
        val raccolta = listOf(File("tools/raccolta/raccogli.py"), File("../tools/raccolta/raccogli.py"), File("../../tools/raccolta/raccogli.py")).firstOrNull { it.exists() }
        if (raccolta != null) assertFalse(raccolta.readText().lines().first { it.startsWith("UA") }.contains("@"))
    }

    @Test fun onlyKnownFilesOpenConnectionsByThemselves() {
        // Nuovi accessi alla rete passano da Http.getText. Questi file hanno casi particolari (POST, flussi, cookie, solo intestazione).
        // Gli altri file aprono la connessione con Http.open: senza rete falliscono subito
        val allowed = setOf("Http.kt", "Feedback.kt", "Health.kt", "Osm.kt", "Updater.kt")
        val root = listOf(File("src/main/java"), File("app/src/main/java")).first { it.isDirectory }
        val extra = root.walkTopDown().filter { it.extension == "kt" && it.readText().contains("openConnection") && it.name !in allowed }.map { it.name }.toList()
        assertTrue("Usa Http.getText invece di openConnection: $extra", extra.isEmpty())
    }
}
