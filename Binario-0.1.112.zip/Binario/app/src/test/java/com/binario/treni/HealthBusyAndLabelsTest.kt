package com.binario.treni

import com.binario.treni.data.Health
import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 06/11/2026: Overpass risponde 429 (troppe richieste) → «occupato», non «guasto»; e le funzioni nuove devono vedersi. */
class HealthBusyAndLabelsTest {
    private fun source(rel: String): String =
        File("src/main/java/com/binario/treni/$rel").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$rel") }.readText()

    @Test fun http429IsBusyNotDown() {
        assertTrue(Health.isBusy(429))
        assertFalse(Health.isBusy(503))
        assertFalse(Health.isBusy(404))
        assertFalse(Health.isBusy(200))
    }

    @Test fun saveOfflineButtonIsVisibleInResults() {
        val s = source("ui/ResultsScreen.kt")
        assertTrue(s.contains("Salva questi orari per usarli offline"))
        assertTrue(s.contains("vm.saveOffline()"))
    }

    @Test fun savedScreenExplainsHowToSave() {
        val s = source("ui/OtherScreens.kt")
        assertFalse(s.contains("icona di download"))
        assertTrue(s.contains("Nessun orario salvato"))
    }

    @Test fun iconTabsShowTheirName() {
        val s = source("ui/Common.kt")
        assertTrue(s.contains("text = { FitText(label"))
    }

    @Test fun punctualitySearchLivesInsideTheScrollingList() {
        val s = source("ui/StatsScreen.kt")
        assertTrue(s.contains("item(key = \"search\")"))
        assertTrue(s.contains("matchesQuery(q, r.name"))
    }

    @Test fun linesNoLongerFallBackToWebPage() {
        val s = source("ui/LinesScreen.kt")
        assertTrue(s.contains("expanded = li.url"))
    }
}
