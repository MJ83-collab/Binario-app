package com.binario.treni

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.binario.treni.data.ColorBlind
import com.binario.treni.data.EN
import com.binario.treni.data.StyleSpec
import com.binario.treni.data.StyleSpecs
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.pow

/** Stili dell'app: leggibilità, adattamento ai daltonici e traduzioni (errori già capitati: stili scuri uguali con i daltonici, testo bianco su colori chiari). */
class StyleSpecsTest {
    @After fun reset() { ColorBlind.mode = "off" }

    private fun lum(c: Color): Double {
        val a = c.toArgb()
        fun ch(v: Int): Double { val x = v / 255.0; return if (x <= 0.03928) x / 12.92 else ((x + 0.055) / 1.055).pow(2.4) }
        return 0.2126 * ch((a shr 16) and 255) + 0.7152 * ch((a shr 8) and 255) + 0.0722 * ch(a and 255)
    }
    private fun contrast(a: Color, b: Color): Double { val x = lum(a); val y = lum(b); return (maxOf(x, y) + 0.05) / (minOf(x, y) + 0.05) }

    private fun allSpecs(): List<StyleSpec> = StyleSpecs.ALL + listOf(
        StyleSpecs.custom(Color(0xFF0B5CAD), false), StyleSpecs.custom(Color(0xFFFFD400), false), StyleSpecs.custom(Color(0xFF808080), false),
        StyleSpecs.custom(Color(0xFFF9A825), false), StyleSpecs.custom(Color(0xFF000000), true), StyleSpecs.custom(Color(0xFF1A237E), true),
        StyleSpecs.custom(Color(0xFFFFFFFF), true),
    )

    @Test fun textIsReadableOnEveryStyle() {
        allSpecs().forEach { s ->
            assertTrue("${s.id}: testo su sfondo", contrast(s.onSurface, s.background) >= 4.5)
            assertTrue("${s.id}: testo su riquadro", contrast(s.onSurface, s.surface) >= 4.5)
            assertTrue("${s.id}: testo sulla testata", contrast(s.onTopBar, s.topBar) >= 3.0)
            assertTrue("${s.id}: testo sul pulsante", contrast(s.onPrimary, s.primary) >= 3.0)
            assertTrue("${s.id}: testo secondario", contrast(s.muted, s.background) >= 3.0)
        }
    }

    @Test fun colorBlindModeChangesEveryBuiltInStyle() {
        listOf("redgreen", "tritan").forEach { mode ->
            ColorBlind.mode = mode
            StyleSpecs.ALL.forEach { s ->
                val a = StyleSpecs.forColorBlind(s)
                assertNotEquals("$mode: ${s.id} resta uguale", s.primary, a.primary)
                assertTrue("$mode: ${s.id} testata illeggibile", contrast(a.onTopBar, a.topBar) >= 3.0)
                assertTrue("$mode: ${s.id} pulsante illeggibile", contrast(a.onPrimary, a.primary) >= 3.0)
            }
        }
    }

    @Test fun colorBlindModeOffLeavesStylesAlone() {
        ColorBlind.mode = "off"
        StyleSpecs.ALL.forEach { assertEquals(it, StyleSpecs.forColorBlind(it)) }
    }

    @Test fun customColoursAreKeptWithColorBlindMode() {
        ColorBlind.mode = "redgreen"
        val c = StyleSpecs.custom(Color(0xFFC2185B), false)
        assertEquals(c, StyleSpecs.forColorBlind(c))
    }

    @Test fun idsAreValid() {
        assertEquals(StyleSpecs.ALL.size, StyleSpecs.ALL.map { it.id }.distinct().size)
        assertEquals("classic", StyleSpecs.valid("non-esiste"))
        assertEquals("vintage", StyleSpecs.valid("vintage"))
        assertEquals("custom", StyleSpecs.valid("custom"))
        StyleSpecs.ALL.forEach { assertEquals(it.id, StyleSpecs.valid(it.id)) }
    }

    @Test fun namesAndDescriptionsAreTranslated() {
        (StyleSpecs.ALL + StyleSpecs.custom(Color.Blue, false)).forEach {
            assertTrue("manca la traduzione di «${it.name}»", EN.containsKey(it.name))
            assertTrue("manca la traduzione di «${it.desc}»", EN.containsKey(it.desc))
        }
    }

    @Test fun rainbowHasSevenColours() = assertEquals(7, StyleSpecs.RAINBOW.size)
}
