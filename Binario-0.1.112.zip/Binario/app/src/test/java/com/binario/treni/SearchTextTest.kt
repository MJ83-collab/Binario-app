package com.binario.treni

import com.binario.treni.ui.foldText
import com.binario.treni.ui.matchesQuery
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 06/11/2026: scrivendo «varese» nella Puntualità non compariva nulla; la ricerca ignora maiuscole, accenti e trattini. */
class SearchTextTest {
    @Test fun fold() {
        assertEquals("varese nord", foldText("Varese-Nord"))
        assertEquals("citta", foldText("Città"))
    }

    @Test fun matches() {
        assertTrue(matchesQuery("varese", "Varese Nord", "FN_S01", ""))
        assertTrue(matchesQuery("VARESE nord", "Varese-Nord", "", ""))
        assertTrue(matchesQuery("", "Qualsiasi"))
        assertFalse(matchesQuery("como", "Varese Nord", "x", "y"))
    }
}
