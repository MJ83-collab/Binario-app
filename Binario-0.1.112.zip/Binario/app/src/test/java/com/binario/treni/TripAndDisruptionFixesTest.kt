package com.binario.treni

import com.binario.treni.data.DisruptionSummary
import com.binario.treni.data.LineDisruption
import com.binario.treni.data.TripEntry
import com.binario.treni.data.TripLog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Dieci migliorie al diario «I miei viaggi» e al disagio delle linee. */
class TripAndDisruptionFixesTest {
    private fun src(p: String) =
        File("src/main/java/com/binario/treni/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$p") }.readText()

    private val at = 1_794_215_520_000L // 9/11/2026 10:12 in Italia

    @Test fun logKeepsMoreThanOneYearOfCommuting() {
        // Andata e ritorno in 250 giorni feriali = 500 viaggi: il riepilogo dell'anno non deve perdere gennaio
        assertTrue(TripLog.MAX >= 1000)
        var list = emptyList<TripEntry>()
        for (i in 1..600) list = TripLog.upsert(list, TripEntry("k$i", "2026-01-01", "R $i", "A", "B", i * 1000L, i * 1000L, 0))
        assertEquals(600, list.size)
    }

    @Test fun csvDoesNotTurnHandWrittenTextIntoFormulas() {
        val list = listOf(TripEntry("a", "2026-11-09", "=HYPERLINK(\"x\")", "+Varese", "@Milano", at, at, 0, manual = true))
        val row = TripLog.toCsv(list).removePrefix("﻿").trimEnd().split("\r\n")[1]
        assertTrue(row, row.contains("\"'=HYPERLINK(\"\"x\"\")\""))
        assertTrue(row, row.contains(";'+Varese;'@Milano;"))
        // I testi normali restano uguali
        val ok = TripLog.toCsv(listOf(TripEntry("b", "2026-11-09", "R 2727", "Varese", "Milano", at, at, 3)))
        assertTrue(ok.contains(";R 2727;Varese;Milano;3;"))
    }

    @Test fun claimLeavesSpaceForNameAndTicket() {
        val t = TripLog.claimText(TripEntry("x", "2026-11-09", "R 2727", "Varese", "Milano", at, at + 70 * 60_000L, 70))
        assertTrue(t.contains("Nome e cognome: \n"))
        assertTrue(t.contains("Numero del biglietto o dell'abbonamento: \n"))
        assertTrue("prima della richiesta vera e propria", t.indexOf("Nome e cognome") < t.indexOf("Ai sensi del Regolamento"))
        assertTrue("nessun indirizzo email", !t.contains("@"))
    }

    @Test fun punctualityOfTheMonth() {
        val list = listOf(
            TripEntry("1", "2026-11-02", "R 1", "A", "B", at, at, 0),
            TripEntry("2", "2026-11-03", "R 1", "A", "B", at, at, 5),
            TripEntry("3", "2026-11-04", "R 1", "A", "B", at, at, 6),
            TripEntry("4", "2026-11-05", "R 1", "A", "B", at, 0L, 0, cancelled = true),
        )
        // 2 in orario (fino a 5 min) su 3 viaggi fatti: il soppresso non conta
        assertEquals(67, TripLog.summary(list).punctuality)
        assertNull("nessun viaggio fatto: niente percentuale", TripLog.summary(list.takeLast(1)).punctuality)
        assertTrue(TripLog.exportText("Novembre", list).contains("Puntualità: 67%"))
        assertTrue(src("ui/TripLogScreen.kt").contains("s.punctuality?.let { p ->"))
    }

    @Test fun deletingOneTripAsksFirst() {
        val ui = src("ui/TripLogScreen.kt")
        assertTrue(ui.contains("TripRow(e) { askDelete = e }"))
        assertTrue(ui.contains("tx(\"Eliminare questo viaggio?\")"))
    }

    @Test fun timeOfDayCardSaysWhenARouteIsChosen() {
        val ui = src("ui/TripLogScreen.kt")
        assertTrue(ui.contains("SlotsCard(TripLog.bySlot(mine), byRoute = route != null)"))
        assertTrue(ui.contains("tx(\"Su tutti i viaggi della tratta scelta\")"))
    }

    @Test fun moreWaysOfSayingLimited() {
        assertTrue(LineDisruption.isLimited("Treno soppresso parzialmente tra Gallarate e Varese"))
        assertTrue(LineDisruption.isLimited("Limitazione di percorso a Saronno"))
        assertTrue(LineDisruption.isLimited("Treno parzialmente cancellato"))
        assertTrue(!LineDisruption.isLimited("Treno in ritardo per guasto alla linea"))
    }

    @Test fun fewTrainsDoNotResetTheAlert() {
        val one = DisruptionSummary(checked = 1, cancelled = 0, limited = 0, late = 0) // 0% ma su un treno solo
        assertEquals("si tiene il 40% di prima", 40, LineDisruption.percentToKeep(one, 40))
        val many = DisruptionSummary(checked = 8, cancelled = 0, limited = 0, late = 1)
        assertEquals(13, LineDisruption.percentToKeep(many, 40))
        assertTrue(src("service/LineWatch.kt").contains("putInt(k + \"_pct\", LineDisruption.percentToKeep(s, lastPct))"))
    }

    @Test fun networkErrorIsNotZeroDisruption() {
        val l = src("data/LineDisruptionLoader.kt")
        assertTrue(l.contains("if (searchErrors == 2) return@withContext null"))
        assertTrue(l.contains("if (numbers.isNotEmpty() && states.all { it == null }) return@withContext null"))
    }

    @Test fun cancelledTripEndsWhereYouGetOff() {
        assertTrue(src("service/Services.kt").contains("recordTrip(st, target, 0L, 0, cancelled = true)"))
    }
}
