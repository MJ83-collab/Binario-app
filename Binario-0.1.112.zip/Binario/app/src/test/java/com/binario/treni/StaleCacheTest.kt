package com.binario.treni

import com.binario.treni.data.Freshness
import com.binario.treni.data.Lru
import com.binario.treni.data.TtlCache
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Migliorìe 2 e 6: dati scaduti usati solo se la rete cade; memorie con un limite. */
class StaleCacheTest {
    @Test fun freshEntryIsReturnedOnlyInsideItsLife() {
        val c = TtlCache<String>(10)
        c.put("k", "dato", now = 1_000L)
        assertEquals("dato", c.fresh("k", 15_000L, now = 10_000L))
        assertNull("scaduta: non è più fresca", c.fresh("k", 15_000L, now = 20_000L))
    }

    @Test fun staleEntryComesBackWithItsAgeUntilTheLimit() {
        val c = TtlCache<String>(10)
        c.put("k", "dato", now = 0L)
        val (v, age) = c.stale("k", 30 * 60_000L, now = 3 * 60_000L)!!
        assertEquals("dato", v)
        assertEquals(3 * 60_000L, age)
        assertNull("oltre 30 minuti non si mostra", c.stale("k", 30 * 60_000L, now = 31 * 60_000L))
        assertNull(c.stale("assente", 30 * 60_000L, now = 0L))
    }

    @Test fun clearForgetsEverything() {
        val c = TtlCache<String>(10)
        c.put("k", "x", now = 0L)
        c.clear()
        assertNull(c.stale("k", Long.MAX_VALUE / 2, now = 1L))
    }

    @Test fun ttlCacheHasALimit() {
        val c = TtlCache<Int>(3)
        (1..5).forEach { c.put("k$it", it, now = 0L) }
        assertNull(c.stale("k1", 1000L, now = 0L))
        assertEquals(5, c.stale("k5", 1000L, now = 0L)!!.first)
    }

    @Test fun lruDropsTheLeastRecentlyUsed() {
        val m = Lru<String, Int>(500)
        (1..500).forEach { m["k$it"] = it }
        m["k1"]            // k1 torna «recente»
        m["k501"] = 501    // esce k2, non k1
        assertEquals(500, m.size)
        assertEquals(1, m["k1"])
        assertNull(m["k2"])
        assertEquals(501, m["k501"])
    }

    @Test fun freshnessBannerWindow() {
        Freshness.reset()
        assertNull(Freshness.ageIfRecent(1_000L))
        Freshness.note(180_000L, now = 1_000L)
        assertEquals(180_000L, Freshness.ageIfRecent(30_000L))
        assertNull("dopo un minuto sparisce", Freshness.ageIfRecent(70_000L))
        Freshness.reset()
    }

    @Test fun memoriesAreBoundedInSource() {
        val data = listOf(java.io.File("src/main/java/com/binario/treni/data"), java.io.File("app/src/main/java/com/binario/treni/data")).first { it.isDirectory }
        val bad = data.walkTopDown().filter { it.extension == "kt" }.flatMap { f ->
            f.readLines().mapIndexedNotNull { i, l -> if (Regex("""private val \w+ = (java\.util\.concurrent\.)?ConcurrentHashMap<String, (Match|Hub|Station|Long|String|Pair<JSONObject, String>)>\(\)""").containsMatchIn(l) && f.name != "Api.kt") "${f.name}:${i + 1}" else null }
        }.toList()
        assertTrue("Memorie senza limite: $bad", bad.isEmpty())
    }
}
