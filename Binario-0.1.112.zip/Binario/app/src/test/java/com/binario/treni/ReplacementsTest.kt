package com.binario.treni

import com.binario.treni.data.BinarioHistory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 05/11/2026: 2727 soppresso su FerrovieNord, partito poi come 4747. */
class ReplacementsTest {
    private val csv = "giorno;soppresso;aggiunto;origine;destinazione;partenza_soppresso;partenza_aggiunto;differenza_minuti\n" +
        "2026-11-05;2727;4747;Milano Cadorna;Varese Nord;19:00;19:08;8\n" +
        "2026-10-29;2727;4745;Milano Cadorna;Varese Nord;19:00;19:05;5\n" +
        "2026-11-04;1111;2222;A;B;10:00;10:03;3\n"

    @Test fun parsesAllRows() {
        val l = BinarioHistory.parseReplacements(csv)
        assertEquals(3, l.size)
        assertEquals("4747", l[0].added)
        assertEquals(8, l[0].diffMinutes)
    }

    @Test fun findsCancelledAndSubstituteTrain() {
        val l = BinarioHistory.parseReplacements(csv)
        assertEquals(listOf("4747", "4745"), BinarioHistory.replacementsOf(l, "2727").map { it.added })
        assertEquals(listOf("2727"), BinarioHistory.replacementsOf(l, "4747").map { it.cancelled })
        assertTrue(BinarioHistory.replacementsOf(l, "9999").isEmpty())
    }

    @Test fun acceptsLabelledNumbers() {
        val l = BinarioHistory.parseReplacements(csv)
        assertEquals(2, BinarioHistory.replacementsOf(l, "REG 2727").size)
    }

    @Test fun emptyOrBrokenFileGivesNothing() {
        assertTrue(BinarioHistory.parseReplacements("").isEmpty())
        assertTrue(BinarioHistory.parseReplacements("giorno;soppresso;aggiunto\n2026-11-05;;\n").isEmpty())
    }
}
