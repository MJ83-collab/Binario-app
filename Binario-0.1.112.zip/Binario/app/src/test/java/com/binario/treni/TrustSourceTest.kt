package com.binario.treni

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Fiducia nei dati: il conto alla rovescia è dichiarato stima e ogni scheda treno dice da quanto tempo sono i dati. */
class TrustSourceTest {
    private fun read(p: String) = File("src/main/java/com/binario/treni/ui/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/$p") }.readText()

    @Test fun countdownIsLabelledAsEstimate() {
        val s = read("NewFeatures.kt")
        assertTrue(s.contains("Stima: orario in tabella più il ritardo noto."))
        assertTrue(s.contains("(if (left > 0) \"~\" else \"\") + big"))
    }

    @Test fun trainScreenDoesNotSpendSpaceOnDataAge() {
        // Età dei dati e fonti stanno nella sezione dedicata: la scheda treno non le ripete (scelta di Marco, 06/11/2026)
        assertFalse(read("TrainScreens.kt").contains("FreshnessLine"))
    }

    @Test fun replacementCardIsOnTrainScreen() {
        assertTrue(read("TrainScreens.kt").contains("ReplacementCard(st)"))
    }
}
