package com.binario.treni

import com.binario.treni.data.HomeLevel
import com.binario.treni.data.HomeMenuRules
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Funzioni della home su tre livelli: Base (predefinito), Avanzate, Complete (23/11/2026). */
class HomeModeTest {
    private fun src(p: String) = File("src/main/java/com/binario/treni/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$p") }.readText()

    private val all = listOf(
        "settings", "bot", "trainsmap", "saved", "trips", "reminders", "lines", "italy", "germany", "switzerland", "austria", "france",
        "explore", "assistance", "news", "guaranteed", "nearby", "toilets?id=&name=", "sellers?id=&name=", "dae?id=&name=",
        "tickets", "fares", "help", "feedback?bug=false",
    )

    @Test fun completeShowsEverything() {
        all.forEach { assertTrue(it, HomeMenuRules.visibleInMenu(it, HomeLevel.FULL)) }
        assertEquals(0, HomeMenuRules.hiddenCount(all, HomeLevel.FULL))
    }

    @Test fun baseKeepsOnlyEssentials() {
        listOf("settings", "reminders", "nearby", "news", "tickets", "help", "feedback?bug=false", "italy").forEach { assertTrue(it, HomeMenuRules.visibleInMenu(it, HomeLevel.BASE)) }
        listOf("trainsmap", "germany", "france", "dae?id=&name=", "explore", "lines", "bot", "trips", "saved").forEach { assertFalse(it, HomeMenuRules.visibleInMenu(it, HomeLevel.BASE)) }
    }

    @Test fun advancedAddsTheEverydayExtras() {
        listOf("trips", "saved", "lines", "guaranteed", "switzerland", "fares", "toilets?id=&name=", "sellers?id=&name=", "assistance")
            .forEach { assertTrue(it, HomeMenuRules.visibleInMenu(it, HomeLevel.ADVANCED)) }
        // Tutto quello di Base resta
        HomeMenuRules.BASIC_ROUTES.forEach { assertTrue(it, HomeMenuRules.visibleInMenu(it, HomeLevel.ADVANCED)) }
        // Il resto solo con Complete
        listOf("trainsmap", "germany", "austria", "france", "dae?id=&name=", "explore", "bot").forEach { assertFalse(it, HomeMenuRules.visibleInMenu(it, HomeLevel.ADVANCED)) }
    }

    @Test fun eachLevelShowsMoreThanThePrevious() {
        val b = HomeMenuRules.hiddenCount(all, HomeLevel.BASE)
        val a = HomeMenuRules.hiddenCount(all, HomeLevel.ADVANCED)
        assertTrue("$b > $a > 0", b > a && a > 0)
    }

    @Test fun oldTwoLevelChoiceIsKept() {
        // Senza scelta: Base. Chi aveva «Base»: Base. Chi aveva scelto «Complete»: resta Complete.
        assertEquals(HomeLevel.BASE, HomeLevel.fromSaved(null, null))
        assertEquals(HomeLevel.BASE, HomeLevel.fromSaved(null, true))
        assertEquals(HomeLevel.FULL, HomeLevel.fromSaved(null, false))
        // La scelta nuova vince
        assertEquals(HomeLevel.ADVANCED, HomeLevel.fromSaved("ADVANCED", false))
        assertEquals(HomeLevel.BASE, HomeLevel.fromSaved("sconosciuto", null))
        assertTrue(com.binario.treni.data.BASIC_DEFAULT)
    }

    @Test fun choiceIsSaved() {
        val store = src("data/Store.kt")
        assertTrue(store.contains("p.getString(\"set_home_level\", null)"))
        assertTrue(store.contains("p.edit().putString(\"set_home_level\", v.name)"))
        val mode = src("data/HomeMode.kt")
        assertTrue(mode.contains("Store(ctx).homeLevel = value"))
        assertTrue(mode.contains("level = Store(ctx).homeLevel"))
    }

    @Test fun routeIgnoresParameters() {
        assertEquals("feedback", HomeMenuRules.routeOf("feedback?bug=false"))
    }

    @Test fun homeShowsPartsByLevel() {
        val s = src("ui/SearchScreen.kt")
        assertTrue(s.contains("com.binario.treni.data.HomeLevel.entries.forEach { l ->"))
        assertTrue("riga che spiega il livello", s.contains("Text(tx(HomeMode.level.description)"))
        assertTrue(s.contains("if (HomeMode.advanced) OptionRow(Icons.Filled.Person"))
        assertTrue(s.contains("if (HomeMode.advanced) OptionRow(Icons.Outlined.LocalOffer"))
        assertTrue(s.contains("if (HomeMode.advanced) item(key = \"h_prices\")"))
        assertTrue(s.contains("if (HomeMode.full) {\n                item(key = \"h_dae\")"))
        assertTrue(s.contains("if (HomeMode.full && AppStyle.spec?.layout"))
        assertFalse(s.contains("HomeMode.basic"))
        val d = src("ui/HomeDrawer.kt")
        assertTrue(d.contains("HomeMenuRules.visibleInMenu(it.route, level)"))
        assertTrue(d.contains("tx(\"Mostra tutte le funzioni\")"))
    }

    @Test fun everyLevelHasLabelAndDescription() {
        HomeLevel.entries.forEach { assertTrue(it.name, it.label.isNotBlank() && it.description.length > 20) }
        assertEquals(listOf("Base", "Avanzate", "Complete"), HomeLevel.entries.map { it.label })
    }
}
