package com.binario.treni

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Con il testo molto ingrandito (caso 06/11/2026: «Partenza» e gli orari si sovrapponevano) una larghezza fissa in dp accanto a un Text
 * taglia o spezza le parole. Ogni larghezza fissa su un Text deve usare `.fs()` (cresce con la dimensione del testo).
 */
class TextSizeSourceTest {
    private fun uiFiles(): List<File> {
        val dir = listOf("src/main/java/com/binario/treni/ui", "app/src/main/java/com/binario/treni/ui").map { File(it) }.first { it.isDirectory }
        return dir.walkTopDown().filter { it.extension == "kt" }.toList()
    }

    @Test fun fixedWidthsOnTextScaleWithTheFont() {
        val fixed = Regex("""(?<!Spacer\()Modifier\.width\(\d+\.dp\)""")
        val bad = uiFiles().filter { it.name != "VintageBoard.kt" }.flatMap { f ->
            f.readLines().mapIndexedNotNull { i, l ->
                if (l.contains("Text(") && fixed.containsMatchIn(l) && !l.trimStart().startsWith("//")) "${f.name}:${i + 1}: ${l.trim()}" else null
            }
        }
        assertTrue("Larghezze fisse su Text senza .fs():\n" + bad.joinToString("\n"), bad.isEmpty())
    }

    @Test fun tabsAndNavLabelsShrinkInsteadOfWrapping() {
        val common = uiFiles().first { it.name == "Common.kt" }.readText()
        assertTrue("GreenTabs deve usare FitText", common.contains("FitText(s.uppercase()"))
        val main = File("src/main/java/com/binario/treni/MainActivity.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/MainActivity.kt") }.readText()
        assertTrue("La barra in basso deve usare FitText", main.contains("FitText(com.binario.treni.data.tx(tab.label)"))
    }
}
