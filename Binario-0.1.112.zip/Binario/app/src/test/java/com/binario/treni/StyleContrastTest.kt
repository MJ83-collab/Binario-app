package com.binario.treni

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.binario.treni.data.StyleSpecs
import org.junit.Assert.assertTrue
import org.junit.Test

/** Ogni stile deve avere testo leggibile (rapporto almeno 4,5:1) su sfondo, riquadri, testata e campi. */
class StyleContrastTest {
    private fun ratio(a: Color, b: Color): Double {
        val l1 = a.luminance().toDouble() + 0.05; val l2 = b.luminance().toDouble() + 0.05
        return if (l1 > l2) l1 / l2 else l2 / l1
    }

    @Test fun everyStyleIsReadable() {
        val bad = mutableListOf<String>()
        StyleSpecs.ALL.forEach { s ->
            listOf(
                "testo/sfondo" to ratio(s.onSurface, s.background), "testo/riquadro" to ratio(s.onSurface, s.surface),
                "secondario/sfondo" to ratio(s.muted, s.background), "secondario/riquadro" to ratio(s.muted, s.surface),
                "secondario/variante" to ratio(s.muted, s.surfaceVariant), "testo/variante" to ratio(s.onSurface, s.surfaceVariant),
                "sul primario" to ratio(s.onPrimary, s.primary), "titolo/testata" to ratio(s.onTopBar, s.topBar),
                "bianco/campo" to ratio(Color.White, s.field),
            ).forEach { (n, r) -> if (r < 4.5) bad += s.id + " " + n + " " + "%.1f".format(r) }
        }
        assertTrue("Contrasto insufficiente: $bad", bad.isEmpty())
    }
}
