package com.binario.treni

import com.binario.treni.data.CSection
import com.binario.treni.data.Connection
import com.binario.treni.data.LineDisruption
import com.binario.treni.data.Linea
import com.binario.treni.data.Station
import com.binario.treni.data.SwissTraffic
import com.binario.treni.data.TiloLines
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * 9/11/2026: sulla S40 Como – Mendrisio – Varese l'app diceva «Nessun treno diretto trovato» e «Nessun treno partito
 * nelle ultime 3 ore» con la circolazione regolare; lo stesso per le altre linee TILO e svizzere.
 */
class TiloLinesTest {
    private fun src(p: String) =
        File("src/main/java/com/binario/treni/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$p") }.readText()

    private val now = 1_794_225_000_000L
    private fun sec(train: String, dep: Long, delay: Int = 0, walk: Boolean = false) =
        CSection(train, "TILO", "Como S. Giovanni", "Varese", dep, dep + 50 * 60_000L, "", "", delay, walk)
    private fun conn(dep: Long, vararg s: CSection) = Connection(dep, dep + 50 * 60_000L, s.count { !it.walk } - 1, s.toList(), emptyList())

    @Test fun onlyDirectTrainsWithTheirDelay() {
        val a = now - 60 * 60_000L
        val b = now - 30 * 60_000L
        val runs = TiloLines.directRuns(
            listOf(
                conn(b, sec("S40 25123", b, delay = 4)),
                conn(a, sec("S40 25121", a, delay = 20)),
                conn(a, sec("S40 25121", a, delay = 20)), // doppione
                conn(a, sec("S10", a), sec("S50", a + 20 * 60_000L)), // con un cambio: non è un diretto della linea
                conn(a, sec("", a, walk = true), sec("S40 25125", a + 5 * 60_000L)), // un tratto a piedi più un treno: diretto
            ),
            "Como S. Giovanni", "Varese",
        )
        assertEquals(listOf("S40 25121", "S40 25125", "S40 25123"), runs.map { it.sol.legs.single().number })
        assertEquals(listOf(20, 0, 4), runs.map { it.delay })
        assertTrue(runs.all { it.sol.source == "sbb.ch" && it.sol.changes == 0 })
    }

    @Test fun disruptionCountsDelaysOfTrainsAlreadyGone() {
        val runs = TiloLines.directRuns(
            listOf(
                conn(now - 170 * 60_000L, sec("S40 1", now - 170 * 60_000L, delay = 16)),
                conn(now - 100 * 60_000L, sec("S40 2", now - 100 * 60_000L, delay = 15)), // 15 non è «oltre 15»
                conn(now - 40 * 60_000L, sec("S40 3", now - 40 * 60_000L, delay = 2)),
                conn(now - 4 * 3_600_000L, sec("S40 4", now - 4 * 3_600_000L, delay = 30)), // fuori dalle 3 ore
                conn(now + 20 * 60_000L, sec("S40 5", now + 20 * 60_000L, delay = 40)), // non ancora partito
            ),
            "A", "B",
        )
        val s = TiloLines.summarize(runs, now)
        assertEquals(3, s.checked)
        assertEquals(1, s.late)
        assertEquals(0, s.cancelled + s.limited)
        assertEquals(33, s.percent)
    }

    @Test fun tiloEndsAreRealStations() {
        assertEquals("Como S. Giovanni" to "Varese", TiloLines.ENDS["S40"])
        assertTrue("nessun capolinea solo «Como» o «Milano»", TiloLines.ENDS.values.flatMap { listOf(it.first, it.second) }.none { it == "Como" || it == "Milano" })
        for (code in listOf("RE80", "S10", "S20", "S30", "S40", "S50", "S90")) assertTrue(code, TiloLines.ENDS.containsKey(code))
        val ls = src("ui/LinesScreen.kt")
        assertTrue(ls.contains("com.binario.treni.data.TiloLines.ENDS[li.code]"))
        // Anche dalla scheda «Svizzera» le linee TILO aprono i treni, non solo la pagina web
        assertTrue(ls.contains("SwissTab(openWeb) { li -> resolve(li)"))
    }

    @Test fun tiloLineIsRecognised() {
        val como = Station("COMO S.GIOVANNI", "S01520")
        val varese = Station("VARESE", "S01700")
        assertTrue(TiloLines.isTilo(Linea("S40", como, varese, operator = "TILO")))
        assertTrue(TiloLines.isTilo(Linea("", Station("Mendrisio (CH)", "CH8505307"), como)))
        assertFalse(TiloLines.isTilo(Linea("S5", varese, Station("MILANO PORTA GARIBALDI", "S01645"), operator = "Trenord")))
    }

    @Test fun lineScreenAndCardUseTheSwissTimetable() {
        val ts = src("ui/TrainScreens.kt")
        assertTrue(ts.contains("com.binario.treni.data.TiloLines.runs(t.from, t.to, now - 15 * 60_000L)"))
        assertTrue(ts.contains("if (tilo) item(key = \"ffs\") { SwissTrafficCard(line, tick, openWeb) }"))
        val card = src("ui/LineDisruptionCard.kt")
        assertFalse("la scheda del disagio non si nasconde più per le linee svizzere", card.contains("SwissLive.isSwiss(line.a.id) || SwissLive.isSwiss(line.b.id)) return"))
        assertTrue(src("data/LineDisruptionLoader.kt").contains("if (TiloLines.isTilo(line)) return@withContext TiloLines.disruption(line, now)"))
    }

    @Test fun backgroundCheckSkipsTiloLines() {
        val como = Station("COMO S.GIOVANNI", "S01520")
        val varese = Station("VARESE", "S01700")
        val t = LineDisruption.targets(listOf(Linea("S40", como, varese, operator = "TILO")), emptyList(), 3)
        assertTrue(t.isEmpty())
    }

    private val sample = """{"total_count":4,"results":[
        {"title":"Limited service: Mendrisio - Stabio","link":"https://www.sbb.ch/en/plan/rail-traffic-information?poiid=1","description":"x",
         "description_html":"09.11.2026 07:00 - 10:00\nLimited train service between Mendrisio and Stabio.\nLine S40 is affected.",
         "published":"2026-11-09T06:10:00+00:00","startdatetime":"2026-11-09T06:00:00+00:00","enddatetime":"2026-11-09T09:00:00+00:00"},
        {"title":"Limited service: Mendrisio - Stabio","link":"https://www.sbb.ch/en/plan/rail-traffic-information?poiid=1","description":"old",
         "description_html":"old","published":"2026-11-09T06:00:00+00:00","startdatetime":"2026-11-09T06:00:00+00:00","enddatetime":"2026-11-09T09:00:00+00:00"},
        {"title":"Limited service: Rapperswil - Einsiedeln","link":"https://www.sbb.ch/en/plan/rail-traffic-information?poiid=2","description":"Line S40 is affected.",
         "description_html":"Line S40 is affected.","published":"2026-11-09T05:00:00+00:00","startdatetime":"2026-11-09T05:00:00+00:00","enddatetime":null},
        {"title":"Disruption: Lugano","link":"https://www.sbb.ch/en/plan/rail-traffic-information?poiid=3","description":"ended",
         "description_html":"ended","published":"2026-11-08T05:00:00+00:00","startdatetime":"2026-11-08T05:00:00+00:00","enddatetime":"2026-11-08T07:00:00+00:00"}
    ]}"""

    @Test fun swissNoticesParsedOncePerNotice() {
        val list = SwissTraffic.parse(sample)
        assertEquals(3, list.size)
        val first = list.first()
        assertTrue("si tiene la versione più recente", first.text.contains("Line S40 is affected."))
        assertEquals(0L, list.first { it.title.contains("Rapperswil") }.end)
    }

    @Test fun swissNoticesForTheRightLine() {
        val list = SwissTraffic.parse(sample)
        val at = 1_794_211_200_000L // 9/11/2026 09:00 in Italia (08:00 UTC)
        val s40 = SwissTraffic.forLine(list, "S40", listOf("Como", "Mendrisio", "Varese", "COMO S.GIOVANNI"), at)
        // Mendrisio sì; la S40 di Zurigo (Rapperswil) no; l'avviso già finito di Lugano no
        assertEquals(listOf("Limited service: Mendrisio - Stabio"), s40.map { it.title })
        val s10 = SwissTraffic.forLine(list, "S10", listOf("Biasca", "Bellinzona", "Lugano", "Chiasso", "Como"), at)
        assertTrue("Lugano è finito", s10.isEmpty())
        val onlyItaly = SwissTraffic.forLine(list, "", listOf("Como", "Varese"), at)
        assertTrue(onlyItaly.isEmpty())
    }
}
