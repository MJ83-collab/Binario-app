package com.binario.treni

import com.binario.treni.data.TextScale
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Dimensione del testo: con il testo ingrandito le righe non si tagliano. */
class TextScaleTest {
    @After fun reset() { TextScale.value = 1f }

    @Test fun normalTextKeepsRequestedLines() {
        TextScale.value = 1f
        assertFalse(TextScale.big)
        assertEquals(1, TextScale.lines(1))
        assertEquals(2, TextScale.lines(2))
    }

    @Test fun bigTextNeverCutsLines() {
        listOf(1.15f, 1.3f, 1.5f).forEach { v ->
            TextScale.value = v
            assertTrue(TextScale.big)
            assertEquals(Int.MAX_VALUE, TextScale.lines(1))
        }
    }
}
