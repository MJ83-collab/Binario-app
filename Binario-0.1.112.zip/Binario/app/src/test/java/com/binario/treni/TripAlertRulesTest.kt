package com.binario.treni

import com.binario.treni.service.TripAlertRules
import com.binario.treni.service.TripAlertRules.Kind
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

class TripAlertRulesTest {
    @Test fun cancelled_always_alerts() = assertEquals(Kind.CANCELLED, TripAlertRules.disruption(true, 0))
    @Test fun cancelled_wins_over_delay() = assertEquals(Kind.CANCELLED, TripAlertRules.disruption(true, 30))
    @Test fun small_delay_is_silent() {
        assertEquals(Kind.NONE, TripAlertRules.disruption(false, 0))
        assertEquals(Kind.NONE, TripAlertRules.disruption(false, 9))
        assertEquals(Kind.NONE, TripAlertRules.disruption(false, -3))
    }
    @Test fun strong_delay_alerts_from_ten() {
        assertEquals(Kind.DELAYED, TripAlertRules.disruption(false, 10))
        assertEquals(Kind.DELAYED, TripAlertRules.disruption(false, 45))
    }
    @Test fun run_wires_disruption_for_out_and_back() {
        val f = File("src/main/java/com/binario/treni/service/TripAlerts.kt").takeIf { it.exists() }
            ?: File("app/src/main/java/com/binario/treni/service/TripAlerts.kt")
        val s = f.readText()
        assertEquals(true, s.contains("disruption(ctx, from, to, t, now, today, \"out\")"))
        assertEquals(true, s.contains("disruption(ctx, to, from, t, now, today, \"back\")"))
    }
}
