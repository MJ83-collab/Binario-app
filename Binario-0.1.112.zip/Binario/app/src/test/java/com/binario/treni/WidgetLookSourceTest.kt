package com.binario.treni

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 07/11/2026: testata verde e fondo chiaro con testi bianchi/gialli illeggibili, perché le righe leggevano lo stile solo se l'app era aperta. */
class WidgetLookSourceTest {
    private val src = File("src/main/java/com/binario/treni/widget/Widgets.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/widget/Widgets.kt") }.readText()

    @Test fun headerAndRowsShareOneLook() {
        assertTrue(src.contains("fun look(ctx: Context)"))
        assertTrue(src.contains("val lk = Widgets.look(ctx)"))
        assertTrue(src.contains("lk.bgRes"))
    }

    @Test fun widgetsNeverReadTheComposeStateDirectly() {
        assertFalse(src.contains("AppStyle.spec\n"))
        assertFalse(src.contains("AppStyle.spec "))
    }

    @Test fun traditionalStyleFollowsDarkTheme() {
        assertTrue(src.contains("widget_bg_app_dark"))
    }
}
