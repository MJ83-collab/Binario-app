package com.binario.treni

import com.binario.treni.data.HttpStatusException
import com.binario.treni.data.OfflineException
import com.binario.treni.data.SwissHttp
import java.io.File
import java.io.IOException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test

/** transport.opendata.ch ha un limite giornaliero per IP: cache, pausa dopo il 429, un solo nuovo tentativo. */
class SwissHttpTest {
    private val board = "https://transport.opendata.ch/v1/stationboard?id=8505300"
    private val t0 = 1_000_000_000L

    @Before fun clean() = SwissHttp.reset()

    @Test fun freshAnswerIsNotAskedAgain() {
        var calls = 0
        repeat(3) { SwissHttp.text(board, 1, 1, now = t0 + it * 1000L) { calls++; "{}" } }
        assertEquals(1, calls)
    }

    @Test fun after429NoRequestsDuringThePause() {
        var calls = 0
        try {
            SwissHttp.text(board, 1, 1, now = t0) { calls++; throw HttpStatusException(429) }
            fail("doveva dare 429")
        } catch (e: HttpStatusException) {
            assertEquals(429, e.code)
        }
        assertEquals("niente nuovo tentativo dopo un 429", 1, calls)
        assertTrue(SwissHttp.isPaused(t0 + 30_000L))
        try {
            SwissHttp.text(board, 1, 1, now = t0 + 30_000L) { calls++; "{}" }
            fail("in pausa doveva dare 429 senza chiedere")
        } catch (e: HttpStatusException) {
            assertEquals(429, e.code)
        }
        assertEquals(1, calls)
        assertFalse(SwissHttp.isPaused(t0 + SwissHttp.MIN_PAUSE_MS + 1))
    }

    @Test fun after429RecentDataIsShownInstead() {
        SwissHttp.text(board, 1, 1, now = t0) { "vecchio" }
        val later = t0 + 60_000L // il tabellone vale 30 s: qui è scaduto
        assertEquals("vecchio", SwissHttp.text(board, 1, 1, now = later) { throw HttpStatusException(429) })
        assertEquals("vecchio", SwissHttp.text(board, 1, 1, now = later + 1000L) { "nuovo" })
    }

    @Test fun serverErrorIsTriedOnceMore() {
        var calls = 0
        val r = SwissHttp.text(board, 1, 1, now = t0) { calls++; if (calls == 1) throw HttpStatusException(503) else "ok" }
        assertEquals("ok", r)
        assertEquals(2, calls)
    }

    @Test fun clientErrorAndOfflineAreNotRetried() {
        for (err in listOf<IOException>(HttpStatusException(404), OfflineException())) {
            SwissHttp.reset()
            var calls = 0
            try {
                SwissHttp.text(board, 1, 1, now = t0) { calls++; throw err }
                fail("doveva fallire")
            } catch (_: IOException) {
            }
            assertEquals(1, calls)
        }
    }

    @Test fun lifeAndPauseLimits() {
        assertEquals(24 * 3_600_000L, SwissHttp.life("https://transport.opendata.ch/v1/locations?query=Lugano"))
        assertEquals(30_000L, SwissHttp.life(board))
        assertEquals(120_000L, SwissHttp.life("https://transport.opendata.ch/v1/connections?from=a&to=b"))
        assertEquals(SwissHttp.MIN_PAUSE_MS, SwissHttp.pauseMs(HttpStatusException(429)))
        assertEquals(5 * 60_000L, SwissHttp.pauseMs(HttpStatusException(429, retryAfterMs = 5 * 60_000L)))
        assertEquals(SwissHttp.MAX_PAUSE_MS, SwissHttp.pauseMs(HttpStatusException(429, retryAfterMs = 3_600_000L)))
    }

    @Test fun healthSaysWhenTheSwissTimetableIsPaused() {
        assertEquals(null, SwissHttp.pauseNotice(t0))
        try { SwissHttp.text(board, 1, 1, now = t0) { throw HttpStatusException(429) } } catch (_: IOException) { }
        val notice = SwissHttp.pauseNotice(t0 + 1000L)
        assertTrue(notice != null && notice.startsWith("In pausa fino alle ") && notice.contains("(429)"))
        assertEquals(null, SwissHttp.pauseNotice(t0 + SwissHttp.MIN_PAUSE_MS + 1))
        val health = File("src/main/java/com/binario/treni/data/Health.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/data/Health.kt") }.readText()
        assertTrue("in pausa non si fa una nuova richiesta", health.contains("if (check.id == \"ch\") SwissHttp.pauseNotice()?.let { return Result(check, false, 0L, it, busy = true) }"))
        for (id in listOf("vt_news", "vt_infomob", "vt_ticker")) assertTrue(id, health.contains("Check(\"$id\""))
    }

    @Test fun swissCodeUsesTheSharedClient() {
        val src = File("src/main/java/com/binario/treni/data/Swiss.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/data/Swiss.kt") }.readText()
        assertFalse(src.contains("Http.getText("))
        assertFalse(src.contains("Binario/2."))
        assertEquals(2, Regex("""SwissHttp\.text\(""").findAll(src).count())
    }
}
