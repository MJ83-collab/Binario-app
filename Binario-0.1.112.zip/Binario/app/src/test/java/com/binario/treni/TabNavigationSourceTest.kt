package com.binario.treni

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 06/11/2026: dalla scheda di un treno il tasto «Cerca» non faceva nulla perché ripristinava lo stato salvato (il treno stesso). */
class TabNavigationSourceTest {
    private val main = File("src/main/java/com/binario/treni/MainActivity.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/MainActivity.kt") }.readText()

    @Test fun tabsNeverRestoreSavedState() {
        assertFalse("Le schede non devono ripristinare lo stato salvato", main.contains("restoreState = true"))
        assertFalse(main.contains("saveState = true"))
    }

    @Test fun barAndShortcutsUseGoTab() {
        assertTrue(main.contains("goTab(nav, tab.route)"))
        assertTrue(main.contains("goTab(nav, AppTab.TIMES.route)"))
        assertTrue(main.contains("popBackStack(route, false)"))
    }
}
