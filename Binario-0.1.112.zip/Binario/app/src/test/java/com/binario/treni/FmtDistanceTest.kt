package com.binario.treni

import com.binario.treni.data.Fmt
import org.junit.Assert.assertEquals
import org.junit.Test

/** Distanze uguali in tutte le schermate: metri sotto il chilometro, poi chilometri con la virgola italiana. */
class FmtDistanceTest {
    @Test fun metresBelowOneKilometre() {
        assertEquals("0 m", Fmt.distance(0.0))
        assertEquals("850 m", Fmt.distance(850.0))
        assertEquals("999 m", Fmt.distance(999.9))
    }

    @Test fun kilometresAlwaysUseItalianComma() {
        assertEquals("1,0 km", Fmt.distance(1000.0))
        assertEquals("1,2 km", Fmt.distance(1234.0))
        assertEquals("12,5 km", Fmt.distance(12_500.0))
    }

    @Test fun wholeMetresAreNotShownWithDecimals() {
        // Un intero passato come decimale deve dare lo stesso testo
        assertEquals("450 m", Fmt.distance(450.toDouble()))
    }
}
