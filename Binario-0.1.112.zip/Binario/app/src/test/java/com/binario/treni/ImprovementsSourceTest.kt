package com.binario.treni

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Controlli sul testo del codice per le correzioni di questa versione: ciò che non deve tornare a essere com'era. */
class ImprovementsSourceTest {
    private fun src(): File = File("src/main/java/com/binario/treni").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni") }
    private fun read(path: String): String = File(src(), path).readText()

    @Test fun versionInAppMatchesBuildFile() {
        // Il numero mostrato nell'app e quello usato dall'aggiornamento devono coincidere con build.gradle.kts
        val gradle = File("build.gradle.kts").let { if (it.exists()) it else File("app/build.gradle.kts") }.readText()
        val gradleName = Regex("""versionName\s*=\s*"([^"]+)"""").find(gradle)!!.groupValues[1]
        val appName = Regex("""const val APP_VERSION = "([^"]+)"""").find(read("ui/OtherScreens.kt"))!!.groupValues[1]
        assertEquals(gradleName, appName)
    }

    @Test fun everyVersionHasReleaseNotes() {
        // 9/11/2026: la 0.1.108 è uscita senza note («null» sotto «Novità»). Il workflow «Crea APK» prende le note dal
        // blocco di CHANGELOG_TEXT che inizia con il versionName esatto: senza quel blocco la build si ferma qui.
        val gradle = File("build.gradle.kts").let { if (it.exists()) it else File("app/build.gradle.kts") }.readText()
        val ver = Regex("""versionName\s*=\s*"([^"]+)"""").find(gradle)!!.groupValues[1]
        val text = Regex("CHANGELOG_TEXT = \"\"\"(.*?)\"\"\"", RegexOption.DOT_MATCHES_ALL).find(read("ui/OtherScreens.kt"))!!.groupValues[1]
        val block = text.split("\n\n").map { it.trim().lines() }.firstOrNull { it.firstOrNull()?.trim() == ver }
        assertTrue("Manca il blocco di note «$ver» in CHANGELOG_TEXT (ui/OtherScreens.kt)", block != null && block.drop(1).any { it.isNotBlank() })
    }

    @Test fun startupLoadsSettingsOnce() {
        val main = read("MainActivity.kt")
        assertEquals(1, Regex("""AppStyle\.load\(this\)""").findAll(main).count())
        assertEquals(1, Regex("""ColorBlind\.mode = """).findAll(main).count())
    }

    @Test fun listsAreSavedInBackground() {
        val s = read("data/Store.kt")
        val body = s.substring(s.indexOf("private fun <T> saveList"), s.indexOf("notifyWidgets()", s.indexOf("private fun <T> saveList")))
        assertTrue(body.contains(".apply()"))
        assertFalse(body.contains(".commit()"))
    }

    @Test fun torchIsAlwaysSwitchedOff() {
        val s = read("service/Services.kt")
        val flash = s.substring(s.indexOf("private fun flash"), s.indexOf(".start()", s.indexOf("private fun flash")))
        assertTrue(flash.contains("finally {"))
        assertTrue(flash.contains("cm.setTorchMode(id, false)"))
    }

    @Test fun backgroundFailuresAreRecorded() {
        // Errori che prima sparivano in silenzio: ora finiscono nel registro (Diag) allegato alle segnalazioni
        assertTrue(read("service/Services.kt").contains("Diag.record(\"avvisi-viaggio\""))
        assertTrue(read("service/Services.kt").contains("Diag.record(\"alto-adige\""))
        assertTrue(read("service/Services.kt").contains("Diag.record(\"annuncio-treno\""))
        assertTrue(read("widget/VintageWidgets.kt").contains("Diag.record(\"widget\""))
        assertTrue(read("data/TrainsMap.kt").contains("Diag.record(\"trenord-ritardi\""))
        assertTrue(read("data/Api.kt").contains("Diag.record(\"viaggiatreno-alternativa\""))
    }

    @Test fun deadViaggiaTrenoSearchIsGone() {
        // soluzioniViaggioNew risponde 404 da tempo: chiamarlo era solo una richiesta inutile
        val api = read("data/Api.kt")
        assertFalse(api.contains("\"soluzioniViaggioNew/"))
        assertFalse(api.contains("viaggiaTrenoSolutions("))
        // senza risultati e con LeFrecce in errore si mostra ancora l'errore di LeFrecce
        assertTrue(api.contains("lfError?.let { throw IOException(it.message ?: \"LeFrecce non raggiungibile\", it) }"))
    }

    @Test fun stopTimesAreExplainedNotOnlyByColour() {
        // Programmato, rilevato e previsto si distinguono anche senza colori: legenda, «≈» e descrizione a voce
        val s = read("ui/TrainScreens.kt")
        assertTrue(s.contains("TimesLegend()"))
        assertTrue(s.contains("Text(\"≈\" + Fmt.time(sched + delay * 60_000L)"))
        assertTrue(s.contains("Modifier.semantics(mergeDescendants = true) { contentDescription = desc }"))
    }

    @Test fun newsSaysHowManyItemsTheFilterHides() {
        val s = read("ui/NewsScreen.kt")
        assertEquals(2, Regex("""HiddenByFilter\(hiddenLabel\(""").findAll(s).count())
        assertTrue(s.contains("if (filter == \"all\") 0 else (total - shown).coerceAtLeast(0)"))
        // «Mostra tutti» cambia solo la vista: il filtro salvato resta quello scelto
        assertTrue(s.contains("{ filter = \"all\" }"))
        assertFalse(s.contains("{ filter = \"all\"; store.newsFilter"))
    }

    @Test fun tabsInARowShrinkTogether() {
        // Se una scheda non ci sta, si rimpiccioliscono tutte: niente schede con grandezze diverse nella stessa barra
        val s = read("ui/Common.kt")
        assertEquals(2, Regex("""shared = shared\)""").findAll(s).count())
        assertTrue(s.contains("val shared = rememberSharedTextSize(14.sp, options)"))
        assertTrue(s.contains("val shared = rememberSharedTextSize(11.sp, icons.map { it.second })"))
        assertTrue(s.contains("if (shared != null) shared.value = size * 0.9f else own = size * 0.9f"))
    }

    @Test fun distancesUseSharedFormatter() {
        // Niente più formati di distanza scritti a mano (che usavano la lingua del telefono)
        val files = listOf("ui/TaxiScreen.kt", "ui/StationScreens.kt", "ui/DaeScreen.kt", "ui/ToiletsScreen.kt", "ui/ExploreScreen.kt")
        val bad = files.filter { read(it).contains("\"%.1f km\"") || read(it).contains("%.1f km\", m / 1000.0") }
        assertEquals(emptyList<String>(), bad)
    }
}
