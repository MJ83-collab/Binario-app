package com.binario.treni

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/** Caso 06/11/2026: «Varese Nord» (rete FN) e «Varese» (rete RFI) vanno separabili; schede della puntualità con icone e scheda Grafici. */
class PunctualityTabsSourceTest {
    private val src = File("src/main/java/com/binario/treni/ui/StatsScreen.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/StatsScreen.kt") }.readText()

    @Test fun rfiFilterExistsForStationsAndTrains() {
        assertTrue(src.split("network == \"rfi\"").size - 1 >= 2)   // una riga di filtri condivisa da stazioni e treni: selezione e azione
        assertTrue(src.contains("\"rfi\" -> !isFn && !fnTrain"))
    }

    @Test fun tabsUseIconsAndChartsTab() {
        assertTrue(src.contains("GreenIconTabs("))
        assertTrue(src.contains("Icons.Filled.BarChart"))
        assertTrue(src.contains("tab == 4 && d != null -> ChartsTab("))
    }

    @Test fun fnStationsAreLabelledWithTheirNetwork() {
        assertTrue(src.contains("rete FN · raccolti dall'app"))
    }
}
