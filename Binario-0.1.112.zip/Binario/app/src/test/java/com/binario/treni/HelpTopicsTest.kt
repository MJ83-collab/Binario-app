package com.binario.treni

import com.binario.treni.data.HelpTopics
import com.binario.treni.ui.HELP_TEXT
import com.binario.treni.ui.HELP_TEXT_DE
import com.binario.treni.ui.HELP_TEXT_EN
import com.binario.treni.ui.HELP_TEXT_ES
import com.binario.treni.ui.HELP_TEXT_FR
import com.binario.treni.ui.HELP_TEXT_JA
import com.binario.treni.ui.HELP_TEXT_ZH
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Guida divisa per argomenti: ogni blocco della guida, in tutte le lingue, è una domanda con la sua risposta. */
class HelpTopicsTest {
    private val all = mapOf("it" to HELP_TEXT, "en" to HELP_TEXT_EN, "zh" to HELP_TEXT_ZH, "de" to HELP_TEXT_DE,
        "fr" to HELP_TEXT_FR, "es" to HELP_TEXT_ES, "ja" to HELP_TEXT_JA)

    @Test fun everyTopicIsAQuestionWithAnAnswer() {
        all.forEach { (lang, text) ->
            val topics = HelpTopics.parse(text)
            assertTrue("$lang: troppo pochi argomenti", topics.size >= 8)
            topics.forEach { t ->
                assertTrue("$lang: «${t.title}» non è una domanda", t.title.endsWith("?") || t.title.endsWith("？"))
                assertTrue("$lang: «${t.title}» senza risposta", t.body.isNotBlank())
            }
            assertEquals("$lang: argomenti doppi", topics.size, topics.map { it.title }.distinct().size)
        }
    }

    @Test fun sameTopicsInEveryLanguage() {
        val n = HelpTopics.parse(HELP_TEXT).size
        all.forEach { (lang, text) -> assertEquals("$lang: numero di argomenti diverso dall'italiano", n, HelpTopics.parse(text).size) }
    }

    @Test fun parsing() {
        val t = HelpTopics.parse("Uno?\nRisposta uno.\nAncora.\n\n  \nDue?\nRisposta due.")
        assertEquals(listOf("Uno?", "Due?"), t.map { it.title })
        assertEquals("Risposta uno.\nAncora.", t[0].body)
    }

    @Test fun helpOpensTheTopicScreen() {
        val s = File("src/main/java/com/binario/treni/MainActivity.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/MainActivity.kt") }.readText()
        assertTrue(s.contains("composable(\"help\") { HelpScreen("))
    }
}
