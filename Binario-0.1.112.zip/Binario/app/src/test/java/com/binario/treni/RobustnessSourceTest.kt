package com.binario.treni

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Verifiche sul testo del codice: ciò che deve restare vero a ogni versione. */
class RobustnessSourceTest {
    private fun root(): File = File("src/main/java/com/binario/treni").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni") }

    @Test fun tabsAndSearchTextSurviveRecreation() {
        // Cambiando tema, lingua o dimensione del testo Android ricrea la schermata: schede e ricerche non si devono perdere
        val bad = File(root(), "ui").listFiles { f -> f.name.endsWith(".kt") }!!.flatMap { f ->
            f.readLines().filter { Regex("""var (tab|query|q|text) by remember \{ mutable(Int)?StateOf""").containsMatchIn(it) }.map { f.name + ": " + it.trim() }
        }
        assertEquals(bad.joinToString("\n"), 0, bad.size)
    }

    @Test fun updateDownloadIsAtomic() {
        val s = File(root(), "data/Updater.kt").readText()
        assertTrue(s.contains(".part"))
        assertTrue(s.contains("renameTo(out)"))
        assertTrue(s.contains("usableSpace"))
    }

    @Test fun newsSourceFailuresAreRecorded() {
        val s = File(root(), "data/Sources.kt").readText()
        assertFalse(s.contains("catch (_: Exception) { }"))
    }

    @Test fun noForcedUnwrapOfHealthResult() {
        assertFalse(File(root(), "data/Health.kt").readText().contains("first!!"))
    }
}

class NoPersonalAddressTest {
    @Test fun noEmailInTheAppSources() {
        val root = File("src/main/java").let { if (it.exists()) it else File("app/src/main/java") }
        val hits = root.walkTopDown().filter { it.extension == "kt" && it.readText().contains("appmail") }.map { it.name }.toList()
        assertTrue("Email nei sorgenti: $hits", hits.isEmpty())
    }
}

class WidgetAndSearchSourceTest {
    private fun src(rel: String) = File("src/main/java/com/binario/treni/$rel").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$rel") }.readText()

    @Test fun widgetsRefreshEvenWhenTheAppIsClosed() {
        assertTrue(src("widget/Widgets.kt").contains("override fun onEnabled"))
        assertTrue(src("service/Services.kt").contains("Widgets.refreshStale(ctx, 10 * 60_000L)"))
        assertTrue(src("service/Services.kt").contains("Widgets.listenForUnlock(ctx)"))
    }

    @Test fun stationSearchShowsLocalMatchesAndHonestErrors() {
        val s = src("ui/Common.kt")
        assertTrue(s.contains("matchesQuery(q, it.name)"))
        assertTrue(s.contains("failure ?: tx(\"Nessuna stazione trovata\")"))
    }
}

class SavedAgeTest {
    @Test fun staleAfterTwelveHours() {
        val h = 3_600_000L
        assertTrue(com.binario.treni.data.SavedAge.isStale(13 * h, 0L + 1))
        assertFalse(com.binario.treni.data.SavedAge.isStale(5 * h, 1))
        assertFalse(com.binario.treni.data.SavedAge.isStale(100 * h, 0L))   // data sconosciuta: non si segnala
    }

    @Test fun keyAndTitleAreParsed() {
        assertEquals("S01700" to "S01645", com.binario.treni.data.SavedAge.parseKey("S01700>S01645@08 nov"))
        assertEquals(null, com.binario.treni.data.SavedAge.parseKey("rotto"))
        assertEquals("Milano Centrale" to "Varese", com.binario.treni.data.SavedAge.parseTitle("Milano Centrale → Varese · 08 nov 12:30"))
        assertEquals(null, com.binario.treni.data.SavedAge.parseTitle("senza freccia"))
    }

    @Test fun guideAndRefreshArePresent() {
        val r = File("src/main/java/com/binario/treni").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni") }
        assertTrue(File(r, "MainActivity.kt").readText().contains("FirstRunGuide(store)"))
        assertTrue(File(r, "ui/MainViewModel.kt").readText().contains("fun refreshSaved()"))
    }
}
