package com.binario.treni

import com.binario.treni.data.HttpStatusException
import com.binario.treni.data.OfflineException
import com.binario.treni.data.isNetwork
import com.binario.treni.data.messageOrUtente
import com.binario.treni.data.perUtente
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Migliorìa 1: l'utente vede una frase chiara, mai il testo tecnico dell'errore («HTTP 503», nomi di classi Java, indirizzi). */
class ErrorMessageTest {
    @Test fun noNetworkIsExplainedInPlainItalian() {
        listOf<Throwable>(OfflineException(), UnknownHostException("www.viaggiatreno.it"), java.net.ConnectException("refused")).forEach {
            assertEquals("Nessuna connessione. Controlla il Wi-Fi o i dati mobili.", it.perUtente())
        }
    }

    @Test fun serverProblemsHaveTheirOwnSentence() {
        assertEquals("Il servizio non risponde. Riprova tra poco.", SocketTimeoutException("timeout").perUtente())
        assertEquals("Il servizio ha un problema. Riprova più tardi.", HttpStatusException(503).perUtente())
        assertEquals("Il servizio ha un problema. Riprova più tardi.", IOException("HTTP 500").perUtente())
        assertEquals("Troppe richieste. Attendi un minuto e riprova.", HttpStatusException(429).perUtente())
        assertEquals("Non trovato: il servizio non ha questo dato.", HttpStatusException(404).perUtente())
    }

    @Test fun technicalTextNeverReachesTheUser() {
        listOf<Throwable>(HttpStatusException(503), UnknownHostException("host.example"), IllegalStateException("boom 42"), IOException("HTTP 418")).forEach {
            val s = it.perUtente()
            assertFalse(s, s.contains("HTTP"))
            assertFalse(s, s.contains("Exception"))
            assertFalse(s, s.contains("host.example"))
            assertFalse(s, s.contains("boom"))
        }
    }

    @Test fun ownMessagesAreKeptButNetworkOnesAreReplaced() {
        assertEquals("Stazione di cambio non trovata", IOException("Stazione di cambio non trovata").messageOrUtente())
        assertEquals("Nessuna connessione. Controlla il Wi-Fi o i dati mobili.", UnknownHostException("x").messageOrUtente())
        assertEquals("Qualcosa non ha funzionato. Riprova.", RuntimeException().messageOrUtente())
        assertTrue(HttpStatusException(500).isNetwork())
        assertFalse(IllegalStateException().isNetwork())
    }

    @Test fun screensDoNotPrintRawExceptionMessages() {
        val ui = listOf(java.io.File("src/main/java/com/binario/treni/ui"), java.io.File("app/src/main/java/com/binario/treni/ui")).first { it.isDirectory }
        val bad = listOf("MainViewModel.kt", "ResultsScreen.kt").flatMap { n ->
            java.io.File(ui, n).readLines().mapIndexedNotNull { i, l -> if (Regex("""error\s*=\s*(\S+\s*\?:\s*)?e\.message\b""").containsMatchIn(l) || l.contains("\"\\n(\$it)\"")) "$n:${i + 1}" else null }
        }
        assertTrue("Messaggi tecnici mostrati all'utente: $bad", bad.isEmpty())
    }
}
