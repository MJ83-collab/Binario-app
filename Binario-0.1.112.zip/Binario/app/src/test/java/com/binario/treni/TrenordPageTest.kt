package com.binario.treni

import com.binario.treni.data.TrenordPage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Pagine delle linee su trenord.it (anche TILO: S50 vista il 9/11/2026): stato, avvisi con PDF, stazioni e servizi. */
class TrenordPageTest {
    private fun src(p: String) =
        File("src/main/java/com/binario/treni/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$p") }.readText()

    private val s50Text = """
        Biasca - Bellinzona - Lugano - Varese - Malpensa
        La linea Transfrontaliera S50 Biasca-Bellinzona-Lugano-Varese-Malpensa fa parte della Direttrice 42.
        STATO DELLA LINEA
        Circolazione regolare
        AVVISI
        Ultimo aggiornamento: 28/10/2026 09:20
        28/10/2026 09:20
        Gentili Clienti, dal 2 novembre al 12 dicembre, per lavori di manutenzione programmata tra le stazioni di Malpensa Aeroporto e Saronno su rete FNM, i seguenti treni subiscono variazioni:
        a.mktgcdn.com/f/3714691/Ndig-XRUuTVZkCE2um2_6CdGguB-FB45ppQvz9ZPpco.pdf
        20/10/2026 10:00
        Seconda comunicazione di prova.
        Vedi avvisi precedenti
        STAZIONI SULLA LINEA
        Filtra per servizio:
        MALPENSA AEROPORTO T2
    """.trimIndent()

    private fun js(text: String) = org.json.JSONObject()
        .put("text", text)
        .put("stations", org.json.JSONArray()
            .put(org.json.JSONArray().put("MALPENSA AEROPORTO T2").put("https://www.trenord.it/linee-e-orari/circolazione/stazione/?mir-code=S01146&no_cache=1").put(true).put(true).put(true))
            .put(org.json.JSONArray().put("MALPENSA AEROPORTO T1").put("https://www.trenord.it/linee-e-orari/circolazione/stazione/?mir-code=S01139&no_cache=1").put(true).put(false).put(true))
            .put(org.json.JSONArray().put("MENDRISIO\n").put("https://www.trenord.it/linee-e-orari/circolazione/stazione/?mir-code=S13143&no_cache=1").put(false).put(false).put(true))
            .put(org.json.JSONArray().put("BIASCA").put("https://www.trenord.it/linee-e-orari/circolazione/stazione/?mir-code=S05209&no_cache=1").put(false).put(false).put(false))
            .put(org.json.JSONArray().put("BIASCA").put("https://www.trenord.it/linee-e-orari/circolazione/stazione/?mir-code=S05209&no_cache=1").put(false).put(false).put(false)))
        .put("docs", org.json.JSONArray()
            .put(org.json.JSONArray().put("a.mktgcdn.com/f/3714691/Ndig.pdf").put("https://a.mktgcdn.com/f/3714691/Ndig-XRUuTVZkCE2um2_6CdGguB-FB45ppQvz9ZPpco.pdf"))
            .put(org.json.JSONArray().put("x").put("http://insicuro.example/x.pdf")))
        .toString()

    @Test fun readsStatusNoticesDocsAndStations() {
        val l = TrenordPage.parseLine(js(s50Text))
        assertNotNull(l)
        l!!
        assertEquals("Circolazione regolare", l.page?.status?.title)
        assertEquals(2, l.notices.size)
        assertEquals("28/10/2026 09:20", l.notices[0].date)
        assertTrue(l.notices[0].body.startsWith("Gentili Clienti, dal 2 novembre"))
        assertFalse("il link scritto nel testo diventa un pulsante", l.notices[0].body.contains("mktgcdn"))
        assertEquals("Seconda comunicazione di prova.", l.notices[1].body)
        assertEquals(listOf("https://a.mktgcdn.com/f/3714691/Ndig-XRUuTVZkCE2um2_6CdGguB-FB45ppQvz9ZPpco.pdf"), l.docs.map { it.url })
        assertEquals(listOf("MALPENSA AEROPORTO T2", "MALPENSA AEROPORTO T1", "MENDRISIO", "BIASCA"), l.stations.map { it.name })
        val t1 = l.stations[1]
        assertEquals("S01139", t1.code)
        assertTrue(t1.ticketOffice && !t1.machines && t1.accessible)
        assertTrue(l.stations[3].let { !it.ticketOffice && !it.machines && !it.accessible })
    }

    @Test fun pageNotReadyYet() {
        assertNull(TrenordPage.parseLine("""{"text":"Caricamento…","stations":[],"docs":[]}"""))
        assertNull(TrenordPage.parseLine("non json"))
        // Stazioni senza stato (la sezione arriva dopo): si tengono
        assertNotNull(TrenordPage.parseLine(js("Caricamento…")))
    }

    @Test fun urlLines() {
        assertTrue(TrenordPage.isUrlLine("a.mktgcdn.com/f/3714691/Ndig-XRUu.pdf"))
        assertTrue(TrenordPage.isUrlLine("https://www.trenord.it/fileadmin/x.pdf"))
        assertFalse(TrenordPage.isUrlLine("i seguenti treni subiscono variazioni:"))
    }

    @Test fun stationPage() {
        val text = """
            MENDRISIO
            Indirizzo
            Piazza della Stazione, 6850 Mendrisio
            Calcola percorso
            Vedi street view
            Altri servizi
            Bar e ristoranti
            Deposito
            bagagli
            Ascensori
            Parcheggio
            biciclette
            Servizi igienici
            Sala d’attesa
            Servizi per
            l'accessibilità
            Scopri di più
            Linee
            S50
        """.trimIndent()
        val i = TrenordPage.parseStation(text)!!
        assertEquals("Piazza della Stazione, 6850 Mendrisio", i.address)
        assertEquals(
            listOf("Bar e ristoranti", "Deposito bagagli", "Ascensori", "Parcheggio biciclette", "Servizi igienici", "Sala d'attesa", "Servizi per l'accessibilità"),
            i.services,
        )
        assertNull(TrenordPage.parseStation("Caricamento…"))
    }

    @Test fun trenordPageForTiloLines() {
        val s50 = "https://www.trenord.it/linee-e-orari/circolazione/le-nostre-linee/biasca-bellinzona-lugano-varese-malpensa/?code=S50"
        val s40 = "https://www.trenord.it/linee-e-orari/circolazione/le-nostre-linee/como-mendrisio-varese/?code=S40"
        val saved = listOf("S40" to s40, "RE13" to "https://www.trenord.it/linee-e-orari/circolazione/le-nostre-linee/x/?code=RE_13")
        assertEquals(s40, TrenordPage.pageFor("S40", "https://www.tilo.ch/collegamenti/S40.html", saved))
        assertEquals("senza elenco salvato: la S50 è nota", s50, TrenordPage.pageFor("S50", "https://www.tilo.ch/collegamenti/S50.html", emptyList()))
        assertEquals("la pagina Trenord della linea resta quella", saved[1].second, TrenordPage.pageFor("RE13", saved[1].second, emptyList()))
        assertEquals(saved[1].second, TrenordPage.pageFor("RE_13", "", saved))
        assertNull(TrenordPage.pageFor("S20", "https://www.tilo.ch/collegamenti/S20.html", saved))
        assertNull(TrenordPage.pageFor("", "", saved))
    }

    @Test fun lineScreenShowsEverythingAndScrolls() {
        val ts = src("ui/TrainScreens.kt")
        assertTrue(ts.contains("com.binario.treni.data.TrenordPage.pageFor(line.name, line.url, saved)"))
        assertTrue(ts.contains("LineNoticeCard(trenordUrl, openWeb, \"\${line.name} \${line.route}\".trim(), showStations = true)"))
        // Le schede stanno nella lista che scorre, non sopra (la lista dei treni restava schiacciata)
        assertTrue(ts.contains("item(key = \"trenord\")"))
        val card = src("ui/LineNoticeCard.kt")
        assertTrue(card.contains("TrenordPage.LINE_JS"))
        assertTrue(card.contains("LineStationsCard(st)"))
        assertTrue(TrenordPage.LINE_JS.contains("img.'+c") && TrenordPage.LINE_JS.contains("mir-code="))
    }
}
