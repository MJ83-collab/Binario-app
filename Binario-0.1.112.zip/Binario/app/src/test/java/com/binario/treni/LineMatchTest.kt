package com.binario.treni

import com.binario.treni.data.LineMatch
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** «Treni davanti e dietro al tuo»: solo treni della stessa linea (segnalazione: stessa destinazione ma altra linea). Fermate di esempio inventate. */
class LineMatchTest {
    private val mine = listOf("B", "C", "D", "E", "F", "G", "MILANO")

    @Test fun sameStopsSameLine() = assertTrue(LineMatch.sameCorridor(mine, mine))

    @Test fun expressSkippingStopsIsStillSameCorridor() = assertTrue(LineMatch.sameCorridor(mine, listOf("B", "E", "G", "MILANO")))

    @Test fun shortTurnTrainIsSameCorridor() = assertTrue(LineMatch.sameCorridor(mine, listOf("B", "C", "D", "E")))

    @Test fun sameDestinationOnlyIsNotSameLine() {
        // Un'altra diramazione che si innesta sulla dorsale solo alla fine e arriva allo stesso capolinea
        assertFalse(LineMatch.sameCorridor(mine, listOf("X", "Y", "Z", "F", "G", "MILANO")))
        assertFalse(LineMatch.sameCorridor(mine, listOf("X", "MILANO")))
    }

    @Test fun oppositeOrderIsNotSameCorridor() = assertFalse(LineMatch.sameCorridor(mine, mine.reversed()))

    @Test fun emptyListsNeverMatch() {
        assertFalse(LineMatch.sameCorridor(emptyList(), mine))
        assertFalse(LineMatch.sameCorridor(mine, emptyList()))
    }

    @Test fun lineCodes() {
        assertTrue(LineMatch.sameLineCode("RE1", " re1 "))
        assertFalse(LineMatch.sameLineCode("RE1", "R31"))
        // Se la linea di uno dei due non è nota non si esclude il treno
        assertTrue(LineMatch.sameLineCode(null, "R31"))
        assertTrue(LineMatch.sameLineCode("RE1", ""))
    }
}

class LineMatchNamesTest {
    @Test fun sameStopWrittenInDifferentWays() {
        val a = LineMatch.norm("Milano Cadorna")
        assertTrue(a == LineMatch.norm("MILANO  CADORNA"))
        assertTrue(a == LineMatch.norm("Milano Cadorna (MI)"))
        assertTrue(LineMatch.norm("Sant'Ambrogio") == LineMatch.norm("SANT AMBROGIO"))
        assertTrue(LineMatch.norm("Vedano Olona") == LineMatch.norm("Vèdano Olona"))
        assertFalse(LineMatch.norm("Milano Centrale") == LineMatch.norm("Milano Cadorna"))
    }
}

class LineMatchFnNamesTest {
    @Test fun fnSuffixIsIgnored() {
        assertTrue(LineMatch.norm("Milano Cadorna FN") == LineMatch.norm("MILANO CADORNA"))
        assertTrue(LineMatch.norm("Varese Nord F.N.") == LineMatch.norm("Varese Nord"))
        assertTrue(LineMatch.norm("Saronno (VA)") == LineMatch.norm("SARONNO"))
        assertFalse(LineMatch.norm("Saronno Sud") == LineMatch.norm("Saronno"))
    }
}
