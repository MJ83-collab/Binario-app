package com.binario.treni

import com.binario.treni.data.Disruption
import com.binario.treni.data.Leg
import com.binario.treni.data.LineDisruption
import com.binario.treni.data.Solution
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.TrainStop
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Grado di disagio di una linea: treni critici (soppressi, limitati, oltre 15 minuti) sui treni partiti di recente. */
class LineDisruptionTest {
    private fun stop(name: String, delay: Int, passed: Boolean) =
        TrainStop(name, name, 1000L, 1000L, if (passed) 1100L else 0L, if (passed) 1100L else 0L, delay, "", false, false)

    /** [arrived]: anche l'ultima fermata è passata. */
    private fun train(n: String, delay: Int = 0, departed: Boolean = true, arrived: Boolean = false, lastDelay: Int = delay,
                      cancelled: Boolean = false, info: String = "") =
        TrainStatus(
            number = n, category = "R", origin = "Varese", destination = "Milano", originCode = "S01", date = 0L,
            delay = delay, lastStation = "", lastTime = 0L, cancelled = cancelled, info = info,
            stops = listOf(stop("Varese", delay, departed), stop("Saronno", delay, arrived), stop("Milano", lastDelay, arrived)),
        )

    @Test fun cancelledAndLimitedAreCritical() {
        assertEquals(Disruption.CANCELLED, LineDisruption.classify(train("1", departed = false, cancelled = true)))
        assertEquals(Disruption.LIMITED, LineDisruption.classify(train("2", info = "Treno limitato a Gallarate")))
        assertEquals(Disruption.LIMITED, LineDisruption.classify(train("3", info = "Il treno è parzialmente soppresso")))
        assertEquals(Disruption.LIMITED, LineDisruption.classify(train("4", info = "Treno soppresso da Saronno a Milano")))
        assertNull(LineDisruption.classify(train("5", info = "Treno in orario")))
    }

    @Test fun moreThan15MinutesIsLate() {
        assertEquals(Disruption.LATE, LineDisruption.classify(train("1", delay = 3, arrived = true, lastDelay = 16)))
        assertNull("15 minuti esatti non sono «oltre 15»", LineDisruption.classify(train("2", delay = 15, arrived = true, lastDelay = 15)))
        assertEquals("in viaggio conta il ritardo attuale", Disruption.LATE, LineDisruption.classify(train("3", delay = 20)))
        assertNull("non ancora partito: non conta", LineDisruption.classify(train("4", delay = 30, departed = false)))
    }

    @Test fun summaryIgnoresTrainsNotYetDeparted() {
        val s = LineDisruption.summarize(
            listOf(
                train("1"), train("2", delay = 22), train("3", departed = false, cancelled = true), train("4"),
                train("5", departed = false), // non partito: fuori dal conto
            ),
        )
        assertEquals(4, s.checked)
        assertEquals(1, s.cancelled)
        assertEquals(1, s.late)
        assertEquals(0, s.limited)
        assertEquals(2, s.critical)
        assertEquals(50, s.percent)
        assertEquals(0, LineDisruption.summarize(emptyList()).percent)
    }

    @Test fun onlyRecentDirectTrainsAreChecked() {
        val now = 10 * 3_600_000L
        fun sol(n: String, dep: Long, legs: Int = 1) =
            Solution("A", "B", dep, dep + 1, "", null, (1..legs).map { Leg(if (it == 1) n else "X$it", "R") })
        val list = listOf(
            sol("old", now - 4 * 3_600_000L), // troppo vecchio
            sol("future", now + 60_000L), // non ancora partito
            sol("change", now - 60_000L, legs = 2), // con cambio: non è un treno della linea
            sol("a", now - 30 * 60_000L), sol("b", now - 10 * 60_000L), sol("a", now - 20 * 60_000L),
        )
        assertEquals(listOf("b", "a"), LineDisruption.candidates(list, now))
        val many = (1..30).map { sol("t$it", now - it * 60_000L) }
        assertEquals(LineDisruption.MAX_TRAINS, LineDisruption.candidates(many, now).size)
    }

    @Test fun favouriteLineAlertOnlyWhenItGetsBad() {
        val h = 3_600_000L
        val bad = com.binario.treni.data.DisruptionSummary(checked = 10, cancelled = 2, limited = 0, late = 2) // 40%
        val ok = com.binario.treni.data.DisruptionSummary(checked = 10, cancelled = 1, limited = 0, late = 1) // 20%
        val few = com.binario.treni.data.DisruptionSummary(checked = 3, cancelled = 2, limited = 0, late = 0) // 67% ma su 3 treni
        assertTrue("prima volta oltre il 25%", LineDisruption.shouldAlert(bad, lastPercent = 10, lastAlertAt = 0L, now = 10 * h))
        assertTrue(!LineDisruption.shouldAlert(ok, lastPercent = 10, lastAlertAt = 0L, now = 10 * h))
        assertTrue("troppo pochi treni per dirlo", !LineDisruption.shouldAlert(few, lastPercent = 0, lastAlertAt = 0L, now = 10 * h))
        assertTrue("ancora alto, avvisato un'ora fa: niente", !LineDisruption.shouldAlert(bad, lastPercent = 40, lastAlertAt = 9 * h, now = 10 * h))
        assertTrue("ancora alto dopo 3 ore: si ricorda", LineDisruption.shouldAlert(bad, lastPercent = 40, lastAlertAt = 7 * h, now = 10 * h))
        assertTrue("25% esatto non basta", !LineDisruption.shouldAlert(
            com.binario.treni.data.DisruptionSummary(checked = 8, cancelled = 2, limited = 0, late = 0), lastPercent = 0, lastAlertAt = 0L, now = 10 * h))
    }

    @Test fun lineWatchRunsInBackgroundWithTheSameRules() {
        fun src(p: String) = File("src/main/java/com/binario/treni/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$p") }.readText()
        val w = src("service/LineWatch.kt")
        assertTrue(w.contains("if (!store.routeAlerts || (store.favLines().isEmpty() && store.favRoutes().isEmpty())) return"))
        assertTrue(w.contains("LineDisruption.targets(store.favLines(), store.favRoutes(), MAX_LINES)"))
        assertTrue(w.contains("const val MIN_GAP_MS = 30 * 60_000L"))
        assertTrue(w.contains("if (hour !in 6..21) return"))
        assertTrue(w.contains("withTimeoutOrNull(READ_TIMEOUT_MS)"))
        assertTrue(w.contains("if (list.size < 5) return"))
        assertTrue(src("service/Services.kt").contains("LineWatch.run(applicationContext)"))
        val lines = src("ui/LinesScreen.kt")
        assertTrue("la schermata usa la stessa notifica", lines.contains("com.binario.treni.service.LineWatch.alertChanges(ctx, trenord, sorted, favKeys)"))
        assertTrue(lines.contains("v.evaluateJavascript(TRENORD_LINES_JS)"))
        assertTrue("la scheda usa lo stesso calcolo", src("ui/LineDisruptionCard.kt").contains("LineDisruptionLoader.load(line)"))
    }

    @Test fun levelMatchesTheColours() {
        assertEquals(0, LineDisruption.level(0))
        assertEquals(0, LineDisruption.level(9))
        assertEquals(1, LineDisruption.level(10))
        assertEquals(1, LineDisruption.level(25))
        assertEquals(2, LineDisruption.level(26))
        val card = File("src/main/java/com/binario/treni/ui/LineDisruptionCard.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/LineDisruptionCard.kt") }.readText()
        assertTrue("livello anche a parole e per TalkBack", card.contains("contentDescription = \"${'$'}{s.percent}% · ${'$'}word · ${'$'}critical\""))
    }

    @Test fun favouriteLinesThenRoutesWithoutDuplicates() {
        fun st(id: String) = com.binario.treni.data.Station(id, id)
        val s5 = com.binario.treni.data.Linea("S5", st("S01205"), st("S01700"))
        val swiss = com.binario.treni.data.Linea("S10", st("CH8505300"), st("S01400"))
        val sameAsS5 = com.binario.treni.data.Tratta(st("S01700"), st("S01205")) // stessi capolinea, verso opposto
        val other = com.binario.treni.data.Tratta(st("S01205"), st("S01300"))
        val loop = com.binario.treni.data.Tratta(st("S01205"), st("S01205"))
        val t = LineDisruption.targets(listOf(s5, swiss), listOf(sameAsS5, other, loop), max = 3)
        assertEquals(2, t.size)
        assertEquals("S5", t[0].line.name)
        assertTrue(!t[0].isRoute && t[1].isRoute)
        assertEquals("S01300", t[1].line.b.id)
        assertEquals(1, LineDisruption.targets(listOf(s5), listOf(other), max = 1).size)
    }

    @Test fun notTodayLastsUntilItalianMidnight() {
        // 9/11/2026 10:12 in Italia → fino alla mezzanotte del 10/11 (ora italiana)
        assertEquals(1_794_265_200_000L, LineDisruption.endOfDay(1_794_215_520_000L))
        // 29/3/2026, giorno del cambio d'ora (23 ore): mezzanotte del 30/3 in ora legale
        assertEquals(1_774_821_600_000L, LineDisruption.endOfDay(1_774_774_800_000L))
        fun src(p: String) = File("src/main/java/com/binario/treni/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$p") }.readText()
        val w = src("service/LineWatch.kt")
        assertTrue(w.contains("if (now < p.getLong(k + \"_mute\", 0L)) continue"))
        assertTrue(w.contains("NotificationCompat.Action(0, tx(\"Non avvisare oggi\"), mute)"))
        assertTrue(w.contains("class DisruptionMuteReceiver : BroadcastReceiver()"))
        val manifest = File("src/main/AndroidManifest.xml").let { if (it.exists()) it else File("app/src/main/AndroidManifest.xml") }.readText()
        assertTrue(manifest.contains("<receiver android:name=\".service.DisruptionMuteReceiver\" android:exported=\"false\" />"))
    }

    @Test fun historyKeepsTheWorstOfEachDayForSevenDays() {
        var h: String? = null
        h = LineDisruption.historyAdd(h, "2026-11-09", 10)
        h = LineDisruption.historyAdd(h, "2026-11-09", 30) // più tardi è peggiorato
        h = LineDisruption.historyAdd(h, "2026-11-09", 20) // poi è migliorato: resta il peggiore
        assertEquals(listOf("2026-11-09" to 30), LineDisruption.historyDecode(h))
        for (d in 1..8) h = LineDisruption.historyAdd(h, "2026-11-0$d", d)
        val days = LineDisruption.historyDecode(h)
        assertEquals(LineDisruption.HISTORY_DAYS, days.size)
        assertEquals("dal più recente", "2026-11-09", days.first().first)
        assertEquals("2026-11-03", days.last().first)
        assertEquals(emptyList<Pair<String, Int>>(), LineDisruption.historyDecode("rotto,,x:1"))
        fun src(p: String) = File("src/main/java/com/binario/treni/$p").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/$p") }.readText()
        assertTrue(src("service/LineWatch.kt").contains("DisruptionHistory.record(ctx, line, s, now)"))
        assertTrue(src("ui/LineDisruptionCard.kt").contains("if (history.size >= 2) HistoryRow(history)"))
        assertTrue("nessun treno: non conta", src("data/DisruptionHistory.kt").contains("if (s.checked == 0) return"))
    }

    @Test fun lineScreenShowsTheCard() {
        val s = File("src/main/java/com/binario/treni/ui/TrainScreens.kt").let { if (it.exists()) it else File("app/src/main/java/com/binario/treni/ui/TrainScreens.kt") }.readText()
        assertTrue(s.contains("LineDisruptionCard(line"))
    }
}
