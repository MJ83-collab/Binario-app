package com.binario.treni

import com.binario.treni.data.EN
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Ogni testo passato a tx("…") nel codice deve avere la traduzione inglese (e quindi le altre lingue ripiegano sull'inglese). */
class TranslationCoverageTest {
    @Test fun everyTxLiteralIsInEnglishMap() {
        val root = listOf(File("src/main/java"), File("app/src/main/java")).firstOrNull { it.exists() } ?: return
        val skip = setOf("En.kt", "De.kt", "Fr.kt", "Es.kt", "Zh.kt", "Ja.kt")
        val re = Regex("""\btx\("((?:[^"\\$]|\\.)*)"\)""")
        val missing = root.walkTopDown().filter { it.isFile && it.extension == "kt" && it.name !in skip }.flatMap { f ->
            re.findAll(f.readText()).map { it.groupValues[1].replace("\\\"", "\"").replace("\\\\", "\\") }.filter { it !in EN }.map { f.name + ": " + it }
        }.toList()
        assertTrue("Testi senza traduzione:\n" + missing.joinToString("\n"), missing.isEmpty())
    }
}
