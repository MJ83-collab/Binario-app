package com.binario.treni

import com.binario.treni.data.Api
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.TrainStop
import org.junit.Assert.assertEquals
import org.junit.Test

/** Treno arrivato con 12 minuti di ritardo ma ritardo del treno a 0: non deve dire «in orario» (caso 10060 Varese Nord). */
class ArrivedDelayTest {
    private val min = 60_000L
    private fun stop(id: String, sa: Long, ra: Long) =
        TrainStop("S$id", id, sa, 0L, ra, 0L, 0, "", false, false)

    private fun train(delay: Int, realArr: Long, cancelled: Boolean = false) = TrainStatus(
        "10060", "REG", "A", "B", "S01738", 0L, delay, "", 0L, cancelled,
        listOf(stop("1", 0L, 0L), stop("2", 1_000 * min, realArr)),
    )

    @Test fun delayTakenFromArrival() {
        assertEquals(12, Api.fixArrivedDelay(train(0, 1_000 * min + 12 * min)).delay)
    }

    @Test fun onTimeStaysZero() {
        assertEquals(0, Api.fixArrivedDelay(train(0, 1_000 * min)).delay)
    }

    @Test fun declaredDelayIsKept() {
        assertEquals(5, Api.fixArrivedDelay(train(5, 1_000 * min + 12 * min)).delay)
    }

    @Test fun cancelledIsUntouched() {
        assertEquals(0, Api.fixArrivedDelay(train(0, 1_000 * min + 12 * min, cancelled = true)).delay)
    }
}
