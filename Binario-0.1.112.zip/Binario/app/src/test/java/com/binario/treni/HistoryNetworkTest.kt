package com.binario.treni

import com.binario.treni.data.BinarioHistory
import org.junit.Assert.assertEquals
import org.junit.Test

/** Trenord e TILO sono un unico servizio: nello storico stanno nello stesso gruppo, con la rete (RFI, FerrovieNord, Svizzera) a parte. */
class HistoryNetworkTest {
    @Test fun trenordAndTiloShareOneGroup() {
        for (s in listOf("Trenord", "Trenord-RFI", "Trenord-FN", "FN", "TILO-CH", "TILO-RFI", "TILO-FN")) {
            assertEquals(s, BinarioHistory.Net.TRENORD, BinarioHistory.netOf(s))
        }
    }

    @Test fun otherSourcesStaySeparate() {
        assertEquals(BinarioHistory.Net.CH, BinarioHistory.netOf("FFS"))
        assertEquals(BinarioHistory.Net.RFI, BinarioHistory.netOf("RFI"))
        assertEquals(BinarioHistory.Net.RFI, BinarioHistory.netOf(""))
    }

    @Test fun networkIsReadFromTheSource() {
        assertEquals("FerrovieNord", BinarioHistory.networkOf("Trenord-FN"))
        assertEquals("FerrovieNord", BinarioHistory.networkOf("FN"))
        assertEquals("FerrovieNord", BinarioHistory.networkOf("TILO-FN"))
        assertEquals("RFI", BinarioHistory.networkOf("TILO-RFI"))
        assertEquals("Svizzera", BinarioHistory.networkOf("TILO-CH"))
        assertEquals("", BinarioHistory.networkOf("Trenord"))
    }
}
