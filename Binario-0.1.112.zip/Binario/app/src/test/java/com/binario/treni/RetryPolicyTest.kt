package com.binario.treni

import com.binario.treni.data.HttpStatusException
import com.binario.treni.data.OfflineException
import com.binario.treni.data.RetryPolicy
import java.io.IOException
import java.net.SocketTimeoutException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Migliorìa 5: tentativi con attesa crescente; 429 e 5xx si riprovano, gli altri 4xx e l'assenza di rete no. */
class RetryPolicyTest {
    @Test fun waitsGrow() {
        val e = IOException("x")
        assertEquals(700L, RetryPolicy.waitMs(e, 0))
        assertEquals(1400L, RetryPolicy.waitMs(e, 1))
        assertEquals(2800L, RetryPolicy.waitMs(e, 2))
        assertEquals(750L, RetryPolicy.waitMs(e, 0, jitter = 50))
    }

    @Test fun serverBusyIsRetriedClientErrorsAreNot() {
        assertTrue(RetryPolicy.shouldRetry(HttpStatusException(503), 0))
        assertTrue(RetryPolicy.shouldRetry(HttpStatusException(429), 0))
        assertTrue(RetryPolicy.shouldRetry(HttpStatusException(408), 1))
        assertFalse(RetryPolicy.shouldRetry(HttpStatusException(404), 0))
        assertFalse(RetryPolicy.shouldRetry(HttpStatusException(403), 0))
        assertFalse(RetryPolicy.shouldRetry(OfflineException(), 0))
    }

    @Test fun neverMoreThanThreeAttempts() {
        assertTrue(RetryPolicy.shouldRetry(HttpStatusException(500), 1))
        assertFalse(RetryPolicy.shouldRetry(HttpStatusException(500), 2))
    }

    @Test fun timeoutIsRetriedOnlyOnce() {
        assertTrue(RetryPolicy.shouldRetry(SocketTimeoutException(), 0))
        assertFalse(RetryPolicy.shouldRetry(SocketTimeoutException(), 1))
    }

    @Test fun retryAfterIsRespectedAndCapped() {
        assertEquals(3000L, RetryPolicy.waitMs(HttpStatusException(429, 3000L), 0))
        assertEquals(10_000L, RetryPolicy.waitMs(HttpStatusException(503, 120_000L), 0))
        assertEquals(5000L, RetryPolicy.parseRetryAfter(" 5 "))
        assertEquals(0L, RetryPolicy.parseRetryAfter("Wed, 21 Oct 2026 07:28:00 GMT"))
        assertEquals(0L, RetryPolicy.parseRetryAfter(null))
        assertEquals(0L, RetryPolicy.parseRetryAfter("99999"))
    }

    @Test fun statusMessageKeepsTheOldFormat() {
        assertEquals("HTTP 503", HttpStatusException(503).message)
    }

    @Test fun withRetryGivesUpAfterTheLastAttemptAndKeepsTheError() {
        var calls = 0
        val r = try { com.binario.treni.data.Http.withRetry<String> { calls++; throw HttpStatusException(404) } } catch (e: HttpStatusException) { e.code }
        assertEquals(404, r)
        assertEquals("un 404 non si ripete", 1, calls)
    }
}
