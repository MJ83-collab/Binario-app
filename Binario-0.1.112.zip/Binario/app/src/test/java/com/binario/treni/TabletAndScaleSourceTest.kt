package com.binario.treni

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Tablet con menu laterale e schermate che reggono testo ingrandito (controlli sui sorgenti: niente altezze fisse sulle righe di testo). */
class TabletAndScaleSourceTest {
    private fun f(rel: String) = File("src/main/$rel").let { if (it.exists()) it else File("app/src/main/$rel") }.readText()
    private val main get() = f("java/com/binario/treni/MainActivity.kt")

    @Test fun tabletUsesSideRailAndPhoneKeepsBottomBar() {
        val m = main
        assertTrue(m.contains("if (!tablet) NavigationBar("))
        assertTrue(m.contains("if (tablet) NavigationRail("))
        assertTrue(m.contains("NavigationRailItem("))
    }

    @Test fun railAndBarShareTheSameTabsAndNavigation() {
        val m = main
        val rail = m.substring(m.indexOf("NavigationRail("), m.indexOf("// Colonna centrale"))
        assertTrue(rail.contains("AppTab.entries.forEach"))
        assertTrue("Il menu laterale deve usare goTab, come la barra in basso", rail.contains("goTab(nav, tab.route)"))
    }

    @Test fun braceBalanceOfMainActivity() {
        val m = main
        assertTrue(m.count { it == '{' } == m.count { it == '}' })
    }

    @Test fun screenChromeAvoidsFixedHeightsOnText() {
        // Le intestazioni e le schede non devono avere altezze fisse in dp che tagliano il testo ingrandito
        for (n in listOf("ui/SearchScreen.kt", "ui/TrainScreens.kt", "ui/NextTrainCard.kt")) {
            val s = f("java/com/binario/treni/$n")
            assertFalse("$n: Text dentro un Box con height() fisso", Regex("""Text\([^)]*\)[^\n]*\.height\(\d+\.dp\)""").containsMatchIn(s))
        }
    }
}
