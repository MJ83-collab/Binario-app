package com.binario.treni

import com.binario.treni.data.LineMatch
import com.binario.treni.data.TrenordGtfs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Il treno 10060 esiste due volte il 5/11/2026: Mortara – Milano Rogoredo (RFI, S00034) e Varese Nord – Milano Cadorna (FerrovieNord, S01738).
 * Trenord li elenca insieme sotto lo stesso numero: l'app mostrava Mortara anche aprendo Varese Nord. Fermate prese dalle risposte reali di ViaggiaTreno.
 */
class SameNumberDifferentNetworkTest {
    private fun stops(vararg p: Pair<String, String>) = p.map { it.first to LineMatch.norm(it.second) }

    private val mortara = stops(
        "S00034" to "MORTARA", "S01060" to "PARONA LOMELLINA", "S01061" to "VIGEVANO", "S01062" to "ABBIATEGRASSO", "S01059" to "ALBAIRATE-VERMEZZO",
        "S01630" to "MILANO S.CRISTOFORO", "S01032" to "MILANO ROMOLO", "S01022" to "MILANO TIBALDI UNIVERSITA' BOCCONI",
        "S01632" to "MILANO SCALO ROMANA", "S01820" to "MILANO ROGOREDO",
    )
    private val varese = stops(
        "S01738" to "VARESE NORD", "S01737" to "MALNATE", "S01736" to "VEDANO OLONA", "S01735" to "VENEGONO SUPERIORE - CASTIGLIONE OLONA",
        "S01734" to "VENEGONO INFERIORE", "S01729" to "TRADATE", "S01728" to "ABBIATE GUAZZONE", "S01727" to "LOCATE VARESINO - CARBONATE",
        "S01726" to "MOZZATE", "S01725" to "CISLAGO", "S01724" to "GERENZANO - TURATE", "S01933" to "SARONNO", "S01642" to "MILANO BOVISA POLITECNICO",
        "S01067" to "MILANO DOMODOSSOLA", "S01066" to "MILANO CADORNA",
    )

    @Test fun trenordJourneyIsTheOneOfTheOpenedTrain() {
        // La risposta di Trenord elenca prima Mortara e poi Varese Nord
        assertEquals(1, LineMatch.bestOverlap(varese, listOf(mortara, varese)))
        assertEquals(0, LineMatch.bestOverlap(mortara, listOf(mortara, varese)))
    }

    @Test fun noJourneyIsBetterThanTheWrongOne() {
        // Se Trenord ha solo la corsa di Mortara, per Varese Nord non si usa nessun dato live
        assertEquals(-1, LineMatch.bestOverlap(varese, listOf(mortara)))
    }

    @Test fun viaggiaTrenoSeeingOnlyPartOfTheRunStillMatches() {
        // ViaggiaTreno elenca solo alcune fermate della corsa FerrovieNord: sono comunque tutte nella corsa Trenord
        val vtPart = varese.filterIndexed { i, _ -> i % 3 == 0 }
        assertEquals(1, LineMatch.bestOverlap(vtPart, listOf(mortara, varese)))
    }

    @Test fun nameWrittenDifferentlyStillMatches() {
        val trenordNames = stops("" to "Varese Nord FN", "" to "Malnate", "" to "Vedano Olona", "" to "Saronno", "" to "Milano Cadorna FN")
        // «FN» finale e maiuscole non devono impedire l'abbinamento (le fonti scrivono i nomi in modi diversi)
        val vt = stops("S01738" to "VARESE NORD", "S01737" to "MALNATE", "S01736" to "VEDANO OLONA", "S01933" to "SARONNO", "S01066" to "MILANO CADORNA")
        assertTrue(LineMatch.stopOverlap(vt, trenordNames) >= 0.5)
    }

    @Test fun neighboursOfTheVareseTrainAreNotMortaraTrains() {
        val mineAfterMalnate = varese.drop(2).map { it.second }
        assertTrue(LineMatch.sameCorridor(mineAfterMalnate, varese.drop(2).map { it.second }))
        assertFalse(LineMatch.sameCorridor(mineAfterMalnate, mortara.drop(2).map { it.second }))
    }

    private fun run(number: String, firstId: String, vararg ids: String, midnight: Long = 1L) =
        TrenordGtfs.RunTrip(number, "R", midnight, listOf(firstId, *ids).map { TrenordGtfs.RunStop(it, it, 0.0, 0.0, 0L, 0L) })

    @Test fun timetableRunIsChosenByOrigin() {
        val a = run("10060", "S00034", "S01820")
        val b = run("10060", "S01738", "S01066")
        assertEquals("S01738", TrenordGtfs.choose(listOf(a, b), 1L, "S01738")!!.stops.first().id)
        assertEquals("S00034", TrenordGtfs.choose(listOf(a, b), 1L, "S00034")!!.stops.first().id)
    }

    @Test fun ambiguousNumberWithUnknownOriginGivesNothingInsteadOfAGuess() {
        val a = run("10060", "S00034", "S01820")
        val b = run("10060", "S01738", "S01066")
        assertNull(TrenordGtfs.choose(listOf(a, b), 1L, "S09999"))
        // Origine non indicata: comportamento di sempre
        assertNotNull(TrenordGtfs.choose(listOf(a, b), 1L, ""))
        // Una sola corsa con quel numero: si usa anche se l'origine è scritta in modo diverso
        assertNotNull(TrenordGtfs.choose(listOf(a), 1L, "S09999"))
    }
}
