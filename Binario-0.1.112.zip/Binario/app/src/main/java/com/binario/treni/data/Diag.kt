package com.binario.treni.data

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * Ultimi errori di rete, tenuti solo in memoria. Si allegano al Feedback insieme ai dati tecnici (a scelta di chi scrive).
 * Si salvano solo l'indirizzo senza parametri e il tipo di errore: nessun dato personale.
 */
object Diag {
    const val MAX = 10
    private val items = ArrayDeque<String>()

    /** Indirizzo senza parametri né frammenti (possono contenere nomi o chiavi). */
    fun clean(url: String): String {
        val noQuery = url.substringBefore('?').substringBefore('#')
        return noQuery.take(120)
    }

    fun what(e: Throwable): String = when (e) {
        is HttpStatusException -> "HTTP ${e.code}"
        is OfflineException -> "offline"
        else -> e.javaClass.simpleName.ifBlank { "errore" }
    }

    fun line(time: Long, url: String, e: Throwable): String =
        SimpleDateFormat("dd/MM HH:mm", Locale.ITALY).format(Date(time)) + " · " + clean(url) + " · " + what(e)

    @Synchronized fun record(url: String, e: Throwable, now: Long = System.currentTimeMillis()) {
        // L'assenza di rete non è un guasto dei servizi: non riempie il registro
        if (e is OfflineException) return
        items.addLast(line(now, url, e))
        while (items.size > MAX) items.removeFirst()
    }

    @Synchronized fun count(): Int = items.size

    @Synchronized fun clear() = items.clear()

    /** Testo da accodare ai dati tecnici; vuoto se non ci sono errori. */
    @Synchronized fun block(): String =
        if (items.isEmpty()) "" else "\nErrori di rete recenti:\n" + items.joinToString("\n")
}
