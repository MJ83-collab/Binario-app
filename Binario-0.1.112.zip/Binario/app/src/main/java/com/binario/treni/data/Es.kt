package com.binario.treni.data

/**
 * Traduzione spagnola dell'interfaccia (generata dalle chiavi inglesi di De.kt). Le chiavi sono i testi inglesi
 * (EN e tr(it, en)); PAIRS risolve le iniziali dei giorni. I testi senza traduzione restano in inglese.
 * Divisa in più funzioni per non superare i limiti del bytecode.
 */
object Es {
    private const val SEP = "\u0001"
    private val PAIRS: Map<String, String> = mapOf(
        "L" + SEP + "M" to "L",
        "M" + SEP + "T" to "M",
        "M" + SEP + "W" to "X",
        "G" + SEP + "T" to "J",
        "V" + SEP + "F" to "V",
        "S" + SEP + "S" to "S",
        "D" + SEP + "S" to "D",
        "Banconote" + SEP + "Notes" to "Billetes",
    )

    private val TEMPLATES: List<Pair<String, String>> = listOf(
        "No out-of-service elevators or escalators reported at {0} (FerrovieNord/RFI). The station screen lists lifts per platform." to "No se han señalado ascensores ni escaleras mecánicas fuera de servicio en {0} (FerrovieNord/RFI). La pantalla de la estación muestra los ascensores por andén.",
        "Binario · scheduled times from Trenitalia/LeFrecce, generated on {0}. Check delays and changes before travelling." to "Binario · horarios programados de Trenitalia/LeFrecce, generados el {0}. Comprueba retrasos y cambios antes de viajar.",
        "I can't find train {0} today. Check the number (it's on your ticket or the board) or search by station." to "Hoy no encuentro el tren {0}. Comprueba el número (está en tu billete o en el panel) o busca por estación.",
        "Band estimated from distance (about {0} km): check at the ticket office or in the Trenord app" to "Tramo estimado por la distancia (unos {0} km): compruébalo en la taquilla o en la app de Trenord",
        "By car it would take about {0} minutes less each way, but you couldn't use the travel time." to "En coche tardarías unos {0} minutos menos por trayecto, pero no podrías aprovechar el tiempo de viaje.",
        "By train you save about {0} minutes each way at rush hour (and you can read or work)." to "En tren ahorras unos {0} minutos por trayecto en hora punta (y puedes leer o trabajar).",
        "Stops from {0} to the terminus · official Swiss timetable (transport.opendata.ch)" to "Paradas de {0} a la estación final · horario oficial suizo (transport.opendata.ch)",
        "Which station do you leave from? Say for example \"from Varese to {0}\"." to "¿De qué estación sales? Di por ejemplo \"de Varese a {0}\".",
        "I can't find bus, metro, tram or taxi stops mapped within 400 m of {0}." to "No encuentro paradas de autobús, metro, tranvía o taxi en el mapa a menos de 400 m de {0}.",
        "You board at {0}. Where do you get off? I'll warn you before the stop." to "Subes en {0}. ¿Dónde bajas? Te avisaré antes de la parada.",
        "You have already sent {0} messages today: try again tomorrow. Thanks!" to "Hoy ya has enviado {0} mensajes: vuelve a intentarlo mañana. ¡Gracias!",
        "No connection: timetable downloaded at {0} on {1}. Delays not updated." to "Sin conexión: horario descargado a las {0} del {1}. Retrasos no actualizados.",
        "Platform change at {0}: train {1} now uses platform {2} instead of {3}." to "Cambio de vía en {0}: el tren {1} sale ahora de la vía {2} en lugar de la {3}.",
        "The nearest station is {0} ({1}). Here are the next departures:" to "La estación más cercana es {0} ({1}). Estas son las próximas salidas:",
        "In about {0} minutes you arrive at {1}. Start getting ready." to "Dentro de unos {0} minutos llegas a {1}. Prepárate.",
        "You are already following {0}. Here is how it's going:" to "Ya estás siguiendo {0}. Así va:",
        "The {0} board isn't responding. Try again shortly." to "El panel de {0} no responde. Inténtalo de nuevo en un momento.",
        "Platform change: leaves from {0} instead of {1}." to "Cambio de vía: sale de la {0} en lugar de la {1}.",
        "Transitous · official {0} timetable (GTFS)" to "Transitous · horario oficial de {0} (GTFS)",
        "I see no departures from {0} at that time." to "No veo salidas desde {0} a esa hora.",
        "Transport data not reachable now for {0}." to "Datos de transporte no disponibles ahora para {0}.",
        "≈ the CO₂ absorbed in a year by {0} trees" to "≈ el CO₂ que absorben en un año {0} árboles",
        "{0} is not installed: choose another app" to "{0} no está instalada: elige otra app",
        "Expected delay: {0} minutes, leaves at " to "Retraso previsto: {0} minutos, sale a las ",
        "I found {0} trains: which one is yours?" to "He encontrado {0} trenes: ¿cuál es el tuyo?",
        ", and shortly before {0} with the alarm" to ", y poco antes de {0} con la alarma",
        "Departure: {0} — now choose the arrival" to "Salida: {0} — ahora elige la llegada",
        "Message too long (max {0} characters)." to "Mensaje demasiado largo (máx. {0} caracteres).",
        "No connections found from {0} to {1}." to "No se han encontrado conexiones de {0} a {1}.",
        "Great, I'm following {0} for you. " to "Perfecto, sigo {0} por ti. ",
        "No disruptions reported for: {0}." to "No hay incidencias señaladas para: {0}.",
        "Warning: train {0} is cancelled." to "Atención: el tren {0} está cancelado.",
        "Train {0} is now {1} minutes late." to "El tren {0} lleva ahora {1} minutos de retraso.",
        "I can't find train {0} today." to "Hoy no encuentro el tren {0}.",
        "Board not available for {0}." to "Panel no disponible para {0}.",
        " I will warn you before {0}." to " Te avisaré antes de {0}.",
        "Does this train stop at {0}?" to "¿Este tren para en {0}?",
        "So far in {0} ({1} days logged)" to "Hasta ahora en {0} ({1} días registrados)",
        "What time do you leave {0}?" to "¿A qué hora sales de {0}?",
        "In a year ({0} travel days)" to "En un año ({0} días de viaje)",
        "Italo real-time data ({0})" to "Datos en tiempo real de Italo ({0})",
        "You get off at {0} around " to "Bajas en {0} hacia las ",
        ", expected delay {0} min." to ", retraso previsto {0} min.",
        "Out of service at {0}:\n" to "Fuera de servicio en {0}:\n",
        "Platform confirmed: {0}." to "Vía confirmada: {0}.",
        "Data from {0} (offline)" to "Datos del {0} (sin conexión)",
        "Running {0} min early." to "Va {0} min adelantado.",
        "Running {0} min late." to "Va {0} min retrasado.",
        "Next trains {0} → {1}:\n" to "Próximos trenes {0} → {1}:\n",
        "Board at {0}: due at {1}" to "Sube en {0}: previsto a las {1}",
        "Departures from {0}:" to "Salidas desde {0}:",
        "Departs from {0} at {1}" to "Sale de {0} a las {1}",
        "Outbound: {0} runs…" to "Ida: {0} trenes…",
        ", {0} minutes late." to ", {0} minutos de retraso.",
        "Train {0} not found" to "Tren {0} no encontrado",
        " (contactless {0})" to " (contactless {0})",
        " from platform {0}" to " desde la vía {0}",
        "Return: {0} runs…" to "Vuelta: {0} trenes…",
        "{0} minutes late." to "{0} minutos de retraso.",
        "Alarm set for {0}" to "Alarma fijada a las {0}",
        "Services at {0}:" to "Servicios en {0}:",
        "Departs from {0}" to "Sale de {0}",
        "Arrivals at {0}:" to "Llegadas a {0}:",
        "Board at {0} at {1}" to "Sube en {0} a las {1}",
        "Days logged: {0}" to "Días registrados: {0}",
        " {0} min late." to " {0} min de retraso.",
        "Arrived at {0}" to "Llegado a {0}",
        ", platform {0}" to ", vía {0}",
        "Next stop: {0}" to "Próxima parada: {0}",
        "{0} min early" to "{0} min de adelanto",
        "Next stop {0}" to "Próxima parada {0}",
        "{0} o'clock, {1}" to "Las {0}, {1}",
        "{0} min late" to "{0} min de retraso",
        "Near {0}:" to "Cerca de {0}:",
        ", at {0}." to ", a las {0}.",
        "Train {0}" to "Tren {0}",
        " at {0}" to " a las {0}",
    )
    private val compiled: List<Pair<Regex, String>> by lazy {
        TEMPLATES.map { (en, tr) ->
            val parts = en.split(Regex("\\{\\d\\}"))
            Regex("^" + parts.joinToString("(.+?)") { Regex.escape(it) } + "$", RegexOption.DOT_MATCHES_ALL) to tr
        }
    }
    private val cache = java.util.Collections.synchronizedMap(object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 300
    })

    private fun fromTemplate(en: String): String? {
        cache[en]?.let { return it.ifEmpty { null } }
        for ((re, tr) in compiled) {
            val m = re.matchEntire(en) ?: continue
            var z = tr
            for (g in 1 until m.groupValues.size) z = z.replace("{${g - 1}}", m.groupValues[g])
            cache[en] = z
            return z
        }
        cache[en] = ""
        return null
    }

    /** Testo tradotto per la coppia italiano/inglese; se manca, l'inglese. */
    fun of(it: String, en: String): String = PAIRS[it + SEP + en] ?: MAP[en] ?: (if (en.length in 4..400) fromTemplate(en) else null) ?: en

    fun has(en: String) = MAP.containsKey(en)

    private val MAP: HashMap<String, String> by lazy { HashMap<String, String>(2400).also { m -> p0(m); p1(m); p2(m); p3(m); p4(m); p5(m); p6(m); p7(m); p8(m); p9(m); p10(m); p11(m); p12(m); p13(m); p14(m) } }

    private fun p0(m: HashMap<String, String>) {
        m["Price with a change: check sbb.ch or Trainline"] = "Precio con transbordo: compruébalo en sbb.ch o Trainline"
        m["SBB fare (single ticket, adult)"] = "Tarifa SBB (billete sencillo, adulto)"
        m["Read on sbb.ch on"] = "Leído en sbb.ch el"
        m["Open on sbb.ch"] = "Abrir en sbb.ch"
        m["2nd class"] = "2.ª clase"
        m["Where there is no 1st class (e.g. many regional trains) the 2nd class price is shown."] = "Donde no hay 1.ª clase (p. ej. muchos regionales) se muestra el precio de 2.ª."
        m["App updates"] = "Actualizaciones de la app"
        m["Only strikes on my route"] = "Solo huelgas en mi trayecto"
        m["at my times"] = "en mis horarios"
        m["change it in News › My route and times"] = "se cambia en Noticias › Mi trayecto y horarios"
        m["No route chosen: set your route in News › My route and times. Meanwhile you get national strikes and those in your region."] = "Ningún trayecto elegido: configura tu trayecto en Noticias › Mi trayecto y horarios. Mientras tanto recibes las huelgas nacionales y las de tu región."
        m["1st and 2nd class"] = "1.ª y 2.ª clase"
        m["Accessible to people with disabilities or reduced mobility"] = "Accesible para personas con discapacidad o movilidad reducida"
        m["Add shortcut"] = "Añadir acceso rápido"
        m["Replacement buses"] = "Autobuses sustitutivos"
        m["Defibrillators"] = "Desfibriladores"
        m["Remove shortcut"] = "Eliminar acceso rápido"
        m["Remove the shortcut?"] = "¿Eliminar el acceso rápido?"
        m["Done"] = "Hecho"
        m["The official app to call 112 sending your exact location."] = "La app oficial para llamar al 112 enviando tu ubicación exacta."
        m["No shortcuts: tap + to add the features you use most."] = "Sin accesos rápidos: toca + para añadir las funciones que más usas."
        m["This route"] = "Este trayecto"
        m["This shortcut already exists"] = "Este acceso rápido ya existe"
        m["AREU Lombardy website"] = "Web de AREU Lombardía"
        m["2nd class only"] = "Solo 2.ª clase"
        m["A station's departure board"] = "El panel de salidas de una estación"
        m["Shortcuts"] = "Accesos rápidos"
        m["Tap the shortcut to remove."] = "Toca el acceso rápido que quieres eliminar."
        m["Bikes allowed"] = "Se admiten bicicletas"
        m["A specific train (by number)"] = "Un tren concreto (por número)"
        m["Do you really want to remove it? You can add it again with +."] = "¿Seguro que quieres eliminarlo? Podrás añadirlo de nuevo con +."
        m["Station toilets"] = "Aseos de la estación"
        m["not available"] = "no disponible"
        m["1st class"] = "1.ª clase"
        m[" early"] = " de adelanto"
        m[" late"] = " de retraso"
        m[" · contactless"] = " · contactless"
        m["1 hour before"] = "1 hora antes"
        m["Cross-border passes"] = "Abonos transfronterizos"
        m["Accessibility"] = "Accesibilidad"
        m["Buy"] = "Comprar"
        m["Now"] = "Ahora"
        m["Crowding"] = "Ocupación"
        m["Refresh"] = "Actualizar"
        m["Add"] = "Añadir"
        m["Add a line, e.g. S5 Varese – Treviglio, to see the next trains in both directions."] = "Añade una línea, p. ej. S5 Varese – Treviglio, para ver los próximos trenes en ambos sentidos."
        m["Help & FAQ"] = "Ayuda y preguntas frecuentes"
        m["Alarm when the train leaves the previous stop"] = "Alarma cuando el tren sale de la parada anterior"
        m["Alarms"] = "Alarmas"
        m["NTV high speed"] = "Alta velocidad NTV"
        m["More"] = "Más"
        m["Outbound"] = "Ida"
        m["Round trip"] = "Ida y vuelta"
        m["Cancel"] = "Cancelar"
        m["Open in browser"] = "Abrir en el navegador"
        m["Open keyboard when choosing a station"] = "Abrir el teclado al elegir estación"
        m["Open a departure board and tap ★ to save the station."] = "Abre un panel de salidas y toca ★ para guardar la estación."
        m["Open a train and tap ★ to add it here."] = "Abre un tren y toca ★ para añadirlo aquí."
        m["Arcobaleno (Swiss section) + Trenord (Lombardy section): check the price when buying"] = "Arcobaleno (tramo suizo) + Trenord (tramo lombardo): comprueba el precio al comprar"
        m["Trenitalia personal area"] = "Área personal de Trenitalia"
        m["Arrived on time"] = "Llegado puntual"
        m["Arrivals"] = "Llegadas"
        m["Arrivals at "] = "Llegadas a "
        m["Arrival"] = "Llegada"
        m["Out-of-service elevators and escalators"] = "Ascensores y escaleras mecánicas fuera de servicio"
        m["Assistance"] = "Asistencia"
        m["Notify me"] = "Avísame"
        m["Notify me 10 minutes before arriving here"] = "Avísame 10 minutos antes de llegar aquí"
        m["Notices"] = "Avisos"
        m["Disruption alerts on favourite routes, lines and trains"] = "Avisos de incidencias en trayectos, líneas y trenes favoritos"
        m["Alerts for deaf or hard-of-hearing people"] = "Avisos para personas sordas o con discapacidad auditiva"
        m["Backup saved"] = "Copia de seguridad guardada"
        m["Bikes and light mobility"] = "Bicicletas y movilidad ligera"
        m["Ticket offices, machines, validators, contactless"] = "Taquillas, máquinas expendedoras, validadoras, contactless"
        m["Tickets"] = "Billetes"
        m["Tickets, passes and QR codes"] = "Billetes, abonos y códigos QR"
        m["Ticket"] = "Billete"
        m["Regional ticket"] = "Billete regional"
        m["Cross-border ticket"] = "Billete transfronterizo"
        m["Platforms: elevators and ramps"] = "Andenes: ascensores y rampas"
        m["Platform"] = "Vía"
        m["Calendar"] = "Calendario"
        m["Strike calendar (Ministry)"] = "Calendario de huelgas (Ministerio)"
        m["Change a Trenitalia booking"] = "Cambiar una reserva de Trenitalia"
        m["Terminus A"] = "Extremo A"
        m["Terminus A (e.g. Varese)"] = "Extremo A (p. ej. Varese)"
        m["Terminus B"] = "Extremo B"
        m["Terminus B (e.g. Treviglio)"] = "Extremo B (p. ej. Treviglio)"
        m["Loading station list (first time only)…"] = "Cargando la lista de estaciones (solo la primera vez)…"
        m["Loading…"] = "Cargando…"
        m["Search"] = "Buscar"
        m["Search timetable"] = "Buscar horario"
        m["Search & Buy"] = "Buscar y comprar"
        m["Search a station"] = "Buscar una estación"
        m["Search a station for the departure board"] = "Busca una estación para ver su panel"
        m["Search within 2 km"] = "Buscar en 2 km"
        m["Close"] = "Cerrar"
        m["Traffic"] = "Circulación"
        m["Connection very much at risk"] = "Transbordo muy en riesgo"
        m["Tight connection"] = "Transbordo ajustado"
        m["How it works"] = "Cómo funciona"
        m["Same as system"] = "Igual que el sistema"
        m["Operator announcements"] = "Comunicados de las compañías"
        m["With delays of at least 60 minutes you are entitled to assistance: meals and refreshments in relation to the waiting time and, if needed, accommodation."] = "Con retrasos de al menos 60 minutos tienes derecho a asistencia: comidas y refrescos según el tiempo de espera y, si hace falta, alojamiento."
        m["Share"] = "Compartir"
        m["Share timetable"] = "Compartir horario"
        m["Malpensa Express conditions"] = "Condiciones del Malpensa Express"
        m["Trenitalia conditions"] = "Condiciones de Trenitalia"
        m["Trenord conditions"] = "Condiciones de Trenord"
        m["Conditions of carriage"] = "Condiciones de transporte"
        m["Conditions of carriage and rights"] = "Condiciones de transporte y derechos"
        m["Conditions of carriage, tickets, bikes, pets, fines"] = "Condiciones de transporte, billetes, bicicletas, animales, multas"
        m["General conditions of carriage (regional and long distance)"] = "Condiciones generales de transporte (regional y larga distancia)"
        m["Specific conditions for the airport link"] = "Condiciones específicas del enlace con el aeropuerto"
        m["Compare"] = "Comparar"
        m["Compare routes"] = "Comparar itinerarios"
        m["Contacts"] = "Contactos"
        m["Always check the updated document before travelling."] = "Consulta siempre el documento actualizado antes de viajar."
        m["Station coordinates not available"] = "Coordenadas de la estación no disponibles"
        m["Stop coordinates not available"] = "Coordenadas de la parada no disponibles"
        m["From mobiles +39 02 32 32 32 · 6:45–21:30"] = "Desde móviles +39 02 32 32 32 · 6:45–21:30"
        m["Data imported"] = "Datos importados"
        m["Direct"] = "Directo"
        m["Rail passengers' rights and obligations (PDF)"] = "Derechos y obligaciones de los viajeros de ferrocarril (PDF)"
        m["Disable maps"] = "Desactivar mapas"
        m["Official documents"] = "Documentos oficiales"
        m["After a search, tap the download icon to save the timetable."] = "Tras una búsqueda, toca el icono de descarga para guardar el horario."
        m["During regional rail strikes, trains are normally guaranteed between 6:00–9:00 and 18:00–21:00, "] = "Durante las huelgas del transporte ferroviario regional, normalmente se garantizan los trenes entre las 6:00–9:00 y las 18:00–21:00, "
        m["Updated official lists"] = "Listas oficiales actualizadas"
        m["List"] = "Lista"
        m["Full FerrovieNord list"] = "Lista completa de FerrovieNord"
        m["Station list not available"] = "Lista de estaciones no disponible"
        m["Delete"] = "Eliminar"
        m["Ticket machines, validators, tobacconists, contactless payment"] = "Máquinas expendedoras, validadoras, estancos, pago contactless"
        m["Network error"] = "Error de red"
        m["Error while saving"] = "Error al guardar"
        m["e.g. Varese → Como via Mendrisio or via Milan"] = "p. ej. Varese → Como por Mendrisio o por Milán"
        m["e.g. Varese → Como: via Mendrisio (TILO) or via Milan. Duration, changes, cost and feasibility."] = "p. ej. Varese → Como: por Mendrisio (TILO) o por Milán. Duración, transbordos, coste y viabilidad."
        m["Exclude categories"] = "Excluir categorías"
        m["Export data"] = "Exportar datos"
        m["Feasible"] = "Viable"
        m["Invalid file"] = "Archivo no válido"
        m["Source: OpenStreetMap. Tobacconists and newsagents often sell regional tickets, but not always: "] = "Fuente: OpenStreetMap. Los estancos y quioscos suelen vender billetes regionales, pero no siempre: "
        m["Frecce, Intercity and Regional"] = "Frecce, Intercity y Regionales"
        m["General"] = "General"
        m["My tickets"] = "Mis billetes"
        m["My Italo trips"] = "Mis viajes Italo"
        m["On-board services (bikes, wheelchair spaces, classes) are not published in real-time data. "] = "Los servicios a bordo (bicicletas, plazas para silla de ruedas, clases) no se publican en los datos en tiempo real. "
        m["Your rights in brief (EU 2021/782)"] = "Tus derechos en resumen (UE 2021/782)"
        m["The price via Milan is the Trenitalia/Trenord fare; the cross-border price is indicative: check at the ticket office or in the Trenord/SBB app."] = "El precio por Milán es la tarifa Trenitalia/Trenord; el precio transfronterizo es orientativo: compruébalo en la taquilla o en la app de Trenord/SBB."
        m["Import data"] = "Importar datos"
        m["Unable to load train data"] = "No se pueden cargar los datos del tren"
        m["Settings"] = "Ajustes"
        m["Set"] = "Configurar"
        m["On time"] = "Puntual"
        m["Delay compensation: 25% of the ticket price for 60–119 minutes, 50% from 120 minutes. Operators may not pay amounts below €4."] = "Indemnización por retraso: 25 % del precio del billete con 60–119 minutos, 50 % a partir de 120 minutos. Las compañías pueden no pagar importes inferiores a 4 €."
        m["Back"] = "Atrás"
        m["Info"] = "Info"
        m["RFI accessibility info"] = "Info de accesibilidad RFI"
        m["Customer information and lost property"] = "Información al cliente y objetos perdidos"
        m["Information and bookings (replies on weekdays)"] = "Información y reservas (responden en días laborables)"
        m["Swap"] = "Invertir"
        m["Italo · assistance"] = "Italo · asistencia"
        m["Italo · news"] = "Italo · noticias"
        m["Purchases are made on the operator's official website: in-app purchase and synchronisation "] = "Las compras se realizan en la web oficial de la compañía: la compra en la app y la sincronización "
        m["Delay compensation may not be due in cases of force majeure (e.g. extreme weather, natural disasters, major public health crises)."] = "La indemnización por retraso puede no corresponder en casos de fuerza mayor (p. ej. fenómenos meteorológicos extremos, catástrofes naturales, graves crisis sanitarias)."
        m["Flash blinking for alerts"] = "Destello del flash para los avisos"
        m["Works"] = "Obras"
        m["National and regional conditions may set different rules for passes and regional trains."] = "Las condiciones nacionales y regionales pueden fijar normas distintas para abonos y trenes regionales."
        m["Legal"] = "Legal"
        m["Lines"] = "Líneas"
        m["Favourite lines"] = "Líneas favoritas"
        m["Lines, cross-border fares, services"] = "Líneas, tarifas transfronterizas, servicios"
        m["Map"] = "Mapa"
        m["FerrovieNord maintenance map"] = "Mapa de mantenimiento de FerrovieNord"
        m["Max changes"] = "Máx. transbordos"
        m["Monthly and annual"] = "Mensuales y anuales"
        m["Change date, time or class"] = "Cambiar fecha, hora o clase"
        m["Show Buy button"] = "Mostrar el botón Comprar"
        m["Show later connections"] = "Mostrar conexiones posteriores"
        m["Later connections"] = "Conexiones posteriores"
        m["No elevators mapped for this station."] = "No hay ascensores en el mapa para esta estación."
        m["No notices"] = "Sin avisos"
        m["No browser available"] = "No hay ningún navegador disponible"
        m["No list published at the moment."] = "No hay ninguna lista publicada en este momento."
        m["No routes found for this time. Try later or another day (some lines do not run on Sundays)."] = "No se han encontrado itinerarios para esta hora. Prueba más tarde u otro día (algunas líneas no circulan los domingos)."
        m["No direct trains found in this direction"] = "No se han encontrado trenes directos en esta dirección"
        m["No trains in the next hours"] = "No hay trenes en las próximas horas"
        m["No traffic disruptions reported"] = "No hay incidencias de circulación señaladas"
        m["No calendar app found"] = "No se ha encontrado ninguna app de calendario"
        m["No email app"] = "No hay ninguna app de correo"
        m["No notifications. Use \"Notify me\" on a train or a connection."] = "Sin notificaciones. Usa \"Avísame\" en un tren o en una conexión."
        m["No connections"] = "Sin conexiones"
        m["No station found"] = "No se ha encontrado ninguna estación"
        m["No rail strikes announced"] = "No hay huelgas ferroviarias convocadas"
        m["Nothing to save"] = "Nada que guardar"
        m["Not departed yet"] = "Aún no ha salido"
        m["Not available at this time"] = "No disponible en este momento"
        m["Persistent notification on"] = "Notificación fija activa"
        m["Persistent notification enabled"] = "Notificación fija activada"
        m["Scheduled notification"] = "Notificación programada"
        m["Strike notifications"] = "Notificaciones de huelgas"
        m["Notifications"] = "Notificaciones"
        m["Scheduled notifications"] = "Notificaciones programadas"
        m["Scheduled notifications and wake-up alarms"] = "Notificaciones programadas y alarmas de parada"
        m["News"] = "Noticias"
        m["Name (e.g. S5, RE2)"] = "Nombre (p. ej. S5, RE2)"
        m["New favourite line"] = "Nueva línea favorita"
        m["Train number"] = "Número de tren"
        m["Station name"] = "Nombre de la estación"
        m["Advanced options"] = "Opciones avanzadas"
        m["Times and changes: official Swiss timetable (transport.opendata.ch) and Trenitalia/LeFrecce. "] = "Horarios y transbordos: horario oficial suizo (transport.opendata.ch) y Trenitalia/LeFrecce. "
        m["Offline timetables"] = "Horarios sin conexión"
        m["Timetable saved for offline use"] = "Horario guardado para usar sin conexión"
        m["Time already passed"] = "Hora ya pasada"
        m["Strike observatory unreachable right now"] = "Observatorio de huelgas no disponible en este momento"
        m["Official pages"] = "Páginas oficiales"
        m["Departure"] = "Salida"
        m["Origin and destination are the same"] = "Origen y destino coinciden"
        m["Departures"] = "Salidas"
        m["Departures from "] = "Salidas desde "
        m["Departures and arrivals from here"] = "Salidas y llegadas desde aquí"
        m["Step-free routes, 55 cm platforms"] = "Itinerarios sin escalones, andenes de 55 cm"
        m["People with disabilities or reduced mobility: free assistance in stations and on board, normally to be requested at least 24 hours in advance."] = "Personas con discapacidad o movilidad reducida: asistencia gratuita en estaciones y a bordo, normalmente a solicitar con al menos 24 horas de antelación."
        m["Arcobaleno zone map"] = "Mapa de zonas Arcobaleno"
        m["Several runs with this number"] = "Varios trenes con este número"
        m["Location & Maps"] = "Ubicación y mapas"
        m["Location not available. Turn on GPS and try again."] = "Ubicación no disponible. Activa el GPS y vuelve a intentarlo."
        m["Location not available: open the map first or turn on GPS."] = "Ubicación no disponible: abre primero el mapa o activa el GPS."
        m["Favourite"] = "Favorito"
        m["Favourites"] = "Favoritos"
        m["Trenitalia/Trenord fare"] = "Tarifa Trenitalia/Trenord"
        m["Trenitalia/Trenord fare (1 adult)"] = "Tarifa Trenitalia/Trenord (1 adulto)"
        m["Before arrival"] = "Antes de la llegada"
        m["Before departure"] = "Antes de la salida"
        m["Privacy & permissions"] = "Privacidad y permisos"
        m["You can check them in the operator's official timetable."] = "Puedes consultarlos en el horario oficial de la compañía."
        m["Recent"] = "Recientes"
        m["Recent & favourites"] = "Recientes y favoritos"
        m["Complaints: the operator must reply within one month (up to three months in justified cases)."] = "Reclamaciones: la compañía debe responder en un mes (hasta tres meses en casos justificados)."
        m["Lombardy regional trains and Malpensa Express"] = "Trenes regionales de Lombardía y Malpensa Express"
        m["Finding your location…"] = "Buscando tu ubicación…"
        m["Refunds and complaints"] = "Reembolsos y reclamaciones"
        m["Remove"] = "Quitar"
        m["Expected arrival delay of at least 60 minutes: you can choose a refund, continuation, or re-routing."] = "Retraso previsto en la llegada de al menos 60 minutos: puedes elegir reembolso, continuación del viaje o un itinerario alternativo."
        m["Return"] = "Vuelta"
        m["Ticket sellers"] = "Puntos de venta"
        m["Nearby ticket sellers and offices"] = "Puntos de venta y taquillas cercanos"
        m["Nearby ticket sellers"] = "Puntos de venta cercanos"
        m["Save"] = "Guardar"
        m["Save offline"] = "Guardar sin conexión"
        m["Saved offline"] = "Guardado sin conexión"
        m["Choose the run"] = "Elige el tren"
        m["Choose origin and destination"] = "Elige origen y destino"
        m["Choose departure and arrival stations"] = "Elige las estaciones de salida y llegada"
        m["Start screen"] = "Pantalla de inicio"
        m["Strikes"] = "Huelgas"
        m["Strikes, traffic and works"] = "Huelgas, circulación y obras"
        m["Dark"] = "Oscuro"
        m["If the operator offers no alternative within 100 minutes, you may arrange it yourself with other trains or buses and claim reasonable costs."] = "Si la compañía no ofrece una alternativa en 100 minutos, puedes organizarla tú con otros trenes o autobuses y pedir el reembolso de los gastos razonables."
        m["Report problems between train and station"] = "Señalar problemas entre tren y estación"
        m["Follow"] = "Seguir"
        m["Following"] = "Siguiendo"
        m["Location permission needed"] = "Se necesita el permiso de ubicación"
        m["Location permission is needed to find nearby stations."] = "Se necesita el permiso de ubicación para encontrar las estaciones cercanas."
        m["Grant permission"] = "Conceder permiso"
        m["TILO services"] = "Servicios TILO"
        m["Services & accessibility"] = "Servicios y accesibilidad"
        m["Station services"] = "Servicios de la estación"
        m["Map service temporarily unreachable"] = "Servicio de mapas temporalmente no disponible"
        m["TILO Pigiama night service"] = "Servicio nocturno TILO Pigiama"
        m["Summary for information only: the official text of the regulation and each operator's conditions prevails. "] = "Resumen solo informativo: prevalecen el texto oficial del reglamento y las condiciones de cada compañía. "
        m["Connections"] = "Conexiones"
        m["Cancelled"] = "Cancelado"
        m["Station"] = "Estación"
        m["Arrival station"] = "Estación de llegada"
        m["Departure station"] = "Estación de salida"
        m["Stations"] = "Estaciones"
        m["Favourite stations"] = "Estaciones favoritas"
        m["Nearby stations"] = "Estaciones cercanas"
        m["Nearby stations and map"] = "Estaciones cercanas y mapa"
        m["Wake me before this stop"] = "Despiértame antes de esta parada"
        m["TILO · Ticino and Lombardy"] = "TILO · Tesino y Lombardía"
        m["TILO · notices"] = "TILO · avisos"
        m["Full fare tables"] = "Tablas de tarifas completas"
        m["Departure board not available"] = "Panel de salidas no disponible"
        m["Station board"] = "Panel de la estación"
        m["Lombardy regional fare: check the price"] = "Tarifa regional de Lombardía: comprueba el precio"
        m["Official Arcobaleno fare"] = "Tarifa oficial Arcobaleno"
        m["Cross-border fares"] = "Tarifas transfronterizas"
        m["Theme"] = "Tema"
        m["Leisure"] = "Ocio"
        m["Type of connections"] = "Tipo de conexiones"
        m["Tickets and passes"] = "Billetes y abonos"
        m["Tickets, bikes, assistance"] = "Billetes, bicicletas, asistencia"
        m["Tap again for the departure board"] = "Toca de nuevo para ver el panel"
        m["Tap to open"] = "Toca para abrir"
        m["Tap a category to exclude it (struck through) or include it."] = "Toca una categoría para excluirla (tachada) o incluirla."
        m["Tap a stop for the board or the alarm."] = "Toca una parada para ver el panel o poner la alarma."
        m["Traffic, delays and strikes"] = "Circulación, retrasos y huelgas"
    }

    private fun p1(m: HashMap<String, String>) {
        m["Route"] = "Trayecto"
        m["Favourite and recent routes"] = "Trayectos favoritos y recientes"
        m["Trains"] = "Trenes"
        m["Guaranteed trains"] = "Trenes garantizados"
        m["Guaranteed trains during strikes"] = "Trenes garantizados durante las huelgas"
        m["Guaranteed trains: updated official lists"] = "Trenes garantizados: listas oficiales actualizadas"
        m["Favourite trains"] = "Trenes favoritos"
        m["Trenitalia · refunds and compensation"] = "Trenitalia · reembolsos e indemnizaciones"
        m["Trenitalia · guaranteed trains"] = "Trenitalia · trenes garantizados"
        m["Trenitalia · travel information"] = "Trenitalia · información de viaje"
        m["Trenord · real-time traffic"] = "Trenord · circulación en tiempo real"
        m["Train"] = "Tren"
        m["Train not found"] = "Tren no encontrado"
        m["Followed train"] = "Tren seguido"
        m["Train cancelled"] = "Tren cancelado"
        m["Trenord · notices"] = "Trenord · avisos"
        m["Trenord · notices and strikes"] = "Trenord · avisos y huelgas"
        m["Trenord · refunds and compensation"] = "Trenord · reembolsos e indemnizaciones"
        m["Trenord: assistance for people with disabilities"] = "Trenord: asistencia para personas con discapacidad"
        m["All"] = "Todo"
        m["Every day 8:15–19:45 · book at least 24 hours ahead"] = "Todos los días 8:15–19:45 · reserva con al menos 24 horas de antelación"
        m["Use your location"] = "Usar tu ubicación"
        m["Light green"] = "Verde claro"
        m["App version"] = "Versión de la app"
        m["Via Mendrisio (TILO, cross-border)"] = "Por Mendrisio (TILO, transfronterizo)"
        m["Via Milan (Italy only)"] = "Por Milán (solo Italia)"
        m["Travellers with disabilities"] = "Viajeros con discapacidad"
        m["Strong vibration with a different pattern per alert: stop alarm (3 long, repeated), reminder (3 short ×2), disruptions (2 long)"] = "Vibración fuerte con un patrón distinto para cada aviso: alarma de parada (3 largas, repetidas), recordatorio (3 cortas ×2), incidencias (2 largas)"
        m["Favourites widget"] = "Widget de favoritos"
        m["Station widget"] = "Widget de estación"
        m["Route / Line widget"] = "Widget de trayecto / línea"
        m["Train widget"] = "Widget de tren"
        m["Arcobaleno zones"] = "Zonas Arcobaleno"
        m["from "] = "desde "
        m["of tickets require a commercial agreement with Trenitalia, Italo and Trenord."] = "de billetes requieren un acuerdo comercial con Trenitalia, Italo y Trenord."
        m["no changes (direct only)"] = "sin transbordos (solo directos)"
        m["no data"] = "sin datos"
        m["not wheelchair accessible"] = "no accesible en silla de ruedas"
        m["not set"] = "sin configurar"
        m["plus the trains listed by the operators. For long-distance trains, each operator's published lists apply. "] = "además de los trenes indicados por las compañías. Para los trenes de larga distancia valen las listas publicadas por cada compañía. "
        m["direct only"] = "solo directos"
        m["check on site. Contactless payment is shown only if mapped."] = "compruébalo en el lugar. El pago contactless solo se muestra si está en el mapa."
        m["♿ accessible"] = "♿ accesible"
        m["♿ limited access"] = "♿ acceso limitado"
        m["💳 cards"] = "💳 tarjetas"
        m["📶 contactless"] = "📶 contactless"
        m["🛗 elevator"] = "🛗 ascensor"
        m["RFI accessibility page"] = "Página de accesibilidad de RFI"
        m["No out-of-service facilities reported for this station."] = "No se han señalado instalaciones fuera de servicio en esta estación."
        m["Checking FerrovieNord and RFI…"] = "Consultando FerrovieNord y RFI…"
        m["OpenStreetMap data unreachable."] = "Datos de OpenStreetMap no disponibles."
        m["Source: OpenStreetMap (volunteer data, may be incomplete). Does not show today's faults."] = "Fuente: OpenStreetMap (datos de voluntarios, pueden estar incompletos). No muestra las averías de hoy."
        m["FerrovieNord: station and elevator notices"] = "FerrovieNord: avisos de estaciones y ascensores"
        m["Varese, Como, Novara, Brescia–Iseo–Edolo lines"] = "Líneas Varese, Como, Novara, Brescia–Iseo–Edolo"
        m["RFI Sala Blu assistance"] = "Asistencia Sala Blu de RFI"
        m["Book help getting on and off"] = "Reserva ayuda para subir y bajar"
        m["Wheelchair access"] = "Acceso en silla de ruedas"
        m["Open official timetable"] = "Abrir el horario oficial"
        m["Sala Blu assistance (people with disabilities)"] = "Asistencia Sala Blu (personas con discapacidad)"
        m["Not available for this train."] = "No disponible para este tren."
        m["Check on the Trenord website"] = "Compruébalo en la web de Trenord"
        m["Estimate provided by Trenord"] = "Estimación proporcionada por Trenord"
        m["Open announcement"] = "Abrir el comunicado"
        m["Source: Strike Observatory – Italian Ministry of Transport"] = "Fuente: Observatorio de huelgas – Ministerio de Transportes italiano"
        m["Strikes and travel info"] = "Huelgas e información de viaje"
        m["No news"] = "Sin noticias"
        m["I took the train today"] = "Hoy he tomado el tren"
        m["Latest news"] = "Últimas noticias"
        m["Strike calendar"] = "Calendario de huelgas"
        m["Official list of the Ministry of Transport"] = "Lista oficial del Ministerio de Transportes"
        m["Trenitalia travel info"] = "Información de viaje de Trenitalia"
        m["Real-time traffic"] = "Circulación en tiempo real"
        m["Choose what to show"] = "Elige qué mostrar"
        m["Real delays and platforms"] = "Retrasos y vías reales"
        m["Best connections"] = "Mejores conexiones"
        m["High speed"] = "Alta velocidad"
        m["Regional"] = "Regionales"
        m["All connections"] = "Todas las conexiones"
        m["Ticket office"] = "Taquilla"
        m["Self-service ticket machine"] = "Máquina expendedora"
        m["Validator"] = "Validadora"
        m["Authorised reseller"] = "Revendedor autorizado"
        m["Elevator"] = "Ascensor"
        m["Ramp"] = "Rampa"
        m["Strike"] = "Huelga"
        m["Works and changes"] = "Obras y cambios"
        m["Notice"] = "Aviso"
        m["How green are you"] = "Cuánto de verde eres"
        m["Train assistant"] = "Asistente de trenes"
        m["How much CO₂, fuel, tolls and time you save"] = "Cuánto CO₂, combustible, peajes y tiempo ahorras"
        m["Ask about trains, delays, strikes and traffic"] = "Pregunta sobre trenes, retrasos, huelgas y circulación"
        m["Language"] = "Idioma"
        m["Legal notes"] = "Notas legales"
        m["Colour-blind colours"] = "Colores para daltónicos"
        m["Off"] = "Desactivado"
        m["Red-green (protanopia, deuteranopia)"] = "Rojo-verde (protanopía, deuteranopía)"
        m["Blue-yellow (tritanopia)"] = "Azul-amarillo (tritanopía)"
        m["version"] = "versión"
        m["Version"] = "Versión"
        m["Before you start"] = "Antes de empezar"
        m["Read the full legal notes"] = "Leer las notas legales completas"
        m["I understand and accept"] = "Lo entiendo y acepto"
        m["Binario is an independent app, not affiliated with Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO or SBB. Data comes from public sources and may contain errors: station boards, announcements and official channels always prevail. Estimated crowding, costs and times are indicative. All sources are public, free and cited in the legal notes. The app is free, ad-free, does not sell tickets and does not collect personal data."] = "Binario es una app independiente, no vinculada a Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO ni SBB. Los datos proceden de fuentes públicas y pueden contener errores: siempre prevalecen los paneles de las estaciones, los anuncios y los canales oficiales. La ocupación, los costes y los tiempos estimados son orientativos. Todas las fuentes son públicas, gratuitas y se citan en las notas legales. La app es gratuita, sin publicidad, no vende billetes y no recoge datos personales."
        m["App created by Marco Jannino"] = "App creada por Marco Jannino"
        m["Punctuality"] = "Puntualidad"
        m["Monthly statistics by operator, station and train"] = "Estadísticas mensuales por compañía, estación y tren"
        m["of seats taken"] = "de plazas ocupadas"
        m["Source"] = "Fuente"
        m["No official data: estimate by time of day (weekday rush hours, trains to/from Milan)."] = "Sin datos oficiales: estimación por franja horaria (horas punta de días laborables, trenes desde/hacia Milán)."
        m["Green: plenty of seats · Yellow: look for seats · Red: full, better wait for the next train"] = "Verde: muchas plazas · Amarillo: busca bien las plazas · Rojo: lleno, mejor esperar al siguiente tren"
        m["Real-time crowding in the Trenord app"] = "Ocupación en tiempo real en la app de Trenord"
        m["Scheduled"] = "Previsto"
        m["Actual"] = "Real"
        m["Scheduled platform"] = "Vía prevista"
        m["Actual platform"] = "Vía real"
        m["Switzerland"] = "Suiza"
        m["All lines"] = "Todas las líneas"
        m["Extracting the line list from the Trenord website…"] = "Extrayendo la lista de líneas de la web de Trenord…"
        m["Trenord list not available right now."] = "Lista de Trenord no disponible en este momento."
        m["Open lines on the Trenord website"] = "Abrir las líneas en la web de Trenord"
        m["FerrovieNord manages the infrastructure: trains on these lines are run by Trenord."] = "FerrovieNord gestiona la infraestructura: los trenes de estas líneas los opera Trenord."
        m["Line added to favourites"] = "Línea añadida a favoritos"
        m["Choose the two termini"] = "Elige los dos extremos"
        m["SBB rail traffic information"] = "Información sobre el tráfico ferroviario de SBB"
        m["Real-time disruption map"] = "Mapa de incidencias en tiempo real"
        m["TILO notices"] = "Avisos TILO"
        m["TILO cross-border lines"] = "Líneas transfronterizas TILO"
        m["Line status, notices and stations"] = "Estado de la línea, avisos y estaciones"
        m["Official page"] = "Página oficial"
        m["Trenord, TILO, FerrovieNord, Switzerland"] = "Trenord, TILO, FerrovieNord, Suiza"
        m["Refresh now"] = "Actualizar ahora"
        m["Updated at"] = "Actualizado a las"
        m["refreshes every 5 minutes"] = "se actualiza cada 5 minutos"
        m["Official websites"] = "Webs oficiales"
        m["Trenitalia · travel news"] = "Trenitalia · noticias de viaje"
        m["Open source"] = "Abrir la fuente"
        m["no date"] = "sin fecha"
        m["The full text is on the source website."] = "El texto completo está en la web de la fuente."
        m["Hours"] = "Horario"
        m["Who"] = "Quién"
        m["Where"] = "Dónde"
        m["Sector"] = "Sector"
        m["Unions"] = "Sindicatos"
        m["Notes"] = "Notas"
        m["Station overview"] = "Resumen de la estación"
        m["Platforms"] = "Vías"
        m["Platforms in use"] = "Vías en uso"
        m["from today's trains"] = "según los trenes de hoy"
        m["not mapped"] = "no está en el mapa"
        m["Lifts"] = "Ascensores"
        m["none mapped"] = "ninguno en el mapa"
        m["escalators"] = "escaleras mecánicas"
        m["ramps"] = "rampas"
        m["none / not mapped"] = "ninguno / no está en el mapa"
        m["present"] = "presente"
        m["Ticket machines"] = "Máquinas expendedoras"
        m["Validators"] = "Validadoras"
        m["none within 500 m"] = "ninguna a menos de 500 m"
        m["nearest at"] = "la más cercana a"
        m["Toilets"] = "Aseos"
        m["available"] = "disponible"
        m["wheelchair accessible station"] = "estación accesible en silla de ruedas"
        m["limited access"] = "acceso limitado"
        m["Lifts per platform"] = "Ascensores por vía"
        m["no lift mapped"] = "ningún ascensor en el mapa"
        m["ramp"] = "rampa"
        m["Loading station services…"] = "Cargando los servicios de la estación…"
        m["Retry"] = "Reintentar"
        m["OpenStreetMap data unreachable right now."] = "Datos de OpenStreetMap no disponibles en este momento."
        m["OpenStreetMap volunteer data: may be incomplete. Today's faults are in the box below."] = "Datos de voluntarios de OpenStreetMap: pueden estar incompletos. Las averías de hoy están en el recuadro de abajo."
        m["Italo · info and support"] = "Italo · información y asistencia"
        m["Your position"] = "Tu posición"
        m["Voice assistant (microphone on at start)"] = "Asistente de voz (micrófono activo al abrir)"
        m["Followed train: alert on platform change or bigger delay"] = "Tren seguido: avisar si cambia la vía o aumenta el retraso"
        m["Voice alerts for blind or visually impaired people"] = "Avisos de voz para personas ciegas o con baja visión"
        m["The phone's voice tells you where to catch the train (platform), when it leaves, platform changes and delays, and warns you with an insistent sound when your stop is near."] = "La voz del teléfono te dice dónde tomar el tren (vía), cuándo sale, los cambios de vía y los retrasos, y te avisa con un sonido insistente cuando se acerca tu parada."
        m["Voice alerts on. I will tell you the platform, the departure and the stop where to get off."] = "Avisos de voz activados. Te diré la vía, la salida y la parada en la que bajar."
        m["Announce every stop of the followed train"] = "Anunciar cada parada del tren seguido"
        m["Voice speed"] = "Velocidad de la voz"
        m["Slow"] = "Lenta"
        m["Normal"] = "Normal"
        m["Fast"] = "Rápida"
        m["Voice test."] = "Prueba de voz."
        m["Try the sounds: each one has a different meaning."] = "Prueba los sonidos: cada uno tiene un significado distinto."
        m["Stop coming up"] = "Parada próxima"
        m["Problem"] = "Problema"
        m["To ask by voice: long-press the Binario icon and choose “Ask by voice” (you can drag it to the Home screen), or add the “Binario · Ask by voice” tile to Quick Settings. With your phone's assistant say “Open Binario”. Works with TalkBack too."] = "Para preguntar por voz: mantén pulsado el icono de Binario y elige «Preguntar por voz» (puedes arrastrarlo a la pantalla de inicio), o añade el mosaico «Binario · Preguntar por voz» a los Ajustes rápidos. Con el asistente del teléfono di «Abrir Binario». Funciona también con TalkBack."
        m["Connection at risk: the previous train is"] = "Transbordo en riesgo: el tren anterior va con"
        m["min late"] = "min de retraso"
        m["Short change"] = "Transbordo corto"
        m["Change"] = "Transbordo"
        m["at"] = "a las"
        m["planned"] = "previsto"
        m["Delay compensation"] = "Indemnización por retraso"
        m["Delay over 2 hours: you can claim 50% of the ticket price."] = "Retraso de más de 2 horas: puedes pedir el 50 % del precio del billete."
        m["Delay over 1 hour: you can claim 25% of the ticket price."] = "Retraso de más de 1 hora: puedes pedir el 25 % del precio del billete."
        m["Frecce 30–59 minutes late: Trenitalia grants compensation. Check the conditions on its website."] = "Frecce con 30–59 minutos de retraso: Trenitalia concede una indemnización. Consulta las condiciones en su web."
        m["The delay at your arrival station counts; season tickets have their own rules. Source: EU Regulation 2021/782 and operators' conditions."] = "Cuenta el retraso en tu estación de llegada; los abonos tienen sus propias normas. Fuente: Reglamento UE 2021/782 y condiciones de las compañías."
        m["Claim from Italo"] = "Reclamar a Italo"
        m["Claim from Trenitalia"] = "Reclamar a Trenitalia"
        m["Trenord refunds"] = "Reembolsos de Trenord"
        m["Trenitalia Regional compensation"] = "Indemnización de Trenitalia Regional"
        m["I board here"] = "Subo aquí"
        m["Platform, time and alerts for this stop (also by voice)"] = "Vía, hora y avisos para esta parada (también por voz)"
        m["I will alert you for boarding at"] = "Te avisaré para subir en"
        m["Only upcoming stop"] = "Solo la parada próxima"
        m["All: platform, departure, changes, delays, stops"] = "Todo: vía, salida, cambios, retrasos, paradas"
        m["I will alert you by voice only when your stop is coming up."] = "Te avisaré por voz solo cuando se acerque tu parada."
        m["Do you want to turn this feature on?"] = "¿Quieres activar esta función?"
        m["Strong vibration with a different pattern for each alert (stop alarm, reminders, disruptions) and flashlight blinking. You can change it any time in Settings → Accessibility."] = "Vibración fuerte con un patrón distinto para cada aviso (alarma de parada, recordatorios, incidencias) y destello de la linterna. Puedes cambiarlo cuando quieras en Ajustes → Accesibilidad."
        m["Try the vibration"] = "Probar la vibración"
        m["Yes, turn on"] = "Sí, activar"
        m["No, thanks"] = "No, gracias"
        m["Voice alerts for blind people"] = "Avisos de voz para personas ciegas"
        m["The phone's voice tells you the platform, when the train leaves, platform changes and delays, and an insistent sound warns you when your stop is coming up."] = "La voz del teléfono te dice la vía, cuándo sale el tren, los cambios de vía y los retrasos, y un sonido insistente te avisa cuando se acerca tu parada."
        m["Yes, all voice alerts"] = "Sí, todos los avisos de voz"
        m["Answer by voice"] = "Responder por voz"
        m["Hear the question again"] = "Volver a oír la pregunta"
        m["I heard"] = "He oído"
        m["Say yes, only stop, or no"] = "Di sí, solo parada o no"
        m["I didn't understand. Answer yes, only stop, or no. Or tap one of the buttons."] = "No te he entendido. Responde sí, solo parada o no. O toca uno de los botones."
        m["Voice alerts for blind or visually impaired people. Do you want to turn this feature on? You can choose: yes, for all voice alerts about platform, departure and stops; only stop, to be alerted only when your stop is coming up; or no."] = "Avisos de voz para personas ciegas o con baja visión. ¿Quieres activar esta función? Puedes elegir: sí, para todos los avisos de voz sobre vía, salida y paradas; solo parada, para que te avise solo cuando se acerque tu parada; o no."
        m["Timetable PDF"] = "Horario en PDF"
        m["All the day's runs, saved on your phone and available offline."] = "Todos los trenes del día, guardados en tu teléfono y disponibles sin conexión."
        m["Today"] = "Hoy"
        m["Tomorrow"] = "Mañana"
        m["Include return"] = "Incluir la vuelta"
        m["Saved in Download/Binario."] = "Guardado en Download/Binario."
        m["Open"] = "Abrir"
        m["No app to open PDFs"] = "No hay ninguna app para abrir PDF"
        m["Download PDF"] = "Descargar PDF"
        m["Could not create the timetable"] = "No se ha podido crear el horario"
        m["Download the day's timetable as PDF"] = "Descargar el horario del día en PDF"
        m["Free"] = "Gratis"
        m["Paid"] = "De pago"
        m["Free or paid: not stated"] = "Gratis o de pago: no se indica"
        m["hours"] = "horario"
        m["Ask by voice"] = "Preguntar por voz"
        m["Strikes and news"] = "Huelgas y noticias"
        m["Current journey"] = "Viaje en curso"
        m["Stop"] = "Detener"
        m["Updating…"] = "Actualizando…"
        m["Board at"] = "Sube en"
        m["platform"] = "vía"
        m["Next stop"] = "Próxima parada"
        m["Alarm before"] = "Alarma antes de"
        m["Your journey"] = "Tu viaje"
        m["Open live status"] = "Abrir el estado en directo"
        m["Stop following"] = "Dejar de seguir"
        m["Assistant: trains, delays, platforms, strikes"] = "Asistente: trenes, retrasos, vías, huelgas"
        m["Downloaded PDFs are also in Download/Binario"] = "Los PDF descargados también están en Download/Binario"
        m["Information"] = "Información"
        m["Official sources, updated every 5 minutes"] = "Fuentes oficiales, actualizadas cada 5 minutos"
        m["Regional vs regional, high speed vs high speed"] = "Regionales con regionales, alta velocidad con alta velocidad"
        m["Conditions of carriage, rights and refunds"] = "Condiciones de transporte, derechos y reembolsos"
        m["Operators' websites"] = "Webs de las compañías"
        m["At the station and tickets"] = "En la estación y billetes"
        m["Nearby stations on the map"] = "Estaciones cercanas en el mapa"
        m["Official ticket sites and personal area"] = "Webs oficiales de billetes y área personal"
        m["Tools"] = "Herramientas"
        m["On: all alerts"] = "Activo: todos los avisos"
        m["On: upcoming stop only"] = "Activo: solo la parada próxima"
        m["Alerts for deaf people"] = "Avisos para personas sordas"
        m["On: vibration and flash"] = "Activo: vibración y flash"
        m["App"] = "App"
        m["What's new in each version"] = "Novedades de cada versión"
        m["Fix report"] = "Informe de correcciones"
        m["Problems fixed in each version"] = "Problemas corregidos en cada versión"
        m["Bus, metro, tram and taxi"] = "Autobús, metro, tranvía y taxi"
        m["Looking for nearby stops and taxi ranks…"] = "Buscando paradas y puntos de taxi cercanos…"
        m["No bus, metro, tram or taxi stop mapped within 400 m."] = "No hay paradas de autobús, metro, tranvía ni taxi en el mapa a menos de 400 m."
        m["Metro"] = "Metro"
        m["Tram"] = "Tranvía"
        m["Bus"] = "Autobús"
        m["Taxi"] = "Taxi"
        m["Bike sharing"] = "Bicicleta compartida"
        m["Stops in maps"] = "Paradas en el mapa"
        m["Find a taxi"] = "Buscar un taxi"
        m["bus stop"] = "parada de autobús"
        m["Lines and stops from OpenStreetMap data: for bus times and routes check the local transport company."] = "Líneas y paradas según datos de OpenStreetMap: para horarios y recorridos de autobús consulta la empresa de transporte local."
        m["Metro entrance"] = "Entrada al metro"
        m["Tram stop"] = "Parada de tranvía"
        m["Bus stop"] = "Parada de autobús"
        m["shelter"] = "marquesina"
        m["Taxi rank"] = "Parada de taxis"
        m["spaces"] = "plazas"
        m["Tobacconists"] = "Estancos"
        m["Newsagents"] = "Quioscos"
        m["Ticket offices"] = "Taquillas"
        m["Bus stops"] = "Paradas de autobús"
        m["Search on Google Maps:"] = "Buscar en Google Maps:"
        m["Can't find it? Search on Google Maps:"] = "¿No lo encuentras? Busca en Google Maps:"
        m["Looking for ticket sellers within"] = "Buscando puntos de venta en un radio de"
        m["saved data"] = "datos guardados"
        m["OpenStreetMap servers are not responding (tried 3 Overpass servers and Postpass). Try again shortly or search on Google Maps."] = "Los servidores de OpenStreetMap no responden (probados 3 servidores Overpass y Postpass). Inténtalo de nuevo en un momento o busca en Google Maps."
        m["OpenStreetMap data unreachable right now (tried 3 Overpass servers and Postpass)."] = "Datos de OpenStreetMap no disponibles en este momento (probados 3 servidores Overpass y Postpass)."
        m["Pull down to retry"] = "Desliza hacia abajo para reintentar"
        m["Pull down to refresh."] = "Desliza hacia abajo para actualizar."
        m["refreshes every 5 minutes or when you pull down"] = "se actualiza cada 5 minutos o al deslizar hacia abajo"
        m["No ticket sellers within"] = "No hay puntos de venta en un radio de"
    }

    private fun p2(m: HashMap<String, String>) {
        m["No ticket sellers found and the OpenStreetMap servers are not responding. Use the official Trenitalia map or try again."] = "No se han encontrado puntos de venta y los servidores de OpenStreetMap no responden. Usa el mapa oficial de Trenitalia o inténtalo de nuevo."
        m["Mooney outlets"] = "Puntos Mooney"
        m["Official Trenitalia map (all of Italy)"] = "Mapa oficial de Trenitalia (toda Italia)"
        m["Sources"] = "Fuentes"
        m["Trenord authorised resellers and ticket offices"] = "Revendedores autorizados y taquillas de Trenord"
        m["list of"] = "lista de"
        m["updated weekly; open/closed checked now"] = "actualizada cada semana; abierto/cerrado comprobado ahora"
        m["SBB ticket machines (open data data.sbb.ch)"] = "Máquinas expendedoras SBB (datos abiertos data.sbb.ch)"
        m["ticket offices, machines and validators from"] = "taquillas, máquinas expendedoras y validadoras de"
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney outlets: the official Trenitalia map shows them."] = "En el resto de Italia, los billetes regionales de Trenitalia se venden en los puntos PuntoLIS y Mooney: el mapa oficial de Trenitalia los muestra."
        m["Nearest station"] = "Estación más cercana"
        m["Authorised resellers"] = "Revendedores autorizados"
        m["nearest"] = "el más cercano"
        m["see the official Trenitalia map in Resellers"] = "consulta el mapa oficial de Trenitalia en Revendedores"
        m["Downloading Trenord sellers…"] = "Descargando los puntos de venta de Trenord…"
        m["Checking who is open now…"] = "Comprobando quién está abierto ahora…"
        m["Sells"] = "Vende"
        m["altoadigemobilità outlets (South Tyrol)"] = "Puntos altoadigemobilità (Tirol del Sur)"
        m["Railway companies"] = "Compañías ferroviarias"
        m["All companies in Italy and Switzerland: sites, tickets, data"] = "Todas las compañías de Italia y Suiza: webs, billetes, datos"
        m["Search company or region"] = "Buscar compañía o región"
        m["no public data"] = "sin datos públicos"
        m["Website"] = "Web"
        m["Where to buy"] = "Dónde comprar"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. Italian railways with their own network (EAV, FSE, Ferrotramviaria, FAL, Circumetnea, ARST and others) publish real-time data only on their own site and app."] = "Los datos en tiempo real de los trenes de la red RFI proceden de ViaggiaTreno; los de todas las compañías suizas, del horario oficial suizo. Los ferrocarriles italianos con red propia (EAV, FSE, Ferrotramviaria, FAL, Circumetnea, ARST y otros) publican los datos en tiempo real solo en su web y su app."
        m["Only departures are available for Swiss stations"] = "Para las estaciones suizas solo están disponibles las salidas"
        m["not yet included (data only in daily files too heavy for a phone: see note in Punctuality)"] = "aún no incluido (datos solo en archivos diarios demasiado pesados para un teléfono: ver la nota en Puntualidad)"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. For EAV, ARST, Trentino Trasporti and Cotral the app shows scheduled times (Transitous). The other railways with their own network publish timetables and real-time data only on their site and app."] = "Los datos en tiempo real de los trenes de la red RFI proceden de ViaggiaTreno; los de todas las compañías suizas, del horario oficial suizo. Para EAV, ARST, Trentino Trasporti y Cotral la app muestra los horarios programados (Transitous). Los demás ferrocarriles con red propia publican horarios y datos en tiempo real solo en su web y su app."
        m["Only departures are available for this station"] = "Para esta estación solo están disponibles las salidas"
        m["Operator's scheduled times (Transitous): delays appear only if the operator publishes them."] = "Horarios programados de la compañía (Transitous): los retrasos solo aparecen si la compañía los publica."
        m["Nearby toilets"] = "Aseos cercanos"
        m["Free or paid, accessible, opening hours"] = "Gratis o de pago, accesibles, horario"
        m["Free or paid, accessible, baby changing, opening hours"] = "Gratis o de pago, accesibles, cambiador, horario"
        m["Authorised resellers, ticket offices, machines, contactless"] = "Revendedores autorizados, taquillas, máquinas expendedoras, contactless"
        m["Looking for toilets within"] = "Buscando aseos en un radio de"
        m["OpenStreetMap servers are not responding. Try again shortly or search on Google Maps."] = "Los servidores de OpenStreetMap no responden. Inténtalo de nuevo en un momento o busca en Google Maps."
        m["Accessible ♿"] = "Accesible ♿"
        m["Within 2 km"] = "En un radio de 2 km"
        m["Public toilets"] = "Aseos públicos"
        m["No toilets mapped within"] = "No hay aseos en el mapa en un radio de"
        m["Prices, hours and accessibility come from OpenStreetMap volunteers: check on site."] = "Precios, horarios y accesibilidad proceden de voluntarios de OpenStreetMap: compruébalo en el lugar."
        m["♿ partly accessible"] = "♿ parcialmente accesible"
        m["🚼 baby changing"] = "🚼 cambiador"
        m["customers only"] = "solo clientes"
        m["for customers"] = "para clientes"
        m["min walk"] = "min a pie"
        m["Service status"] = "Estado de los servicios"
        m["Check that all data sources respond"] = "Comprueba que todas las fuentes de datos respondan"
        m["Check again"] = "Volver a comprobar"
        m["Checking all data sources…"] = "Comprobando todas las fuentes de datos…"
        m["All sources respond correctly."] = "Todas las fuentes responden correctamente."
        m["sources with problems: related features use fallbacks or the last saved data."] = "fuentes con problemas: las funciones afectadas usan alternativas o los últimos datos guardados."
        m["Working"] = "Funciona"
        m["Checked at"] = "Comprobado a las"
        m["Sources are external public services: if one is down the app tries alternatives (other servers, saved data, Google Maps)."] = "Las fuentes son servicios públicos externos: si uno no funciona, la app prueba alternativas (otros servidores, datos guardados, Google Maps)."
        m["Trains and boards"] = "Trenes y paneles"
        m["Journeys"] = "Itinerarios"
        m["News and strikes"] = "Noticias y huelgas"
        m["Maps and station services"] = "Mapas y servicios de la estación"
        m["The app closed unexpectedly"] = "La app se ha cerrado inesperadamente"
        m["Do you want to send the report to the developer? It contains only the technical error details, the phone model and the Android version: no personal data, location or trips."] = "¿Quieres enviar el informe al desarrollador? Solo contiene los detalles técnicos del error, el modelo del teléfono y la versión de Android: ningún dato personal, ubicación ni viaje."
        m["Binario error report"] = "Informe de error de Binario"
        m["Send report"] = "Enviar informe"
        m["Ignore"] = "Ignorar"
        m["Your next train"] = "Tu próximo tren"
        m["I won't suggest it again"] = "No lo volveré a sugerir"
        m["Not mine"] = "No es el mío"
        m["to"] = "a"
        m["leaves at"] = "sale a las"
        m["changed!"] = "¡cambiado!"
        m["Alternatives"] = "Alternativas"
        m["Leaving earlier"] = "Sale antes"
        m["Looking for alternatives…"] = "Buscando alternativas…"
        m["No alternative soon."] = "No hay alternativas pronto."
        m["Route ready in the Search tab"] = "Itinerario listo en la pestaña Buscar"
        m["Learn the trains I take often"] = "Aprender los trenes que tomo a menudo"
        m["From the board, journeys, Follow and favourites. Stays on the phone only."] = "Desde el panel, los itinerarios, Seguir y los favoritos. Se queda solo en el teléfono."
        m["Alert me automatically about my usual train"] = "Avisarme automáticamente de mi tren habitual"
        m["In the 45 minutes before departure: delay, cancellation, platform change and ready alternatives"] = "En los 45 minutos antes de la salida: retraso, cancelación, cambio de vía y alternativas listas"
        m["Forget"] = "Olvidar"
        m["No usual train yet: it appears after you open it at least twice on the same weekday."] = "Aún no hay tren habitual: aparece después de abrirlo al menos dos veces el mismo día de la semana."
        m["Download failed. Check your connection and try again."] = "Descarga fallida. Comprueba la conexión y vuelve a intentarlo."
        m["A new version is available"] = "Hay una nueva versión disponible"
        m["Downloading the update…"] = "Descargando la actualización…"
        m["To install the update allow Binario to install apps (Android asks only once), then come back here."] = "Para instalar la actualización permite que Binario instale apps (Android lo pide solo una vez) y luego vuelve aquí."
        m["Update downloaded. Confirm the installation in the Android window: favourites and settings are kept."] = "Actualización descargada. Confirma la instalación en la ventana de Android: favoritos y ajustes se conservan."
        m["Do you want to update Binario? The app downloads the new version by itself; favourites and settings are kept."] = "¿Quieres actualizar Binario? La app descarga la nueva versión sola; favoritos y ajustes se conservan."
        m["What's new"] = "Novedades"
        m["Allow"] = "Permitir"
        m["Install"] = "Instalar"
        m["Later"] = "Más tarde"
        m["Feedback and bug reports"] = "Comentarios y errores"
        m["Write to the developer: ideas, suggestions, problems"] = "Escribe al desarrollador: ideas, sugerencias, problemas"
        m["Suggestions, ideas or something not working? Write it here: the message goes straight to the developer."] = "¿Sugerencias, ideas o algo que no funciona? Escríbelo aquí: el mensaje llega directamente al desarrollador."
        m["Suggestion"] = "Sugerencia"
        m["Report a bug"] = "Señalar un error"
        m["Full name"] = "Nombre y apellidos"
        m["Enter your full name"] = "Escribe tu nombre y apellidos"
        m["Invalid email"] = "Correo no válido"
        m["Only used to reply to you"] = "Solo se usa para responderte"
        m["Describe the problem"] = "Describe el problema"
        m["Your feedback"] = "Tu opinión"
        m["What you were doing, what happened and what you expected (e.g. station, train number, time)."] = "Qué estabas haciendo, qué ha pasado y qué esperabas (p. ej. estación, número de tren, hora)."
        m["What you like, what you would improve, what is missing."] = "Qué te gusta, qué mejorarías, qué falta."
        m["Write at least a few words"] = "Escribe al menos unas palabras"
        m["Attach technical details"] = "Adjuntar detalles técnicos"
        m["App version, phone model and Android version: they help find the problem."] = "Versión de la app, modelo del teléfono y versión de Android: ayudan a encontrar el problema."
        m["Thank you! Message sent."] = "¡Gracias! Mensaje enviado."
        m["No connection: the message is saved and will be sent automatically as soon as possible."] = "Sin conexión: el mensaje se ha guardado y se enviará automáticamente en cuanto sea posible."
        m["Sending…"] = "Enviando…"
        m["Send"] = "Enviar"
        m["Name and email are only used to reply to you and nothing else. The message contains no location, trips or favourites."] = "El nombre y el correo solo se usan para responderte y para nada más. El mensaje no contiene ubicación, viajes ni favoritos."
        m["Email"] = "Correo electrónico"
        m["I recommend Binario, the free train app for Italy and Switzerland: timetables, live delays, platforms, strikes, Trenord and FerrovieNord, alerts for your train. No ads."] = "Te recomiendo Binario, la app gratuita de trenes para Italia y Suiza: horarios, retrasos en directo, vías, huelgas, Trenord y FerrovieNord, avisos para tu tren. Sin publicidad."
        m["Download the latest version for Android:"] = "Descarga la última versión para Android:"
        m["After downloading, open the file and allow the installation: the app then updates itself."] = "Después de descargarla, abre el archivo y permite la instalación: luego la app se actualiza sola."
        m["App not installed: choose another app"] = "App no instalada: elige otra app"
        m["Share Binario"] = "Compartir Binario"
        m["Send your contacts the link to download the latest version of the app."] = "Envía a tus contactos el enlace para descargar la última versión de la app."
        m["Other apps (SMS, email…)"] = "Otras apps (SMS, correo…)"
        m["Send the app to your contacts on WhatsApp, Telegram…"] = "Envía la app a tus contactos por WhatsApp, Telegram…"
        m["STIBM area"] = "Área STIBM"
        m["How much it costs"] = "Cuánto cuesta"
        m["From"] = "Desde"
        m["To"] = "Hasta"
        m["The journey goes through Milan"] = "El viaje pasa por Milán"
        m["In that case zone Mi1 is also needed"] = "En ese caso también se necesita la zona Mi1"
        m["zones"] = "zonas"
        m["Same zone: the minimum 2-zone fare still applies (the one with the inner zone is fine too)."] = "Misma zona: se aplica igualmente la tarifa mínima de 2 zonas (también vale la que incluye la zona interior)."
        m["Note: this station is outside the STIBM area. It is only valid for changing train or bus, not as start or end of a STIBM ticket."] = "Atención: esta estación está fuera del área STIBM. Solo vale para cambiar de tren o autobús, no como inicio o fin de un billete STIBM."
        m["Single ticket"] = "Billete sencillo"
        m["min"] = "min"
        m["Carnet of 10 (Trenord website and app)"] = "Bono de 10 (web y app de Trenord)"
        m["Daily (24 hours)"] = "Diario (24 horas)"
        m["3 days"] = "3 días"
        m["Weekly (Mon–Sun)"] = "Semanal (lun–dom)"
        m["Monthly"] = "Mensual"
        m["Yearly"] = "Anual"
        m["Monthly under 26 / over 65"] = "Mensual menores de 26 / mayores de 65"
        m["Yearly under 26 / over 65"] = "Anual menores de 26 / mayores de 65"
        m["Yearly ISEE below €6,000"] = "Anual ISEE inferior a 6.000 €"
        m["Prices valid from"] = "Precios válidos desde el"
        m["Valid on Trenord and Trenitalia regional trains in 2nd class, metro, trams and buses."] = "Válido en trenes regionales Trenord y Trenitalia en 2.ª clase, metro, tranvías y autobuses."
        m["Main rules"] = "Normas principales"
        m["Zone map"] = "Mapa de zonas"
        m["Fares"] = "Tarifas"
        m["Rules"] = "Normas"
        m["Stations in the STIBM area"] = "Estaciones del área STIBM"
        m["Search station or town"] = "Buscar estación o municipio"
        m["outside the area, interchange only"] = "fuera del área, solo transbordo"
        m["service suspended"] = "servicio suspendido"
        m["Use for the calculation"] = "Usar para el cálculo"
        m["Source: Trenord, STIBM area – areas and fares"] = "Fuente: Trenord, área STIBM – áreas y tarifas"
        m["Choose the station"] = "Elige la estación"
        m["Station not found"] = "Estación no encontrada"
        m["Outside the STIBM area (interchange only)"] = "Fuera del área STIBM (solo transbordo)"
        m["zone"] = "zona"
        m["fares"] = "tarifas"
        m["STIBM area · Milan and Monza Brianza"] = "Área STIBM · Milán y Monza Brianza"
        m["Zones, prices and stations of the integrated ticket"] = "Zonas, precios y estaciones del billete integrado"
        m["One ticket for Trenord and Trenitalia regional trains, metro, trams and buses in the Metropolitan City of Milan, the province of Monza and Brianza and some nearby towns. The price depends on the number of zones (Mi1…Mi9) between start and end, not on the vehicle."] = "Un solo billete para trenes regionales Trenord y Trenitalia, metro, tranvías y autobuses en la Ciudad Metropolitana de Milán, la provincia de Monza y Brianza y algunos municipios cercanos. El precio depende del número de zonas (Mi1…Mi9) entre inicio y fin, no del medio de transporte."
        m["How much your pass costs"] = "Cuánto cuesta tu abono"
        m["My Conductor"] = "Mi Revisor"
        m["Follow your train: alerts before, during and after the trip"] = "Sigue tu tren: avisos antes, durante y después del viaje"
        m["Tell me your train: I'll alert you about platform, delays and arrival. All trains, no sign-up."] = "Dime tu tren: te avisaré de la vía, los retrasos y la llegada. Todos los trenes, sin registro."
        m["Trenord from A to B: weekly, monthly, yearly, Trenocittà, tickets"] = "Trenord de A a B: semanal, mensual, anual, Trenocittà, billetes"
        m["Trenord regional fare (Lombardy) by distance band, valid from"] = "Tarifa regional Trenord (Lombardía) por tramo de distancia, válida desde el"
        m["Cannot work out the distance between these stations. Check your connection or choose stations in Lombardy."] = "No se puede calcular la distancia entre estas estaciones. Comprueba la conexión o elige estaciones de Lombardía."
        m["Journey within the STIBM area"] = "Viaje dentro del área STIBM"
        m["Between these stations the integrated STIBM ticket applies (also valid on metro, trams and buses):"] = "Entre estas estaciones se aplica el billete integrado STIBM (válido también en metro, tranvías y autobuses):"
        m["Tap for prices and rules."] = "Toca para ver precios y normas."
        m["distance band"] = "tramo de distancia"
        m["Passes"] = "Abonos"
        m["Weekly"] = "Semanal"
        m["Trenocittà monthly"] = "Mensual Trenocittà"
        m["Trenocittà: train plus city transport in the town shown. "] = "Trenocittà: tren más transporte urbano en la ciudad indicada. "
        m["Passes on the Io Viaggio card (€10, valid 4 years). Families: 2nd minor child −20%, from the 3rd free (Io Viaggio in Famiglia)."] = "Abonos en la tarjeta Io Viaggio (10 €, válida 4 años). Familias: 2.º hijo menor −20 %, gratis a partir del 3.º (Io Viaggio in Famiglia)."
        m["Adult single"] = "Sencillo adulto"
        m["Children 4–14"] = "Niños 4–14"
        m["Senior"] = "Mayores"
        m["Carnet of 10"] = "Bono de 10"
        m["Children under 4 free; children 4–14 free with an adult family member holding a ticket."] = "Niños menores de 4 años gratis; niños de 4–14 años gratis con un familiar adulto con billete."
        m["Io Viaggio Ovunque (all trains and public transport)"] = "Io Viaggio Ovunque (todos los trenes y el transporte público)"
        m["All of Lombardy"] = "Toda Lombardía"
        m["Province, monthly"] = "Provincial, mensual"
        m["1 day"] = "1 día"
        m["2 days"] = "2 días"
        m["7 days"] = "7 días"
        m["Quarterly"] = "Trimestral"
        m["1st class supplement:"] = "Suplemento de 1.ª clase:"
        m["per trip"] = "por viaje"
        m["per month"] = "al mes"
        m["per year (Io Viaggio Ovunque in Lombardia)"] = "al año (Io Viaggio Ovunque in Lombardia)"
        m["Bikes on lines leaving Lombardy: €3.50."] = "Bicicletas en líneas que salen de Lombardía: 3,50 €."
        m["Official fares"] = "Tarifas oficiales"
        m["Trenord passes"] = "Abonos Trenord"
        m["2nd cl."] = "2.ª cl."
        m["1st cl."] = "1.ª cl."
        m["Trains: 2nd class only. First class supplement: €2.80 per trip, €31 per month, €310 per year."] = "Trenes: solo 2.ª clase. Suplemento de primera clase: 2,80 € por viaje, 31 € al mes, 310 € al año."
        m["Malpensa Express · fares"] = "Malpensa Express · tarifas"
        m["Prices from every station, lines, classes and restrictions"] = "Precios desde cada estación, líneas, clases y restricciones"
        m["The two lines"] = "Las dos líneas"
        m["Prices from every station"] = "Precios desde cada estación"
        m["Single adult / child"] = "Sencillo adulto / niño"
        m["Same-day return"] = "Ida y vuelta en el día"
        m["Weekly pass"] = "Abono semanal"
        m["Monthly pass"] = "Abono mensual"
        m["Yearly pass"] = "Abono anual"
        m["Other tickets"] = "Otros billetes"
        m["Return within 30 days (online only), adult / child"] = "Ida y vuelta en 30 días (solo online), adulto / niño"
        m["Malpensa Family (2 adults + 2 children 4–17)"] = "Malpensa Family (2 adultos + 2 niños de 4–17)"
        m["Terminal 1 ⇄ Terminal 2 transfer, adult / child"] = "Traslado Terminal 1 ⇄ Terminal 2, adulto / niño"
        m["Rules and restrictions"] = "Normas y restricciones"
        m["Milan ⇄ Malpensa"] = "Milán ⇄ Malpensa"
        m["To or from Malpensa airport (Terminal 1 and 2) the airport fare applies. Prices valid from"] = "Hacia o desde el aeropuerto de Malpensa (Terminal 1 y 2) se aplica la tarifa del aeropuerto. Precios válidos desde el"
        m["Malpensa airport: Malpensa Express fare"] = "Aeropuerto de Malpensa: tarifa Malpensa Express"
        m["single"] = "sencillo"
        m["monthly 2nd cl."] = "mensual 2.ª cl."
        m["monthly 1st cl."] = "mensual 1.ª cl."
        m["There is no direct airport fare for this station. Tap for all fares and rules."] = "Para esta estación no hay tarifa directa al aeropuerto. Toca para ver todas las tarifas y normas."
        m["The prices below (regional fare) are not valid to or from the airport. Tap for all fares and restrictions."] = "Los precios de abajo (tarifa regional) no valen hacia o desde el aeropuerto. Toca para ver todas las tarifas y restricciones."
        m["2nd class, single ticket, CHF · valid from 14.12.2025 (source: Arcobaleno)"] = "2.ª clase, billete sencillo, CHF · válido desde el 14.12.2025 (fuente: Arcobaleno)"
        m["Trenord passes and tickets"] = "Abonos y billetes Trenord"
        m["Add to calendar"] = "Añadir al calendario"
        m["Some features may have bugs or change. Tap here to report a problem."] = "Algunas funciones pueden tener errores o cambiar. Toca aquí para señalar un problema."
        m["Alarms and saved timetables"] = "Alarmas y horarios guardados"
        m["More options (voice, vibration for deaf people) in Settings → Accessibility."] = "Más opciones (voz, vibración para personas sordas) en Ajustes → Accesibilidad."
        m["Also just for your route and your times"] = "También solo para tu trayecto y tus horarios"
        m["Cancelled."] = "Cancelado."
        m["Travel assistance for disabled passengers"] = "Asistencia en el viaje para viajeros con discapacidad"
        m["Remind me (scheduled notification)"] = "Recuérdamelo (notificación programada)"
        m["Trenord notices"] = "Avisos de Trenord"
        m["Biasca – Bellinzona – Lugano – Chiasso – Como"] = "Biasca – Bellinzona – Lugano – Chiasso – Como"
        m["Biasca – Bellinzona – Lugano – Varese – Malpensa"] = "Biasca – Bellinzona – Lugano – Varese – Malpensa"
        m["Tickets and prices"] = "Billetes y precios"
        m["Cadenazzo – Luino – Gallarate"] = "Cadenazzo – Luino – Gallarate"
        m["Arcobaleno fare calculator"] = "Calculadora de tarifas Arcobaleno"
        m["Dogs, cats and pet carriers: rules and prices by operator"] = "Perros, gatos y transportines: normas y precios por compañía"
        m["Castione-Arbedo – Bellinzona – Locarno"] = "Castione-Arbedo – Bellinzona – Locarno"
        m["Find an Italo train by number"] = "Buscar un tren Italo por número"
        m["Who to call and how to book: Sale Blu 800 90 60 60, Trenord, Italo, SBB"] = "A quién llamar y cómo reservar: Sale Blu 800 90 60 60, Trenord, Italo, SBB"
        m["Colour-blind colours. Do you want to turn this on? Tap yes red-green, yes blue-yellow, or no."] = "Colores para daltónicos. ¿Quieres activarlos? Toca sí rojo-verde, sí azul-amarillo o no."
        m["What's your name? Tell me your first and last name."] = "¿Cómo te llamas? Dime tu nombre y apellidos."
        m["Como – Mendrisio – Varese"] = "Como – Mendrisio – Varese"
        m["Conditions of carriage, delays, compensation"] = "Condiciones de transporte, retrasos, indemnizaciones"
        m["Contacts and support"] = "Contactos y asistencia"
        m["Validate before departure and at every change of vehicle (between two trains the first validation is enough)."] = "Valida antes de salir y en cada cambio de vehículo (entre dos trenes basta la primera validación)."
        m["Single ticket valid 4 hours for the whole journey (in Italy from validation). Monthly cross-border passes: in Italy from the 1st of the month, only on an Io Viaggio card; in Ticino 30 days from purchase."] = "Billete sencillo válido 4 horas para todo el viaje (en Italia desde la validación). Abonos mensuales transfronterizos: en Italia desde el día 1 del mes, solo en tarjeta Io Viaggio; en el Tesino 30 días desde la compra."
        m["What to do and who to contact: Trenord, Trenitalia, Italo, SBB"] = "Qué hacer y a quién contactar: Trenord, Trenitalia, Italo, SBB"
        m["From A to B: passes and tickets, also to Switzerland"] = "De A a B: abonos y billetes, también hacia Suiza"
        m["From: "] = "Desde: "
        m["Describe the problem."] = "Describe el problema."
        m["Describe the problem: what you were doing and what happened."] = "Describe el problema: qué estabas haciendo y qué ha pasado."
        m["Dictate the message"] = "Dictar el mensaje"
        m["Shall I send, correct or cancel? Say send, correct or cancel."] = "¿Envío, corrijo o cancelo? Di enviar, corregir o cancelar."
        m["Tell me your suggestion."] = "Dime tu sugerencia."
        m["Rights and refunds"] = "Derechos y reembolsos"
        m["Where am I"] = "Dónde estoy"
        m["Where I am, platforms, lifts, stairs, nearby services; guidance to a place"] = "Dónde estoy, vías, ascensores, escaleras, servicios cercanos; guía hasta un lugar"
        m["Where I am, platforms, lifts, services; guidance to a place"] = "Dónde estoy, vías, ascensores, servicios; guía hasta un lugar"
        m["Duration"] = "Duración"
        m["Sold out"] = "Agotado"
        m["Explore by voice"] = "Explorar por voz"
        m["Voice feedback"] = "Comentarios por voz"
        m["Voice feedback. After the tone, tell me: is it a suggestion or do you want to report a problem? You can say cancel at any time."] = "Comentarios por voz. Después del tono, dime: ¿es una sugerencia o quieres señalar un problema? Puedes decir cancelar en cualquier momento."
        m["Feedback and reports. Tap the \"Voice feedback\" button at the top to dictate your message."] = "Comentarios y avisos. Toca el botón \"Comentarios por voz\" arriba para dictar tu mensaje."
        m["Intermediate stops only at stations in the STIBM area; outside the area only to change vehicle (e.g. Saronno, Busto Arsizio, Treviglio)."] = "Paradas intermedias solo en estaciones del área STIBM; fuera del área solo para cambiar de medio (p. ej. Saronno, Busto Arsizio, Treviglio)."
        m["Giubiasco – Lugano – Mendrisio"] = "Giubiasco – Lugano – Mendrisio"
        m["Got it"] = "Entendido"
        m["Tickets cannot be transferred after validation. Passes on an Io Viaggio or ATM card."] = "Los billetes no se pueden ceder después de validarlos. Abonos en tarjeta Io Viaggio o ATM."
        m["Your trains during the strike"] = "Tus trenes durante la huelga"
        m["The standard ticket is valid 75 minutes for 2 zones, +15 minutes per zone up to 4 zones, +30 minutes per zone from 5 zones up; in Milan (Mi1–Mi3) it is valid 90 minutes. Unlimited journeys within the validity time."] = "El billete ordinario vale 75 minutos para 2 zonas, +15 minutos por zona hasta 4 zonas, +30 minutos por zona a partir de 5 zonas; en Milán (Mi1–Mi3) vale 90 minutos. Viajes ilimitados dentro del tiempo de validez."
        m["The message is too short."] = "El mensaje es demasiado corto."
        m["Speech recognition is not available on this phone."] = "El reconocimiento de voz no está disponible en este teléfono."
        m["At the station and tools"] = "En la estación y herramientas"
        m["Travel updates, guaranteed trains, tickets"] = "Información de viaje, trenes garantizados, billetes"
        m["About the app"] = "Información sobre la app"
        m["Full fare"] = "Tarifa completa"
        m["Italy and Switzerland: websites, tickets, data"] = "Italia y Suiza: webs, billetes, datos"
        m["The Lombardy regional fare is not valid across the border. The price adds the Lombardy section (Trenord distance bands) and the Ticino section (Arcobaleno zones): Trenord sells it in euros, Arcobaleno in francs."] = "La tarifa regional de Lombardía no vale para cruzar la frontera. El precio suma el tramo lombardo (tramos de distancia de Trenord) y el tramo del Tesino (zonas Arcobaleno): Trenord lo vende en euros, Arcobaleno en francos."
        m["Trenord and FerrovieNord lines"] = "Líneas Trenord y FerrovieNord"
        m["FerrovieNord network lines"] = "Líneas de la red FerrovieNord"
        m["Lines, Malpensa Express, STIBM area, notices"] = "Líneas, Malpensa Express, área STIBM, avisos"
        m["Locarno – Lugano – Chiasso – Milan"] = "Locarno – Lugano – Chiasso – Milán"
        m["Malpensa Express: valid only within the city of Milan (not in the 21 towns of zone Mi3) and between Milan and Rescaldina (Mi1–Mi7), only on trains to/from Milano Centrale."] = "Malpensa Express: válido solo dentro de la ciudad de Milán (no en los 21 municipios de la zona Mi3) y entre Milán y Rescaldina (Mi1–Mi7), solo en trenes desde/hacia Milano Centrale."
        m["The name is missing."] = "Falta el nombre."
        m["A valid email is missing."] = "Falta un correo válido."
        m["Half fare"] = "Media tarifa"
        m["Also show these options on the Home screen"] = "Mostrar estas opciones también en la pantalla de inicio"
        m["Hide"] = "Ocultar"
        m["Hide fares"] = "Ocultar tarifas"
        m["During guaranteed hours (weekdays 6–9 and 18–21) regional trains run. Outside those hours check your operator's list of guaranteed trains."] = "En las franjas garantizadas (días laborables 6–9 y 18–21) circulan los trenes regionales. Fuera de esas franjas consulta la lista de trenes garantizados de tu compañía."
        m["No strike announced in your region"] = "No hay huelgas convocadas en tu región"
        m["No announced strike affects your route at your times"] = "Ninguna huelga convocada afecta a tu trayecto en tus horarios"
        m["No"] = "No"
        m["I didn't understand the email. Say it again slowly, saying at and dot."] = "No he entendido el correo. Repítelo despacio, diciendo arroba y punto."
        m["I didn't hear you. Tap \"Voice feedback\" again to try again."] = "No te he oído. Toca de nuevo \"Comentarios por voz\" para volver a intentarlo."
        m["Note: the malpensaexpress.it passes page shows lower \"from\" prices (€25 weekly, €87 monthly, €840 yearly): here are the prices from the current Trenord fare table."] = "Atención: la página de abonos de malpensaexpress.it muestra precios «desde» más bajos (25 € semanal, 87 € mensual, 840 € anual): aquí están los precios de la tabla de tarifas vigente de Trenord."
        m["Scheduled notifications, alarms, offline timetables"] = "Notificaciones programadas, alarmas, horarios sin conexión"
        m["Travel update news"] = "Noticias de información de viaje"
    }

    private fun p3(m: HashMap<String, String>) {
        m["What's new, fixes, service status, privacy"] = "Novedades, correcciones, estado de los servicios, privacidad"
        m["Lost property"] = "Objetos perdidos"
        m["Spoken mode"] = "Modo hablado"
        m["Spoken mode (blind users)"] = "Modo hablado (personas ciegas)"
        m["Spoken mode on."] = "Modo hablado activado."
        m["Time"] = "Hora"
        m["Sort:"] = "Ordenar:"
        m["By operator"] = "Por compañía"
        m["For people who are blind or prefer to talk: the app asks the questions aloud and you answer by voice."] = "Para personas ciegas o que prefieren hablar: la app hace las preguntas en voz alta y respondes con la voz."
        m["Trenord doesn't publish a price table for this route: the exact price in euros is in the Trenord online shop."] = "Trenord no publica una tabla de precios para este trayecto: el precio exacto en euros está en la tienda online de Trenord."
        m["Ranks outside the station, radio taxis to call, apps"] = "Paradas fuera de la estación, radiotaxis a los que llamar, apps"
        m["Taxi ranks, radio taxis to call, apps"] = "Paradas de taxis, radiotaxis a los que llamar, apps"
        m["Best prices by day and time of day"] = "Mejores precios por día y franja horaria"
        m["Prices for 1 adult from LeFrecce (Trenitalia); they may change until purchase."] = "Precios para 1 adulto de LeFrecce (Trenitalia); pueden cambiar hasta la compra."
        m["Price"] = "Precio"
        m["Arcobaleno price (2nd class, single ticket):"] = "Precio Arcobaleno (2.ª clase, billete sencillo):"
        m["Trenord price (adult single ticket)"] = "Precio Trenord (billete sencillo adulto)"
        m["Price and booking on italotreno.com"] = "Precio y compra en italotreno.com"
        m["Price on the Trenord website"] = "Precio en la web de Trenord"
        m["Sales points"] = "Puntos de venta"
        m["FerrovieNord punctuality"] = "Puntualidad de FerrovieNord"
        m["What's your email? For example: mario dot rossi at gmail dot com."] = "¿Cuál es tu correo? Por ejemplo: mario punto rossi arroba gmail punto com."
        m["RFI Sala Blu · 800 90 60 60"] = "RFI Sala Blu · 800 90 60 60"
        m["Children under 14 travel free with a paying adult; on their own they need the Under 14 card."] = "Los menores de 14 años viajan gratis con un adulto que paga; solos necesitan la tarjeta Under 14."
        m["EU Regulation 2021/782"] = "Reglamento UE 2021/782"
        m["Delays, cancellations, platforms, crowding and punctuality use distinguishable colours (orange and blue instead of red and green) and extra symbols. You can change it at any time from Home or Settings → Accessibility."] = "Retrasos, cancelaciones, vías, ocupación y puntualidad usan colores distinguibles (naranja y azul en lugar de rojo y verde) y símbolos adicionales. Puedes cambiarlo cuando quieras desde Inicio o Ajustes → Accesibilidad."
        m["Problem report."] = "Aviso de problema."
        m["You are here"] = "Estás aquí"
        m["FerrovieNord website"] = "Web de FerrovieNord"
        m["Suggestion."] = "Sugerencia."
        m["Yes, blue-yellow"] = "Sí, azul-amarillo"
        m["Yes, turn off"] = "Sí, desactivar"
        m["Yes, red-green (the most common)"] = "Sí, rojo-verde (el más común)"
        m["TILO (Ticino–Lombardy)"] = "TILO (Tesino–Lombardía)"
        m["TILO and Switzerland"] = "TILO y Suiza"
        m["TILO · Services"] = "TILO · Servicios"
        m["Departures and arrivals board"] = "Panel de salidas y llegadas"
        m["Nearby taxis"] = "Taxis cercanos"
        m["Ticino–Lombardy, cross-border fares"] = "Tesino–Lombardía, tarifas transfronterizas"
        m["Between two Swiss stations Arcobaleno (Ticino) or SBB fares apply: Trenord's distance bands don't apply."] = "Entre dos estaciones suizas se aplican las tarifas Arcobaleno (Tesino) o SBB: los tramos de distancia de Trenord no valen."
        m["Between places outside Milan: the zones between them; if you cross Milan you always also need Mi1. Minimum 2 zones."] = "Entre localidades fuera de Milán: las zonas entre ellas; si cruzas Milán siempre necesitas también Mi1. Mínimo 2 zonas."
        m["Real-time trains, contacts"] = "Trenes en tiempo real, contactos"
        m["Trenord · 800 210 955"] = "Trenord · 800 210 955"
        m["All railway operators"] = "Todas las compañías ferroviarias"
        m["All accessibility options"] = "Todas las opciones de accesibilidad"
        m["All fares and classes"] = "Todas las tarifas y clases"
        m["Checked on the Trenord website on"] = "Comprobado en la web de Trenord el"
        m["Travelling with pets"] = "Viajar con animales"
        m["Italy ⇄ Switzerland trip: cross-border ticket"] = "Viaje Italia ⇄ Suiza: billete transfronterizo"
        m["Trip within Switzerland"] = "Viaje dentro de Suiza"
        m["Do you want to turn on spoken mode? The phone's voice will tell you the platform, departure, delays and the stop where to get off."] = "¿Quieres activar el modo hablado? La voz del teléfono te dirá la vía, la salida, los retrasos y la parada en la que bajar."
        m["Do you want to turn off spoken mode?"] = "¿Quieres desactivar el modo hablado?"
        m["application/json"] = "application/json"
        m["contactless"] = "contactless"
        m["from"] = "de"
        m["data saved on the phone"] = "datos guardados en el teléfono"
        m["sold out"] = "agotado"
        m["in testing"] = "en pruebas"
        m["half price"] = "mitad de precio"
        m["last"] = "últimos"
        m["Departures from Cadorna at minutes 27 and 57 (from 4.27 to 00.20), 37 minutes. Stops at Milano Bovisa, Saronno, Busto Arsizio Nord. FIRST class only."] = "Salidas desde Cadorna en los minutos 27 y 57 (de 4.27 a 00.20), 37 minutos. Para en Milano Bovisa, Saronno, Busto Arsizio Nord. Solo PRIMERA clase."
        m["Departures from Centrale at minutes 25 and 55 (from 5.25 to 23.25), 51 minutes. Stops at Porta Garibaldi, Bovisa, Saronno, Busto Arsizio; the :25 trains also at Rescaldina, Castellanza and Ferno-Lonate Pozzolo. First and second class, but second class is only for trips that do NOT start or end at the airport."] = "Salidas desde Centrale en los minutos 25 y 55 (de 5.25 a 23.25), 51 minutos. Para en Porta Garibaldi, Bovisa, Saronno, Busto Arsizio; los de :25 también en Rescaldina, Castellanza y Ferno-Lonate Pozzolo. Primera y segunda clase, pero la segunda clase es solo para viajes que NO empiezan ni terminan en el aeropuerto."
        m["To or from Malpensa Terminal 1 and 2 you always need an airport-fare ticket: regional passes, Io Viaggio Ovunque (Lombardy or Varese province) and STIBM are valid on Malpensa Express trains only between the other stations."] = "Hacia o desde Malpensa Terminal 1 y 2 siempre necesitas un billete con tarifa del aeropuerto: los abonos regionales, Io Viaggio Ovunque (Lombardía o provincia de Varese) y STIBM valen en los trenes Malpensa Express solo entre las demás estaciones."
        m["The Malpensa ticket is valid for both terminals."] = "El billete de Malpensa vale para las dos terminales."
        m["Single ticket: valid on the chosen day until the end of service, no validation needed; the date can be changed up to 3 times until the day before."] = "Billete sencillo: válido el día elegido hasta el final del servicio, sin validar; la fecha se puede cambiar hasta 3 veces hasta el día anterior."
        m["Return ticket: same-day at ticket offices and machines; within 30 days only online and in the app (Milan ⇄ Malpensa, €25 instead of €30), only the return date can be changed."] = "Billete de ida y vuelta: en el día en taquillas y máquinas; en 30 días solo online y en la app (Milán ⇄ Malpensa, 25 € en lugar de 30 €), solo se puede cambiar la fecha de vuelta."
        m["Malpensa Family €36: 2 adults and 2 young people aged 4 to 17, between a Milan station and the airport. Children under 4 travel free."] = "Malpensa Family 36 €: 2 adultos y 2 jóvenes de 4 a 17 años, entre una estación de Milán y el aeropuerto. Los menores de 4 años viajan gratis."
        m["Young people: reduced fare from 4 to 13 years."] = "Jóvenes: tarifa reducida de 4 a 13 años."
        m["The Malpensa Express ticket to/from Milan is also valid on all trains between stations in the Milan area."] = "El billete Malpensa Express desde/hacia Milán también vale en todos los trenes entre estaciones del área de Milán."
        m["On urban sections (Cadorna–Domodossola–Bovisa and Centrale–Porta Garibaldi–Bovisa) urban Trenord and STIBM tickets are also valid. STIBM is valid only in 2nd class, and on trains to/from Milano Centrale also as far as Rescaldina (Mi1–Mi7)."] = "En los tramos urbanos (Cadorna–Domodossola–Bovisa y Centrale–Porta Garibaldi–Bovisa) también valen los billetes urbanos de Trenord y STIBM. STIBM vale solo en 2.ª clase y, en los trenes desde/hacia Milano Centrale, también hasta Rescaldina (Mi1–Mi7)."
        m["Malpensa Express passes: weekly (on sale from the Thursday before, activate within 5 days), monthly (from the 22nd of the previous month, within 15 days), yearly (within 30 days); on an Io Viaggio card or Phone Pass."] = "Abonos Malpensa Express: semanal (a la venta desde el jueves anterior, activar en 5 días), mensual (desde el día 22 del mes anterior, en 15 días), anual (en 30 días); en tarjeta Io Viaggio o Phone Pass."
        m["Bikes and dogs travel free as luggage with a boarding pass; without a boarding pass dogs pay the pet supplement."] = "Las bicicletas y los perros viajan gratis como equipaje con tarjeta de embarque; sin tarjeta de embarque los perros pagan el suplemento para animales."
        m["Transfer between Terminal 1 and Terminal 2: €2 adults, €1 young people."] = "Traslado entre Terminal 1 y Terminal 2: 2 € adultos, 1 € jóvenes."
        m["via Terminal 2"] = "por Terminal 2"
        m["via Busto Arsizio"] = "por Busto Arsizio"
        m["Share Binario: coming soon"] = "Compartir Binario: próximamente"
        m["Network, lifts out of service, accessibility, defibrillators"] = "Red, ascensores fuera de servicio, accesibilidad, desfibriladores"
        m["FERROVIENORD network info"] = "Información de la red FERROVIENORD"
        m["Lifts and escalators out of service, accessibility, assistance, AEDs, documents"] = "Ascensores y escaleras mecánicas fuera de servicio, accesibilidad, asistencia, DEA, documentos"
        m["Stops and times of buses replacing trains · Trenord, Trenitalia, TILO"] = "Paradas y horarios de los autobuses que sustituyen a los trenes · Trenord, Trenitalia, TILO"
        m["Defibrillators (AED)"] = "Desfibriladores (DEA)"
        m["Where they are, near you or the station · call 112"] = "Dónde están, cerca de ti o de la estación · llama al 112"
        m["Share Binario, not available: coming soon"] = "Compartir Binario, no disponible: próximamente"
        m["Coming soon"] = "Próximamente"
        m["solutions · saved on "] = "soluciones · guardado el "
        m["Reminder at "] = "Recordatorio a las "
        m["arrival"] = "llegada"
        m["departure"] = "salida"
        m["Ticket offices, machines, resellers · nearby or by province"] = "Taquillas, máquinas expendedoras, revendedores · cerca o por provincia"
        m["Location not available: turn on GPS."] = "Ubicación no disponible: activa el GPS."
        m["Looking for taxi ranks…"] = "Buscando paradas de taxis…"
        m["OpenStreetMap servers are not responding. Use the numbers below or Google Maps."] = "Los servidores de OpenStreetMap no responden. Usa los números de abajo o Google Maps."
        m["Call a taxi"] = "Llamar a un taxi"
        m["I don't have a verified radio taxi number for this city: use an app or search for the number."] = "No tengo un número de radiotaxi verificado para esta ciudad: usa una app o busca el número."
        m["Search for the taxi number"] = "Buscar el número de taxi"
        m["Italian radio taxi app: book and pay in the app"] = "App italiana de radiotaxi: reserva y paga en la app"
        m["Taxis in many Italian cities"] = "Taxis en muchas ciudades italianas"
        m["Uber Taxi in cities where available"] = "Uber Taxi en las ciudades donde está disponible"
        m["Where to get a taxi"] = "Dónde tomar un taxi"
        m["No taxi rank mapped within 1.5 km. The rank is usually in front of the station's main exit."] = "No hay paradas de taxis en el mapa a menos de 1,5 km. La parada suele estar delante de la salida principal de la estación."
        m["Local taxi companies"] = "Empresas de taxi locales"
        m["Taxi ranks"] = "Paradas de taxis"
        m["Ranks and phones from OpenStreetMap (volunteers), radio taxis from city services: check on site. 112 is for emergencies only."] = "Paradas y teléfonos de OpenStreetMap (voluntarios), radiotaxis de los servicios municipales: compruébalo en el lugar. El 112 es solo para emergencias."
        m["Tap to open the location"] = "Toca para abrir la ubicación"
        m["Tap to call"] = "Toca para llamar"
        m["Best prices"] = "Mejores precios"
        m["Choose origin and destination first."] = "Elige primero origen y destino."
        m["All trains"] = "Todos los trenes"
        m["Lowest price for 1 adult among trains in that time band (LeFrecce · Trenitalia). Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "Precio más bajo para 1 adulto entre los trenes de esa franja (LeFrecce · Trenitalia). Toca una celda para ver las soluciones. Las tarifas económicas cambian según la disponibilidad: el precio final es el del pago."
        m["In short"] = "En resumen"
        m["Small animals (cats, small dogs, rabbits, birds) in a carrier: almost always free."] = "Animales pequeños (gatos, perros pequeños, conejos, pájaros) en transportín: casi siempre gratis."
        m["Larger dogs: leash and muzzle; a dog ticket is often needed."] = "Perros más grandes: correa y bozal; a menudo se necesita un billete para el perro."
        m["Guide and assistance dogs: always free, on all trains and classes, with no time limits."] = "Perros guía y de asistencia: siempre gratis, en todos los trenes y clases, sin límites de horario."
        m["Always carry the dog-registry certificate and health booklet (from abroad: EU pet passport)."] = "Lleva siempre el certificado del registro canino y la cartilla sanitaria (desde el extranjero: pasaporte europeo para animales)."
        m["The animal must not take up seats or disturb others: staff may ask you to leave if it causes danger or disturbance."] = "El animal no debe ocupar asientos ni molestar: el personal puede pedirte que bajes si causa peligro o molestias."
        m["Small animals in a carrier (max 70×30×50 cm): free within Lombardy."] = "Animales pequeños en transportín (máx. 70×30×50 cm): gratis dentro de Lombardía."
        m["Dogs of any size: muzzle, leash and dog-registry certificate; free within Lombardy."] = "Perros de cualquier tamaño: bozal, correa y certificado del registro canino; gratis dentro de Lombardía."
        m["Not allowed on weekdays (Monday–Friday) 7:00–9:30 and 17:30–19:30, small animals included. Guide dogs can always travel."] = "No se admiten en días laborables (lunes–viernes) de 7:00 a 9:30 y de 17:30 a 19:30, animales pequeños incluidos. Los perros guía pueden viajar siempre."
        m["Beyond Lombardy and to Switzerland an animal supplement is needed, under the rules of the operating company."] = "Fuera de Lombardía y hacia Suiza se necesita un suplemento para el animal, según las normas de la compañía que opera el tren."
        m["Malpensa Express: dogs travel free as luggage with a boarding pass; without one they pay the animal supplement."] = "Malpensa Express: los perros viajan gratis como equipaje con tarjeta de embarque; sin ella pagan el suplemento para animales."
        m["Small animals in a carrier (max 70×30×50 cm): always free, on all trains."] = "Animales pequeños en transportín (máx. 70×30×50 cm): siempre gratis, en todos los trenes."
        m["Regional trains: larger dogs travel with a 2nd-class ticket at 50% off, with leash and muzzle."] = "Trenes regionales: los perros más grandes viajan con un billete de 2.ª clase con un 50 % de descuento, con correa y bozal."
        m["Frecce and Intercity: a dog outside the carrier must be added when buying (\"Travel with your dog\"); the price is the one shown at checkout, with promotions in some periods (e.g. dogs free in summer)."] = "Frecce e Intercity: un perro fuera del transportín debe añadirse al comprar (\"Viaja con tu perro\"); el precio es el que se muestra al pagar, con promociones en algunos periodos (p. ej. perros gratis en verano)."
        m["Documents: dog-registry certificate and health booklet; staff may ask for them. Assistance dogs are also allowed in bar/restaurant cars and replacement buses."] = "Documentos: certificado del registro canino y cartilla sanitaria; el personal puede pedirlos. Los perros de asistencia también se admiten en el vagón bar/restaurante y en los autobuses sustitutivos."
        m["Small animals (up to about 5 kg) in a carrier: free."] = "Animales pequeños (hasta unos 5 kg) en transportín: gratis."
        m["Larger dogs: allowed in Smart and Prima by booking the \"Dog\" service (online or Pronto Italo 06 07 08, up to 2 hours before); always on a leash, muzzle when boarding/leaving or on request. Price shown at checkout."] = "Perros más grandes: admitidos en Smart y Prima reservando el servicio \"Dog\" (online o Pronto Italo 06 07 08, hasta 2 horas antes); siempre con correa, bozal al subir/bajar o si se pide. Precio indicado al pagar."
        m["Guide dogs: free, any size."] = "Perros guía: gratis, de cualquier tamaño."
        m["Switzerland · SBB and TILO"] = "Suiza · SBB y TILO"
        m["Dogs up to 30 cm at the withers and other small animals in a bag or carrier: free, as hand luggage."] = "Perros de hasta 30 cm a la cruz y otros animales pequeños en bolsa o transportín: gratis, como equipaje de mano."
        m["Larger dogs (or outside a carrier): half the 2nd-class fare, or the dog day pass CHF 25 (also valid on buses, trams and boats); dog pass CHF 60 a month or CHF 350 a year."] = "Perros más grandes (o fuera del transportín): media tarifa de 2.ª clase, o el pase diario para perros de 25 CHF (válido también en autobuses, tranvías y barcos); abono para perros de 60 CHF al mes o 350 CHF al año."
        m["The dog stays under your seat without blocking the aisle. Not allowed in restaurant cars (except guide and assistance dogs)."] = "El perro se queda debajo de tu asiento sin bloquear el pasillo. No se admite en el vagón restaurante (excepto perros guía y de asistencia)."
        m["Rules from the operators' official pages (October 2026). Prices and promotions change: before travelling check the operator's page with the button above."] = "Normas de las páginas oficiales de las compañías (octubre de 2026). Precios y promociones cambian: antes de viajar consulta la página de la compañía con el botón de arriba."
        m["Official page "] = "Página oficial "
        m["Enter town or station"] = "Escribe un municipio o una estación"
        m["Clear"] = "Borrar"
        m["Near me"] = "Cerca de mí"
        m["Show map"] = "Mostrar mapa"
        m["Show list"] = "Mostrar lista"
        m["towards "] = "hacia "
        m["straight ahead"] = "todo recto"
        m["to your right"] = "a tu derecha"
        m["behind you"] = "detrás de ti"
        m["to your left"] = "a tu izquierda"
        m["ahead on the right"] = "delante a la derecha"
        m["ahead on the left"] = "delante a la izquierda"
        m["behind on the right"] = "detrás a la derecha"
        m["behind on the left"] = "detrás a la izquierda"
        m["metres"] = "metros"
        m["Travelling, near the station of "] = "Viajando, cerca de la estación de "
        m["You are at "] = "Estás en "
        m["Warning, out of service: "] = "Atención, fuera de servicio: "
        m["You have arrived: "] = "Has llegado: "
        m["Explore"] = "Explorar"
        m["Categories"] = "Categorías"
        m["Guiding you to: "] = "Te guío hasta: "
        m["Walking navigation"] = "Navegación a pie"
        m["Stop guiding"] = "Dejar de guiar"
        m["Location permission is needed to explore."] = "Se necesita el permiso de ubicación para explorar."
        m["Finding your position… Turn on GPS."] = "Buscando tu posición… Activa el GPS."
        m["Guiding you to "] = "Te guío hasta "
        m["Exploring. I'll tell you about nearby stations, platforms, lifts, stairs and services."] = "Explorando. Te hablaré de las estaciones, vías, ascensores, escaleras y servicios cercanos."
        m["Exploring stopped."] = "Exploración detenida."
        m["Stop exploring"] = "Dejar de explorar"
        m["Start spoken exploration"] = "Empezar la exploración hablada"
        m["Nearest station: "] = "Estación más cercana: "
        m["You are moving at "] = "Te mueves a "
        m["No useful places found nearby."] = "No se han encontrado lugares útiles cerca."
        m["Where am I? Tell me"] = "¿Dónde estoy? Dímelo"
        m["Last announcement"] = "Último anuncio"
        m["GPS accuracy: "] = "Precisión del GPS: "
        m[" · no compass: directions by compass points"] = " · sin brújula: direcciones por puntos cardinales"
        m["Hold the phone in front of you: \"12 o'clock\" is ahead, \"3\" right, \"9\" left. In stations GPS can be off by a few metres: ask staff or the Sale Blu for help (More → Disability assistance)."] = "Sostén el teléfono delante de ti: \"las 12\" es delante, \"las 3\" a la derecha, \"las 9\" a la izquierda. En las estaciones el GPS puede desviarse unos metros: pide ayuda al personal o a las Sale Blu (Más → Asistencia a personas con discapacidad)."
        m["None of these mapped nearby (300 m)."] = "Ninguno de estos en el mapa cerca (300 m)."
        m["Guide me"] = "Guíame"
        m["Board"] = "Panel"
        m["No results for "] = "Sin resultados para "
        m["Found "] = "Encontrados "
        m[" results. First: "] = " resultados. Primero: "
        m["Place, address, station…"] = "Lugar, dirección, estación…"
        m["Voice search"] = "Búsqueda por voz"
        m["Save this spot"] = "Guardar este punto"
        m["E.g. \"Platform 3, front of the train\", \"Lift by the café\", \"Taxi exit\": then \"Guide me\" brings you back. Favourite stations and trains are in the Stations and Trains tabs."] = "P. ej. \"Vía 3, cabeza del tren\", \"Ascensor junto al bar\", \"Salida de taxis\": luego \"Guíame\" te lleva de vuelta. Las estaciones y trenes favoritos están en las pestañas Estaciones y Trenes."
        m["No saved places."] = "No hay lugares guardados."
        m["Name"] = "Nombre"
        m["Current position, accuracy ±"] = "Posición actual, precisión ±"
        m["Saved spot"] = "Punto guardado"
        m["Saved: "] = "Guardado: "
        m["No solutions found for the chosen time."] = "No se han encontrado soluciones para la hora elegida."
        m["Cannot reach the server. Check your connection."] = "No se puede conectar con el servidor. Comprueba la conexión."
        m["Departing from "] = "Sale de "
        m["FASTEST"] = "MÁS RÁPIDO"
        m[" · first train +"] = " · primer tren +"
        m["Not reachable now: "] = "No disponible ahora: "
        m["Train "] = "Tren "
        m["I'll remind you at "] = "Te lo recordaré a las "
        m["Where to catch the bus when trains don't run · Trenord, Trenitalia, TILO"] = "Dónde tomar el autobús cuando no circulan los trenes · Trenord, Trenitalia, TILO"
        m["The nearest to you · call 112"] = "Los más cercanos a ti · llama al 112"
        m["FERROVIENORD · source: ferrovienord.it (station accessibility notices). Assistance: 800 210 955"] = "FERROVIENORD · fuente: ferrovienord.it (avisos de accesibilidad de las estaciones). Asistencia: 800 210 955"
        m["Show later trains (+6 hours)"] = "Mostrar trenes posteriores (+6 horas)"
        m["Platform "] = "Vía "
        m["What to do right away"] = "Qué hacer enseguida"
        m["If you are still on the train or in the station, tell the conductor or staff straight away: it's the fastest way to find it."] = "Si todavía estás en el tren o en la estación, díselo enseguida al revisor o al personal: es la forma más rápida de encontrarlo."
        m["Note the train number, day, time, coach and seat, and describe the item well (brand, colour, contents)."] = "Anota el número del tren, el día, la hora, el coche y el asiento, y describe bien el objeto (marca, color, contenido)."
        m["Contact the train's operator (below): each has its own lost property service."] = "Contacta con la compañía del tren (abajo): cada una tiene su propio servicio de objetos perdidos."
        m["Documents, cards or phone: block your cards and, for theft or documents, report it to the Railway Police (Polfer) or Carabinieri."] = "Documentos, tarjetas o teléfono: bloquea las tarjetas y, en caso de robo o documentos, denúncialo a la Policía Ferroviaria (Polfer) o a los Carabinieri."
        m["After a few days unclaimed items go to the town's lost property office: ask there."] = "Pasados unos días, los objetos no reclamados van a la oficina de objetos perdidos del municipio: pregunta allí."
        m["The train you are following: "] = "El tren que sigues: "
        m["Trenord, Malpensa Express and FerrovieNord stations"] = "Estaciones Trenord, Malpensa Express y FerrovieNord"
        m["Trenord Contact Center: items lost on trains or platforms"] = "Contact Center de Trenord: objetos perdidos en trenes o andenes"
        m["Found items are kept at the My Link Points in Milano Cadorna and Milano Porta Garibaldi for a few days (up to 6), then go to the City of Milan lost property office."] = "Los objetos encontrados se guardan en los My Link Point de Milano Cadorna y Milano Porta Garibaldi unos días (hasta 6) y luego pasan a la oficina de objetos perdidos del Ayuntamiento de Milán."
        m["City of Milan · Lost property"] = "Ayuntamiento de Milán · Objetos perdidos"
        m["Via Friuli 30, Milan · 02 884 53900"] = "Via Friuli 30, Milán · 02 884 53900"
        m["Trenord lost property page"] = "Página de objetos perdidos de Trenord"
        m["Frecce: go to the Frecciadesk or customer service in the station as soon as you notice, staff can have your seat checked. Regional and Intercity: found items are usually handed to the lost property office of the town where the train terminates."] = "Frecce: ve al Frecciadesk o a la atención al cliente de la estación en cuanto te des cuenta, el personal puede hacer revisar tu asiento. Regionales e Intercity: los objetos encontrados suelen entregarse a la oficina de objetos perdidos del municipio donde termina el tren."
        m["Lost items search service"] = "Servicio de búsqueda de objetos perdidos"
        m["Customer service offices"] = "Oficinas de atención al cliente"
        m["Pronto Italo, daily 7–23: report the item with train number, coach and seat"] = "Pronto Italo, todos los días 7–23: indica el objeto con número de tren, coche y asiento"
        m["Report the loss online"] = "Declarar la pérdida online"
        m["SBB Contact Center, 24 hours"] = "Contact Center de SBB, 24 horas"
        m["On collection you pay CHF 20 (CHF 10 with a GA travelcard); electronics and bulky items CHF 25 (CHF 15). On TILO trains between Italy and Switzerland report to both SBB and Trenord."] = "Al recogerlo pagas 20 CHF (10 CHF con abono general AG); electrónica y objetos voluminosos 25 CHF (15 CHF). En los trenes TILO entre Italia y Suiza avisa tanto a SBB como a Trenord."
        m["Information from the official Trenord, Trenitalia and SBB pages (October 2026): times and procedures may change."] = "Información de las páginas oficiales de Trenord, Trenitalia y SBB (octubre de 2026): horarios y procedimientos pueden cambiar."
        m["Location not available: search a town or station."] = "Ubicación no disponible: busca un municipio o una estación."
        m["Search a town or station above."] = "Busca un municipio o una estación arriba."
        m["Looking for defibrillators…"] = "Buscando desfibriladores…"
        m["Looking for defibrillators within "] = "Buscando desfibriladores en un radio de "
        m["Station "] = "Estación "
        m["Station AED: usually on the outside wall, in a marked case"] = "DEA de la estación: normalmente en la pared exterior, en una caja señalizada"
        m["ferrovienord.it · AEDs in all FERROVIENORD stations"] = "ferrovienord.it · DEA en todas las estaciones FERROVIENORD"
        m["Defibrillator"] = "Desfibrilador"
        m["Emilia-Romagna regional AED register (open data)"] = "Registro regional de DEA de Emilia-Romaña (datos abiertos)"
        m["OpenStreetMap (volunteers): check on site"] = "OpenStreetMap (voluntarios): compruébalo en el lugar"
        m["OpenStreetMap servers are not responding: use the official map below or retry."] = "Los servidores de OpenStreetMap no responden: usa el mapa oficial de abajo o vuelve a intentarlo."
        m["Emergency: call "] = "Emergencia: llama al "
        m["The operator guides you through CPR and tells you where the nearest AED is. AEDs can be used on children too and give voice instructions."] = "El operador te guía en la reanimación y te dice dónde está el DEA más cercano. Los DEA también se pueden usar en niños y dan instrucciones por voz."
        m["Public access"] = "Acceso público"
        m["Always available"] = "Siempre disponible"
        m["Outdoors"] = "Al aire libre"
        m["Nearby defibrillators"] = "Desfibriladores cercanos"
        m["No defibrillator in the open lists here. Call 112: the dispatch centre knows all registered AEDs and guides you."] = "No hay ningún desfibrilador en las listas abiertas aquí. Llama al 112: la central conoce todos los DEA registrados y te guía."
        m["Where to get help nearby"] = "Dónde pedir ayuda cerca"
        m["Emergency departments and pharmacies: many pharmacies have an AED, but it isn't guaranteed."] = "Urgencias y farmacias: muchas farmacias tienen un DEA, pero no está garantizado."
        m["Official maps and sources"] = "Mapas y fuentes oficiales"
        m["AREU Lombardy · AED map (official)"] = "AREU Lombardía · mapa de DEA (oficial)"
        m["Ticino Cuore · AEDs in Ticino"] = "Ticino Cuore · DEA en el Tesino"
        m["FERROVIENORD · station AEDs"] = "FERROVIENORD · DEA de las estaciones"
        m["FERROVIENORD: 125 AEDs installed in 2022–2023 in all its stations, where possible on the outside wall so they can be reached at night, in alarmed cases linked to 112/118 dispatch. Other AEDs come from OpenStreetMap (volunteers): check on site. Trenitalia/RFI, Italo and SBB don't publish a list of station AEDs: ask staff or call 112 (144 in Switzerland)."] = "FERROVIENORD: 125 DEA instalados en 2022–2023 en todas sus estaciones, cuando es posible en la pared exterior para que se puedan alcanzar de noche, en cajas con alarma conectadas a la central 112/118. Los demás DEA proceden de OpenStreetMap (voluntarios): compruébalo en el lugar. Trenitalia/RFI, Italo y SBB no publican una lista de DEA en las estaciones: pregunta al personal o llama al 112 (144 en Suiza)."
        m["Tap again for directions"] = "Toca de nuevo para la ruta"
        m["Searched place"] = "Lugar buscado"
        m["Hospital · ask for help here"] = "Hospital · pide ayuda aquí"
        m["Pharmacy · ask if they have an AED"] = "Farmacia · pregunta si tienen un DEA"
        m["Operator not stated"] = "Gestor no indicado"
        m["Available 24/7"] = "Disponible 24 h"
        m["Restricted access"] = "Acceso restringido"
        m["At or next to a station"] = "En una estación o junto a ella"
        m["Source: "] = "Fuente: "
        m["Get directions"] = "Cómo llegar"
        m["View on MapComplete"] = "Ver en MapComplete"
        m["Nearest defibrillator"] = "Desfibrilador más cercano"
        m["List and map of AEDs · tap to see them"] = "Lista y mapa de los DEA · toca para verlos"
        m["Complete official list"] = "Lista oficial completa"
        m["⏳ Waiting for official AREU data: Binario has asked to use Lombardy's official defibrillator register. Until permission arrives the list below may be incomplete: open the official AREU map to see them all."] = "⏳ A la espera de los datos oficiales de AREU: Binario ha pedido usar el registro oficial de desfibriladores de Lombardía. Hasta que llegue la autorización la lista de abajo puede estar incompleta: abre el mapa oficial de AREU para verlos todos."
        m["Below are the AEDs from open lists (OpenStreetMap, FERROVIENORD, Emilia-Romagna register)."] = "Abajo están los DEA de las listas abiertas (OpenStreetMap, FERROVIENORD, registro de Emilia-Romaña)."
        m["Official AREU map"] = "Mapa oficial de AREU"
        m["Ticino Cuore map"] = "Mapa de Ticino Cuore"
        m["Search Google Maps"] = "Buscar en Google Maps"
        m["Station coordinates not available: search a town or station."] = "Coordenadas de la estación no disponibles: busca un municipio o una estación."
        m["Location not available: turn on GPS or search a town or station."] = "Ubicación no disponible: activa el GPS o busca un municipio o una estación."
        m["Location permission needed, or search a town or station."] = "Se necesita el permiso de ubicación, o busca un municipio o una estación."
        m["Looking for public toilets within"] = "Buscando aseos públicos en un radio de"
        m["Place not found: try the town or station name."] = "Lugar no encontrado: prueba con el nombre del municipio o de la estación."
        m["Accessible"] = "Accesible"
        m["Baby changing"] = "Cambiador"
        m["Open to all"] = "Abierto a todos"
        m["near"] = "cerca de"
        m["No public toilets mapped here with these filters."] = "No hay aseos públicos en el mapa aquí con estos filtros."
        m["Data © OpenStreetMap, the same as the MapComplete \"Public toilets\" map ("] = "Datos © OpenStreetMap, los mismos del mapa \"Aseos públicos\" de MapComplete ("
        m["Prices, hours and accessibility are entered by volunteers: check on site. If something is wrong you can fix it via \"View on MapComplete\"."] = "Precios, horarios y accesibilidad los introducen voluntarios: compruébalo en el lugar. Si algo está mal puedes corregirlo con \"Ver en MapComplete\"."
        m["Public toilet"] = "Aseo público"
        m["♿ Wheelchair accessible"] = "♿ Accesible en silla de ruedas"
        m["♿ Partly accessible"] = "♿ Parcialmente accesible"
        m["Not wheelchair accessible"] = "No accesible en silla de ruedas"
        m["🚼 Baby changing table"] = "🚼 Cambiador para bebés"
        m["Unisex"] = "Unisex"
        m["Men and women"] = "Hombres y mujeres"
        m["Men only"] = "Solo hombres"
        m["Women only"] = "Solo mujeres"
        m["Seated and urinals"] = "Inodoros y urinarios"
        m["Urinals only"] = "Solo urinarios"
        m["Squat toilet"] = "Turca"
        m["Seated"] = "Inodoro"
        m["toilet paper"] = "papel higiénico"
        m["hand washing"] = "lavamanos"
        m["With "] = "Con "
        m["Customers only"] = "Solo clientes"
        m["Not open to the public"] = "No abierto al público"
        m["Level"] = "Planta"
        m["Operated by"] = "Gestionado por"
        m["Calculation failed"] = "Error en el cálculo"
        m["Edit"] = "Editar"
        m["Every day (round trip)"] = "Cada día (ida y vuelta)"
    }

    private fun p4(m: HashMap<String, String>) {
        m["of CO₂ saved"] = "de CO₂ ahorrado"
        m["saved"] = "ahorrado"
        m["extra cost"] = "gasto adicional"
        m["Travel time (one way)"] = "Tiempo de viaje (ida)"
        m["avg delay"] = "retraso medio"
        m["Car"] = "Coche"
        m["free flow"] = "tráfico fluido"
        m["rush hour"] = "hora punta"
        m["Daily breakdown (round trip)"] = "Desglose diario (ida y vuelta)"
        m["yours"] = "tuyo"
        m["Road distance"] = "Distancia por carretera"
        m["of which tolled"] = "de ella con peaje"
        m["Consumption"] = "Consumo"
        m["Fuel"] = "Combustible"
        m["Motorway tolls"] = "Peajes de autopista"
        m[" (estimate)"] = " (estimación)"
        m["Parking"] = "Aparcamiento"
        m["Car total"] = "Total coche"
        m["Train (daily share of pass)"] = "Tren (parte diaria del abono)"
        m["Tap an item with ✎ to enter your own value: everything is recalculated at once and saved."] = "Toca un elemento con ✎ para introducir tu propio valor: todo se recalcula al momento y se guarda."
        m["Car CO₂"] = "CO₂ del coche"
        m["Train CO₂"] = "CO₂ del tren"
        m["CO₂ avoided"] = "CO₂ evitado"
        m["Road distance (one way)"] = "Distancia por carretera (ida)"
        m["Tolls per day (round trip)"] = "Peajes al día (ida y vuelta)"
        m["Fuel price"] = "Precio del combustible"
        m["Parking per day"] = "Aparcamiento al día"
        m["Train pass per month"] = "Abono de tren al mes"
        m["Car consumption"] = "Consumo del coche"
        m["Back to the app's estimate"] = "Volver a la estimación de la app"
        m["Save and recalculate"] = "Guardar y recalcular"
        m["Trip and delay log"] = "Registro de viajes y retrasos"
        m[" · avg delay "] = " · retraso medio "
        m[" · max "] = " · máx. "
        m["Remove today"] = "Quitar hoy"
        m["out "] = "ida "
        m["  back "] = "  vuelta "
        m["On travel days after 9 pm the app automatically logs the delays of your usual trains."] = "En los días de viaje, después de las 21, la app registra automáticamente los retrasos de tus trenes habituales."
        m["Your commute"] = "Tu trayecto diario"
        m["choose"] = "elegir"
        m["To: "] = "A: "
        m["Outbound train"] = "Tren de ida"
        m["Return train"] = "Tren de vuelta"
        m["Travel days"] = "Días de viaje"
        m["M"] = "L"
        m["W"] = "X"
        m["T"] = "M"
        m["F"] = "V"
        m["S"] = "S"
        m["Car fuel"] = "Combustible del coche"
        m["Consumption l/100 km"] = "Consumo l/100 km"
        m["Parking € per day"] = "Aparcamiento € al día"
        m["Train pass € per month"] = "Abono de tren € al mes"
        m["Calculate"] = "Calcular"
        m["A network error occurred. Please try again."] = "Se ha producido un error de red. Vuelve a intentarlo."
        m[". You can follow the train with voice alerts."] = ". Puedes seguir el tren con avisos de voz."
        m["Ask about a train, station or route"] = "Pregunta por un tren, una estación o un trayecto"
        m["Speech recognition is not available on this phone. Install or enable the Google app."] = "El reconocimiento de voz no está disponible en este teléfono. Instala o activa la app de Google."
        m["Read aloud on"] = "Lectura en voz alta activada"
        m["Read aloud off"] = "Lectura en voz alta desactivada"
        m["Open train"] = "Abrir tren"
        m["Following the train. I will give you voice alerts."] = "Siguiendo el tren. Te daré avisos de voz."
        m["Follow with voice alerts"] = "Seguir con avisos de voz"
        m["Open station"] = "Abrir estación"
        m["Where is my train?"] = "¿Dónde está mi tren?"
        m["Any strikes?"] = "¿Hay huelgas?"
        m["Can I bring my bike?"] = "¿Puedo llevar mi bicicleta?"
        m["Disability assistance"] = "Asistencia a personas con discapacidad"
        m["e.g. delay train 2070"] = "p. ej. retraso tren 2070"
        m["Speak: ask a question"] = "Habla: haz una pregunta"
        m["Finding the station…"] = "Buscando la estación…"
        m["Search a station or town above."] = "Busca una estación o un municipio arriba."
        m["Location not available: search a station."] = "Ubicación no disponible: busca una estación."
        m["No station found."] = "No se ha encontrado ninguna estación."
        m["Place not found: try the station name."] = "Lugar no encontrado: prueba con el nombre de la estación."
        m["Looking for replacement buses at"] = "Buscando autobuses sustitutivos en"
        m["Other operators"] = "Otras compañías"
        m["Replacement bus stop"] = "Parada del autobús sustitutivo"
        m["Replacement buses in the next 6 hours"] = "Autobuses sustitutivos en las próximas 6 horas"
        m["Timetable services are not responding: retry or check the official pages below."] = "Los servicios de horarios no responden: vuelve a intentarlo o consulta las páginas oficiales de abajo."
        m["No replacement buses scheduled here in the next hours according to official timetables. After sudden disruptions buses may not be in the timetables yet: check the official pages and station announcements."] = "Según los horarios oficiales, no hay autobuses sustitutivos programados aquí en las próximas horas. Tras incidencias repentinas los autobuses pueden no estar todavía en los horarios: consulta las páginas oficiales y los anuncios de la estación."
        m["Sources: official GTFS timetables of Trenord, Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements."] = "Fuentes: horarios oficiales GTFS de Trenord, Trenitalia y SBB a través de Transitous (transitous.org); autobuses del panel de ViaggiaTreno (RFI). Cada viaje muestra su fuente. Los horarios son programados: durante las incidencias sigue los anuncios de la estación."
        m["Board at: "] = "Sube en: "
        m[" from the station"] = " de la estación"
        m["Bay / platform: "] = "Dársena / andén: "
        m["Real time"] = "Tiempo real"
        m["Scheduled time"] = "Hora programada"
        m["Directions to the stop"] = "Cómo llegar a la parada"
        m["My region"] = "Mi región"
        m["My route and times"] = "Mi trayecto y horarios"
        m["National strikes and in: "] = "Huelgas nacionales y en: "
        m["back "] = "vuelta "
        m["Set your route and the time of your outbound and/or return train"] = "Configura tu trayecto y la hora de tu tren de ida y/o de vuelta"
        m["Mon"] = "Lun"
        m["Tue"] = "Mar"
        m["Wed"] = "Mié"
        m["Thu"] = "Jue"
        m["Fri"] = "Vie"
        m["Sat"] = "Sáb"
        m["Sun"] = "Dom"
        m["Mon–Fri"] = "Lun–Vie"
        m["every day"] = "todos los días"
        m["My route"] = "Mi trayecto"
        m["Out "] = "Ida "
        m["Back "] = "Vuelta "
        m["No outbound"] = "Sin ida"
        m["No return"] = "Sin vuelta"
        m["Days"] = "Días"
        m["Operators you use"] = "Compañías que usas"
        m["Regions (also for the \"My region\" filter)"] = "Regiones (también para el filtro \"Mi región\")"
        m["A strike shows in \"My route\" if it is national or in one of your regions, involves one of your operators (or all) and its hours cover your outbound or return train on one of your travel days."] = "Una huelga aparece en \"Mi trayecto\" si es nacional o en una de tus regiones, afecta a una de tus compañías (o a todas) y su horario cubre tu tren de ida o de vuelta en uno de tus días de viaje."
        m["arrival at "] = "llegada a las "
        m["Arrival "] = "Llegada "
        m["Departure "] = "Salida "
        m["On Xiaomi: Settings → Apps → Binario → Battery saver → No restrictions, and also enable \"Autostart\"."] = "En Xiaomi: Ajustes → Aplicaciones → Binario → Ahorro de batería → Sin restricciones, y activa también \"Inicio automático\"."
        m["On Oppo, Realme and OnePlus: Settings → Apps → Binario → Battery usage → allow background activity and auto launch."] = "En Oppo, Realme y OnePlus: Ajustes → Aplicaciones → Binario → Uso de la batería → permitir la actividad en segundo plano y el inicio automático."
        m["On Huawei and Honor: Settings → Battery → App launch → Binario → manage manually, with all three options on."] = "En Huawei y Honor: Ajustes → Batería → Inicio de aplicaciones → Binario → gestionar manualmente, con las tres opciones activadas."
        m["On Samsung: Settings → Apps → Binario → Battery → Unrestricted, and remove Binario from \"Sleeping apps\"."] = "En Samsung: Ajustes → Aplicaciones → Binario → Batería → Sin restricciones, y quita Binario de \"Aplicaciones en suspensión\"."
        m["On Vivo: Settings → Battery → Background power consumption → allow Binario."] = "En Vivo: Ajustes → Batería → Consumo de energía en segundo plano → permitir Binario."
        m["If the followed train stops by itself: Settings → Apps → Binario → Battery → Unrestricted."] = "Si el tren seguido se detiene solo: Ajustes → Aplicaciones → Binario → Batería → Sin restricciones."
        m["Alerts even with the app closed"] = "Avisos incluso con la app cerrada"
        m["The train is followed even with Binario closed. Some phones, however, stop the alerts after a while to save battery. To avoid missing platform, delays and the wake-up alarm, allow Binario to run without battery restrictions: consumption stays low and it stops by itself on arrival."] = "El tren se sigue incluso con Binario cerrada. Sin embargo, algunos teléfonos detienen los avisos al cabo de un rato para ahorrar batería. Para no perderte la vía, los retrasos y la alarma de parada, permite que Binario funcione sin restricciones de batería: el consumo sigue siendo bajo y se detiene sola al llegar."
        m["Guide for your phone"] = "Guía para tu teléfono"
        m["Not now"] = "Ahora no"
        m["Infrastructure manager of the Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa and Brescia–Iseo–Edolo network. Trains are run by Trenord."] = "Gestor de la infraestructura de la red Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa y Brescia–Iseo–Edolo. Los trenes los opera Trenord."
        m["Lifts and escalators out of service"] = "Ascensores y escaleras mecánicas fuera de servicio"
        m["The FERROVIENORD site is not responding. Open the official page or retry."] = "La web de FERROVIENORD no responde. Abre la página oficial o vuelve a intentarlo."
        m["No equipment reported out of service."] = "No se han señalado equipos fuera de servicio."
        m["No equipment out of service at this station."] = "No hay equipos fuera de servicio en esta estación."
        m["Platform not accessible: "] = "Andén no accesible: "
        m["Out of service since "] = "Fuera de servicio desde "
        m["Expected back: "] = "Vuelta prevista: "
        m["Source: ferrovienord.it · Station accessibility notices (read now, refreshed every 30 minutes)."] = "Fuente: ferrovienord.it · Avisos de accesibilidad de las estaciones (leídos ahora, actualizados cada 30 minutos)."
        m["Accessibility and assistance"] = "Accesibilidad y asistencia"
        m["Live lift and escalator status"] = "Estado en directo de ascensores y escaleras mecánicas"
        m["Assistance for disabled passengers: 800 210 955"] = "Asistencia a viajeros con discapacidad: 800 210 955"
        m["Trenord/FERROVIENORD free number · book at least 48 hours ahead"] = "Número gratuito Trenord/FERROVIENORD · reserva con al menos 48 horas de antelación"
        m["Assistance request by email"] = "Solicitud de asistencia por correo"
        m["Book assistance online"] = "Reservar asistencia online"
        m["Station accessibility sheets · Milan branches"] = "Fichas de accesibilidad de las estaciones · ramales de Milán"
        m["Station accessibility sheets · Brescia–Iseo–Edolo"] = "Fichas de accesibilidad de las estaciones · Brescia–Iseo–Edolo"
        m["Station accessibility and reduced mobility"] = "Accesibilidad de las estaciones y movilidad reducida"
        m["Every FERROVIENORD station has a defibrillator (125 installed in 2022–2023): where possible on the outside wall so it can be reached at night, in an alarmed, marked case with a first-aid kit. It is remotely monitored and registered with the regional emergency centres. It can be used on children too. In an emergency call 112."] = "Cada estación FERROVIENORD tiene un desfibrilador (125 instalados en 2022–2023): cuando es posible en la pared exterior para que se pueda alcanzar de noche, en una caja señalizada con alarma y botiquín. Está supervisado a distancia y registrado en las centrales regionales de emergencia. También se puede usar en niños. En caso de emergencia llama al 112."
        m["Map of nearby defibrillators"] = "Mapa de desfibriladores cercanos"
        m["FERROVIENORD stations and other AEDs"] = "Estaciones FERROVIENORD y otros DEA"
        m["Defibrillators page"] = "Página de desfibriladores"
        m["Network documents (PIR web)"] = "Documentos de la red (PIR web)"
        m["Service quality indicators 2026"] = "Indicadores de calidad del servicio 2026"
        m["Line and facility characteristics"] = "Características de líneas e instalaciones"
        m["Station usage plan"] = "Plan de uso de las estaciones"
        m["Station upgrades for reduced mobility"] = "Adaptación de estaciones para movilidad reducida"
        m["Network statement"] = "Declaración sobre la red"
        m["All documents"] = "Todos los documentos"
        m["Sources: ferrovienord.it (PIR web, station accessibility notices, defibrillators) and trenord.it (assistance). Restore dates are the manager's estimates."] = "Fuentes: ferrovienord.it (PIR web, avisos de accesibilidad de las estaciones, desfibriladores) y trenord.it (asistencia). Las fechas de vuelta al servicio son estimaciones del gestor."
        m["Customer service"] = "Atención al cliente"
        m["Validators & more"] = "Validadoras y más"
        m[" (open/closed from Trenord)"] = " (abierto/cerrado según Trenord)"
        m["trenitalia.com · Customer service offices (April 2025 hours)"] = "trenitalia.com · Oficinas de atención al cliente (horario de abril de 2025)"
        m["italotreno.com · Station ticket offices"] = "italotreno.com · Taquillas en las estaciones"
        m["SBB open data (data.sbb.ch)"] = "Datos abiertos de SBB (data.sbb.ch)"
        m["Loading sales points…"] = "Cargando puntos de venta…"
        m["you"] = "tú"
        m["nearest to"] = "más cercano a"
        m["Trenord sales points are in Lombardy. Nearby: SBB machines, altoadigemobilità and OpenStreetMap points; elsewhere in Italy use the official Trenitalia map (at the bottom)."] = "Los puntos de venta de Trenord están en Lombardía. Cerca: máquinas SBB, altoadigemobilità y puntos de OpenStreetMap; en el resto de Italia usa el mapa oficial de Trenitalia (abajo)."
        m["Open/closed updated now from Trenord for the province of"] = "Abierto/cerrado actualizado ahora según Trenord para la provincia de"
        m["No sales points found."] = "No se han encontrado puntos de venta."
        m["Showing the nearest 300: search a town or station for the others."] = "Se muestran los 300 más cercanos: busca un municipio o una estación para ver los demás."
        m["Distance: "] = "Distancia: "
        m["Sells: "] = "Vende: "
        m["Weekly opening hours"] = "Horario semanal"
        m["Visit the page"] = "Visitar la página"
        m["Card"] = "Tarjeta"
        m["Coins"] = "Monedas"
        m[", limited operation"] = ", funcionamiento limitado"
        m["*Limited operation"] = "*Funcionamiento limitado"
        m["closed"] = "cerrado"
        m["Trenord offices, machines and resellers"] = "Oficinas, máquinas y revendedores de Trenord"
        m["open/closed read now"] = "abierto/cerrado leído ahora"
        m["SBB ticket machines (data.sbb.ch)"] = "Máquinas expendedoras SBB (data.sbb.ch)"
        m["other points from"] = "otros puntos de"
        m["1 machine"] = "1 máquina"
        m["machines"] = "máquinas"
        m["Overview"] = "Resumen"
        m["Statistics not available right now."] = "Estadísticas no disponibles en este momento."
        m["Search station"] = "Buscar estación"
        m["Train number or destination"] = "Número de tren o destino"
        m["Least punctual"] = "Menos puntuales"
        m["Most punctual"] = "Más puntuales"
        m["FerrovieNord network"] = "Red FerrovieNord"
        m["Milan Passante"] = "Passante de Milán"
        m["collected by the app · "] = "recopilado por la app · "
        m[" days"] = " días"
        m["No results"] = "Sin resultados"
        m["on time (within 5 min)"] = "puntuales (en 5 min)"
        m[" points vs "] = " puntos frente a "
        m["arrivals observed"] = "llegadas observadas"
        m["cancelled runs"] = "trenes cancelados"
        m["Avg delay "] = "Retraso medio "
        m[" arrivals"] = " llegadas"
        m[" cancelled"] = " cancelados"
        m[" trains"] = " trenes"
        m["Your trains"] = "Tus trenes"
        m["Your stations"] = "Tus estaciones"
        m["Switzerland · SBB"] = "Suiza · SBB"
        m["SBB data not reachable right now."] = "Datos de SBB no disponibles en este momento."
        m[" stop arrivals"] = " llegadas a paradas"
        m[" cancelled stops"] = " paradas canceladas"
        m["Data for "] = "Datos del "
        m["Average of "] = "Media de "
        m[" days ("] = " días ("
        m["Why BLS, SOB, Rhaetian Railway and the other Swiss companies are missing"] = "Por qué faltan BLS, SOB, el Ferrocarril Rético y las demás compañías suizas"
        m["FerrovieNord network · Trenord"] = "Red FerrovieNord · Trenord"
        m["Collection just started: first data after a few hours, reliable figures after a couple of weeks."] = "Recopilación recién iniciada: primeros datos en unas horas, cifras fiables en un par de semanas."
        m["Today's data"] = "Datos de hoy"
        m["Last "] = "Últimos "
        m[" days collected ("] = " días recopilados ("
        m["Stations are in the Stations tab (FerrovieNord filter)."] = "Las estaciones están en la pestaña Estaciones (filtro FerrovieNord)."
        m["Collection on"] = "Recopilación del"
        m[" runs"] = " trenes"
        m[" severe delays"] = " retrasos graves"
        m["recent days (collected by the app)"] = "últimos días (recopilados por la app)"
        m[" runs observed"] = " trenes observados"
        m["Recent punctuality (FN network): "] = "Puntualidad reciente (red FN): "
        m["Last month punctuality: "] = "Puntualidad del mes pasado: "
        m["avg delay "] = "retraso medio "
        m[". On time = arrival within 5 minutes."] = ". Puntual = llegada en 5 minutos."
        m["How shall I find your train? Type its number, or I find the station nearest to you, or pick a station and time."] = "¿Cómo busco tu tren? Escribe su número, o busco la estación más cercana a ti, o elige una estación y una hora."
        m["No sign-up needed and your data stays on the phone. To send you alerts I need permission for notifications: tap Allow."] = "No hace falta registrarse y tus datos se quedan en el teléfono. Para enviarte avisos necesito el permiso de notificaciones: toca Permitir."
        m["Without notifications I can only update you here in the app. You can turn them on any time in the phone settings."] = "Sin notificaciones solo puedo informarte aquí en la app. Puedes activarlas cuando quieras en los ajustes del teléfono."
        m["I found this train: is it yours?"] = "He encontrado este tren: ¿es el tuyo?"
        m["I can't connect. Check your connection and try again."] = "No consigo conectarme. Comprueba la conexión y vuelve a intentarlo."
        m["plat. "] = "vía "
        m["Without location I can't find the nearby station: pick the station yourself."] = "Sin ubicación no puedo encontrar la estación cercana: elige tú la estación."
        m["I can't find your location. Turn on location or pick the station."] = "No encuentro tu ubicación. Activa la ubicación o elige la estación."
        m["Station list unavailable, try again."] = "Lista de estaciones no disponible, vuelve a intentarlo."
        m["I can't answer right now: check your connection."] = "No puedo responder ahora: comprueba la conexión."
        m["They said: "] = "Han dicho: "
        m["Hold the phone close to the speaker"] = "Acerca el teléfono a quien habla"
        m["Say the train number or ask a question"] = "Di el número del tren o haz una pregunta"
        m["Speech recognition isn't available on this phone: install or enable the Google app."] = "El reconocimiento de voz no está disponible en este teléfono: instala o activa la app de Google."
        m["I can't read this train's data right now. Try again shortly."] = "No puedo leer los datos de este tren ahora. Vuelve a intentarlo en un momento."
        m["Where do you board?"] = "¿Dónde subes?"
        m["I'll alert you when the platform is announced or changes, if the delay grows, if the train is cancelled"] = "Te avisaré cuando se anuncie o cambie la vía, si aumenta el retraso, si el tren se cancela"
        m[", and on arrival I'll send you a summary. Everything is in the ongoing notification too."] = ", y al llegar te enviaré un resumen. Todo está también en la notificación fija."
        m["Trip completed: I'm no longer following the train. Want to follow another one?"] = "Viaje terminado: ya no sigo el tren. ¿Quieres seguir otro?"
        m["OK, no more updates on this train."] = "De acuerdo, no más avisos sobre este tren."
        m["Where do you get off? I'll warn you before the stop."] = "¿Dónde bajas? Te avisaré antes de la parada."
        m["To the terminus"] = "Hasta la estación final"
        m["No alarm needed: follow to the terminus"] = "Sin alarma: seguir hasta la estación final"
        m["+1 hour"] = "+1 hora"
        m["+2 hours"] = "+2 horas"
        m["+3 hours"] = "+3 horas"
        m["Pick time"] = "Elegir hora"
        m["Type or say the train number (it's on your ticket or the board)."] = "Escribe o di el número del tren (está en tu billete o en el panel)."
        m["Station and time"] = "Estación y hora"
        m["Follow another train"] = "Seguir otro tren"
        m["Delayed? Your rights"] = "¿Retraso? Tus derechos"
        m["Transcribe speech"] = "Transcribir lo que se dice"
        m["Let the phone speak"] = "Que hable el teléfono"
        m["Train number, e.g. 2070"] = "Número de tren, p. ej. 2070"
        m["Type a train number or a question"] = "Escribe un número de tren o una pregunta"
        m["Speak"] = "Hablar"
        m["Which station do you leave from?"] = "¿De qué estación sales?"
        m["platform "] = "vía "
        m["platform not yet announced"] = "vía aún no anunciada"
        m["Next stop: "] = "Próxima parada: "
        m["Last seen: "] = "Visto por última vez: "
        m["They said"] = "Han dicho"
        m["I am deaf: could you please write it down?"] = "Soy sordo: ¿podría escribirlo, por favor?"
        m["Which platform does the train leave from?"] = "¿De qué vía sale el tren?"
        m["Could you tell me when we reach my stop?"] = "¿Podría avisarme cuando lleguemos a mi parada?"
        m["How late is the train?"] = "¿Cuánto retraso lleva el tren?"
        m["Where can I buy a ticket?"] = "¿Dónde puedo comprar un billete?"
        m["Show the screen to the person in front of you: the phone is also reading it aloud."] = "Muestra la pantalla a la persona que tienes delante: el teléfono también lo lee en voz alta."
        m["Type what you want to say"] = "Escribe lo que quieres decir"
        m["Ready phrases"] = "Frases listas"
        m["Read aloud"] = "Leer en voz alta"
        m["Assistance is free, in the station and for getting on and off the train."] = "La asistencia es gratuita, en la estación y para subir y bajar del tren."
        m["It covers wheelchair users and people with walking difficulties (even temporary), blind or partially sighted, deaf or with communication difficulties, people with intellectual or mental disabilities, older people and pregnant women."] = "Es para usuarios de silla de ruedas y personas con dificultades para caminar (también temporales), ciegas o con baja visión, sordas o con dificultades de comunicación, personas con discapacidad intelectual o psíquica, personas mayores y embarazadas."
        m["Who to call depends on the station and train: at RFI stations (almost all Italian stations) the Sale Blu assist for every operator; at FerrovieNord stations Trenord does; in Switzerland, SBB."] = "A quién llamar depende de la estación y del tren: en las estaciones RFI (casi todas las de Italia) las Sale Blu atienden a todas las compañías; en las estaciones FerrovieNord, Trenord; en Suiza, SBB."
        m["RFI Sale Blu · Trenitalia, Italo, Trenord at RFI stations"] = "Sale Blu de RFI · Trenitalia, Italo, Trenord en estaciones RFI"
        m["Toll-free from landlines · daily 6:45–21:30"] = "Gratuito desde fijos · todos los días 6:45–21:30"
        m["From mobiles and abroad (standard rate)"] = "Desde móviles y el extranjero (tarifa normal)"
        m["At least 6 hours before: stations, date, train, type of assistance, phone"] = "Al menos 6 horas antes: estaciones, fecha, tren, tipo de asistencia, teléfono"
        m["SalaBlu Online and SalaBlu+ app"] = "SalaBlu Online y app SalaBlu+"
        m["Booking up to 3 hours before; chat for deaf people"] = "Reserva hasta 3 horas antes; chat para personas sordas"
        m["How far ahead: at major stations (e.g. Milano Porta Garibaldi) up to 1 hour before for trains between 7:45 and 22:30; at other stations and at night at least 12 hours before. Groups of 3+: 24 hours. Trips abroad: 24–48 hours."] = "Con cuánta antelación: en las grandes estaciones (p. ej. Milano Porta Garibaldi) hasta 1 hora antes para trenes entre las 7:45 y las 22:30; en las demás estaciones y de noche al menos 12 horas antes. Grupos de 3 o más: 24 horas. Viajes al extranjero: 24–48 horas."
        m["Be at the meeting point at least 30 minutes before: staff wear orange vests. To cancel, give at least 4 hours' notice."] = "Estate en el punto de encuentro al menos 30 minutos antes: el personal lleva chaleco naranja. Para cancelar, avisa con al menos 4 horas de antelación."
        m["Trenord and FerrovieNord stations"] = "Estaciones Trenord y FerrovieNord"
        m["Trenord assistance toll-free · book preferably 48 hours ahead"] = "Número gratuito de asistencia de Trenord · reserva preferiblemente con 48 horas de antelación"
        m["Trenord contact centre (also from mobiles)"] = "Contact center de Trenord (también desde móviles)"
        m["Information and bookings"] = "Información y reservas"
        m["Report barriers between train and station"] = "Señalar barreras entre tren y estación"
        m["Pronto Italo · daily 7–23: suitable seat and assistance booking (provided in station by RFI)"] = "Pronto Italo · todos los días 7–23: asiento adecuado y reserva de asistencia (prestada en la estación por RFI)"
        m["Italo assistance page"] = "Página de asistencia de Italo"
        m["SBB Contact Center Handicap from Italy · daily 5–24 (from Switzerland 0800 007 102, free)"] = "SBB Contact Center Handicap desde Italia · todos los días 5–24 (desde Suiza 0800 007 102, gratis)"
        m["Book online"] = "Reservar online"
        m["swisspass.ch/handicap · at least 1 hour before (international trips 24 hours)"] = "swisspass.ch/handicap · al menos 1 hora antes (viajes internacionales 24 horas)"
        m["Tips by type of disability"] = "Consejos según el tipo de discapacidad"
        m["Wheelchair: boarding with ramp or lift. Wheelchair at most 70 cm wide, 120 cm long and 250 kg including the person. The station screen shows lifts per platform and current faults."] = "Silla de ruedas: subida con rampa o elevador. Silla de máximo 70 cm de ancho, 120 cm de largo y 250 kg con la persona. La pantalla de la estación muestra los ascensores por vía y las averías actuales."
    }

    private fun p5(m: HashMap<String, String>) {
        m["Wi-Fi and sockets: on Frecce and Italo on-board Wi-Fi is free and there are power sockets at the seats. Regional trains usually have no Wi-Fi and only some new trains have sockets. In Switzerland many SBB stations have free Wi-Fi."] = "Wi-Fi y enchufes: en los Frecce y en Italo el Wi-Fi a bordo es gratuito y hay enchufes en los asientos. Los trenes regionales normalmente no tienen Wi-Fi y solo algunos trenes nuevos tienen enchufes. En Suiza muchas estaciones de SBB tienen Wi-Fi gratuito."
        m["Seats: on Frecce, Intercity and Italo the seat is assigned with the ticket and you can choose it when buying (window, aisle…). Regional trains (Trenord, Trenitalia Regional, TILO) have no reservations: you sit wherever there is room."] = "Asientos: en los Frecce, los Intercity e Italo el asiento va asignado con el billete y puedes elegirlo al comprar (ventanilla, pasillo…). En los trenes regionales (Trenord, Trenitalia Regional, TILO) no se reserva: te sientas donde haya sitio."
        m["First class: Frecciarossa trains have Standard, Premium, Business and Executive levels; Italo has Smart, Comfort, Prima and Club Executive. Many Trenord regional trains have 1st class, with a supplement of €2.80 per trip (€31 a month, €310 a year with a pass). In the search results you can see 1st-class prices with the \"1st class\" selector."] = "Primera clase: el Frecciarossa tiene los niveles Standard, Premium, Business y Executive; Italo tiene Smart, Comfort, Prima y Club Executive. Muchos trenes regionales de Trenord tienen 1.ª clase, con un suplemento de 2,80 € por viaje (31 € al mes, 310 € al año con abono). En los resultados de búsqueda ves los precios de 1.ª clase con el selector \"1.ª clase\"."
        m["Ticket validity: it depends on the ticket. STIBM area (Milan and surroundings): 75 minutes for 2 zones, 90 minutes in the city, longer with more zones. Arcobaleno/Trenord cross-border tickets: 4 hours for the whole trip. Digital regional tickets are valid for the day or train shown; paper ones must be validated before boarding. Frecce and Italo: valid for the booked train."] = "Validez del billete: depende del billete. Área STIBM (Milán y alrededores): 75 minutos para 2 zonas, 90 minutos en la ciudad, más con más zonas. Billetes transfronterizos Arcobaleno/Trenord: 4 horas para todo el viaje. Los billetes regionales digitales valen para el día o el tren indicados; los de papel se validan antes de subir. Frecce e Italo: valen para el tren reservado."
        m["Parking: many stations have a car park (often paid) and bike racks or bike stations. The app does not list car parks yet: open the map from the station screen and search for \"parking\"."] = "Aparcamiento: muchas estaciones tienen aparcamiento (a menudo de pago) y aparcabicis o estaciones de bicis. La app aún no muestra los aparcamientos: abre el mapa desde la ficha de la estación y busca \"aparcamiento\"."
        m["Night trains: Trenitalia runs Intercity Notte trains (for example to southern Italy and Sicily); ÖBB Nightjets link Italy with Austria and Germany; in Ticino there is the TILO Pigiama night service on some nights. Search the route with an evening time."] = "Trenes nocturnos: Trenitalia tiene los Intercity Notte (por ejemplo hacia el sur de Italia y Sicilia); los Nightjet de ÖBB unen Italia con Austria y Alemania; en el Tesino hay algunas noches el servicio nocturno TILO Pigiama. Busca el trayecto con una hora de la tarde-noche."
        m["Italo (NTV) is the private high-speed operator, on the high-speed lines between Turin, Milan, Venice, Bologna, Florence, Rome and Naples. Tickets are sold on italotreno.com, in the app, at Italo ticket offices and machines in stations; levels are Smart, Comfort, Prima and Club Executive. Binario shows Italo trains in the solutions and in real time. Pronto Italo: 06 07 08."] = "Italo (NTV) es la compañía privada de alta velocidad, en las líneas de alta velocidad entre Turín, Milán, Venecia, Bolonia, Florencia, Roma y Nápoles. Los billetes se venden en italotreno.com, en la app, en las taquillas y máquinas de Italo en las estaciones; los niveles son Smart, Comfort, Prima y Club Executive. Binario muestra los trenes Italo en las soluciones y en tiempo real. Pronto Italo: 06 07 08."
        m["Food and drink: on every train you can eat and drink what you bring. Frecce have a bar/FRECCIABistrò, Italo offers snacks and drinks; regional trains have no catering."] = "Comida y bebida: en todos los trenes puedes comer y beber lo que lleves. Los Frecce tienen bar/FRECCIABistrò, Italo ofrece snacks y bebidas; los trenes regionales no tienen servicio de restauración."
        m["Smoking is forbidden on all trains and in enclosed station areas, e-cigarettes on board included. Smokers risk a fine."] = "Está prohibido fumar en todos los trenes y en las zonas cerradas de las estaciones, también el cigarrillo electrónico a bordo. Quien fuma se arriesga a una multa."
        m["Discounts: Trenitalia has Economy and Super Economy fares (limited seats), discounts for young people and over-60s with CartaFRECCIA, and group offers. Italo has Low Cost and Economy fares and the Italo Più programme. In Lombardy Trenord has reduced passes for under-26s and over-65s and the Io Viaggio in Famiglia family discount. The app's \"Best prices\" calendar shows the lowest prices by time of day."] = "Descuentos: Trenitalia tiene las tarifas Economy y Super Economy (plazas limitadas), descuentos para jóvenes y mayores de 60 con CartaFRECCIA y ofertas para grupos. Italo tiene las tarifas Low Cost y Economy y el programa Italo Più. En Lombardía, Trenord tiene abonos reducidos para menores de 26 y mayores de 65 y el descuento familiar Io Viaggio in Famiglia. El calendario \"Mejores precios\" de la app muestra los precios más bajos por franja horaria."
        m["Groups: Trenitalia and Italo have group offers (usually from 10 people, to be requested in advance); Trenord has tickets for groups and school classes. Conditions and forms are on the operators' websites."] = "Grupos: Trenitalia e Italo tienen ofertas para grupos (normalmente a partir de 10 personas, a pedir con antelación); Trenord tiene billetes para grupos y clases escolares. Las condiciones y los formularios están en las webs de las compañías."
        m["Minors travelling alone: the rules differ between operators. In general older children can travel alone with a valid ticket, while young children must be accompanied by an adult. Before travelling check the conditions of carriage of Trenord, Trenitalia or Italo."] = "Menores que viajan solos: las normas cambian según la compañía. En general, los niños mayores pueden viajar solos con un billete válido, mientras que los niños pequeños deben ir acompañados de un adulto. Antes de viajar consulta las condiciones de transporte de Trenord, Trenitalia o Italo."
        m["Digital tickets: no need to print them, just show them on your phone (PDF, app or QR code) with enough battery. Some tickets require check-in or activation before boarding: it is stated on the ticket and in the operator's app."] = "Billetes digitales: no hace falta imprimirlos, basta con enseñarlos en el móvil (PDF, app o código QR) con batería suficiente. Algunos billetes requieren check-in o activación antes de subir: lo indica el billete y la app de la compañía."
        m["Emergency or safety: call 112, the single emergency number. On board use the intercom or emergency button and tell the conductor; in stations there is the Railway Police (Polfer). For a theft report it to the Polfer or Carabinieri and block your cards and phone. The nearest defibrillator is on the Home screen."] = "Emergencia o seguridad: llama al 112, el número único de emergencias. A bordo usa el interfono o el botón de emergencia y avisa al revisor; en las estaciones está la Policía Ferroviaria (Polfer). En caso de robo, denúncialo a la Polfer o a los Carabinieri y bloquea tus tarjetas y el móvil. El desfibrilador más cercano está en la pantalla de inicio."
        m["Payments: ticket machines take cards (also contactless) and often cash; apps and websites take cards, PayPal and digital wallets depending on the operator; ticket offices also take cash. On some lines and metros you can tap a contactless card directly at the validators."] = "Pagos: las máquinas aceptan tarjetas (también contactless) y a menudo efectivo; las apps y webs aceptan tarjetas, PayPal y monederos digitales según la compañía; las taquillas también aceptan efectivo. En algunas líneas y metros puedes pagar directamente en las validadoras con una tarjeta contactless."
        m["Replacement buses: when trains are replaced by buses, Stations → Replacement buses shows stops, times and sources for your station; notices are in News. The bus stop is usually signposted in front of the station."] = "Autobuses sustitutivos: cuando los trenes se sustituyen por autobuses, en Estaciones → Autobuses sustitutivos ves paradas, horarios y fuentes de tu estación; los avisos están en Noticias. La parada del autobús suele estar señalizada delante de la estación."
        m["Language: tap the flag at the top of the Home screen or go to More → Settings → Language. Italian, English, Chinese, German, French, Spanish and Japanese are available; the voice changes language too."] = "Idioma: toca la bandera arriba en la pantalla de inicio o ve a Más → Ajustes → Idioma. Hay italiano, inglés, chino, alemán, francés, español y japonés; la voz también cambia de idioma."
        m["Favourites: tap the star ★ on a train, a station board or a route. You find them in the Trains and Stations tabs, in Quick (recent and favourites) and in the Favourites widget; you can also add them to the Home shortcuts with +."] = "Favoritos: toca la estrella ★ en un tren, en el panel de una estación o en un trayecto. Los encuentras en las pestañas Trenes y Estaciones, en Rápido (recientes y favoritos) y en el widget de Favoritos; también puedes añadirlos a los accesos rápidos de Inicio con +."
        m["Searching a timetable: in the Search tab choose departure and arrival, date and time (and return if needed), then tap Search. The results show times, changes, prices and delays; tap a train for stops and platforms. You can also ask me \"trains from Varese to Milano\"."] = "Buscar un horario: en la pestaña Buscar elige salida y llegada, fecha y hora (y la vuelta si hace falta) y toca Buscar. Los resultados muestran horarios, transbordos, precios y retrasos; toca un tren para ver paradas y vías. También puedes preguntarme \"trenes de Varese a Milano\"."
        m["Ticket on board: on regional trains you buy the ticket before boarding. If the station has no way to buy one (office closed, machine broken), tell the conductor as soon as you board: usually you can pay with a surcharge, but rules differ between operators. The conditions of carriage say when this is possible and how much it costs."] = "Billete a bordo: en los trenes regionales el billete se compra antes de subir. Si en la estación no hay forma de comprarlo (taquilla cerrada, máquina averiada), avisa al revisor nada más subir: normalmente puedes regularizarlo con un recargo, pero las normas cambian según la compañía. Las condiciones de transporte indican cuándo es posible y cuánto cuesta."
        m["Blind or partially sighted: guide dogs travel free; you can ask for a suitable seat when booking. Turn on the spoken option: the app tells you platform, departure and your stop."] = "Personas ciegas o con baja visión: los perros guía viajan gratis; puedes pedir un asiento adecuado al reservar. Activa la opción hablada: la app te dice la vía, la salida y tu parada."
        m["Deaf people: the Sale Blu have a chat (after registering on SalaBlu Online). In My Conductor use \"Transcribe speech\" and \"Let the phone speak\"; turn on vibration and flash alerts."] = "Personas sordas: las Sale Blu tienen un chat (tras registrarte en SalaBlu Online). En Mi Revisor usa \"Transcribir lo que se dice\" y \"Que hable el teléfono\"; activa los avisos con vibración y flash."
        m["Intellectual or mental disabilities, or people who are not self-sufficient: a companion may be needed; staff escort you from the meeting point to the train and connection."] = "Discapacidad intelectual o psíquica, o personas no autosuficientes: puede hacer falta un acompañante; el personal te acompaña desde el punto de encuentro hasta el tren y el transbordo."
        m["Older people, pregnant women, casts or temporary difficulties: assistance is for you too, with a wheelchair on request and help with one piece of hand luggage."] = "Personas mayores, embarazadas, escayolas o dificultades temporales: la asistencia también es para ti, con silla de ruedas si la pides y ayuda con un bulto de equipaje de mano."
        m["Connections: allow at least 30 minutes between trains when booking assistance."] = "Transbordos: deja al menos 30 minutos entre trenes al reservar la asistencia."
        m["Open My Conductor"] = "Abrir Mi Revisor"
        m["Emergency"] = "Emergencias"
        m["Single emergency number (Italy and Switzerland)"] = "Número único de emergencias (Italia y Suiza)"
        m["Numbers and rules from the official RFI, Trenord, Italo and SBB pages (October 2026): if in doubt, check the operator's site."] = "Números y normas de las páginas oficiales de RFI, Trenord, Italo y SBB (octubre de 2026): si tienes dudas, consulta la web de la compañía."
        m["Page"] = "Página"
        m["Changes"] = "Transbordos"
        m["direct"] = "directo"
        m["Downloading outbound…"] = "Descargando la ida…"
        m["Downloading return…"] = "Descargando la vuelta…"
        m["No runs found for that day"] = "No se han encontrado trenes para ese día"
        m["Timetable for"] = "Horario del"
        m["runs"] = "trenes"
        m["No runs found."] = "No se han encontrado trenes."
        m["Real time from the operator · "] = "Tiempo real de la compañía · "
        m["Scheduled times: delays not published by the operator · "] = "Horarios programados: retrasos no publicados por la compañía · "
        m["Departure station not found"] = "Estación de salida no encontrada"
        m["Arrival station not found"] = "Estación de llegada no encontrada"
        m["responds but the format changed"] = "responde pero el formato ha cambiado"
        m["OK (backup server: "] = "OK (servidor de reserva: "
        m["no response"] = "sin respuesta"
        m["Foreign operators (ÖBB, DB)"] = "Compañías extranjeras (ÖBB, DB)"
        m["Replacement bus"] = "Autobús sustitutivo"
        m["SBB timetable (transport.opendata.ch)"] = "Horario SBB (transport.opendata.ch)"
        m["ViaggiaTreno (RFI) · station board"] = "ViaggiaTreno (RFI) · panel de la estación"
        m["Trenord · replacement bus map"] = "Trenord · mapa de autobuses sustitutivos"
        m["RFI · travel updates (works and replacement buses)"] = "RFI · información de viaje (obras y autobuses sustitutivos)"
        m["SBB · S-Bahn and regional"] = "SBB · S-Bahn y regionales"
        m["SBB · InterRegio, InterCity, EuroCity"] = "SBB · InterRegio, InterCity, EuroCity"
        m[" · guaranteed band 6–9 / 18–21"] = " · franja garantizada 6–9 / 18–21"
        m["Incomplete download"] = "Descarga incompleta"
        m["accessible"] = "accesible"
        m["tactile paving"] = "pavimento táctil"
        m["steps"] = "escalones"
        m["handrail"] = "pasamanos"
        m["level "] = "planta "
        m["Hospital"] = "Hospital"
        m["Pharmacy"] = "Farmacia"
        m["emergency department"] = "urgencias"
        m["hospital"] = "hospital"
        m["pharmacy"] = "farmacia"
        m["You are not following any train. Ask for example \"train 2512\" and then tap \"Follow with voice alerts\"."] = "No estás siguiendo ningún tren. Pregunta por ejemplo \"tren 2512\" y luego toca \"Seguir con avisos de voz\"."
        m["Which station? Ask for example \"bus and taxi at Varese\"."] = "¿Qué estación? Pregunta por ejemplo \"autobús y taxi en Varese\"."
        m["Which station? Ask for example \"toilets at Saronno\"."] = "¿Qué estación? Pregunta por ejemplo \"aseos en Saronno\"."
        m["Tell me the train number, for example \"delay train 2512\" or \"platform of 9544\"."] = "Dime el número del tren, por ejemplo \"retraso tren 2512\" o \"vía del 9544\"."
        m["Sorry, I didn't understand. Try one of these topics: "] = "Perdona, no te he entendido. Prueba uno de estos temas: "
        m["lines "] = "líneas "
        m["Toilets: not mapped"] = "Aseos: no están en el mapa"
        m["Toilets: "] = "Aseos: "
        m[", accessible"] = ", accesibles"
        m[", hours "] = ", horario "
        m["Platforms: "] = "Vías: "
        m["Lifts: "] = "Ascensores: "
        m["Ticket office: "] = "Taquilla: "
        m["Ticket machines: "] = "Máquinas expendedoras: "
        m["Validators: "] = "Validadoras: "
        m["Station data not reachable now."] = "Datos de la estación no disponibles ahora."
        m["Train cancelled."] = "Tren cancelado."
        m["Arrived"] = "Llegado"
        m["Running on time."] = "Circula puntual."
        m[" (scheduled)"] = " (previsto)"
        m[", platform not yet announced"] = ", vía aún no anunciada"
        m[" · scheduled platform "] = " · vía prevista "
        m[" · actual "] = " · real "
        m[" · CANCELLED"] = " · CANCELADO"
        m[" · on time"] = " · puntual"
        m[" · plat. "] = " · vía "
        m["Timetable service unreachable."] = "Servicio de horarios no disponible."
        m[" plat."] = " vía"
        m["No rail strikes announced (source: Italian Ministry strike observatory)."] = "No hay huelgas ferroviarias convocadas (fuente: observatorio de huelgas del Ministerio italiano)."
        m["Announced rail strikes:\n"] = "Huelgas ferroviarias convocadas:\n"
        m["\n\nGuaranteed trains: More → Guaranteed trains."] = "\n\nTrenes garantizados: Más → Trenes garantizados."
        m["Strike observatory unreachable."] = "Observatorio de huelgas no disponible."
        m["No traffic disruptions reported right now."] = "No hay incidencias de circulación señaladas en este momento."
        m["Take a few seconds to write the message."] = "Tómate unos segundos para escribir el mensaje."
        m["You just sent a message: wait a few minutes before the next one."] = "Acabas de enviar un mensaje: espera unos minutos antes del siguiente."
        m["This message has already been sent."] = "Este mensaje ya se ha enviado."
        m["Too many links in the message: at most 2."] = "Demasiados enlaces en el mensaje: como máximo 2."
        m["The message does not look like text: describe the problem or suggestion in words."] = "El mensaje no parece texto: describe el problema o la sugerencia con palabras."
        m["Information, help during disruption, reduced mobility, Carta Blu, complaints"] = "Información, ayuda durante incidencias, movilidad reducida, Carta Blu, reclamaciones"
        m["Italo tickets, changes, refunds and help"] = "Billetes Italo, cambios, reembolsos y ayuda"
        m["Italo ticket machines (unstaffed)"] = "Máquinas expendedoras de Italo (sin personal)"
        m["TILO/SBB and Arcobaleno tickets, passes, information and help"] = "Billetes TILO/SBB y Arcobaleno, abonos, información y ayuda"
        m["Live data not yet available"] = "Datos en directo aún no disponibles"
        m["Departed"] = "Salido"
        m[" changes"] = " transbordos"
        m["Downloading South Tyrol ticket outlets…"] = "Descargando los puntos de venta del Tirol del Sur…"
        m["Locating outlets…"] = "Localizando los puntos de venta…"
        m["Downloading Trenord sales points…"] = "Descargando los puntos de venta de Trenord…"
        m["Downloading ticket office hours…"] = "Descargando el horario de las taquillas…"
        m["Downloading the sales points list…"] = "Descargando la lista de puntos de venta…"
        m["Downloading the sellers list…"] = "Descargando la lista de revendedores…"
        m["Ticket machine"] = "Máquina expendedora"
        m["Price you entered"] = "Precio que has introducido"
        m["platform not accessible: "] = "vía no accesible: "
        m["expected back on "] = "vuelta prevista el "
        m["Band from the official regional ticket price"] = "Tramo según el precio oficial del billete regional"
        m["delay compensation"] = "indemnización por retraso"
        m["bikes on trains"] = "bicicletas en el tren"
        m["children"] = "niños"
        m["disability assistance"] = "asistencia a personas con discapacidad"
        m["lost property"] = "objetos perdidos"
        m["ticket validation"] = "validación del billete"
        m["bus and taxi at Varese"] = "autobús y taxi en Varese"
        m["toilets at Saronno"] = "aseos en Saronno"
        m["\nLast reported: "] = "\nÚltimo aviso: "
        m["\nNext: "] = "\nSiguiente: "
        m["on time"] = "puntual"
        m["FN network"] = "red FN"
        m["Departure and arrival reminders"] = "Recordatorios de salida y llegada"
        m["Disruptions on favourite routes and lines"] = "Incidencias en trayectos y líneas favoritos"
        m["Stop alarm"] = "Alarma de parada"
        m["Board at "] = "Sube en "
        m[" at "] = " a las "
        m[" · platform "] = " · vía "
        m["Alarm before "] = "Alarma antes de "
        m["Data temporarily unavailable"] = "Datos temporalmente no disponibles"
        m[" on time."] = " puntual."
        m["\nWith a delay of 60 minutes or more you can claim compensation: see More › Conditions, rights and refunds."] = "\nCon un retraso de 60 minutos o más puedes pedir una indemnización: mira Más › Condiciones, derechos y reembolsos."
        m["\nIf you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation."] = "\nSi tienes un abono, los retrasos cuentan para el bono mensual (Trenord) o la indemnización."
        m["\nI've stopped following the train. Have a good day!"] = "\nHe dejado de seguir el tren. ¡Que tengas un buen día!"
        m["trip completed"] = "viaje terminado"
        m["Platform change"] = "Cambio de vía"
        m["Wake up! Next stop: "] = "¡Despierta! Próxima parada: "
        m["Expected arrival at "] = "Llegada prevista a las "
        m["Expected departure at "] = "Salida prevista a las "
        m["Arrival at "] = "Llegada a "
        m["Departure from "] = "Salida de "
        m["Warning: the train is cancelled"] = "Atención: el tren está cancelado"
        m["Follow train"] = "Seguir tren"
        m["cancelled"] = "cancelado"
        m["It is cancelled."] = "Está cancelado."
        m["Back on time."] = "De nuevo puntual."
        m["Alternatives:"] = "Alternativas:"
        m["No alternative found soon: open the app for more options."] = "No hay alternativas pronto: abre la app para ver más opciones."
        m["Refreshing widget…"] = "Actualizando el widget…"
        m["refreshing…"] = "actualizando…"
        m["Tap to set up"] = "Toca para configurar"
        m["Tap the title to choose what to show"] = "Toca el título para elegir qué mostrar"
        m["Tap ⟳ to refresh"] = "Toca ⟳ para actualizar"
        m["Refreshes automatically · ⟳ to retry"] = "Se actualiza solo · ⟳ para reintentar"
        m["not updated"] = "no actualizado"
        m["Data service temporarily unreachable"] = "Servicio de datos temporalmente no disponible"
        m["Tap ⟳ to retry"] = "Toca ⟳ para reintentar"
        m["No departures in the next hours"] = "No hay salidas en las próximas horas"
        m["The widget refreshes itself; tap ⟳ to retry"] = "El widget se actualiza solo; toca ⟳ para reintentar"
        m["First departures"] = "Primeras salidas"
        m["No trains now: here are the first scheduled"] = "Ahora no hay trenes: estos son los primeros programados"
        m[" · not updated"] = " · no actualizado"
        m["Status not available yet"] = "Estado aún no disponible"
        m["Resume following "] = "Volver a seguir "
        m["The phone restarted: tap to keep receiving platform, delay and arrival alerts."] = "El teléfono se ha reiniciado: toca para seguir recibiendo avisos de vía, retraso y llegada."
        m["is cancelled."] = "está cancelado."
        m["Search by voice"] = "Buscar por voz"
        m["OpenStreetMap servers are not responding. Try again shortly or search Google Maps."] = "Los servidores de OpenStreetMap no responden. Inténtalo de nuevo en un momento o busca en Google Maps."
        m["Set up"] = "Configurar"
        m["Share train status"] = "Compartir el estado del tren"
        m["Other apps"] = "Otras apps"
        m["Resellers"] = "Revendedores"
        m["Mooney points"] = "Puntos Mooney"
        m["list from"] = "lista de"
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney points: see the official Trenitalia map."] = "En el resto de Italia, los billetes regionales de Trenitalia se venden en los puntos PuntoLIS y Mooney: consulta el mapa oficial de Trenitalia."
        m["Official Trenitalia map (all Italy)"] = "Mapa oficial de Trenitalia (toda Italia)"
        m["No data for this station. TrovaTreno does not publish the FerrovieNord network: for those stations the app collects arrivals from ViaggiaTreno by itself and data appears here after a few hours."] = "No hay datos para esta estación. TrovaTreno no publica la red FerrovieNord: para esas estaciones la app recopila por sí misma las llegadas de ViaggiaTreno y los datos aparecen aquí en unas horas."
        m["Average delay "] = "Retraso medio "
        m["Each box compares only services of the same kind. Based on trains with at least 30 observed arrivals in the month; runs without a category are not included. Regional operators other than Trenord and Trenitalia (Tper, EAV, Ferrovie del Gargano, TUA, BLS…) are identified by route and train number; only those running on the RFI network tracked by ViaggiaTreno are included."] = "Cada recuadro compara solo servicios del mismo tipo. Basado en trenes con al menos 30 llegadas observadas en el mes; los trenes sin categoría no se incluyen. Las compañías regionales distintas de Trenord y Trenitalia (Tper, EAV, Ferrovie del Gargano, TUA, BLS…) se identifican por recorrido y número de tren; solo se incluyen las que circulan por la red RFI seguida por ViaggiaTreno."
        m["SBB counts a train as punctual under 3 minutes late (5 in Italy), so the comparison with Italy is conservative. SBB publishes only the previous day: the app collects one per day."] = "SBB considera puntual un tren con menos de 3 minutos de retraso (5 en Italia), así que la comparación con Italia es prudente. SBB solo publica el día anterior: la app recopila uno al día."
        m["Their actual times exist as open data (opentransportdata.swiss, \"Ist-Daten\"), but only as a single daily file with all Swiss public transport: hundreds of MB, to be downloaded every day. On a phone that would use too much data and battery, and there is no service returning per-company totals as SBB does. They can be added in future if such a service appears, or with a small server that downloads the file and prepares the totals for the app."] = "Sus horarios reales existen como datos abiertos (opentransportdata.swiss, \"Ist-Daten\"), pero solo como un único archivo diario con todo el transporte público suizo: cientos de MB, que habría que descargar cada día. En un teléfono gastaría demasiados datos y batería, y no hay ningún servicio que devuelva los totales por compañía como hace SBB. Se podrán añadir en el futuro si aparece un servicio así, o con un pequeño servidor que descargue el archivo y prepare los totales para la app."
        m["TrovaTreno does not publish the FerrovieNord network. The app reads arrivals from ViaggiaTreno by itself: every 80 minutes on Wi-Fi, every 3 hours on mobile data (about 0.3 MB). On time = within 5 minutes. Figures depend on when the phone is on and connected."] = "TrovaTreno no publica la red FerrovieNord. La app lee por sí misma las llegadas de ViaggiaTreno: cada 80 minutos con Wi-Fi, cada 3 horas con datos móviles (unos 0,3 MB). Puntual = en 5 minutos. Las cifras dependen de cuándo esté el teléfono encendido y conectado."
        m["Hi, I'm your Conductor! 🚆 I keep you posted about your train before, during and after the trip: platform, delays, platform changes, cancellations, next stops and arrival. It works with all trains: Trenord, Trenitalia, FerrovieNord, Italo, TILO and SBB."] = "¡Hola, soy tu Revisor! 🚆 Te mantengo al día sobre tu tren antes, durante y después del viaje: vía, retrasos, cambios de vía, cancelaciones, próximas paradas y llegada. Funciona con todos los trenes: Trenord, Trenitalia, FerrovieNord, Italo, TILO y SBB."
        m["Departs"] = "Sale"
        m["Arrives"] = "Llega"
        m["Italy"] = "Italia"
        m["International"] = "Internacional"
        m["Long distance"] = "Larga distancia"
        m["Regional and long distance"] = "Regional y larga distancia"
        m["Real time: ViaggiaTreno (RFI network)"] = "Tiempo real: ViaggiaTreno (red RFI)"
        m["Real time: official Swiss timetable"] = "Tiempo real: horario oficial suizo"
        m["Real time only on the company's site/app"] = "Tiempo real solo en la web/app de la compañía"
        m["Scheduled times in the app (Transitous); real time only on the company's site/app"] = "Horarios programados en la app (Transitous); tiempo real solo en la web/app de la compañía"
        m["Regional and suburban"] = "Regionales y cercanías"
        m["Intercity and long distance"] = "Intercity y larga distancia"
        m["Plenty of seats"] = "Muchas plazas libres"
        m["Moderately busy: look for seats"] = "Bastante lleno: busca bien las plazas"
        m["Very crowded"] = "Muy lleno"
        m["Trenord (sensors or previous days' history)"] = "Trenord (sensores o historial de días anteriores)"
        m["SBB forecast"] = "Previsión de SBB"
        m["Binario estimate by time of day"] = "Estimación de Binario por franja horaria"
        m["I can help with:\n• \"delay train 2070\" or \"where is 9544\"\n• \"trains from Varese to Milano\"\n• \"departures from Varese\" / \"arrivals at Como\"\n• \"any strikes?\"\n• \"traffic on S5\" / \"problems at Saronno\"\n• \"elevators at Saronno\"\n• \"guaranteed trains\"\n• \"where is my train?\" (the train you follow)\n• \"next train to Milano\"\n• \"bus, metro and taxi at Milano Centrale\"\n• \"toilets at Saronno\" / \"services at Varese\"\n• \"delay compensation\", \"can I bring my bike?\", \"children\", \"disability assistance\", \"lost property\"\nTap the microphone to ask by voice."] = "Puedo ayudarte con:\n• \"retraso tren 2070\" o \"dónde está el 9544\"\n• \"trenes de Varese a Milano\"\n• \"salidas de Varese\" / \"llegadas a Como\"\n• \"¿hay huelgas?\"\n• \"circulación en la S5\" / \"problemas en Saronno\"\n• \"ascensores en Saronno\"\n• \"trenes garantizados\"\n• \"¿dónde está mi tren?\" (el tren que sigues)\n• \"próximo tren a Milano\"\n• \"autobús, metro y taxi en Milano Centrale\"\n• \"aseos en Saronno\" / \"servicios en Varese\"\n• \"indemnización por retraso\", \"¿puedo llevar la bicicleta?\", \"niños\", \"asistencia a personas con discapacidad\", \"objetos perdidos\"\nToca el micrófono para preguntar por voz."
        m["During regional rail strikes trains are normally guaranteed 6:00–9:00 and 18:00–21:00 on weekdays (7:00–10:00 and 18:00–21:00 on holidays). Updated official lists are in More → Guaranteed trains."] = "Durante las huelgas del transporte ferroviario regional, normalmente se garantizan los trenes de 6:00 a 9:00 y de 18:00 a 21:00 en días laborables (de 7:00 a 10:00 y de 18:00 a 21:00 en festivos). Las listas oficiales actualizadas están en Más → Trenes garantizados."
        m["yes"] = "sí"
        m[", platform not yet shown"] = ", vía aún no indicada"
        m["Delay compensation (EU Regulation 2021/782):\n• 60–119 minutes late on arrival: 25% of the ticket\n• 120 minutes or more: 50%\n• Trenitalia Frecce: compensation also for 30–59 minutes, under Trenitalia's conditions\n• season tickets: own rules (Trenord gives season-ticket bonuses based on line punctuality)\nIf the expected delay exceeds 60 minutes you can also give up the trip with a full refund or be re-routed. The train screen shows whether you are entitled to compensation."] = "Indemnización por retraso (Reglamento UE 2021/782):\n• 60–119 minutos de retraso en la llegada: 25 % del billete\n• 120 minutos o más: 50 %\n• Frecce de Trenitalia: indemnización también con 30–59 minutos, según las condiciones de Trenitalia\n• abonos: normas propias (Trenord da bonificaciones a los abonados según la puntualidad de la línea)\nSi el retraso previsto supera los 60 minutos también puedes renunciar al viaje con reembolso completo o cambiar de itinerario. La pantalla del tren indica si tienes derecho a indemnización."
        m["Ticket refund or change: it depends on the fare (cheap offers are often non-refundable). Trenitalia: request on the website or app with the ticket code (PNR). Trenord: from the refunds page. If the train is cancelled or expected more than 60 minutes late a refund is always due."] = "Reembolso o cambio del billete: depende de la tarifa (las ofertas baratas a menudo no son reembolsables). Trenitalia: solicítalo en la web o en la app con el código del billete (PNR). Trenord: desde la página de reembolsos. Si el tren se cancela o se prevé un retraso de más de 60 minutos, el reembolso siempre corresponde."
        m["Validation: paper regional tickets without date and time must be validated before boarding (validating machine in the station). Digital tickets bought online or in the app already show the train or the day: check on the ticket whether check-in is needed. The nearest validators are in Stations → station → Overview, or More → Nearby resellers."] = "Validación: los billetes regionales en papel sin fecha ni hora deben validarse antes de subir (validadora en la estación). Los billetes digitales comprados online o en la app ya indican el tren o el día: comprueba en el billete si hace falta el check-in. Las validadoras más cercanas están en Estaciones → estación → Resumen, o en Más → Revendedores cercanos."
        m["Without a valid ticket you pay the fare plus a fine; amounts and how to pay (reduced if you pay at once or within a few days) are in the operator's conditions of carriage. If the ticket machine was broken, tell the conductor straight away."] = "Sin billete válido pagas la tarifa más una multa; los importes y la forma de pago (reducida si pagas en el momento o en pocos días) están en las condiciones de transporte de la compañía. Si la máquina expendedora estaba averiada, díselo enseguida al revisor."
        m["Bikes and scooters:\n• Trenord (Lombardy): regular, folding, electric bikes and scooters travel free on all trains, at any time, space permitting\n• Trenitalia Regional: usually on trains with the bike symbol, with a supplement\n• Frecce and Italo: normally only folded bikes in a bag\n• TILO: SBB rules in Ticino, Trenord rules in Lombardy"] = "Bicicletas y patinetes:\n• Trenord (Lombardía): bicicletas normales, plegables, eléctricas y patinetes viajan gratis en todos los trenes, a cualquier hora, si hay sitio\n• Trenitalia Regional: normalmente en trenes con el símbolo de bicicleta, con suplemento\n• Frecce e Italo: normalmente solo bicicletas plegadas en bolsa\n• TILO: normas de SBB en el Tesino, normas de Trenord en Lombardía"
        m["Pets on trains:\n• Trenord: free within Lombardy (carrier max 70×30×50 cm; dogs with muzzle, leash and registry certificate); not allowed on weekdays 7:00–9:30 and 17:30–19:30; beyond Lombardy an animal supplement is needed\n• Trenitalia: carrier free; on regional trains large dogs pay 50% of 2nd class; on Frecce and Intercity add \"Travel with your dog\" when buying\n• Italo: free up to about 5 kg in a carrier; larger dogs with the \"Dog\" service in Smart and Prima\n• SBB/TILO: free up to 30 cm in a bag; otherwise half fare or dog day pass CHF 25\n• Guide and assistance dogs: always free. Details in More → Travelling with pets."] = "Animales en el tren:\n• Trenord: gratis dentro de Lombardía (transportín máx. 70×30×50 cm; perros con bozal, correa y certificado del registro); no se admiten en días laborables de 7:00 a 9:30 y de 17:30 a 19:30; fuera de Lombardía se necesita un suplemento para el animal\n• Trenitalia: transportín gratis; en regionales los perros grandes pagan el 50 % de la 2.ª clase; en Frecce e Intercity añade \"Viaja con tu perro\" al comprar\n• Italo: gratis hasta unos 5 kg en transportín; perros más grandes con el servicio \"Dog\" en Smart y Prima\n• SBB/TILO: gratis hasta 30 cm en bolsa; si no, media tarifa o pase diario para perros de 25 CHF\n• Perros guía y de asistencia: siempre gratis. Detalles en Más → Viajar con animales."
        m["Children:\n• Regional trains in Lombardy: free under 4 without a seat, 50% off from 4 to under 14\n• Trenitalia national trains: free under 4 without a seat, 50% off the Base fare from 4 to under 15\n• Other regions and Italo have their own rules"] = "Niños:\n• Trenes regionales de Lombardía: gratis menores de 4 años sin asiento, 50 % de descuento de 4 a menos de 14 años\n• Trenes nacionales de Trenitalia: gratis menores de 4 años sin asiento, 50 % de descuento sobre la tarifa Base de 4 a menos de 15 años\n• Otras regiones e Italo tienen sus propias normas"
        m["Assistance for people with disabilities or reduced mobility:\n• RFI Sala Blu (RFI stations): 800 90 60 60, from mobiles +39 02 32 32 32\n• Trenord: 800 210 955 (daily 8:15–19:45) or +39 02 72 49 49 49; book preferably 48 hours ahead\n• SBB (Ticino): 0800 007 102\nThe station screen shows lifts per platform and current faults."] = "Asistencia a personas con discapacidad o movilidad reducida:\n• Sala Blu de RFI (estaciones RFI): 800 90 60 60, desde móviles +39 02 32 32 32\n• Trenord: 800 210 955 (todos los días 8:15–19:45) o +39 02 72 49 49 49; reserva preferiblemente con 48 horas de antelación\n• SBB (Tesino): 0800 007 102\nLa pantalla de la estación muestra los ascensores por vía y las averías actuales."
        m["Lost property: tell the conductor straight away. Trenord: 02 72 49 49 49, items kept at the Cadorna and Garibaldi My Link Points for a few days, then at the City of Milan office (via Friuli 30). Trenitalia: lost items search service and Frecciadesk. Italo: Pronto Italo 06 07 08. SBB/TILO: report online at lostandfound.sbb.ch. Details in More → Lost property."] = "Objetos perdidos: díselo enseguida al revisor. Trenord: 02 72 49 49 49, los objetos se guardan unos días en los My Link Point de Cadorna y Garibaldi y luego en la oficina del Ayuntamiento de Milán (via Friuli 30). Trenitalia: servicio de búsqueda de objetos perdidos y Frecciadesk. Italo: Pronto Italo 06 07 08. SBB/TILO: declara la pérdida online en lostandfound.sbb.ch. Detalles en Más → Objetos perdidos."
        m["Strikes and tickets: Trenord refunds on request within 30 days of the strike. Trenitalia refunds from the announcement: Frecce and Intercity up to departure time, regional trains until midnight of the day before. In the guaranteed time bands (weekdays 6–9 and 18–21) the trains on the official list run."] = "Huelgas y billetes: Trenord reembolsa a petición en los 30 días siguientes a la huelga. Trenitalia reembolsa desde el anuncio: Frecce e Intercity hasta la hora de salida, regionales hasta la medianoche del día anterior. En las franjas garantizadas (días laborables 6–9 y 18–21) circulan los trenes de la lista oficial."
        m["Cancelled train: you are entitled to a full refund or to travel on the first available train to the same destination. A replacement bus is often provided: see the notices (More → Strikes, traffic and works). Tell me the train number to check it."] = "Tren cancelado: tienes derecho al reembolso completo o a viajar en el primer tren disponible hacia el mismo destino. A menudo se ofrece un autobús sustitutivo: consulta los avisos (Más → Huelgas, circulación y obras). Dime el número del tren para comprobarlo."
        m["Missed connection because of a delay: with a single ticket you can continue on the first available train at no extra cost. For journeys with a change the app shows the minutes to change and warns \"connection at risk\" if the first train is late."] = "Transbordo perdido por un retraso: con un billete único puedes continuar en el primer tren disponible sin coste adicional. En los viajes con transbordo la app muestra los minutos para cambiar y avisa \"transbordo en riesgo\" si el primer tren va con retraso."
        m["Luggage: you travel with your own bags in the luggage spaces at no cost for normal use; they must stay under your control and not block aisles and doors. Large stations often have a paid left-luggage office."] = "Equipaje: viajas con tus maletas en los espacios para equipaje sin coste para un uso normal; deben estar bajo tu control y no bloquear pasillos ni puertas. Las grandes estaciones suelen tener consigna de pago."
        m["Tickets: on the official websites and apps (Trenitalia, Trenord, Italo), at ticket offices and machines in the station, and at authorised resellers (tobacconists, newsagents). More → Nearby resellers shows ticket offices, machines (also contactless) and resellers near you."] = "Billetes: en las webs y apps oficiales (Trenitalia, Trenord, Italo), en las taquillas y máquinas de la estación y en los revendedores autorizados (estancos, quioscos). Más → Revendedores cercanos muestra taquillas, máquinas (también contactless) y revendedores cerca de ti."
        m["Season tickets: Trenord offers monthly and annual tickets and the integrated Io Viaggio passes (train + public transport in Lombardy). Trenitalia has regional and Frecce passes. Season-ticket holders have their own refund and delay-bonus rules."] = "Abonos: Trenord ofrece abonos mensuales y anuales y los abonos integrados Io Viaggio (tren + transporte público en Lombardía). Trenitalia tiene abonos regionales y para Frecce. Los abonados tienen sus propias normas de reembolso y de bonificación por retrasos."
        m["Airports:\n• Malpensa: Malpensa Express from Milano Cadorna and Milano Centrale, stops T1 and T2\n• Linate: metro line M4 (no train)\n• Orio al Serio (Bergamo): bus from Bergamo station\nAsk me for example \"trains from Milano Cadorna to Malpensa\"."] = "Aeropuertos:\n• Malpensa: Malpensa Express desde Milano Cadorna y Milano Centrale, paradas T1 y T2\n• Linate: línea de metro M4 (sin tren)\n• Orio al Serio (Bérgamo): autobús desde la estación de Bérgamo\nPregúntame por ejemplo \"trenes de Milano Cadorna a Malpensa\"."
        m["Switzerland and TILO: trips between Lombardy and Ticino need cross-border tickets (Arcobaleno in CHF or Trenord in euros). TILO lines, fares and services are in More → TILO; for a route ask \"trains from Como to Lugano\"."] = "Suiza y TILO: los viajes entre Lombardía y el Tesino necesitan billetes transfronterizos (Arcobaleno en CHF o Trenord en euros). Líneas, tarifas y servicios de TILO están en Más → TILO; para un trayecto pregunta \"trenes de Como a Lugano\"."
        m["Contacts:\n• Trenitalia: 892021 (call centre)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (disability assistance): 800 90 60 60\nFor complaints use the forms on the official websites."] = "Contactos:\n• Trenitalia: 892021 (centro de llamadas)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• Sala Blu de RFI (asistencia a personas con discapacidad): 800 90 60 60\nPara reclamaciones usa los formularios de las webs oficiales."
        m["Your rights (EU Regulation 2021/782): travel information, refund or re-routing if the expected delay exceeds 60 minutes, compensation of 25% (60–119 minutes) or 50% (120+), assistance (drinks, meals, accommodation if needed), free assistance for people with disabilities."] = "Tus derechos (Reglamento UE 2021/782): información de viaje, reembolso o cambio de itinerario si el retraso previsto supera los 60 minutos, indemnización del 25 % (60–119 minutos) o del 50 % (120 o más), asistencia (bebidas, comidas, alojamiento si hace falta), asistencia gratuita para personas con discapacidad."
        m["Platforms in the app: the scheduled platform comes from the timetable; the actual one (blue) is confirmed by the station. A change is shown in red (e.g. 3 → 5) and, if you follow the train, you get a notification and a voice alert."] = "Vías en la app: la vía prevista procede del horario; la real (azul) la confirma la estación. Un cambio se muestra en rojo (p. ej. 3 → 5) y, si sigues el tren, recibes una notificación y un aviso de voz."
        m["Stop alarm: open the train, tap the stop where you get off and choose \"Wake me before this stop\". It rings when the train leaves the previous stop (or 4 minutes before); with voice alerts you also hear the voice."] = "Alarma de parada: abre el tren, toca la parada donde bajas y elige \"Despiértame antes de esta parada\". Suena cuando el tren sale de la parada anterior (o 4 minutos antes); con los avisos de voz también oyes la voz."
        m["Where I board: open the train, tap the stop where you get on and choose \"I board here\". Platform, time and alerts refer to that stop."] = "Dónde subo: abre el tren, toca la parada donde subes y elige \"Subo aquí\". Vía, hora y avisos se refieren a esa parada."
        m["Timetables offline: search the route and tap the PDF icon in the results to download the day's timetable (outbound and return) to Download/Binario. The app also remembers the latest times of every route you searched."] = "Horarios sin conexión: busca el trayecto y toca el icono PDF en los resultados para descargar el horario del día (ida y vuelta) en Download/Binario. La app también recuerda los últimos horarios de cada trayecto que has buscado."
        m["Voice alerts: in Settings → Accessibility choose \"All\" or \"Only upcoming stop\". To ask by voice tap the microphone below, or long-press the Binario icon and choose \"Ask by voice\"."] = "Avisos de voz: en Ajustes → Accesibilidad elige \"Todo\" o \"Solo la parada próxima\". Para preguntar por voz toca el micrófono de abajo, o mantén pulsado el icono de Binario y elige \"Preguntar por voz\"."
        m["Alerts for deaf people: in Settings → Accessibility turn on strong vibration (one pattern per alert) and the flashlight."] = "Avisos para personas sordas: en Ajustes → Accesibilidad activa la vibración fuerte (un patrón por aviso) y la linterna."
        m["Widgets: long-press an empty spot on the Home screen → Widgets → Binario. There are Route, Train, Station and Favourites; tap the title to change it."] = "Widgets: mantén pulsado un espacio vacío de la pantalla de inicio → Widgets → Binario. Hay Trayecto, Tren, Estación y Favoritos; toca el título para cambiarlo."
        m["Following a train: open the train and tap \"Follow\": a pinned notification updates every minute and warns of platform changes and delays."] = "Seguir un tren: abre el tren y toca \"Seguir\": una notificación fija se actualiza cada minuto y avisa de cambios de vía y retrasos."
        m["Punctuality: More → Punctuality has monthly statistics, with regional trains compared with regional ones and high speed separately, plus every station and train (TrovaTreno.it data)."] = "Puntualidad: Más → Puntualidad tiene estadísticas mensuales, con los regionales comparados con los regionales y la alta velocidad por separado, además de cada estación y tren (datos de TrovaTreno.it)."
        m["Milan – Saronno – Varese – Laveno"] = "Milán – Saronno – Varese – Laveno"
        m["Milan – Saronno – Como"] = "Milán – Saronno – Como"
        m["Milan – Saronno – Novara"] = "Milán – Saronno – Novara"
        m["Milan – Seveso – Asso"] = "Milán – Seveso – Asso"
        m["Brescia – Iseo – Edolo"] = "Brescia – Iseo – Edolo"
        m["Other trains (S lines and Passante)"] = "Otros trenes (líneas S y Passante)"
        m["Check for updates"] = "Buscar actualizaciones"
        m["Checking…"] = "Comprobando…"
        m["You already have the latest version"] = "Ya tienes la última versión"
        m["Couldn't check for updates: check your connection and try again."] = "No se han podido buscar actualizaciones: comprueba la conexión y vuelve a intentarlo."
        m["Euro amounts are indicative (rate about €1.135 per CHF): the rate may differ at purchase."] = "Los importes en euros son orientativos (cambio de unos 1,135 € por CHF): el cambio puede ser distinto al comprar."
        m["More actions"] = "Más acciones"
        m["Not a railway station: opening it on the map"] = "No es una estación de tren: se abre en el mapa"
        m["Transport:"] = "Medios:"
        m["Trains only"] = "Solo trenes"
        m["Also metro and bus"] = "También metro y autobús"
        m["There are no train-only solutions at this time: solutions with metro or bus are shown too."] = "A esta hora no hay soluciones solo en tren: también se muestran las que incluyen metro o autobús."
        m["Hidden"] = "Ocultas"
        m["solutions with metro or bus"] = "soluciones con metro o autobús"
        m["Prices:"] = "Precios:"
        m["1st class estimated: check sbb.ch"] = "1.ª clase estimada: compruébalo en sbb.ch"
        m["New version available"] = "Nueva versión disponible"
        m["Tap to download and install"] = "Toca para descargar e instalar"
        m["Quick"] = "Rápido"
        m["Active filters"] = "Filtros activos"
        m["Nearby stations, toilets, replacement buses, taxis, defibrillators"] = "Estaciones cercanas, aseos, autobuses sustitutivos, taxis, desfibriladores"
        m["Show these options on the Quick page too"] = "Mostrar estas opciones también en la página Rápido"
        m["Send the link or the app file via WhatsApp, Telegram…"] = "Envía el enlace o el archivo de la app por WhatsApp, Telegram…"
        m["Or send the app file directly (installed version):"] = "O envía directamente el archivo de la app (versión instalada):"
        m["App file (APK)"] = "Archivo de la app (APK)"
        m["The recipient must open it and allow installation. WhatsApp may refuse APK files: in that case use the link."] = "Quien lo recibe debe abrirlo y permitir la instalación. WhatsApp puede rechazar los archivos APK: en ese caso usa el enlace."
        m["Binario, the free app for trains in Italy and Switzerland. Open the file and allow installation."] = "Binario, la app gratuita de trenes para Italia y Suiza. Abre el archivo y permite la instalación."
        m["Could not prepare the app file"] = "No se ha podido preparar el archivo de la app"
        m["SBB services at the station"] = "Servicios SBB en la estación"
        m["SBB services not reachable right now."] = "Servicios SBB no disponibles en este momento."
        m["Tap to retry"] = "Toca para reintentar"
        m["Reading services from the SBB website…"] = "Leyendo los servicios de la web de SBB…"
        m["Hide shops and food"] = "Ocultar tiendas y restauración"
        m["Shops and food"] = "Tiendas y restauración"
        m["open"] = "abiertos"
        m["Closed"] = "Cerrado"
        m["Open/closed and hours: SBB website, refreshed every 5 minutes. All data without guarantee."] = "Abierto/cerrado y horarios: web de SBB, actualizado cada 5 minutos. Todos los datos sin garantía."
        m["Station page on sbb.ch"] = "Página de la estación en sbb.ch"
        m["No region chosen"] = "Ninguna región elegida"
        m["Notices and strikes in: "] = "Avisos y huelgas en: "
        m[" (and with no region given)"] = " (y sin región indicada)"
        m["Show only notices and strikes that affect these regions (plus national ones). You can pick more than one."] = "Mostrar solo los avisos y huelgas que afectan a estas regiones (más los nacionales). Puedes elegir más de una."
        m["Reset"] = "Restablecer"
    }

    /** 0.1.23: Italo, prezzi migliori, cambi rischiosi, condivisione solo Android. */
    private fun p6(m: HashMap<String, String>) {
        m["Android smartphones and tablets only: it does not work on iPhone and iPad."] = "Solo para smartphones y tabletas Android: no funciona en iPhone ni iPad."
        m["Risky change"] = "Transbordo arriesgado"
        m["Tight change"] = "Transbordo justo"
        m["For this change we recommend at least"] = "Para este transbordo se recomiendan al menos"
        m["a small delay could make you miss the connection."] = "con un pequeño retraso podrías perder el enlace."
        m["Find an alternative with later trains"] = "Buscar una alternativa con trenes posteriores"
        m["Two tickets: Italo on italotreno.com, the other train on trenitalia.com or trenord.it"] = "Dos billetes: Italo en italotreno.com, el otro tren en trenitalia.com o trenord.it"
        m["Change station not found"] = "Estación de transbordo no encontrada"
        m["Arrival station not found"] = "Estación de llegada no encontrada"
        m["Alternatives for the change at"] = "Alternativas al transbordo en"
        m["Arriving on"] = "Llegada con el"
        m["Later trains with at least"] = "Trenes posteriores con al menos"
        m["min to change"] = "min para el transbordo"
        m["No alternative found after this time."] = "No se ha encontrado ninguna alternativa después de esta hora."
        m["Comfortable changes"] = "Transbordos holgados"
        m["With tickets for a fixed train and time (Frecce, Italo, Intercity) taking another train may require changing the ticket. Regional tickets are valid on any regional train on the route."] = "Con billetes de tren y hora fijos (Frecce, Italo, Intercity) tomar otro tren puede requerir cambiar el billete. Los billetes regionales valen en cualquier regional del trayecto."
        m["Cannot reach the server. Check your connection."] = "No se puede contactar con el servidor. Comprueba la conexión."
        m["Some time bands did not respond: tap to retry"] = "Algunas franjas no han respondido: toca para reintentar"
        m["Lowest price for 1 adult among trains in that time band (Trenitalia, Trenord and Italo). «—» = no price available, «?» = service not reachable. Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "Precio más bajo para 1 adulto entre los trenes de esa franja (Trenitalia, Trenord e Italo). «—» = sin precio disponible, «?» = servicio no disponible. Toca una casilla para ver las soluciones. Las tarifas económicas cambian según la disponibilidad: el precio final es el de la compra."
        m["next 7 days, morning, afternoon and evening"] = "próximos 7 días, mañana, tarde y noche"
        m["Choose origin and destination to see the lowest prices for the next 7 days."] = "Elige salida y llegada para ver los precios más bajos de los próximos 7 días."
    }

    /** 0.1.24: silenzio degli avvisi di sciopero. */
    private fun p7(m: HashMap<String, String>) {
        m["Mute strike alerts"] = "Silenciar los avisos de huelga"
        m["Muted until"] = "Silenciados hasta el"
        m["On · tap to mute them for a while"] = "Activos · toca para silenciarlos un tiempo"
        m["Turn back on"] = "Reactivar"
        m["1 hour"] = "1 hora"
        m["3 hours"] = "3 horas"
        m["8 hours"] = "8 horas"
        m["1 week"] = "1 semana"
        m["1 month"] = "1 mes"
        m["For how long? Strikes stay visible in News."] = "¿Durante cuánto tiempo? Las huelgas siguen visibles en Noticias."
        m["Until a day and time…"] = "Hasta un día y una hora…"
    }

    /** 0.1.25: passeggeri, menù laterale, prossimo sciopero, notifica del treno seguito. */
    private fun p8(m: HashMap<String, String>) {
        m["Travel"] = "Viaje"
        m["Best prices"] = "Mejores precios"
        m["At the station"] = "En la estación"
        m["Tickets and passes"] = "Billetes y abonos"
        m["Fares"] = "Tarifas"
        m["Send feedback"] = "Enviar comentarios"
        m["Next train strike"] = "Próxima huelga de trenes"
        m.putIfAbsent("Details", "Detalles")
        m.putIfAbsent("Menu", "Menú")
        m["1 adult"] = "1 adulto"
        m["adults"] = "adultos"
        m["1 child"] = "1 niño"
        m["children"] = "niños"
        m["Passengers"] = "Pasajeros"
        m["Adults"] = "Adultos"
        m["Children"] = "Niños"
        m["aged 4 to 14 (under 4 free without a seat)"] = "de 4 a 14 años (menores de 4 gratis sin asiento)"
        m["Prices shown are the total for all passengers. Discounts for children and families: check when buying."] = "Los precios mostrados son el total para todos los pasajeros. Descuentos para niños y familias: compruébalo al comprar."
        m["Less"] = "Menos"
        m["More"] = "Más"
        m.putIfAbsent("total price", "precio total")
        m.putIfAbsent("min early", "min de adelanto")
        m.putIfAbsent("late", "de retraso")
        m.putIfAbsent("Refresh", "Actualizar")
        m.putIfAbsent("On time", "Puntual")
        m.putIfAbsent("Cancelled", "Cancelado")
    }

    /** 0.1.26: menù Accessibilità. */
    private fun p9(m: HashMap<String, String>) {
        m["Colour-blind, voice and vibration"] = "Daltónicos, voz y vibración"
    }

    /** Germania: treni, aziende, stazioni e biglietti. */
    private fun p10(m: HashMap<String, String>) {
        m["Trains in Germany"] = "Trenes en Alemania"
        m["Times, delays and platforms in real time for all German operators"] = "Horarios, retrasos y vías en tiempo real de todas las empresas alemanas"
        m["Search a German station like an Italian one, also by its Italian name: «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Journey search (also Italy ⇄ Germany), departure and arrival boards, train details and «Follow» all work."] = "Busca una estación alemana como una italiana, también con su nombre italiano: «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Funcionan la búsqueda de viajes (también Italia ⇄ Alemania), los paneles de salidas y llegadas, la ficha del tren y «Seguir»."
        m["Data: official German DELFI timetables via Transitous. Prices are not public: buy on bahn.de or in the DB Navigator app."] = "Datos: horarios oficiales alemanes DELFI a través de Transitous. Los precios no son públicos: se compran en bahn.de o en la app DB Navigator."
        m["Train types"] = "Tipos de tren"
        m["DB high-speed trains between major cities; seat reservation recommended."] = "Alta velocidad DB entre grandes ciudades; se recomienda reservar asiento."
        m["Intercity and EuroCity: long distance, also to Austria, Switzerland and Italy."] = "Intercity y EuroCity: larga distancia, también a Austria, Suiza e Italia."
        m["Regional trains (DB Regio and many other companies): valid with the Deutschlandticket."] = "Regionales (DB Regio y muchas otras empresas): válidos con el Deutschlandticket."
        m["City S-Bahn (Munich, Berlin, Hamburg, Stuttgart…): valid with the Deutschlandticket."] = "S-Bahn de las ciudades (Múnich, Berlín, Hamburgo, Stuttgart…): válidos con el Deutschlandticket."
        m["FlixTrain: low-cost long distance, Flix tickets only."] = "FlixTrain: larga distancia low cost, solo billete Flix."
        m["Night trains: ÖBB Nightjet and European Sleeper."] = "Trenes nocturnos: ÖBB Nightjet y European Sleeper."
        m["Monthly pass for all regional trains (RE, RB, S-Bahn), buses, trams and metro in Germany. Not valid on ICE, IC, EC and FlixTrain. Cancel by the 10th of the month. It costs €63 until 31/12/2026 and €66.80 from 1 January 2027."] = "Abono mensual para todos los trenes regionales (RE, RB, S-Bahn), autobuses, tranvías y metro de Alemania. No vale en ICE, IC, EC ni FlixTrain. Se cancela antes del día 10 del mes. Cuesta 63 € hasta el 31/12/2026 y 66,80 € desde el 1 de enero de 2027."
        m["Full fare: valid on any train on the chosen day."] = "Tarifa completa: vale en cualquier tren del día indicado."
        m["Cheaper when bought early, but tied to the chosen train (Zugbindung)."] = "Más baratos si se compran con antelación, pero vinculados al tren elegido (Zugbindung)."
        m["DB annual discount cards (25% or 50%, or unlimited travel with the 100)."] = "Tarjetas de descuento anuales de DB (25 % o 50 %, o viajes ilimitados con la 100)."
        m["Buy on bahn.de"] = "Comprar en bahn.de"
        m["Deutschlandticket: information and purchase"] = "Deutschlandticket: información y compra"
        m["DB Navigator app (tickets on your phone)"] = "App DB Navigator (billetes en el móvil)"
        m["Delays: your rights"] = "Retrasos: tus derechos"
        m["60 minutes or more late on arrival: 25% of the fare back; 120 minutes or more: 50% (minimum €4)."] = "60 minutos o más de retraso a la llegada: reembolso del 25 % del billete; 120 minutos o más: 50 % (mínimo 4 €)."
        m["Expected delay over 20 minutes: train binding is lifted and even with a Sparpreis you can take another train."] = "Retraso previsto de más de 20 minutos: se anula la Zugbindung y también con Sparpreis puedes tomar otro tren."
        m["Expected arrival between midnight and 5 am with at least 60 minutes' delay: taxi refunded up to €120."] = "Llegada prevista entre medianoche y las 5 con al menos 60 minutos de retraso: taxi reembolsado hasta 120 €."
        m["Claim within 3 months on bahn.de, in DB Navigator or with the Fahrgastrechte form."] = "La solicitud se hace en 3 meses en bahn.de, en DB Navigator o con el formulario Fahrgastrechte."
        m["Passenger rights (Fahrgastrechte)"] = "Derechos de los pasajeros (Fahrgastrechte)"
        m["Assistance for people with disabilities"] = "Asistencia para personas con discapacidad"
        m["Mon–Fri 6–22, Sat–Sun and holidays 8–20"] = "lun–vie 6–22, sáb–dom y festivos 8–20"
        m["Book assistance online (by 8 pm the day before)"] = "Reserva la asistencia en línea (antes de las 20 del día anterior)"
        m["Companies and stations"] = "Empresas y estaciones"
        m["All German railway companies"] = "Todas las empresas ferroviarias alemanas"
        m["DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… («Germany» filter)"] = "DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… (filtro «Alemania»)"
        m["Open a German station's board › «Station» tab: services, lifts and accessibility from bahnhof.de"] = "Abre el panel de una estación alemana › pestaña «Estación»: servicios, ascensores y accesibilidad de bahnhof.de"
        m["Germany: official DELFI timetables with delays and platforms in real time when published (Transitous)."] = "Alemania: horarios oficiales DELFI con retrasos y vías en tiempo real cuando se publican (Transitous)."
        m["Station services (Germany)"] = "Servicios en la estación (Alemania)"
        m["Services, shops, DB Lounge and map"] = "Servicios, tiendas, DB Lounge y plano"
        m["Lifts with real-time status"] = "Ascensores con estado en tiempo real"
        m["Station accessibility"] = "Accesibilidad de la estación"
        m["Assistance for people with disabilities (DB)"] = "Asistencia para personas con discapacidad (DB)"
        m["Valid with the Deutschlandticket"] = "Válido con el Deutschlandticket"
        m["/month"] = "/mes"
        m["Price and tickets on bahn.de (Sparpreis tied to the train)"] = "Precio y billetes en bahn.de (Sparpreis vinculados al tren)"
        m["ICE, regional trains, S-Bahn, Deutschlandticket, rights and companies"] = "ICE, regionales, S-Bahn, Deutschlandticket, derechos y empresas"
        m["Italy, Switzerland and Germany: websites, tickets, data"] = "Italia, Suiza y Alemania: webs, billetes, datos"
        m.putIfAbsent("Germany", "Alemania")
        m["Times and real time in the app: official German DELFI data (Transitous)"] = "Horarios y tiempo real en la app: datos oficiales alemanes DELFI (Transitous)"
        m["Trip not found"] = "Trayecto no encontrado"
        m.putIfAbsent("Real time · ", "Tiempo real · ")
        m["Scheduled times (no real time for this trip) · "] = "Horarios previstos (sin tiempo real para este trayecto) · "
    }

    /** Puntualità: confronto tra aziende e paesi. */
    private fun p11(m: HashMap<String, String>) {
        m["Companies and countries compared"] = "Empresas y países comparados"
        m["Companies to compare"] = "Empresas para comparar"
        m["Deutsche Bahn · official figures"] = "Deutsche Bahn · datos oficiales"
        m["Each country measures differently: in Italy (TrovaTreno) and Austria a train is on time within 5 minutes, in Germany under 6 minutes, for SBB under 3 minutes (stricter). DB and ÖBB count stops along the route, TrovaTreno counts arrivals. The fairest comparison is between trains of the same type: use the Regional or Long distance filter."] = "Cada país mide de forma distinta: en Italia (TrovaTreno) y Austria un tren es puntual hasta 5 minutos, en Alemania por debajo de 6 minutos y para los SBB por debajo de 3 minutos (más estricto). DB y ÖBB cuentan las paradas del recorrido, TrovaTreno las llegadas. La comparación más justa es entre trenes del mismo tipo: usa el filtro Regionales o Larga distancia."
        m["How to read the comparison"] = "Cómo leer la comparación"
        m["No companies to compare: tap «Add»."] = "No hay empresas en la comparación: toca «Añadir»."
        m["Remove from comparison"] = "Quitar de la comparación"
        m["Some chosen companies have no data yet: they will appear when available."] = "Algunas empresas elegidas aún no tienen datos: aparecerán cuando estén disponibles."
        m["Trenord · FerrovieNord network"] = "Trenord · red FerrovieNord"
        m.putIfAbsent("last ", "últimos ")
        m["long distance (Railjet, IC, Nightjet)"] = "larga distancia (Railjet, IC, Nightjet)"
        m.putIfAbsent("regional", "regionales")
        m["regional and S-Bahn"] = "regionales y S-Bahn"
        m["ÖBB · official figures"] = "ÖBB · datos oficiales"
    }

    /** Germania: scioperi e prezzi. */
    private fun p12(m: HashMap<String, String>) {
        m["Train strikes in Germany"] = "Huelgas de trenes en Alemania"
        m["News not reachable right now."] = "Noticias no disponibles ahora."
        m["No train strike announced in Germany in the last 14 days."] = "No se ha anunciado ninguna huelga de trenes en Alemania en los últimos 14 días."
        m["News in German (Google News): in Germany strikes are announced by the GDL and EVG unions a few days in advance, with no official calendar."] = "Noticias en alemán (Google News): en Alemania los sindicatos GDL y EVG anuncian las huelgas pocos días antes, sin calendario oficial."
        m["Traffic in Germany: disruptions and engineering works (DB)"] = "Circulación en Alemania: incidencias y obras (DB)"
        m["Open on bahn.de"] = "Abrir en bahn.de"
        m["For trains in Germany prices are not public: the lowest-price calendar is on bahn.de («Bestpreissuche»). With regional trains only, the Deutschlandticket is valid."] = "Para los trenes en Alemania los precios no son públicos: el calendario de precios más bajos está en bahn.de («Bestpreissuche»). Con solo trenes regionales vale el Deutschlandticket."
        m["Train strike in Germany"] = "Huelga de trenes en Alemania"
    }

    /** Emergenze per paese, affollamento e accessibilita' all'estero. */
    private fun p13(m: HashMap<String, String>) {
        m.putIfAbsent("Lombardy: Trenord and FerrovieNord trains from Trenord's official timetable (Regione Lombardia Open Data), with the delay from Trenord's live service.", "Lombardía: trenes Trenord y FerrovieNord del horario oficial de Trenord (Open Data de la Región de Lombardía), con el retraso del servicio en vivo de Trenord.")
        m.putIfAbsent("Austria", "Austria")
        m.putIfAbsent("France", "Francia")
        m.putIfAbsent("Germany, Austria, Switzerland and France: running trains placed on the line from the timetable and the realtime data the companies publish (Transitous); where there is no realtime the position follows the timetable.", "Alemania, Austria, Suiza y Francia: trenes en marcha colocados en la línea según el horario y los datos en tiempo real que publican las empresas (Transitous); sin tiempo real, la posición sigue el horario.")
        m.putIfAbsent("Finland (GPS)", "Finlandia (GPS)")
        m.putIfAbsent("Norway (GPS)", "Noruega (GPS)")
        m.putIfAbsent("GPS position", "Posición GPS")
        m.putIfAbsent("trains running or about to depart", "trenes en marcha o a punto de salir")
        m.putIfAbsent("Location unavailable", "Ubicación no disponible")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour. In Italy the position is estimated along the route from the timetable and the last stop (shortly after opening the dots move onto the line); elsewhere it stays around the hub: not GPS. It is a sample, not the whole network. Finland and Norway show the real GPS position (Digitraffic, Entur). Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "Cada punto es un tren que sale de un nodo en la próxima hora. En Italia la posición se estima a lo largo del trayecto con el horario y la última parada (poco después de abrir, los puntos pasan a la línea); en otros países queda alrededor del nodo: no es GPS. Es una muestra, no toda la red. Finlandia y Noruega muestran la posición GPS real (Digitraffic, Entur). Fuentes: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Vías: © colaboradores de OpenStreetMap, estilo CC-BY-SA 2.0 OpenRailwayMap.")
        m.putIfAbsent("Colored dots by delay, zoom and «Near me»", "Puntos de colores según el retraso, zoom y «Cerca de mí»")
        m.putIfAbsent("Alerts for my trip", "Avisos de mi viaje")
        m.putIfAbsent("Minutes from home to the departure station", "Minutos desde casa hasta la estación de salida")
        m.putIfAbsent("«Leave home» before the outbound train, «Last useful train» in the evening on the return and «Connection at risk» when a delay endangers a change. The departure is the station near home.", "«Sal de casa» antes del tren de ida, «Último tren útil» por la noche en la vuelta y «Conexión en riesgo» cuando un retraso pone en peligro un cambio. La salida es la estación cercana a casa.")
        m.putIfAbsent("Leave home", "Sal de casa")
        m.putIfAbsent("Leave home by", "Sal de casa antes de las")
        m.putIfAbsent("for the train at", "para el tren de las")
        m.putIfAbsent("Last useful train", "Último tren útil")
        m.putIfAbsent("Last useful train to", "Último tren útil hacia")
        m.putIfAbsent("departs at", "sale a las")
        m.putIfAbsent("Connection at risk at", "Conexión en riesgo en")
        m.putIfAbsent("expected arrival", "llegada prevista")
        m.putIfAbsent("departure", "salida")
        m.putIfAbsent("Your history on this train", "Tu historial en este tren")
        m.putIfAbsent("Average delay", "Retraso medio")
        m.putIfAbsent("On time (within 5 min)", "Puntual (hasta 5 min)")
        m.putIfAbsent("Worst", "Peor")
        m.putIfAbsent("Days recorded", "Días registrados")
        m.putIfAbsent("Data stays on your phone only.", "Datos solo en tu teléfono.")
        m.putIfAbsent("Most punctual among the next trains", "El más puntual entre los próximos trenes")
        m.putIfAbsent("runs observed", "circulaciones observadas")
        m.putIfAbsent("TrovaTreno data from last month; they do not guarantee today's delay.", "Datos de TrovaTreno del último mes; no garantizan el retraso de hoy.")
        m.putIfAbsent("RFI notice on your route", "Aviso de RFI sobre tu trayecto")
        m.putIfAbsent("Notices on your routes", "Avisos sobre tus trayectos")
        m.putIfAbsent("Until", "Hasta el")
        m.putIfAbsent("Timetable notice", "Aviso sobre el horario")
        m.putIfAbsent("From", "Del")
        m.putIfAbsent("to", "al")
        m.putIfAbsent("arrival at destination with", "llegada al destino con")
        m.putIfAbsent("minutes", "minutos")
        m.putIfAbsent("Tap for the source", "Toca para la fuente")
        m.putIfAbsent("Service interruption between Rho and Parabiago", "Interrupción del servicio entre Rho y Parabiago")
        m.putIfAbsent("Timetable remodulation 126.1: staff shifts remain unchanged.", "Remodulación del horario 126.1: los turnos del personal no cambian.")
        m.putIfAbsent("From the departures of the next hours. High-speed, Intercity and Trenitalia regional trains have no line in the official timetables: they are shown by category and route.", "A partir de las salidas de las próximas horas. Los trenes de alta velocidad, Intercity y regionales de Trenitalia no tienen línea en los horarios oficiales: se indican por categoría y trayecto.")
        m.putIfAbsent("Trenord network / Lombardy", "Red Trenord / Lombardía")
        m.putIfAbsent("Other network or region", "Otra red o región")
        m.putIfAbsent("Over 60 with CartaFreccia: FrecciaSENIOR offer on Frecce trains (from €29). Discounts and conditions detailed on the official page.", "Mayores de 60 con CartaFreccia: oferta FrecciaSENIOR en los trenes Frecce (desde 29 €). Descuentos y condiciones detallados en la página oficial.")
        m.putIfAbsent("From age 65, single tickets are 20% off the Lombardy Regional Single Fare; in the STIBM area 25% off ordinary monthly and annual passes (to be loaded on the Io Viaggio card, €10).", "Desde los 65 años, billetes sencillos con un 20 % de descuento sobre la Tarifa Única Regional de Lombardía; en el área STIBM 25 % de descuento en abonos mensuales y anuales ordinarios (a cargar en la tarjeta Io Viaggio, 10 €).")
        m.putIfAbsent("Over 60: Italo Senior, 40% to 60% off the Flex fare, in Smart and Prima Business; non-refundable, changeable up to 72 hours before departure.", "Mayores de 60: Italo Senior, del 40 % al 60 % de descuento sobre la tarifa Flex, en Smart y Prima Business; no reembolsable, modificable hasta 72 horas antes de la salida.")
        m.putIfAbsent("Reduced General Abonnement (GA) for women from their 64th birthday (from 65 starting in 2028) and for men from 65.", "Abono general (AG) reducido para mujeres desde los 64 años (desde 2028, desde los 65) y para hombres desde los 65.")
        m.putIfAbsent("Senior BahnCard from age 65; the BahnCard 50 (ages 27 to 64) gives 50% off the Flexpreis and 25% off long-distance Sparpreis fares.", "BahnCard Senior desde los 65 años; la BahnCard 50 (de 27 a 64 años) da un 50 % en el Flexpreis y un 25 % en los Sparpreis de larga distancia.")
        m.putIfAbsent("From age 65, men and women: Vorteilscard Senior at €31 (valid 1 year).", "Desde los 65 años, hombres y mujeres: Vorteilscard Senior a 31 € (válida 1 año).")
        m.putIfAbsent("From age 60: Carte Avantage Senior at €49 (confirm the price when buying): 30% off trips in 2nd and 1st class, 60% for up to 3 accompanying children aged 4-11; TER discounts vary by region.", "Desde los 60 años: Carte Avantage Senior a 49 € (confirma el precio al comprar): 30 % en viajes en 2.ª y 1.ª clase, 60 % para hasta 3 niños de 4 a 11 años que te acompañen; descuentos TER variables según la región.")
        m.putIfAbsent("The prices shown are the total for all passengers.", "Los precios mostrados son el total para todos los pasajeros.")
        m.putIfAbsent("Age discounts vary by country and company: here kids are 4 to 14, but other companies use other ages. Family discounts: check when buying.", "Los descuentos por edad cambian según el país y la compañía: aquí los niños tienen de 4 a 14 años, pero otras compañías usan otras edades. Descuentos familiares: comprueba al comprar.")
        m.putIfAbsent("Age rules for each company", "Reglas de edad de cada compañía")
        m.putIfAbsent("Age rules: companies and countries", "Reglas de edad: compañías y países")
        m.putIfAbsent("Age reductions depend on the country, company, train type and fare. Summary from the official sites (3/11/2026): they may change, always check the source before buying.", "Las reducciones por edad dependen del país, la compañía, el tipo de tren y la tarifa. Resumen de las webs oficiales (3/11/2026): pueden cambiar, comprueba siempre la fuente antes de comprar.")
        m.putIfAbsent("National trains: under 4 free without a seat; ages 4 to 14 (until the 15th birthday) 50% off the Base fare.", "Trenes nacionales: gratis menores de 4 años sin asiento; de 4 a 14 años (hasta cumplir 15) 50 % de descuento sobre la tarifa Base.")
        m.putIfAbsent("Regional trains: under 4 free (with an adult, without a seat); ages 4 to under 12 get 50% off. Some regions have their own rules (Lombardy, Campania, Abruzzo, Sardinia, Apulia, Trento, Bolzano).", "Regionales: gratis menores de 4 años (con un adulto, sin asiento); de 4 a menos de 12 años 50 % de descuento. Algunas regiones tienen reglas propias (Lombardía, Campania, Abruzos, Cerdeña, Apulia, Trento, Bolzano).")
        m.putIfAbsent("International trains (EuroCity, EuroNight): free up to age 5 without a seat; ages 6 to 14 get the «CHILD» offer (about 50%), varies by service.", "Trenes internacionales (EuroCity, EuroNight): gratis hasta 5 años sin asiento; de 6 a 14 años oferta «CHILD» (aprox. 50 %), varía según el servicio.")
        m.putIfAbsent("Up to age 3 free on the whole fleet, without taking a seat; ages 4 to under 14 get 50% off the Regional Single Fare; in the STIBM area under-14s travel free (with a document proving their age).", "Hasta 3 años gratis en toda la flota, sin ocupar asiento; de 4 a menos de 14 años 50 % de descuento sobre la Tarifa Única Regional; en el área STIBM los menores de 14 años viajan gratis (con un documento que pruebe la edad).")
        m.putIfAbsent("Under 3 free, without an assigned seat and held by an adult (with more than one child per adult a paid seat is required). Italo Family offer for 2–4 people: details on the site.", "Menores de 3 años gratis, sin asiento asignado y en brazos de un adulto (con más de un niño por adulto hace falta un asiento de pago). Oferta Italo Familia para 2–4 personas: detalles en la web.")
        m.putIfAbsent("Under 6 free; ages 6 to under 16 pay half price (or the minimum fare), or travel free with a parent holding a valid ticket if you have the Junior Card. Under 25: Youth Half-Fare.", "Menores de 6 años gratis; de 6 a menos de 16 años mitad de precio (o precio mínimo), o gratis con un progenitor con billete válido si tienes la Tarjeta Junior. Menores de 25: Medio precio jóvenes.")
        m.putIfAbsent("Under 6 free; ages 6 to 14 travel free on long-distance trains when accompanied by an adult or a sibling aged 15 or over. Regional trains and discounted tickets may have different rules.", "Menores de 6 años gratis; de 6 a 14 años viajan gratis en trenes de larga distancia acompañados de un adulto o de un hermano de 15 años o más. Regionales y billetes con descuento pueden tener otras reglas.")
        m.putIfAbsent("Under 6 free without a ticket, with an adult; ages 6 to 14 (until the day before the 15th birthday) free with the Vorteilscard Family (€21, up to 4 children), only on ÖBB trains in Austria; from 15 adult fare.", "Menores de 6 años gratis sin billete, con un adulto; de 6 a 14 años (hasta el día antes del 15.º cumpleaños) gratis con la Vorteilscard Family (21 €, hasta 4 niños), solo en trenes ÖBB en Austria; desde los 15 años tarifa de adulto.")
        m.putIfAbsent("Under 4 free on the lap (TGV INOUI, TER, Intercités), one child per traveller; own seat with the Forfait Bambin at €9. Ages 4 to 11: 60% off for those accompanying a Carte Avantage Adulte holder. OUIGO has its own fares.", "Menores de 4 años gratis en brazos (TGV INOUI, TER, Intercités), un solo niño por viajero; asiento propio con el Forfait Bambin a 9 €. De 4 a 11 años: 60 % de descuento para quienes acompañan a un titular de la Carte Avantage Adulte. OUIGO tiene tarifas propias.")
        m.putIfAbsent("Plan B", "Plan B")
        m.putIfAbsent("Missed the train or the connection? Find alternatives from where you are now.", "¿Has perdido el tren o la conexión? Busca alternativas desde donde estás ahora.")
        m.putIfAbsent("Where you are now", "Dónde estás ahora")
        m.putIfAbsent("Another station…", "Otra estación…")
        m.putIfAbsent("Alternatives to", "Alternativas hacia")
        m.putIfAbsent("Looking for alternatives…", "Buscando alternativas…")
        m.putIfAbsent("How Binario works", "Cómo funciona Binario")
        m.putIfAbsent("Basic or Full", "Básico o Completo")
        m.putIfAbsent("On the Search screen choose how many features to see. You can change it any time: your choice is saved.", "En la pantalla Buscar elige cuántas funciones ver. Puedes cambiarlo cuando quieras: la elección se guarda.")
        m.putIfAbsent("Offline timetables", "Horarios sin conexión")
        m.putIfAbsent("In the results tap «Save these times to use them offline»: you will find them in Offline timetables even without a network.", "En los resultados toca «Guardar estos horarios para usarlos sin conexión»: los encontrarás en Horarios sin conexión incluso sin red.")
        m.putIfAbsent("Widgets", "Widgets")
        m.putIfAbsent("Long-press the home screen, choose Widgets and add Binario: departures and delays always in sight.", "Mantén pulsada la pantalla de inicio, elige Widgets y añade Binario: salidas y retrasos siempre a la vista.")
        m.putIfAbsent("Punctuality", "Puntualidad")
        m.putIfAbsent("Under each icon is the tab name: search a station or a train and see how many arrive on time.", "Bajo cada icono está el nombre de la pestaña: busca una estación o un tren y mira cuántos llegan a tiempo.")
        m.putIfAbsent("Got it", "Entendido")
        m.putIfAbsent("less than a minute ago", "hace menos de un minuto")
        m.putIfAbsent("%d min ago", "hace %d min")
        m.putIfAbsent("%d h ago", "hace %d h")
        m.putIfAbsent("%d days ago", "hace %d días")
        m.putIfAbsent("Timetables saved %s. They may have changed: connect to refresh them.", "Horarios guardados %s. Pueden haber cambiado: conéctate para actualizarlos.")
        m.putIfAbsent("Last saved message: the Trenord page is not responding right now.", "Último mensaje guardado: la página de Trenord no responde ahora.")
        m.putIfAbsent("The downloaded file is not a valid APK. Try downloading it again.", "El archivo descargado no es un APK válido. Vuelve a descargarlo.")
        m.putIfAbsent("The downloaded file is not Binario.", "El archivo descargado no es Binario.")
        m.putIfAbsent("This version is already installed or is older.", "Esta versión ya está instalada o es más antigua.")
        m.putIfAbsent("Your Binario was installed with a different signature from the updates (for example a test build or another source): Android cannot update it and would show “App not installed”. Uninstall Binario and install the latest version from the download page: you will lose favourites and settings.", "Tu Binario se instaló con una firma distinta a la de las actualizaciones (por ejemplo una versión de prueba u otro origen): Android no puede actualizarlo y mostraría «Aplicación no instalada». Desinstala Binario e instala la última versión desde la página de descarga: perderás favoritos y ajustes.")
        m.putIfAbsent("Open the download page", "Abrir la página de descarga")
        m.putIfAbsent("Show the message", "Mostrar el mensaje")
        m.putIfAbsent("1 source has problems: related features use backups or the latest saved data.", "1 fuente tiene problemas: las funciones relacionadas usan las alternativas o los últimos datos guardados.")
        m.putIfAbsent("%d sources have problems: related features use backups or the latest saved data.", "%d fuentes tienen problemas: las funciones relacionadas usan las alternativas o los últimos datos guardados.")
        m.putIfAbsent("All sources respond, but some are busy (too many requests): the app uses backups.", "Todas las fuentes responden, pero algunas están ocupadas (demasiadas solicitudes): la app usa las alternativas.")
        m.putIfAbsent("Latest message from Trenord", "Último mensaje de Trenord")
        m.putIfAbsent("Reading the message from the Trenord site…", "Leyendo el mensaje del sitio de Trenord…")
        m.putIfAbsent("Message not available right now.", "Mensaje no disponible ahora.")
        m.putIfAbsent("Line status", "Estado de la línea")
        m.putIfAbsent("Latest notice", "Último aviso")
        m.putIfAbsent("Show all", "Mostrar todo")
        m.putIfAbsent("Show less", "Mostrar menos")
        m.putIfAbsent("Open the line page", "Abrir la página de la línea")
        m.putIfAbsent("Save these times to use them offline", "Guardar estos horarios para usarlos sin conexión")
        m.putIfAbsent("Saved: find it in Offline timetables", "Guardado: lo encuentras en Horarios sin conexión")
        m.putIfAbsent("No saved timetables", "No hay horarios guardados")
        m.putIfAbsent("To have timetables without a network: search for a trip, then in the results tap «Save these times to use them offline». You will find it here.", "Para tener horarios sin red: busca un viaje y, en los resultados, toca «Guardar estos horarios para usarlos sin conexión». Lo encontrarás aquí.")
        m.putIfAbsent("Tap a search to reopen it, even without a network.", "Toca una búsqueda para reabrirla, incluso sin red.")
        m.putIfAbsent("Search for a trip", "Buscar un viaje")
        m.putIfAbsent("Busy: too many requests from your address (429). The app tries the other servers and then Postpass; retry in 15 seconds.", "Ocupado: demasiadas solicitudes desde tu dirección (429). La app prueba los otros servidores y luego Postpass; vuelve a intentarlo en 15 segundos.")
        m.putIfAbsent("Share of trains on time for each station in the chosen month. Type a name to search, then tap it to open.", "Porcentaje de trenes puntuales en cada estación durante el mes elegido. Escribe un nombre para buscar y tócalo para abrirlo.")
        m.putIfAbsent("Share of runs on time for each train in the chosen month. Search by number or destination, then tap it to open.", "Porcentaje de circulaciones puntuales de cada tren en el mes elegido. Busca por número o destino y tócalo para abrirlo.")
        m.putIfAbsent("Search station", "Buscar estación")
        m.putIfAbsent("Train number or destination", "Número de tren o destino")
        m.putIfAbsent("Clear", "Borrar")
        m.putIfAbsent("Least punctual", "Menos puntuales")
        m.putIfAbsent("Most punctual", "Más puntuales")
        m.putIfAbsent("Milan Passante", "Passante de Milán")
        m.putIfAbsent("RFI network", "Red RFI")
        m.putIfAbsent("FerrovieNord network", "Red FerrovieNord")
        m.putIfAbsent("%d results", "%d resultados")
        m.putIfAbsent("%d results for «%s»", "%d resultados para «%s»")
        m.putIfAbsent("No results", "Sin resultados")
        m.putIfAbsent("No alternatives found in the next hours.", "No se han encontrado alternativas en las próximas horas.")
        m.putIfAbsent("direct", "directo")
        m.putIfAbsent("changes", "cambios")
        m.putIfAbsent("Tap a train to open it. Times are scheduled: check delays and platforms on its page.", "Toca un tren para abrirlo. Las horas son programadas: consulta retrasos y andenes en su ficha.")
        m.putIfAbsent("Trains in Austria", "Trenes en Austria")
        m.putIfAbsent("Trains in France", "Trenes en Francia")
        m.putIfAbsent("Trains in Italy", "Trenes en Italia")
        m.putIfAbsent("Features", "Funciones")
        m.putIfAbsent("Basic", "Básicas")
        m.putIfAbsent("Full", "Completas")
        m.putIfAbsent("Estimate: scheduled time plus the known delay.", "Estimación: horario previsto más el retraso conocido.")
        m.putIfAbsent("This train usually arrives with", "Este tren suele llegar con")
        m.putIfAbsent("Updated just now", "Actualizado ahora")
        m.putIfAbsent("Data from %d min ago", "Datos de hace %d min")
        m.putIfAbsent("tap ↻ to refresh", "toca ↻ para actualizar")
        m.putIfAbsent("Cancelled today", "Suprimido hoy")
        m.putIfAbsent("Extra train today", "Tren adicional hoy")
        m.putIfAbsent("Replaced by train", "Sustituido por el tren")
        m.putIfAbsent("Runs in place of train", "Circula en lugar del tren")
        m.putIfAbsent("Other times", "Otras veces")
        m.putIfAbsent("replaced by", "sustituido por")
        m.putIfAbsent("in place of", "en lugar del")
        m.putIfAbsent("network", "red")
        m.putIfAbsent("Trenord · TILO", "Trenord · TILO")
        m.putIfAbsent("All networks", "Todas las redes")
        m.putIfAbsent("Switzerland · SBB", "Suiza · SBB")
        m.putIfAbsent("All", "Todos")
        m.putIfAbsent("FerrovieNord", "FerrovieNord")
        m.putIfAbsent("RFI", "RFI")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Sources: ViaggiaTreno (Italy, Trenord, FerrovieNord) and transport.opendata.ch (TILO, Switzerland). Trenord and TILO are a single service.", "Muestra de los paneles de salidas de los principales nudos (próximas horas): no es toda la red. Fuentes: ViaggiaTreno (Italia, Trenord, FerrovieNord) y transport.opendata.ch (TILO, Suiza). Trenord y TILO son un único servicio.")
        m.putIfAbsent("Italia · RFI", "Italia · RFI")
        m.putIfAbsent("Trenord · rete RFI", "Trenord · red RFI")
        m.putIfAbsent("Trenord · rete FerrovieNord", "Trenord · red FerrovieNord")
        m.putIfAbsent("TILO", "TILO")
        m.putIfAbsent("Svizzera · FFS/SBB", "Suiza · SBB")
        m.putIfAbsent("Nessun ritardo di 5 minuti o più nei nodi controllati.", "Sin retrasos de 5 minutos o más en los nudos controlados.")
        m.putIfAbsent("Campione dai tabelloni dei principali nodi (partenze delle prossime ore): non è l'elenco di tutta la rete. Fonti: ViaggiaTreno (Italia, Trenord, FerrovieNord) e transport.opendata.ch (TILO, Svizzera).", "Muestra de los paneles de salidas de los principales nudos (próximas horas): no es toda la red. Fuentes: ViaggiaTreno (Italia, Trenord, FerrovieNord) y transport.opendata.ch (TILO, Suiza).")
        m.putIfAbsent("Trains in Switzerland", "Trenes en Suiza")
        m.putIfAbsent("Timetables, delays and platforms of Italian trains (Trenitalia, Italo, Trenord, FerrovieNord and regional railways).", "Horarios, retrasos y andenes de los trenes italianos (Trenitalia, Italo, Trenord, FerrovieNord y ferrocarriles regionales).")
        m.putIfAbsent("Timetables, delays and platforms of Swiss trains (SBB, TILO and regional railways), with crowding and station services where SBB publishes them.", "Horarios, retrasos y andenes de los trenes suizos (SBB, TILO y ferrocarriles regionales), con ocupación y servicios en la estación donde SBB los publica.")
        m.putIfAbsent("Search a station by name, a train by number, or a route. Journey search, departure board, train page and “Follow” work.", "Busca una estación por nombre, un tren por número o un trayecto. Funcionan la búsqueda de viajes, el panel de salidas, la ficha del tren y «Seguir».")
        m.putIfAbsent("Data: ViaggiaTreno, Trenord and Italo. Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "Datos: ViaggiaTreno, Trenord e Italo. El tiempo real depende de lo que publiquen las empresas y puede faltar en algunos trenes. Siempre prevalecen los paneles y los avisos.")
        m.putIfAbsent("Data: SBB (open data). Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "Datos: SBB (datos abiertos). El tiempo real depende de lo que publiquen las empresas y puede faltar en algunos trenes. Siempre prevalecen los paneles y los avisos.")
        m.putIfAbsent("Timetables, delays and platforms of Austrian trains (ÖBB, Westbahn and regional operators), when real-time data is published.", "Horarios, retrasos y andenes de los trenes austriacos (ÖBB, Westbahn y operadores regionales), cuando se publican datos en tiempo real.")
        m.putIfAbsent("Timetables, delays and platforms of French trains (TGV, TER, Intercités, RER), when real-time data is published.", "Horarios, retrasos y andenes de los trenes franceses (TGV, TER, Intercités, RER), cuando se publican datos en tiempo real.")
        m.putIfAbsent("Search the station with its Italian name too: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Trip search (also with Italy), station board, train page and «Follow» all work.", "Busca la estación también con el nombre italiano: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Funcionan la búsqueda de viajes (también con Italia), el panel, la ficha del tren y «Seguir».")
        m.putIfAbsent("Data: official timetables via Transitous; real time depends on what operators publish and may be missing for some trips. Prices are not public: tickets on the official sites. Station boards and announcements always prevail.", "Datos: horarios oficiales a través de Transitous; el tiempo real depende de lo que publiquen las compañías y puede faltar en algunos viajes. Los precios no son públicos: billetes en las webs oficiales. Siempre prevalecen los paneles y avisos.")
        m.putIfAbsent("Tickets and official information", "Billetes e información oficial")
        m.putIfAbsent("Prices for these trains are not public: the lowest-price calendar is on the operators' sites (ÖBB, SNCF) or on bahn.de.", "Los precios de estos trenes no son públicos: el calendario de precios más bajos está en las webs de las compañías (ÖBB, SNCF) o en bahn.de.")
        m.putIfAbsent("Austria and France: official timetables with real-time delays and platforms when published (Transitous).", "Austria y Francia: horarios oficiales con retrasos y andenes en tiempo real cuando se publican (Transitous).")
        m.putIfAbsent("Prices and tickets on the operators' sites (ÖBB, SNCF) or on bahn.de", "Precios y billetes en las webs de las compañías (ÖBB, SNCF) o en bahn.de")
        m.putIfAbsent("Sharing? When the time is right…", "¿Compartir? Cuando llegue el momento…")
        m.putIfAbsent("Unofficial app: not affiliated with, sponsored or endorsed by Trenitalia, RFI, Italo, Trenord or any other transport company. Data comes from public sources.", "App no oficial: no está afiliada, patrocinada ni respaldada por Trenitalia, RFI, Italo, Trenord ni ninguna otra empresa de transporte. Los datos proceden de fuentes públicas.")
        m.putIfAbsent("Tap again for the board and services", "Toca de nuevo para el panel y los servicios")
        m.putIfAbsent("Services near this station", "Servicios cerca de esta estación")
        m.putIfAbsent("Board", "Panel")
        m.putIfAbsent("Platform ", "Vía ")
        m.putIfAbsent("Delay now: ", "Retraso ahora: ")
        m.putIfAbsent("Scheduled times: the delay may change. Created with Binario.", "Horarios programados: el retraso puede cambiar. Creado con Binario.")
        m.putIfAbsent("Tracks", "Vías")
        m.putIfAbsent("Ahead", "Delante")
        m.putIfAbsent("Behind", "Detrás")
        m.putIfAbsent("Trains ahead and behind yours", "Trenes delante y detrás del tuyo")
        m.putIfAbsent("Compared at the next stop: ", "Comparación en la próxima parada: ")
        m.putIfAbsent("Your train", "Tu tren")
        m.putIfAbsent("The train ahead is running late and could slow yours down.", "El tren de delante va con retraso y podría frenar el tuyo.")
        m.putIfAbsent("Trains in the same direction passing that stop in the 45 minutes before and after yours. Source: ViaggiaTreno.", "Trenes en la misma dirección que pasan por esa parada en los 45 minutos antes y después del tuyo. Fuente: ViaggiaTreno.")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "Cada punto es un tren que sale de un nodo en la próxima hora, colocado alrededor del nodo: no es su posición GPS. Es una muestra, no toda la red. Fuentes: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Vías: © colaboradores de OpenStreetMap, estilo CC-BY-SA 2.0 OpenRailwayMap.")
        m.putIfAbsent("Watch and smartwatch", "Reloj y smartwatch")
        m.putIfAbsent("Followed train status on the watch too", "Estado del tren seguido también en el reloj")
        m.putIfAbsent("Sends a normal (not pinned) notification when the delay, platform or next stop changes, so Mi Band, Wear OS and other watches show it.", "Envía una notificación normal (no fija) cuando cambian el retraso, la vía o la próxima parada, para que Mi Band, Wear OS y otros relojes la muestren.")
        m.putIfAbsent("Send a test notification", "Enviar notificación de prueba")
        m.putIfAbsent("Test: if you see this on your watch, all is well.", "Prueba: si ves esto en el reloj, todo está bien.")
        m.putIfAbsent("Watch status", "Estado en el reloj")
        m.putIfAbsent("Binario does not talk to the watch directly: notifications (alerts, strikes, platform changes, delays, reminders) reach your wrist through the watch's own app. Mi Band: in Mi Fitness or Zepp Life open your device › Notifications and reminders › App alerts and turn on Binario. Wear OS: they arrive on their own (check in the Wear OS app › Notifications). In both cases set Binario to «no restrictions» in battery settings. The pinned train notification (with «Stop following») is usually not forwarded: that is why the separate alerts above exist.", "Binario no habla directamente con el reloj: las notificaciones (avisos, huelgas, cambios de vía, retrasos, recordatorios) llegan a la muñeca a través de la app del reloj. Mi Band: en Mi Fitness o Zepp Life abre tu dispositivo › Notificaciones y recordatorios › Avisos de apps y activa Binario. Wear OS: llegan solas (revisa en la app Wear OS › Notificaciones). En ambos casos pon Binario en «sin restricciones» en la batería. La notificación fija del tren (con «Dejar de seguir») normalmente no se reenvía: por eso existen los avisos separados de arriba.")
        m.putIfAbsent("Cancelled", "Suprimido")
        m.putIfAbsent("Next: ", "Próxima: ")
        m.putIfAbsent("Pl. ", "Vía ")
        m.putIfAbsent("Delays right now: Italy, Switzerland, Germany", "Retrasos ahora: Italia, Suiza, Alemania")
        m.putIfAbsent("Not enough data right now", "No hay datos suficientes ahora")
        m.putIfAbsent("Trains by delay band", "Trenes por franja de retraso")
        m.putIfAbsent("Average delay", "Retraso medio")
        m.putIfAbsent("On time (up to 5 min)", "Puntual (hasta 5 min)")
        m.putIfAbsent("Trains with a delay reading", "Trenes con retraso medido")
        m.putIfAbsent("Hubs with the highest average delay", "Nodos con mayor retraso medio")
        m.putIfAbsent("Sample of trains departing from the big hubs in the next hour, not the whole network. For Italian trains the delay is known only after departure from the origin (ViaggiaTreno): so only trains with a delay reading are counted, and the comparison with Switzerland and Germany, which also give the predicted delay, is only indicative. For monthly statistics and the comparison between companies see below.", "Muestra de los trenes que salen de los grandes nodos en la próxima hora, no toda la red. En los trenes italianos el retraso solo se conoce tras la salida del origen (ViaggiaTreno): por eso solo se cuentan los trenes con retraso medido, y la comparación con Suiza y Alemania, que también dan el retraso previsto, es solo orientativa. Para las estadísticas mensuales y la comparación entre empresas, mira más abajo.")
        m.putIfAbsent("Train map", "Mapa de trenes")
        m.putIfAbsent("Delay", "Retraso")
        m.putIfAbsent("Send by email", "Enviar por correo")
        m.putIfAbsent("Info and sources", "Info y fuentes")
        m.putIfAbsent("Rainbow theme", "Tema arcoíris")
        m.putIfAbsent("Each tile has a rainbow colour", "Cada recuadro tiene un color del arcoíris")
        m.putIfAbsent("Custom colours", "Colores personalizados")
        m.putIfAbsent("Choose your own main colour", "Elige tú el color principal")
        m.putIfAbsent("Main colour", "Color principal")
        m.putIfAbsent("Colour code (hex)", "Código de color (hex)")
        m.putIfAbsent("Dark background", "Fondo oscuro")
        m.putIfAbsent("Apply", "Aplicar")
        m.putIfAbsent("Text size", "Tamaño del texto")
        m.putIfAbsent("Large", "Grande")
        m.putIfAbsent("Very large", "Muy grande")
        m.putIfAbsent("Huge", "Enorme")
        m.putIfAbsent("Enlarges the text across the app; lines wrap instead of being cut off.", "Agranda el texto en toda la app; las líneas se ajustan en vez de cortarse.")
        m.putIfAbsent("Weather at", "Tiempo en")
        m.putIfAbsent("Feels like", "Sensación")
        m.putIfAbsent("Wind", "Viento")
        m.putIfAbsent("Arriving", "Llegando")
        m.putIfAbsent("Departs in", "Sale en")
        m.putIfAbsent("Last 30 days history", "Historial de los últimos 30 días")
        m.putIfAbsent("Cancelled", "Suprimidos")
        m.putIfAbsent("Measured on arrival at", "Medido a la llegada a")
        m.putIfAbsent("runs operated", "servicios realizados")
        m.putIfAbsent("Data collected by Binario, unofficial.", "Datos recogidos por Binario, no oficiales.")
        m.putIfAbsent("Delay ranking", "Clasificación de retrasos")
        m.putIfAbsent("By day", "Por día")
        m.putIfAbsent("30 days", "30 días")
        m.putIfAbsent("Sample from the main hubs: not the list of the whole network.", "Muestra de los nodos principales: no es toda la red.")
        m.putIfAbsent("Most delayed", "Más retrasados")
        m.putIfAbsent("Most punctual", "Más puntuales")
        m.putIfAbsent("runs", "servicios")
        m.putIfAbsent("The history is still filling up.", "El historial aún se está llenando.")
        m.putIfAbsent("Binario collects delays every day: in a few days the ranking will be here.", "Binario recoge los retrasos cada día: en unos días verás aquí la clasificación.")
        m.putIfAbsent("Last 30 days, trains observed by Binario", "Últimos 30 días, trenes observados por Binario")
        m.putIfAbsent("Choose the style", "Elige el estilo")
        m.putIfAbsent("The style changes colours, shapes and the layout of the Home, widgets included. You can change it whenever you like.", "El estilo cambia colores, formas y disposición del inicio, también en los widgets. Puedes cambiarlo cuando quieras.")
        m.putIfAbsent("The usual look, green", "El aspecto de siempre, verde")
        m.putIfAbsent("Dark amber Solari board", "Panel Solari oscuro y ámbar")
        m.putIfAbsent("Find a train", "Buscar tren")
        m.putIfAbsent("By number or line", "Por número o línea")
        m.putIfAbsent("Arrivals and departures", "Llegadas y salidas")
        m.putIfAbsent("Around you", "A tu alrededor")
        m.putIfAbsent("Train map", "Mapa de trenes")
        m.putIfAbsent("Where they are now", "Dónde están ahora")
        m.putIfAbsent("Who is most delayed", "Quién va más retrasado")
        m.putIfAbsent("What changes", "Qué cambia")
        m.putIfAbsent("Alarms and reminders", "Alarmas y recordatorios")
        m.putIfAbsent("Saved on the phone", "Guardados en el teléfono")
        m.putIfAbsent("Statistics", "Estadísticas")
        m.putIfAbsent("Refunds", "Reembolsos")
        m.putIfAbsent("Passenger rights", "Derechos del viajero")
        m.putIfAbsent("Help", "Ayuda")
        m.putIfAbsent("Frequently asked questions", "Preguntas frecuentes")
        m.putIfAbsent("Clear", "Despejado")
        m.putIfAbsent("Partly cloudy", "Poco nuboso")
        m.putIfAbsent("Overcast", "Cubierto")
        m.putIfAbsent("Fog", "Niebla")
        m.putIfAbsent("Drizzle", "Llovizna")
        m.putIfAbsent("Rain", "Lluvia")
        m.putIfAbsent("Snow", "Nieve")
        m.putIfAbsent("Showers", "Chubascos")
        m.putIfAbsent("Thunderstorm", "Tormenta")
        m.putIfAbsent("Variable", "Variable")
        m.putIfAbsent("Light tiles", "Mosaicos claros")
        m.putIfAbsent("White tiles on a light blue background, blue header", "Mosaicos blancos sobre fondo azul claro, cabecera azul")
        m.putIfAbsent("Coloured tiles", "Mosaicos de colores")
        m.putIfAbsent("Each function has its own pastel colour", "Cada función tiene su color pastel")
        m.putIfAbsent("Dark board", "Panel oscuro")
        m.putIfAbsent("Black and gold, fixed-width numbers", "Negro y oro, números de ancho fijo")
        m.putIfAbsent("Wide-tile list", "Lista de mosaicos anchos")
        m.putIfAbsent("Wide rows split into sections", "Filas anchas por secciones")
        m.putIfAbsent("My train up front", "Mi tren en primer plano")
        m.putIfAbsent("Your next train on top, with a countdown", "Arriba tu próximo tren con cuenta atrás")
        m.putIfAbsent("Four big tiles and a list", "Cuatro grandes y una lista")
        m.putIfAbsent("Four big tiles, then rows for the rest", "Cuatro mosaicos grandes y filas para el resto")
        m.putIfAbsent("Lines and codes", "Líneas y siglas")
        m.putIfAbsent("Rows with a coloured code on the left, like on the lines", "Filas con la sigla de color a la izquierda, como en las líneas")
        m.putIfAbsent("High contrast", "Alto contraste")
        m.putIfAbsent("Black and yellow, big tiles and thick borders", "Negro y amarillo, mosaicos grandes y bordes gruesos")
        m.putIfAbsent("Three columns by section", "Tres columnas por secciones")
        m.putIfAbsent("Compact icons in three columns, with sections", "Iconos compactos en tres columnas, con secciones")
        m.putIfAbsent("Today's dashboard", "Panel de hoy")
        m.putIfAbsent("Last 30 days, current delays and shortcuts", "Últimos 30 días, retrasos actuales y accesos directos")
        m.putIfAbsent("Fixes, service status, privacy", "Correcciones, estado de los servicios, privacidad")
        m.putIfAbsent("Weather at the station (Open-Meteo)", "Tiempo en la estación (Open-Meteo)")
        m.putIfAbsent("Real time", "En tiempo real")
        m.putIfAbsent("Mine", "Los míos")
        m.putIfAbsent("Prefer to write by email?", "¿Prefieres escribir por correo?")
        m.putIfAbsent("Conditions and fares by company", "Condiciones y tarifas por empresa")
        m.putIfAbsent("Fares and tickets", "Tarifas y billetes")
        m.putIfAbsent("Rights and refunds", "Derechos y reembolsos")
        m.putIfAbsent("Source: official website of", "Fuente: sitio oficial de")
        m.putIfAbsent("links checked on", "enlaces comprobados el")
        m.putIfAbsent("Conditions and fares change: the app opens each company's official pages without copying their prices. The company's own text prevails.", "Las condiciones y las tarifas cambian: la app abre las páginas oficiales de cada empresa sin copiar sus precios. Prevalece el texto de la empresa.")
        m.putIfAbsent("Trains departing soon from the main hubs of Italy, Switzerland and Germany, coloured by delay", "Trenes que salen pronto de los principales nodos de Italia, Suiza y Alemania, coloreados por retraso")
        m.putIfAbsent("On time", "Puntual")
        m.putIfAbsent("1–5 min late", "1–5 min de retraso")
        m.putIfAbsent("6–14 min late", "6–14 min de retraso")
        m.putIfAbsent("15+ min late", "15+ min de retraso")
        m.putIfAbsent("Delay n.a.", "Retraso n.d.")
        m.putIfAbsent("Trains shown", "Trenes mostrados")
        m.putIfAbsent("Open train", "Abrir tren")
        m.putIfAbsent("Refresh", "Actualizar")
        m.putIfAbsent("Italy", "Italia")
        m.putIfAbsent("Switzerland", "Suiza")
        m.putIfAbsent("Germany", "Alemania")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous.", "Cada punto es un tren que sale de un nodo en la próxima hora, colocado alrededor del nodo: no es su posición GPS. Es una muestra, no toda la red. Fuentes: ViaggiaTreno, SBB (transport.opendata.ch), Transitous.")
        m.putIfAbsent("App style", "Estilo de la app")
        m.putIfAbsent("Traditional", "Tradicional")
        m.putIfAbsent("Vintage (split-flap board)", "Vintage (panel de paletas)")
        m.putIfAbsent("Refreshing the board…", "Actualizando el panel…")
        m.putIfAbsent("TAP THE TITLE TO CHOOSE", "TOCA EL TÍTULO PARA ELEGIR")
        m.putIfAbsent("NO DATA", "SIN DATOS")
        m.putIfAbsent("Departure board style", "Estilo de los paneles de salidas")
        m.putIfAbsent("Classic", "Clásico")
        m.putIfAbsent("Vintage (split-flap)", "Vintage (de paletas)")
        m.putIfAbsent(". After the timetable change buses may be missing until Trenord publishes the new file.", ". Tras el cambio de horario pueden faltar autobuses hasta que Trenord publique el nuevo archivo.")
        m.putIfAbsent(": Transitous timetables are used for Trenord instead.", ": para Trenord se usan en su lugar los horarios de Transitous.")
        m.putIfAbsent("Sources: official Trenord GTFS timetable from Lombardy Region open data (Transitous as a fallback); Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements.", "Fuentes: horario GTFS oficial de Trenord de los datos abiertos de la Región de Lombardía (Transitous como alternativa); Trenitalia y SBB mediante Transitous (transitous.org); autobuses del panel de ViaggiaTreno (RFI). Cada viaje indica su fuente. Los horarios son programados: ante incidencias sigue los avisos de la estación.")
        m.putIfAbsent("The Trenord replacement-bus timetable is valid until", "El horario de los autobuses sustitutivos de Trenord vale hasta el")
        m.putIfAbsent("The Trenord timetable file (Lombardy Region) expired on", "El archivo de horarios de Trenord (Región de Lombardía) caducó el")
        m.putIfAbsent("Lombardy Region open data · official Trenord timetable (GTFS)", "Datos abiertos de la Región de Lombardía · horario oficial de Trenord (GTFS)")
        m.putIfAbsent("Which time is most punctual", "¿Qué horario es más puntual?")
        m.putIfAbsent("on time", "puntual")
        m.putIfAbsent("Each option counts as its least punctual train. Statistics of the latest month, not a forecast: strikes and works can change everything.", "Cada opción cuenta con su tren menos puntual. Estadísticas del último mes, no una previsión: huelgas y obras pueden cambiarlo todo.")
        m.putIfAbsent("Text copied", "Texto copiado")
        m.putIfAbsent("Copy the request text", "Copiar el texto de la solicitud")
        m.putIfAbsent("Most delayed trains right now", "Trenes con más retraso ahora")
        m.putIfAbsent("No significant delays at the main hubs, or the service is not responding.", "Sin retrasos relevantes en los principales nodos, o el servicio no responde.")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Source: ViaggiaTreno.", "Muestra de los tableros de los principales nodos (próximas horas): no es la lista de toda la red. Fuente: ViaggiaTreno.")
        m.putIfAbsent("Dual numbering", "Doble numeración")
        m.putIfAbsent("This service changes number when it passes from one network to another (RFI, FerrovieNord, SBB).", "Este servicio cambia de número al pasar de una red a otra (RFI, FerrovieNord, SBB).")
        m.putIfAbsent("From the official Trenord timetables in force: the numbers can change with every timetable change.", "De los horarios oficiales de Trenord en vigor: los números pueden cambiar con cada cambio de horario.")
        m.putIfAbsent("After", "Después de")
        m.putIfAbsent("the train becomes", "el tren pasa a ser")
        m.putIfAbsent("Reported by ViaggiaTreno.", "Indicado por ViaggiaTreno.")
        m.putIfAbsent("Strike tomorrow", "Huelga mañana")
        m.putIfAbsent("Line", "Línea")
        m.putIfAbsent("Line page", "Página de la línea")
        m.putIfAbsent("Tap for the official line page: stops, timetables and notices.", "Toca para ver la página oficial de la línea: paradas, horarios y avisos.")
        m.putIfAbsent("Lines through this station", "Líneas que pasan por aquí")
        m.putIfAbsent("From the departures of the next few hours. Frecce, Intercity and Trenitalia regional trains have no line in the official timetables.", "Según las salidas de las próximas horas. Los Frecce, Intercity y regionales de Trenitalia no tienen línea en los horarios oficiales.")
        m.putIfAbsent("Official website", "Sitio oficial")
        m["Automatic (mobile network)"] = "Automático (red móvil)"
        m.putIfAbsent("Germany", "Alemania")
        m.putIfAbsent("Italy", "Italia")
        m["Country for emergencies and defibrillators"] = "País para emergencias y desfibriladores"
        m["Expected occupancy in DB Navigator"] = "Ocupación prevista en DB Navigator"
        m["Expected occupancy on sbb.ch"] = "Ocupación prevista en sbb.ch"
        m["SBB assistance for people with disabilities (Contact Center Handicap)"] = "Asistencia SBB para personas con discapacidad (Contact Center Handicap)"
        m["No official data: DB publishes expected occupancy only in DB Navigator and on bahn.de. This is an estimate by time of day."] = "Sin dato oficial: DB publica la ocupación prevista solo en DB Navigator y en bahn.de. Aquí hay una estimación por franja horaria."
        m["German companies do not publish per-train services (wheelchair spaces, bikes) in open data: you can find them in DB Navigator or on bahn.de. "] = "Las empresas alemanas no publican en datos abiertos los servicios de cada tren (plazas para silla de ruedas, bicis): los encuentras en DB Navigator o en bahn.de. "
        m.putIfAbsent("Switzerland", "Suiza")
        m["The Rega (air rescue) app sends your location to the operations centre. Ambulance: 144."] = "La app de Rega (rescate aéreo) envía tu ubicación a la central. Ambulancia: 144."
        m["The official emergency app of the German federal states: reach 112 and 110 also in writing, with your location."] = "La app de emergencia oficial de los estados alemanes: contacta con el 112 y el 110 también por escrito, con tu ubicación."
        m.putIfAbsent("Train cancelled", "Tren cancelado")
        m.putIfAbsent("Train heavily delayed", "Tren con mucho retraso")
        m.putIfAbsent("No connection", "Sin conexión")
        m.putIfAbsent("Last reading: %d min ago", "Última lectura: hace %d min")
        m.putIfAbsent("It updates as soon as the network is back.", "Se actualiza en cuanto vuelva la red.")
    }

    private fun p14(m: HashMap<String, String>) {
        m.putIfAbsent("No connection. Check your Wi-Fi or mobile data.", "Sin conexión. Revisa el Wi-Fi o los datos móviles.")
        m.putIfAbsent("The service is not responding. Try again shortly.", "El servicio no responde. Inténtalo de nuevo en un momento.")
        m.putIfAbsent("Too many requests. Wait a minute and try again.", "Demasiadas solicitudes. Espera un minuto e inténtalo de nuevo.")
        m.putIfAbsent("Not found: the service does not have this data.", "No encontrado: el servicio no tiene este dato.")
        m.putIfAbsent("The service has a problem. Try again later.", "El servicio tiene un problema. Inténtalo más tarde.")
        m.putIfAbsent("Something went wrong. Try again.", "Algo no ha funcionado. Inténtalo de nuevo.")
        m.putIfAbsent("You are offline. Showing the latest available data.", "Estás sin conexión. Se muestran los últimos datos disponibles.")
        m.putIfAbsent("The service is not responding: some data is %d min old.", "El servicio no responde: algunos datos son de hace %d min.")
        m.putIfAbsent("With the app's latest network errors (service addresses only, no personal data).", "Con los últimos errores de red de la app (solo direcciones de los servicios, ningún dato personal).")
        m.putIfAbsent("Try changing the time or the station.", "Prueba a cambiar la hora o la estación.")
        m.putIfAbsent("Looking for alternatives…", "Buscando alternativas…")
        m.putIfAbsent("Advanced", "Avanzadas")
        m.putIfAbsent("Just the essentials: timetable search, strikes and your shortcuts.", "Solo lo esencial: buscar horarios, huelgas y tus accesos rápidos.")
        m.putIfAbsent("Also: passengers, train type, prices, My trips, offline timetables, lines and fares.", "Además: pasajeros, tipo de tren, precios, Mis viajes, horarios sin conexión, líneas y tarifas.")
        m.putIfAbsent("All features: also maps, other countries, emergency, assistant and style tiles.", "Todas las funciones: también mapas, extranjero, emergencia, asistente y recuadros del estilo.")
        m.putIfAbsent("Show all features", "Mostrar todas las funciones")
        m.putIfAbsent("Accessible", "Accesible")
        m.putIfAbsent("Accessible stations", "Accesibles")
        m.putIfAbsent("Other services", "Otros servicios")
        m.putIfAbsent("Open the notice document (PDF)", "Abrir el documento del aviso (PDF)")
        m.putIfAbsent("Open the station page", "Abrir la página de la estación")
        m.putIfAbsent("Trenord notice", "Aviso Trenord")
        m.putIfAbsent("Bars and restaurants", "Bares y restaurantes")
        m.putIfAbsent("Bike sharing", "Bicicletas compartidas")
        m.putIfAbsent("Get directions", "Cómo llegar")
        m.putIfAbsent("Car sharing", "Coche compartido")
        m.putIfAbsent("With ticket office", "Con taquilla")
        m.putIfAbsent("With ticket machines", "Con máquinas expendedoras")
        m.putIfAbsent("From the Trenord website. Tap a station for its address and other services.", "Del sitio de Trenord. Toca una estación para ver la dirección y otros servicios.")
        m.putIfAbsent("Defibrillator", "Desfibrilador")
        m.putIfAbsent("Left luggage", "Consigna de equipaje")
        m.putIfAbsent("Machines", "Máquinas")
        m.putIfAbsent("Ticket machines", "Máquinas expendedoras")
        m.putIfAbsent("Newsstand", "Quiosco")
        m.putIfAbsent("Address", "Dirección")
        m.putIfAbsent("Reading the station page from the Trenord website…", "Leyendo la página de la estación en el sitio de Trenord…")
        m.putIfAbsent("Show all", "Mostrar todas")
        m.putIfAbsent("No services listed", "Sin servicios indicados")
        m.putIfAbsent("No stations with these services.", "Ninguna estación con estos servicios.")
        m.putIfAbsent("Parking", "Aparcamiento")
        m.putIfAbsent("Car park", "Aparcamiento de coches")
        m.putIfAbsent("Bike parking", "Aparcamiento de bicicletas")
        m.putIfAbsent("Waiting room", "Sala de espera")
        m.putIfAbsent("Escalators", "Escaleras mecánicas")
        m.putIfAbsent("Station page not available right now.", "Página de la estación no disponible ahora.")
        m.putIfAbsent("Accessibility services", "Servicios de accesibilidad")
        m.putIfAbsent("Stations on the line", "Estaciones de la línea")
        m.putIfAbsent("Wi-Fi", "Wi-Fi")
        m.putIfAbsent("TILO trains that left in the last 3 hours, in both directions, from the Swiss timetable: it counts delays over 15 minutes, not cancelled trains. For cancellations see the SBB notices below.", "Trenes TILO salidos en las últimas 3 horas, en ambos sentidos, según el horario suizo: cuenta los retrasos de más de 15 minutos, no los trenes cancelados. Para las cancelaciones mira los avisos SBB de abajo.")
        m.putIfAbsent("SBB notices on the line", "Avisos SBB en la línea")
        m.putIfAbsent("Checking SBB notices…", "Comprobando los avisos SBB…")
        m.putIfAbsent("No current SBB notices: according to SBB, service is running normally.", "No hay avisos SBB en curso: según SBB, la circulación es regular.")
        m.putIfAbsent("SBB open data (texts in English).", "Datos abiertos SBB (textos en inglés).")
        m.putIfAbsent("SBB service status", "Estado del servicio SBB")
        m.putIfAbsent("Delete this trip?", "¿Eliminar este viaje?")
        m.putIfAbsent("Across all trips on the chosen route", "En todos los viajes del trayecto elegido")
        m.putIfAbsent("Morning (5–10)", "Mañana (5–10)")
        m.putIfAbsent("Daytime (10–16)", "Día (10–16)")
        m.putIfAbsent("Evening (16–21)", "Tarde (16–21)")
        m.putIfAbsent("Night (21–5)", "Noche (21–5)")
        m.putIfAbsent("When your trains are most late", "A qué hora tus trenes llevan más retraso")
        m.putIfAbsent("Across all trips in the log", "Sobre todos los viajes del diario")
        m.putIfAbsent("{0} trips · average delay {1} min · {2} with 15 min or more", "{0} viajes · retraso medio {1} min · {2} con 15 min o más")
        m.putIfAbsent("most delays", "más retraso")
        m.putIfAbsent("today", "hoy")
        m.putIfAbsent("yesterday", "ayer")
        m.putIfAbsent("Last few days (worst moment)", "Últimos días (peor momento)")
        m.putIfAbsent("All routes", "Todos los trayectos")
        m.putIfAbsent("Compensation claim", "Solicitud de indemnización")
        m.putIfAbsent("Not today", "Hoy no avisar")
        m.putIfAbsent("Year", "Año")
        m.putIfAbsent("Arrival delay, day by day", "Retraso a la llegada, día a día")
        m.putIfAbsent("Filled bar: minutes late (top = 60 or more). Empty bar: train cancelled.", "Barra llena: minutos de retraso (arriba = 60 o más). Barra vacía: tren suprimido.")
        m.putIfAbsent("Days with trips: {0}. No delays. Cancelled: {1}.", "Días con viajes: {0}. Sin retrasos. Suprimidos: {1}.")
        m.putIfAbsent("Days with trips: {0}. Highest delay: {1} minutes on day {2}. Cancelled: {3}.", "Días con viajes: {0}. Mayor retraso: {1} minutos el día {2}. Suprimidos: {3}.")
        m.putIfAbsent("{0} minutes late", "{0} minutos de retraso")
        m.putIfAbsent("Date", "Fecha")
        m.putIfAbsent("Scheduled arrival", "Llegada prevista")
        m.putIfAbsent("Delay (min)", "Retraso (min)")
        m.putIfAbsent("Yes", "Sí")
        m.putIfAbsent("Delays this month", "Retrasos del mes")
        m.putIfAbsent("Search the guide", "Buscar en la guía")
        m.putIfAbsent("No topic found", "No se encontró ningún tema")
        m.putIfAbsent("Tap to open «My trips» and share the month.", "Toca para abrir «Mis viajes» y compartir el mes.")
        m.putIfAbsent("added by hand", "añadido a mano")
        m.putIfAbsent("Add a trip", "Añadir un viaje")
        m.putIfAbsent("Train (e.g. R 2727)", "Tren (p. ej. R 2727)")
        m.putIfAbsent("Date (dd/mm/yyyy)", "Fecha (dd/mm/aaaa)")
        m.putIfAbsent("Scheduled arrival (hh:mm)", "Llegada prevista (hh:mm)")
        m.putIfAbsent("Minutes late on arrival", "Minutos de retraso a la llegada")
        m.putIfAbsent("Write the train with its number, for example R 2727.", "Escribe el tren con su número, por ejemplo R 2727.")
        m.putIfAbsent("Write the departure and arrival stations.", "Escribe la estación de salida y la de llegada.")
        m.putIfAbsent("Check date and time: for example 09/11/2026 and 08:15.", "Revisa fecha y hora: por ejemplo 09/11/2026 y 08:15.")
        m.putIfAbsent("The trip cannot be in the future.", "El viaje no puede estar en el futuro.")
        m.putIfAbsent("The delay must be from 0 to 999 minutes.", "El retraso va de 0 a 999 minutos.")
        m.putIfAbsent("Low disruption", "Incidencia baja")
        m.putIfAbsent("Moderate disruption", "Incidencia media")
        m.putIfAbsent("High disruption", "Incidencia alta")
        m.putIfAbsent("1 strike hidden by the filter", "1 huelga oculta por el filtro")
        m.putIfAbsent("{0} strikes hidden by the filter", "{0} huelgas ocultas por el filtro")
        m.putIfAbsent("1 notice hidden by the filter", "1 aviso oculto por el filtro")
        m.putIfAbsent("{0} notices hidden by the filter", "{0} avisos ocultos por el filtro")
        m.putIfAbsent("Share the month", "Compartir el mes")
        m.putIfAbsent("Times recorded by the Binario app: they do not replace the operator's official certificates.", "Horarios registrados por la app Binario: no sustituyen los certificados oficiales de la empresa.")
        m.putIfAbsent("{0}: scheduled {1}, actual {2}", "{0}: programado {1}, real {2}")
        m.putIfAbsent("{0}: scheduled {1}, expected {2}", "{0}: programado {1}, previsto {2}")
        m.putIfAbsent("{0}: scheduled {1}", "{0}: programado {1}")
        m.putIfAbsent("How to read the times", "Cómo leer los horarios")
        m.putIfAbsent("Actual time: the train passed on time", "Horario real: el tren pasó puntual")
        m.putIfAbsent("Actual time: the train passed late", "Horario real: el tren pasó con retraso")
        m.putIfAbsent("Expected time: scheduled plus the current delay reported by the operator", "Horario previsto: el programado más el retraso actual comunicado por la empresa")
        m.putIfAbsent("When data comes from several operators, the source is shown under the stop name (e.g. Trenord, SBB).", "Cuando los datos vienen de varias empresas, la fuente aparece bajo el nombre de la parada (p. ej. Trenord, SBB).")
        m.putIfAbsent("Disruption on the line (last 3 hours)", "Incidencias en la línea (últimas 3 horas)")
        m.putIfAbsent("Checking the trains of the last few hours…", "Compruebo los trenes de las últimas horas…")
        m.putIfAbsent("No trains departed in the last 3 hours.", "Ningún tren ha salido en las últimas 3 horas.")
        m.putIfAbsent("{0} critical trains out of {1}", "{0} trenes críticos de {1}")
        m.putIfAbsent("Short-run", "Limitados")
        m.putIfAbsent("Over 15 min", "Más de 15 min")
        m.putIfAbsent("Trains that departed in the last 3 hours, in both directions. Critical: cancelled, short-run or more than 15 minutes late.", "Trenes que salieron en las últimas 3 horas, en ambos sentidos. Crítico: suprimido, limitado o con más de 15 minutos de retraso.")
        m.putIfAbsent("My trips", "Mis viajes")
        m.putIfAbsent("Trains followed to arrival, delays this month", "Trenes seguidos hasta la llegada, retrasos del mes")
        m.putIfAbsent("Previous month", "Mes anterior")
        m.putIfAbsent("Next month", "Mes siguiente")
        m.putIfAbsent("No trips yet", "Aún no hay viajes")
        m.putIfAbsent("When you follow a train (the «Follow» button on the train page) until it arrives, the trip appears here with its delay. It stays on this phone only.", "Cuando sigues un tren (botón «Seguir» en la ficha del tren) hasta la llegada, el viaje aparece aquí con su retraso. Se queda solo en este teléfono.")
        m.putIfAbsent("No trips this month.", "No hay viajes este mes.")
        m.putIfAbsent("The trip log stays on this phone only.", "El diario se queda solo en este teléfono.")
        m.putIfAbsent("Clear the trip log", "Borrar el diario")
        m.putIfAbsent("Delete all saved trips?", "¿Borrar todos los viajes guardados?")
        m.putIfAbsent("Trips", "Viajes")
        m.putIfAbsent("Delay of 15 min or more", "Retraso de 15 min o más")
        m.putIfAbsent("Delay of 60 min or more", "Retraso de 60 min o más")
        m.putIfAbsent("Total minutes of delay", "Minutos de retraso en total")
        m.putIfAbsent("With a delay of 60 minutes or more you can claim compensation.", "Con 60 minutos o más de retraso puedes pedir una indemnización.")
        m.putIfAbsent("If you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation.", "Si tienes un abono, los retrasos cuentan para el bono mensual (Trenord) o la indemnización.")
    }
}
