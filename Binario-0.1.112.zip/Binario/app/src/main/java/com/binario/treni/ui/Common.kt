package com.binario.treni.ui

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.lifecycle.compose.currentStateAsState
import kotlinx.coroutines.flow.first

import com.binario.treni.data.tx
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.binario.treni.data.Api
import com.binario.treni.data.Station
import com.binario.treni.data.messageOrUtente
import com.binario.treni.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Colore principale: verde, oppure blu / verde acqua in modalità daltonici (si aggiorna subito in tutta l'app). */
private val vintageOn: Boolean get() = com.binario.treni.data.AppStyle.vintage && !com.binario.treni.data.ColorBlind.on
private val styleSpec: com.binario.treni.data.StyleSpec? get() = com.binario.treni.data.AppStyle.spec
val Green: Color get() = styleSpec?.primary ?: if (vintageOn) Color(0xFF9A7420) else Color(com.binario.treni.data.ColorBlind.brand)
val GreenDark: Color get() = styleSpec?.primary ?: if (vintageOn) Color(0xFF6F5316) else Color(com.binario.treni.data.ColorBlind.brandDark)
/** Colore del testo e delle icone sopra [Green]: nero sul giallo dell'alto contrasto, bianco altrove. */
val OnGreen: Color get() = styleSpec?.onPrimary ?: Color.White
val GreenField: Color get() = styleSpec?.field ?: if (vintageOn) Color(0xFFB48A2C) else Color(com.binario.treni.data.ColorBlind.brandField)
/** Rosso ritardo (arancio in modalità daltonici). */
/** Ambra del tabellone vintage; con i colori per daltonici diventa l'azzurro (o verde acqua) sicuro. */
val vintageAmber: Color get() = if (com.binario.treni.data.ColorBlind.on) Color(com.binario.treni.data.ColorBlind.brandOnDark) else Color(0xFFF5C84C)
val LateRed: Color get() = Color(com.binario.treni.data.ColorBlind.late)
/** Verde "in orario" (blu in modalità daltonici). */
val OnTime: Color get() = Color(com.binario.treni.data.ColorBlind.ok)
val EarlyBlue = Color(0xFF1976D2)
val PassedBlue = Color(0xFF1E88E5)
val Muted = Color(0xFF8A8A8A)

/** Angoli dei riquadri: 3 dp nello stile tradizionale, quelli dello stile scelto negli altri. */
@Composable
fun cardShape(): androidx.compose.ui.graphics.Shape =
    com.binario.treni.data.AppStyle.spec?.let { RoundedCornerShape((it.radius * 3 / 4).dp) } ?: RoundedCornerShape(3.dp)

@Composable
fun BinarioTheme(theme: String = "system", content: @Composable () -> Unit) {
    val vintage = com.binario.treni.data.AppStyle.vintage
    val sp = com.binario.treni.data.AppStyle.spec
    val dark = if (vintage) true else if (sp != null) sp.dark else when (theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val scheme = if (sp != null) {
        val base = if (sp.dark) darkColorScheme() else lightColorScheme()
        base.copy(
            primary = sp.primary, onPrimary = sp.onPrimary, secondary = sp.primary, onSecondary = sp.onPrimary,
            background = sp.background, onBackground = sp.onSurface, surface = sp.surface, onSurface = sp.onSurface,
            surfaceVariant = sp.surfaceVariant, onSurfaceVariant = sp.muted, outline = sp.muted,
        )
    } else if (vintage) darkColorScheme(
        primary = vintageAmber, onPrimary = Color.Black, secondary = vintageAmber, onSecondary = Color.Black,
        background = Color(0xFF0B0B0C), onBackground = Color(0xFFF2EFE6), surface = Color(0xFF18181A), onSurface = Color(0xFFF2EFE6),
        surfaceVariant = Color(0xFF242427), onSurfaceVariant = Color(0xFFD8D2C0), outline = Color(0xFF6F6A5C),
    ) else if (dark) darkColorScheme(
        primary = Color(com.binario.treni.data.ColorBlind.brandOnDark), onPrimary = Color.Black, secondary = Color(com.binario.treni.data.ColorBlind.brandOnDark),
        background = Color(0xFF121212), surface = Color(0xFF1F1F1F), surfaceVariant = Color(0xFF2A2A2A),
    ) else lightColorScheme(
        primary = Green, onPrimary = Color.White, secondary = Green, onSecondary = Color.White,
        background = Color(0xFFEDEDED), surface = Color.White, surfaceVariant = Color(0xFFF4F4F4),
    )
    val shapes = if (sp != null) androidx.compose.material3.Shapes(
        extraSmall = RoundedCornerShape((sp.radius / 4).dp), small = RoundedCornerShape((sp.radius / 2).dp),
        medium = RoundedCornerShape(sp.radius.dp), large = RoundedCornerShape((sp.radius + 4).dp), extraLarge = RoundedCornerShape((sp.radius + 12).dp),
    ) else androidx.compose.material3.MaterialTheme.shapes
    val d = androidx.compose.ui.platform.LocalDensity.current
    val scaled = androidx.compose.ui.unit.Density(d.density, d.fontScale * com.binario.treni.data.TextScale.value)
    androidx.compose.runtime.CompositionLocalProvider(androidx.compose.ui.platform.LocalDensity provides scaled) {
        MaterialTheme(colorScheme = scheme, shapes = shapes, typography = if (vintage) monoTypography() else androidx.compose.material3.Typography(), content = content)
    }
}

/** Tipografia a spaziatura fissa per lo stile vintage. */
private fun monoTypography(): androidx.compose.material3.Typography {
    val b = androidx.compose.material3.Typography()
    val f = androidx.compose.ui.text.font.FontFamily.Monospace
    return b.copy(
        displayLarge = b.displayLarge.copy(fontFamily = f), displayMedium = b.displayMedium.copy(fontFamily = f), displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f), headlineMedium = b.headlineMedium.copy(fontFamily = f), headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f), titleMedium = b.titleMedium.copy(fontFamily = f), titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f), bodyMedium = b.bodyMedium.copy(fontFamily = f), bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f), labelMedium = b.labelMedium.copy(fontFamily = f), labelSmall = b.labelSmall.copy(fontFamily = f),
    )
}

/** Barra superiore verde comune a tutte le schermate. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GreenTopBar(title: String, onBack: (() -> Unit)? = null, onMenu: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    val barSpec = styleSpec
    TopAppBar(
        title = {
            val big = com.binario.treni.data.TextScale.big
            // Testo ingrandito: titolo su due righe, un po' più piccolo, per non tagliare le parole
            if (com.binario.treni.data.AppStyle.vintage) Text(title.uppercase(), maxLines = if (big) 2 else 1, overflow = TextOverflow.Ellipsis, fontSize = if (big) 14.sp else 18.sp, lineHeight = if (big) 16.sp else androidx.compose.ui.unit.TextUnit.Unspecified, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            else Text(title, maxLines = if (big) 2 else 1, overflow = TextOverflow.Ellipsis, fontSize = if (big) 16.sp else 20.sp, lineHeight = if (big) 18.sp else androidx.compose.ui.unit.TextUnit.Unspecified)
        },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tx("Indietro")) }
            else if (onMenu != null) IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, tx("Menu")) }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = barSpec?.topBar ?: if (com.binario.treni.data.AppStyle.vintage) Color(0xFF141416) else Green,
            titleContentColor = barSpec?.onTopBar ?: if (com.binario.treni.data.AppStyle.vintage) vintageAmber else Color.White,
            navigationIconContentColor = barSpec?.onTopBar ?: if (com.binario.treni.data.AppStyle.vintage) vintageAmber else Color.White,
            actionIconContentColor = barSpec?.onTopBar ?: if (com.binario.treni.data.AppStyle.vintage) vintageAmber else Color.White,
        ),
    )
}

/** Voce del menu ⋮ della barra in alto. */
data class BarAction(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String, val onClick: () -> Unit)

/**
 * Menu ⋮ della barra verde: le azioni meno usate vanno qui, con icona e nome, così le icone non si sovrappongono
 * e il titolo resta leggibile anche sui telefoni stretti.
 */
@Composable
fun BarOverflow(items: List<BarAction>) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }) { Icon(Icons.Filled.MoreVert, tx("Altre azioni")) }
        DropdownMenu(open, { open = false }) {
            items.forEach { a ->
                DropdownMenuItem(
                    text = { Text(a.label) },
                    leadingIcon = { Icon(a.icon, null, tint = Green) },
                    onClick = { open = false; a.onClick() },
                )
            }
        }
    }
}

/** Scheda bianca con leggera ombra, come nelle schermate di riferimento. */
@Composable
fun WhiteCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val m = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
    if (onClick != null) {
        Card(
            onClick = onClick, modifier = m, shape = cardShape(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp), content = content,
        )
    } else {
        Card(
            modifier = m, shape = cardShape(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp), content = content,
        )
    }
}

@Composable
fun SectionHeader(text: String) {
    Text(
        text, style = MaterialTheme.typography.bodyMedium, color = Muted,
        modifier = Modifier.padding(start = 18.dp, top = 16.dp, bottom = 6.dp),
    )
}

/** Titolo verde di una sezione dentro una scheda (stile impostazioni). */
@Composable
fun CardTitle(text: String) {
    Text(text, color = Green, fontSize = 22.sp, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 10.dp))
    HorizontalDivider(color = Color(0x14000000))
}

fun categoryColor(cat: String): Color {
    val c = cat.uppercase()
    return when {
        c.startsWith("FR") || c.startsWith("FA") || c.contains("FRECCIAROSSA") || c.contains("FRECCIARGENTO") ||
            c.startsWith("ITA") || c.contains("ITALO") -> Color(0xFFC62828)
        c.startsWith("FB") || c.contains("FRECCIABIANCA") -> Color(0xFF1565C0)
        c.startsWith("IC") || c.startsWith("EC") || c.startsWith("EN") || c.contains("THELLO") -> Color(0xFF2E7D32)
        else -> Color(0xFF37474F)
    }
}

/**
 * "Trenord REG 2159", "Trenitalia FR 9627": impresa che effettua il servizio in grigio, categoria e numero colorati.
 * [operator] arriva da ViaggiaTreno quando c'è; altrimenti viene ricavata dal nome del treno.
 */
@Composable
fun TrainTitle(category: String, number: String, size: Int = 18, operator: String? = null, originId: String? = null, onClick: (() -> Unit)? = null) {
    val op = operator?.takeIf { it.isNotBlank() } ?: com.binario.treni.data.Operators.fromText(category, number)
    val num = com.binario.treni.data.Operators.cleanNumber(number).let { n -> if (op.isNotBlank() && n.startsWith("$op ")) n.removePrefix("$op ").trim() else n }
    // Doppia numerazione (RFI / FerrovieNord / FFS): «24114/11813»
    // Il numero da solo non basta (20309 è anche un regionale Trenitalia nel Lazio): serve l'impresa o la zona della corsa.
    val alias = (if (originId != null) com.binario.treni.data.TrainAliases.othersFor(num, originId)
        else if (Regex("trenord|tilo|sbb|ffs|ferrovienord|trenitalia tilo", RegexOption.IGNORE_CASE).containsMatchIn(op)) com.binario.treni.data.TrainAliases.others(num)
        else emptyList()).firstOrNull()?.other
    val shownNum = if (alias != null) "$num/$alias" else num
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = if (onClick != null) Modifier.clip(RoundedCornerShape(4.dp)).clickable(onClick = onClick).padding(vertical = 2.dp) else Modifier,
    ) {
        // Impresa in grassetto con il colore del testo (ben leggibile sia nel tema chiaro sia in quello scuro)
        if (op.isNotBlank()) {
            Text(op, color = MaterialTheme.colorScheme.onSurface, fontSize = size.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(8.dp))
        }
        // Categoria e numero in un'etichetta piena: testo bianco su colore della categoria (alto contrasto)
        Text(
            "$category $shownNum".trim(), color = Color.White, fontSize = (size - 1).sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(categoryColor(category)).padding(horizontal = 6.dp, vertical = 1.dp),
        )
    }
}

/** Riquadro del binario: azzurro se confermato/reale, grigio se programmato. */
@Composable
fun PlatformBox(platform: String, confirmed: Boolean, changed: Boolean = false) {
    if (platform.isBlank()) return
    Box(
        Modifier.clip(RoundedCornerShape(3.dp))
            .background(if (confirmed) Color(0xFFDCEBFB) else Color(0xFFEEEEEE))
            .padding(horizontal = 7.dp, vertical = 2.dp),
    ) {
        Text(platform, color = if (confirmed || changed) EarlyBlue else Color(0xFF555555), fontSize = 15.sp)
    }
}

/**
 * Binario previsto e binario reale affiancati.
 * Grigio = previsto (programmato); azzurro = reale confermato; rosso = binario cambiato rispetto al previsto.
 */
@Composable
fun PlatformPair(sched: String, real: String, compact: Boolean = false) {
    if (sched.isBlank() && real.isBlank()) return
    val changed = real.isNotBlank() && sched.isNotBlank() && real != sched
    if (compact) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            when {
                changed -> {
                    PlatBox(sched, PlatStyle.STRUCK)
                    Text(" → ", color = LateRed, fontSize = 13.sp)
                    PlatBox(real, PlatStyle.CHANGED)
                }
                real.isNotBlank() -> PlatBox(real, PlatStyle.REAL)
                else -> PlatBox(sched, PlatStyle.SCHED)
            }
        }
        return
    }
    Column(horizontalAlignment = Alignment.End) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tx("Previsto") + " ", color = Muted, fontSize = 10.sp)
            PlatBox(sched.ifBlank { "–" }, if (changed) PlatStyle.STRUCK else PlatStyle.SCHED)
        }
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tx("Reale") + " ", color = Muted, fontSize = 10.sp)
            PlatBox(real.ifBlank { "–" }, when {
                real.isBlank() -> PlatStyle.EMPTY
                changed -> PlatStyle.CHANGED
                else -> PlatStyle.REAL
            })
        }
    }
}

private enum class PlatStyle { SCHED, REAL, CHANGED, STRUCK, EMPTY }

@Composable
private fun PlatBox(text: String, style: PlatStyle) {
    val (bg, fg) = when (style) {
        PlatStyle.SCHED -> Color(0xFFEEEEEE) to Color(0xFF555555)
        PlatStyle.REAL -> Color(0xFFDCEBFB) to EarlyBlue
        PlatStyle.CHANGED -> Color(0xFFFDE0E0) to LateRed
        PlatStyle.STRUCK -> Color(0xFFF5F5F5) to Color(0xFF9E9E9E)
        PlatStyle.EMPTY -> Color(0xFFF5F5F5) to Color(0xFFBDBDBD)
    }
    Box(Modifier.clip(RoundedCornerShape(3.dp)).background(bg).padding(horizontal = 7.dp, vertical = 2.dp)) {
        Text(
            text, color = fg, fontSize = 15.sp, fontWeight = if (style == PlatStyle.CHANGED) FontWeight.Bold else FontWeight.Normal,
            textDecoration = if (style == PlatStyle.STRUCK) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
        )
    }
}

/** Icona del treno colorata come nell'app Trenord: verde, giallo, rosso. */
@Composable
fun CrowdBadge(c: com.binario.treni.data.Crowd?, withLabel: Boolean = false) {
    if (c == null) return
    val col = Color(c.level.color)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Train, c.level.label, tint = col, modifier = Modifier.size(18.dp))
        if (com.binario.treni.data.ColorBlind.on) Text(c.level.symbol, color = col, fontSize = 13.sp)
        if (c.source == com.binario.treni.data.Crowd.Source.ESTIMATE) Text("≈", color = col, fontSize = 11.sp)
        if (withLabel) {
            Spacer(Modifier.width(6.dp))
            Text(c.level.label, color = col, fontSize = 13.sp)
        }
    }
}

/** "+13 min" in rosso, "-2 min" in verde. */
@Composable
fun DelayBadge(delay: Int, cancelled: Boolean = false, showZero: Boolean = false) {
    when {
        cancelled -> Text(com.binario.treni.data.ColorBlind.delaySymbol(0, true) + "SOPP.", color = LateRed, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        delay != 0 || showZero -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(com.binario.treni.data.ColorBlind.delaySymbol(delay, false) + (if (delay > 0) "+$delay" else "$delay"), color = if (delay > 0) LateRed else OnTime, fontSize = 20.sp)
            Text("min", color = if (delay > 0) LateRed else OnTime, fontSize = 13.sp)
        }
    }
}

@Composable
fun DelayText(delay: Int, departed: Boolean = true, cancelled: Boolean = false, modifier: Modifier = Modifier) {
    val (txt, col) = when {
        cancelled -> tx("Soppresso") to LateRed
        delay > 0 -> "+$delay'" to LateRed
        delay < 0 -> "$delay'" to OnTime
        departed -> tx("In orario") to OnTime
        else -> "" to Color.Gray
    }
    if (txt.isNotEmpty()) Text(com.binario.treni.data.ColorBlind.delaySymbol(delay, cancelled) + txt, color = col, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = modifier)
}

/** Pallino del tragitto: pieno e blu se già transitato. */
@Composable
fun StopDot(passed: Boolean, size: Int = 14) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .border(2.dp, if (passed) PassedBlue else Color(0xFFBDBDBD), CircleShape)
            .padding(3.dp).clip(CircleShape)
            .background(if (passed) PassedBlue else Color(0xFFBDBDBD)),
    )
}

/** I tre stati di una schermata che non mostra ancora dati. */
enum class ViewState { LOADING, EMPTY, ERROR }

/**
 * Un solo aspetto per «sto caricando», «non c'è niente» ed «errore»: icona, titolo, spiegazione e, se serve, il tasto «Riprova».
 * Il testo segue la dimensione scelta in Accessibilità e va a capo, senza larghezze fisse.
 */
@Composable
fun StateView(state: ViewState, title: String, hint: String? = null, onRetry: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        when (state) {
            ViewState.LOADING -> CircularProgressIndicator(color = Green)
            ViewState.EMPTY -> Icon(Icons.Filled.SearchOff, null, tint = Muted, modifier = Modifier.size(36.dp))
            ViewState.ERROR -> Icon(Icons.Filled.CloudOff, null, tint = LateRed, modifier = Modifier.size(36.dp))
        }
        Text(title, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (!hint.isNullOrBlank()) Text(hint, color = Muted, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (onRetry != null && state != ViewState.LOADING) OutlinedButton(onClick = onRetry) { Text(tx("Riprova"), color = Green) }
    }
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
}

@Composable
fun MessageBox(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Muted, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun ActionChip(icon: ImageVector, label: String, active: Boolean = false, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = if (active) Green else Muted)
        Text(label, fontSize = 11.sp, color = if (active) Green else Muted)
    }
}

/** Riga di menu con icona grigia, come nella scheda "Altro". */
@Composable
fun MenuRow(icon: ImageVector?, title: String, sub: String = "", trailing: @Composable () -> Unit = {}, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color(0xFF757575), modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(26.dp))
        } else Spacer(Modifier.width(36.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 13.sp)
        }
        trailing()
    }
}

@Composable
fun SimpleRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Green)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 13.sp)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = Muted)
        }
    }
    HorizontalDivider(color = Color(0x14000000))
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(6.dp)).border(1.dp, OnGreen, RoundedCornerShape(6.dp)),
    ) {
        options.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).fillMaxHeight().background(if (i == selected) OnGreen else Color.Transparent)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) { Text(s, color = if (i == selected) Green else OnGreen, fontWeight = FontWeight.Medium) }
        }
    }
}

/** Larghezza fissa pensata per il testo normale: cresce con la dimensione del testo (anche quella di sistema), al massimo 1,6 volte. */
@Composable
fun androidx.compose.ui.unit.Dp.fs(): androidx.compose.ui.unit.Dp =
    this * androidx.compose.ui.platform.LocalDensity.current.fontScale.coerceIn(1f, 1.6f)

/**
 * Testo su una riga che si rimpicciolisce finché sta nello spazio: nessuna parola spezzata o tagliata (schede, barra in basso).
 * Con [shared] più testi usano la stessa grandezza: se uno non ci sta si rimpiccioliscono tutti (le schede restano uguali).
 */
@Composable
fun FitText(
    text: String, modifier: Modifier = Modifier, fontSize: androidx.compose.ui.unit.TextUnit,
    color: Color = Color.Unspecified, fontWeight: FontWeight? = null, minSize: androidx.compose.ui.unit.TextUnit = 8.sp,
    shared: MutableState<androidx.compose.ui.unit.TextUnit>? = null,
) {
    var own by remember(text, fontSize) { mutableStateOf(fontSize) }
    val size = shared?.value ?: own
    Text(
        text, modifier, color = color, fontWeight = fontWeight, fontSize = size, maxLines = 1, softWrap = false,
        onTextLayout = { r ->
            if (r.hasVisualOverflow && size.value > minSize.value) {
                if (shared != null) shared.value = size * 0.9f else own = size * 0.9f
            }
        },
    )
}

/** Grandezza comune per il testo di una fila di schede: riparte da [base] se cambiano le schede o la dimensione del testo. */
@Composable
fun rememberSharedTextSize(base: androidx.compose.ui.unit.TextUnit, vararg keys: Any?): MutableState<androidx.compose.ui.unit.TextUnit> {
    val scale = androidx.compose.ui.platform.LocalDensity.current.fontScale
    return remember(base, scale, *keys) { mutableStateOf(base) }
}

/** Da questa grandezza del testo (impostazioni di Android) le file di pulsanti vanno a capo e le schede scorrono. */
const val BIG_TEXT_SCALE = 1.3f

/** Vero con il testo grande o enorme nelle impostazioni del telefono. */
@Composable
fun bigText(): Boolean = androidx.compose.ui.platform.LocalDensity.current.fontScale >= BIG_TEXT_SCALE

/**
 * Fila di pulsanti (chip) con un'etichetta facoltativa («Ordina:», «Mezzi:»). Con il testo normale è una riga che scorre;
 * con il testo grande va a capo e l'etichetta sta sopra: prima i pulsanti venivano schiacciati e il testo andava
 * a capo una lettera per riga («D-u-r-a-t-a»), oppure restavano fuori schermo.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChipRow(modifier: Modifier = Modifier, label: String? = null, content: @Composable () -> Unit) {
    if (bigText()) {
        Column(modifier) {
            if (label != null) Text(label, color = Muted, fontSize = 13.sp)
            FlowRow { content() }
        }
    } else {
        Row(modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            if (label != null) Text(label, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(end = 6.dp))
            content()
        }
    }
}

/**
 * Schede in maiuscolo sotto la barra verde (TRAGITTO / INFO / MAPPA). Con il testo grande le schede scorrono e il nome
 * resta intero e leggibile (prima si rimpiccioliva fino a un limite e poi veniva tagliato: «CIRCOLAZI(»).
 */
@Composable
fun GreenTabs(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    if (bigText()) {
        ScrollableTabRow(
            selectedTabIndex = selected, containerColor = Green, contentColor = OnGreen, edgePadding = 0.dp,
            indicator = { pos ->
                if (selected < pos.size) with(TabRowDefaults) {
                    SecondaryIndicator(Modifier.tabIndicatorOffset(pos[selected]), color = OnGreen)
                }
            },
        ) {
            options.forEachIndexed { i, s ->
                Tab(i == selected, { onSelect(i) }, text = {
                    Text(s.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false,
                        color = if (i == selected) OnGreen else OnGreen.copy(alpha = 0.75f))
                })
            }
        }
        return
    }
    TabRow(
        selectedTabIndex = selected, containerColor = Green, contentColor = OnGreen,
        indicator = { pos ->
            if (selected < pos.size) with(TabRowDefaults) {
                SecondaryIndicator(Modifier.tabIndicatorOffset(pos[selected]), color = OnGreen)
            }
        },
    ) {
        val shared = rememberSharedTextSize(14.sp, options)
        options.forEachIndexed { i, s ->
            Tab(i == selected, { onSelect(i) }, text = {
                FitText(s.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (i == selected) OnGreen else OnGreen.copy(alpha = 0.75f), shared = shared)
            })
        }
    }
}

/** Schede con icona e nome sotto (il nome serve anche a TalkBack). */
@Composable
fun GreenIconTabs(icons: List<Pair<androidx.compose.ui.graphics.vector.ImageVector, String>>, selected: Int, onSelect: (Int) -> Unit) {
    TabRow(
        selectedTabIndex = selected, containerColor = Green, contentColor = OnGreen,
        indicator = { pos ->
            if (selected < pos.size) with(TabRowDefaults) {
                SecondaryIndicator(Modifier.tabIndicatorOffset(pos[selected]), color = OnGreen)
            }
        },
    ) {
        val shared = rememberSharedTextSize(11.sp, icons.map { it.second })
        icons.forEachIndexed { i, (icon, label) ->
            Tab(
                i == selected, { onSelect(i) },
                modifier = Modifier.semantics { contentDescription = label },
                icon = { Icon(icon, null, tint = if (i == selected) OnGreen else OnGreen.copy(alpha = 0.75f), modifier = Modifier.size(22.dp)) },
                // L'icona da sola non basta: sotto c'è sempre il nome della scheda
                text = { FitText(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (i == selected) OnGreen else OnGreen.copy(alpha = 0.75f), shared = shared) },
            )
        }
    }
}

/** Dialog di ricerca stazione con autocompletamento ViaggiaTreno. */
@Composable
fun StationPickerDialog(title: String, onDismiss: () -> Unit, onPick: (Station) -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var q by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Station>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var failure by remember { mutableStateOf<String?>(null) }
    val favs = remember { store.favStations() }
    val recents = remember {
        store.recentRoutes().flatMap { listOf(it.from, it.to) }.distinctBy { it.id }.filter { r -> favs.none { it.id == r.id } }.take(6)
    }
    val focus = remember { FocusRequester() }
    LaunchedEffect(q) {
        if (q.trim().length < 2) {
            results = emptyList(); return@LaunchedEffect
        }
        delay(250)
        loading = true
        failure = null
        results = try {
            withContext(Dispatchers.IO) { Api.searchStations(q) }
        } catch (e: Exception) {
            failure = e.messageOrUtente()
            emptyList()
        }
        loading = false
    }
    LaunchedEffect(Unit) { if (store.openKeyboard) focus.requestFocus() }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true,
                    placeholder = { Text(tx("Nome della stazione")) },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                )
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                LazyColumn {
                    if (q.trim().length < 2) {
                        if (favs.isNotEmpty()) item { SectionHeader(tx("Stazioni preferite")) }
                        keyedItems(favs) { s -> PickRow(s, Icons.Filled.Star) { onPick(s) } }
                        if (recents.isNotEmpty()) item { SectionHeader(tx("Recenti")) }
                        keyedItems(recents) { s -> PickRow(s, Icons.Filled.History) { onPick(s) } }
                    } else {
                        // Subito i preferiti e i recenti che corrispondono, poi i risultati della rete (senza doppioni)
                        val local = (favs + recents).filter { matchesQuery(q, it.name) }
                        keyedItems((local + results).distinctBy { it.id }) { s ->
                            PickRow(s, if (local.any { it.id == s.id }) Icons.Filled.History else Icons.Filled.Place) { onPick(s) }
                        }
                    }
                }
                if (q.trim().length >= 2 && !loading && results.isEmpty() && (favs + recents).none { matchesQuery(q, it.name) }) {
                    // Rete assente o servizio in errore non sono «nessuna stazione»: si dice cosa è successo
                    MessageBox(failure ?: tx("Nessuna stazione trovata"))
                }
            }
        }
    }
}

@Composable
private fun PickRow(s: Station, icon: ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(s.name)
    }
    HorizontalDivider(color = Color(0x14000000))
}

/** Scelta del promemoria: quanti minuti prima, partenza o arrivo. */
@Composable
fun ReminderDialog(onDismiss: () -> Unit, onConfirm: (minutes: Int, arrival: Boolean) -> Unit) {
    var minutes by rememberSaveable { mutableStateOf(15) }
    var arrival by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Notifica programmata")) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(!arrival, { arrival = false }); Text(tx("Prima della partenza"))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(arrival, { arrival = true }); Text(tx("Prima dell'arrivo"))
                }
                Spacer(Modifier.height(8.dp))
                listOf(5, 10, 15, 30, 60).forEach { m ->
                    Row(Modifier.fillMaxWidth().clickable { minutes = m }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(minutes == m, { minutes = m })
                        Text(if (m == 60) tx("1 ora prima") else "$m minuti prima")
                    }
                }
            }
        },
        confirmButton = { TextButton({ onConfirm(minutes, arrival) }) { Text(tx("Imposta"), color = Green) } },
        dismissButton = { TextButton(onDismiss) { Text(tx("Annulla")) } },
    )
}

/** Campo numerico per la ricerca treno. */
@Composable
fun NumberField(value: String, onChange: (String) -> Unit, onSearch: () -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { v -> onChange(v.filter { it.isDigit() }.take(6)) },
        singleLine = true, label = { Text(tx("Numero del treno")) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        trailingIcon = { IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, tx("Cerca")) } },
        modifier = Modifier.fillMaxWidth(),
    )
}

// ---------------- Intent di sistema ----------------

fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(com.binario.treni.data.LinkLoc.url(url))))
    } catch (e: ActivityNotFoundException) {
        toast(ctx, tx("Nessun browser disponibile"))
    }
}

/**
 * Cerca [query] su Google Maps attorno al punto (app Google Maps se installata, altrimenti il browser).
 * Gratuito e senza chiavi: è un semplice collegamento, l'app non riceve dati da Google.
 */
fun googleMaps(ctx: Context, lat: Double, lon: Double, query: String) {
    val url = "https://www.google.com/maps/search/" + Uri.encode(query) + "/@$lat,$lon,16z"
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.apps.maps"))
    } catch (e: Exception) {
        openUrl(ctx, url)
    }
}

/** Riga di pulsanti "Cerca su Google Maps" per una o più ricerche (etichetta → testo da cercare). */
@Composable
fun GoogleMapsButtons(lat: Double, lon: Double, searches: List<Pair<String, String>>) {
    val ctx = LocalContext.current
    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
        searches.forEach { (label, q) ->
            TextButton({ googleMaps(ctx, lat, lon, q) }) {
                Icon(Icons.Filled.Map, null, Modifier.size(18.dp), tint = Green)
                Spacer(Modifier.width(4.dp))
                Text(label, color = Green)
            }
        }
    }
}

/**
 * "Trascina giù per aggiornare": tieni il dito sull'elenco e tiralo verso il basso.
 * Il contenuto deve poter scorrere (LazyColumn o Column con verticalScroll).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PullRefresh(refreshing: Boolean, onRefresh: () -> Unit, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    androidx.compose.material3.pulltorefresh.PullToRefreshBox(
        isRefreshing = refreshing, onRefresh = onRefresh, modifier = modifier.fillMaxSize(), content = content,
    )
}

/** Messaggio in un riquadro che si può tirare giù per aggiornare. */
@Composable
fun PullableMessage(text: String) {
    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState())) { MessageBox(text) }
}

fun shareText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "$text\n\n— via Binario")
    ctx.startActivity(Intent.createChooser(i, tx("Condividi")))
}

fun addToCalendar(ctx: Context, title: String, begin: Long, end: Long, location: String, description: String = "") {
    val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, if (end > begin) end else begin + 3600_000)
        .putExtra(CalendarContract.Events.TITLE, title)
        .putExtra(CalendarContract.Events.EVENT_LOCATION, location)
        .putExtra(CalendarContract.Events.DESCRIPTION, description)
    try {
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        toast(ctx, tx("Nessuna app calendario trovata"))
    }
}

/** Sito di acquisto in base alla categoria del treno. */
fun buyUrl(category: String): String {
    val c = category.uppercase()
    return when {
        c.contains("ITA") || c.contains("NTV") -> "https://www.italotreno.com"
        c.contains("TN") || c.contains("TRENORD") || c.startsWith("MXP") -> "https://www.trenord.it"
        else -> "https://www.lefrecce.it"
    }
}

fun buySource(category: String): String = when (buyUrl(category)) {
    "https://www.italotreno.com" -> "italotreno.it"
    "https://www.trenord.it" -> "trenord.it"
    else -> "trenitalia.com"
}


/**
 * Vero quando l'app è in primo piano. Gli aggiornamenti automatici (tabelloni, treni, notizie) si fermano quando
 * l'app è in background: meno batteria e meno dati, e al ritorno si aggiornano subito.
 */
@Composable
fun rememberForeground(): androidx.compose.runtime.State<Boolean> {
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val state = owner.lifecycle.currentStateAsState()
    return androidx.compose.runtime.remember(state) {
        androidx.compose.runtime.derivedStateOf { state.value.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED) }
    }
}

/** Aspetta che l'app torni in primo piano (subito se lo è già). */
suspend fun waitForeground(fg: androidx.compose.runtime.State<Boolean>) {
    if (fg.value) return
    androidx.compose.runtime.snapshotFlow { fg.value }.first { it }
}
