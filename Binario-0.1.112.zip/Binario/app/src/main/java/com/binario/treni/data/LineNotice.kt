package com.binario.treni.data

/**
 * Ultimo messaggio sulla linea, letto dalla pagina ufficiale Trenord («Stato della linea» e primo «Avviso»).
 * Lavora sul testo visibile della pagina (innerText), quindi non dipende dalla struttura HTML del sito.
 */
object LineNotice {
    data class Message(val title: String, val date: String, val body: String)
    data class Page(val status: Message?, val notice: Message?, val updated: String)

    enum class Level { SEVERE, WARNING, REGULAR, OTHER }

    private val DATE = Regex("""\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}""")
    private val DATE_ONLY = Regex("""^\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}$""")

    /** Una pagina di linea Trenord («…/le-nostre-linee/<direttrice>/?code=R38»): le sole di cui sappiamo leggere il messaggio. */
    fun isTrenordLinePage(url: String) = url.contains("trenord.it/") && url.contains("le-nostre-linee/")

    private fun isHeading(l: String, name: String) = l.trim().trimEnd(':').equals(name, ignoreCase = true)
    private fun isMore(l: String) = l.trim().startsWith("Vedi ", ignoreCase = true) && l.contains("precedent", ignoreCase = true)

    /** Testo della pagina → ultimo messaggio di stato e ultimo avviso. Null se la pagina non ha la sezione «Stato della linea». */
    fun parse(text: String): Page? {
        val lines = text.lines().map { it.trim().replace('\u00A0', ' ') }.filter { it.isNotEmpty() }
        val iStatus = lines.indexOfFirst { isHeading(it, "STATO DELLA LINEA") }
        if (iStatus < 0) return null
        val iNotices = lines.indexOfFirst { isHeading(it, "AVVISI") }.let { i -> if (i > iStatus) i else -1 }
        val statusEnd = if (iNotices > iStatus) iNotices else lines.size
        val statusLines = lines.subList(iStatus + 1, statusEnd)
        val noticeLines = if (iNotices >= 0) lines.subList(iNotices + 1, lines.size) else emptyList()
        val updated = statusLines.firstOrNull { it.startsWith("Ultimo aggiornamento", true) }?.substringAfter(':')?.trim().orEmpty()
        val status = message(statusLines)
        val notice = message(noticeLines)
        if (status == null && notice == null) return null
        return Page(status, notice, updated)
    }

    /** Il primo messaggio di una sezione: titolo (se c'è), data e testo, fino a «Vedi … precedenti». */
    private fun message(section: List<String>): Message? {
        val body = ArrayList<String>()
        for (l in section) {
            if (isMore(l)) break
            if (l.startsWith("Ultimo aggiornamento", true)) continue
            body += l
        }
        if (body.isEmpty()) return null
        var title = ""
        var date = ""
        var rest: List<String> = body
        if (DATE_ONLY.matches(body.first())) {
            date = body.first(); rest = body.drop(1)
        } else if (body.size >= 2 && DATE_ONLY.matches(body[1])) {
            title = body.first(); date = body[1]; rest = body.drop(2)
        } else {
            title = body.first(); rest = body.drop(1)
        }
        if (title.isEmpty() && date.isEmpty() && rest.isEmpty()) return null
        return Message(title, date, rest.joinToString("\n"))
    }

    /** Estratto breve: taglia alla parola intera e aggiunge «…». */
    fun excerpt(body: String, max: Int = 220): String {
        val one = body.replace(Regex("\\s*\n\\s*"), " ").trim()
        if (one.length <= max) return one
        val cut = one.take(max)
        return cut.substring(0, cut.lastIndexOf(' ').takeIf { it > max / 2 } ?: max).trimEnd(',', ';', ':', '.', ' ') + "…"
    }

    fun level(title: String): Level {
        val t = title.lowercase()
        return when {
            "grav" in t || "interrott" in t || "sospes" in t -> Level.SEVERE
            "critic" in t || "rallent" in t || "variaz" in t || "ritard" in t -> Level.WARNING
            "regolar" in t -> Level.REGULAR
            else -> Level.OTHER
        }
    }

    /**
     * L'elenco delle linee dà per ogni voce «Piacenza-Lodi-Milano» e, sotto, lo stato («Circolazione con gravi criticità»).
     * Qui si separano: il nome della linea resta stabile (serve a trovare i capolinea e a ricordare i preferiti), lo stato va a parte.
     */
    fun splitRow(text: String, code: String = ""): Pair<String, String> {
        val parts = text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.equals(code, true) }
        if (parts.isEmpty()) return "" to ""
        fun isStatus(s: String) = Regex("^(circolazione|servizio|traffico)\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)
        val route = parts.firstOrNull { !isStatus(it) } ?: parts.first()
        val status = parts.filter { it != route && isStatus(it) }.joinToString(" ")
        return route to status
    }

    private val cache = Lru<String, Pair<Long, Page>>(60)
    private const val TTL_MS = 10 * 60_000L

    fun cached(url: String, now: Long = System.currentTimeMillis()): Page? = cache[url]?.let { (t, p) -> if (now - t < TTL_MS) p else null }
    fun put(url: String, p: Page, now: Long = System.currentTimeMillis()) { cache[url] = now to p }

    private fun norm(s: String) = s.lowercase().replace(Regex("\\s+"), " ").trim()

    /**
     * Linee seguite il cui stato è cambiato rispetto all'ultima lettura: (chiave, nuovo stato).
     * La prima lettura di una linea non genera avvisi, e uno stato vuoto non è un cambiamento.
     */
    fun changes(old: Map<String, String>, now: Map<String, String>, watched: Set<String>): List<Pair<String, String>> =
        watched.sorted().mapNotNull { k ->
            val n = now[k]?.trim().orEmpty()
            val o = old[k]
            if (n.isEmpty() || o == null || norm(o) == norm(n)) null else k to n
        }

    private const val SEP_FIELD = "\u0001"
    private const val SEP_PART = "\u0002"
    private fun enc(m: Message?): String = if (m == null) "" else listOf(m.title, m.date, m.body).joinToString(SEP_FIELD)
    private fun dec(s: String): Message? {
        if (s.isEmpty()) return null
        val f = s.split(SEP_FIELD)
        return if (f.size == 3) Message(f[0], f[1], f[2]) else null
    }

    /** Testo salvabile sul telefono: l'ultimo messaggio resta leggibile anche senza rete. */
    fun encode(p: Page): String = listOf(p.updated, enc(p.status), enc(p.notice)).joinToString(SEP_PART)

    fun decode(s: String?): Page? {
        if (s.isNullOrEmpty()) return null
        val f = s.split(SEP_PART)
        if (f.size != 3) return null
        val st = dec(f[1]); val no = dec(f[2])
        return if (st == null && no == null) null else Page(st, no, f[0])
    }
}
