package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.TripEntry
import com.binario.treni.data.TripLog
import com.binario.treni.data.TripSummary
import com.binario.treni.data.tx
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * «I miei viaggi»: i treni seguiti fino all'arrivo (o soppressi mentre li seguivi), mese per mese,
 * con il riepilogo dei ritardi che servono per il bonus degli abbonati e per gli indennizzi.
 */
@Composable
fun TripLogScreen(onBack: () -> Unit, onConditions: () -> Unit) {
    val ctx = LocalContext.current
    var all by remember { mutableStateOf(TripLog.all(ctx)) }
    val current = TripLog.monthOf(System.currentTimeMillis())
    var month by rememberSaveable { mutableStateOf(current) }
    var askClear by remember { mutableStateOf(false) }
    // Viaggio da eliminare: si chiede conferma (il tasto è piccolo e vicino al resto della riga)
    var askDelete by remember { mutableStateOf<TripEntry?>(null) }
    var adding by rememberSaveable { mutableStateOf(false) }
    var route by rememberSaveable { mutableStateOf<String?>(null) }
    val routes = TripLog.routeOptions(all)
    // Con una tratta scelta, mese, grafico, anno ed esportazioni mostrano solo quella
    val mine = TripLog.byRoute(all, route)
    val shown = TripLog.inMonth(mine, month)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("I miei viaggi"), onBack)
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ month = TripLog.shift(month, -1) }) {
                Icon(Icons.Filled.ChevronLeft, tx("Mese precedente"), tint = Green)
            }
            Text(monthLabel(month), Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 17.sp, textAlign = TextAlign.Center)
            val canNext = month < current
            IconButton({ if (canNext) month = TripLog.shift(month, 1) }, enabled = canNext) {
                Icon(Icons.Filled.ChevronRight, tx("Mese successivo"), tint = if (canNext) Green else Muted)
            }
        }
        if (routes.size > 1) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
            FilterChip(route == null, { route = null }, label = { Text(tx("Tutte le tratte")) }, modifier = Modifier.padding(end = 6.dp))
            routes.take(6).forEach { o ->
                FilterChip(route == o.key, { route = if (route == o.key) null else o.key }, label = { Text(o.label) }, modifier = Modifier.padding(end = 6.dp))
            }
        }
        if (all.isEmpty()) {
            StateView(
                ViewState.EMPTY, tx("Nessun viaggio ancora"),
                tx("Quando segui un treno (tasto «Segui» nella scheda del treno) fino all'arrivo, il viaggio compare qui con il suo ritardo. Resta solo su questo telefono."),
            )
            OutlinedButton({ adding = true }, Modifier.padding(horizontal = 16.dp)) { Text(tx("Aggiungi un viaggio"), color = Green) }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                item(key = "summary") {
                    SummaryCard(TripLog.summary(shown), onConditions)
                    if (shown.isNotEmpty()) Row(Modifier.padding(horizontal = 12.dp)) {
                        TextButton({ try { shareText(ctx, TripLog.exportText(tx("I miei viaggi") + " · " + monthLabel(month), shown)) } catch (_: Exception) { } }) {
                            Icon(Icons.Filled.Share, null, tint = Green)
                            Text("  " + tx("Condividi il mese"), color = Green)
                        }
                        // Lo stesso mese come file per un foglio di calcolo (Excel, Fogli Google…)
                        TextButton({ shareCsv(ctx, month, shown) }) {
                            Icon(Icons.Filled.TableChart, null, tint = Green)
                            Text("  CSV", color = Green)
                        }
                    }
                }
                if (shown.isNotEmpty()) item(key = "chart") { MonthChart(TripLog.dailyBars(shown, month)) }
                // Totale dell'anno del mese mostrato
                val year = month.take(4)
                val yearTrips = TripLog.inYear(mine, year)
                if (yearTrips.isNotEmpty()) item(key = "year") {
                    SummaryCard(TripLog.summary(yearTrips), onConditions, title = tx("Anno") + " " + year, advice = false)
                }
                // A che ora i treni fanno più ritardo: su tutti i viaggi (della tratta scelta), servono abbastanza dati
                if (mine.count { it.schedArr > 0 } >= 5) item(key = "slots") { SlotsCard(TripLog.bySlot(mine), byRoute = route != null) }
                if (shown.isEmpty()) item(key = "none") { MessageBox(tx("Nessun viaggio in questo mese.")) }
                keyedItems(shown, key = { it.key }) { e ->
                    TripRow(e) { askDelete = e }
                    HorizontalDivider()
                }
                item(key = "clear") {
                    OutlinedButton({ adding = true }, Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp)) { Text(tx("Aggiungi un viaggio"), color = Green) }
                    Text(
                        tx("Il diario resta solo su questo telefono."), color = Muted, fontSize = 12.sp,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp),
                    )
                    OutlinedButton({ askClear = true }, Modifier.padding(16.dp)) { Text(tx("Cancella il diario"), color = Green) }
                }
            }
        }
    }

    if (adding) ManualTripDialog(onDismiss = { adding = false }) { e ->
        TripLog.record(ctx, e)
        all = TripLog.all(ctx)
        month = TripLog.monthOf(e.time)
        adding = false
    }

    askDelete?.let { e ->
        AlertDialog(
            onDismissRequest = { askDelete = null },
            title = { Text(tx("Eliminare questo viaggio?")) },
            text = { Text("${e.train} · ${e.from} → ${e.to} · " + (if (e.time > 0) Fmt.dayTime(e.time) else e.day)) },
            confirmButton = {
                TextButton({
                    TripLog.delete(ctx, e.key)
                    all = TripLog.all(ctx)
                    askDelete = null
                }) { Text(tx("Elimina"), color = LateRed) }
            },
            dismissButton = { TextButton({ askDelete = null }) { Text(tx("Annulla"), color = Green) } },
        )
    }

    if (askClear) AlertDialog(
        onDismissRequest = { askClear = false },
        title = { Text(tx("Cancellare tutti i viaggi salvati?")) },
        confirmButton = {
            TextButton({
                TripLog.clear(ctx)
                all = emptyList()
                askClear = false
            }) { Text(tx("Elimina"), color = LateRed) }
        },
        dismissButton = { TextButton({ askClear = false }) { Text(tx("Annulla"), color = Green) } },
    )
}

@Composable
private fun SummaryCard(s: TripSummary, onConditions: () -> Unit, title: String? = null, advice: Boolean = true) {
    WhiteCard(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            title?.let { Text(it, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Green, modifier = Modifier.padding(bottom = 4.dp)) }
            SummaryLine(tx("Viaggi"), s.trips, bold = true)
            SummaryLine(tx("In orario (fino a 5 min)"), s.onTime)
            s.punctuality?.let { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(tx("Puntualità"), Modifier.weight(1f), fontSize = 14.sp)
                    Text("$p%", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            SummaryLine(tx("Ritardo di 15 min o più"), s.late15)
            SummaryLine(tx("Ritardo di 60 min o più"), s.late60)
            SummaryLine(tx("Soppressi"), s.cancelled)
            SummaryLine(tx("Minuti di ritardo in tutto"), s.delayMinutes)
            if (advice) {
                if (s.late60 > 0) {
                    Text(tx("Con 60 minuti o più di ritardo puoi chiedere l'indennizzo."), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                    TextButton(onConditions) { Text(tx("Diritti e rimborsi"), color = Green) }
                } else if (s.late15 > 0 || s.cancelled > 0) {
                    Text(tx("Se hai un abbonamento, i ritardi contano per il bonus mensile (Trenord) o l'indennizzo."), fontSize = 13.sp, color = Muted,
                        modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: Int, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, Modifier.weight(1f), fontSize = if (bold) 16.sp else 14.sp, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal)
        Text(value.toString(), fontSize = if (bold) 16.sp else 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TripRow(e: TripEntry, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    Surface(color = MaterialTheme.colorScheme.surface) {
        Column {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            val date = if (e.time > 0) Fmt.dayTime(e.time) else e.day
            // TalkBack legge la riga intera (treno, tratta, giorno, ritardo); il riquadro del ritardo non si ripete
            Column(Modifier.weight(1f).padding(vertical = 10.dp).semantics(mergeDescendants = true) { contentDescription = TripLog.spoken(e, date) }) {
                Text(e.train, fontWeight = FontWeight.Medium)
                Text("${e.from} → ${e.to}", fontSize = 14.sp)
                Text(date + if (e.manual) " · " + tx("inserito a mano") else "", color = Muted, fontSize = 13.sp)
            }
            Box(Modifier.clearAndSetSemantics { }) { DelayBadge(e.delay, cancelled = e.cancelled, showZero = true) }
            IconButton(onDelete) { Icon(Icons.Filled.Delete, tx("Elimina"), tint = Muted) }
        }
        // 60 minuti o più, o soppresso: testo della richiesta già pronto, da condividere o copiare nel modulo dell'azienda
        if (TripLog.claimable(e)) TextButton(
            { shareClaim(ctx, TripLog.claimText(e)) },
            Modifier.padding(start = 8.dp),
        ) { Text(tx("Richiesta di indennizzo"), color = Green) }
        }
    }
}

/** «Novembre 2026» nella lingua dell'app. */
private fun monthLabel(month: String): String = try {
    val d = SimpleDateFormat("yyyy-MM", Locale.US).apply { timeZone = TimeZone.getTimeZone("Europe/Rome") }.parse(month)
    SimpleDateFormat(if (I18n.cjk) "yyyy年M月" else "MMMM yyyy", I18n.locale)
        .apply { timeZone = TimeZone.getTimeZone("Europe/Rome") }
        .format(d!!).replaceFirstChar { it.uppercase() }
} catch (_: Exception) {
    month
}

/** Modulo per un viaggio non seguito con «Segui»: treno, tratta, data, ora di arrivo prevista, ritardo o soppressione. */
@Composable
private fun ManualTripDialog(onDismiss: () -> Unit, onSave: (TripEntry) -> Unit) {
    val now = System.currentTimeMillis()
    var train by rememberSaveable { mutableStateOf("") }
    var from by rememberSaveable { mutableStateOf("") }
    var to by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable { mutableStateOf(SimpleDateFormat("dd/MM/yyyy", Locale.ITALY).apply { timeZone = TimeZone.getTimeZone("Europe/Rome") }.format(Date(now))) }
    var time by rememberSaveable { mutableStateOf(SimpleDateFormat("HH:mm", Locale.ITALY).apply { timeZone = TimeZone.getTimeZone("Europe/Rome") }.format(Date(now))) }
    var delay by rememberSaveable { mutableStateOf("") }
    var cancelled by rememberSaveable { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Aggiungi un viaggio")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(train, { train = it }, label = { Text(tx("Treno (es. R 2727)")) }, singleLine = true)
                OutlinedTextField(from, { from = it }, label = { Text(tx("Da")) }, singleLine = true)
                OutlinedTextField(to, { to = it }, label = { Text(tx("A")) }, singleLine = true)
                OutlinedTextField(date, { date = it }, label = { Text(tx("Data (gg/mm/aaaa)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(time, { time = it }, label = { Text(tx("Arrivo previsto (hh:mm)")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (!cancelled) OutlinedTextField(delay, { delay = it.filter { c -> c.isDigit() }.take(3) }, label = { Text(tx("Minuti di ritardo all'arrivo")) },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                    Switch(cancelled, { cancelled = it })
                    Text("  " + tx("Treno soppresso"))
                }
                error?.let { Text(it, color = LateRed, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        },
        confirmButton = {
            TextButton({
                val (e, err) = TripLog.manualEntry(train, from, to, date, time, delay, cancelled)
                if (e != null) onSave(e) else error = when (err) {
                    TripLog.ManualError.TRAIN -> tx("Scrivi il treno con il suo numero, per esempio R 2727.")
                    TripLog.ManualError.PLACES -> tx("Scrivi la stazione di partenza e quella di arrivo.")
                    TripLog.ManualError.DATE -> tx("Controlla data e ora: per esempio 09/11/2026 e 08:15.")
                    TripLog.ManualError.FUTURE -> tx("Il viaggio non può essere nel futuro.")
                    else -> tx("Il ritardo va da 0 a 999 minuti.")
                }
            }) { Text(tx("Salva"), color = Green) }
        },
        dismissButton = { TextButton(onDismiss) { Text(tx("Annulla"), color = Green) } },
    )
}

/** Salva il mese come CSV nella cartella di condivisione dell'app e lo apre nel menu «Condividi». */
private fun shareCsv(ctx: android.content.Context, month: String, list: List<TripEntry>) {
    try {
        val dir = java.io.File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = java.io.File(dir, "binario-viaggi-$month.csv")
        f.writeText(TripLog.toCsv(list), Charsets.UTF_8)
        val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/csv")
            .putExtra(android.content.Intent.EXTRA_STREAM, uri)
            .putExtra(android.content.Intent.EXTRA_SUBJECT, tx("I miei viaggi") + " · " + monthLabel(month))
            .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(android.content.Intent.createChooser(i, tx("Condividi")))
    } catch (e: Exception) {
        com.binario.treni.data.Diag.record("diario-csv", e)
        toast(ctx, tx("Errore nel salvataggio"))
    }
}

/**
 * Ritardo all'arrivo giorno per giorno: barra piena alta quanto il ritardo (in cima = 60 minuti o più), barra vuota con il bordo
 * per un treno soppresso, trattino per i giorni senza viaggi. Si legge anche senza colori; il lettore vocale ne dice il riassunto.
 */
@Composable
private fun MonthChart(bars: List<TripLog.DayBar>) {
    val maxMin = 60f
    WhiteCard(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(tx("Ritardo all'arrivo, giorno per giorno"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Row(
                Modifier.fillMaxWidth().height(72.dp).padding(top = 8.dp)
                    .clearAndSetSemantics { contentDescription = TripLog.chartDescription(bars) },
                verticalAlignment = Alignment.Bottom,
            ) {
                bars.forEach { b ->
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.BottomCenter) {
                        when {
                            b.trips == 0 -> Box(Modifier.fillMaxWidth(0.6f).height(1.dp).background(Muted.copy(alpha = 0.5f)))
                            b.cancelled && b.delay == 0 -> Box(Modifier.fillMaxWidth(0.7f).fillMaxHeight().border(1.dp, LateRed))
                            else -> Box(
                                Modifier.fillMaxWidth(0.7f).fillMaxHeight((b.delay / maxMin).coerceIn(0.06f, 1f)).background(barColor(b.delay)),
                            )
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth()) {
                Text("1", fontSize = 10.sp, color = Muted)
                Spacer(Modifier.weight(1f))
                Text("${(bars.size + 1) / 2}", fontSize = 10.sp, color = Muted)
                Spacer(Modifier.weight(1f))
                Text("${bars.size}", fontSize = 10.sp, color = Muted)
            }
            Text(
                tx("Barra piena: minuti di ritardo (in cima = 60 o più). Barra vuota: treno soppresso."),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

/** Come la scheda del treno: in orario fino a 5 minuti, ambra fino a 14, rosso da 15 (con i colori per daltonici dove servono). */
private fun barColor(delay: Int): androidx.compose.ui.graphics.Color = when {
    delay <= 5 -> OnTime
    delay < 15 -> androidx.compose.ui.graphics.Color(0xFFE08A00)
    else -> LateRed
}

/** Condivide la richiesta di indennizzo così com'è: niente firma «via Binario» in una lettera all'azienda. */
private fun shareClaim(ctx: android.content.Context, text: String) {
    try {
        val i = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain")
            .putExtra(android.content.Intent.EXTRA_TEXT, text)
            .putExtra(android.content.Intent.EXTRA_SUBJECT, text.lineSequence().first().removePrefix("Oggetto: "))
        ctx.startActivity(android.content.Intent.createChooser(i, tx("Richiesta di indennizzo")))
    } catch (e: Exception) {
        com.binario.treni.data.Diag.record("diario-indennizzo", e)
    }
}

/** Ritardo per fascia oraria (su tutti i viaggi del diario, o della tratta scelta); la fascia peggiore è scritta, non solo colorata. */
@Composable
private fun SlotsCard(stats: List<TripLog.SlotStat>, byRoute: Boolean = false) {
    val worst = TripLog.worstSlot(stats)
    val names = listOf(tx("Mattina (5–10)"), tx("Giorno (10–16)"), tx("Sera (16–21)"), tx("Notte (21–5)"))
    WhiteCard(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(tx("A che ora i tuoi treni fanno più ritardo"), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(if (byRoute) tx("Su tutti i viaggi della tratta scelta") else tx("Su tutti i viaggi del diario"), color = Muted, fontSize = 12.sp)
            stats.filter { it.trips > 0 }.forEach { s ->
                val line = tx("{0} viaggi · ritardo medio {1} min · {2} con 15 min o più").replace("{0}", "${s.trips}")
                    .replace("{1}", "${s.avgDelay}").replace("{2}", "${s.late15}") +
                    (if (s.cancelled > 0) " · " + tx("Soppressi") + " ${s.cancelled}" else "")
                Column(Modifier.padding(top = 8.dp)) {
                    Text(names[s.slot] + if (s.slot == worst) " · " + tx("più ritardo") else "",
                        fontWeight = FontWeight.Medium, color = if (s.slot == worst) LateRed else androidx.compose.ui.graphics.Color.Unspecified)
                    Text(line, fontSize = 13.sp, color = Muted)
                }
            }
        }
    }
}
