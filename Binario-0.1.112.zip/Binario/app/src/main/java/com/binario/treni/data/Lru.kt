package com.binario.treni.data

/** Memoria con un limite: quando è piena esce la voce usata meno di recente. Sicura tra più thread. */
class Lru<K, V>(private val max: Int) {
    private val m = object : LinkedHashMap<K, V>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>?): Boolean = size > max
    }

    operator fun get(k: K): V? = synchronized(m) { m[k] }
    operator fun set(k: K, v: V) { synchronized(m) { m[k] = v } }
    fun remove(k: K): V? = synchronized(m) { m.remove(k) }
    fun clear() = synchronized(m) { m.clear() }
    val size: Int get() = synchronized(m) { m.size }
}

/** Cache con scadenza: una voce è «fresca» entro [life] ms; se la rete cade si può ancora usare quella scaduta, fino a un'età massima. */
class TtlCache<V>(private val max: Int) {
    private class Entry<V>(val t: Long, val v: V)

    private val m = object : LinkedHashMap<String, Entry<V>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry<V>>?): Boolean = size > max
    }

    fun put(k: String, v: V, now: Long = System.currentTimeMillis()) { synchronized(m) { m[k] = Entry(now, v) } }

    fun fresh(k: String, life: Long, now: Long = System.currentTimeMillis()): V? = synchronized(m) {
        val e = m[k] ?: return null
        if (now - e.t < life) e.v else null
    }

    /** Voce scaduta ma non troppo vecchia, con la sua età in ms. */
    fun stale(k: String, maxAge: Long, now: Long = System.currentTimeMillis()): Pair<V, Long>? = synchronized(m) {
        val e = m[k] ?: return null
        val age = now - e.t
        if (age <= maxAge) e.v to age else null
    }

    fun clear() { synchronized(m) { m.clear() } }
}
