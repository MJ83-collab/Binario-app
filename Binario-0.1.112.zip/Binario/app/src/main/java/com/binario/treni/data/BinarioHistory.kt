package com.binario.treni.data

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Storico dei ritardi raccolto da Binario (script tools/raccolta, pubblicato ogni giorno nella cartella «storico» del repository pubblico):
 * ultimi 30 giorni per treno e classifica giornaliera. Dati ricavati dai tabelloni di ViaggiaTreno, non ufficiali.
 * Se i file non ci sono ancora, le schermate che li usano restano semplicemente nascoste.
 */
object BinarioHistory {
    const val BASE = "https://raw.githubusercontent.com/MJ83-collab/Binario-app/main/storico/"
    private const val TTL = 3 * 3_600_000L

    /** Un giorno di un treno: ritardo in minuti, oppure null se soppresso. */
    data class Day(val day: String, val delay: Int?)

    data class TrainDays(
        val number: String, val category: String, val origin: String, val stationId: String, val station: String,
        val observed: Int, val cancelled: Int, val avgDelay: Double, val punctuality: Double, val days: List<Day>,
        val source: String = "",
    )

    data class Ranked(val day: String, val pos: Int, val number: String, val category: String, val origin: String, val station: String, val time: String, val delay: Int, val source: String = "")

    data class Summary(val trains: Int, val observed: Int, val cancelled: Int, val punctuality: Double, val avgDelay: Double)

    @Volatile private var trainsMemo: Pair<Long, List<TrainDays>>? = null
    @Volatile private var rankMemo: Pair<Long, List<Ranked>>? = null

    private fun fetch(ctx: Context, name: String): String? {
        val f = File(ctx.cacheDir, "storico-" + name.replace('/', '_'))
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < TTL) return f.readText()
        return try {
            val c = Http.open(BASE + name).apply {
                connectTimeout = 10_000; readTimeout = 15_000
                setRequestProperty("User-Agent", "Binario (Android; com.binario.treni)")
            }
            if (c.responseCode != 200) { c.disconnect(); return if (f.exists()) f.readText() else null }
            val t = try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
            f.writeText(t)
            t
        } catch (_: Exception) {
            if (f.exists()) f.readText() else null
        }
    }

    private fun rows(text: String): List<Map<String, String>> {
        val lines = text.lines().filter { it.isNotBlank() }
        if (lines.size < 2) return emptyList()
        val head = lines[0].split(';')
        return lines.drop(1).map { l -> val p = l.split(';'); head.indices.associate { head[it] to p.getOrElse(it) { "" } } }
    }

    fun trains(ctx: Context): List<TrainDays> {
        trainsMemo?.let { (at, l) -> if (System.currentTimeMillis() - at < TTL) return l }
        val text = fetch(ctx, "treni-30g.csv") ?: return emptyList()
        val out = rows(text).mapNotNull { r ->
            try {
                TrainDays(
                    r["numero"].orEmpty(), r["categoria"].orEmpty(), r["origine"].orEmpty(), r["stazione"].orEmpty(), r["nome"].orEmpty(),
                    r["n_osservazioni"]?.toInt() ?: 0, r["n_soppressi"]?.toInt() ?: 0,
                    r["ritardo_medio_minuti"]?.toDouble() ?: 0.0, r["puntualita_percento"]?.toDouble() ?: 0.0,
                    r["giorni"].orEmpty().split('|').filter { it.contains(':') }.map { d ->
                        val day = d.substringBeforeLast(':'); val v = d.substringAfterLast(':')
                        Day(day, if (v == "S") null else v.toIntOrNull() ?: 0)
                    },
                    r["fonte"].orEmpty(),
                )
            } catch (_: Exception) { null }
        }
        if (out.isNotEmpty()) trainsMemo = System.currentTimeMillis() to out
        return out
    }

    fun ranking(ctx: Context): List<Ranked> {
        rankMemo?.let { (at, l) -> if (System.currentTimeMillis() - at < TTL) return l }
        val text = fetch(ctx, "classifica-giorno.csv") ?: return emptyList()
        val out = rows(text).mapNotNull { r ->
            try {
                Ranked(r["giorno"].orEmpty(), r["posizione"]?.toInt() ?: 0, r["numero"].orEmpty(), r["categoria"].orEmpty(), r["origine"].orEmpty(),
                    r["nome"].orEmpty(), r["orario"].orEmpty(), r["ritardo_minuti"]?.toInt() ?: 0, r["fonte"].orEmpty())
            } catch (_: Exception) { null }
        }
        if (out.isNotEmpty()) rankMemo = System.currentTimeMillis() to out
        return out
    }

    /** Gruppi del filtro nella classifica. Trenord e TILO sono un unico servizio: storico unito, su tutte le linee e le reti. */
    enum class Net(val label: String) { ALL("Tutti"), RFI("Italia · RFI"), TRENORD("Trenord · TILO"), CH("Svizzera · FFS") }

    fun netOf(source: String): Net = when {
        source.startsWith("TILO") || source.startsWith("Trenord") || source == "FN" -> Net.TRENORD
        source == "FFS" -> Net.CH
        else -> Net.RFI
    }

    /** Rete su cui arriva il treno Trenord/TILO (dal suffisso della fonte); vuoto se il collettore non la indica. */
    fun networkOf(source: String): String = when (source.substringAfter('-', source.takeIf { it == "FN" } ?: "")) {
        "FN" -> "FerrovieNord"; "RFI" -> "RFI"; "CH" -> "Svizzera"; else -> ""
    }

    /** Un treno soppresso e quello aggiunto che parte al suo posto (stessa stazione, stessa destinazione, entro 15 minuti). */
    data class Replacement(
        val day: String, val cancelled: String, val added: String, val origin: String, val destination: String,
        val cancelledDep: String, val addedDep: String, val diffMinutes: Int,
    )

    fun parseReplacements(text: String): List<Replacement> = rows(text).mapNotNull { r ->
        val c = r["soppresso"].orEmpty().trim(); val a = r["aggiunto"].orEmpty().trim()
        if (c.isBlank() || a.isBlank()) null else Replacement(
            r["giorno"].orEmpty(), c, a, r["origine"].orEmpty(), r["destinazione"].orEmpty(),
            r["partenza_soppresso"].orEmpty(), r["partenza_aggiunto"].orEmpty(), r["differenza_minuti"]?.toIntOrNull() ?: 0,
        )
    }

    /** Le sostituzioni che riguardano [number], come treno soppresso o come treno aggiunto, dalla più recente. */
    fun replacementsOf(all: List<Replacement>, number: String): List<Replacement> {
        val n = number.filter { it.isDigit() }
        if (n.isBlank()) return emptyList()
        return all.filter { it.cancelled == n || it.added == n }.sortedByDescending { it.day }
    }

    fun replacements(ctx: Context): List<Replacement> = fetch(ctx, "trenord/sostituzioni.csv")?.let { parseReplacements(it) }.orEmpty()

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Righe di questo numero di treno; se conosciamo la stazione di origine, scarta quelle di un altro treno con lo stesso numero. */
    fun forTrain(ctx: Context, number: String, origin: String): List<TrainDays> {
        val n = number.filter { it.isDigit() }
        val o = norm(origin)
        return trains(ctx).filter { it.number == n && it.observed >= 2 }
            .filter { r -> o.isBlank() || norm(r.origin).isBlank() || o.contains(norm(r.origin)) || norm(r.origin).contains(o) }
            .sortedByDescending { it.observed }
    }

    fun summary(ctx: Context): Summary? {
        val l = trains(ctx)
        val obs = l.sumOf { it.observed }
        if (obs < 50) return null
        // «observed» comprende anche i soppressi; puntualità e ritardo medio sono sui treni effettuati
        val ran = obs - l.sumOf { it.cancelled }
        val ok = l.sumOf { (it.observed - it.cancelled) * it.punctuality / 100.0 }
        return Summary(l.size, obs, l.sumOf { it.cancelled }, if (ran <= 0) 0.0 else ok * 100.0 / ran,
            if (ran <= 0) 0.0 else l.sumOf { (it.observed - it.cancelled) * it.avgDelay } / ran)
    }
}
