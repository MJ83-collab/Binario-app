package com.binario.treni.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.lerp

/** Come sono disposte le funzioni nella Home. */
enum class HomeLayout { GRID2, MIX, LIST, HERO, GRID3, DASH }

/**
 * Tavolozza e forma di uno stile dell'app. Gli stili «classic» (tradizionale) e «vintage» (tabellone a palette) restano quelli di sempre
 * e non hanno una scheda qui: [AppStyle.spec] vale null.
 */
data class StyleSpec(
    val id: String,
    val name: String,
    val desc: String,
    val layout: HomeLayout,
    val dark: Boolean,
    val primary: Color,
    val onPrimary: Color,
    /** Colore dei campi sulla testata (come GreenField). */
    val field: Color,
    val topBar: Color,
    val onTopBar: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val onSurface: Color,
    val muted: Color,
    val radius: Int = 16,
    /** Spessore del bordo dei riquadri (0 = nessuno). */
    val border: Int = 0,
    val borderColor: Color = Color.Transparent,
    /** Riquadri con un colore pastello diverso per funzione. */
    val colorful: Boolean = false,
    /** Righe con sigla colorata a sinistra (stile «linee e sigle»). */
    val badges: Boolean = false,
    /** Testi e riquadri più grandi. */
    val big: Boolean = false,
    /** Numeri e orari a spaziatura fissa. */
    val mono: Boolean = false,
    /** Riquadri con i sette colori dell'arcobaleno. */
    val rainbow: Boolean = false,
    /** Versione per widget: sfondo del corpo, testo principale e secondario (ARGB). */
    val widgetBody: Int,
    val widgetText: Int,
    val widgetSub: Int,
)

object AppStyle {
    /** Identificativo dello stile attivo: «classic», «vintage» oppure uno di [StyleSpecs.ALL]. */
    var id by mutableStateOf("classic")

    /** Compatibilità: il vecchio interruttore tradizionale / vintage. */
    var vintage: Boolean
        get() = id == "vintage"
        set(v) { id = if (v) "vintage" else "classic" }

    /** Scheda dello stile attivo, oppure null per tradizionale e vintage. */
    val spec: StyleSpec? get() = StyleSpecs.byId(id)?.let { StyleSpecs.forColorBlind(it) }

    /** Colori personalizzati scelti dall'utente (stile «custom»). */
    var customPrimary by mutableStateOf(0xFF0B5CAD.toInt())
    var customDark by mutableStateOf(false)

    fun load(ctx: Context) {
        val st = Store(ctx)
        customPrimary = st.customColor; customDark = st.customDark
        id = StyleSpecs.valid(st.boardStyle)
    }

    /** Salva i colori personalizzati e attiva lo stile «custom». */
    fun setCustom(ctx: Context, color: Int, dark: Boolean) {
        val st = Store(ctx)
        st.customColor = color; st.customDark = dark
        customPrimary = color; customDark = dark
        set(ctx, "custom")
    }

    fun set(ctx: Context, newId: String) {
        val v = StyleSpecs.valid(newId)
        Store(ctx).boardStyle = v
        id = v
    }

    /** Lettura senza stato Compose, per widget e servizi che possono partire senza aprire l'app. */
    fun specOf(ctx: Context): StyleSpec? {
        val st = Store(ctx)
        customPrimary = st.customColor; customDark = st.customDark
        return StyleSpecs.byId(StyleSpecs.valid(st.boardStyle))?.let { StyleSpecs.forColorBlind(it) }
    }
}

object StyleSpecs {
    private fun c(v: Long) = Color(v)

    val ALL: List<StyleSpec> = listOf(
        StyleSpec("tiles_light", "Tessere chiare", "Riquadri bianchi su fondo azzurro, testata blu", HomeLayout.GRID2, false,
            c(0xFF0B5CAD), Color.White, c(0xFF2A74C4), c(0xFF0B5CAD), Color.White, c(0xFFF1F4F8), Color.White, c(0xFFE8EDF4), c(0xFF14213D), c(0xFF5B6678),
            widgetBody = 0xF7FFFFFF.toInt(), widgetText = 0xFF14213D.toInt(), widgetSub = 0xFF5B6678.toInt()),
        StyleSpec("tiles_color", "Tessere colorate", "Ogni funzione ha il suo colore pastello", HomeLayout.GRID2, false,
            c(0xFF2F6BDE), Color.White, c(0xFF3568D4), Color.White, c(0xFF1B1B1F), Color.White, Color.White, c(0xFFEEF0F4), c(0xFF1B1B1F), c(0xFF5F6370),
            radius = 20, colorful = true,
            widgetBody = 0xFFFFFFFF.toInt(), widgetText = 0xFF1B1B1F.toInt(), widgetSub = 0xFF5F6370.toInt()),
        StyleSpec("board_dark", "Tabellone scuro", "Fondo nero e oro, numeri a spaziatura fissa", HomeLayout.GRID2, true,
            c(0xFFD9A441), Color.Black, c(0xFF2A2D35), c(0xFF0E0F12), c(0xFFD9A441), c(0xFF0E0F12), c(0xFF1A1C21), c(0xFF24272E), c(0xFFF2F0EA), c(0xFF9A9CA5),
            radius = 12, border = 1, borderColor = c(0xFF2A2D35), mono = true,
            widgetBody = 0xF20E0F12.toInt(), widgetText = 0xFFF2F0EA.toInt(), widgetSub = 0xFF9A9CA5.toInt()),
        StyleSpec("list_wide", "Lista a riquadri larghi", "Righe larghe divise per sezioni", HomeLayout.LIST, false,
            c(0xFF0B5CAD), Color.White, c(0xFF2A74C4), c(0xFF0B5CAD), Color.White, c(0xFFEEF1F6), Color.White, c(0xFFE8EDF4), c(0xFF14213D), c(0xFF5B6678),
            widgetBody = 0xF7FFFFFF.toInt(), widgetText = 0xFF14213D.toInt(), widgetSub = 0xFF5B6678.toInt()),
        StyleSpec("my_train", "Il mio treno in primo piano", "In alto il tuo prossimo treno con conto alla rovescia", HomeLayout.HERO, false,
            c(0xFF0B5CAD), Color.White, c(0xFF2A74C4), c(0xFF0B5CAD), Color.White, c(0xFFF1F4F8), Color.White, c(0xFFE8EDF4), c(0xFF14213D), c(0xFF5B6678),
            widgetBody = 0xF7FFFFFF.toInt(), widgetText = 0xFF14213D.toInt(), widgetSub = 0xFF5B6678.toInt()),
        StyleSpec("big_four", "Quattro grandi e una lista", "Quattro riquadri grandi, poi righe per il resto", HomeLayout.MIX, false,
            c(0xFF0B5CAD), Color.White, c(0xFF2A74C4), c(0xFF0B5CAD), Color.White, c(0xFFF1F4F8), Color.White, c(0xFFE8EDF4), c(0xFF14213D), c(0xFF5B6678),
            widgetBody = 0xF7FFFFFF.toInt(), widgetText = 0xFF14213D.toInt(), widgetSub = 0xFF5B6678.toInt()),
        StyleSpec("lines_badges", "Linee e sigle", "Righe con la sigla colorata a sinistra, come sulle linee", HomeLayout.LIST, false,
            c(0xFF6A2C91), Color.White, c(0xFF8344AD), c(0xFF6A2C91), Color.White, c(0xFFF3F1F6), Color.White, c(0xFFEAE6F0), c(0xFF211A2B), c(0xFF625A70),
            radius = 14, badges = true,
            widgetBody = 0xF7FFFFFF.toInt(), widgetText = 0xFF211A2B.toInt(), widgetSub = 0xFF625A70.toInt()),
        StyleSpec("contrast", "Alto contrasto", "Nero e giallo, riquadri grandi e bordi spessi", HomeLayout.GRID2, true,
            c(0xFFFFD400), Color.Black, c(0xFF3A3A00), Color.Black, c(0xFFFFD400), Color.Black, Color.Black, c(0xFF1A1A1A), Color.White, c(0xFFE6E6E6),
            radius = 18, border = 3, borderColor = c(0xFFFFD400), big = true,
            widgetBody = 0xFF000000.toInt(), widgetText = 0xFFFFFFFF.toInt(), widgetSub = 0xFFFFD400.toInt()),
        StyleSpec("three_cols", "Tre colonne per sezioni", "Icone compatte in tre colonne, con le sezioni", HomeLayout.GRID3, false,
            c(0xFF0B5CAD), Color.White, c(0xFF2A74C4), c(0xFF0B5CAD), Color.White, c(0xFFF1F4F8), Color.White, c(0xFFE8EDF4), c(0xFF14213D), c(0xFF5B6678),
            radius = 14,
            widgetBody = 0xF7FFFFFF.toInt(), widgetText = 0xFF14213D.toInt(), widgetSub = 0xFF5B6678.toInt()),
        StyleSpec("dashboard", "Cruscotto di oggi", "Ultimi 30 giorni, ritardi del momento e scorciatoie", HomeLayout.DASH, false,
            c(0xFF0B5CAD), Color.White, c(0xFF2A74C4), c(0xFF0B5CAD), Color.White, c(0xFFF1F4F8), Color.White, c(0xFFE8EDF4), c(0xFF14213D), c(0xFF5B6678),
            widgetBody = 0xF7FFFFFF.toInt(), widgetText = 0xFF14213D.toInt(), widgetSub = 0xFF5B6678.toInt()),
        StyleSpec("rainbow", "Tema arcobaleno", "Ogni riquadro ha un colore dell'arcobaleno", HomeLayout.GRID2, false,
            c(0xFF5E35B1), Color.White, c(0xFF7E57C2), c(0xFF5E35B1), Color.White, c(0xFFFAF7FF), Color.White, c(0xFFEFE9F8), c(0xFF1F1B2E), c(0xFF625A75),
            radius = 20, colorful = true, rainbow = true,
            widgetBody = 0xFFFFFFFF.toInt(), widgetText = 0xFF1F1B2E.toInt(), widgetSub = 0xFF625A75.toInt()),
    )

    /** Sette colori dell'arcobaleno: tinta chiara per il riquadro e tinta decisa per icona e sigla. */
    val RAINBOW: List<Pair<Color, Color>> = listOf(
        c(0xFFFFD6D6) to c(0xFFD32F2F), c(0xFFFFE0B2) to c(0xFFE65100), c(0xFFFFF59D) to c(0xFF9A7000),
        c(0xFFC8E6C9) to c(0xFF2E7D32), c(0xFFB2EBF2) to c(0xFF00838F), c(0xFFBBDEFB) to c(0xFF1565C0), c(0xFFE1BEE7) to c(0xFF7B1FA2),
    )

    /** Tavolozza proposta per i colori personalizzati. */
    val PALETTE: List<Int> = listOf(
        0xFF0B5CAD, 0xFF1565C0, 0xFF00838F, 0xFF2E7D32, 0xFF558B2F, 0xFFF9A825,
        0xFFEF6C00, 0xFFD32F2F, 0xFFC2185B, 0xFF7B1FA2, 0xFF5E35B1, 0xFF455A64,
    ).map { it.toInt() }

    /** Stile costruito dai colori scelti dall'utente: testata e pulsanti nel colore scelto, fondo chiaro o scuro. */
    fun custom(primary: Color, dark: Boolean): StyleSpec {
        val onP = if (primary.luminance() > 0.179f) Color.Black else Color.White
        return if (!dark) StyleSpec("custom", "Colori personalizzati", "Scegli tu il colore principale", HomeLayout.GRID2, false,
            primary, onP, lerp(primary, onP, 0.18f), primary, onP, c(0xFFF4F5F7), Color.White, lerp(Color.White, primary, 0.10f), c(0xFF1B1B1F), c(0xFF5F6368),
            widgetBody = 0xF7FFFFFF.toInt(), widgetText = 0xFF1B1B1F.toInt(), widgetSub = 0xFF5F6368.toInt())
        else {
            // Su fondo scuro il colore deve essere abbastanza chiaro da leggersi
            // (lerp di Compose lavora in Oklab: si schiarisce a passi finché la luminanza basta, invece di una quota fissa)
            var acc = primary
            var t = 0f
            while (acc.luminance() < 0.3f && t < 1f) { t += 0.1f; acc = lerp(primary, Color.White, t.coerceAtMost(1f)) }
            StyleSpec("custom", "Colori personalizzati", "Scegli tu il colore principale", HomeLayout.GRID2, true,
                acc, Color.Black, lerp(Color.Black, acc, 0.25f), c(0xFF0E0F12), acc, c(0xFF0E0F12), c(0xFF1A1C21), c(0xFF24272E), c(0xFFF2F2F2), c(0xFF9A9CA5),
                radius = 12, border = 1, borderColor = lerp(Color.Black, acc, 0.4f),
                widgetBody = 0xF20E0F12.toInt(), widgetText = 0xFFF2F2F2.toInt(), widgetSub = acc.toArgb())
        }
    }

    /**
     * Con la modalità daltonici attiva il colore principale diventa quello sicuro scelto per l'app (blu o verde acqua),
     * anche nelle testate e nei campi dello stile. Gli stili scuri e quello ad alto contrasto restano come sono:
     * chiaro su scuro, senza affidarsi alle tinte. Il significato (ritardo, in orario) passa sempre da simboli e testo.
     */
    fun forColorBlind(s: StyleSpec): StyleSpec {
        if (!ColorBlind.on || s.id == "custom") return s // i colori personalizzati li ha scelti l'utente
        if (s.dark) {
            // Stili scuri: il giallo/oro diventa l'azzurro (o verde acqua) sicuro, chiaro su scuro. Il resto resta com'è.
            val acc = Color(ColorBlind.brandOnDark)
            fun sw(c: Color) = if (c == s.primary) acc else c
            return s.copy(
                primary = acc,
                field = if (s.id == "contrast") androidx.compose.ui.graphics.lerp(Color.Black, acc, 0.25f) else s.field,
                onTopBar = sw(s.onTopBar), borderColor = sw(s.borderColor),
                widgetSub = if (s.widgetSub == s.primary.toArgb()) acc.toArgb() else s.widgetSub,
            )
        }
        val brand = Color(ColorBlind.brand)
        return s.copy(
            primary = brand, field = Color(ColorBlind.brandField),
            topBar = if (s.topBar == s.primary) brand else s.topBar,
            onTopBar = if (s.topBar == s.primary) Color.White else s.onTopBar,
        )
    }

    fun byId(id: String): StyleSpec? = if (id == "custom") custom(Color(AppStyle.customPrimary), AppStyle.customDark) else ALL.firstOrNull { it.id == id }

    /** Id accettato: i due stili storici o uno di quelli nuovi; qualsiasi altro valore torna al tradizionale. */
    fun valid(id: String): String = if (id == "classic" || id == "vintage" || byId(id) != null) id else "classic"
}
