package com.binario.treni.ui

import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.runtime.saveable.rememberSaveable
import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.binario.treni.data.Api
import com.binario.treni.data.Linea
import com.binario.treni.data.Station
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Una linea nell'elenco delle aziende. */
data class LineInfo(val code: String, val operator: String, val route: String, val url: String, val status: String = "") {
    fun toJson(): JSONObject = JSONObject().put("c", code).put("o", operator).put("r", route).put("u", url).put("s", status)

    companion object {
        /** Gli elenchi salvati dalle versioni precedenti hanno lo stato dentro il nome («Milano\nCircolazione…»): si separano qui. */
        fun from(o: JSONObject): LineInfo {
            val code = o.optString("c")
            val (route, st) = com.binario.treni.data.LineNotice.splitRow(o.optString("r"), code)
            return LineInfo(code, o.optString("o"), route.ifBlank { o.optString("r") }, o.optString("u"), o.optString("s").ifBlank { st })
        }
    }
}

private val TILO = listOf(
    LineInfo("RE80", "TILO", "Locarno – Lugano – Chiasso – Milano", "https://www.tilo.ch/collegamenti/RE80.html"),
    LineInfo("S10", "TILO", "Biasca – Bellinzona – Lugano – Chiasso – Como", "https://www.tilo.ch/collegamenti/S10.html"),
    LineInfo("S20", "TILO", "Castione-Arbedo – Bellinzona – Locarno", "https://www.tilo.ch/collegamenti/S20.html"),
    LineInfo("S30", "TILO", "Cadenazzo – Luino – Gallarate", "https://www.tilo.ch/collegamenti/S30.html"),
    LineInfo("S40", "TILO", "Como – Mendrisio – Varese", "https://www.tilo.ch/collegamenti/S40.html"),
    LineInfo("S50", "TILO", "Biasca – Bellinzona – Lugano – Varese – Malpensa", "https://www.tilo.ch/collegamenti/S50.html"),
    LineInfo("S90", "TILO", "Giubiasco – Lugano – Mendrisio", "https://www.tilo.ch/collegamenti/S90.html"),
)

/** Rete FerrovieNord (infrastruttura; i treni sono Trenord). */
private val FNM = listOf(
    LineInfo("FN", "FerrovieNord", "Milano – Saronno – Varese – Laveno", "https://www.ferrovienord.it"),
    LineInfo("FN", "FerrovieNord", "Saronno – Como Lago", "https://www.ferrovienord.it"),
    LineInfo("FN", "FerrovieNord", "Milano – Seveso – Asso", "https://www.ferrovienord.it"),
    LineInfo("FN", "FerrovieNord", "Saronno – Novara", "https://www.ferrovienord.it"),
    LineInfo("FN", "FerrovieNord", "Saronno – Seregno", "https://www.ferrovienord.it"),
    LineInfo("FN", "FerrovieNord", "Busto Arsizio – Malpensa", "https://www.ferrovienord.it"),
    LineInfo("FN", "FerrovieNord", "Brescia – Iseo – Edolo", "https://www.ferrovienord.it"),
)

fun lineColor(code: String, operator: String): Color {
    val c = code.uppercase()
    return when {
        operator == "TILO" -> Color(0xFFE2001A)
        operator == "FerrovieNord" -> Color(0xFF00843D)
        c.startsWith("MXP") || c.startsWith("XP") -> Color(0xFFB71C1C)
        c.startsWith("RE") -> Color(0xFFC62828)
        c.startsWith("S") -> Color(0xFF1565C0)
        c.startsWith("R") -> Color(0xFF2E7D32)
        else -> Color(0xFF616161)
    }
}

@Composable
fun LineBadge(code: String, operator: String) {
    Box(
        Modifier.clip(RoundedCornerShape(4.dp)).background(lineColor(code, operator)).padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) { Text(code, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}

/** Pagina ufficiale con l'elenco delle linee Trenord (costruita in JavaScript: si legge con un WebView). */
internal const val TRENORD_LINES_URL = "https://www.trenord.it/linee-e-orari/circolazione/le-nostre-linee/"

/** Script che raccoglie i link alle pagine delle linee: [indirizzo, testo] per ciascuno. */
internal const val TRENORD_LINES_JS = "(function(){return Array.from(document.querySelectorAll('a[href*=\"le-nostre-linee/\"]')).map(function(a){" +
    "return [a.href,(a.innerText||a.getAttribute('title')||a.getAttribute('aria-label')||'').trim()];});})()"

/** Risultato dello script → linee Trenord, senza doppioni (vuoto se illeggibile). Usato dalla schermata e dal controllo in sfondo. */
internal fun parseTrenordLinesJs(res: String?): List<LineInfo> = try {
    val a = JSONArray(res ?: "[]")
    (0 until a.length()).mapNotNull { i ->
        val r = a.getJSONArray(i); parseTrenord(r.optString(0), r.optString(1))
    }.distinctBy { it.code + it.route }
} catch (e: Exception) {
    emptyList()
}

/** Ordine dell'elenco: per tipo (R, RE, S…) e poi per numero. */
internal fun sortTrenordLines(l: List<LineInfo>): List<LineInfo> =
    l.sortedWith(compareBy<LineInfo>({ it.code.takeWhile { c -> c.isLetter() } }, { it.code.filter { c -> c.isDigit() }.toIntOrNull() ?: 0 }))

/** Codice dal parametro della pagina Trenord (RE_13 → RE13) e nome dallo slug. */
private fun parseTrenord(href: String, text: String): LineInfo? {
    if (!href.contains("le-nostre-linee/")) return null
    val code = Regex("[?&]code=([A-Za-z0-9_]+)").find(href)?.groupValues?.get(1)?.replace("_", "") ?: return null
    val slug = href.substringAfter("le-nostre-linee/").substringBefore('/').substringBefore('?')
    if (slug.isBlank()) return null
    val (name, status) = com.binario.treni.data.LineNotice.splitRow(text, code)
    val route = name.takeIf { it.length > 3 }
        ?: slug.split('-').joinToString(" – ") { w -> w.replaceFirstChar { it.uppercase() } }
    return LineInfo(code, "Trenord", route, href, status)
}

/** Elenco Trenord salvato in precedenza (vuoto se manca o è illeggibile). */
internal fun loadSavedTrenordLines(prefs: android.content.SharedPreferences): List<LineInfo> {
    return try {
        val a = JSONArray(prefs.getString("trenord_lines", "[]") ?: "[]")
        val out = ArrayList<LineInfo>(a.length())
        for (i in 0 until a.length()) out.add(LineInfo.from(a.getJSONObject(i)))
        out
    } catch (e: Exception) {
        emptyList()
    }
}

@Composable
fun LinesScreen(vm: MainViewModel, onBack: () -> Unit, onOpen: (Linea) -> Unit, openWeb: (String, String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("binario", android.content.Context.MODE_PRIVATE) }
    var tab by rememberSaveable { mutableStateOf(0) }
    var trenord: List<LineInfo> by remember { mutableStateOf(loadSavedTrenordLines(prefs)) }
    var extracting by remember { mutableStateOf(trenord.isEmpty()) }
    var failed by remember { mutableStateOf(false) }
    var favKeys by remember { mutableStateOf(vm.store.favLines().map { it.url + it.route }.toSet()) }
    var resolving by remember { mutableStateOf<String?>(null) }
    var manual by remember { mutableStateOf<LineInfo?>(null) }
    var expanded by rememberSaveable { mutableStateOf<String?>(null) }

    if (extracting) {
        TrenordLinesReader(
            onResult = { l ->
                extracting = false
                if (l.isEmpty()) {
                    failed = trenord.isEmpty()
                } else {
                    val sorted = sortTrenordLines(l)
                    // Linee preferite il cui stato Trenord è cambiato dall'ultima lettura: avviso (toast + notifica, come in sfondo)
                    com.binario.treni.service.LineWatch.alertChanges(ctx, trenord, sorted, favKeys).forEach { (li, status) ->
                        toast(ctx, "${li.code} · $status")
                    }
                    trenord = sorted
                    com.binario.treni.service.LineWatch.saveTrenordLines(prefs, sorted)
                }
            },
        )
    }

    /** Trova i capolinea dalle stazioni della linea (prima e ultima) per poter mostrare i treni. */
    fun resolve(li: LineInfo, then: (Linea?) -> Unit) {
        resolving = li.route
        scope.launch {
            val parts = li.route.split("–", " - ", "-").map { it.trim() }.filter { it.isNotBlank() }
            val l = withContext(Dispatchers.IO) {
                try {
                    // TILO: capolinea scritti per intero e cercati prima tra le stazioni svizzere («Como» diventava Como Borghi)
                    val ends = if (li.operator == "TILO") com.binario.treni.data.TiloLines.ENDS[li.code] else null
                    val a = if (ends != null) com.binario.treni.data.TiloLines.resolveEnd(ends.first)
                        else parts.firstOrNull()?.let { n -> Api.resolveStation(n) }
                    val b = if (ends != null) com.binario.treni.data.TiloLines.resolveEnd(ends.second)
                        else parts.lastOrNull()?.let { n -> Api.resolveStation(n) }
                    if (a != null && b != null && a.id != b.id) Linea(li.code, a, b, li.url, li.operator, li.route) else null
                } catch (e: Exception) {
                    null
                }
            }
            resolving = null
            then(l)
        }
    }

    val lists: List<List<LineInfo>> = listOf(trenord, TILO, FNM)
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Linee"), onBack) {
            if (tab == 0) IconButton({ extracting = true; failed = false }) { Icon(Icons.Filled.Refresh, tx("Aggiorna")) }
        }
        GreenTabs(listOf("Trenord", "TILO", "FerrovieNord", tx("Svizzera")), tab) { tab = it }
        if (resolving != null) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        if (tab == 3) {
            SwissTab(openWeb) { li -> resolve(li) { l -> if (l != null) onOpen(l) else openWeb("TILO ${li.code}", li.url) } }
            return@Column
        }
        val list = lists[tab]
        LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
            if (tab == 0 && extracting && list.isEmpty()) item { MessageBox(tx("Estraggo l'elenco delle linee dal sito Trenord…")) }
            if (tab == 0 && failed) item {
                MessageBox(tx("Elenco Trenord non disponibile ora."))
                TextButton({ openWeb("Trenord", "https://www.trenord.it/linee-e-orari/circolazione/le-nostre-linee/") }) {
                    Text(tx("Apri le linee sul sito Trenord"), color = Green)
                }
            }
            if (tab == 2) item {
                Text(tx("FerrovieNord gestisce l'infrastruttura: i treni su queste linee sono Trenord."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            }
            items(list, key = { it.operator + it.code + it.route }) { li ->
                val fav = (li.url + li.route) in favKeys
                Column {
                WhiteCard(onClick = { resolve(li) { l -> if (l != null) onOpen(l) else expanded = li.url } }) {
                    Row(Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        LineBadge(li.code, li.operator)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(li.route, fontSize = 16.sp)
                            if (li.status.isNotBlank()) {
                                val lvl = com.binario.treni.data.LineNotice.level(li.status)
                                val tint = noticeColor(lvl)
                                Row(Modifier.clickable(role = androidx.compose.ui.semantics.Role.Button) { expanded = if (expanded == li.url) null else li.url }
                                    .semantics(mergeDescendants = true) { stateDescription = if (expanded == li.url) tx("Aperto") else tx("Chiuso") }
                                    .padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(if (lvl == com.binario.treni.data.LineNotice.Level.REGULAR) Icons.Filled.CheckCircle else Icons.Filled.Warning, null, tint = tint, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(li.status, fontSize = 13.sp, color = tint, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f, fill = false))
                                    Icon(if (expanded == li.url) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, tx("Mostra il messaggio"), tint = tint, modifier = Modifier.size(18.dp))
                                }
                            }
                            Text(li.operator, color = Muted, fontSize = 12.sp)
                        }
                        IconButton({
                            if (fav) {
                                vm.store.favLines().filter { it.url + it.route == li.url + li.route }.forEach { vm.store.removeLine(it) }
                                favKeys = vm.store.favLines().map { it.url + it.route }.toSet()
                            } else resolve(li) { l ->
                                if (l != null) {
                                    vm.store.addLine(l)
                                    favKeys = vm.store.favLines().map { it.url + it.route }.toSet()
                                    toast(ctx, tx("Linea aggiunta ai preferiti"))
                                } else manual = li
                            }
                        }) { Icon(if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder, tx("Preferito"), tint = Green) }
                    }
                }
                if (expanded == li.url) LineNoticeCard(li.url, openWeb, "${li.code} ${li.route}")
                }
            }
        }
    }

    // Se non riesco a riconoscere i capolinea, li fa scegliere a mano
    manual?.let { li ->
        ManualTermini(li, onDismiss = { manual = null }) { l ->
            vm.store.addLine(l); favKeys = vm.store.favLines().map { it.url + it.route }.toSet(); manual = null
        }
    }
}

@Composable
private fun ManualTermini(li: LineInfo, onDismiss: () -> Unit, onSave: (Linea) -> Unit) {
    var a by remember { mutableStateOf<Station?>(null) }
    var b by remember { mutableStateOf<Station?>(null) }
    var pick by remember { mutableStateOf<Int?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${li.code} · ${li.route}") },
        text = {
            Column {
                Text(tx("Scegli i due capolinea"), color = Muted)
                OutlinedButton({ pick = 0 }, Modifier.fillMaxWidth()) { Text(a?.name ?: tx("Capolinea A")) }
                OutlinedButton({ pick = 1 }, Modifier.fillMaxWidth()) { Text(b?.name ?: tx("Capolinea B")) }
            }
        },
        confirmButton = {
            TextButton({ val x = a; val y = b; if (x != null && y != null) onSave(Linea(li.code, x, y, li.url, li.operator, li.route)) }) {
                Text(tx("Salva"), color = Green)
            }
        },
        dismissButton = { TextButton(onDismiss) { Text(tx("Annulla")) } },
    )
    pick?.let { w ->
        key(w) {
            StationPickerDialog(if (w == 0) tx("Capolinea A") else tx("Capolinea B"), { pick = null }) { s ->
                if (w == 0) a = s else b = s
                pick = null
            }
        }
    }
}

@Composable
private fun SwissTab(openWeb: (String, String) -> Unit, onLine: (LineInfo) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
        item {
            WhiteCard {
                CardTitle(tx("Svizzera"))
                MenuRow(Icons.Filled.Warning, tx("Informazioni traffico ferroviario SBB"), tx("Mappa delle perturbazioni in tempo reale")) {
                    openWeb("SBB", "https://www.sbb.ch/it/pianificare/informazioni-traffico-ferroviario?z=5.493227049949057&lng=8.201299999999975&lat=46.80756683561583")
                }
                MenuRow(Icons.Filled.Public, tx("Avvisi TILO"), "") { openWeb("TILO", "https://www.tilo.ch/avvisi.html") }
                MenuRow(Icons.Filled.Info, tx("Traffico, ritardi e scioperi") + " · TILO", "") {
                    openWeb("TILO", "https://www.tilo.ch/servizi/informazioni-traffico-ferroviario.html")
                }
            }
        }
        item { SectionHeader(tx("Linee transfrontaliere TILO")) }
        keyedItems(TILO) { li ->
            // Apre la linea con i treni (orario svizzero); la pagina TILO resta nella scheda della linea
            WhiteCard(onClick = { onLine(li) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    LineBadge(li.code, li.operator)
                    Spacer(Modifier.width(12.dp))
                    Text(li.route, Modifier.weight(1f))
                    Icon(Icons.Filled.KeyboardArrowRight, null, tint = Muted)
                }
            }
        }
    }
}

/**
 * Legge l'elenco delle linee Trenord dalla pagina ufficiale. La pagina è costruita via JavaScript,
 * quindi la apriamo in un WebView invisibile e raccogliamo i link alle pagine delle singole linee.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun TrenordLinesReader(onResult: (List<LineInfo>) -> Unit) {
    AndroidView(
        modifier = Modifier.size(1.dp),
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                var tries = 0
                fun read(v: WebView) {
                    v.evaluateJavascript(TRENORD_LINES_JS) { res ->
                        val list = parseTrenordLinesJs(res)
                        if (list.size < 5 && tries++ < 4) v.postDelayed({ read(v) }, 3000) else onResult(list)
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String?) {
                        view.postDelayed({ read(view) }, 2500)
                    }
                }
                loadUrl(TRENORD_LINES_URL)
            }
        },
        onRelease = { it.destroy() },
    )
}

