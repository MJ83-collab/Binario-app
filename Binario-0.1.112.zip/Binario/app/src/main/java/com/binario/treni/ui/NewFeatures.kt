package com.binario.treni.ui

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.BinarioHistory
import com.binario.treni.data.Station
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.Weather
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------------------------------------------------
// Meteo alla stazione (Open-Meteo)
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun StationWeatherCard(vm: MainViewModel, station: Station) {
    if (!vm.store.showWeather) return
    val ctx = LocalContext.current
    var w by remember(station.id) { mutableStateOf<Weather.Now?>(null) }
    var failed by remember(station.id) { mutableStateOf(false) }
    LaunchedEffect(station.id) {
        val r = withContext(Dispatchers.IO) {
            val c = Api.stationCoord(vm.store, station.id) ?: return@withContext null
            Weather.load(c.first, c.second)
        }
        w = r; failed = r == null
    }
    val x = w
    if (x == null) { if (!failed) Box(Modifier.fillMaxWidth().height(2.dp)); return }
    WhiteCard {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Weather.icon(x.code), fontSize = 34.sp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(x.temp.toString() + "° · " + tx(Weather.label(x.code)), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(tx("Meteo a") + " " + station.name, color = Muted, fontSize = 12.sp, maxLines = com.binario.treni.data.TextScale.lines(1))
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(tx("Percepita") + " " + x.feels + "°", fontSize = 13.sp)
                    Text(tx("Vento") + " " + x.windKmh + " km/h" + (if (x.rainMm > 0.0) " · " + x.rainMm + " mm" else ""), color = Muted, fontSize = 12.sp)
                }
            }
            if (x.hours.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    x.hours.forEach { h ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(h.label, color = Muted, fontSize = 11.sp)
                            Text(Weather.icon(h.code), fontSize = 18.sp)
                            Text(h.temp.toString() + "°", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            if (h.rainPercent >= 30) Text(h.rainPercent.toString() + "%", color = Color(0xFF1976D2), fontSize = 11.sp)
                        }
                    }
                }
            }
            Text("Open-Meteo.com", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Prossima fermata con conto alla rovescia
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun NextStopCard(st: TrainStatus) {
    if (st.cancelled || st.arrived || st.stops.isEmpty()) return
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.number, st.delay) { while (true) { now = System.currentTimeMillis(); delay(1000) } }

    // Treno non ancora partito: il conto alla rovescia è per la partenza dalla prima stazione
    val departed = st.departed
    val stop = if (departed) st.nextStop else st.stops.first()
    if (stop == null) return
    val sched = if (departed) (if (stop.schedArr > 0) stop.schedArr else stop.schedDep) else (if (stop.schedDep > 0) stop.schedDep else stop.schedArr)
    if (sched <= 0) return
    val eta = sched + (if (stop.delay != 0) stop.delay else st.delay) * 60_000L
    val left = eta - now
    val sec = left / 1000
    val big = when {
        left <= 0 -> tx("In arrivo")
        sec >= 3600 -> (sec / 3600).toString() + " h " + ((sec % 3600) / 60).toString().padStart(2, '0') + " min"
        else -> (sec / 60).toString().padStart(2, '0') + ":" + (sec % 60).toString().padStart(2, '0')
    }
    val urgent = left in 1..120_000L
    val ctx = LocalContext.current
    var typical by remember(st.number) { mutableStateOf<Double?>(null) }
    LaunchedEffect(st.number) {
        typical = withContext(Dispatchers.IO) { runCatching { BinarioHistory.forTrain(ctx, st.number, st.origin).firstOrNull()?.takeIf { it.observed >= 5 }?.avgDelay }.getOrNull() }
    }
    WhiteCard {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(if (departed) tx("Prossima fermata") else tx("Partenza tra"), color = Muted, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stop.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = com.binario.treni.data.TextScale.lines(2))
                    Text(com.binario.treni.data.Fmt.time(eta) +
                        (if (stop.platformText.isNotBlank()) " · " + tx("binario") + " " + stop.platformText else "") +
                        (if (st.delay > 0) " · +${st.delay} min" else ""), color = if (st.delay > 5) LateRed else Muted, fontSize = 13.sp)
                }
                Text((if (left > 0) "~" else "") + big, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 30.sp, color = if (urgent) LateRed else Green)
            }
            Text(
                tx("Stima: orario in tabella più il ritardo noto.") + typical?.let { " " + tx("Di solito questo treno arriva con") + " " + (if (it > 0) "+" else "") + "%.1f min".format(it) + "." }.orEmpty(),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Storico dei ritardi più ricco (ultimi 30 giorni raccolti da Binario)
// ---------------------------------------------------------------------------------------------------------------------

/** «Soppresso, sostituito dal 4747»: avviso in cima alla scheda quando oggi questo treno è soppresso e un altro parte al suo posto, o è il sostituto. */
@Composable
fun ReplacementCard(st: TrainStatus, onTrain: (TrainRef) -> Unit) {
    val ctx = LocalContext.current
    var list by remember(st.number) { mutableStateOf<List<BinarioHistory.Replacement>>(emptyList()) }
    LaunchedEffect(st.number) {
        list = withContext(Dispatchers.IO) { runCatching { BinarioHistory.replacementsOf(BinarioHistory.replacements(ctx), st.number) }.getOrDefault(emptyList()) }
    }
    if (list.isEmpty()) return
    val n = st.number.filter { it.isDigit() }
    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ROOT).apply { timeZone = java.util.TimeZone.getTimeZone("Europe/Rome") }.format(java.util.Date())
    val now = list.firstOrNull { it.day == today }
    WhiteCard {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            if (now != null) {
                val isCancelled = now.cancelled == n
                val other = if (isCancelled) now.added else now.cancelled
                Text(if (isCancelled) tx("Soppresso oggi") else tx("Treno aggiunto oggi"), color = LateRed, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    if (isCancelled) tx("Sostituito dal treno") + " " + other + " · " + tx("partenza") + " " + now.addedDep + " " + tx("da") + " " + now.origin + " " + tx("per") + " " + now.destination
                    else tx("Parte al posto del treno") + " " + other + " (" + now.cancelledDep + ") " + tx("da") + " " + now.origin + " " + tx("per") + " " + now.destination,
                    fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp),
                )
                Text(tx("Apri il treno") + " " + other + " →", color = Green, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    modifier = Modifier.padding(top = 8.dp).clickable { onTrain(TrainRef(other, label = other)) })
            }
            val older = list.filter { it.day != today }.take(3)
            if (older.isNotEmpty()) {
                Text(tx("Altre volte") + ": " + older.joinToString(" · ") { r ->
                    r.day.takeLast(5).split('-').reversed().joinToString("/") + " " + (if (r.cancelled == n) tx("sostituito dal") + " " + r.added else tx("al posto del") + " " + r.cancelled)
                }, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            Text(tx("Dati raccolti da Binario, non ufficiali."), color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun TrainHistory14Card(st: TrainStatus) {
    val ctx = LocalContext.current
    var rows by remember(st.number) { mutableStateOf<List<BinarioHistory.TrainDays>>(emptyList()) }
    LaunchedEffect(st.number) {
        rows = withContext(Dispatchers.IO) { runCatching { BinarioHistory.forTrain(ctx, st.number, st.origin) }.getOrDefault(emptyList()) }
    }
    val r = rows.firstOrNull() ?: return
    val ran = r.observed - r.cancelled
    WhiteCard {
        CardTitle(tx("Storico ultimi 30 giorni"))
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Stat(tx("In orario"), "%.0f%%".format(r.punctuality), if (r.punctuality >= 80) OnTime else if (r.punctuality >= 60) Color(0xFFEF6C00) else LateRed, Modifier.weight(1f))
                Stat(tx("Ritardo medio"), (if (r.avgDelay > 0) "+" else "") + "%.1f min".format(r.avgDelay), if (r.avgDelay > 5) LateRed else MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
                Stat(tx("Soppressi"), r.cancelled.toString(), if (r.cancelled > 0) LateRed else MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            DelayBars(r.days)
            Text(tx("Rilevato all'arrivo a") + " " + r.station + BinarioHistory.networkOf(r.source).let { if (it.isBlank()) "" else " (" + tx("rete") + " " + it + ")" } + " · " + ran + " " + tx("corse effettuate"), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Text(tx("Dati raccolti da Binario, non ufficiali."), color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Stat(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(10.dp)) {
        Text(label, color = Muted, fontSize = 11.sp, maxLines = com.binario.treni.data.TextScale.lines(1))
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = com.binario.treni.data.TextScale.lines(1))
    }
}

/** Una colonna per giorno: altezza = minuti di ritardo (massimo 30), rossa oltre i 5 minuti, grigia con una croce se soppresso. */
@Composable
private fun DelayBars(days: List<BinarioHistory.Day>) {
    val late = LateRed; val ok = OnTime; val grey = Muted; val line = MaterialTheme.colorScheme.outline
    Canvas(Modifier.fillMaxWidth().height(64.dp)) {
        val n = days.size.coerceAtLeast(1)
        val gap = 4.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        drawLine(line.copy(alpha = 0.4f), Offset(0f, size.height - 1f), Offset(size.width, size.height - 1f), 1f)
        days.forEachIndexed { i, d ->
            val x = i * (w + gap)
            val v = d.delay
            if (v == null) {
                drawRect(grey.copy(alpha = 0.5f), Offset(x, 0f), Size(w, size.height - 2f))
            } else {
                val h = ((v.coerceIn(0, 30)) / 30f * (size.height - 6f)).coerceAtLeast(3f)
                drawRect(if (v > 5) late else ok, Offset(x, size.height - 2f - h), Size(w, h))
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Classifica ritardi: adesso, per giorno, ultimi 30 giorni
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun RankingScreen(onBack: () -> Unit, onTrain: (com.binario.treni.data.TrainRef) -> Unit, onNumber: (String) -> Unit) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var worst by remember { mutableStateOf(true) }
    var rank by remember { mutableStateOf<List<BinarioHistory.Ranked>?>(null) }
    var trains by remember { mutableStateOf<List<BinarioHistory.TrainDays>?>(null) }
    var day by rememberSaveable { mutableStateOf("") }
    var net by remember { mutableStateOf(BinarioHistory.Net.ALL) }
    var sub by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            rank = runCatching { BinarioHistory.ranking(ctx) }.getOrDefault(emptyList())
            trains = runCatching { BinarioHistory.trains(ctx) }.getOrDefault(emptyList())
        }
        day = rank.orEmpty().maxOfOrNull { it.day }.orEmpty()
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Classifica ritardi"), onBack = onBack)
        TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.surface, contentColor = Green) {
            listOf(tx("Adesso"), tx("Per giorno"), tx("30 giorni")).forEachIndexed { i, t ->
                Tab(tab == i, { tab = i }, text = { Text(t, fontSize = 14.sp) })
            }
        }
        when (tab) {
            0 -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                DelayedNowCard(onTrain)
                Text(tx("Campione dei principali nodi: non è l'elenco di tutta la rete."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
            }
            1 -> {
                val all = rank
                when {
                    all == null -> LoadingBox()
                    all.isEmpty() -> EmptyHistory()
                    else -> {
                        val days = all.map { it.day }.distinct().sortedDescending().take(7)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BinarioHistory.Net.entries.forEach { n -> FilterChip(selected = n == net, onClick = { net = n; sub = "" }, label = { Text(tx(n.label), fontSize = 12.sp) }) }
                        }
                        if (net == BinarioHistory.Net.TRENORD) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("" to "Tutte le reti", "RFI" to "RFI", "FerrovieNord" to "FerrovieNord", "Svizzera" to "Svizzera").forEach { (k, l) ->
                                    FilterChip(selected = sub == k, onClick = { sub = k }, label = { Text(tx(l), fontSize = 12.sp) })
                                }
                            }
                        }
                        ChipRow(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
                            days.forEach { d -> FilterChip(selected = d == day, modifier = Modifier.padding(end = 6.dp), onClick = { day = d }, label = { Text(d.takeLast(5).replace('-', '/').split('/').reversed().joinToString("/"), fontSize = 12.sp) }) }
                        }
                        LazyColumn(Modifier.fillMaxSize()) {
                            keyedItems(all.filter { it.day == day && (net == BinarioHistory.Net.ALL || BinarioHistory.netOf(it.source) == net) && (sub.isBlank() || BinarioHistory.networkOf(it.source) == sub) }.sortedByDescending { it.delay }.withIndex().toList()) { (i, r) ->
                                RankRow(i + 1, r.category + " " + r.number, r.origin + " → " + r.station + " · " + r.time + BinarioHistory.networkOf(r.source).let { if (it.isBlank()) "" else " · " + it }, "+" + r.delay + " min", LateRed) { onNumber(r.number) }
                            }
                            item { Text(tx("Dati raccolti da Binario, non ufficiali."), color = Muted, fontSize = 11.sp, modifier = Modifier.padding(16.dp)) }
                        }
                    }
                }
            }
            else -> {
                val all = trains
                when {
                    all == null -> LoadingBox()
                    all.isEmpty() -> EmptyHistory()
                    else -> {
                        val list = all.filter { it.observed >= 3 && (net == BinarioHistory.Net.ALL || BinarioHistory.netOf(it.source) == net) && (sub.isBlank() || BinarioHistory.networkOf(it.source) == sub) }.let { l ->
                            if (worst) l.sortedByDescending { it.avgDelay } else l.sortedWith(compareByDescending<BinarioHistory.TrainDays> { it.punctuality }.thenByDescending { it.observed })
                        }.take(50)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BinarioHistory.Net.entries.forEach { n -> FilterChip(selected = n == net, onClick = { net = n; sub = "" }, label = { Text(tx(n.label), fontSize = 12.sp) }) }
                        }
                        if (net == BinarioHistory.Net.TRENORD) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("" to "Tutte le reti", "RFI" to "RFI", "FerrovieNord" to "FerrovieNord", "Svizzera" to "Svizzera").forEach { (k, l) ->
                                    FilterChip(selected = sub == k, onClick = { sub = k }, label = { Text(tx(l), fontSize = 12.sp) })
                                }
                            }
                        }
                        ChipRow(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
                            FilterChip(worst, { worst = true }, label = { Text(tx("Più in ritardo")) }, modifier = Modifier.padding(end = 6.dp))
                            FilterChip(!worst, { worst = false }, label = { Text(tx("Più puntuali")) })
                        }
                        LazyColumn(Modifier.fillMaxSize()) {
                            keyedItems(list.indices.toList()) { i ->
                                val r = list[i]
                                RankRow(i + 1, r.category + " " + r.number, r.origin + " → " + r.station + " · " + r.observed + " " + tx("corse") + BinarioHistory.networkOf(r.source).let { if (it.isBlank()) "" else " · " + it },
                                    if (worst) (if (r.avgDelay > 0) "+" else "") + "%.1f min".format(r.avgDelay) else "%.0f%%".format(r.punctuality),
                                    if (worst) LateRed else OnTime) { onNumber(r.number) }
                            }
                            item { Text(tx("Dati raccolti da Binario, non ufficiali."), color = Muted, fontSize = 11.sp, modifier = Modifier.padding(16.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyHistory() {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(tx("Lo storico si sta ancora riempiendo."), fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Text(tx("Binario raccoglie i ritardi ogni giorno: tra qualche giorno qui trovi la classifica."), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun RankRow(pos: Int, title: String, sub: String, value: String, color: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(pos.toString(), color = Muted, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.width(34.dp.fs()))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = com.binario.treni.data.TextScale.lines(1))
            Text(sub, color = Muted, fontSize = 12.sp, maxLines = com.binario.treni.data.TextScale.lines(1))
        }
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
    HorizontalDivider(color = Color(0x14000000))
}
