package com.binario.treni.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext

/**
 * Calcolo del disagio di una linea con i dati veri: treni diretti partiti nelle ultime 3 ore in entrambe le direzioni,
 * poi lo stato di ciascuno (al massimo 16, 4 alla volta). Lo usano la scheda della linea e il controllo in sfondo
 * delle linee preferite. Null se non si è potuto calcolare (l'errore va nel registro).
 */
object LineDisruptionLoader {
    suspend fun load(line: Linea, now: Long = System.currentTimeMillis()): DisruptionSummary? = withContext(Dispatchers.IO) {
        // Linee TILO e svizzere: treni e ritardi dall'orario svizzero (l'orario italiano non ha i diretti attraverso la Svizzera)
        if (TiloLines.isTilo(line)) return@withContext TiloLines.disruption(line, now)
        try {
            var searchErrors = 0
            val sols = listOf(line.a to line.b, line.b to line.a).flatMap { (from, to) ->
                try {
                    Api.solutions(from, to, now - LineDisruption.WINDOW_MS, SearchFilter.ALL, maxChanges = 0)
                } catch (e: Exception) {
                    searchErrors++
                    Diag.record("disagio-linea/orario", e)
                    emptyList()
                }
            }
            // Orario non letto in nessuna delle due direzioni: non si sa nulla, non «nessun treno partito»
            if (searchErrors == 2) return@withContext null
            val numbers = LineDisruption.candidates(sols, now)
            val states = numbers.chunked(4).flatMap { group ->
                group.map { n ->
                    async {
                        try {
                            Api.status(TrainRef(n))
                        } catch (e: Exception) {
                            null
                        }
                    }
                }.awaitAll()
            }
            // Nessuno stato letto su tanti treni: errore di rete, non un disagio dello 0%
            if (numbers.isNotEmpty() && states.all { it == null }) return@withContext null
            LineDisruption.summarize(states.filterNotNull())
        } catch (e: Exception) {
            Diag.record("disagio-linea", e)
            null
        }
    }
}
