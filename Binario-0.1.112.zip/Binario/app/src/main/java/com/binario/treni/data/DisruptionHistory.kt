package com.binario.treni.data

import android.content.Context

/**
 * Andamento del disagio delle linee sul telefono: lo aggiornano la scheda della linea (quando la apri) e il controllo
 * in sfondo delle linee preferite. Per ogni linea il disagio peggiore di ciascuno degli ultimi 7 giorni.
 */
object DisruptionHistory {
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("line_watch", Context.MODE_PRIVATE)

    private fun key(line: Linea) = "h_" + line.key.hashCode()

    fun record(ctx: Context, line: Linea, s: DisruptionSummary, now: Long = System.currentTimeMillis()) {
        if (s.checked == 0) return // nessun treno partito: non dice nulla sul disagio
        val p = prefs(ctx)
        p.edit().putString(key(line), LineDisruption.historyAdd(p.getString(key(line), null), TripLog.dayOf(now), s.percent)).apply()
    }

    fun get(ctx: Context, line: Linea): List<Pair<String, Int>> = LineDisruption.historyDecode(prefs(ctx).getString(key(line), null))
}
