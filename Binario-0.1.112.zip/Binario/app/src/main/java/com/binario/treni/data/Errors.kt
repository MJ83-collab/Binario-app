package com.binario.treni.data

import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/** Errore di rete o del servizio (non un problema di dati o di logica). */
fun Throwable.isNetwork(): Boolean = this is OfflineException || this is HttpStatusException || this is UnknownHostException ||
    this is ConnectException || this is NoRouteToHostException || this is SocketTimeoutException || this is javax.net.ssl.SSLException

/** Il messaggio scritto dall'app se c'è; per gli errori di rete (o senza messaggio) la frase comprensibile. */
fun Throwable.messageOrUtente(): String = if (isNetwork() || message.isNullOrBlank()) perUtente() else message!!

/** Frase comprensibile per l'utente al posto del testo tecnico dell'errore (nella lingua scelta). */
fun Throwable.perUtente(): String = when {
    this is OfflineException || this is UnknownHostException || this is ConnectException || this is NoRouteToHostException ->
        tx("Nessuna connessione. Controlla il Wi-Fi o i dati mobili.")
    this is SocketTimeoutException -> tx("Il servizio non risponde. Riprova tra poco.")
    this is HttpStatusException && (code == 429) -> tx("Troppe richieste. Attendi un minuto e riprova.")
    this is HttpStatusException && (code == 404) -> tx("Non trovato: il servizio non ha questo dato.")
    this is HttpStatusException && (code >= 500) -> tx("Il servizio ha un problema. Riprova più tardi.")
    message?.startsWith("HTTP 5") == true -> tx("Il servizio ha un problema. Riprova più tardi.")
    message?.startsWith("HTTP 429") == true -> tx("Troppe richieste. Attendi un minuto e riprova.")
    message?.startsWith("HTTP 404") == true -> tx("Non trovato: il servizio non ha questo dato.")
    else -> tx("Qualcosa non ha funzionato. Riprova.")
}
