package com.binario.treni.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Avviso di circolazione di ViaggiaTreno (rete RFI): titolo, testo, data «gg/mm/aaaa» (o con l'ora) oppure vuota. */
data class VtItem(val title: String, val text: String, val date: String)

/**
 * Lettura dell'infomobilità di ViaggiaTreno, che arriva come frammenti HTML:
 * - `infomobilitaRSS/false`: avvisi completi (`<li class="editModeCollapsibleElement">`, titolo in `headingNewsAccordion`,
 *   data in `<h4>gg.mm.aaaa</h4>`, testo in `info-text`);
 * - `infomobilitaTicker`: avvisi brevi del nastro scorrevole (`<ul><li>…</li></ul>`).
 * «Circolazione regolare» non è un avviso e si scarta. Logica pura, provata nei test.
 */
object VtInfomobility {
    private val itemStart = Regex("""<li[^>]*class="[^"]*editModeCollapsibleElement[^"]*"[^>]*>""", RegexOption.IGNORE_CASE)
    private val titleRx = Regex("""class="[^"]*headingNewsAccordion[^"]*"[^>]*>(.*?)</a>""", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    private val dateRx = Regex("""<h4[^>]*>\s*(\d{1,2})[./-](\d{1,2})[./-](\d{4})\s*</h4>""", RegexOption.IGNORE_CASE)
    private val bodyRx = Regex("""class="[^"]*info-text[^"]*"[^>]*>(.*)""", RegexOption.DOT_MATCHES_ALL)
    private val liRx = Regex("""<li[^>]*>(.*?)</li>""", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    private val regular = Regex("""(?i)^circolazione regolare\b""")
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")

    fun isRegular(title: String): Boolean = regular.containsMatchIn(title.trim())

    /** Data e ora nel formato che le Notizie sanno ordinare («09/11/2026 10:12»). */
    fun itDate(ms: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALY).apply { timeZone = rome }.format(Date(ms))

    fun parseRss(html: String, clean: (String) -> String): List<VtItem> =
        itemStart.split(html).drop(1).mapNotNull { chunk ->
            val t = titleRx.find(chunk)?.groupValues?.get(1)?.let(clean).orEmpty()
            if (t.isBlank() || isRegular(t)) return@mapNotNull null
            val d = dateRx.find(chunk)?.let { m ->
                String.format(Locale.US, "%02d/%02d/%s", m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3])
            }.orEmpty()
            val b = bodyRx.find(chunk)?.groupValues?.get(1)?.let(clean).orEmpty()
            VtItem(t, b, d)
        }

    fun parseTicker(html: String, clean: (String) -> String): List<VtItem> =
        liRx.findAll(html).map { clean(it.groupValues[1]) }
            .filter { it.isNotBlank() && !isRegular(it) }
            .map { VtItem(it, "", "") }
            .toList()

    /** Chiave per confrontare i titoli: minuscole, solo lettere e cifre. */
    fun key(s: String): String = s.lowercase().replace(Regex("""[^\p{L}\p{N}]+"""), " ").trim()

    /**
     * Toglie i doppioni: stesso titolo, oppure un avviso breve (senza testo) già contenuto nel titolo di uno completo.
     * Vince il primo: passare prima gli avvisi completi, poi quelli brevi.
     */
    fun dedupe(items: List<VtItem>): List<VtItem> {
        val out = mutableListOf<VtItem>()
        for (item in items) {
            val k = key(item.title)
            if (k.isBlank()) continue
            val dup = out.any { o ->
                val ok = key(o.title)
                ok == k || (item.text.isBlank() && ok.contains(k)) || (o.text.isBlank() && k.contains(ok))
            }
            if (!dup) out += item
        }
        return out
    }
}
