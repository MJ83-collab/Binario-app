package com.binario.treni.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DownloadForOffline
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Store
import com.binario.treni.data.tx

/** Guida breve, una sola volta, dopo le prime domande: le quattro cose che non si capiscono a colpo d'occhio. */
@Composable
fun FirstRunGuide(store: Store) {
    var show by remember { mutableStateOf(!store.guideSeen) }
    if (!show) return
    fun close() { store.guideSeen = true; show = false }
    AlertDialog(
        onDismissRequest = { close() },
        title = { Text(tx("Come funziona Binario")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                GuideRow(Icons.Filled.Tune, tx("Base o Completa"), tx("Nella schermata Cerca scegli quante funzioni vedere. Puoi cambiare quando vuoi: la scelta resta salvata."))
                GuideRow(Icons.Filled.DownloadForOffline, tx("Orari offline"), tx("Nei risultati tocca «Salva questi orari per usarli offline»: li ritrovi in Orari offline anche senza rete."))
                GuideRow(Icons.Filled.Widgets, tx("Widget"), tx("Tieni premuto sulla Home, scegli Widget e aggiungi Binario: partenze e ritardi sempre sotto gli occhi."))
                GuideRow(Icons.Filled.BarChart, tx("Puntualità"), tx("Sotto ogni icona c'è il nome della scheda: cerca una stazione o un treno e vedi quanti arrivano in orario."))
            }
        },
        confirmButton = { Button({ close() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tx("Ho capito")) } },
    )
}

@Composable
private fun GuideRow(icon: ImageVector, title: String, text: String) {
    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(text, color = Muted, fontSize = 14.sp)
        }
    }
}
