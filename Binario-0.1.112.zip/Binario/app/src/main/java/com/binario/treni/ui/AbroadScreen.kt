package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.tx

/** «Treni in Italia», «Treni in Svizzera», «Treni in Austria» e «Treni in Francia»: come cercarli, fonte dei dati e siti ufficiali. */
@Composable
fun AbroadScreen(country: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val title = when (country) {
        "IT" -> tx("Treni in Italia"); "CH" -> tx("Treni in Svizzera"); "AT" -> tx("Treni in Austria"); else -> tx("Treni in Francia")
    }
    val flag = when (country) { "IT" -> "🇮🇹 "; "CH" -> "🇨🇭 "; "AT" -> "🇦🇹 "; else -> "🇫🇷 " }
    val intro = when (country) {
        "IT" -> tx("Orari, ritardi e binari dei treni italiani (Trenitalia, Italo, Trenord, FerrovieNord e ferrovie regionali).")
        "CH" -> tx("Orari, ritardi e binari dei treni svizzeri (FFS, TILO e ferrovie regionali), con affollamento e servizi in stazione dove le FFS li pubblicano.")
        "AT" -> tx("Orari, ritardi e binari dei treni austriaci (ÖBB, Westbahn e aziende regionali), quando i dati in tempo reale sono pubblicati.")
        else -> tx("Orari, ritardi e binari dei treni francesi (TGV, TER, Intercités, RER), quando i dati in tempo reale sono pubblicati.")
    }
    val how = when (country) {
        "IT", "CH" -> tx("Cerca la stazione per nome, il treno per numero o la tratta. Funzionano ricerca viaggi, tabellone, scheda del treno e «Segui».")
        else -> tx("Cerca la stazione anche con il nome italiano: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Funzionano ricerca viaggi (anche con l'Italia), tabellone, scheda del treno e «Segui».")
    }
    val note = when (country) {
        "IT" -> tx("Dati: ViaggiaTreno, Trenord e Italo. Il tempo reale dipende da quanto pubblicano le aziende e può mancare per alcune corse. Fanno sempre fede tabelloni e annunci.")
        "CH" -> tx("Dati: FFS (dati aperti). Il tempo reale dipende da quanto pubblicano le aziende e può mancare per alcune corse. Fanno sempre fede tabelloni e annunci.")
        else -> tx("Dati: orari ufficiali tramite Transitous; il tempo reale dipende da quanto pubblicano le aziende e può mancare per alcune corse. I prezzi non sono pubblici: biglietti sui siti ufficiali. Fanno sempre fede tabelloni e annunci.")
    }
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { GreenTopBar(title, onBack) }
        item {
            WhiteCard {
                Column(Modifier.padding(16.dp)) {
                    Text(flag + intro, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(how, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(note, color = Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            WhiteCard {
                val info = tx("Biglietti e informazioni ufficiali")
                Column {
                    when (country) {
                        "IT" -> {
                            MenuRow(Icons.Filled.ShoppingCart, "Trenitalia", "$info · trenitalia.com") { openUrl(ctx, "https://www.trenitalia.com/") }
                            MenuRow(Icons.Filled.ShoppingCart, "Italo", "$info · italotreno.com") { openUrl(ctx, "https://www.italotreno.com/") }
                            MenuRow(Icons.Filled.ShoppingCart, "Trenord", "$info · trenord.it") { openUrl(ctx, "https://www.trenord.it/") }
                        }
                        "CH" -> {
                            MenuRow(Icons.Filled.ShoppingCart, "SBB / CFF / FFS", "$info · sbb.ch") { openUrl(ctx, "https://www.sbb.ch/") }
                            MenuRow(Icons.Filled.ShoppingCart, "TILO", "$info · tilo.ch") { openUrl(ctx, "https://www.tilo.ch/") }
                        }
                        "AT" -> MenuRow(Icons.Filled.ShoppingCart, "ÖBB", "$info · oebb.at") { openUrl(ctx, "https://www.oebb.at/") }
                        else -> MenuRow(Icons.Filled.ShoppingCart, "SNCF Connect", "$info · sncf-connect.com") { openUrl(ctx, "https://www.sncf-connect.com/") }
                    }
                }
            }
        }
    }
}
