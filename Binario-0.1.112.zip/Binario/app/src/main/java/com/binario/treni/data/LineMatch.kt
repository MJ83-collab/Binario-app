package com.binario.treni.data

/**
 * Riconoscimento della «stessa linea» tra due treni, senza dipendere da Android (si prova con i test).
 * Usato da «Treni davanti e dietro al tuo»: avere la stessa destinazione non basta.
 */
object LineMatch {
    /** Nome di fermata confrontabile: senza maiuscole, accenti, spazi e punteggiatura (le fonti scrivono «Milano Cadorna», «MILANO CADORNA», «Milano Cadorna (MI)»). */
    fun norm(name: String): String =
        java.text.Normalizer.normalize(name.substringBefore(" (").lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\bf\\.\\s?n\\.?(?=\\s|$)"), " ")      // «F.N.»
            .replace(Regex("\\b(fn|ferrovienord|ferrovie nord)\\b"), " ") // sigla della rete FerrovieNord («Milano Cadorna FN»)
            .filter { it.isLetterOrDigit() }

    /**
     * Le fermate che restano al tuo treno (da quella di riferimento) e a un altro treno: percorrono lo stesso tratto se quelle
     * del più corto ricorrono quasi tutte (70%) nell'altro, nello stesso ordine, e sono almeno due (o una sola se il tratto è di una fermata).
     */
    fun sameCorridor(mine: List<String>, cand: List<String>): Boolean {
        if (mine.isEmpty() || cand.isEmpty()) return false
        val (short, long) = if (cand.size <= mine.size) cand to mine else mine to cand
        var pos = 0
        val common = short.count { k ->
            val i = long.drop(pos).indexOf(k)
            if (i >= 0) { pos += i + 1; true } else false
        }
        return common >= minOf(2, short.size) && common * 100 >= short.size * 70
    }

    /** Stesso codice linea (RE1, R31…); se per uno dei due non è noto, non si esclude. */
    fun sameLineCode(a: String?, b: String?): Boolean =
        a.isNullOrBlank() || b.isNullOrBlank() || a.trim().equals(b.trim(), ignoreCase = true)

    /**
     * Quanto due elenchi di fermate (identificativo, nome normalizzato) coincidono: la quota maggiore tra «fermate di [mine] presenti in [other]»
     * e il contrario. Serve a capire se due fonti descrivono la stessa corsa quando il numero del treno è lo stesso su reti diverse
     * (es. 10060 Mortara – Milano Rogoredo e 10060 Varese Nord – Milano Cadorna).
     */
    fun stopOverlap(mine: List<Pair<String, String>>, other: List<Pair<String, String>>): Double {
        fun share(a: List<Pair<String, String>>, b: List<Pair<String, String>>): Double {
            if (a.isEmpty() || b.isEmpty()) return 0.0
            val ids = b.map { it.first }.filter { it.isNotBlank() }.toSet()
            val names = b.map { it.second }.filter { it.isNotBlank() }.toSet()
            return a.count { (id, n) -> (id.isNotBlank() && id in ids) || (n.isNotBlank() && n in names) }.toDouble() / a.size
        }
        return maxOf(share(mine, other), share(other, mine))
    }

    /** Indice del candidato che coincide di più con [mine] (almeno [min]); -1 se nessuno è la stessa corsa. */
    fun bestOverlap(mine: List<Pair<String, String>>, candidates: List<List<Pair<String, String>>>, min: Double = 0.5): Int {
        var best = -1
        var bo = -1.0
        candidates.forEachIndexed { i, c ->
            val o = stopOverlap(mine, c)
            if (o >= min && o > bo) { bo = o; best = i }
        }
        return best
    }
}
