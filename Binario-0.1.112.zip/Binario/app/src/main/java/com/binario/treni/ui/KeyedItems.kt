package com.binario.treni.ui

import androidx.compose.foundation.lazy.LazyItemScope
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.Composable

/**
 * Chiavi uniche e stabili per una lista: quella scelta da [key] e, se la stessa compare più volte, un numero progressivo
 * («k», «k#1», «k#2»…). Così due righe uguali non fanno mai fermare l'app (Compose non ammette chiavi doppie).
 */
fun <T> uniqueKeys(items: List<T>, key: (T) -> Any?): List<String> {
    val seen = HashMap<String, Int>()
    return items.map { item ->
        val base = key(item).toString()
        val n = seen[base] ?: 0
        seen[base] = n + 1
        if (n == 0) base else "$base#$n"
    }
}

/**
 * Come `items(lista)`, ma ogni riga ha una chiave stabile: quando i dati si aggiornano Compose ridisegna solo le righe cambiate
 * e la posizione di scorrimento resta dov'è. Senza [key] la chiave è il contenuto della riga.
 */
fun <T> LazyListScope.keyedItems(
    items: Iterable<T>,
    key: (T) -> Any? = { it.hashCode() },
    content: @Composable LazyItemScope.(T) -> Unit,
) {
    val list = items.toList()
    val keys = uniqueKeys(list, key)
    itemsIndexed(list, key = { i, _ -> keys[i] }) { _, item -> content(this, item) }
}
