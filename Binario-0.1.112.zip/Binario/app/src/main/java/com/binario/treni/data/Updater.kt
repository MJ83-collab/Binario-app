package com.binario.treni.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Aggiornamenti dell'app. Ogni compilazione su GitHub pubblica l'APK firmato come "release" nel repository
 * pubblico [REPO] (il codice resta privato). All'avvio l'app legge l'ultima release e, se ha un numero di build
 * più alto di quello installato, propone di aggiornare: scarica l'APK e apre l'installazione di Android.
 * Android accetta l'aggiornamento solo se l'APK è firmato con la stessa chiave dell'app installata.
 */
object Updater {
    const val REPO = "MJ83-collab/Binario-app"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"
    const val PAGE = "https://github.com/$REPO/releases/latest"

    data class Release(val versionName: String, val versionCode: Long, val url: String, val size: Long, val notes: String)

    /** Nome dell'APK pubblicato: Binario-2.4-9.apk (versione e numero di build). */
    private val ASSET = Regex("""^Binario-(.+)-(\d+)\.apk$""")

    /** Legge la risposta di GitHub (logica pura, usata anche nei test). */
    fun parse(json: String): Release? {
        val o = JSONObject(json)
        if (o.optBoolean("draft") || o.optBoolean("prerelease")) return null
        val assets = o.optJSONArray("assets") ?: return null
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            val m = ASSET.find(a.optString("name")) ?: continue
            val url = a.optString("browser_download_url")
            if (!url.startsWith("https://")) continue
            return Release(m.groupValues[1], m.groupValues[2].toLong(), url, a.optLong("size"), notesOf(o))
        }
        return null
    }

    /**
     * Note della release. Senza note GitHub manda `"body": null` e su Android `optString` restituisce la parola «null»,
     * che finiva sotto «Novità» (9/11/2026, 0.1.108): note vuote o «null» diventano testo vuoto e la sezione non compare.
     */
    fun notesOf(o: JSONObject): String {
        if (!o.has("body") || o.isNull("body")) return ""
        val t = o.optString("body").trim()
        return if (t == "null") "" else t
    }

    /**
     * Motivo del download non riuscito, in parole semplici (logica pura, provata nei test): prima l'app diceva sempre
     * «Controlla la connessione», anche quando la connessione c'era.
     */
    fun failureReason(e: Throwable): String {
        val m = e.message.orEmpty()
        return when {
            m.contains("Spazio") || m.contains("free space") -> m
            e is java.net.SocketTimeoutException -> I18n.tr("Il download si è fermato: GitHub non risponde da troppo tempo. Riprova.", "The download stopped: GitHub has not responded for too long. Try again.")
            e is java.net.UnknownHostException -> I18n.tr("GitHub non è raggiungibile: controlla la connessione e riprova.", "GitHub cannot be reached: check your connection and try again.")
            m.startsWith("HTTP ") -> I18n.tr("GitHub ha risposto con un errore", "GitHub replied with an error") + " (" + m.removePrefix("HTTP ").trim() + "). " +
                I18n.tr("Riprova più tardi o scarica dalla pagina di download.", "Try again later or download from the download page.")
            m == "Download incompleto" || m == "Incomplete download" -> I18n.tr("Il download si è interrotto a metà. Riprova.", "The download was interrupted halfway. Try again.")
            else -> I18n.tr("Download non riuscito", "Download failed") + (if (m.isNotBlank()) " ($m)" else "") + ". " +
                I18n.tr("Riprova o scarica dalla pagina di download.", "Try again or download from the download page.")
        }
    }

    /** Vero per gli errori che conviene riprovare da soli (rete lenta o interrotta), falso per spazio pieno o file non sicuro. */
    fun retriable(e: Throwable): Boolean {
        val m = e.message.orEmpty()
        if (m.contains("Spazio") || m.contains("free space") || m.contains("non sicuro")) return false
        if (m.startsWith("HTTP 4")) return false
        return e is IOException
    }

    fun installedCode(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (e: Exception) {
        Long.MAX_VALUE
    }

    /** La release più recente, se è più nuova di quella installata; altrimenti null (anche senza rete). */
    fun check(ctx: Context): Release? = checkReached(ctx).first

    /**
     * Come [check], ma dice anche se GitHub ha risposto: (release più nuova o null, true se il controllo è riuscito).
     * Serve al pulsante "Cerca aggiornamenti" per distinguere "sei già aggiornato" da "non c'è connessione".
     */
    fun checkReached(ctx: Context): Pair<Release?, Boolean> {
        val api = checkApi(ctx)
        if (api.second) return api
        // L'API di GitHub senza token ha un limite di richieste per indirizzo (reti mobili condivise): si ripiega sulle pagine pubbliche
        return checkViaPages(ctx)
    }

    private fun connect(url: String, redirects: Boolean = true): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 10000
            instanceFollowRedirects = redirects
            setRequestProperty("User-Agent", "Binario-Android")
        }

    /** Alternativa all'API: la pagina "latest" rimanda al tag, e l'elenco dei file della release contiene il nome dell'APK con il numero di build. */
    private fun checkViaPages(ctx: Context): Pair<Release?, Boolean> = try {
        val c1 = connect("https://github.com/$REPO/releases/latest", false)
        val loc = try { if (c1.responseCode in 300..399) c1.getHeaderField("Location") else null } finally { c1.disconnect() }
        val tag = loc?.substringAfter("/releases/tag/", "")?.substringBefore('?')?.takeIf { it.isNotBlank() }
        if (tag == null) {
            null to false
        } else {
            val c2 = connect("https://github.com/$REPO/releases/expanded_assets/$tag")
            val html = try { if (c2.responseCode == 200) c2.inputStream.bufferedReader().use { it.readText() } else null } finally { c2.disconnect() }
            if (html == null) {
                null to false
            } else {
                val rel = Regex("""/releases/download/[^"'\s<>]+?\.apk""").findAll(html).mapNotNull { m ->
                    val name = m.value.substringAfterLast('/')
                    val a = ASSET.find(name) ?: return@mapNotNull null
                    Release(a.groupValues[1], a.groupValues[2].toLong(), "https://github.com/$REPO" + m.value, 0L, "")
                }.firstOrNull()
                rel?.takeIf { it.versionCode > installedCode(ctx) } to true
            }
        }
    } catch (e: Exception) {
        null to false
    }

    private fun checkApi(ctx: Context): Pair<Release?, Boolean> = try {
        val c = (URL(API).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 10000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "Binario-Android")
        }
        try {
            if (c.responseCode != 200) null to false
            else parse(c.inputStream.bufferedReader().use { it.readText() })?.takeIf { it.versionCode > installedCode(ctx) } to true
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null to false
    }

    /**
     * Scarica l'APK nella memoria dell'app, con l'avanzamento da 0 a 1. Su rete mobile il download si può interrompere:
     * fino a 3 tentativi, a pochi secondi di distanza, prima di mostrare l'errore.
     */
    fun download(ctx: Context, r: Release, progress: (Float) -> Unit): File {
        var last: Exception? = null
        for (attempt in 1..3) {
            try {
                return downloadOnce(ctx, r, progress)
            } catch (e: Exception) {
                last = e
                if (!retriable(e) || attempt == 3) break
                progress(0f)
                Thread.sleep(2000L * attempt)
            }
        }
        throw last ?: IOException("Download non riuscito")
    }

    private fun downloadOnce(ctx: Context, r: Release, progress: (Float) -> Unit): File {
        val dir = File(ctx.filesDir, "updates").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, "Binario-${r.versionName}-${r.versionCode}.apk")
        // Si scrive in un file provvisorio: un download interrotto non lascia mai un APK a metà
        val part = File(dir, out.name + ".part")
        if (r.size > 0 && dir.usableSpace < r.size * 2) throw IOException(I18n.tr("Spazio insufficiente sul telefono", "Not enough free space on the phone"))
        var url = r.url
        var conn: HttpURLConnection
        var hops = 0
        // GitHub reindirizza il download verso il proprio server dei file
        while (true) {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000; readTimeout = 60000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "Binario-Android")
            }
            val code = conn.responseCode
            if (code in 300..399 && hops < 5) {
                val next = conn.getHeaderField("Location") ?: throw IOException("Download non riuscito")
                conn.disconnect()
                if (!next.startsWith("https://")) throw IOException("Download non sicuro")
                url = next; hops++
                continue
            }
            if (code !in 200..299) throw IOException("HTTP $code")
            break
        }
        try {
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: r.size
            conn.inputStream.use { input ->
                part.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) progress((done.toFloat() / total).coerceIn(0f, 1f))
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
        if (r.size > 0 && part.length() != r.size) {
            part.delete()
            throw IOException(I18n.tr("Download incompleto", "Incomplete download"))
        }
        if (!part.renameTo(out)) { part.delete(); throw IOException(I18n.tr("Download non riuscito", "Download failed")) }
        return out
    }

    enum class ApkCheck { OK, UNREADABLE, OTHER_APP, NOT_NEWER, OTHER_KEY }

    /** Vero se le due firme sono la stessa; se una delle due non si può leggere non si blocca nulla. */
    fun sameSigners(installed: Set<String>, downloaded: Set<String>): Boolean =
        installed.isEmpty() || downloaded.isEmpty() || installed == downloaded

    private fun signers(info: android.content.pm.PackageInfo?): Set<String> {
        if (info == null) return emptySet()
        val sigs: Array<android.content.pm.Signature>? = if (Build.VERSION.SDK_INT >= 28) info.signingInfo?.apkContentsSigners
        else @Suppress("DEPRECATION") info.signatures
        return sigs.orEmpty().map { sg ->
            java.security.MessageDigest.getInstance("SHA-256").digest(sg.toByteArray()).joinToString("") { "%02x".format(it) }
        }.toSet()
    }

    /**
     * Prima di aprire l'installazione di Android controlla il file scaricato: è Binario, è più nuovo e ha la stessa firma di
     * quello installato. Se la firma è diversa Android risponde solo «App non installata», senza dire perché.
     */
    fun verify(ctx: Context, apk: File): ApkCheck {
        val pm = ctx.packageManager
        val flags = if (Build.VERSION.SDK_INT >= 28) android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES
        else @Suppress("DEPRECATION") android.content.pm.PackageManager.GET_SIGNATURES
        val down = try { pm.getPackageArchiveInfo(apk.absolutePath, flags) } catch (e: Exception) { null } ?: return ApkCheck.UNREADABLE
        if (down.packageName != ctx.packageName) return ApkCheck.OTHER_APP
        if (PackageInfoCompat.getLongVersionCode(down) <= installedCode(ctx)) return ApkCheck.NOT_NEWER
        val mine = try { pm.getPackageInfo(ctx.packageName, flags) } catch (e: Exception) { null }
        return if (sameSigners(signers(mine), signers(down))) ApkCheck.OK else ApkCheck.OTHER_KEY
    }

    fun openDownloadPage(ctx: Context) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PAGE)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }

    /** Android 8+: l'utente deve consentire a Binario di installare app (una volta sola). */
    fun canInstall(ctx: Context): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ctx.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    fun install(ctx: Context, apk: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}
