package com.binario.treni.data

/**
 * Traduzione cinese (semplificato) dell'interfaccia. Le chiavi sono i testi inglesi (EN e tr(it, en)), così una sola
 * tabella copre entrambi i sistemi; PAIRS risolve le poche parole inglesi ambigue (iniziali dei giorni, "Notes").
 * I testi senza traduzione restano in inglese. Divisa in più funzioni per non superare i limiti del bytecode.
 */
object Zh {
    private const val SEP = "\u0001"
    private val PAIRS: Map<String, String> = mapOf(
        "M" + SEP + "T" to "二",
        "G" + SEP + "T" to "四",
        "S" + SEP + "S" to "六",
        "D" + SEP + "S" to "日",
        "L" + SEP + "M" to "一",
        "M" + SEP + "W" to "三",
        "V" + SEP + "F" to "五",
        "Banconote" + SEP + "Notes" to "纸币",
    )
    private val MAP: HashMap<String, String> by lazy { HashMap<String, String>(2400).also { m -> m.putAll(mapOf("Price with a change: check sbb.ch or Trainline" to "换乘票价：请在 sbb.ch 或 Trainline 核实", "SBB fare (single ticket, adult)" to "SBB 票价（单程，成人）", "Read on sbb.ch on" to "读取自 sbb.ch，日期：", "Open on sbb.ch" to "在 sbb.ch 打开", "2nd class" to "二等座", "Where there is no 1st class (e.g. many regional trains) the 2nd class price is shown." to "没有一等座的列车（如许多地区列车）显示二等座价格。", "App updates" to "应用更新", "Only strikes on my route" to "仅限我的路线的罢工", "at my times" to "在我的时间段", "change it in News › My route and times" to "可在 新闻 › 我的路线和时间 中更改", "No route chosen: set your route in News › My route and times. Meanwhile you get national strikes and those in your region." to "尚未选择路线：请在 新闻 › 我的路线和时间 中设置。在此之前，你会收到全国性及你所在地区的罢工通知。", "1st and 2nd class" to "一等座和二等座", "Accessible to people with disabilities or reduced mobility" to "适合残障人士或行动不便者", "Add shortcut" to "添加快捷按钮", "Replacement buses" to "替代巴士", "Defibrillators" to "除颤器", "Remove shortcut" to "删除快捷按钮", "Remove the shortcut?" to "删除此快捷按钮？", "Done" to "完成", "The official app to call 112 sending your exact location." to "拨打 112 并发送你精确位置的官方应用。", "No shortcuts: tap + to add the features you use most." to "没有快捷按钮：点按 + 添加你最常用的功能。", "This route" to "此路线", "This shortcut already exists" to "此快捷按钮已存在", "AREU Lombardy website" to "AREU 伦巴第网站", "2nd class only" to "仅二等座", "A station's departure board" to "某车站的时刻表", "Shortcuts" to "快捷按钮", "Tap the shortcut to remove." to "点按要删除的快捷按钮。", "Bikes allowed" to "可携带自行车", "A specific train (by number)" to "指定列车（按车次）", "Do you really want to remove it? You can add it again with +." to "确定要删除吗？之后可以用 + 重新添加。", "Station toilets" to "车站厕所", "not available" to "不可用", "1st class" to "一等座")); p0(m); p1(m); p2(m); p3(m); p4(m); p5(m); p6(m); p7(m); p8(m); p9(m); p10(m); p11(m); p12(m); p13(m); p14(m); mapOf("SBB services at the station" to "车站内的 SBB 服务", "SBB services not reachable right now." to "目前无法获取 SBB 服务信息。", "Tap to retry" to "点按重试", "Reading services from the SBB website…" to "正在从 SBB 网站读取服务…", "Hide shops and food" to "隐藏商店和餐饮", "Shops and food" to "商店和餐饮", "open" to "营业中", "Open" to "营业中", "Closed" to "已关闭", "Open/closed and hours: SBB website, refreshed every 5 minutes. All data without guarantee." to "营业状态和时间：来自 SBB 网站，每 5 分钟更新。所有信息不作保证。", "Station page on sbb.ch" to "sbb.ch 上的车站页面").forEach { (k, v) -> m.putIfAbsent(k, v) }; mapOf("No region chosen" to "未选择地区", "Notices and strikes in: " to "以下地区的通告和罢工：", " (and with no region given)" to "（及未标明地区的）", "Change" to "更改", "Show only notices and strikes that affect these regions (plus national ones). You can pick more than one." to "只显示影响这些地区的通告和罢工（以及全国性的）。可以选择多个。", "Reset" to "重置").forEach { (k, v) -> m.putIfAbsent(k, v) } } }

    /** Frasi con valori variabili: modello inglese con {0}, {1}… e il corrispondente cinese. */
    private val TEMPLATES: List<Pair<String, String>> = listOf(
        "No out-of-service elevators or escalators reported at {0} (FerrovieNord/RFI). The station screen lists lifts per platform." to "{0} 没有报告停用的电梯或自动扶梯（FerrovieNord/RFI）。车站页面按站台列出电梯。",
        "Binario · scheduled times from Trenitalia/LeFrecce, generated on {0}. Check delays and changes before travelling." to "Binario · Trenitalia/LeFrecce 计划时刻，生成于 {0}。出行前请查看延误和变更。",
        "I can't find train {0} today. Check the number (it's on your ticket or the board) or search by station." to "今天找不到列车 {0}。请检查车次（在车票或时刻牌上），或按车站搜索。",
        "Band estimated from distance (about {0} km): check at the ticket office or in the Trenord app" to "根据距离估算的价格区间（约 {0} 公里）：请在售票处或 Trenord 应用中核实",
        "By car it would take about {0} minutes less each way, but you couldn't use the travel time." to "开车单程约少用 {0} 分钟，但您无法利用路上的时间。",
        "By train you save about {0} minutes each way at rush hour (and you can read or work)." to "乘火车高峰时段单程约节省 {0} 分钟（还可以阅读或工作）。",
        "Stops from {0} to the terminus · official Swiss timetable (transport.opendata.ch)" to "从 {0} 到终点站的停靠站 · 瑞士官方时刻表（transport.opendata.ch）",
        "Which station do you leave from? Say for example \"from Varese to {0}\"." to "您从哪个车站出发？例如说 \"从 Varese 到 {0}\"。",
        "I can't find bus, metro, tram or taxi stops mapped within 400 m of {0}." to "在 {0} 400 米范围内找不到已标注的巴士、地铁、有轨电车或出租车站点。",
        "You board at {0}. Where do you get off? I'll warn you before the stop." to "您在 {0} 上车。在哪里下车？我会在到站前提醒您。",
        "You have already sent {0} messages today: try again tomorrow. Thanks!" to "您今天已经发送了 {0} 条消息：请明天再试。谢谢！",
        "No connection: timetable downloaded at {0} on {1}. Delays not updated." to "无网络：时刻表下载于 {1} {0}。延误未更新。",
        "Platform change at {0}: train {1} now uses platform {2} instead of {3}." to "{0} 站台变更：列车 {1} 现在使用 {2} 站台，而不是 {3}。",
        "The nearest station is {0} ({1}). Here are the next departures:" to "最近的车站是 {0}（{1}）。以下是接下来的出发班次：",
        "In about {0} minutes you arrive at {1}. Start getting ready." to "大约 {0} 分钟后到达 {1}。请开始准备。",
        "You are already following {0}. Here is how it's going:" to "您已在跟踪 {0}。目前情况如下：",
        "The {0} board isn't responding. Try again shortly." to "{0} 的时刻牌无响应。请稍后重试。",
        "Platform change: leaves from {0} instead of {1}." to "站台变更：从 {0} 站台出发，而不是 {1}。",
        "Transitous · official {0} timetable (GTFS)" to "Transitous · {0} 官方时刻表（GTFS）",
        "I see no departures from {0} at that time." to "该时间段 {0} 没有出发班次。",
        "Transport data not reachable now for {0}." to "暂时无法获取 {0} 的交通数据。",
        "≈ the CO₂ absorbed in a year by {0} trees" to "≈ {0} 棵树一年吸收的 CO₂",
        "{0} is not installed: choose another app" to "未安装 {0}：请选择其他应用",
        "Expected delay: {0} minutes, leaves at " to "预计晚点：{0} 分钟，出发时间 ",
        "I found {0} trains: which one is yours?" to "我找到了 {0} 趟列车：哪一趟是您的？",
        ", and shortly before {0} with the alarm" to "，并在到达 {0} 前不久用闹钟提醒",
        "Departure: {0} — now choose the arrival" to "出发站：{0} — 现在请选择到达站",
        "Message too long (max {0} characters)." to "消息太长（最多 {0} 个字符）。",
        "No connections found from {0} to {1}." to "未找到从 {0} 到 {1} 的班次。",
        "Great, I'm following {0} for you. " to "好的，我为您跟踪 {0}。",
        "No disruptions reported for: {0}." to "以下没有报告中断：{0}。",
        "Warning: train {0} is cancelled." to "注意：列车 {0} 已停运。",
        "Train {0} is now {1} minutes late." to "列车 {0} 现在晚点 {1} 分钟。",
        "I can't find train {0} today." to "今天找不到列车 {0}。",
        "Board not available for {0}." to "{0} 的时刻牌不可用。",
        " I will warn you before {0}." to " 我会在 {0} 之前提醒您。",
        "Does this train stop at {0}?" to "这趟列车停靠 {0} 吗？",
        "So far in {0} ({1} days logged)" to "{0} 年至今（已记录 {1} 天）",
        "What time do you leave {0}?" to "您几点从 {0} 出发？",
        "In a year ({0} travel days)" to "一年内（{0} 个出行日）",
        "Italo real-time data ({0})" to "Italo 实时数据（{0}）",
        "You get off at {0} around " to "您大约在 {0} 下车，时间 ",
        ", expected delay {0} min." to "，预计晚点 {0} 分钟。",
        "Out of service at {0}:\n" to "{0} 停用中：\n",
        "Platform confirmed: {0}." to "站台已确认：{0}。",
        "Data from {0} (offline)" to "数据时间 {0}（离线）",
        "Running {0} min early." to "提前 {0} 分钟运行。",
        "Running {0} min late." to "晚点 {0} 分钟运行。",
        "Next trains {0} → {1}:\n" to "下一班列车 {0} → {1}：\n",
        "Board at {0}: due at {1}" to "在 {0} 上车：预计 {1}",
        "Departures from {0}:" to "{0} 出发：",
        "Departs from {0} at {1}" to "从 {0} 出发，时间 {1}",
        "Outbound: {0} runs…" to "去程：{0} 个班次…",
        ", {0} minutes late." to "，晚点 {0} 分钟。",
        "Train {0} not found" to "未找到列车 {0}",
        "Train {0} not found" to "未找到列车 {0}",
        " (contactless {0})" to " （非接触支付 {0}）",
        " from platform {0}" to " 从 {0} 站台",
        "Return: {0} runs…" to "返程：{0} 个班次…",
        "{0} minutes late." to "晚点 {0} 分钟。",
        "Alarm set for {0}" to "已为 {0} 设置闹钟",
        "Services at {0}:" to "{0} 的服务：",
        "Departs from {0}" to "从 {0} 出发",
        "Arrivals at {0}:" to "{0} 到达：",
        "Board at {0} at {1}" to "在 {0} 上车，时间 {1}",
        "Days logged: {0}" to "已记录天数：{0}",
        " {0} min late." to " 晚点 {0} 分钟。",
        "Arrived at {0}" to "已到达 {0}",
        ", platform {0}" to "，站台 {0}",
        ", platform {0}" to "，站台 {0}",
        "Next stop: {0}" to "下一站：{0}",
        "{0} min early" to "提前 {0} 分钟",
        "Next stop {0}" to "下一站 {0}",
        "{0} o'clock, {1}" to "{0} 点钟方向，{1}",
        "{0} min late" to "晚点 {0} 分钟",
        "Near {0}:" to "{0} 附近：",
        ", at {0}." to "，{0} 到达。",
        "Train {0}" to "列车 {0}",
        " at {0}" to " 于 {0}",
    )
    private val compiled: List<Pair<Regex, String>> by lazy {
        TEMPLATES.map { (en, zh) ->
            val parts = en.split(Regex("\\{\\d\\}"))
            Regex("^" + parts.joinToString("(.+?)") { Regex.escape(it) } + "$", RegexOption.DOT_MATCHES_ALL) to zh
        }
    }
    private val cache = java.util.Collections.synchronizedMap(object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 300
    })

    private fun fromTemplate(en: String): String? {
        cache[en]?.let { return it.ifEmpty { null } }
        for ((re, zh) in compiled) {
            val m = re.matchEntire(en) ?: continue
            var z = zh
            // I segnaposto inglesi sono in ordine {0}, {1}…; il cinese può usarli in un altro ordine
            for (g in 1 until m.groupValues.size) z = z.replace("{${g - 1}}", m.groupValues[g])
            cache[en] = z
            return z
        }
        cache[en] = ""
        return null
    }

    /** Testo cinese per la coppia italiano/inglese; se manca, l'inglese. */
    fun of(it: String, en: String): String = PAIRS[it + SEP + en] ?: MAP[en] ?: (if (en.length in 4..400) fromTemplate(en) else null) ?: en

    fun has(en: String) = MAP.containsKey(en)

    private fun p0(m: HashMap<String, String>) {
        m[" early"] = " 提前"
        m[" late"] = " 晚点"
        m[" · contactless"] = " · 非接触支付"
        m["1 hour before"] = "提前1小时"
        m["Cross-border passes"] = "跨境月票"
        m["Accessibility"] = "无障碍"
        m["Buy"] = "购买"
        m["Now"] = "现在"
        m["Crowding"] = "拥挤程度"
        m["Refresh"] = "刷新"
        m["Add"] = "添加"
        m["Add a line, e.g. S5 Varese – Treviglio, to see the next trains in both directions."] = "添加一条线路，例如 S5 Varese – Treviglio，即可查看两个方向的下一班列车。"
        m["Help & FAQ"] = "帮助与常见问题"
        m["Alarm when the train leaves the previous stop"] = "列车离开上一站时提醒"
        m["Alarms"] = "闹钟"
        m["NTV high speed"] = "NTV 高铁"
        m["More"] = "更多"
        m["Outbound"] = "去程"
        m["Round trip"] = "往返"
        m["Cancel"] = "取消"
        m["Open in browser"] = "在浏览器中打开"
        m["Open keyboard when choosing a station"] = "选择车站时打开键盘"
        m["Open a departure board and tap ★ to save the station."] = "打开一个车站时刻牌，点击 ★ 收藏该车站。"
        m["Open a train and tap ★ to add it here."] = "打开一趟列车，点击 ★ 添加到这里。"
        m["Arcobaleno (Swiss section) + Trenord (Lombardy section): check the price when buying"] = "Arcobaleno（瑞士段）+ Trenord（伦巴第段）：购票时请核对价格"
        m["Trenitalia personal area"] = "Trenitalia 个人中心"
        m["Arrived on time"] = "准点到达"
        m["Arrivals"] = "到达"
        m["Arrivals at "] = "到达 "
        m["Arrival"] = "到达"
        m["Out-of-service elevators and escalators"] = "停用的电梯和自动扶梯"
        m["Assistance"] = "协助"
        m["Notify me"] = "提醒我"
        m["Notify me 10 minutes before arriving here"] = "到达此站前10分钟提醒我"
        m["Notices"] = "通知"
        m["Disruption alerts on favourite routes, lines and trains"] = "常用线路、路线和列车的中断提醒"
        m["Alerts for deaf or hard-of-hearing people"] = "为听障人士提供的提醒"
        m["Backup saved"] = "备份已保存"
        m["Bikes and light mobility"] = "自行车和轻型交通工具"
        m["Ticket offices, machines, validators, contactless"] = "售票处、售票机、验票机、非接触支付"
        m["Tickets"] = "车票"
        m["Tickets, passes and QR codes"] = "车票、月票和二维码"
        m["Ticket"] = "车票"
        m["Regional ticket"] = "区域车票"
        m["Cross-border ticket"] = "跨境车票"
        m["Platforms: elevators and ramps"] = "站台：电梯和坡道"
        m["Platform"] = "站台"
        m["Calendar"] = "日历"
        m["Strike calendar (Ministry)"] = "罢工日历（交通部）"
        m["Change a Trenitalia booking"] = "修改 Trenitalia 订单"
        m["Terminus A"] = "终点站 A"
        m["Terminus A (e.g. Varese)"] = "终点站 A（例如 Varese）"
        m["Terminus B"] = "终点站 B"
        m["Terminus B (e.g. Treviglio)"] = "终点站 B（例如 Treviglio）"
        m["Loading station list (first time only)…"] = "正在加载车站列表（仅首次）…"
        m["Loading…"] = "加载中…"
        m["Search"] = "搜索"
        m["Search timetable"] = "查询时刻表"
        m["Search & Buy"] = "搜索与购买"
        m["Search a station"] = "搜索车站"
        m["Search a station for the departure board"] = "搜索车站以查看时刻牌"
        m["Search within 2 km"] = "在2公里内搜索"
        m["Close"] = "关闭"
        m["Traffic"] = "运行情况"
        m["Connection very much at risk"] = "换乘风险很高"
        m["Tight connection"] = "换乘时间紧张"
        m["How it works"] = "使用说明"
        m["Same as system"] = "跟随系统"
        m["Operator announcements"] = "运营方公告"
        m["With delays of at least 60 minutes you are entitled to assistance: meals and refreshments in relation to the waiting time and, if needed, accommodation."] = "延误至少60分钟时，您有权获得协助：根据等待时间提供餐饮，必要时提供住宿。"
        m["Share"] = "分享"
        m["Share timetable"] = "分享时刻表"
        m["Malpensa Express conditions"] = "Malpensa Express 运输条款"
        m["Trenitalia conditions"] = "Trenitalia 运输条款"
        m["Trenord conditions"] = "Trenord 运输条款"
        m["Conditions of carriage"] = "运输条款"
        m["Conditions of carriage and rights"] = "运输条款与乘客权利"
        m["Conditions of carriage, tickets, bikes, pets, fines"] = "运输条款、车票、自行车、宠物、罚款"
        m["General conditions of carriage (regional and long distance)"] = "一般运输条款（区域和长途）"
        m["Specific conditions for the airport link"] = "机场线专项条款"
        m["Compare"] = "比较"
        m["Compare routes"] = "比较路线"
        m["Contacts"] = "联系方式"
        m["Always check the updated document before travelling."] = "出行前请务必查看最新文件。"
        m["Station coordinates not available"] = "车站坐标不可用"
        m["Stop coordinates not available"] = "停靠站坐标不可用"
        m["From mobiles +39 02 32 32 32 · 6:45–21:30"] = "手机拨打 +39 02 32 32 32 · 6:45–21:30"
        m["Data imported"] = "数据已导入"
        m["Direct"] = "直达"
        m["Rail passengers' rights and obligations (PDF)"] = "铁路乘客的权利与义务（PDF）"
        m["Disable maps"] = "关闭地图"
        m["Official documents"] = "官方文件"
        m["After a search, tap the download icon to save the timetable."] = "搜索后，点击下载图标保存时刻表。"
        m["During regional rail strikes, trains are normally guaranteed between 6:00–9:00 and 18:00–21:00, "] = "区域铁路罢工期间，工作日 6:00–9:00 和 18:00–21:00 的列车通常有保障，"
        m["Updated official lists"] = "最新官方列表"
        m["List"] = "列表"
        m["Full FerrovieNord list"] = "FerrovieNord 完整列表"
        m["Station list not available"] = "车站列表不可用"
        m["Delete"] = "删除"
        m["Ticket machines, validators, tobacconists, contactless payment"] = "售票机、验票机、烟草店、非接触支付"
        m["Network error"] = "网络错误"
        m["Error while saving"] = "保存时出错"
        m["e.g. Varese → Como via Mendrisio or via Milan"] = "例如 Varese → Como 经 Mendrisio 或经米兰"
        m["e.g. Varese → Como: via Mendrisio (TILO) or via Milan. Duration, changes, cost and feasibility."] = "例如 Varese → Como：经 Mendrisio（TILO）或经米兰。时长、换乘、费用和可行性。"
        m["Exclude categories"] = "排除类别"
        m["Export data"] = "导出数据"
        m["Feasible"] = "可行"
        m["Invalid file"] = "文件无效"
        m["Source: OpenStreetMap. Tobacconists and newsagents often sell regional tickets, but not always: "] = "来源：OpenStreetMap。烟草店和报亭常售区域车票，但并非总是："
        m["Frecce, Intercity and Regional"] = "Frecce、Intercity 和区域列车"
        m["General"] = "通用"
        m["My tickets"] = "我的车票"
        m["My Italo trips"] = "我的 Italo 行程"
        m["On-board services (bikes, wheelchair spaces, classes) are not published in real-time data. "] = "车上服务（自行车、轮椅位、车厢等级）不在实时数据中公布。"
        m["Your rights in brief (EU 2021/782)"] = "您的权利简述（EU 2021/782）"
        m["The price via Milan is the Trenitalia/Trenord fare; the cross-border price is indicative: check at the ticket office or in the Trenord/SBB app."] = "经米兰的价格为 Trenitalia/Trenord 票价；跨境价格仅供参考：请在售票处或 Trenord/SBB 应用中核实。"
        m["Import data"] = "导入数据"
        m["Unable to load train data"] = "无法加载列车数据"
        m["Settings"] = "设置"
        m["Set"] = "设定"
        m["On time"] = "准点"
        m["Delay compensation: 25% of the ticket price for 60–119 minutes, 50% from 120 minutes. Operators may not pay amounts below €4."] = "延误赔偿：延误60–119分钟赔偿票价的25%，120分钟起赔偿50%。运营方可不支付低于4欧元的金额。"
        m["Back"] = "返回"
        m["Info"] = "信息"
        m["RFI accessibility info"] = "RFI 无障碍信息"
        m["Customer information and lost property"] = "乘客信息与失物招领"
        m["Information and bookings (replies on weekdays)"] = "信息与预约（工作日回复）"
        m["Swap"] = "交换"
        m["Italo · assistance"] = "Italo · 协助"
        m["Italo · news"] = "Italo · 新闻"
        m["Purchases are made on the operator's official website: in-app purchase and synchronisation "] = "购票在运营方官网完成：应用内购票和同步 "
        m["Delay compensation may not be due in cases of force majeure (e.g. extreme weather, natural disasters, major public health crises)."] = "不可抗力情况下（如极端天气、自然灾害、重大公共卫生危机）可能不予延误赔偿。"
        m["Flash blinking for alerts"] = "提醒时闪光"
        m["Works"] = "施工"
        m["National and regional conditions may set different rules for passes and regional trains."] = "各国家和地区的条款可能对月票和区域列车有不同规定。"
        m["Legal"] = "法律信息"
        m["Lines"] = "线路"
        m["Favourite lines"] = "常用线路"
        m["Lines, cross-border fares, services"] = "线路、跨境票价、服务"
        m["Map"] = "地图"
        m["FerrovieNord maintenance map"] = "FerrovieNord 维修地图"
        m["Max changes"] = "最多换乘次数"
        m["Monthly and annual"] = "月票和年票"
        m["Change date, time or class"] = "更改日期、时间或车厢等级"
        m["Show Buy button"] = "显示“购买”按钮"
        m["Show later connections"] = "显示稍后的换乘"
        m["Later connections"] = "稍后的换乘"
        m["No elevators mapped for this station."] = "此车站未标注电梯。"
        m["No notices"] = "暂无通知"
        m["No browser available"] = "没有可用的浏览器"
        m["No list published at the moment."] = "目前没有公布列表。"
        m["No routes found for this time. Try later or another day (some lines do not run on Sundays)."] = "此时间段未找到线路。请稍后或换一天再试（部分线路周日停运）。"
        m["No direct trains found in this direction"] = "此方向未找到直达列车"
        m["No trains in the next hours"] = "未来几小时内没有列车"
        m["No traffic disruptions reported"] = "未报告运行中断"
        m["No calendar app found"] = "未找到日历应用"
        m["No email app"] = "没有电子邮件应用"
        m["No notifications. Use \"Notify me\" on a train or a connection."] = "暂无通知。可在列车或换乘方案上使用“提醒我”。"
        m["No connections"] = "无换乘方案"
        m["No station found"] = "未找到车站"
        m["No rail strikes announced"] = "未宣布铁路罢工"
        m["Nothing to save"] = "没有可保存的内容"
        m["Not departed yet"] = "尚未出发"
        m["Not available at this time"] = "当前不可用"
        m["Persistent notification on"] = "常驻通知已开启"
        m["Persistent notification enabled"] = "常驻通知已启用"
        m["Scheduled notification"] = "定时通知"
        m["Strike notifications"] = "罢工通知"
        m["Notifications"] = "通知"
        m["Scheduled notifications"] = "定时通知"
        m["Scheduled notifications and wake-up alarms"] = "定时通知和到站闹钟"
        m["News"] = "新闻"
        m["Name (e.g. S5, RE2)"] = "名称（例如 S5、RE2）"
        m["New favourite line"] = "新的常用线路"
        m["Train number"] = "车次"
        m["Station name"] = "车站名称"
        m["Advanced options"] = "高级选项"
        m["Times and changes: official Swiss timetable (transport.opendata.ch) and Trenitalia/LeFrecce. "] = "时刻与换乘：瑞士官方时刻表（transport.opendata.ch）和 Trenitalia/LeFrecce。"
        m["Offline timetables"] = "离线时刻表"
        m["Timetable saved for offline use"] = "时刻表已保存供离线使用"
        m["Time already passed"] = "时间已过"
        m["Strike observatory unreachable right now"] = "罢工观察站暂时无法访问"
        m["Official pages"] = "官方页面"
        m["Departure"] = "出发"
        m["Origin and destination are the same"] = "出发地和目的地相同"
        m["Departures"] = "出发"
        m["Departures from "] = "出发自 "
        m["Departures and arrivals from here"] = "从这里出发和到达的列车"
        m["Step-free routes, 55 cm platforms"] = "无台阶路线，55厘米站台"
        m["People with disabilities or reduced mobility: free assistance in stations and on board, normally to be requested at least 24 hours in advance."] = "残障或行动不便人士：车站和车上提供免费协助，通常需至少提前24小时申请。"
        m["Arcobaleno zone map"] = "Arcobaleno 区域地图"
        m["Several runs with this number"] = "此车次有多趟"
        m["Location & Maps"] = "位置与地图"
        m["Location not available. Turn on GPS and try again."] = "位置不可用。请打开GPS后重试。"
        m["Location not available: open the map first or turn on GPS."] = "位置不可用：请先打开地图或开启GPS。"
        m["Favourite"] = "收藏"
        m["Favourites"] = "收藏"
        m["Trenitalia/Trenord fare"] = "Trenitalia/Trenord 票价"
        m["Trenitalia/Trenord fare (1 adult)"] = "Trenitalia/Trenord 票价（1名成人）"
        m["Before arrival"] = "到达前"
        m["Before departure"] = "出发前"
        m["Privacy & permissions"] = "隐私与权限"
        m["You can check them in the operator's official timetable."] = "您可以在运营方的官方时刻表中查看。"
        m["Recent"] = "最近"
        m["Recent & favourites"] = "最近与收藏"
        m["Complaints: the operator must reply within one month (up to three months in justified cases)."] = "投诉：运营方须在一个月内答复（有正当理由时最长三个月）。"
        m["Lombardy regional trains and Malpensa Express"] = "伦巴第区域列车和 Malpensa Express"
        m["Finding your location…"] = "正在查找您的位置…"
        m["Refunds and complaints"] = "退款与投诉"
        m["Remove"] = "移除"
        m["Expected arrival delay of at least 60 minutes: you can choose a refund, continuation, or re-routing."] = "预计到达延误至少60分钟：您可选择退款、继续行程或改道。"
        m["Return"] = "返程"
        m["Ticket sellers"] = "售票点"
        m["Nearby ticket sellers and offices"] = "附近的售票点和售票处"
        m["Nearby ticket sellers"] = "附近的售票点"
        m["Save"] = "保存"
        m["Save offline"] = "离线保存"
        m["Saved offline"] = "已离线保存"
        m["Choose the run"] = "选择班次"
        m["Choose origin and destination"] = "选择出发地和目的地"
        m["Choose departure and arrival stations"] = "选择出发站和到达站"
        m["Start screen"] = "启动页面"
        m["Strikes"] = "罢工"
        m["Strikes, traffic and works"] = "罢工、运行情况和施工"
        m["Dark"] = "深色"
        m["If the operator offers no alternative within 100 minutes, you may arrange it yourself with other trains or buses and claim reasonable costs."] = "如果运营方在100分钟内未提供替代方案，您可自行安排其他列车或巴士，并申请报销合理费用。"
        m["Report problems between train and station"] = "报告列车与车站之间的问题"
        m["Follow"] = "跟踪"
        m["Following"] = "跟踪中"
        m["Location permission needed"] = "需要位置权限"
        m["Location permission is needed to find nearby stations."] = "需要位置权限才能查找附近车站。"
        m["Grant permission"] = "授予权限"
        m["TILO services"] = "TILO 服务"
        m["Services & accessibility"] = "服务与无障碍"
        m["Station services"] = "车站服务"
        m["Map service temporarily unreachable"] = "地图服务暂时无法访问"
        m["TILO Pigiama night service"] = "TILO Pigiama 夜间列车"
        m["Summary for information only: the official text of the regulation and each operator's conditions prevails. "] = "仅供参考的摘要：以法规官方文本和各运营方条款为准。"
        m["Connections"] = "换乘方案"
        m["Cancelled"] = "已停运"
        m["Station"] = "车站"
        m["Arrival station"] = "到达站"
        m["Departure station"] = "出发站"
        m["Stations"] = "车站"
        m["Favourite stations"] = "收藏的车站"
        m["Nearby stations"] = "附近车站"
        m["Nearby stations and map"] = "附近车站与地图"
        m["Wake me before this stop"] = "在此站前叫醒我"
        m["TILO · Ticino and Lombardy"] = "TILO · 提契诺与伦巴第"
        m["TILO · notices"] = "TILO · 通知"
        m["Full fare tables"] = "完整票价表"
        m["Departure board not available"] = "时刻牌不可用"
        m["Station board"] = "车站时刻牌"
        m["Lombardy regional fare: check the price"] = "伦巴第区域票价：请核对价格"
        m["Official Arcobaleno fare"] = "Arcobaleno 官方票价"
        m["Cross-border fares"] = "跨境票价"
        m["Theme"] = "主题"
        m["Leisure"] = "休闲"
        m["Type of connections"] = "换乘类型"
        m["Tickets and passes"] = "车票和月票"
        m["Tickets, bikes, assistance"] = "车票、自行车、协助"
        m["Tap again for the departure board"] = "再次点击查看时刻牌"
        m["Tap to open"] = "点击打开"
        m["Tap a category to exclude it (struck through) or include it."] = "点击类别可排除（划线）或包含。"
        m["Tap a stop for the board or the alarm."] = "点击停靠站查看时刻牌或设置闹钟。"
        m["Traffic, delays and strikes"] = "运行情况、延误和罢工"
        m["Route"] = "路线"
        m["Favourite and recent routes"] = "收藏和最近的路线"
        m["Trains"] = "列车"
        m["Guaranteed trains"] = "保障列车"
        m["Guaranteed trains during strikes"] = "罢工期间的保障列车"
        m["Guaranteed trains: updated official lists"] = "保障列车：最新官方列表"
        m["Favourite trains"] = "收藏的列车"
        m["Trenitalia · refunds and compensation"] = "Trenitalia · 退款与赔偿"
        m["Trenitalia · guaranteed trains"] = "Trenitalia · 保障列车"
        m["Trenitalia · travel information"] = "Trenitalia · 出行信息"
        m["Trenord · real-time traffic"] = "Trenord · 实时运行"
        m["Train"] = "列车"
        m["Train not found"] = "未找到列车"
        m["Followed train"] = "跟踪的列车"
        m["Train cancelled"] = "列车已停运"
        m["Trenord · notices"] = "Trenord · 通知"
        m["Trenord · notices and strikes"] = "Trenord · 通知与罢工"
        m["Trenord · refunds and compensation"] = "Trenord · 退款与赔偿"
        m["Trenord: assistance for people with disabilities"] = "Trenord：残障人士协助"
        m["All"] = "全部"
        m["Every day 8:15–19:45 · book at least 24 hours ahead"] = "每天 8:15–19:45 · 请至少提前24小时预约"
        m["Use your location"] = "使用您的位置"
        m["Light green"] = "浅绿色"
        m["App version"] = "应用版本"
        m["Via Mendrisio (TILO, cross-border)"] = "经 Mendrisio（TILO，跨境）"
        m["Via Milan (Italy only)"] = "经米兰（仅意大利境内）"
        m["Travellers with disabilities"] = "残障旅客"
        m["Strong vibration with a different pattern per alert: stop alarm (3 long, repeated), reminder (3 short ×2), disruptions (2 long)"] = "强烈振动，每种提醒模式不同：到站闹钟（3次长振，重复）、提醒（3次短振×2）、中断（2次长振）"
        m["Favourites widget"] = "收藏小组件"
        m["Station widget"] = "车站小组件"
        m["Route / Line widget"] = "路线/线路小组件"
        m["Train widget"] = "列车小组件"
        m["Arcobaleno zones"] = "Arcobaleno 区域"
        m["from "] = "从 "
    }

    private fun p1(m: HashMap<String, String>) {
        m["of tickets require a commercial agreement with Trenitalia, Italo and Trenord."] = "车票需要与 Trenitalia、Italo 和 Trenord 签订商业协议。"
        m["no changes (direct only)"] = "不换乘（仅直达）"
        m["no data"] = "无数据"
        m["not wheelchair accessible"] = "轮椅无法通行"
        m["not set"] = "未设置"
        m["plus the trains listed by the operators. For long-distance trains, each operator's published lists apply. "] = "以及运营方列出的列车。长途列车以各运营方公布的列表为准。"
        m["direct only"] = "仅直达"
        m["check on site. Contactless payment is shown only if mapped."] = "请现场核实。仅在已标注时显示非接触支付。"
        m["♿ accessible"] = "♿ 无障碍"
        m["♿ limited access"] = "♿ 部分无障碍"
        m["💳 cards"] = "💳 银行卡"
        m["📶 contactless"] = "📶 非接触支付"
        m["🛗 elevator"] = "🛗 电梯"
        m["RFI accessibility page"] = "RFI 无障碍页面"
        m["No out-of-service facilities reported for this station."] = "此车站未报告停用设施。"
        m["Checking FerrovieNord and RFI…"] = "正在查询 FerrovieNord 和 RFI…"
        m["OpenStreetMap data unreachable."] = "无法访问 OpenStreetMap 数据。"
        m["Source: OpenStreetMap (volunteer data, may be incomplete). Does not show today's faults."] = "来源：OpenStreetMap（志愿者数据，可能不完整）。不显示今日的故障。"
        m["FerrovieNord: station and elevator notices"] = "FerrovieNord：车站和电梯通知"
        m["Varese, Como, Novara, Brescia–Iseo–Edolo lines"] = "Varese、Como、Novara、Brescia–Iseo–Edolo 线"
        m["RFI Sala Blu assistance"] = "RFI Sala Blu 协助"
        m["Book help getting on and off"] = "预约上下车协助"
        m["Wheelchair access"] = "轮椅通行"
        m["Open official timetable"] = "打开官方时刻表"
        m["Sala Blu assistance (people with disabilities)"] = "Sala Blu 协助（残障人士）"
        m["Not available for this train."] = "此列车不可用。"
        m["Check on the Trenord website"] = "在 Trenord 网站上查看"
        m["Estimate provided by Trenord"] = "Trenord 提供的估算"
        m["Open announcement"] = "打开公告"
        m["Source: Strike Observatory – Italian Ministry of Transport"] = "来源：罢工观察站 – 意大利交通部"
        m["Strikes and travel info"] = "罢工与出行信息"
        m["No news"] = "暂无新闻"
        m["I took the train today"] = "我今天乘坐了火车"
        m["Latest news"] = "最新消息"
        m["Strike calendar"] = "罢工日历"
        m["Official list of the Ministry of Transport"] = "交通部官方列表"
        m["Trenitalia travel info"] = "Trenitalia 出行信息"
        m["Real-time traffic"] = "实时运行"
        m["Choose what to show"] = "选择要显示的内容"
        m["Real delays and platforms"] = "实际延误和站台"
        m["Best connections"] = "最佳方案"
        m["High speed"] = "高铁"
        m["Regional"] = "区域列车"
        m["All connections"] = "全部方案"
        m["Ticket office"] = "售票处"
        m["Self-service ticket machine"] = "自助售票机"
        m["Validator"] = "验票机"
        m["Authorised reseller"] = "授权代售点"
        m["Elevator"] = "电梯"
        m["Ramp"] = "坡道"
        m["Strike"] = "罢工"
        m["Works and changes"] = "施工与变更"
        m["Notice"] = "通知"
        m["How green are you"] = "你有多环保"
        m["Train assistant"] = "列车助手"
        m["How much CO₂, fuel, tolls and time you save"] = "您节省了多少二氧化碳、燃料、通行费和时间"
        m["Ask about trains, delays, strikes and traffic"] = "询问列车、延误、罢工和运行情况"
        m["Language"] = "语言"
        m["Legal notes"] = "法律说明"
        m["Colour-blind colours"] = "色盲配色"
        m["Off"] = "关闭"
        m["Red-green (protanopia, deuteranopia)"] = "红绿色盲（红色盲、绿色盲）"
        m["Blue-yellow (tritanopia)"] = "蓝黄色盲（蓝色盲）"
        m["version"] = "版本"
        m["Version"] = "版本"
        m["Before you start"] = "开始之前"
        m["Read the full legal notes"] = "阅读完整法律说明"
        m["I understand and accept"] = "我已了解并接受"
        m["Binario is an independent app, not affiliated with Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO or SBB. Data comes from public sources and may contain errors: station boards, announcements and official channels always prevail. Estimated crowding, costs and times are indicative. All sources are public, free and cited in the legal notes. The app is free, ad-free, does not sell tickets and does not collect personal data."] = "Binario 是一款独立应用，与 Trenitalia、RFI、Italo、Trenord、FerrovieNord、TILO 或 SBB 无关联。数据来自公开来源，可能有误：一律以车站时刻牌、广播和官方渠道为准。预估的拥挤程度、费用和时间仅供参考。所有来源均为公开、免费，并在法律说明中注明。本应用免费、无广告、不售票、不收集个人数据。"
        m["App created by Marco Jannino"] = "应用作者：Marco Jannino"
        m["Punctuality"] = "准点率"
        m["Monthly statistics by operator, station and train"] = "按运营方、车站和列车统计的月度数据"
        m["of seats taken"] = "座位已占用"
        m["Source"] = "来源"
        m["No official data: estimate by time of day (weekday rush hours, trains to/from Milan)."] = "无官方数据：按时段估算（工作日高峰、往返米兰的列车）。"
        m["Green: plenty of seats · Yellow: look for seats · Red: full, better wait for the next train"] = "绿色：座位充足 · 黄色：需要找座位 · 红色：已满，最好等下一班"
        m["Real-time crowding in the Trenord app"] = "在 Trenord 应用中查看实时拥挤程度"
        m["Scheduled"] = "计划"
        m["Actual"] = "实际"
        m["Scheduled platform"] = "计划站台"
        m["Actual platform"] = "实际站台"
        m["Switzerland"] = "瑞士"
        m["All lines"] = "全部线路"
        m["Extracting the line list from the Trenord website…"] = "正在从 Trenord 网站获取线路列表…"
        m["Trenord list not available right now."] = "Trenord 列表暂不可用。"
        m["Open lines on the Trenord website"] = "在 Trenord 网站上打开线路"
        m["FerrovieNord manages the infrastructure: trains on these lines are run by Trenord."] = "FerrovieNord 负责基础设施：这些线路上的列车由 Trenord 运营。"
        m["Line added to favourites"] = "线路已加入收藏"
        m["Choose the two termini"] = "选择两个终点站"
        m["SBB rail traffic information"] = "SBB 铁路运行信息"
        m["Real-time disruption map"] = "实时中断地图"
        m["TILO notices"] = "TILO 通知"
        m["TILO cross-border lines"] = "TILO 跨境线路"
        m["Line status, notices and stations"] = "线路状态、通知和车站"
        m["Official page"] = "官方页面"
        m["Trenord, TILO, FerrovieNord, Switzerland"] = "Trenord、TILO、FerrovieNord、瑞士"
        m["Refresh now"] = "立即刷新"
        m["Updated at"] = "更新于"
        m["refreshes every 5 minutes"] = "每5分钟刷新"
        m["Official websites"] = "官方网站"
        m["Trenitalia · travel news"] = "Trenitalia · 出行新闻"
        m["Open source"] = "打开来源"
        m["no date"] = "无日期"
        m["The full text is on the source website."] = "全文请见来源网站。"
        m["Hours"] = "时间"
        m["Who"] = "谁"
        m["Where"] = "地点"
        m["Sector"] = "行业"
        m["Unions"] = "工会"
        m["Notes"] = "备注"
        m["Station overview"] = "车站概况"
        m["Platforms"] = "站台"
        m["Platforms in use"] = "使用中的站台"
        m["from today's trains"] = "根据今日列车"
        m["not mapped"] = "未标注"
        m["Lifts"] = "电梯"
        m["none mapped"] = "未标注"
        m["escalators"] = "自动扶梯"
        m["ramps"] = "坡道"
        m["none / not mapped"] = "无 / 未标注"
        m["present"] = "有"
        m["Ticket machines"] = "售票机"
        m["Validators"] = "验票机"
        m["none within 500 m"] = "500米内没有"
        m["nearest at"] = "最近的在"
        m["Toilets"] = "卫生间"
        m["available"] = "可用"
        m["wheelchair accessible station"] = "轮椅可通行的车站"
        m["limited access"] = "部分无障碍"
        m["Lifts per platform"] = "各站台电梯"
        m["no lift mapped"] = "未标注电梯"
        m["ramp"] = "坡道"
        m["Loading station services…"] = "正在加载车站服务…"
        m["Retry"] = "重试"
        m["OpenStreetMap data unreachable right now."] = "暂时无法访问 OpenStreetMap 数据。"
        m["OpenStreetMap volunteer data: may be incomplete. Today's faults are in the box below."] = "OpenStreetMap 志愿者数据：可能不完整。今日故障见下方框内。"
        m["Italo · info and support"] = "Italo · 信息与支持"
        m["Your position"] = "您的位置"
        m["Voice assistant (microphone on at start)"] = "语音助手（启动时打开麦克风）"
        m["Followed train: alert on platform change or bigger delay"] = "跟踪的列车：站台变更或延误加大时提醒"
        m["Voice alerts for blind or visually impaired people"] = "为视障人士提供的语音提醒"
        m["The phone's voice tells you where to catch the train (platform), when it leaves, platform changes and delays, and warns you with an insistent sound when your stop is near."] = "手机语音会告诉您在哪里上车（站台）、何时出发、站台变更和延误，并在您的下车站临近时用持续的声音提醒您。"
        m["Voice alerts on. I will tell you the platform, the departure and the stop where to get off."] = "语音提醒已开启。我会告诉您站台、出发时间和下车站。"
        m["Announce every stop of the followed train"] = "播报跟踪列车的每个停靠站"
        m["Voice speed"] = "语速"
        m["Slow"] = "慢"
        m["Normal"] = "正常"
        m["Fast"] = "快"
        m["Voice test."] = "语音测试。"
        m["Try the sounds: each one has a different meaning."] = "试听提示音：每种声音含义不同。"
        m["Stop coming up"] = "即将到站"
        m["Problem"] = "问题"
        m["To ask by voice: long-press the Binario icon and choose “Ask by voice” (you can drag it to the Home screen), or add the “Binario · Ask by voice” tile to Quick Settings. With your phone's assistant say “Open Binario”. Works with TalkBack too."] = "语音提问：长按 Binario 图标并选择“语音提问”（可拖到主屏幕），或在快捷设置中添加“Binario · 语音提问”磁贴。也可对手机助手说“打开 Binario”。支持 TalkBack。"
        m["Connection at risk: the previous train is"] = "换乘有风险：上一班列车"
        m["min late"] = "分钟晚点"
        m["Short change"] = "换乘时间短"
        m["Change"] = "换乘"
        m["at"] = "于"
        m["planned"] = "计划"
        m["Delay compensation"] = "延误赔偿"
        m["Delay over 2 hours: you can claim 50% of the ticket price."] = "延误超过2小时：可申请票价的50%。"
        m["Delay over 1 hour: you can claim 25% of the ticket price."] = "延误超过1小时：可申请票价的25%。"
        m["Frecce 30–59 minutes late: Trenitalia grants compensation. Check the conditions on its website."] = "Frecce 晚点30–59分钟：Trenitalia 提供赔偿。请在其网站查看条件。"
        m["The delay at your arrival station counts; season tickets have their own rules. Source: EU Regulation 2021/782 and operators' conditions."] = "以到达站的延误为准；月票有单独规定。来源：EU 2021/782 法规和运营方条款。"
        m["Claim from Italo"] = "向 Italo 申请"
        m["Claim from Trenitalia"] = "向 Trenitalia 申请"
        m["Trenord refunds"] = "Trenord 退款"
        m["Trenitalia Regional compensation"] = "Trenitalia 区域列车赔偿"
        m["I board here"] = "我在这里上车"
        m["Platform, time and alerts for this stop (also by voice)"] = "此站的站台、时间和提醒（也可语音）"
        m["I will alert you for boarding at"] = "我会提醒您上车，地点："
        m["Only upcoming stop"] = "仅即将到站"
        m["All: platform, departure, changes, delays, stops"] = "全部：站台、出发、变更、延误、停靠站"
        m["I will alert you by voice only when your stop is coming up."] = "只有在您的下车站临近时我才会语音提醒。"
        m["Do you want to turn this feature on?"] = "要开启此功能吗？"
        m["Strong vibration with a different pattern for each alert (stop alarm, reminders, disruptions) and flashlight blinking. You can change it any time in Settings → Accessibility."] = "强烈振动，每种提醒模式不同（到站闹钟、提醒、中断），并闪烁手电筒。可随时在 设置 → 无障碍 中更改。"
        m["Try the vibration"] = "试试振动"
        m["Yes, turn on"] = "是，开启"
        m["No, thanks"] = "不，谢谢"
        m["Voice alerts for blind people"] = "为视障人士提供的语音提醒"
        m["The phone's voice tells you the platform, when the train leaves, platform changes and delays, and an insistent sound warns you when your stop is coming up."] = "手机语音会告诉您站台、列车何时出发、站台变更和延误，并在您的下车站临近时用持续的声音提醒您。"
        m["Yes, all voice alerts"] = "是，全部语音提醒"
        m["Answer by voice"] = "语音回答"
        m["Hear the question again"] = "再听一遍问题"
        m["I heard"] = "我听到的是"
        m["Say yes, only stop, or no"] = "请说：是、仅下车站，或不"
        m["I didn't understand. Answer yes, only stop, or no. Or tap one of the buttons."] = "我没听懂。请回答：是、仅下车站，或不。也可以点击按钮。"
        m["Voice alerts for blind or visually impaired people. Do you want to turn this feature on? You can choose: yes, for all voice alerts about platform, departure and stops; only stop, to be alerted only when your stop is coming up; or no."] = "为视障人士提供的语音提醒。要开启此功能吗？您可以选择：是，接收关于站台、出发和停靠站的全部语音提醒；仅下车站，只在您的下车站临近时提醒；或不。"
        m["Timetable PDF"] = "时刻表 PDF"
        m["All the day's runs, saved on your phone and available offline."] = "当天所有班次，保存在手机上，可离线查看。"
        m["Today"] = "今天"
        m["Tomorrow"] = "明天"
        m["Include return"] = "包含返程"
        m["Saved in Download/Binario."] = "已保存到 Download/Binario。"
        m["Open"] = "打开"
        m["No app to open PDFs"] = "没有可打开 PDF 的应用"
        m["Download PDF"] = "下载 PDF"
        m["Could not create the timetable"] = "无法生成时刻表"
        m["Download the day's timetable as PDF"] = "将当天时刻表下载为 PDF"
        m["Free"] = "免费"
        m["Paid"] = "收费"
        m["Free or paid: not stated"] = "免费或收费：未注明"
        m["hours"] = "时间"
        m["Ask by voice"] = "语音提问"
        m["Strikes and news"] = "罢工与新闻"
        m["Current journey"] = "当前行程"
        m["Stop"] = "停止"
        m["Updating…"] = "更新中…"
        m["Board at"] = "上车地点"
        m["platform"] = "站台"
        m["Next stop"] = "下一站"
        m["Alarm before"] = "提前叫醒于"
        m["Your journey"] = "您的行程"
        m["Open live status"] = "打开实时状态"
        m["Stop following"] = "停止跟踪"
        m["Assistant: trains, delays, platforms, strikes"] = "助手：列车、延误、站台、罢工"
        m["Downloaded PDFs are also in Download/Binario"] = "下载的 PDF 也在 Download/Binario 中"
        m["Information"] = "信息"
        m["Official sources, updated every 5 minutes"] = "官方来源，每5分钟更新"
        m["Regional vs regional, high speed vs high speed"] = "区域列车与区域列车比较，高铁与高铁比较"
        m["Conditions of carriage, rights and refunds"] = "运输条款、权利和退款"
        m["Operators' websites"] = "运营方网站"
        m["At the station and tickets"] = "车站与车票"
        m["Nearby stations on the map"] = "地图上的附近车站"
        m["Official ticket sites and personal area"] = "官方购票网站和个人中心"
        m["Tools"] = "工具"
        m["On: all alerts"] = "已开启：全部提醒"
        m["On: upcoming stop only"] = "已开启：仅即将到站"
        m["Alerts for deaf people"] = "为听障人士提供的提醒"
        m["On: vibration and flash"] = "已开启：振动和闪光"
        m["App"] = "应用"
        m["What's new in each version"] = "每个版本的新功能"
        m["Fix report"] = "修复报告"
        m["Problems fixed in each version"] = "每个版本修复的问题"
        m["Bus, metro, tram and taxi"] = "公交、地铁、有轨电车和出租车"
        m["Looking for nearby stops and taxi ranks…"] = "正在查找附近的站点和出租车停靠点…"
        m["No bus, metro, tram or taxi stop mapped within 400 m."] = "400米内未标注公交、地铁、有轨电车或出租车站点。"
        m["Metro"] = "地铁"
        m["Tram"] = "有轨电车"
        m["Bus"] = "公交"
        m["Taxi"] = "出租车"
        m["Bike sharing"] = "共享单车"
        m["Stops in maps"] = "地图中的站点"
        m["Find a taxi"] = "找出租车"
        m["bus stop"] = "公交站"
        m["Lines and stops from OpenStreetMap data: for bus times and routes check the local transport company."] = "线路和站点来自 OpenStreetMap 数据：公交时刻和线路请咨询当地交通公司。"
        m["Metro entrance"] = "地铁入口"
        m["Tram stop"] = "有轨电车站"
        m["Bus stop"] = "公交站"
        m["shelter"] = "候车亭"
        m["Taxi rank"] = "出租车停靠点"
        m["spaces"] = "车位"
        m["Tobacconists"] = "烟草店"
        m["Newsagents"] = "报亭"
        m["Ticket offices"] = "售票处"
        m["Bus stops"] = "公交站"
        m["Search on Google Maps:"] = "在 Google 地图上搜索："
        m["Can't find it? Search on Google Maps:"] = "找不到？在 Google 地图上搜索："
        m["Looking for ticket sellers within"] = "正在查找售票点，范围"
        m["saved data"] = "已保存的数据"
        m["OpenStreetMap servers are not responding (tried 3 Overpass servers and Postpass). Try again shortly or search on Google Maps."] = "OpenStreetMap 服务器无响应（已尝试3个 Overpass 服务器和 Postpass）。请稍后重试或在 Google 地图上搜索。"
        m["OpenStreetMap data unreachable right now (tried 3 Overpass servers and Postpass)."] = "暂时无法访问 OpenStreetMap 数据（已尝试3个 Overpass 服务器和 Postpass）。"
        m["Pull down to retry"] = "下拉重试"
        m["Pull down to refresh."] = "下拉刷新。"
        m["refreshes every 5 minutes or when you pull down"] = "每5分钟或下拉时刷新"
        m["No ticket sellers within"] = "范围内没有售票点"
        m["No ticket sellers found and the OpenStreetMap servers are not responding. Use the official Trenitalia map or try again."] = "未找到售票点，且 OpenStreetMap 服务器无响应。请使用 Trenitalia 官方地图或重试。"
        m["Mooney outlets"] = "Mooney 网点"
        m["Official Trenitalia map (all of Italy)"] = "Trenitalia 官方地图（全意大利）"
        m["Sources"] = "来源"
        m["Trenord authorised resellers and ticket offices"] = "Trenord 授权代售点和售票处"
        m["list of"] = "列表日期"
        m["updated weekly; open/closed checked now"] = "每周更新；营业状态实时查询"
        m["SBB ticket machines (open data data.sbb.ch)"] = "SBB 售票机（开放数据 data.sbb.ch）"
        m["ticket offices, machines and validators from"] = "售票处、售票机和验票机，来自"
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney outlets: the official Trenitalia map shows them."] = "在意大利其他地区，Trenitalia 区域车票在 PuntoLIS 和 Mooney 网点出售：Trenitalia 官方地图上可以找到。"
        m["Nearest station"] = "最近的车站"
        m["Authorised resellers"] = "授权代售点"
        m["nearest"] = "最近"
        m["see the official Trenitalia map in Resellers"] = "请在“售票点”中查看 Trenitalia 官方地图"
        m["Downloading Trenord sellers…"] = "正在下载 Trenord 售票点…"
        m["Checking who is open now…"] = "正在查询当前营业的网点…"
        m["Sells"] = "出售"
        m["altoadigemobilità outlets (South Tyrol)"] = "altoadigemobilità 网点（南蒂罗尔）"
        m["Railway companies"] = "铁路公司"
        m["All companies in Italy and Switzerland: sites, tickets, data"] = "意大利和瑞士的所有公司：网站、车票、数据"
        m["Search company or region"] = "搜索公司或地区"
        m["no public data"] = "无公开数据"
        m["Website"] = "网站"
        m["Where to buy"] = "购票地点"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. Italian railways with their own network (EAV, FSE, Ferrotramviaria, FAL, Circumetnea, ARST and others) publish real-time data only on their own site and app."] = "RFI 线网列车的实时数据来自 ViaggiaTreno；所有瑞士公司的数据来自瑞士官方时刻表。拥有自有线网的意大利铁路（EAV、FSE、Ferrotramviaria、FAL、Circumetnea、ARST 等）仅在其网站和应用中发布实时数据。"
        m["Only departures are available for Swiss stations"] = "瑞士车站仅提供出发信息"
        m["not yet included (data only in daily files too heavy for a phone: see note in Punctuality)"] = "尚未包含（数据仅在每日文件中，对手机来说太大：见“准点率”中的说明）"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. For EAV, ARST, Trentino Trasporti and Cotral the app shows scheduled times (Transitous). The other railways with their own network publish timetables and real-time data only on their site and app."] = "RFI 线网列车的实时数据来自 ViaggiaTreno；所有瑞士公司的数据来自瑞士官方时刻表。EAV、ARST、Trentino Trasporti 和 Cotral 显示计划时刻（Transitous）。其他拥有自有线网的铁路仅在其网站和应用中发布时刻表和实时数据。"
        m["Only departures are available for this station"] = "此车站仅提供出发信息"
        m["Operator's scheduled times (Transitous): delays appear only if the operator publishes them."] = "运营方计划时刻（Transitous）：仅当运营方发布时才显示延误。"
        m["Nearby toilets"] = "附近的卫生间"
        m["Free or paid, accessible, opening hours"] = "免费或收费、无障碍、开放时间"
        m["Free or paid, accessible, baby changing, opening hours"] = "免费或收费、无障碍、婴儿护理台、开放时间"
        m["Authorised resellers, ticket offices, machines, contactless"] = "授权代售点、售票处、售票机、非接触支付"
    }

    private fun p2(m: HashMap<String, String>) {
        m["Looking for toilets within"] = "正在查找卫生间，范围"
        m["OpenStreetMap servers are not responding. Try again shortly or search on Google Maps."] = "OpenStreetMap 服务器无响应。请稍后重试或在 Google 地图上搜索。"
        m["Accessible ♿"] = "无障碍 ♿"
        m["Within 2 km"] = "2公里内"
        m["Public toilets"] = "公共卫生间"
        m["No toilets mapped within"] = "范围内未标注卫生间"
        m["Prices, hours and accessibility come from OpenStreetMap volunteers: check on site."] = "价格、开放时间和无障碍信息来自 OpenStreetMap 志愿者：请现场核实。"
        m["♿ partly accessible"] = "♿ 部分无障碍"
        m["🚼 baby changing"] = "🚼 婴儿护理台"
        m["customers only"] = "仅限顾客"
        m["for customers"] = "供顾客使用"
        m["min walk"] = "分钟步行"
        m["Service status"] = "服务状态"
        m["Check that all data sources respond"] = "检查所有数据来源是否响应"
        m["Check again"] = "再次检查"
        m["Checking all data sources…"] = "正在检查所有数据来源…"
        m["All sources respond correctly."] = "所有来源均正常响应。"
        m["sources with problems: related features use fallbacks or the last saved data."] = "个来源有问题：相关功能将使用备用来源或最近保存的数据。"
        m["Working"] = "正常"
        m["Checked at"] = "检查时间"
        m["Sources are external public services: if one is down the app tries alternatives (other servers, saved data, Google Maps)."] = "数据来源为外部公共服务：若某个来源不可用，应用会尝试替代方案（其他服务器、已保存数据、Google 地图）。"
        m["Trains and boards"] = "列车与时刻牌"
        m["Journeys"] = "行程方案"
        m["News and strikes"] = "新闻与罢工"
        m["Maps and station services"] = "地图与车站服务"
        m["The app closed unexpectedly"] = "应用意外关闭"
        m["Do you want to send the report to the developer? It contains only the technical error details, the phone model and the Android version: no personal data, location or trips."] = "要把报告发送给开发者吗？报告只包含技术错误详情、手机型号和 Android 版本：不含个人数据、位置或行程。"
        m["Binario error report"] = "Binario 错误报告"
        m["Send report"] = "发送报告"
        m["Ignore"] = "忽略"
        m["Your next train"] = "您的下一班列车"
        m["I won't suggest it again"] = "不再推荐"
        m["Not mine"] = "不是我的"
        m["to"] = "开往"
        m["leaves at"] = "出发时间"
        m["changed!"] = "已变更！"
        m["Alternatives"] = "替代方案"
        m["Leaving earlier"] = "更早出发"
        m["Looking for alternatives…"] = "正在查找替代方案…"
        m["No alternative soon."] = "近期没有替代方案。"
        m["Route ready in the Search tab"] = "路线已在“搜索”页准备好"
        m["Learn the trains I take often"] = "学习我常坐的列车"
        m["From the board, journeys, Follow and favourites. Stays on the phone only."] = "来自时刻牌、行程方案、跟踪和收藏。仅保存在手机上。"
        m["Alert me automatically about my usual train"] = "自动提醒我常坐的列车"
        m["In the 45 minutes before departure: delay, cancellation, platform change and ready alternatives"] = "出发前45分钟内：延误、停运、站台变更及备选方案"
        m["Forget"] = "忘记"
        m["No usual train yet: it appears after you open it at least twice on the same weekday."] = "尚无常坐列车：在同一工作日至少打开两次后才会出现。"
        m["Download failed. Check your connection and try again."] = "下载失败。请检查网络后重试。"
        m["A new version is available"] = "有新版本可用"
        m["Downloading the update…"] = "正在下载更新…"
        m["To install the update allow Binario to install apps (Android asks only once), then come back here."] = "要安装更新，请允许 Binario 安装应用（Android 只会询问一次），然后返回这里。"
        m["Update downloaded. Confirm the installation in the Android window: favourites and settings are kept."] = "更新已下载。请在 Android 窗口中确认安装：收藏和设置都会保留。"
        m["Do you want to update Binario? The app downloads the new version by itself; favourites and settings are kept."] = "要更新 Binario 吗？应用会自动下载新版本；收藏和设置都会保留。"
        m["What's new"] = "新功能"
        m["Allow"] = "允许"
        m["Install"] = "安装"
        m["Later"] = "稍后"
        m["Feedback and bug reports"] = "反馈与错误报告"
        m["Write to the developer: ideas, suggestions, problems"] = "写信给开发者：想法、建议、问题"
        m["Suggestions, ideas or something not working? Write it here: the message goes straight to the developer."] = "有建议、想法或发现问题？写在这里：消息会直接发给开发者。"
        m["Suggestion"] = "建议"
        m["Report a bug"] = "报告错误"
        m["Full name"] = "姓名"
        m["Enter your full name"] = "请输入您的姓名"
        m["Invalid email"] = "电子邮件无效"
        m["Only used to reply to you"] = "仅用于回复您"
        m["Describe the problem"] = "描述问题"
        m["Your feedback"] = "您的反馈"
        m["What you were doing, what happened and what you expected (e.g. station, train number, time)."] = "您当时在做什么、发生了什么、您期望什么（例如车站、车次、时间）。"
        m["What you like, what you would improve, what is missing."] = "您喜欢什么、希望改进什么、缺少什么。"
        m["Write at least a few words"] = "请至少写几个字"
        m["Attach technical details"] = "附上技术信息"
        m["App version, phone model and Android version: they help find the problem."] = "应用版本、手机型号和 Android 版本：有助于查找问题。"
        m["Thank you! Message sent."] = "谢谢！消息已发送。"
        m["No connection: the message is saved and will be sent automatically as soon as possible."] = "无网络：消息已保存，将尽快自动发送。"
        m["Sending…"] = "发送中…"
        m["Send"] = "发送"
        m["Name and email are only used to reply to you and nothing else. The message contains no location, trips or favourites."] = "姓名和电子邮件仅用于回复您，不作他用。消息不包含位置、行程或收藏。"
        m["Email"] = "电子邮件"
        m["I recommend Binario, the free train app for Italy and Switzerland: timetables, live delays, platforms, strikes, Trenord and FerrovieNord, alerts for your train. No ads."] = "推荐 Binario，一款意大利和瑞士的免费火车应用：时刻表、实时延误、站台、罢工、Trenord 和 FerrovieNord、列车提醒。无广告。"
        m["Download the latest version for Android:"] = "下载 Android 最新版本："
        m["After downloading, open the file and allow the installation: the app then updates itself."] = "下载后打开文件并允许安装：之后应用会自动更新。"
        m["App not installed: choose another app"] = "未安装该应用：请选择其他应用"
        m["Share Binario"] = "分享 Binario"
        m["Send your contacts the link to download the latest version of the app."] = "把下载最新版本应用的链接发给您的联系人。"
        m["Other apps (SMS, email…)"] = "其他应用（短信、电子邮件…）"
        m["Send the app to your contacts on WhatsApp, Telegram…"] = "通过 WhatsApp、Telegram 等把应用发给联系人…"
        m["STIBM area"] = "STIBM 区域"
        m["How much it costs"] = "价格"
        m["From"] = "从"
        m["To"] = "到"
        m["The journey goes through Milan"] = "行程经过米兰"
        m["In that case zone Mi1 is also needed"] = "这种情况下还需要 Mi1 区"
        m["zones"] = "个区"
        m["Same zone: the minimum 2-zone fare still applies (the one with the inner zone is fine too)."] = "同一区：仍按最低2区票价（含内圈区的也可以）。"
        m["Note: this station is outside the STIBM area. It is only valid for changing train or bus, not as start or end of a STIBM ticket."] = "注意：此车站在 STIBM 区域外。仅可用于换乘火车或公交，不能作为 STIBM 车票的起点或终点。"
        m["Single ticket"] = "单程票"
        m["min"] = "分钟"
        m["Carnet of 10 (Trenord website and app)"] = "10次票（Trenord 网站和应用）"
        m["Daily (24 hours)"] = "日票（24小时）"
        m["3 days"] = "3日票"
        m["Weekly (Mon–Sun)"] = "周票（周一至周日）"
        m["Monthly"] = "月票"
        m["Yearly"] = "年票"
        m["Monthly under 26 / over 65"] = "月票 26岁以下 / 65岁以上"
        m["Yearly under 26 / over 65"] = "年票 26岁以下 / 65岁以上"
        m["Yearly ISEE below €6,000"] = "年票 ISEE 低于6000欧元"
        m["Prices valid from"] = "价格生效日期"
        m["Valid on Trenord and Trenitalia regional trains in 2nd class, metro, trams and buses."] = "适用于二等座 Trenord 和 Trenitalia 区域列车、地铁、有轨电车和公交。"
        m["Main rules"] = "主要规定"
        m["Zone map"] = "分区地图"
        m["Fares"] = "票价"
        m["Rules"] = "规定"
        m["Stations in the STIBM area"] = "STIBM 区域内的车站"
        m["Search station or town"] = "搜索车站或城镇"
        m["outside the area, interchange only"] = "区域外，仅限换乘"
        m["service suspended"] = "服务暂停"
        m["Use for the calculation"] = "用于计算"
        m["Source: Trenord, STIBM area – areas and fares"] = "来源：Trenord，STIBM 区域 – 分区与票价"
        m["Choose the station"] = "选择车站"
        m["Station not found"] = "未找到车站"
        m["Outside the STIBM area (interchange only)"] = "在 STIBM 区域外（仅限换乘）"
        m["zone"] = "区"
        m["fares"] = "票价"
        m["STIBM area · Milan and Monza Brianza"] = "STIBM 区域 · 米兰和蒙扎-布里安扎"
        m["Zones, prices and stations of the integrated ticket"] = "一票通的分区、价格和车站"
        m["One ticket for Trenord and Trenitalia regional trains, metro, trams and buses in the Metropolitan City of Milan, the province of Monza and Brianza and some nearby towns. The price depends on the number of zones (Mi1…Mi9) between start and end, not on the vehicle."] = "一张车票可乘坐米兰大都会区、蒙扎-布里安扎省及附近部分城镇的 Trenord 和 Trenitalia 区域列车、地铁、有轨电车和公交。价格取决于起点和终点之间的分区数（Mi1…Mi9），与交通工具无关。"
        m["How much your pass costs"] = "您的月票多少钱"
        m["My Conductor"] = "我的列车长"
        m["Follow your train: alerts before, during and after the trip"] = "跟踪您的列车：出发前、途中和到达后的提醒"
        m["Tell me your train: I'll alert you about platform, delays and arrival. All trains, no sign-up."] = "告诉我您的车次：我会提醒您站台、延误和到达。所有列车，无需注册。"
        m["Trenord from A to B: weekly, monthly, yearly, Trenocittà, tickets"] = "Trenord 从 A 到 B：周票、月票、年票、Trenocittà、车票"
        m["Trenord regional fare (Lombardy) by distance band, valid from"] = "Trenord 区域票价（伦巴第），按里程段计算，生效日期"
        m["Cannot work out the distance between these stations. Check your connection or choose stations in Lombardy."] = "无法计算这两个车站之间的距离。请检查网络或选择伦巴第的车站。"
        m["Journey within the STIBM area"] = "STIBM 区域内的行程"
        m["Between these stations the integrated STIBM ticket applies (also valid on metro, trams and buses):"] = "这两个车站之间适用 STIBM 一票通（也可乘坐地铁、有轨电车和公交）："
        m["Tap for prices and rules."] = "点击查看价格和规定。"
        m["distance band"] = "里程段"
        m["Passes"] = "月票/周票"
        m["Weekly"] = "周票"
        m["Trenocittà monthly"] = "Trenocittà 月票"
        m["Trenocittà: train plus city transport in the town shown. "] = "Trenocittà：火车加所示城市的市内交通。"
        m["Passes on the Io Viaggio card (€10, valid 4 years). Families: 2nd minor child −20%, from the 3rd free (Io Viaggio in Famiglia)."] = "月票须存在 Io Viaggio 卡上（10欧元，有效期4年）。家庭：第2个未成年子女减20%，第3个起免费（Io Viaggio in Famiglia）。"
        m["Adult single"] = "成人单程"
        m["Children 4–14"] = "儿童 4–14 岁"
        m["Senior"] = "长者"
        m["Carnet of 10"] = "10次票"
        m["Children under 4 free; children 4–14 free with an adult family member holding a ticket."] = "4岁以下儿童免费；4–14岁儿童由持票的成年家庭成员陪同时免费。"
        m["Io Viaggio Ovunque (all trains and public transport)"] = "Io Viaggio Ovunque（所有列车和公共交通）"
        m["All of Lombardy"] = "伦巴第全境"
        m["Province, monthly"] = "省内，月票"
        m["1 day"] = "1日"
        m["2 days"] = "2日"
        m["7 days"] = "7日"
        m["Quarterly"] = "季票"
        m["1st class supplement:"] = "一等座附加费："
        m["per trip"] = "每次"
        m["per month"] = "每月"
        m["per year (Io Viaggio Ovunque in Lombardia)"] = "每年（伦巴第 Io Viaggio Ovunque）"
        m["Bikes on lines leaving Lombardy: €3.50."] = "驶出伦巴第线路上的自行车：3.50欧元。"
        m["Official fares"] = "官方票价"
        m["Trenord passes"] = "Trenord 月票"
        m["2nd cl."] = "二等"
        m["1st cl."] = "一等"
        m["Trains: 2nd class only. First class supplement: €2.80 per trip, €31 per month, €310 per year."] = "列车：仅二等座。一等座附加费：每次2.80欧元，每月31欧元，每年310欧元。"
        m["Malpensa Express · fares"] = "Malpensa Express · 票价"
        m["Prices from every station, lines, classes and restrictions"] = "各站价格、线路、车厢等级和限制"
        m["The two lines"] = "两条线路"
        m["Prices from every station"] = "各站价格"
        m["Single adult / child"] = "成人 / 儿童单程"
        m["Same-day return"] = "当日往返"
        m["Weekly pass"] = "周票"
        m["Monthly pass"] = "月票"
        m["Yearly pass"] = "年票"
        m["Other tickets"] = "其他车票"
        m["Return within 30 days (online only), adult / child"] = "30天内返程（仅限网上），成人 / 儿童"
        m["Malpensa Family (2 adults + 2 children 4–17)"] = "Malpensa 家庭票（2名成人 + 2名 4–17 岁儿童）"
        m["Terminal 1 ⇄ Terminal 2 transfer, adult / child"] = "1号航站楼 ⇄ 2号航站楼接驳，成人 / 儿童"
        m["Rules and restrictions"] = "规定与限制"
        m["Milan ⇄ Malpensa"] = "米兰 ⇄ Malpensa"
        m["To or from Malpensa airport (Terminal 1 and 2) the airport fare applies. Prices valid from"] = "往返 Malpensa 机场（1号和2号航站楼）适用机场票价。价格生效日期"
        m["Malpensa airport: Malpensa Express fare"] = "Malpensa 机场：Malpensa Express 票价"
        m["single"] = "单程"
        m["monthly 2nd cl."] = "二等月票"
        m["monthly 1st cl."] = "一等月票"
        m["There is no direct airport fare for this station. Tap for all fares and rules."] = "此车站没有直达机场的票价。点击查看所有票价和规定。"
        m["The prices below (regional fare) are not valid to or from the airport. Tap for all fares and restrictions."] = "以下价格（区域票价）不适用于往返机场。点击查看所有票价和限制。"
        m["2nd class, single ticket, CHF · valid from 14.12.2025 (source: Arcobaleno)"] = "二等座，单程票，瑞士法郎 · 自2025年12月14日起有效（来源：Arcobaleno）"
        m["Trenord passes and tickets"] = "Trenord 月票和车票"
        m["Add to calendar"] = "添加到日历"
        m["Some features may have bugs or change. Tap here to report a problem."] = "部分功能可能有错误或变动。点击这里报告问题。"
        m["Alarms and saved timetables"] = "闹钟和已保存的时刻表"
        m["More options (voice, vibration for deaf people) in Settings → Accessibility."] = "更多选项（语音、为听障人士提供的振动）在 设置 → 无障碍 中。"
        m["Also just for your route and your times"] = "也可以只针对您的路线和时间"
        m["Cancelled."] = "已取消。"
        m["Travel assistance for disabled passengers"] = "残障旅客出行协助"
        m["Remind me (scheduled notification)"] = "提醒我（定时通知）"
        m["Trenord notices"] = "Trenord 通知"
        m["Biasca – Bellinzona – Lugano – Chiasso – Como"] = "Biasca – Bellinzona – Lugano – Chiasso – Como"
        m["Biasca – Bellinzona – Lugano – Varese – Malpensa"] = "Biasca – Bellinzona – Lugano – Varese – Malpensa"
        m["Tickets and prices"] = "车票与价格"
        m["Cadenazzo – Luino – Gallarate"] = "Cadenazzo – Luino – Gallarate"
        m["Arcobaleno fare calculator"] = "Arcobaleno 票价计算器"
        m["Dogs, cats and pet carriers: rules and prices by operator"] = "狗、猫和宠物箱：各运营方的规定和价格"
        m["Castione-Arbedo – Bellinzona – Locarno"] = "Castione-Arbedo – Bellinzona – Locarno"
        m["Find an Italo train by number"] = "按车次查找 Italo 列车"
        m["Who to call and how to book: Sale Blu 800 90 60 60, Trenord, Italo, SBB"] = "联系谁以及如何预约：Sale Blu 800 90 60 60、Trenord、Italo、SBB"
        m["Colour-blind colours. Do you want to turn this on? Tap yes red-green, yes blue-yellow, or no."] = "色盲配色。要开启吗？请点击：是红绿、是蓝黄，或不。"
        m["What's your name? Tell me your first and last name."] = "您叫什么名字？请告诉我您的姓名。"
        m["Como – Mendrisio – Varese"] = "Como – Mendrisio – Varese"
        m["Conditions of carriage, delays, compensation"] = "运输条款、延误、赔偿"
        m["Contacts and support"] = "联系方式与支持"
        m["Validate before departure and at every change of vehicle (between two trains the first validation is enough)."] = "出发前和每次换乘交通工具时都要验票（两趟火车之间第一次验票即可）。"
        m["Single ticket valid 4 hours for the whole journey (in Italy from validation). Monthly cross-border passes: in Italy from the 1st of the month, only on an Io Viaggio card; in Ticino 30 days from purchase."] = "单程票在整个行程中有效4小时（在意大利自验票起算）。跨境月票：在意大利自每月1日起，仅限 Io Viaggio 卡；在提契诺自购买起30天。"
        m["What to do and who to contact: Trenord, Trenitalia, Italo, SBB"] = "该怎么做、联系谁：Trenord、Trenitalia、Italo、SBB"
        m["From A to B: passes and tickets, also to Switzerland"] = "从 A 到 B：月票和车票，也可去瑞士"
        m["From: "] = "从："
        m["Describe the problem."] = "请描述问题。"
        m["Describe the problem: what you were doing and what happened."] = "请描述问题：您当时在做什么，发生了什么。"
        m["Dictate the message"] = "口述消息"
        m["Shall I send, correct or cancel? Say send, correct or cancel."] = "要发送、修改还是取消？请说：发送、修改或取消。"
        m["Tell me your suggestion."] = "请说出您的建议。"
        m["Rights and refunds"] = "权利与退款"
        m["Where am I"] = "我在哪里"
        m["Where I am, platforms, lifts, stairs, nearby services; guidance to a place"] = "我在哪里、站台、电梯、楼梯、附近服务；引导前往某地"
        m["Where I am, platforms, lifts, services; guidance to a place"] = "我在哪里、站台、电梯、服务；引导前往某地"
        m["Duration"] = "时长"
        m["Sold out"] = "已售罄"
        m["Explore by voice"] = "语音探索"
        m["Voice feedback"] = "语音反馈"
        m["Voice feedback. After the tone, tell me: is it a suggestion or do you want to report a problem? You can say cancel at any time."] = "语音反馈。提示音后请告诉我：是建议还是要报告问题？随时可以说“取消”。"
        m["Feedback and reports. Tap the \"Voice feedback\" button at the top to dictate your message."] = "反馈与报告。点击顶部的“语音反馈”按钮口述您的消息。"
        m["Intermediate stops only at stations in the STIBM area; outside the area only to change vehicle (e.g. Saronno, Busto Arsizio, Treviglio)."] = "中途停靠仅限 STIBM 区域内的车站；区域外仅可用于换乘（例如 Saronno、Busto Arsizio、Treviglio）。"
        m["Giubiasco – Lugano – Mendrisio"] = "Giubiasco – Lugano – Mendrisio"
        m["Got it"] = "知道了"
        m["Tickets cannot be transferred after validation. Passes on an Io Viaggio or ATM card."] = "车票验票后不可转让。月票须存在 Io Viaggio 或 ATM 卡上。"
        m["Your trains during the strike"] = "罢工期间您的列车"
        m["The standard ticket is valid 75 minutes for 2 zones, +15 minutes per zone up to 4 zones, +30 minutes per zone from 5 zones up; in Milan (Mi1–Mi3) it is valid 90 minutes. Unlimited journeys within the validity time."] = "普通车票2个区有效75分钟，4个区以内每增加1区加15分钟，5个区起每增加1区加30分钟；在米兰（Mi1–Mi3）有效90分钟。有效期内可不限次乘坐。"
        m["The message is too short."] = "消息太短。"
        m["Speech recognition is not available on this phone."] = "此手机不支持语音识别。"
        m["At the station and tools"] = "车站与工具"
        m["Travel updates, guaranteed trains, tickets"] = "出行信息、保障列车、车票"
        m["About the app"] = "关于本应用"
        m["Full fare"] = "全价"
        m["Italy and Switzerland: websites, tickets, data"] = "意大利和瑞士：网站、车票、数据"
        m["The Lombardy regional fare is not valid across the border. The price adds the Lombardy section (Trenord distance bands) and the Ticino section (Arcobaleno zones): Trenord sells it in euros, Arcobaleno in francs."] = "伦巴第区域票价不适用于跨境。价格由伦巴第段（Trenord 里程段）和提契诺段（Arcobaleno 分区）相加：Trenord 以欧元出售，Arcobaleno 以瑞士法郎出售。"
        m["Trenord and FerrovieNord lines"] = "Trenord 和 FerrovieNord 线路"
        m["FerrovieNord network lines"] = "FerrovieNord 线网线路"
        m["Lines, Malpensa Express, STIBM area, notices"] = "线路、Malpensa Express、STIBM 区域、通知"
        m["Locarno – Lugano – Chiasso – Milan"] = "Locarno – Lugano – Chiasso – 米兰"
        m["Malpensa Express: valid only within the city of Milan (not in the 21 towns of zone Mi3) and between Milan and Rescaldina (Mi1–Mi7), only on trains to/from Milano Centrale."] = "Malpensa Express：仅在米兰市内（不含 Mi3 区的21个市镇）以及米兰与 Rescaldina 之间（Mi1–Mi7）有效，且仅限往返米兰中央车站的列车。"
        m["The name is missing."] = "缺少姓名。"
        m["A valid email is missing."] = "缺少有效的电子邮件。"
        m["Half fare"] = "半价"
        m["Also show these options on the Home screen"] = "也在主页显示这些选项"
        m["Hide"] = "隐藏"
        m["Hide fares"] = "隐藏票价"
        m["During guaranteed hours (weekdays 6–9 and 18–21) regional trains run. Outside those hours check your operator's list of guaranteed trains."] = "在保障时段（工作日 6–9 点和 18–21 点）区域列车照常运行。其他时段请查看您所乘运营方的保障列车列表。"
        m["No strike announced in your region"] = "您所在地区没有宣布罢工"
        m["No announced strike affects your route at your times"] = "已宣布的罢工不影响您的路线和时间"
        m["No"] = "否"
        m["I didn't understand the email. Say it again slowly, saying at and dot."] = "我没听懂电子邮件地址。请慢慢再说一遍，用“at”和“dot”表示 @ 和点。"
        m["I didn't hear you. Tap \"Voice feedback\" again to try again."] = "我没听到。请再次点击“语音反馈”重试。"
        m["Note: the malpensaexpress.it passes page shows lower \"from\" prices (€25 weekly, €87 monthly, €840 yearly): here are the prices from the current Trenord fare table."] = "注意：malpensaexpress.it 月票页面显示的“起价”较低（周票25欧元、月票87欧元、年票840欧元）：这里显示的是现行 Trenord 票价表中的价格。"
        m["Scheduled notifications, alarms, offline timetables"] = "定时通知、闹钟、离线时刻表"
        m["Travel update news"] = "出行信息新闻"
        m["What's new, fixes, service status, privacy"] = "新功能、修复、服务状态、隐私"
        m["Lost property"] = "失物招领"
        m["Spoken mode"] = "语音模式"
        m["Spoken mode (blind users)"] = "语音模式（视障人士）"
        m["Spoken mode on."] = "语音模式已开启。"
        m["Time"] = "时间"
        m["Sort:"] = "排序："
        m["By operator"] = "按运营方"
        m["For people who are blind or prefer to talk: the app asks the questions aloud and you answer by voice."] = "适用于视障或喜欢说话的人：应用会大声提问，您用语音回答。"
        m["Trenord doesn't publish a price table for this route: the exact price in euros is in the Trenord online shop."] = "Trenord 未公布此路线的价格表：准确的欧元价格请见 Trenord 网上商店。"
        m["Ranks outside the station, radio taxis to call, apps"] = "车站外的停靠点、可拨打的无线电出租车、应用"
        m["Taxi ranks, radio taxis to call, apps"] = "出租车停靠点、可拨打的无线电出租车、应用"
        m["Best prices by day and time of day"] = "按日期和时段的最低价格"
        m["Prices for 1 adult from LeFrecce (Trenitalia); they may change until purchase."] = "1名成人的价格，来自 LeFrecce（Trenitalia）；购买前可能变动。"
        m["Price"] = "价格"
        m["Arcobaleno price (2nd class, single ticket):"] = "Arcobaleno 价格（二等座，单程票）："
        m["Trenord price (adult single ticket)"] = "Trenord 价格（成人单程票）"
        m["Price and booking on italotreno.com"] = "在 italotreno.com 查看价格和预订"
        m["Price on the Trenord website"] = "Trenord 网站上的价格"
        m["Sales points"] = "售票点"
        m["FerrovieNord punctuality"] = "FerrovieNord 准点率"
        m["What's your email? For example: mario dot rossi at gmail dot com."] = "您的电子邮件是什么？例如：mario dot rossi at gmail dot com。"
        m["RFI Sala Blu · 800 90 60 60"] = "RFI Sala Blu · 800 90 60 60"
        m["Children under 14 travel free with a paying adult; on their own they need the Under 14 card."] = "14岁以下儿童由付费成人陪同时免费；单独出行需要 Under 14 卡。"
        m["EU Regulation 2021/782"] = "欧盟法规 2021/782"
        m["Delays, cancellations, platforms, crowding and punctuality use distinguishable colours (orange and blue instead of red and green) and extra symbols. You can change it at any time from Home or Settings → Accessibility."] = "延误、停运、站台、拥挤程度和准点率使用易于区分的颜色（橙色和蓝色代替红色和绿色）并附加符号。可随时在主页或 设置 → 无障碍 中更改。"
        m["Problem report."] = "问题报告。"
        m["You are here"] = "您在这里"
        m["FerrovieNord website"] = "FerrovieNord 网站"
        m["Suggestion."] = "建议。"
        m["Yes, blue-yellow"] = "是，蓝黄"
        m["Yes, turn off"] = "是，关闭"
        m["Yes, red-green (the most common)"] = "是，红绿（最常见）"
        m["TILO (Ticino–Lombardy)"] = "TILO（提契诺–伦巴第）"
    }

    private fun p3(m: HashMap<String, String>) {
        m["TILO and Switzerland"] = "TILO 与瑞士"
        m["TILO · Services"] = "TILO · 服务"
        m["Departures and arrivals board"] = "出发与到达时刻牌"
        m["Nearby taxis"] = "附近的出租车"
        m["Ticino–Lombardy, cross-border fares"] = "提契诺–伦巴第，跨境票价"
        m["Between two Swiss stations Arcobaleno (Ticino) or SBB fares apply: Trenord's distance bands don't apply."] = "两个瑞士车站之间适用 Arcobaleno（提契诺）或 SBB 票价：不适用 Trenord 里程段。"
        m["Between places outside Milan: the zones between them; if you cross Milan you always also need Mi1. Minimum 2 zones."] = "米兰以外两地之间：按两地之间的分区计算；如穿过米兰，始终还需 Mi1 区。最少2个区。"
        m["Real-time trains, contacts"] = "实时列车、联系方式"
        m["Trenord · 800 210 955"] = "Trenord · 800 210 955"
        m["All railway operators"] = "所有铁路运营方"
        m["All accessibility options"] = "所有无障碍选项"
        m["All fares and classes"] = "所有票价和车厢等级"
        m["Checked on the Trenord website on"] = "在 Trenord 网站核实于"
        m["Travelling with pets"] = "携带宠物出行"
        m["Italy ⇄ Switzerland trip: cross-border ticket"] = "意大利 ⇄ 瑞士行程：跨境车票"
        m["Trip within Switzerland"] = "瑞士境内行程"
        m["Do you want to turn on spoken mode? The phone's voice will tell you the platform, departure, delays and the stop where to get off."] = "要开启语音模式吗？手机语音会告诉您站台、出发时间、延误和下车站。"
        m["Do you want to turn off spoken mode?"] = "要关闭语音模式吗？"
        m["application/json"] = "application/json"
        m["contactless"] = "非接触支付"
        m["from"] = "从"
        m["data saved on the phone"] = "手机上保存的数据"
        m["sold out"] = "已售罄"
        m["in testing"] = "测试中"
        m["half price"] = "半价"
        m["last"] = "最后"
        m["Departures from Cadorna at minutes 27 and 57 (from 4.27 to 00.20), 37 minutes. Stops at Milano Bovisa, Saronno, Busto Arsizio Nord. FIRST class only."] = "从 Cadorna 每小时第27和57分发车（4:27 至 00:20），全程37分钟。停靠 Milano Bovisa、Saronno、Busto Arsizio Nord。仅限一等座。"
        m["Departures from Centrale at minutes 25 and 55 (from 5.25 to 23.25), 51 minutes. Stops at Porta Garibaldi, Bovisa, Saronno, Busto Arsizio; the :25 trains also at Rescaldina, Castellanza and Ferno-Lonate Pozzolo. First and second class, but second class is only for trips that do NOT start or end at the airport."] = "从 Centrale 每小时第25和55分发车（5:25 至 23:25），全程51分钟。停靠 Porta Garibaldi、Bovisa、Saronno、Busto Arsizio；第25分的班次还停靠 Rescaldina、Castellanza 和 Ferno-Lonate Pozzolo。设一等和二等座，但二等座仅限不从机场出发或不到达机场的行程。"
        m["To or from Malpensa Terminal 1 and 2 you always need an airport-fare ticket: regional passes, Io Viaggio Ovunque (Lombardy or Varese province) and STIBM are valid on Malpensa Express trains only between the other stations."] = "往返 Malpensa 1号和2号航站楼必须购买机场票价车票：区域月票、Io Viaggio Ovunque（伦巴第或瓦雷泽省）和 STIBM 在 Malpensa Express 列车上仅适用于其他车站之间。"
        m["The Malpensa ticket is valid for both terminals."] = "Malpensa 车票两个航站楼均有效。"
        m["Single ticket: valid on the chosen day until the end of service, no validation needed; the date can be changed up to 3 times until the day before."] = "单程票：在所选日期内有效至当天运营结束，无需验票；可在前一天之前最多改期3次。"
        m["Return ticket: same-day at ticket offices and machines; within 30 days only online and in the app (Milan ⇄ Malpensa, €25 instead of €30), only the return date can be changed."] = "往返票：当日往返可在售票处和售票机购买；30天内往返仅限网上和应用购买（米兰 ⇄ Malpensa，25欧元而非30欧元），仅可更改返程日期。"
        m["Malpensa Family €36: 2 adults and 2 young people aged 4 to 17, between a Milan station and the airport. Children under 4 travel free."] = "Malpensa 家庭票36欧元：2名成人和2名4至17岁青少年，往返米兰某车站与机场。4岁以下儿童免费。"
        m["Young people: reduced fare from 4 to 13 years."] = "青少年：4至13岁享受优惠票价。"
        m["The Malpensa Express ticket to/from Milan is also valid on all trains between stations in the Milan area."] = "往返米兰的 Malpensa Express 车票也可乘坐米兰地区各车站之间的所有列车。"
        m["On urban sections (Cadorna–Domodossola–Bovisa and Centrale–Porta Garibaldi–Bovisa) urban Trenord and STIBM tickets are also valid. STIBM is valid only in 2nd class, and on trains to/from Milano Centrale also as far as Rescaldina (Mi1–Mi7)."] = "在市区路段（Cadorna–Domodossola–Bovisa 和 Centrale–Porta Garibaldi–Bovisa）也可使用 Trenord 市区车票和 STIBM 车票。STIBM 仅限二等座，在往返米兰中央车站的列车上也可乘至 Rescaldina（Mi1–Mi7）。"
        m["Malpensa Express passes: weekly (on sale from the Thursday before, activate within 5 days), monthly (from the 22nd of the previous month, within 15 days), yearly (within 30 days); on an Io Viaggio card or Phone Pass."] = "Malpensa Express 月票：周票（前一周周四起发售，5天内激活）、月票（上月22日起，15天内）、年票（30天内）；存于 Io Viaggio 卡或 Phone Pass。"
        m["Bikes and dogs travel free as luggage with a boarding pass; without a boarding pass dogs pay the pet supplement."] = "持登机牌时，自行车和狗可作为行李免费携带；无登机牌时，狗需支付宠物附加费。"
        m["Transfer between Terminal 1 and Terminal 2: €2 adults, €1 young people."] = "1号与2号航站楼之间接驳：成人2欧元，青少年1欧元。"
        m["via Terminal 2"] = "经2号航站楼"
        m["via Busto Arsizio"] = "经 Busto Arsizio"
        m["Share Binario: coming soon"] = "分享 Binario：即将推出"
        m["Network, lifts out of service, accessibility, defibrillators"] = "线网、停用电梯、无障碍、除颤器"
        m["FERROVIENORD network info"] = "FERROVIENORD 线网信息"
        m["Lifts and escalators out of service, accessibility, assistance, AEDs, documents"] = "停用的电梯和自动扶梯、无障碍、协助、AED、文件"
        m["Replacement buses"] = "替代巴士"
        m["Stops and times of buses replacing trains · Trenord, Trenitalia, TILO"] = "代替火车的巴士站点和时刻 · Trenord、Trenitalia、TILO"
        m["Defibrillators (AED)"] = "除颤器（AED）"
        m["Where they are, near you or the station · call 112"] = "在哪里：您附近或车站附近 · 拨打112"
        m["Share Binario, not available: coming soon"] = "分享 Binario，不可用：即将推出"
        m["Coming soon"] = "即将推出"
        m["solutions · saved on "] = "个方案 · 保存于 "
        m["Reminder at "] = "提醒时间 "
        m["arrival"] = "到达"
        m["departure"] = "出发"
        m["Ticket offices, machines, resellers · nearby or by province"] = "售票处、售票机、代售点 · 附近或按省份"
        m["Location not available: turn on GPS."] = "位置不可用：请打开GPS。"
        m["Looking for taxi ranks…"] = "正在查找出租车停靠点…"
        m["OpenStreetMap servers are not responding. Use the numbers below or Google Maps."] = "OpenStreetMap 服务器无响应。请使用下方电话或 Google 地图。"
        m["Call a taxi"] = "叫出租车"
        m["I don't have a verified radio taxi number for this city: use an app or search for the number."] = "我没有这个城市经核实的无线电出租车电话：请使用应用或搜索电话号码。"
        m["Search for the taxi number"] = "搜索出租车电话"
        m["Italian radio taxi app: book and pay in the app"] = "意大利无线电出租车应用：在应用中叫车和付款"
        m["Taxis in many Italian cities"] = "意大利多个城市的出租车"
        m["Uber Taxi in cities where available"] = "Uber 出租车（在已开通的城市）"
        m["Where to get a taxi"] = "在哪里打车"
        m["No taxi rank mapped within 1.5 km. The rank is usually in front of the station's main exit."] = "1.5公里内未标注出租车停靠点。停靠点通常在车站正门前。"
        m["Local taxi companies"] = "本地出租车公司"
        m["Taxi ranks"] = "出租车停靠点"
        m["Ranks and phones from OpenStreetMap (volunteers), radio taxis from city services: check on site. 112 is for emergencies only."] = "停靠点和电话来自 OpenStreetMap（志愿者），无线电出租车来自城市服务：请现场核实。112仅用于紧急情况。"
        m["Tap to open the location"] = "点击打开位置"
        m["Tap to call"] = "点击拨打"
        m["Best prices"] = "最低价格"
        m["Choose origin and destination first."] = "请先选择出发地和目的地。"
        m["All trains"] = "所有列车"
        m["Lowest price for 1 adult among trains in that time band (LeFrecce · Trenitalia). Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "该时段列车中1名成人的最低价格（LeFrecce · Trenitalia）。点击格子查看方案。经济票价随余票变化：最终价格以结账时为准。"
        m["In short"] = "简要说明"
        m["Small animals (cats, small dogs, rabbits, birds) in a carrier: almost always free."] = "装在宠物箱里的小动物（猫、小型犬、兔子、鸟）：几乎都免费。"
        m["Larger dogs: leash and muzzle; a dog ticket is often needed."] = "较大的狗：须拴绳并戴口套；通常需要购买狗票。"
        m["Guide and assistance dogs: always free, on all trains and classes, with no time limits."] = "导盲犬和辅助犬：始终免费，所有列车和车厢等级均可，无时间限制。"
        m["Always carry the dog-registry certificate and health booklet (from abroad: EU pet passport)."] = "请始终携带犬只登记证明和健康手册（来自国外：欧盟宠物护照）。"
        m["The animal must not take up seats or disturb others: staff may ask you to leave if it causes danger or disturbance."] = "动物不得占用座位或打扰他人：如造成危险或干扰，工作人员可要求您下车。"
        m["Small animals in a carrier (max 70×30×50 cm): free within Lombardy."] = "装在宠物箱里的小动物（最大 70×30×50 厘米）：伦巴第境内免费。"
        m["Dogs of any size: muzzle, leash and dog-registry certificate; free within Lombardy."] = "任何体型的狗：须戴口套、拴绳并携带犬只登记证明；伦巴第境内免费。"
        m["Not allowed on weekdays (Monday–Friday) 7:00–9:30 and 17:30–19:30, small animals included. Guide dogs can always travel."] = "工作日（周一至周五）7:00–9:30 和 17:30–19:30 不允许携带，包括小动物。导盲犬随时可乘车。"
        m["Beyond Lombardy and to Switzerland an animal supplement is needed, under the rules of the operating company."] = "出伦巴第及前往瑞士需根据运营公司的规定支付动物附加费。"
        m["Malpensa Express: dogs travel free as luggage with a boarding pass; without one they pay the animal supplement."] = "Malpensa Express：持登机牌时狗可作为行李免费；无登机牌需支付动物附加费。"
        m["Small animals in a carrier (max 70×30×50 cm): always free, on all trains."] = "装在宠物箱里的小动物（最大 70×30×50 厘米）：所有列车均免费。"
        m["Regional trains: larger dogs travel with a 2nd-class ticket at 50% off, with leash and muzzle."] = "区域列车：较大的狗需购买二等座半价票，并须拴绳和戴口套。"
        m["Frecce and Intercity: a dog outside the carrier must be added when buying (\"Travel with your dog\"); the price is the one shown at checkout, with promotions in some periods (e.g. dogs free in summer)."] = "Frecce 和 Intercity：不在宠物箱内的狗须在购票时添加（\"Travel with your dog\"）；价格以结账时显示为准，部分时期有优惠（例如夏季狗免费）。"
        m["Documents: dog-registry certificate and health booklet; staff may ask for them. Assistance dogs are also allowed in bar/restaurant cars and replacement buses."] = "证件：犬只登记证明和健康手册；工作人员可能要求出示。辅助犬也可进入酒吧/餐车和替代巴士。"
        m["Small animals (up to about 5 kg) in a carrier: free."] = "装在宠物箱里的小动物（约5公斤以内）：免费。"
        m["Larger dogs: allowed in Smart and Prima by booking the \"Dog\" service (online or Pronto Italo 06 07 08, up to 2 hours before); always on a leash, muzzle when boarding/leaving or on request. Price shown at checkout."] = "较大的狗：可在 Smart 和 Prima 车厢乘坐，须预订“Dog”服务（网上或拨打 Pronto Italo 06 07 08，最晚出发前2小时）；须始终拴绳，上下车时或应要求时戴口套。价格以结账时显示为准。"
        m["Guide dogs: free, any size."] = "导盲犬：免费，任何体型。"
        m["Switzerland · SBB and TILO"] = "瑞士 · SBB 和 TILO"
        m["Dogs up to 30 cm at the withers and other small animals in a bag or carrier: free, as hand luggage."] = "肩高30厘米以下的狗和其他小动物装在包或宠物箱内：免费，作为手提行李。"
        m["Larger dogs (or outside a carrier): half the 2nd-class fare, or the dog day pass CHF 25 (also valid on buses, trams and boats); dog pass CHF 60 a month or CHF 350 a year."] = "较大的狗（或不在宠物箱内）：二等座半价，或购买狗日票 25 瑞士法郎（也可乘坐公交、有轨电车和船）；狗月票每月60瑞士法郎，年票350瑞士法郎。"
        m["The dog stays under your seat without blocking the aisle. Not allowed in restaurant cars (except guide and assistance dogs)."] = "狗须待在您的座位下方，不得堵塞通道。不得进入餐车（导盲犬和辅助犬除外）。"
        m["Rules from the operators' official pages (October 2026). Prices and promotions change: before travelling check the operator's page with the button above."] = "规定来自运营方官方页面（2026年10月）。价格和优惠会变动：出行前请用上方按钮查看运营方页面。"
        m["Official page "] = "官方页面 "
        m["Enter town or station"] = "输入城镇或车站"
        m["Clear"] = "清除"
        m["Near me"] = "我附近"
        m["Show map"] = "显示地图"
        m["Show list"] = "显示列表"
        m["towards "] = "前往 "
        m["straight ahead"] = "正前方"
        m["to your right"] = "在您右侧"
        m["behind you"] = "在您身后"
        m["to your left"] = "在您左侧"
        m["ahead on the right"] = "右前方"
        m["ahead on the left"] = "左前方"
        m["behind on the right"] = "右后方"
        m["behind on the left"] = "左后方"
        m["metres"] = "米"
        m["Travelling, near the station of "] = "行进中，靠近车站 "
        m["You are at "] = "您在 "
        m["Warning, out of service: "] = "注意，停用中："
        m["You have arrived: "] = "您已到达："
        m["Explore"] = "探索"
        m["Categories"] = "类别"
        m["Guiding you to: "] = "正在引导您前往："
        m["Walking navigation"] = "步行导航"
        m["Stop guiding"] = "停止引导"
        m["Location permission is needed to explore."] = "探索需要位置权限。"
        m["Finding your position… Turn on GPS."] = "正在获取您的位置… 请打开GPS。"
        m["Guiding you to "] = "正在引导您前往 "
        m["Exploring. I'll tell you about nearby stations, platforms, lifts, stairs and services."] = "正在探索。我会告诉您附近的车站、站台、电梯、楼梯和服务。"
        m["Exploring stopped."] = "探索已停止。"
        m["Stop exploring"] = "停止探索"
        m["Start spoken exploration"] = "开始语音探索"
        m["Nearest station: "] = "最近的车站："
        m["You are moving at "] = "您的移动速度："
        m["No useful places found nearby."] = "附近没有找到有用的地点。"
        m["Where am I? Tell me"] = "我在哪里？告诉我"
        m["Last announcement"] = "上一条播报"
        m["GPS accuracy: "] = "GPS 精度："
        m[" · no compass: directions by compass points"] = " · 无指南针：按方位指示方向"
        m["Hold the phone in front of you: \"12 o'clock\" is ahead, \"3\" right, \"9\" left. In stations GPS can be off by a few metres: ask staff or the Sale Blu for help (More → Disability assistance)."] = "把手机举在面前：“12点”是正前方，“3点”是右边，“9点”是左边。在车站内GPS可能偏差几米：请向工作人员或 Sale Blu 求助（更多 → 残障协助）。"
        m["None of these mapped nearby (300 m)."] = "附近（300米）没有标注这些地点。"
        m["Guide me"] = "引导我"
        m["Board"] = "时刻牌"
        m["No results for "] = "没有结果："
        m["Found "] = "找到 "
        m[" results. First: "] = " 个结果。第一个："
        m["Place, address, station…"] = "地点、地址、车站…"
        m["Voice search"] = "语音搜索"
        m["Save this spot"] = "保存此位置"
        m["E.g. \"Platform 3, front of the train\", \"Lift by the café\", \"Taxi exit\": then \"Guide me\" brings you back. Favourite stations and trains are in the Stations and Trains tabs."] = "例如“3号站台，列车前部”、“咖啡馆旁的电梯”、“出租车出口”：之后点“引导我”即可带您回来。收藏的车站和列车在“车站”和“列车”页中。"
        m["No saved places."] = "没有保存的地点。"
        m["Name"] = "名称"
        m["Current position, accuracy ±"] = "当前位置，精度 ±"
        m["Saved spot"] = "已保存的位置"
        m["Saved: "] = "已保存："
        m["No solutions found for the chosen time."] = "所选时间未找到方案。"
        m["Cannot reach the server. Check your connection."] = "无法连接服务器。请检查网络。"
        m["Departing from "] = "出发时间从 "
        m["FASTEST"] = "最快"
        m[" · first train +"] = " · 首班车 +"
        m["Not reachable now: "] = "暂时无法访问："
        m["Train "] = "列车 "
        m["I'll remind you at "] = "我会提醒您，时间："
        m["Where to catch the bus when trains don't run · Trenord, Trenitalia, TILO"] = "火车停运时在哪里坐巴士 · Trenord、Trenitalia、TILO"
        m["The nearest to you · call 112"] = "离您最近的 · 拨打112"
        m["FERROVIENORD · source: ferrovienord.it (station accessibility notices). Assistance: 800 210 955"] = "FERROVIENORD · 来源：ferrovienord.it（车站无障碍通知）。协助：800 210 955"
        m["Show later trains (+6 hours)"] = "显示之后的列车（+6小时）"
        m["Platform "] = "站台 "
        m["What to do right away"] = "立即要做的事"
        m["If you are still on the train or in the station, tell the conductor or staff straight away: it's the fastest way to find it."] = "如果您还在车上或车站，请立即告知列车长或工作人员：这是最快的找回方式。"
        m["Note the train number, day, time, coach and seat, and describe the item well (brand, colour, contents)."] = "记下车次、日期、时间、车厢和座位，并详细描述物品（品牌、颜色、内容）。"
        m["Contact the train's operator (below): each has its own lost property service."] = "联系该列车的运营方（见下方）：每家都有自己的失物招领服务。"
        m["Documents, cards or phone: block your cards and, for theft or documents, report it to the Railway Police (Polfer) or Carabinieri."] = "证件、银行卡或手机：请冻结银行卡；如被盗或丢失证件，请向铁路警察（Polfer）或宪兵报案。"
        m["After a few days unclaimed items go to the town's lost property office: ask there."] = "几天后无人认领的物品会送到当地市政失物招领处：请去那里询问。"
        m["The train you are following: "] = "您正在跟踪的列车："
        m["Trenord, Malpensa Express and FerrovieNord stations"] = "Trenord、Malpensa Express 和 FerrovieNord 车站"
        m["Trenord Contact Center: items lost on trains or platforms"] = "Trenord 客服中心：在列车或站台遗失的物品"
        m["Found items are kept at the My Link Points in Milano Cadorna and Milano Porta Garibaldi for a few days (up to 6), then go to the City of Milan lost property office."] = "找到的物品会在 Milano Cadorna 和 Milano Porta Garibaldi 的 My Link Point 保管几天（最多6天），之后送到米兰市失物招领处。"
        m["City of Milan · Lost property"] = "米兰市 · 失物招领"
        m["Via Friuli 30, Milan · 02 884 53900"] = "Via Friuli 30, 米兰 · 02 884 53900"
        m["Trenord lost property page"] = "Trenord 失物招领页面"
        m["Frecce: go to the Frecciadesk or customer service in the station as soon as you notice, staff can have your seat checked. Regional and Intercity: found items are usually handed to the lost property office of the town where the train terminates."] = "Frecce：一发现就前往车站的 Frecciadesk 或客服处，工作人员可安排检查您的座位。区域列车和 Intercity：找到的物品通常交给列车终点站所在城镇的失物招领处。"
        m["Lost items search service"] = "失物查询服务"
        m["Customer service offices"] = "客服办公室"
        m["Pronto Italo, daily 7–23: report the item with train number, coach and seat"] = "Pronto Italo，每天 7–23 点：报失时请提供车次、车厢和座位"
        m["Report the loss online"] = "在线报失"
        m["SBB Contact Center, 24 hours"] = "SBB 客服中心，24小时"
        m["On collection you pay CHF 20 (CHF 10 with a GA travelcard); electronics and bulky items CHF 25 (CHF 15). On TILO trains between Italy and Switzerland report to both SBB and Trenord."] = "领取时需付 20 瑞士法郎（持 GA 通票 10 瑞士法郎）；电子设备和大件物品 25 瑞士法郎（15 瑞士法郎）。在意大利和瑞士之间的 TILO 列车上，请同时向 SBB 和 Trenord 报失。"
        m["Information from the official Trenord, Trenitalia and SBB pages (October 2026): times and procedures may change."] = "信息来自 Trenord、Trenitalia 和 SBB 官方页面（2026年10月）：时间和流程可能变动。"
        m["Location not available: search a town or station."] = "位置不可用：请搜索城镇或车站。"
        m["Search a town or station above."] = "请在上方搜索城镇或车站。"
        m["Looking for defibrillators…"] = "正在查找除颤器…"
        m["Looking for defibrillators within "] = "正在查找除颤器，范围 "
        m["Station "] = "车站 "
        m["Station AED: usually on the outside wall, in a marked case"] = "车站 AED：通常在外墙上，装在有标识的箱子里"
        m["ferrovienord.it · AEDs in all FERROVIENORD stations"] = "ferrovienord.it · 所有 FERROVIENORD 车站都有 AED"
        m["Defibrillator"] = "除颤器"
        m["Emilia-Romagna regional AED register (open data)"] = "艾米利亚-罗马涅大区 AED 登记册（开放数据）"
        m["OpenStreetMap (volunteers): check on site"] = "OpenStreetMap（志愿者）：请现场核实"
        m["OpenStreetMap servers are not responding: use the official map below or retry."] = "OpenStreetMap 服务器无响应：请使用下方官方地图或重试。"
        m["Defibrillators"] = "除颤器"
        m["Emergency: call "] = "紧急情况：拨打 "
        m["The operator guides you through CPR and tells you where the nearest AED is. AEDs can be used on children too and give voice instructions."] = "接线员会指导您进行心肺复苏，并告诉您最近的 AED 在哪里。AED 也可用于儿童，并有语音指示。"
        m["Public access"] = "公众可用"
        m["Always available"] = "全天可用"
        m["Outdoors"] = "室外"
        m["Nearby defibrillators"] = "附近的除颤器"
        m["No defibrillator in the open lists here. Call 112: the dispatch centre knows all registered AEDs and guides you."] = "开放列表中这里没有除颤器。请拨打112：急救中心知道所有登记的 AED 并会指导您。"
        m["Where to get help nearby"] = "附近可求助的地方"
        m["Emergency departments and pharmacies: many pharmacies have an AED, but it isn't guaranteed."] = "急诊科和药店：许多药店有 AED，但不能保证。"
        m["Official maps and sources"] = "官方地图与来源"
        m["AREU Lombardy · AED map (official)"] = "AREU 伦巴第 · AED 地图（官方）"
        m["Ticino Cuore · AEDs in Ticino"] = "Ticino Cuore · 提契诺的 AED"
        m["FERROVIENORD · station AEDs"] = "FERROVIENORD · 车站 AED"
        m["FERROVIENORD: 125 AEDs installed in 2022–2023 in all its stations, where possible on the outside wall so they can be reached at night, in alarmed cases linked to 112/118 dispatch. Other AEDs come from OpenStreetMap (volunteers): check on site. Trenitalia/RFI, Italo and SBB don't publish a list of station AEDs: ask staff or call 112 (144 in Switzerland)."] = "FERROVIENORD：2022–2023年在其所有车站安装了125台 AED，尽可能装在外墙上以便夜间取用，装在带报警的箱子里并与112/118急救中心联网。其他 AED 来自 OpenStreetMap（志愿者）：请现场核实。Trenitalia/RFI、Italo 和 SBB 未公布车站 AED 列表：请询问工作人员或拨打112（瑞士为144）。"
        m["Tap again for directions"] = "再次点击获取路线"
        m["Searched place"] = "搜索的地点"
        m["Hospital · ask for help here"] = "医院 · 可在此求助"
        m["Pharmacy · ask if they have an AED"] = "药店 · 询问是否有 AED"
        m["Operator not stated"] = "未注明管理方"
        m["Available 24/7"] = "全天24小时可用"
        m["Restricted access"] = "限制进入"
        m["At or next to a station"] = "在车站内或车站旁"
        m["Source: "] = "来源："
        m["Get directions"] = "获取路线"
        m["View on MapComplete"] = "在 MapComplete 上查看"
        m["Nearest defibrillator"] = "最近的除颤器"
        m["List and map of AEDs · tap to see them"] = "AED 列表和地图 · 点击查看"
        m["Complete official list"] = "完整官方列表"
        m["⏳ Waiting for official AREU data: Binario has asked to use Lombardy's official defibrillator register. Until permission arrives the list below may be incomplete: open the official AREU map to see them all."] = "⏳ 等待 AREU 官方数据：Binario 已申请使用伦巴第官方除颤器登记册。在获得许可之前，下方列表可能不完整：请打开 AREU 官方地图查看全部。"
        m["Below are the AEDs from open lists (OpenStreetMap, FERROVIENORD, Emilia-Romagna register)."] = "以下是开放列表中的 AED（OpenStreetMap、FERROVIENORD、艾米利亚-罗马涅登记册）。"
        m["Official AREU map"] = "AREU 官方地图"
        m["Ticino Cuore map"] = "Ticino Cuore 地图"
        m["Search Google Maps"] = "在 Google 地图上搜索"
        m["Station coordinates not available: search a town or station."] = "车站坐标不可用：请搜索城镇或车站。"
        m["Location not available: turn on GPS or search a town or station."] = "位置不可用：请打开GPS或搜索城镇或车站。"
        m["Location permission needed, or search a town or station."] = "需要位置权限，或搜索城镇或车站。"
        m["Looking for public toilets within"] = "正在查找公共卫生间，范围"
        m["Place not found: try the town or station name."] = "未找到地点：请尝试城镇或车站名称。"
        m["Accessible"] = "无障碍"
        m["Baby changing"] = "婴儿护理"
        m["Open to all"] = "对所有人开放"
        m["near"] = "附近"
        m["No public toilets mapped here with these filters."] = "按这些筛选条件，这里没有标注公共卫生间。"
        m["Data © OpenStreetMap, the same as the MapComplete \"Public toilets\" map ("] = "数据 © OpenStreetMap，与 MapComplete \"公共卫生间\" 地图相同（"
        m["Prices, hours and accessibility are entered by volunteers: check on site. If something is wrong you can fix it via \"View on MapComplete\"."] = "价格、开放时间和无障碍信息由志愿者录入：请现场核实。如有错误，可通过“在 MapComplete 上查看”修正。"
        m["Public toilet"] = "公共卫生间"
        m["♿ Wheelchair accessible"] = "♿ 轮椅可通行"
        m["♿ Partly accessible"] = "♿ 部分无障碍"
        m["Not wheelchair accessible"] = "轮椅无法通行"
        m["🚼 Baby changing table"] = "🚼 婴儿护理台"
        m["Unisex"] = "男女通用"
        m["Men and women"] = "男女分开"
        m["Men only"] = "仅限男性"
        m["Women only"] = "仅限女性"
        m["Seated and urinals"] = "坐便器和小便池"
        m["Urinals only"] = "仅有小便池"
        m["Squat toilet"] = "蹲便"
        m["Seated"] = "坐便"
        m["toilet paper"] = "卫生纸"
        m["hand washing"] = "洗手"
        m["With "] = "提供 "
        m["Customers only"] = "仅限顾客"
        m["Not open to the public"] = "不对公众开放"
        m["Level"] = "楼层"
        m["Operated by"] = "管理方"
        m["Calculation failed"] = "计算失败"
        m["Edit"] = "编辑"
        m["Every day (round trip)"] = "每天（往返）"
        m["of CO₂ saved"] = "节省的二氧化碳"
        m["saved"] = "节省"
        m["extra cost"] = "额外费用"
        m["Travel time (one way)"] = "单程时间"
        m["avg delay"] = "平均延误"
        m["Car"] = "汽车"
        m["free flow"] = "畅通"
        m["rush hour"] = "高峰时段"
        m["Daily breakdown (round trip)"] = "每日明细（往返）"
        m["yours"] = "您的"
        m["Road distance"] = "道路距离"
        m["of which tolled"] = "其中收费路段"
        m["Consumption"] = "油耗"
        m["Fuel"] = "燃料"
        m["Motorway tolls"] = "高速公路通行费"
        m[" (estimate)"] = " （估算）"
        m["Parking"] = "停车"
        m["Car total"] = "汽车总计"
        m["Train (daily share of pass)"] = "火车（月票每日分摊）"
        m["Tap an item with ✎ to enter your own value: everything is recalculated at once and saved."] = "点击带 ✎ 的项目输入您自己的数值：所有数据会立即重新计算并保存。"
        m["Car CO₂"] = "汽车二氧化碳"
        m["Train CO₂"] = "火车二氧化碳"
        m["CO₂ avoided"] = "避免的二氧化碳"
        m["Road distance (one way)"] = "道路距离（单程）"
        m["Tolls per day (round trip)"] = "每日通行费（往返）"
        m["Fuel price"] = "燃料价格"
        m["Parking per day"] = "每日停车费"
        m["Train pass per month"] = "每月火车月票"
        m["Car consumption"] = "汽车油耗"
        m["Back to the app's estimate"] = "恢复为应用的估算值"
        m["Save and recalculate"] = "保存并重新计算"
        m["Trip and delay log"] = "行程与延误记录"
    }

    private fun p4(m: HashMap<String, String>) {
        m[" · avg delay "] = " · 平均延误 "
        m[" · max "] = " · 最长 "
        m["Remove today"] = "删除今天"
        m["out "] = "去程 "
        m["  back "] = "  返程 "
        m["On travel days after 9 pm the app automatically logs the delays of your usual trains."] = "在出行日晚上9点后，应用会自动记录您常坐列车的延误。"
        m["Your commute"] = "您的通勤"
        m["choose"] = "选择"
        m["To: "] = "到："
        m["Outbound train"] = "去程列车"
        m["Return train"] = "返程列车"
        m["Travel days"] = "出行日"
        m["M"] = "一"
        m["W"] = "三"
        m["T"] = "四"
        m["F"] = "五"
        m["S"] = "六"
        m["Car fuel"] = "汽车燃料"
        m["Consumption l/100 km"] = "油耗 升/100公里"
        m["Parking € per day"] = "每日停车费（欧元）"
        m["Train pass € per month"] = "每月火车月票（欧元）"
        m["Calculate"] = "计算"
        m["A network error occurred. Please try again."] = "发生网络错误。请重试。"
        m[". You can follow the train with voice alerts."] = "。您可以用语音提醒跟踪这趟列车。"
        m["Ask about a train, station or route"] = "询问列车、车站或路线"
        m["Speech recognition is not available on this phone. Install or enable the Google app."] = "此手机不支持语音识别。请安装或启用 Google 应用。"
        m["Read aloud on"] = "朗读已开启"
        m["Read aloud off"] = "朗读已关闭"
        m["Open train"] = "打开列车"
        m["Following the train. I will give you voice alerts."] = "正在跟踪列车。我会用语音提醒您。"
        m["Follow with voice alerts"] = "用语音提醒跟踪"
        m["Open station"] = "打开车站"
        m["Where is my train?"] = "我的列车在哪里？"
        m["Any strikes?"] = "有罢工吗？"
        m["Can I bring my bike?"] = "可以带自行车吗？"
        m["Disability assistance"] = "残障协助"
        m["e.g. delay train 2070"] = "例如 延误 列车 2070"
        m["Speak: ask a question"] = "说话：提一个问题"
        m["Finding the station…"] = "正在查找车站…"
        m["Search a station or town above."] = "请在上方搜索车站或城镇。"
        m["Location not available: search a station."] = "位置不可用：请搜索车站。"
        m["No station found."] = "未找到车站。"
        m["Place not found: try the station name."] = "未找到地点：请尝试车站名称。"
        m["Looking for replacement buses at"] = "正在查找替代巴士，地点"
        m["Other operators"] = "其他运营方"
        m["Replacement bus stop"] = "替代巴士站"
        m["Replacement buses in the next 6 hours"] = "未来6小时的替代巴士"
        m["Timetable services are not responding: retry or check the official pages below."] = "时刻表服务无响应：请重试或查看下方官方页面。"
        m["No replacement buses scheduled here in the next hours according to official timetables. After sudden disruptions buses may not be in the timetables yet: check the official pages and station announcements."] = "根据官方时刻表，未来几小时这里没有安排替代巴士。突发中断后巴士可能尚未列入时刻表：请查看官方页面和车站广播。"
        m["Sources: official GTFS timetables of Trenord, Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements."] = "来源：Trenord、Trenitalia 和 SBB 的官方 GTFS 时刻表，经 Transitous（transitous.org）获取；时刻牌上的巴士来自 ViaggiaTreno（RFI）。每个班次都注明来源。时刻为计划时刻：中断期间请以车站广播为准。"
        m["Board at: "] = "上车地点："
        m[" from the station"] = " 距车站"
        m["Bay / platform: "] = "车位 / 站台："
        m["Real time"] = "实时"
        m["Scheduled time"] = "计划时间"
        m["Directions to the stop"] = "前往站点的路线"
        m["My region"] = "我的地区"
        m["My route and times"] = "我的路线和时间"
        m["National strikes and in: "] = "全国罢工以及："
        m["back "] = "返程 "
        m["Set your route and the time of your outbound and/or return train"] = "设置您的路线以及去程和/或返程列车的时间"
        m["Mon"] = "周一"
        m["Tue"] = "周二"
        m["Wed"] = "周三"
        m["Thu"] = "周四"
        m["Fri"] = "周五"
        m["Sat"] = "周六"
        m["Sun"] = "周日"
        m["Mon–Fri"] = "周一至周五"
        m["every day"] = "每天"
        m["My route"] = "我的路线"
        m["Out "] = "去程 "
        m["Back "] = "返程 "
        m["No outbound"] = "无去程"
        m["No return"] = "无返程"
        m["Days"] = "日期"
        m["Operators you use"] = "您乘坐的运营方"
        m["Regions (also for the \"My region\" filter)"] = "地区（也用于“我的地区”筛选）"
        m["A strike shows in \"My route\" if it is national or in one of your regions, involves one of your operators (or all) and its hours cover your outbound or return train on one of your travel days."] = "如果罢工是全国性的或在您的某个地区、涉及您的某个运营方（或全部），且其时段覆盖您某个出行日的去程或返程列车，就会显示在“我的路线”中。"
        m["arrival at "] = "到达 "
        m["Arrival "] = "到达 "
        m["Departure "] = "出发 "
        m["On Xiaomi: Settings → Apps → Binario → Battery saver → No restrictions, and also enable \"Autostart\"."] = "小米手机：设置 → 应用 → Binario → 省电策略 → 无限制，并开启“自启动”。"
        m["On Oppo, Realme and OnePlus: Settings → Apps → Binario → Battery usage → allow background activity and auto launch."] = "Oppo、Realme 和 OnePlus：设置 → 应用 → Binario → 耗电管理 → 允许后台活动和自动启动。"
        m["On Huawei and Honor: Settings → Battery → App launch → Binario → manage manually, with all three options on."] = "华为和荣耀：设置 → 电池 → 应用启动管理 → Binario → 手动管理，三个选项全部打开。"
        m["On Samsung: Settings → Apps → Binario → Battery → Unrestricted, and remove Binario from \"Sleeping apps\"."] = "三星：设置 → 应用 → Binario → 电池 → 不受限制，并将 Binario 从“休眠应用”中移除。"
        m["On Vivo: Settings → Battery → Background power consumption → allow Binario."] = "Vivo：设置 → 电池 → 后台耗电管理 → 允许 Binario。"
        m["If the followed train stops by itself: Settings → Apps → Binario → Battery → Unrestricted."] = "如果跟踪的列车自行停止：设置 → 应用 → Binario → 电池 → 不受限制。"
        m["Alerts even with the app closed"] = "应用关闭时也能收到提醒"
        m["The train is followed even with Binario closed. Some phones, however, stop the alerts after a while to save battery. To avoid missing platform, delays and the wake-up alarm, allow Binario to run without battery restrictions: consumption stays low and it stops by itself on arrival."] = "即使关闭 Binario 也会继续跟踪列车。但部分手机为了省电会在一段时间后停止提醒。为避免错过站台、延误和到站闹钟，请允许 Binario 不受电池限制运行：耗电很低，到达后会自动停止。"
        m["Guide for your phone"] = "您手机的设置指南"
        m["Not now"] = "暂不"
        m["Infrastructure manager of the Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa and Brescia–Iseo–Edolo network. Trains are run by Trenord."] = "负责 Milano Cadorna–Saronno–Varese、Como、Novara、Laveno、Asso、Seregno、Malpensa 和 Brescia–Iseo–Edolo 线网的基础设施管理方。列车由 Trenord 运营。"
        m["Lifts and escalators out of service"] = "停用的电梯和自动扶梯"
        m["The FERROVIENORD site is not responding. Open the official page or retry."] = "FERROVIENORD 网站无响应。请打开官方页面或重试。"
        m["No equipment reported out of service."] = "未报告停用设备。"
        m["No equipment out of service at this station."] = "此车站没有停用设备。"
        m["Platform not accessible: "] = "站台无法通行："
        m["Out of service since "] = "停用起始："
        m["Expected back: "] = "预计恢复："
        m["Source: ferrovienord.it · Station accessibility notices (read now, refreshed every 30 minutes)."] = "来源：ferrovienord.it · 车站无障碍通知（当前读取，每30分钟刷新）。"
        m["Accessibility and assistance"] = "无障碍与协助"
        m["Live lift and escalator status"] = "电梯和自动扶梯实时状态"
        m["Assistance for disabled passengers: 800 210 955"] = "残障旅客协助：800 210 955"
        m["Trenord/FERROVIENORD free number · book at least 48 hours ahead"] = "Trenord/FERROVIENORD 免费电话 · 请至少提前48小时预约"
        m["Assistance request by email"] = "通过电子邮件申请协助"
        m["Book assistance online"] = "在线预约协助"
        m["Station accessibility sheets · Milan branches"] = "车站无障碍信息表 · 米兰各线"
        m["Station accessibility sheets · Brescia–Iseo–Edolo"] = "车站无障碍信息表 · Brescia–Iseo–Edolo"
        m["Station accessibility and reduced mobility"] = "车站无障碍与行动不便"
        m["Every FERROVIENORD station has a defibrillator (125 installed in 2022–2023): where possible on the outside wall so it can be reached at night, in an alarmed, marked case with a first-aid kit. It is remotely monitored and registered with the regional emergency centres. It can be used on children too. In an emergency call 112."] = "每个 FERROVIENORD 车站都有一台除颤器（2022–2023年共安装125台）：尽可能装在外墙上以便夜间取用，放在带报警、有标识的箱子里，并配有急救包。设备受远程监控，并在大区急救中心登记。也可用于儿童。紧急情况请拨打112。"
        m["Map of nearby defibrillators"] = "附近除颤器地图"
        m["FERROVIENORD stations and other AEDs"] = "FERROVIENORD 车站和其他 AED"
        m["Defibrillators page"] = "除颤器页面"
        m["Network documents (PIR web)"] = "线网文件（PIR web）"
        m["Service quality indicators 2026"] = "2026年服务质量指标"
        m["Line and facility characteristics"] = "线路和设施特性"
        m["Station usage plan"] = "车站使用计划"
        m["Station upgrades for reduced mobility"] = "面向行动不便人士的车站改造"
        m["Network statement"] = "线网说明书"
        m["All documents"] = "全部文件"
        m["Sources: ferrovienord.it (PIR web, station accessibility notices, defibrillators) and trenord.it (assistance). Restore dates are the manager's estimates."] = "来源：ferrovienord.it（PIR web、车站无障碍通知、除颤器）和 trenord.it（协助）。恢复日期为管理方的估计。"
        m["Customer service"] = "客服处"
        m["Validators & more"] = "验票机及其他"
        m[" (open/closed from Trenord)"] = " （营业状态来自 Trenord）"
        m["trenitalia.com · Customer service offices (April 2025 hours)"] = "trenitalia.com · 客服办公室（2025年4月的营业时间）"
        m["italotreno.com · Station ticket offices"] = "italotreno.com · 车站售票处"
        m["SBB open data (data.sbb.ch)"] = "SBB 开放数据（data.sbb.ch）"
        m["Loading sales points…"] = "正在加载售票点…"
        m["you"] = "您"
        m["nearest to"] = "距离最近："
        m["Trenord sales points are in Lombardy. Nearby: SBB machines, altoadigemobilità and OpenStreetMap points; elsewhere in Italy use the official Trenitalia map (at the bottom)."] = "Trenord 售票点在伦巴第。附近有：SBB 售票机、altoadigemobilità 和 OpenStreetMap 网点；在意大利其他地区请使用 Trenitalia 官方地图（见底部）。"
        m["Open/closed updated now from Trenord for the province of"] = "营业状态已根据 Trenord 实时更新，省份："
        m["No sales points found."] = "未找到售票点。"
        m["Showing the nearest 300: search a town or station for the others."] = "显示最近的300个：其他请搜索城镇或车站。"
        m["Distance: "] = "距离："
        m["Sells: "] = "出售："
        m["Weekly opening hours"] = "每周营业时间"
        m["Visit the page"] = "访问页面"
        m["Card"] = "银行卡"
        m["Coins"] = "硬币"
        m[", limited operation"] = "，功能受限"
        m["*Limited operation"] = "*功能受限"
        m["closed"] = "关闭"
        m["Trenord offices, machines and resellers"] = "Trenord 售票处、售票机和代售点"
        m["open/closed read now"] = "营业状态实时读取"
        m["SBB ticket machines (data.sbb.ch)"] = "SBB 售票机（data.sbb.ch）"
        m["other points from"] = "其他网点来自"
        m["1 machine"] = "1台售票机"
        m["machines"] = "台售票机"
        m["Overview"] = "概览"
        m["Statistics not available right now."] = "统计数据暂不可用。"
        m["Search station"] = "搜索车站"
        m["Train number or destination"] = "车次或目的地"
        m["Least punctual"] = "最不准点"
        m["Most punctual"] = "最准点"
        m["FerrovieNord network"] = "FerrovieNord 线网"
        m["Milan Passante"] = "米兰 Passante"
        m["collected by the app · "] = "由应用收集 · "
        m[" days"] = " 天"
        m["No results"] = "无结果"
        m["on time (within 5 min)"] = "准点（5分钟以内）"
        m[" points vs "] = " 个百分点，相比 "
        m["arrivals observed"] = "观察到的到达"
        m["cancelled runs"] = "停运班次"
        m["Avg delay "] = "平均延误 "
        m[" arrivals"] = " 次到达"
        m[" cancelled"] = " 停运"
        m[" trains"] = " 趟列车"
        m["Your trains"] = "您的列车"
        m["Your stations"] = "您的车站"
        m["Switzerland · SBB"] = "瑞士 · SBB"
        m["SBB data not reachable right now."] = "暂时无法获取 SBB 数据。"
        m[" stop arrivals"] = " 次停站到达"
        m[" cancelled stops"] = " 次停站取消"
        m["Data for "] = "数据日期："
        m["Average of "] = "平均值："
        m[" days ("] = " 天（"
        m["Why BLS, SOB, Rhaetian Railway and the other Swiss companies are missing"] = "为什么缺少 BLS、SOB、雷蒂亚铁路和其他瑞士公司"
        m["FerrovieNord network · Trenord"] = "FerrovieNord 线网 · Trenord"
        m["Collection just started: first data after a few hours, reliable figures after a couple of weeks."] = "刚开始收集：几小时后有首批数据，几周后数据才可靠。"
        m["Today's data"] = "今日数据"
        m["Last "] = "最近 "
        m[" days collected ("] = " 天收集的数据（"
        m["Stations are in the Stations tab (FerrovieNord filter)."] = "车站在“车站”页中（FerrovieNord 筛选）。"
        m["Collection on"] = "收集日期"
        m[" runs"] = " 个班次"
        m[" severe delays"] = " 严重延误"
        m["recent days (collected by the app)"] = "最近几天（由应用收集）"
        m[" runs observed"] = " 个观察到的班次"
        m["Recent punctuality (FN network): "] = "近期准点率（FN 线网）："
        m["Last month punctuality: "] = "上月准点率："
        m["avg delay "] = "平均延误 "
        m[". On time = arrival within 5 minutes."] = "。准点 = 5分钟内到达。"
        m["How shall I find your train? Type its number, or I find the station nearest to you, or pick a station and time."] = "我该如何找到您的列车？输入车次，或者我找离您最近的车站，或者选择车站和时间。"
        m["No sign-up needed and your data stays on the phone. To send you alerts I need permission for notifications: tap Allow."] = "无需注册，数据保存在手机上。为了给您发送提醒，我需要通知权限：请点击“允许”。"
        m["Without notifications I can only update you here in the app. You can turn them on any time in the phone settings."] = "没有通知权限，我只能在应用内告诉您。您可以随时在手机设置中开启。"
        m["I found this train: is it yours?"] = "我找到了这趟列车：是您的吗？"
        m["I can't connect. Check your connection and try again."] = "无法连接。请检查网络后重试。"
        m["plat. "] = "站台 "
        m["Without location I can't find the nearby station: pick the station yourself."] = "没有位置信息，我无法找到附近车站：请自己选择车站。"
        m["I can't find your location. Turn on location or pick the station."] = "我找不到您的位置。请打开定位或选择车站。"
        m["Station list unavailable, try again."] = "车站列表不可用，请重试。"
        m["I can't answer right now: check your connection."] = "我现在无法回答：请检查网络。"
        m["They said: "] = "对方说："
        m["Hold the phone close to the speaker"] = "把手机靠近说话的人"
        m["Say the train number or ask a question"] = "说出车次或提一个问题"
        m["Speech recognition isn't available on this phone: install or enable the Google app."] = "此手机不支持语音识别：请安装或启用 Google 应用。"
        m["I can't read this train's data right now. Try again shortly."] = "暂时无法读取这趟列车的数据。请稍后重试。"
        m["Where do you board?"] = "您在哪里上车？"
        m["I'll alert you when the platform is announced or changes, if the delay grows, if the train is cancelled"] = "站台公布或变更、延误增加、列车停运时，我都会提醒您"
        m[", and on arrival I'll send you a summary. Everything is in the ongoing notification too."] = "，到达时我会发给您一份总结。所有信息也会显示在常驻通知中。"
        m["Trip completed: I'm no longer following the train. Want to follow another one?"] = "行程结束：我已不再跟踪这趟列车。要跟踪另一趟吗？"
        m["OK, no more updates on this train."] = "好的，不再更新这趟列车。"
        m["Where do you get off? I'll warn you before the stop."] = "您在哪里下车？我会在到站前提醒您。"
        m["To the terminus"] = "到终点站"
        m["No alarm needed: follow to the terminus"] = "不需要闹钟：跟踪到终点站"
        m["+1 hour"] = "+1小时"
        m["+2 hours"] = "+2小时"
        m["+3 hours"] = "+3小时"
        m["Pick time"] = "选择时间"
        m["Type or say the train number (it's on your ticket or the board)."] = "输入或说出车次（在您的车票或时刻牌上）。"
        m["Station and time"] = "车站和时间"
        m["Follow another train"] = "跟踪另一趟列车"
        m["Delayed? Your rights"] = "晚点了？您的权利"
        m["Transcribe speech"] = "语音转文字"
        m["Let the phone speak"] = "让手机说话"
        m["Train number, e.g. 2070"] = "车次，例如 2070"
        m["Type a train number or a question"] = "输入车次或问题"
        m["Speak"] = "说话"
        m["Which station do you leave from?"] = "您从哪个车站出发？"
        m["platform "] = "站台 "
        m["platform not yet announced"] = "站台尚未公布"
        m["Next stop: "] = "下一站："
        m["Last seen: "] = "最后位置："
        m["They said"] = "对方说"
        m["I am deaf: could you please write it down?"] = "我是聋人：能请您写下来吗？"
        m["Which platform does the train leave from?"] = "列车从哪个站台出发？"
        m["Could you tell me when we reach my stop?"] = "到我的站时能告诉我吗？"
        m["How late is the train?"] = "列车晚点多久？"
        m["Where can I buy a ticket?"] = "在哪里可以买票？"
        m["Show the screen to the person in front of you: the phone is also reading it aloud."] = "把屏幕给对面的人看：手机也会大声读出来。"
        m["Type what you want to say"] = "输入您想说的话"
        m["Ready phrases"] = "常用语"
        m["Read aloud"] = "朗读"
        m["Assistance is free, in the station and for getting on and off the train."] = "协助服务免费，提供车站内及上下车协助。"
        m["It covers wheelchair users and people with walking difficulties (even temporary), blind or partially sighted, deaf or with communication difficulties, people with intellectual or mental disabilities, older people and pregnant women."] = "适用于轮椅使用者和行走困难者（包括暂时性的）、盲人或弱视者、聋人或沟通困难者、智力或精神障碍者、老年人和孕妇。"
        m["Who to call depends on the station and train: at RFI stations (almost all Italian stations) the Sale Blu assist for every operator; at FerrovieNord stations Trenord does; in Switzerland, SBB."] = "联系谁取决于车站和列车：在 RFI 车站（几乎所有意大利车站），Sale Blu 为所有运营方提供协助；在 FerrovieNord 车站由 Trenord 负责；在瑞士由 SBB 负责。"
        m["RFI Sale Blu · Trenitalia, Italo, Trenord at RFI stations"] = "RFI Sale Blu · RFI 车站的 Trenitalia、Italo、Trenord"
        m["Toll-free from landlines · daily 6:45–21:30"] = "固定电话免费 · 每天 6:45–21:30"
        m["From mobiles and abroad (standard rate)"] = "手机和国外拨打（标准费率）"
        m["At least 6 hours before: stations, date, train, type of assistance, phone"] = "至少提前6小时：车站、日期、车次、协助类型、电话"
        m["SalaBlu Online and SalaBlu+ app"] = "SalaBlu Online 和 SalaBlu+ 应用"
        m["Booking up to 3 hours before; chat for deaf people"] = "最晚提前3小时预约；为聋人提供聊天服务"
        m["How far ahead: at major stations (e.g. Milano Porta Garibaldi) up to 1 hour before for trains between 7:45 and 22:30; at other stations and at night at least 12 hours before. Groups of 3+: 24 hours. Trips abroad: 24–48 hours."] = "提前多久：在大站（例如 Milano Porta Garibaldi），7:45 至 22:30 之间的列车最晚提前1小时；其他车站和夜间至少提前12小时。3人以上团体：24小时。国际行程：24–48小时。"
        m["Be at the meeting point at least 30 minutes before: staff wear orange vests. To cancel, give at least 4 hours' notice."] = "请至少提前30分钟到达集合点：工作人员穿橙色背心。如需取消，请至少提前4小时通知。"
        m["Trenord and FerrovieNord stations"] = "Trenord 和 FerrovieNord 车站"
        m["Trenord assistance toll-free · book preferably 48 hours ahead"] = "Trenord 协助免费电话 · 最好提前48小时预约"
        m["Trenord contact centre (also from mobiles)"] = "Trenord 客服中心（手机也可拨打）"
        m["Information and bookings"] = "信息与预约"
        m["Report barriers between train and station"] = "报告列车与车站之间的障碍"
        m["Pronto Italo · daily 7–23: suitable seat and assistance booking (provided in station by RFI)"] = "Pronto Italo · 每天 7–23 点：合适座位和协助预约（由 RFI 在车站提供）"
        m["Italo assistance page"] = "Italo 协助页面"
        m["SBB Contact Center Handicap from Italy · daily 5–24 (from Switzerland 0800 007 102, free)"] = "SBB 残障客服中心，从意大利拨打 · 每天 5–24 点（从瑞士拨打 0800 007 102，免费）"
        m["Book online"] = "在线预约"
        m["swisspass.ch/handicap · at least 1 hour before (international trips 24 hours)"] = "swisspass.ch/handicap · 至少提前1小时（国际行程24小时）"
        m["Tips by type of disability"] = "按残障类型的建议"
        m["Wheelchair: boarding with ramp or lift. Wheelchair at most 70 cm wide, 120 cm long and 250 kg including the person. The station screen shows lifts per platform and current faults."] = "轮椅：通过坡道或升降机上车。轮椅宽度不超过70厘米、长度不超过120厘米、连人总重不超过250公斤。车站页面显示各站台电梯和当前故障。"
        m["Blind or partially sighted: guide dogs travel free; you can ask for a suitable seat when booking. Turn on the spoken option: the app tells you platform, departure and your stop."] = "盲人或弱视者：导盲犬免费乘车；预约时可要求合适的座位。开启语音选项：应用会告诉您站台、出发时间和下车站。"
        m["Deaf people: the Sale Blu have a chat (after registering on SalaBlu Online). In My Conductor use \"Transcribe speech\" and \"Let the phone speak\"; turn on vibration and flash alerts."] = "聋人：Sale Blu 提供聊天服务（在 SalaBlu Online 注册后）。在“我的列车长”中使用“语音转文字”和“让手机说话”；开启振动和闪光提醒。"
        m["Intellectual or mental disabilities, or people who are not self-sufficient: a companion may be needed; staff escort you from the meeting point to the train and connection."] = "智力或精神障碍者，或无法自理者：可能需要陪同人员；工作人员会从集合点护送您到列车和换乘处。"
        m["Older people, pregnant women, casts or temporary difficulties: assistance is for you too, with a wheelchair on request and help with one piece of hand luggage."] = "老年人、孕妇、打石膏或暂时有困难的人：协助也适用于您，可按需提供轮椅，并帮忙拿一件手提行李。"
        m["Connections: allow at least 30 minutes between trains when booking assistance."] = "换乘：预约协助时，两趟列车之间请至少预留30分钟。"
        m["Open My Conductor"] = "打开“我的列车长”"
        m["Emergency"] = "紧急情况"
        m["Single emergency number (Italy and Switzerland)"] = "统一紧急电话（意大利和瑞士）"
        m["Numbers and rules from the official RFI, Trenord, Italo and SBB pages (October 2026): if in doubt, check the operator's site."] = "电话和规定来自 RFI、Trenord、Italo 和 SBB 官方页面（2026年10月）：如有疑问，请查看运营方网站。"
        m["Page"] = "页面"
        m["Changes"] = "换乘"
        m["direct"] = "直达"
        m["Downloading outbound…"] = "正在下载去程…"
        m["Downloading return…"] = "正在下载返程…"
        m["No runs found for that day"] = "当天没有找到班次"
        m["Timetable for"] = "时刻表："
        m["runs"] = "个班次"
        m["No runs found."] = "未找到班次。"
        m["Real time from the operator · "] = "来自运营方的实时数据 · "
        m["Scheduled times: delays not published by the operator · "] = "计划时刻：运营方未公布延误 · "
        m["Departure station not found"] = "未找到出发站"
        m["Arrival station not found"] = "未找到到达站"
        m["responds but the format changed"] = "有响应但格式已变"
        m["OK (backup server: "] = "正常（备用服务器："
        m["no response"] = "无响应"
        m["Foreign operators (ÖBB, DB)"] = "外国运营方（ÖBB、DB）"
        m["Replacement bus"] = "替代巴士"
        m["SBB timetable (transport.opendata.ch)"] = "SBB 时刻表（transport.opendata.ch）"
        m["ViaggiaTreno (RFI) · station board"] = "ViaggiaTreno（RFI）· 车站时刻牌"
        m["Trenord · replacement bus map"] = "Trenord · 替代巴士地图"
        m["RFI · travel updates (works and replacement buses)"] = "RFI · 出行信息（施工和替代巴士）"
        m["SBB · S-Bahn and regional"] = "SBB · S-Bahn 和区域列车"
    }

    private fun p5(m: HashMap<String, String>) {
        m["Wi-Fi and sockets: on Frecce and Italo on-board Wi-Fi is free and there are power sockets at the seats. Regional trains usually have no Wi-Fi and only some new trains have sockets. In Switzerland many SBB stations have free Wi-Fi."] = "Wi-Fi和插座：Frecce和Italo车上Wi-Fi免费，座位旁有电源插座。区域列车通常没有Wi-Fi，只有部分新车有插座。在瑞士，许多SBB车站有免费Wi-Fi。"
        m["Seats: on Frecce, Intercity and Italo the seat is assigned with the ticket and you can choose it when buying (window, aisle…). Regional trains (Trenord, Trenitalia Regional, TILO) have no reservations: you sit wherever there is room."] = "座位：Frecce、Intercity和Italo的座位随车票分配，购票时可以选择（靠窗、靠过道等）。区域列车（Trenord、Trenitalia区域列车、TILO）不订座：有空位就可以坐。"
        m["First class: Frecciarossa trains have Standard, Premium, Business and Executive levels; Italo has Smart, Comfort, Prima and Club Executive. Many Trenord regional trains have 1st class, with a supplement of €2.80 per trip (€31 a month, €310 a year with a pass). In the search results you can see 1st-class prices with the \"1st class\" selector."] = "一等座：Frecciarossa有Standard、Premium、Business和Executive四个等级；Italo有Smart、Comfort、Prima和Club Executive。许多Trenord区域列车有一等座，每次需补价2.80欧元（持月票每月31欧元，每年310欧元）。在搜索结果中，用\"一等座\"选项可以查看一等座票价。"
        m["Ticket validity: it depends on the ticket. STIBM area (Milan and surroundings): 75 minutes for 2 zones, 90 minutes in the city, longer with more zones. Arcobaleno/Trenord cross-border tickets: 4 hours for the whole trip. Digital regional tickets are valid for the day or train shown; paper ones must be validated before boarding. Frecce and Italo: valid for the booked train."] = "车票有效期：取决于车票类型。STIBM区域（米兰及周边）：2个区75分钟，市内90分钟，区数越多时间越长。Arcobaleno/Trenord跨境车票：全程4小时。区域电子车票在票面所示日期或车次有效；纸质车票上车前需要打票。Frecce和Italo：仅限预订的车次。"
        m["Parking: many stations have a car park (often paid) and bike racks or bike stations. The app does not list car parks yet: open the map from the station screen and search for \"parking\"."] = "停车：许多车站有停车场（通常收费）和自行车架或自行车停放站。应用暂未列出停车场：请在车站页面打开地图，搜索\"停车场\"."
        m["Night trains: Trenitalia runs Intercity Notte trains (for example to southern Italy and Sicily); ÖBB Nightjets link Italy with Austria and Germany; in Ticino there is the TILO Pigiama night service on some nights. Search the route with an evening time."] = "夜车：Trenitalia开行Intercity Notte夜车（例如开往意大利南部和西西里）；ÖBB Nightjet连接意大利与奥地利、德国；在提契诺，部分夜晚有TILO Pigiama夜间服务。请用晚上的时间搜索路线。"
        m["Italo (NTV) is the private high-speed operator, on the high-speed lines between Turin, Milan, Venice, Bologna, Florence, Rome and Naples. Tickets are sold on italotreno.com, in the app, at Italo ticket offices and machines in stations; levels are Smart, Comfort, Prima and Club Executive. Binario shows Italo trains in the solutions and in real time. Pronto Italo: 06 07 08."] = "Italo（NTV）是私营高铁公司，运营都灵、米兰、威尼斯、博洛尼亚、佛罗伦萨、罗马和那不勒斯之间的高铁线路。车票可在italotreno.com、应用、车站的Italo售票处和售票机购买；等级有Smart、Comfort、Prima和Club Executive。Binario在行程和实时信息中显示Italo列车。Pronto Italo：06 07 08。"
        m["Food and drink: on every train you can eat and drink what you bring. Frecce have a bar/FRECCIABistrò, Italo offers snacks and drinks; regional trains have no catering."] = "餐饮：所有列车上都可以吃喝自带的食物。Frecce有餐吧/FRECCIABistrò，Italo提供零食和饮料；区域列车没有餐饮服务。"
        m["Smoking is forbidden on all trains and in enclosed station areas, e-cigarettes on board included. Smokers risk a fine."] = "所有列车和车站室内区域都禁止吸烟，车上也禁止使用电子烟。吸烟者可能会被罚款。"
        m["Discounts: Trenitalia has Economy and Super Economy fares (limited seats), discounts for young people and over-60s with CartaFRECCIA, and group offers. Italo has Low Cost and Economy fares and the Italo Più programme. In Lombardy Trenord has reduced passes for under-26s and over-65s and the Io Viaggio in Famiglia family discount. The app's \"Best prices\" calendar shows the lowest prices by time of day."] = "优惠：Trenitalia有Economy和Super Economy票价（名额有限）、持CartaFRECCIA的青年和60岁以上优惠，以及团体优惠。Italo有Low Cost和Economy票价以及Italo Più计划。在伦巴第，Trenord有26岁以下和65岁以上的优惠月票，以及家庭优惠Io Viaggio in Famiglia。应用的\"最低票价\"日历按时段显示最低价格。"
        m["Groups: Trenitalia and Italo have group offers (usually from 10 people, to be requested in advance); Trenord has tickets for groups and school classes. Conditions and forms are on the operators' websites."] = "团体：Trenitalia和Italo有团体优惠（通常10人起，需提前申请）；Trenord有团体票和学生团体票。条件和申请表见各公司网站。"
        m["Minors travelling alone: the rules differ between operators. In general older children can travel alone with a valid ticket, while young children must be accompanied by an adult. Before travelling check the conditions of carriage of Trenord, Trenitalia or Italo."] = "未成年人单独乘车：各公司规定不同。一般来说，年龄较大的孩子持有效车票可以单独乘车，年幼的孩子必须由成人陪同。出行前请查看Trenord、Trenitalia或Italo的运输条款。"
        m["Digital tickets: no need to print them, just show them on your phone (PDF, app or QR code) with enough battery. Some tickets require check-in or activation before boarding: it is stated on the ticket and in the operator's app."] = "电子车票：无需打印，用手机出示即可（PDF、应用或二维码），注意手机电量。部分车票需要在上车前值机或激活：车票和公司应用上会注明。"
        m["Emergency or safety: call 112, the single emergency number. On board use the intercom or emergency button and tell the conductor; in stations there is the Railway Police (Polfer). For a theft report it to the Polfer or Carabinieri and block your cards and phone. The nearest defibrillator is on the Home screen."] = "紧急情况或安全：请拨打统一紧急电话112。在车上使用对讲机或紧急按钮并告知检票员；车站有铁路警察（Polfer）。遇到盗窃请向Polfer或宪兵报案，并挂失银行卡和手机。最近的除颤器在首页。"
        m["Payments: ticket machines take cards (also contactless) and often cash; apps and websites take cards, PayPal and digital wallets depending on the operator; ticket offices also take cash. On some lines and metros you can tap a contactless card directly at the validators."] = "支付：售票机接受银行卡（包括非接触支付），通常也收现金；应用和网站根据公司不同接受银行卡、PayPal和电子钱包；售票处也收现金。在部分线路和地铁，可以直接在验票机上刷非接触银行卡。"
        m["Replacement buses: when trains are replaced by buses, Stations → Replacement buses shows stops, times and sources for your station; notices are in News. The bus stop is usually signposted in front of the station."] = "替代巴士：当列车由巴士替代时，在\"车站 → 替代巴士\"可以查看你所在车站的站点、时间和信息来源；通知在\"新闻\"中。巴士站通常在车站前有标识。"
        m["Language: tap the flag at the top of the Home screen or go to More → Settings → Language. Italian, English, Chinese, German, French, Spanish and Japanese are available; the voice changes language too."] = "语言：点按首页顶部的国旗，或进入\"更多 → 设置 → 语言\".可选意大利语、英语、中文、德语、法语、西班牙语和日语；语音也会随之切换。"
        m["Favourites: tap the star ★ on a train, a station board or a route. You find them in the Trains and Stations tabs, in Quick (recent and favourites) and in the Favourites widget; you can also add them to the Home shortcuts with +."] = "收藏：在列车、车站时刻表或路线上点按星标★。可以在\"列车\"和\"车站\"标签、\"快捷\"（最近和收藏）以及收藏小组件中找到；也可以用+添加到首页的快捷按钮。"
        m["Searching a timetable: in the Search tab choose departure and arrival, date and time (and return if needed), then tap Search. The results show times, changes, prices and delays; tap a train for stops and platforms. You can also ask me \"trains from Varese to Milano\"."] = "查询时刻表：在\"搜索\"标签中选择出发地和目的地、日期和时间（需要时也选返程），然后点按\"搜索\".结果会显示时间、换乘、票价和晚点；点按列车可查看停靠站和站台。也可以问我\"从Varese到Milano的火车\"."
        m["Ticket on board: on regional trains you buy the ticket before boarding. If the station has no way to buy one (office closed, machine broken), tell the conductor as soon as you board: usually you can pay with a surcharge, but rules differ between operators. The conditions of carriage say when this is possible and how much it costs."] = "车上买票：乘坐区域列车需要在上车前买票。如果车站无法购票（售票处关闭、售票机故障），上车后请立即告知检票员：通常可以加价补票，但各公司规定不同。运输条款会说明何时可以补票以及价格。"
        m["SBB · InterRegio, InterCity, EuroCity"] = "SBB · InterRegio、InterCity、EuroCity"
        m[" · guaranteed band 6–9 / 18–21"] = " · 保障时段 6–9 / 18–21"
        m["Incomplete download"] = "下载不完整"
        m["accessible"] = "无障碍"
        m["tactile paving"] = "盲道"
        m["steps"] = "台阶"
        m["handrail"] = "扶手"
        m["level "] = "层 "
        m["Hospital"] = "医院"
        m["Pharmacy"] = "药店"
        m["emergency department"] = "急诊"
        m["hospital"] = "医院"
        m["pharmacy"] = "药店"
        m["You are not following any train. Ask for example \"train 2512\" and then tap \"Follow with voice alerts\"."] = "您没有跟踪任何列车。例如可以问 \"列车 2512\"，然后点击 \"语音提醒跟踪\"。"
        m["Which station? Ask for example \"bus and taxi at Varese\"."] = "哪个车站？例如可以问 \"Varese 的巴士和出租车\"。"
        m["Which station? Ask for example \"toilets at Saronno\"."] = "哪个车站？例如可以问 \"Saronno 的厕所\"。"
        m["Tell me the train number, for example \"delay train 2512\" or \"platform of 9544\"."] = "请告诉我车次，例如 \"列车 2512 延误\" 或 \"9544 的站台\"。"
        m["Sorry, I didn't understand. Try one of these topics: "] = "抱歉，我没听懂。请试试这些话题："
        m["lines "] = "线路 "
        m["Toilets: not mapped"] = "厕所：未标注"
        m["Toilets: "] = "厕所："
        m[", accessible"] = "，无障碍"
        m[", hours "] = "，开放时间 "
        m["Platforms: "] = "站台："
        m["Lifts: "] = "电梯："
        m["Ticket office: "] = "售票处："
        m["Ticket machines: "] = "售票机："
        m["Validators: "] = "验票机："
        m["Station data not reachable now."] = "暂时无法获取车站数据。"
        m["Train cancelled."] = "列车已停运。"
        m["Arrived"] = "已到达"
        m["Running on time."] = "列车准点运行。"
        m[" (scheduled)"] = " （计划）"
        m[", platform not yet announced"] = "，站台尚未公布"
        m[" · scheduled platform "] = " · 计划站台 "
        m[" · actual "] = " · 实际 "
        m[" · CANCELLED"] = " · 已停运"
        m[" · on time"] = " · 准点"
        m[" · plat. "] = " · 站台 "
        m["Timetable service unreachable."] = "时刻表服务无法访问。"
        m[" plat."] = " 站台"
        m["No rail strikes announced (source: Italian Ministry strike observatory)."] = "未宣布铁路罢工（来源：意大利交通部罢工观察站）。"
        m["Announced rail strikes:\n"] = "已宣布的铁路罢工：\n"
        m["\n\nGuaranteed trains: More → Guaranteed trains."] = "\n\n保障列车：更多 → 保障列车。"
        m["Strike observatory unreachable."] = "罢工观察站无法访问。"
        m["No traffic disruptions reported right now."] = "目前没有报告交通中断。"
        m["Take a few seconds to write the message."] = "请花几秒钟写下留言。"
        m["You just sent a message: wait a few minutes before the next one."] = "您刚发送过消息：请等几分钟再发下一条。"
        m["This message has already been sent."] = "这条消息已经发送过了。"
        m["Too many links in the message: at most 2."] = "消息中链接太多：最多2个。"
        m["The message does not look like text: describe the problem or suggestion in words."] = "消息看起来不像文字：请用文字描述问题或建议。"
        m["Information, help during disruption, reduced mobility, Carta Blu, complaints"] = "信息、运营中断时的帮助、行动不便、Carta Blu、投诉"
        m["Italo tickets, changes, refunds and help"] = "Italo 车票、改签、退款和帮助"
        m["Italo ticket machines (unstaffed)"] = "Italo 售票机（无人值守）"
        m["TILO/SBB and Arcobaleno tickets, passes, information and help"] = "TILO/SBB 和 Arcobaleno 车票、通票、信息和帮助"
        m["Live data not yet available"] = "暂无实时数据"
        m["Departed"] = "已出发"
        m[" changes"] = " 次换乘"
        m["Downloading South Tyrol ticket outlets…"] = "正在下载南蒂罗尔售票点…"
        m["Locating outlets…"] = "正在定位售票点…"
        m["Downloading Trenord sales points…"] = "正在下载 Trenord 售票点…"
        m["Downloading ticket office hours…"] = "正在下载售票处营业时间…"
        m["Downloading the sales points list…"] = "正在下载售票点列表…"
        m["Downloading the sellers list…"] = "正在下载代售点列表…"
        m["Ticket machine"] = "售票机"
        m["Price you entered"] = "您输入的价格"
        m["platform not accessible: "] = "站台无法通行："
        m["expected back on "] = "预计恢复于 "
        m["Band from the official regional ticket price"] = "官方大区票价的价格区间"
        m["delay compensation"] = "延误补偿"
        m["bikes on trains"] = "列车携带自行车"
        m["children"] = "儿童"
        m["disability assistance"] = "残障协助"
        m["lost property"] = "失物招领"
        m["ticket validation"] = "车票验证"
        m["bus and taxi at Varese"] = "Varese 的巴士和出租车"
        m["toilets at Saronno"] = "Saronno 的厕所"
        m["\nLast reported: "] = "\n最后报告："
        m["\nNext: "] = "\n下一站："
        m["on time"] = "准点"
        m["FN network"] = "FN 线网"
        m["Departure and arrival reminders"] = "出发和到达提醒"
        m["Disruptions on favourite routes and lines"] = "常用路线和线路的中断"
        m["Stop alarm"] = "到站闹钟"
        m["Board at "] = "上车站："
        m[" at "] = " 于 "
        m[" · platform "] = " · 站台 "
        m["Alarm before "] = "提前闹钟："
        m["Data temporarily unavailable"] = "数据暂时不可用"
        m[" on time."] = " 准点。"
        m["\nWith a delay of 60 minutes or more you can claim compensation: see More › Conditions, rights and refunds."] = "\n延误60分钟或以上可申请补偿：见 更多 › 条件、权利和退款。"
        m["\nIf you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation."] = "\n如果您持有月票，延误计入每月优惠（Trenord）或补偿。"
        m["\nI've stopped following the train. Have a good day!"] = "\n我已停止跟踪这趟列车。祝您愉快！"
        m["trip completed"] = "行程已完成"
        m["Platform change"] = "站台变更"
        m["Wake up! Next stop: "] = "醒醒！下一站："
        m["Expected arrival at "] = "预计到达 "
        m["Expected departure at "] = "预计出发 "
        m["Arrival at "] = "到达 "
        m["Departure from "] = "出发自 "
        m["Warning: the train is cancelled"] = "注意：列车已停运"
        m["Follow train"] = "跟踪列车"
        m["cancelled"] = "已停运"
        m["It is cancelled."] = "已停运。"
        m["Back on time."] = "已恢复准点。"
        m["Alternatives:"] = "替代方案："
        m["No alternative found soon: open the app for more options."] = "短时间内没有找到替代方案：打开应用查看更多选项。"
        m["Refreshing widget…"] = "正在刷新小组件…"
        m["refreshing…"] = "刷新中…"
        m["Tap to set up"] = "点击进行设置"
        m["Tap the title to choose what to show"] = "点击标题选择显示内容"
        m["Tap ⟳ to refresh"] = "点击 ⟳ 刷新"
        m["Refreshes automatically · ⟳ to retry"] = "自动刷新 · 点 ⟳ 重试"
        m["not updated"] = "未更新"
        m["Data service temporarily unreachable"] = "数据服务暂时无法访问"
        m["Tap ⟳ to retry"] = "点击 ⟳ 重试"
        m["No departures in the next hours"] = "未来几小时没有出发班次"
        m["The widget refreshes itself; tap ⟳ to retry"] = "小组件会自动刷新；点 ⟳ 重试"
        m["First departures"] = "首班出发"
        m["No trains now: here are the first scheduled"] = "现在没有列车：以下是首批计划班次"
        m[" · not updated"] = " · 未更新"
        m["Status not available yet"] = "状态暂不可用"
        m["Resume following "] = "继续跟踪 "
        m["The phone restarted: tap to keep receiving platform, delay and arrival alerts."] = "手机已重启：点击以继续接收站台、延误和到站提醒。"
        m["is cancelled."] = "已停运。"
        m["Search by voice"] = "语音搜索"
        m["OpenStreetMap servers are not responding. Try again shortly or search Google Maps."] = "OpenStreetMap 服务器无响应。请稍后重试或在 Google 地图中搜索。"
        m["Set up"] = "设置"
        m["Share train status"] = "分享列车状态"
        m["Other apps"] = "其他应用"
        m["Resellers"] = "代售点"
        m["Mooney points"] = "Mooney 网点"
        m["list from"] = "列表来源："
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney points: see the official Trenitalia map."] = "在意大利其他地区，Trenitalia 区域车票在 PuntoLIS 和 Mooney 网点出售：请查看 Trenitalia 官方地图。"
        m["Official Trenitalia map (all Italy)"] = "Trenitalia 官方地图（全意大利）"
        m["No data for this station. TrovaTreno does not publish the FerrovieNord network: for those stations the app collects arrivals from ViaggiaTreno by itself and data appears here after a few hours."] = "此车站暂无数据。TrovaTreno 不公布 FerrovieNord 线网：这些车站由应用自行从 ViaggiaTreno 收集到达数据，几小时后会显示在这里。"
        m["Average delay "] = "平均延误 "
        m["Each box compares only services of the same kind. Based on trains with at least 30 observed arrivals in the month; runs without a category are not included. Regional operators other than Trenord and Trenitalia (Tper, EAV, Ferrovie del Gargano, TUA, BLS…) are identified by route and train number; only those running on the RFI network tracked by ViaggiaTreno are included."] = "每个方框只比较同类服务。基于当月至少有30次观察到达的列车；没有类别的班次不计入。Trenord 和 Trenitalia 以外的区域运营方（Tper、EAV、Ferrovie del Gargano、TUA、BLS…）按线路和车次识别；只包括在 ViaggiaTreno 跟踪的 RFI 线网上运行的列车。"
        m["SBB counts a train as punctual under 3 minutes late (5 in Italy), so the comparison with Italy is conservative. SBB publishes only the previous day: the app collects one per day."] = "SBB 将晚点不超过3分钟的列车计为准点（意大利为5分钟），因此与意大利的比较偏保守。SBB 只公布前一天的数据：应用每天收集一次。"
        m["Their actual times exist as open data (opentransportdata.swiss, \"Ist-Daten\"), but only as a single daily file with all Swiss public transport: hundreds of MB, to be downloaded every day. On a phone that would use too much data and battery, and there is no service returning per-company totals as SBB does. They can be added in future if such a service appears, or with a small server that downloads the file and prepares the totals for the app."] = "它们的实际时刻有开放数据（opentransportdata.swiss，\"Ist-Daten\"），但只是一个包含全瑞士公共交通的每日文件：数百 MB，需要每天下载。在手机上会消耗过多流量和电量，而且没有像 SBB 那样按公司提供汇总的服务。如果将来出现这样的服务，或者通过一个小型服务器下载文件并为应用准备汇总，就可以加入。"
        m["TrovaTreno does not publish the FerrovieNord network. The app reads arrivals from ViaggiaTreno by itself: every 80 minutes on Wi-Fi, every 3 hours on mobile data (about 0.3 MB). On time = within 5 minutes. Figures depend on when the phone is on and connected."] = "TrovaTreno 不公布 FerrovieNord 线网。应用自行从 ViaggiaTreno 读取到达数据：Wi-Fi 下每80分钟一次，移动数据下每3小时一次（约0.3 MB）。准点 = 5分钟以内。数据取决于手机开机和联网的时间。"
        m["Hi, I'm your Conductor! 🚆 I keep you posted about your train before, during and after the trip: platform, delays, platform changes, cancellations, next stops and arrival. It works with all trains: Trenord, Trenitalia, FerrovieNord, Italo, TILO and SBB."] = "您好，我是您的列车长！🚆 我会在行程前、行程中和行程后告诉您列车的情况：站台、延误、站台变更、停运、下一站和到达。适用于所有列车：Trenord、Trenitalia、FerrovieNord、Italo、TILO 和 SBB。"
        m["Departs"] = "出发"
        m["Arrives"] = "到达"
        m["Italy"] = "意大利"
        m["International"] = "国际"
        m["Long distance"] = "长途"
        m["Regional and long distance"] = "区域和长途"
        m["Real time: ViaggiaTreno (RFI network)"] = "实时：ViaggiaTreno（RFI 线网）"
        m["Real time: official Swiss timetable"] = "实时：瑞士官方时刻表"
        m["Real time only on the company's site/app"] = "实时信息仅在公司网站/应用上"
        m["Scheduled times in the app (Transitous); real time only on the company's site/app"] = "应用内为计划时刻（Transitous）；实时信息仅在公司网站/应用上"
        m["Regional and suburban"] = "区域和市郊列车"
        m["Intercity and long distance"] = "城际和长途列车"
        m["Plenty of seats"] = "座位充足"
        m["Moderately busy: look for seats"] = "较拥挤：请寻找座位"
        m["Very crowded"] = "非常拥挤"
        m["Trenord (sensors or previous days' history)"] = "Trenord（传感器或前几天的历史数据）"
        m["SBB forecast"] = "SBB 预测"
        m["Binario estimate by time of day"] = "Binario 按时段估算"
        m["I can help with:\n• \"delay train 2070\" or \"where is 9544\"\n• \"trains from Varese to Milano\"\n• \"departures from Varese\" / \"arrivals at Como\"\n• \"any strikes?\"\n• \"traffic on S5\" / \"problems at Saronno\"\n• \"elevators at Saronno\"\n• \"guaranteed trains\"\n• \"where is my train?\" (the train you follow)\n• \"next train to Milano\"\n• \"bus, metro and taxi at Milano Centrale\"\n• \"toilets at Saronno\" / \"services at Varese\"\n• \"delay compensation\", \"can I bring my bike?\", \"children\", \"disability assistance\", \"lost property\"\nTap the microphone to ask by voice."] = "我可以帮您：\n• \"列车 2070 延误\" 或 \"9544 在哪里\"\n• \"从 Varese 到 Milano 的列车\"\n• \"Varese 出发\" / \"Como 到达\"\n• \"有罢工吗？\"\n• \"S5 的运行情况\" / \"Saronno 的问题\"\n• \"Saronno 的电梯\"\n• \"保障列车\"\n• \"我的列车在哪里？\"（您跟踪的列车）\n• \"去 Milano 的下一班车\"\n• \"Milano Centrale 的巴士、地铁和出租车\"\n• \"Saronno 的厕所\" / \"Varese 的服务\"\n• \"延误补偿\"、\"可以带自行车吗？\"、\"儿童\"、\"残障协助\"、\"失物招领\"\n点击麦克风用语音提问。"
        m["During regional rail strikes trains are normally guaranteed 6:00–9:00 and 18:00–21:00 on weekdays (7:00–10:00 and 18:00–21:00 on holidays). Updated official lists are in More → Guaranteed trains."] = "区域铁路罢工期间，工作日 6:00–9:00 和 18:00–21:00 的列车通常有保障（节假日为 7:00–10:00 和 18:00–21:00）。最新官方名单见 更多 → 保障列车。"
        m["yes"] = "有"
        m[", platform not yet shown"] = "，站台尚未显示"
        m["Delay compensation (EU Regulation 2021/782):\n• 60–119 minutes late on arrival: 25% of the ticket\n• 120 minutes or more: 50%\n• Trenitalia Frecce: compensation also for 30–59 minutes, under Trenitalia's conditions\n• season tickets: own rules (Trenord gives season-ticket bonuses based on line punctuality)\nIf the expected delay exceeds 60 minutes you can also give up the trip with a full refund or be re-routed. The train screen shows whether you are entitled to compensation."] = "延误补偿（欧盟法规 2021/782）：\n• 到达晚点60–119分钟：票价的25%\n• 120分钟或以上：50%\n• Trenitalia Frecce：按 Trenitalia 条款，晚点30–59分钟也有补偿\n• 月票/年票：有自己的规则（Trenord 根据线路准点率给予持票人优惠）\n如果预计晚点超过60分钟，您也可以放弃行程并全额退款，或改走其他路线。列车页面会显示您是否有权获得补偿。"
        m["Ticket refund or change: it depends on the fare (cheap offers are often non-refundable). Trenitalia: request on the website or app with the ticket code (PNR). Trenord: from the refunds page. If the train is cancelled or expected more than 60 minutes late a refund is always due."] = "退票或改签：取决于票价类型（特价票通常不可退）。Trenitalia：在网站或应用上凭车票编码（PNR）申请。Trenord：在退款页面申请。如果列车停运或预计晚点超过60分钟，一定可以退款。"
        m["Validation: paper regional tickets without date and time must be validated before boarding (validating machine in the station). Digital tickets bought online or in the app already show the train or the day: check on the ticket whether check-in is needed. The nearest validators are in Stations → station → Overview, or More → Nearby resellers."] = "验票：没有日期和时间的纸质区域车票必须在上车前验票（车站内的验票机）。在线或在应用中购买的电子票已显示列车或日期：请查看车票上是否需要签到。最近的验票机见 车站 → 车站 → 概览，或 更多 → 附近代售点。"
        m["Without a valid ticket you pay the fare plus a fine; amounts and how to pay (reduced if you pay at once or within a few days) are in the operator's conditions of carriage. If the ticket machine was broken, tell the conductor straight away."] = "没有有效车票需支付票价加罚款；金额和支付方式（立即或几天内支付可减免）见运营方的运输条款。如果售票机坏了，请立即告诉列车员。"
        m["Bikes and scooters:\n• Trenord (Lombardy): regular, folding, electric bikes and scooters travel free on all trains, at any time, space permitting\n• Trenitalia Regional: usually on trains with the bike symbol, with a supplement\n• Frecce and Italo: normally only folded bikes in a bag\n• TILO: SBB rules in Ticino, Trenord rules in Lombardy"] = "自行车和滑板车：\n• Trenord（伦巴第）：普通、折叠、电动自行车和滑板车在所有列车上任何时间免费，视空间而定\n• Trenitalia 区域列车：通常在有自行车标志的列车上，需付附加费\n• Frecce 和 Italo：通常只允许装袋的折叠自行车\n• TILO：在提契诺按 SBB 规则，在伦巴第按 Trenord 规则"
        m["Pets on trains:\n• Trenord: free within Lombardy (carrier max 70×30×50 cm; dogs with muzzle, leash and registry certificate); not allowed on weekdays 7:00–9:30 and 17:30–19:30; beyond Lombardy an animal supplement is needed\n• Trenitalia: carrier free; on regional trains large dogs pay 50% of 2nd class; on Frecce and Intercity add \"Travel with your dog\" when buying\n• Italo: free up to about 5 kg in a carrier; larger dogs with the \"Dog\" service in Smart and Prima\n• SBB/TILO: free up to 30 cm in a bag; otherwise half fare or dog day pass CHF 25\n• Guide and assistance dogs: always free. Details in More → Travelling with pets."] = "携带宠物乘车：\n• Trenord：伦巴第境内免费（宠物箱最大 70×30×50 厘米；狗需戴口罩、牵绳并有登记证明）；工作日 7:00–9:30 和 17:30–19:30 不允许；出伦巴第需购买动物附加票\n• Trenitalia：宠物箱免费；区域列车上大型犬付二等座的50%；Frecce 和 Intercity 购票时加选 \"Travel with your dog\"\n• Italo：装在宠物箱内约5公斤以下免费；大型犬在 Smart 和 Prima 使用 \"Dog\" 服务\n• SBB/TILO：装袋30厘米以下免费；否则半价或犬类日票 CHF 25\n• 导盲犬和辅助犬：始终免费。详情见 更多 → 携带宠物出行。"
        m["Children:\n• Regional trains in Lombardy: free under 4 without a seat, 50% off from 4 to under 14\n• Trenitalia national trains: free under 4 without a seat, 50% off the Base fare from 4 to under 15\n• Other regions and Italo have their own rules"] = "儿童：\n• 伦巴第区域列车：4岁以下不占座免费，4岁至14岁以下五折\n• Trenitalia 国内列车：4岁以下不占座免费，4岁至15岁以下 Base 票价五折\n• 其他大区和 Italo 有各自的规则"
        m["Assistance for people with disabilities or reduced mobility:\n• RFI Sala Blu (RFI stations): 800 90 60 60, from mobiles +39 02 32 32 32\n• Trenord: 800 210 955 (daily 8:15–19:45) or +39 02 72 49 49 49; book preferably 48 hours ahead\n• SBB (Ticino): 0800 007 102\nThe station screen shows lifts per platform and current faults."] = "残障或行动不便人士协助：\n• RFI Sala Blu（RFI 车站）：800 90 60 60，手机拨打 +39 02 32 32 32\n• Trenord：800 210 955（每天 8:15–19:45）或 +39 02 72 49 49 49；最好提前48小时预约\n• SBB（提契诺）：0800 007 102\n车站页面显示各站台电梯和当前故障。"
        m["Lost property: tell the conductor straight away. Trenord: 02 72 49 49 49, items kept at the Cadorna and Garibaldi My Link Points for a few days, then at the City of Milan office (via Friuli 30). Trenitalia: lost items search service and Frecciadesk. Italo: Pronto Italo 06 07 08. SBB/TILO: report online at lostandfound.sbb.ch. Details in More → Lost property."] = "失物招领：请立即告诉列车员。Trenord：02 72 49 49 49，物品在 Cadorna 和 Garibaldi 的 My Link Point 保存几天，之后送到米兰市政府失物处（via Friuli 30）。Trenitalia：失物查询服务和 Frecciadesk。Italo：Pronto Italo 06 07 08。SBB/TILO：在 lostandfound.sbb.ch 在线报失。详情见 更多 → 失物招领。"
        m["Strikes and tickets: Trenord refunds on request within 30 days of the strike. Trenitalia refunds from the announcement: Frecce and Intercity up to departure time, regional trains until midnight of the day before. In the guaranteed time bands (weekdays 6–9 and 18–21) the trains on the official list run."] = "罢工与车票：Trenord 在罢工后30天内可申请退款。Trenitalia 自宣布起退款：Frecce 和 Intercity 到发车时间为止，区域列车到前一天午夜为止。在保障时段（工作日 6–9 点和 18–21 点）官方名单上的列车照常运行。"
        m["Cancelled train: you are entitled to a full refund or to travel on the first available train to the same destination. A replacement bus is often provided: see the notices (More → Strikes, traffic and works). Tell me the train number to check it."] = "列车停运：您有权全额退款，或乘坐前往同一目的地的第一班可用列车。通常会安排替代巴士：请查看通知（更多 → 罢工、交通和施工）。告诉我车次，我来查。"
        m["Missed connection because of a delay: with a single ticket you can continue on the first available train at no extra cost. For journeys with a change the app shows the minutes to change and warns \"connection at risk\" if the first train is late."] = "因晚点错过换乘：使用单一车票可免费乘坐第一班可用列车继续行程。对于需要换乘的行程，应用会显示换乘时间，如果第一趟列车晚点会提示 \"换乘有风险\"。"
        m["Luggage: you travel with your own bags in the luggage spaces at no cost for normal use; they must stay under your control and not block aisles and doors. Large stations often have a paid left-luggage office."] = "行李：随身行李正常使用时免费放在行李区；行李须在您的看管下，不得阻挡通道和车门。大站通常有收费行李寄存处。"
        m["Tickets: on the official websites and apps (Trenitalia, Trenord, Italo), at ticket offices and machines in the station, and at authorised resellers (tobacconists, newsagents). More → Nearby resellers shows ticket offices, machines (also contactless) and resellers near you."] = "车票：在官方网站和应用（Trenitalia、Trenord、Italo）、车站售票处和售票机，以及授权代售点（烟草店、报亭）购买。更多 → 附近代售点 显示您附近的售票处、售票机（也有非接触支付）和代售点。"
        m["Season tickets: Trenord offers monthly and annual tickets and the integrated Io Viaggio passes (train + public transport in Lombardy). Trenitalia has regional and Frecce passes. Season-ticket holders have their own refund and delay-bonus rules."] = "月票和年票：Trenord 提供月票、年票以及 Io Viaggio 联票（伦巴第火车 + 公共交通）。Trenitalia 有区域和 Frecce 通票。持票人有自己的退款和延误优惠规则。"
        m["Airports:\n• Malpensa: Malpensa Express from Milano Cadorna and Milano Centrale, stops T1 and T2\n• Linate: metro line M4 (no train)\n• Orio al Serio (Bergamo): bus from Bergamo station\nAsk me for example \"trains from Milano Cadorna to Malpensa\"."] = "机场：\n• Malpensa：从 Milano Cadorna 和 Milano Centrale 乘 Malpensa Express，停靠 T1 和 T2\n• Linate：地铁 M4 线（无火车）\n• Orio al Serio（Bergamo）：从 Bergamo 火车站乘巴士\n例如可以问我 \"从 Milano Cadorna 到 Malpensa 的列车\"。"
        m["Switzerland and TILO: trips between Lombardy and Ticino need cross-border tickets (Arcobaleno in CHF or Trenord in euros). TILO lines, fares and services are in More → TILO; for a route ask \"trains from Como to Lugano\"."] = "瑞士和 TILO：伦巴第和提契诺之间的行程需要跨境车票（瑞郎计价的 Arcobaleno 或欧元计价的 Trenord）。TILO 线路、票价和服务见 更多 → TILO；查询路线可问 \"从 Como 到 Lugano 的列车\"。"
        m["Contacts:\n• Trenitalia: 892021 (call centre)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (disability assistance): 800 90 60 60\nFor complaints use the forms on the official websites."] = "联系方式：\n• Trenitalia：892021（客服中心）\n• Trenord：+39 02 72 49 49 49\n• Italo：892020\n• RFI Sala Blu（残障协助）：800 90 60 60\n投诉请使用官方网站上的表格。"
        m["Your rights (EU Regulation 2021/782): travel information, refund or re-routing if the expected delay exceeds 60 minutes, compensation of 25% (60–119 minutes) or 50% (120+), assistance (drinks, meals, accommodation if needed), free assistance for people with disabilities."] = "您的权利（欧盟法规 2021/782）：出行信息；预计晚点超过60分钟时退款或改线；补偿25%（60–119分钟）或50%（120分钟以上）；协助（必要时提供饮料、餐食、住宿）；残障人士免费协助。"
        m["Platforms in the app: the scheduled platform comes from the timetable; the actual one (blue) is confirmed by the station. A change is shown in red (e.g. 3 → 5) and, if you follow the train, you get a notification and a voice alert."] = "应用中的站台：计划站台来自时刻表；实际站台（蓝色）由车站确认。变更以红色显示（例如 3 → 5），如果您跟踪了这趟列车，会收到通知和语音提醒。"
        m["Stop alarm: open the train, tap the stop where you get off and choose \"Wake me before this stop\". It rings when the train leaves the previous stop (or 4 minutes before); with voice alerts you also hear the voice."] = "到站闹钟：打开列车，点击您下车的车站，选择 \"在此站前叫醒我\"。列车离开前一站时（或提前4分钟）会响铃；开启语音提醒时还会听到语音。"
        m["Where I board: open the train, tap the stop where you get on and choose \"I board here\". Platform, time and alerts refer to that stop."] = "上车站：打开列车，点击您上车的车站，选择 \"我在这里上车\"。站台、时间和提醒都以该站为准。"
        m["Timetables offline: search the route and tap the PDF icon in the results to download the day's timetable (outbound and return) to Download/Binario. The app also remembers the latest times of every route you searched."] = "离线时刻表：搜索路线并点击结果中的 PDF 图标，即可将当天的时刻表（去程和返程）下载到 Download/Binario。应用也会记住您搜索过的每条路线的最新时刻。"
        m["Voice alerts: in Settings → Accessibility choose \"All\" or \"Only upcoming stop\". To ask by voice tap the microphone below, or long-press the Binario icon and choose \"Ask by voice\"."] = "语音提醒：在 设置 → 无障碍 中选择 \"全部\" 或 \"仅下一站\"。要用语音提问，请点击下方的麦克风，或长按 Binario 图标并选择 \"语音提问\"。"
        m["Alerts for deaf people: in Settings → Accessibility turn on strong vibration (one pattern per alert) and the flashlight."] = "为聋人提供的提醒：在 设置 → 无障碍 中开启强振动（每种提醒一种模式）和闪光灯。"
        m["Widgets: long-press an empty spot on the Home screen → Widgets → Binario. There are Route, Train, Station and Favourites; tap the title to change it."] = "小组件：长按主屏幕空白处 → 小组件 → Binario。有路线、列车、车站和收藏；点击标题可更改。"
        m["Following a train: open the train and tap \"Follow\": a pinned notification updates every minute and warns of platform changes and delays."] = "跟踪列车：打开列车并点击 \"跟踪\"：常驻通知每分钟更新，并提醒站台变更和延误。"
        m["Punctuality: More → Punctuality has monthly statistics, with regional trains compared with regional ones and high speed separately, plus every station and train (TrovaTreno.it data)."] = "准点率：更多 → 准点率 提供每月统计，区域列车与区域列车比较，高铁单独统计，还有每个车站和每趟列车（TrovaTreno.it 数据）。"
        m["Milan – Saronno – Varese – Laveno"] = "米兰 – Saronno – Varese – Laveno"
        m["Milan – Saronno – Como"] = "米兰 – Saronno – Como"
        m["Milan – Saronno – Novara"] = "米兰 – Saronno – Novara"
        m["Milan – Seveso – Asso"] = "米兰 – Seveso – Asso"
        m["Brescia – Iseo – Edolo"] = "Brescia – Iseo – Edolo"
        m["Other trains (S lines and Passante)"] = "其他列车（S 线和 Passante）"
        m["Check for updates"] = "检查更新"
        m["Checking…"] = "正在检查…"
        m["You already have the latest version"] = "您已经是最新版本"
        m["Couldn't check for updates: check your connection and try again."] = "无法检查更新：请检查网络后重试。"
        m["Euro amounts are indicative (rate about €1.135 per CHF): the rate may differ at purchase."] = "欧元金额仅供参考（约 1.135 欧元兑 1 瑞郎）：购票时汇率可能不同。"
        m["More actions"] = "更多操作"
        m["Not a railway station: opening it on the map"] = "这不是火车站：在地图上打开"
        m["Transport:"] = "交通方式："
        m["Trains only"] = "仅火车"
        m["Also metro and bus"] = "包括地铁和巴士"
        m["There are no train-only solutions at this time: solutions with metro or bus are shown too."] = "该时段没有纯火车方案：同时显示包含地铁或巴士的方案。"
        m["Hidden"] = "已隐藏"
        m["solutions with metro or bus"] = "个含地铁或巴士的方案"
        m["Prices:"] = "价格："
        m["2nd class"] = "二等座"
        m["1st class"] = "一等座"
        m["1st class estimated: check sbb.ch"] = "一等座为估算价：请在 sbb.ch 核实"
        m["New version available"] = "有新版本"
        m["Tap to download and install"] = "点按下载并安装"
        m["Quick"] = "快捷"
        m["Active filters"] = "已启用的筛选"
        m["Nearby stations, toilets, replacement buses, taxis, defibrillators"] = "附近车站、洗手间、替代巴士、出租车、除颤器"
        m["Show these options on the Quick page too"] = "这些选项也显示在“快捷”页"
        m["Send the link or the app file via WhatsApp, Telegram…"] = "通过 WhatsApp、Telegram 等发送应用链接或文件"
        m["Or send the app file directly (installed version):"] = "或直接发送应用文件（已安装的版本）："
        m["App file (APK)"] = "应用文件（APK）"
        m["The recipient must open it and allow installation. WhatsApp may refuse APK files: in that case use the link."] = "接收者需要打开并允许安装。WhatsApp 可能拒绝 APK 文件：此时请使用链接。"
        m["Binario, the free app for trains in Italy and Switzerland. Open the file and allow installation."] = "Binario，意大利和瑞士火车的免费应用。打开文件并允许安装。"
        m["Could not prepare the app file"] = "无法准备应用文件"
    }

    /** 0.1.23: Italo, prezzi migliori, cambi rischiosi, condivisione solo Android. */
    private fun p6(m: HashMap<String, String>) {
        m["Android smartphones and tablets only: it does not work on iPhone and iPad."] = "仅适用于 Android 手机和平板电脑：不支持 iPhone 和 iPad。"
        m["Risky change"] = "换乘有风险"
        m["Tight change"] = "换乘时间紧"
        m["For this change we recommend at least"] = "此次换乘建议至少"
        m["a small delay could make you miss the connection."] = "稍有延误就可能错过换乘。"
        m["Find an alternative with later trains"] = "用后续列车寻找替代方案"
        m["Two tickets: Italo on italotreno.com, the other train on trenitalia.com or trenord.it"] = "两张车票：Italo 在 italotreno.com 购买，另一趟列车在 trenitalia.com 或 trenord.it 购买"
        m["Change station not found"] = "未找到换乘车站"
        m["Arrival station not found"] = "未找到到达车站"
        m["Alternatives for the change at"] = "换乘替代方案："
        m["Arriving on"] = "乘坐"
        m["Later trains with at least"] = "后续列车，至少留出"
        m["min to change"] = "分钟换乘"
        m["No alternative found after this time."] = "此时间之后没有找到替代方案。"
        m["Comfortable changes"] = "换乘时间充裕"
        m["With tickets for a fixed train and time (Frecce, Italo, Intercity) taking another train may require changing the ticket. Regional tickets are valid on any regional train on the route."] = "指定车次和时间的车票（Frecce、Italo、Intercity）改乘其他列车可能需要改签。地区车票在该线路的任何地区列车上均有效。"
        m["Cannot reach the server. Check your connection."] = "无法连接服务器。请检查网络连接。"
        m["Some time bands did not respond: tap to retry"] = "部分时段没有响应：点按重试"
        m["Lowest price for 1 adult among trains in that time band (Trenitalia, Trenord and Italo). «—» = no price available, «?» = service not reachable. Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "该时段列车中 1 名成人的最低价格（Trenitalia、Trenord 和 Italo）。«—» = 无价格，«?» = 服务无法访问。点按格子查看方案。优惠票价随余票变化：以购买时价格为准。"
        m["next 7 days, morning, afternoon and evening"] = "未来 7 天，上午、下午和晚上"
        m["Choose origin and destination to see the lowest prices for the next 7 days."] = "选择出发站和到达站，查看未来 7 天的最低价格。"
    }

    /** 0.1.24: silenzio degli avvisi di sciopero. */
    private fun p7(m: HashMap<String, String>) {
        m["Mute strike alerts"] = "静音罢工提醒"
        m["Muted until"] = "静音至"
        m["On · tap to mute them for a while"] = "已开启 · 点按可暂时静音"
        m["Turn back on"] = "重新开启"
        m["1 hour"] = "1 小时"
        m["3 hours"] = "3 小时"
        m["8 hours"] = "8 小时"
        m["1 week"] = "1 周"
        m["1 month"] = "1 个月"
        m["For how long? Strikes stay visible in News."] = "静音多久？罢工信息仍可在新闻中查看。"
        m["Until a day and time…"] = "直到指定日期和时间…"
    }

    /** 0.1.25: passeggeri, menù laterale, prossimo sciopero, notifica del treno seguito. */
    private fun p8(m: HashMap<String, String>) {
        m["Travel"] = "出行"
        m["Best prices"] = "最低价格"
        m["At the station"] = "在车站"
        m["Tickets and passes"] = "车票和月票"
        m["Fares"] = "票价"
        m["Send feedback"] = "发送反馈"
        m["Next train strike"] = "下一次铁路罢工"
        m.putIfAbsent("Details", "详情")
        m.putIfAbsent("Menu", "菜单")
        m["1 adult"] = "1 名成人"
        m["adults"] = "名成人"
        m["1 child"] = "1 名儿童"
        m["children"] = "名儿童"
        m["Passengers"] = "乘客"
        m["Adults"] = "成人"
        m["Children"] = "儿童"
        m["aged 4 to 14 (under 4 free without a seat)"] = "4 至 14 岁（4 岁以下不占座免费）"
        m["Prices shown are the total for all passengers. Discounts for children and families: check when buying."] = "显示的价格为所有乘客的总价。儿童和家庭优惠：购买时请核实。"
        m["Less"] = "减少"
        m["More"] = "增加"
        m.putIfAbsent("total price", "总价")
        m.putIfAbsent("min early", "分钟提前")
        m.putIfAbsent("late", "晚点")
        m.putIfAbsent("Refresh", "刷新")
        m.putIfAbsent("On time", "准点")
        m.putIfAbsent("Cancelled", "已取消")
    }

    /** 0.1.26: menù Accessibilità. */
    private fun p9(m: HashMap<String, String>) {
        m["Colour-blind, voice and vibration"] = "色盲、语音和振动"
    }

    /** Germania: treni, aziende, stazioni e biglietti. */
    private fun p10(m: HashMap<String, String>) {
        m["Trains in Germany"] = "德国火车"
        m["Times, delays and platforms in real time for all German operators"] = "德国所有铁路公司的实时时刻、晚点和站台"
        m["Search a German station like an Italian one, also by its Italian name: «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Journey search (also Italy ⇄ Germany), departure and arrival boards, train details and «Follow» all work."] = "像搜索意大利车站一样搜索德国车站，也可用意大利语名称：«München»、«Monaco di Baviera»、«Colonia»、«Berlin Hbf»。支持行程搜索（含意大利 ⇄ 德国）、出发和到达时刻表、列车详情和「关注」。"
        m["Data: official German DELFI timetables via Transitous. Prices are not public: buy on bahn.de or in the DB Navigator app."] = "数据：通过 Transitous 获取的德国官方 DELFI 时刻表。票价不公开：请在 bahn.de 或 DB Navigator 应用中购买。"
        m["Train types"] = "列车类型"
        m["DB high-speed trains between major cities; seat reservation recommended."] = "DB 大城市间高速列车；建议预订座位。"
        m["Intercity and EuroCity: long distance, also to Austria, Switzerland and Italy."] = "城际和欧洲城际列车：长途，也通往奥地利、瑞士和意大利。"
        m["Regional trains (DB Regio and many other companies): valid with the Deutschlandticket."] = "地区列车（DB Regio 及许多其他公司）：可使用 Deutschlandticket。"
        m["City S-Bahn (Munich, Berlin, Hamburg, Stuttgart…): valid with the Deutschlandticket."] = "城市 S-Bahn（慕尼黑、柏林、汉堡、斯图加特…）：可使用 Deutschlandticket。"
        m["FlixTrain: low-cost long distance, Flix tickets only."] = "FlixTrain：廉价长途，仅限 Flix 车票。"
        m["Night trains: ÖBB Nightjet and European Sleeper."] = "夜车：ÖBB Nightjet 和 European Sleeper。"
        m["Monthly pass for all regional trains (RE, RB, S-Bahn), buses, trams and metro in Germany. Not valid on ICE, IC, EC and FlixTrain. Cancel by the 10th of the month. It costs €63 until 31/12/2026 and €66.80 from 1 January 2027."] = "德国所有地区列车（RE、RB、S-Bahn）、巴士、有轨电车和地铁的月票。不适用于 ICE、IC、EC 和 FlixTrain。每月 10 日前可退订。2026 年 12 月 31 日前 63 欧元，2027 年 1 月 1 日起 66.80 欧元。"
        m["Full fare: valid on any train on the chosen day."] = "全价票：当天任意列车有效。"
        m["Cheaper when bought early, but tied to the chosen train (Zugbindung)."] = "提前购买更便宜，但仅限所选列车（Zugbindung）。"
        m["DB annual discount cards (25% or 50%, or unlimited travel with the 100)."] = "DB 年度折扣卡（25% 或 50%，或用 100 卡无限乘车）。"
        m["Buy on bahn.de"] = "在 bahn.de 购买"
        m["Deutschlandticket: information and purchase"] = "Deutschlandticket：信息和购买"
        m["DB Navigator app (tickets on your phone)"] = "DB Navigator 应用（手机车票）"
        m["Delays: your rights"] = "晚点：你的权利"
        m["60 minutes or more late on arrival: 25% of the fare back; 120 minutes or more: 50% (minimum €4)."] = "到达晚点 60 分钟以上：退还 25% 票价；120 分钟以上：50%（最低 4 欧元）。"
        m["Expected delay over 20 minutes: train binding is lifted and even with a Sparpreis you can take another train."] = "预计晚点超过 20 分钟：取消车次限制，即使是 Sparpreis 也可改乘其他列车。"
        m["Expected arrival between midnight and 5 am with at least 60 minutes' delay: taxi refunded up to €120."] = "预计在午夜至 5 点之间到达且晚点至少 60 分钟：出租车费用最高报销 120 欧元。"
        m["Claim within 3 months on bahn.de, in DB Navigator or with the Fahrgastrechte form."] = "请在 3 个月内通过 bahn.de、DB Navigator 或 Fahrgastrechte 表格申请。"
        m["Passenger rights (Fahrgastrechte)"] = "乘客权利（Fahrgastrechte）"
        m["Assistance for people with disabilities"] = "残障人士协助"
        m["Mon–Fri 6–22, Sat–Sun and holidays 8–20"] = "周一至周五 6–22 点，周末及节假日 8–20 点"
        m["Book assistance online (by 8 pm the day before)"] = "在线预约协助（前一天 20 点前）"
        m["Companies and stations"] = "公司和车站"
        m["All German railway companies"] = "所有德国铁路公司"
        m["DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… («Germany» filter)"] = "DB、FlixTrain、Arverio、Länderbahn、metronom、ODEG…（「德国」筛选）"
        m["Open a German station's board › «Station» tab: services, lifts and accessibility from bahnhof.de"] = "打开德国车站的时刻表 ›「车站」标签：来自 bahnhof.de 的服务、电梯和无障碍信息"
        m["Germany: official DELFI timetables with delays and platforms in real time when published (Transitous)."] = "德国：官方 DELFI 时刻表，发布时含实时晚点和站台（Transitous）。"
        m["Station services (Germany)"] = "车站服务（德国）"
        m["Services, shops, DB Lounge and map"] = "服务、商店、DB 贵宾室和地图"
        m["Lifts with real-time status"] = "电梯实时状态"
        m["Station accessibility"] = "车站无障碍设施"
        m["Assistance for people with disabilities (DB)"] = "残障人士协助（DB）"
        m["Valid with the Deutschlandticket"] = "可使用 Deutschlandticket"
        m["/month"] = "/月"
        m["Price and tickets on bahn.de (Sparpreis tied to the train)"] = "票价和车票见 bahn.de（Sparpreis 限定车次）"
        m["ICE, regional trains, S-Bahn, Deutschlandticket, rights and companies"] = "ICE、地区列车、S-Bahn、Deutschlandticket、权利和公司"
        m["Italy, Switzerland and Germany: websites, tickets, data"] = "意大利、瑞士和德国：网站、车票、数据"
        m.putIfAbsent("Germany", "德国")
        m["Times and real time in the app: official German DELFI data (Transitous)"] = "应用内时刻和实时信息：德国官方 DELFI 数据（Transitous）"
        m["Trip not found"] = "未找到车次"
        m.putIfAbsent("Real time · ", "实时 · ")
        m["Scheduled times (no real time for this trip) · "] = "计划时刻（此车次无实时信息） · "
    }

    /** Puntualità: confronto tra aziende e paesi. */
    private fun p11(m: HashMap<String, String>) {
        m["Companies and countries compared"] = "公司和国家对比"
        m["Companies to compare"] = "要比较的公司"
        m["Deutsche Bahn · official figures"] = "德国铁路 · 官方数据"
        m["Each country measures differently: in Italy (TrovaTreno) and Austria a train is on time within 5 minutes, in Germany under 6 minutes, for SBB under 3 minutes (stricter). DB and ÖBB count stops along the route, TrovaTreno counts arrivals. The fairest comparison is between trains of the same type: use the Regional or Long distance filter."] = "各国的统计方式不同：在意大利（TrovaTreno）和奥地利，5 分钟内到达算准点；德国为 6 分钟以内；瑞士联邦铁路为 3 分钟以内（更严格）。DB 和 ÖBB 统计沿途各站，TrovaTreno 统计到达。最公平的是比较同类列车：请使用「地区」或「长途」筛选。"
        m["How to read the comparison"] = "如何理解对比"
        m["No companies to compare: tap «Add»."] = "没有要比较的公司：点按「添加」。"
        m["Remove from comparison"] = "从对比中移除"
        m["Some chosen companies have no data yet: they will appear when available."] = "部分所选公司暂无数据：有数据后会显示。"
        m["Trenord · FerrovieNord network"] = "Trenord · FerrovieNord 线网"
        m.putIfAbsent("last ", "最近 ")
        m["long distance (Railjet, IC, Nightjet)"] = "长途（Railjet、IC、Nightjet）"
        m.putIfAbsent("regional", "地区列车")
        m["regional and S-Bahn"] = "地区列车和 S-Bahn"
        m["ÖBB · official figures"] = "ÖBB · 官方数据"
    }

    /** Germania: scioperi e prezzi. */
    private fun p12(m: HashMap<String, String>) {
        m["Train strikes in Germany"] = "德国铁路罢工"
        m["News not reachable right now."] = "暂时无法获取新闻。"
        m["No train strike announced in Germany in the last 14 days."] = "过去 14 天德国没有宣布铁路罢工。"
        m["News in German (Google News): in Germany strikes are announced by the GDL and EVG unions a few days in advance, with no official calendar."] = "德语新闻（Google 新闻）：在德国，GDL 和 EVG 工会通常提前几天宣布罢工，没有官方日历。"
        m["Traffic in Germany: disruptions and engineering works (DB)"] = "德国运行情况：故障和施工（DB）"
        m["Open on bahn.de"] = "在 bahn.de 打开"
        m["For trains in Germany prices are not public: the lowest-price calendar is on bahn.de («Bestpreissuche»). With regional trains only, the Deutschlandticket is valid."] = "德国火车的票价不公开：最低价日历请见 bahn.de（«Bestpreissuche»）。只乘坐地区列车时可使用 Deutschlandticket。"
        m["Train strike in Germany"] = "德国铁路罢工"
    }

    /** Emergenze per paese, affollamento e accessibilita' all'estero. */
    private fun p13(m: HashMap<String, String>) {
        m.putIfAbsent("Lombardy: Trenord and FerrovieNord trains from Trenord's official timetable (Regione Lombardia Open Data), with the delay from Trenord's live service.", "伦巴第：Trenord 和 FerrovieNord 列车来自 Trenord 官方时刻表（伦巴第大区开放数据），晚点来自 Trenord 实时服务。")
        m.putIfAbsent("Austria", "奥地利")
        m.putIfAbsent("France", "法国")
        m.putIfAbsent("Germany, Austria, Switzerland and France: running trains placed on the line from the timetable and the realtime data the companies publish (Transitous); where there is no realtime the position follows the timetable.", "德国、奥地利、瑞士和法国：运行中的列车根据时刻表和各公司发布的实时数据放置在线路上（Transitous）；没有实时数据时，位置按时刻表显示。")
        m.putIfAbsent("Finland (GPS)", "芬兰（GPS）")
        m.putIfAbsent("Norway (GPS)", "挪威（GPS）")
        m.putIfAbsent("GPS position", "GPS 位置")
        m.putIfAbsent("trains running or about to depart", "列车运行中或即将发车")
        m.putIfAbsent("Location unavailable", "无法获取位置")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour. In Italy the position is estimated along the route from the timetable and the last stop (shortly after opening the dots move onto the line); elsewhere it stays around the hub: not GPS. It is a sample, not the whole network. Finland and Norway show the real GPS position (Digitraffic, Entur). Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "每个圆点是一小时内从某枢纽出发的列车。在意大利，位置根据时刻表和上一站沿线路估算（打开后不久圆点会移到线路上）；其他地方仍围绕枢纽分布：不是 GPS。这只是样本，不是整个路网。芬兰和挪威显示真实 GPS 位置（Digitraffic、Entur）。来源：ViaggiaTreno、SBB (transport.opendata.ch)、Transitous。轨道：© OpenStreetMap 贡献者，样式 CC-BY-SA 2.0 OpenRailwayMap。")
        m.putIfAbsent("Colored dots by delay, zoom and «Near me»", "按晚点着色的圆点、缩放和“我附近”")
        m.putIfAbsent("Alerts for my trip", "我的行程提醒")
        m.putIfAbsent("Minutes from home to the departure station", "从家到出发车站的分钟数")
        m.putIfAbsent("«Leave home» before the outbound train, «Last useful train» in the evening on the return and «Connection at risk» when a delay endangers a change. The departure is the station near home.", "“该出门了”在去程列车前提醒；“最后一班可用列车”在晚上返程时提醒；“换乘有风险”在晚点危及换乘时提醒。出发站是离家近的车站。")
        m.putIfAbsent("Leave home", "该出门了")
        m.putIfAbsent("Leave home by", "最晚出门时间")
        m.putIfAbsent("for the train at", "赶乘以下时间的列车")
        m.putIfAbsent("Last useful train", "最后一班可用列车")
        m.putIfAbsent("Last useful train to", "开往以下方向的最后一班可用列车")
        m.putIfAbsent("departs at", "发车时间")
        m.putIfAbsent("Connection at risk at", "换乘有风险：")
        m.putIfAbsent("expected arrival", "预计到达")
        m.putIfAbsent("departure", "再次发车")
        m.putIfAbsent("Your history on this train", "您在这趟列车上的记录")
        m.putIfAbsent("Average delay", "平均晚点")
        m.putIfAbsent("On time (within 5 min)", "准点（5 分钟内）")
        m.putIfAbsent("Worst", "最差")
        m.putIfAbsent("Days recorded", "已记录天数")
        m.putIfAbsent("Data stays on your phone only.", "数据仅保存在您的手机上。")
        m.putIfAbsent("Most punctual among the next trains", "接下来列车中最准点的")
        m.putIfAbsent("runs observed", "已观测班次")
        m.putIfAbsent("TrovaTreno data from last month; they do not guarantee today's delay.", "TrovaTreno 上月数据；不保证今天的晚点情况。")
        m.putIfAbsent("RFI notice on your route", "RFI 关于您路线的通知")
        m.putIfAbsent("Notices on your routes", "您路线上的通知")
        m.putIfAbsent("Until", "至")
        m.putIfAbsent("Timetable notice", "时刻表通知")
        m.putIfAbsent("From", "自")
        m.putIfAbsent("to", "至")
        m.putIfAbsent("arrival at destination with", "到达终点时间延长")
        m.putIfAbsent("minutes", "分钟")
        m.putIfAbsent("Tap for the source", "点按查看来源")
        m.putIfAbsent("Service interruption between Rho and Parabiago", "Rho 与 Parabiago 之间运营中断")
        m.putIfAbsent("Timetable remodulation 126.1: staff shifts remain unchanged.", "时刻表调整 126.1：人员排班保持不变。")
        m.putIfAbsent("From the departures of the next hours. High-speed, Intercity and Trenitalia regional trains have no line in the official timetables: they are shown by category and route.", "来自未来几小时的发车信息。Trenitalia 的高速、城际和区域列车在官方时刻表中没有线路：按类别和路线显示。")
        m.putIfAbsent("Trenord network / Lombardy", "Trenord 网络 / 伦巴第")
        m.putIfAbsent("Other network or region", "其他网络或地区")
        m.putIfAbsent("Over 60 with CartaFreccia: FrecciaSENIOR offer on Frecce trains (from €29). Discounts and conditions detailed on the official page.", "60岁以上持 CartaFreccia：Frecce 列车的 FrecciaSENIOR 优惠（29欧元起）。折扣和条件详见官方页面。")
        m.putIfAbsent("From age 65, single tickets are 20% off the Lombardy Regional Single Fare; in the STIBM area 25% off ordinary monthly and annual passes (to be loaded on the Io Viaggio card, €10).", "65岁起，伦巴第区域统一票价的单程票享八折；在 STIBM 区域，普通月票和年票享七五折（需加载到 Io Viaggio 卡，10欧元）。")
        m.putIfAbsent("Over 60: Italo Senior, 40% to 60% off the Flex fare, in Smart and Prima Business; non-refundable, changeable up to 72 hours before departure.", "60岁以上：Italo Senior，较 Flex 票价优惠40%至60%，适用于 Smart 和 Prima Business；不可退款，发车前72小时可改签。")
        m.putIfAbsent("Reduced General Abonnement (GA) for women from their 64th birthday (from 65 starting in 2028) and for men from 65.", "优惠版通票（GA）：女性自64岁生日起（2028年起为65岁），男性自65岁起。")
        m.putIfAbsent("Senior BahnCard from age 65; the BahnCard 50 (ages 27 to 64) gives 50% off the Flexpreis and 25% off long-distance Sparpreis fares.", "65岁起可办 Senioren BahnCard；BahnCard 50（27至64岁）享 Flexpreis 五折和长途 Sparpreis 七五折。")
        m.putIfAbsent("From age 65, men and women: Vorteilscard Senior at €31 (valid 1 year).", "65岁起（男女相同）：Vorteilscard Senior 31欧元（有效期1年）。")
        m.putIfAbsent("From age 60: Carte Avantage Senior at €49 (confirm the price when buying): 30% off trips in 2nd and 1st class, 60% for up to 3 accompanying children aged 4-11; TER discounts vary by region.", "60岁起：Carte Avantage Senior 49欧元（购买时请确认价格）：二等和一等座行程七折，最多3名随行4至11岁儿童四折；TER 优惠因地区而异。")
        m.putIfAbsent("The prices shown are the total for all passengers.", "显示的价格为所有乘客的总价。")
        m.putIfAbsent("Age discounts vary by country and company: here kids are 4 to 14, but other companies use other ages. Family discounts: check when buying.", "年龄优惠因国家和公司而异：这里的儿童为4至14岁，其他公司采用不同的年龄。家庭优惠：购票时请确认。")
        m.putIfAbsent("Age rules for each company", "各公司的年龄规则")
        m.putIfAbsent("Age rules: companies and countries", "年龄规则：公司和国家")
        m.putIfAbsent("Age reductions depend on the country, company, train type and fare. Summary from the official sites (3/11/2026): they may change, always check the source before buying.", "年龄优惠取决于国家、公司、列车类型和票价。以下为官方网站摘要（2026年11月3日）：可能会变化，购票前请务必核对来源。")
        m.putIfAbsent("National trains: under 4 free without a seat; ages 4 to 14 (until the 15th birthday) 50% off the Base fare.", "国内列车：4岁以下不占座免费；4至14岁（至15岁生日前）基本票价五折。")
        m.putIfAbsent("Regional trains: under 4 free (with an adult, without a seat); ages 4 to under 12 get 50% off. Some regions have their own rules (Lombardy, Campania, Abruzzo, Sardinia, Apulia, Trento, Bolzano).", "区域列车：4岁以下与成人同行、不占座免费；4岁至不满12岁五折。部分地区有自己的规定（伦巴第、坎帕尼亚、阿布鲁佐、撒丁岛、普利亚、特伦托、博尔扎诺）。")
        m.putIfAbsent("International trains (EuroCity, EuroNight): free up to age 5 without a seat; ages 6 to 14 get the «CHILD» offer (about 50%), varies by service.", "国际列车（EuroCity、EuroNight）：5岁以下不占座免费；6至14岁适用“CHILD”优惠（约五折），因线路而异。")
        m.putIfAbsent("Up to age 3 free on the whole fleet, without taking a seat; ages 4 to under 14 get 50% off the Regional Single Fare; in the STIBM area under-14s travel free (with a document proving their age).", "3岁及以下不占座，全线免费；4岁至不满14岁享受区域统一票价五折；在 STIBM 区域，14岁以下免费（需出示年龄证明）。")
        m.putIfAbsent("Under 3 free, without an assigned seat and held by an adult (with more than one child per adult a paid seat is required). Italo Family offer for 2–4 people: details on the site.", "3岁以下免费，不分配座位，由成人抱着（一名成人带多名儿童时需购买付费座位）。Italo 家庭优惠适用于2至4人：详情见官网。")
        m.putIfAbsent("Under 6 free; ages 6 to under 16 pay half price (or the minimum fare), or travel free with a parent holding a valid ticket if you have the Junior Card. Under 25: Youth Half-Fare.", "6岁以下免费；6岁至不满16岁半价（或最低票价），持 Junior 卡可与持有效车票的父母同行免费。25岁以下：青年半价。")
        m.putIfAbsent("Under 6 free; ages 6 to 14 travel free on long-distance trains when accompanied by an adult or a sibling aged 15 or over. Regional trains and discounted tickets may have different rules.", "6岁以下免费；6至14岁在成人或15岁及以上兄弟姐妹陪同下乘坐长途列车免费。区域列车和优惠票可能有不同规定。")
        m.putIfAbsent("Under 6 free without a ticket, with an adult; ages 6 to 14 (until the day before the 15th birthday) free with the Vorteilscard Family (€21, up to 4 children), only on ÖBB trains in Austria; from 15 adult fare.", "6岁以下与成人同行免票；6至14岁（至15岁生日前一天）持 Vorteilscard Family（21欧元，最多4名儿童）免费，仅限奥地利境内的 ÖBB 列车；15岁起按成人票价。")
        m.putIfAbsent("Under 4 free on the lap (TGV INOUI, TER, Intercités), one child per traveller; own seat with the Forfait Bambin at €9. Ages 4 to 11: 60% off for those accompanying a Carte Avantage Adulte holder. OUIGO has its own fares.", "4岁以下坐在大人腿上免费（TGV INOUI、TER、Intercités），每位旅客限带一名儿童；独立座位可购买9欧元的 Forfait Bambin。4至11岁：陪同 Carte Avantage Adulte 持卡人的儿童享六折。OUIGO 有自己的票价。")
        m.putIfAbsent("Plan B", "B计划")
        m.putIfAbsent("Missed the train or the connection? Find alternatives from where you are now.", "错过了列车或换乘？从你现在的位置查找替代方案。")
        m.putIfAbsent("Where you are now", "你现在的位置")
        m.putIfAbsent("Another station…", "其他车站…")
        m.putIfAbsent("Alternatives to", "前往以下目的地的替代方案：")
        m.putIfAbsent("Looking for alternatives…", "正在查找替代方案…")
        m.putIfAbsent("How Binario works", "Binario 使用指南")
        m.putIfAbsent("Basic or Full", "基础或完整")
        m.putIfAbsent("On the Search screen choose how many features to see. You can change it any time: your choice is saved.", "在“搜索”界面选择显示多少功能。随时可以更改：选择会被保存。")
        m.putIfAbsent("Offline timetables", "离线时刻表")
        m.putIfAbsent("In the results tap «Save these times to use them offline»: you will find them in Offline timetables even without a network.", "在结果中点按“保存这些时刻表以便离线使用”：没有网络时也能在“离线时刻表”中找到。")
        m.putIfAbsent("Widgets", "小组件")
        m.putIfAbsent("Long-press the home screen, choose Widgets and add Binario: departures and delays always in sight.", "长按主屏幕，选择小组件并添加 Binario：发车和晚点一目了然。")
        m.putIfAbsent("Punctuality", "准点率")
        m.putIfAbsent("Under each icon is the tab name: search a station or a train and see how many arrive on time.", "每个图标下方都有标签名称：搜索车站或列车，查看准点到达的比例。")
        m.putIfAbsent("Got it", "知道了")
        m.putIfAbsent("less than a minute ago", "不到一分钟前")
        m.putIfAbsent("%d min ago", "%d 分钟前")
        m.putIfAbsent("%d h ago", "%d 小时前")
        m.putIfAbsent("%d days ago", "%d 天前")
        m.putIfAbsent("Timetables saved %s. They may have changed: connect to refresh them.", "时刻表保存于%s。可能已有变化：联网后即可更新。")
        m.putIfAbsent("Last saved message: the Trenord page is not responding right now.", "上次保存的消息：Trenord 页面目前无响应。")
        m.putIfAbsent("The downloaded file is not a valid APK. Try downloading it again.", "下载的文件不是有效的 APK。请重新下载。")
        m.putIfAbsent("The downloaded file is not Binario.", "下载的文件不是 Binario。")
        m.putIfAbsent("This version is already installed or is older.", "此版本已安装或比已安装版本更旧。")
        m.putIfAbsent("Your Binario was installed with a different signature from the updates (for example a test build or another source): Android cannot update it and would show “App not installed”. Uninstall Binario and install the latest version from the download page: you will lose favourites and settings.", "你的 Binario 安装时使用的签名与更新不同（例如测试版或其他来源）：Android 无法更新，并会显示“应用未安装”。请卸载 Binario，再从下载页面安装最新版本：收藏和设置会丢失。")
        m.putIfAbsent("Open the download page", "打开下载页面")
        m.putIfAbsent("Show the message", "显示消息")
        m.putIfAbsent("1 source has problems: related features use backups or the latest saved data.", "1 个数据源有问题：相关功能会使用备用源或最近保存的数据。")
        m.putIfAbsent("%d sources have problems: related features use backups or the latest saved data.", "%d 个数据源有问题：相关功能会使用备用源或最近保存的数据。")
        m.putIfAbsent("All sources respond, but some are busy (too many requests): the app uses backups.", "所有数据源都有响应，但部分繁忙（请求过多）：应用会使用备用源。")
        m.putIfAbsent("Latest message from Trenord", "Trenord 最新消息")
        m.putIfAbsent("Reading the message from the Trenord site…", "正在从 Trenord 网站读取消息…")
        m.putIfAbsent("Message not available right now.", "暂时无法获取消息。")
        m.putIfAbsent("Line status", "线路状态")
        m.putIfAbsent("Latest notice", "最新通知")
        m.putIfAbsent("Show all", "显示全部")
        m.putIfAbsent("Show less", "收起")
        m.putIfAbsent("Open the line page", "打开线路页面")
        m.putIfAbsent("Save these times to use them offline", "保存这些时刻表以便离线使用")
        m.putIfAbsent("Saved: find it in Offline timetables", "已保存：可在“离线时刻表”中找到")
        m.putIfAbsent("No saved timetables", "没有已保存的时刻表")
        m.putIfAbsent("To have timetables without a network: search for a trip, then in the results tap «Save these times to use them offline». You will find it here.", "想在没有网络时查看时刻表：先搜索行程，然后在结果中点按“保存这些时刻表以便离线使用”。之后可在此找到。")
        m.putIfAbsent("Tap a search to reopen it, even without a network.", "点按一条搜索即可重新打开，无网络也可以。")
        m.putIfAbsent("Search for a trip", "搜索行程")
        m.putIfAbsent("Busy: too many requests from your address (429). The app tries the other servers and then Postpass; retry in 15 seconds.", "繁忙：你的地址请求过多 (429)。应用会尝试其他服务器，然后是 Postpass；请 15 秒后重试。")
        m.putIfAbsent("Share of trains on time for each station in the chosen month. Type a name to search, then tap it to open.", "所选月份各车站的准点列车比例。输入名称搜索，然后点按打开。")
        m.putIfAbsent("Share of runs on time for each train in the chosen month. Search by number or destination, then tap it to open.", "所选月份各列车的准点运行比例。按车次或目的地搜索，然后点按打开。")
        m.putIfAbsent("Search station", "搜索车站")
        m.putIfAbsent("Train number or destination", "车次或目的地")
        m.putIfAbsent("Clear", "清除")
        m.putIfAbsent("Least punctual", "准点率最低")
        m.putIfAbsent("Most punctual", "准点率最高")
        m.putIfAbsent("Milan Passante", "米兰 Passante")
        m.putIfAbsent("RFI network", "RFI 路网")
        m.putIfAbsent("FerrovieNord network", "FerrovieNord 路网")
        m.putIfAbsent("%d results", "%d 个结果")
        m.putIfAbsent("%d results for «%s»", "“%s”的 %d 个结果")
        m.putIfAbsent("No results", "没有结果")
        m.putIfAbsent("No alternatives found in the next hours.", "未来几小时内未找到替代方案。")
        m.putIfAbsent("direct", "直达")
        m.putIfAbsent("changes", "次换乘")
        m.putIfAbsent("Tap a train to open it. Times are scheduled: check delays and platforms on its page.", "点击列车即可打开。显示的是计划时间：请在列车页面查看晚点和站台。")
        m.putIfAbsent("Trains in Austria", "奥地利列车")
        m.putIfAbsent("Trains in France", "法国列车")
        m.putIfAbsent("Trains in Italy", "意大利列车")
        m.putIfAbsent("Features", "功能")
        m.putIfAbsent("Basic", "基础")
        m.putIfAbsent("Full", "完整")
        m.putIfAbsent("Estimate: scheduled time plus the known delay.", "预估：时刻表时间加上已知晚点。")
        m.putIfAbsent("This train usually arrives with", "该列车通常晚点")
        m.putIfAbsent("Updated just now", "刚刚更新")
        m.putIfAbsent("Data from %d min ago", "%d 分钟前的数据")
        m.putIfAbsent("tap ↻ to refresh", "点按 ↻ 刷新")
        m.putIfAbsent("Cancelled today", "今日停运")
        m.putIfAbsent("Extra train today", "今日加开列车")
        m.putIfAbsent("Replaced by train", "由以下列车替代")
        m.putIfAbsent("Runs in place of train", "代替以下列车运行")
        m.putIfAbsent("Other times", "其他日期")
        m.putIfAbsent("replaced by", "被替代为")
        m.putIfAbsent("in place of", "代替")
        m.putIfAbsent("network", "路网")
        m.putIfAbsent("Trenord · TILO", "Trenord · TILO")
        m.putIfAbsent("All networks", "所有路网")
        m.putIfAbsent("Switzerland · SBB", "瑞士 · SBB")
        m.putIfAbsent("All", "全部")
        m.putIfAbsent("FerrovieNord", "FerrovieNord")
        m.putIfAbsent("RFI", "RFI")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Sources: ViaggiaTreno (Italy, Trenord, FerrovieNord) and transport.opendata.ch (TILO, Switzerland). Trenord and TILO are a single service.", "主要枢纽出发信息板的抽样（未来几小时）：并非整个路网。来源：ViaggiaTreno（意大利、Trenord、FerrovieNord）和 transport.opendata.ch（TILO、瑞士）。Trenord 和 TILO 是同一项服务。")
        m.putIfAbsent("Italia · RFI", "意大利 · RFI")
        m.putIfAbsent("Trenord · rete RFI", "Trenord · RFI 线路网")
        m.putIfAbsent("Trenord · rete FerrovieNord", "Trenord · FerrovieNord 线路网")
        m.putIfAbsent("TILO", "TILO")
        m.putIfAbsent("Svizzera · FFS/SBB", "瑞士 · SBB")
        m.putIfAbsent("Nessun ritardo di 5 minuti o più nei nodi controllati.", "所检查的枢纽没有 5 分钟及以上的晚点。")
        m.putIfAbsent("Campione dai tabelloni dei principali nodi (partenze delle prossime ore): non è l'elenco di tutta la rete. Fonti: ViaggiaTreno (Italia, Trenord, FerrovieNord) e transport.opendata.ch (TILO, Svizzera).", "主要枢纽出发信息板的抽样（未来几小时）：并非整个路网。来源：ViaggiaTreno（意大利、Trenord、FerrovieNord）和 transport.opendata.ch（TILO、瑞士）。")
        m.putIfAbsent("Trains in Switzerland", "瑞士列车")
        m.putIfAbsent("Timetables, delays and platforms of Italian trains (Trenitalia, Italo, Trenord, FerrovieNord and regional railways).", "意大利列车（Trenitalia、Italo、Trenord、FerrovieNord 及地区铁路）的时刻、晚点和站台信息。")
        m.putIfAbsent("Timetables, delays and platforms of Swiss trains (SBB, TILO and regional railways), with crowding and station services where SBB publishes them.", "瑞士列车（SBB、TILO 及地区铁路）的时刻、晚点和站台信息，SBB 提供时还包括拥挤程度和车站服务。")
        m.putIfAbsent("Search a station by name, a train by number, or a route. Journey search, departure board, train page and “Follow” work.", "可按名称搜索车站、按车次搜索列车，或搜索路线。行程搜索、发车看板、列车页面和“关注”均可使用。")
        m.putIfAbsent("Data: ViaggiaTreno, Trenord and Italo. Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "数据：ViaggiaTreno、Trenord 和 Italo。实时信息取决于各公司公布的内容，部分列车可能缺失。一切以车站看板和广播为准。")
        m.putIfAbsent("Data: SBB (open data). Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "数据：SBB（开放数据）。实时信息取决于各公司公布的内容，部分列车可能缺失。一切以车站看板和广播为准。")
        m.putIfAbsent("Timetables, delays and platforms of Austrian trains (ÖBB, Westbahn and regional operators), when real-time data is published.", "奥地利列车（ÖBB、Westbahn 及地区运营商）的时刻表、晚点和站台信息，在发布实时数据时提供。")
        m.putIfAbsent("Timetables, delays and platforms of French trains (TGV, TER, Intercités, RER), when real-time data is published.", "法国列车（TGV、TER、Intercités、RER）的时刻表、晚点和站台信息，在发布实时数据时提供。")
        m.putIfAbsent("Search the station with its Italian name too: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Trip search (also with Italy), station board, train page and «Follow» all work.", "也可以用意大利语名称搜索车站：“Vienna”“Salisburgo”“Parigi”“Lione”“Marsiglia”。行程搜索（含意大利）、车站看板、列车页面和“关注”均可使用。")
        m.putIfAbsent("Data: official timetables via Transitous; real time depends on what operators publish and may be missing for some trips. Prices are not public: tickets on the official sites. Station boards and announcements always prevail.", "数据：通过 Transitous 获取的官方时刻表；实时信息取决于各公司发布的内容，部分车次可能缺失。价格不公开：请在官方网站购票。一切以车站看板和广播为准。")
        m.putIfAbsent("Tickets and official information", "车票和官方信息")
        m.putIfAbsent("Prices for these trains are not public: the lowest-price calendar is on the operators' sites (ÖBB, SNCF) or on bahn.de.", "这些列车的价格不公开：最低价日历请查看各公司网站（ÖBB、SNCF）或 bahn.de。")
        m.putIfAbsent("Austria and France: official timetables with real-time delays and platforms when published (Transitous).", "奥地利和法国：官方时刻表，发布时提供实时晚点和站台信息（Transitous）。")
        m.putIfAbsent("Prices and tickets on the operators' sites (ÖBB, SNCF) or on bahn.de", "价格和车票请见各公司网站（ÖBB、SNCF）或 bahn.de")
        m.putIfAbsent("Sharing? When the time is right…", "分享？时机到了再说……")
        m.putIfAbsent("Unofficial app: not affiliated with, sponsored or endorsed by Trenitalia, RFI, Italo, Trenord or any other transport company. Data comes from public sources.", "非官方应用：与 Trenitalia、RFI、Italo、Trenord 或其他交通公司无任何关联，也未获其赞助或认可。数据来自公开来源。")
        m.putIfAbsent("Tap again for the board and services", "再次点按查看看板和服务")
        m.putIfAbsent("Services near this station", "此车站附近的服务")
        m.putIfAbsent("Board", "看板")
        m.putIfAbsent("Platform ", "站台 ")
        m.putIfAbsent("Delay now: ", "当前晚点：")
        m.putIfAbsent("Scheduled times: the delay may change. Created with Binario.", "计划时间：晚点情况可能变化。由 Binario 创建。")
        m.putIfAbsent("Tracks", "轨道")
        m.putIfAbsent("Ahead", "前方")
        m.putIfAbsent("Behind", "后方")
        m.putIfAbsent("Trains ahead and behind yours", "你前后的列车")
        m.putIfAbsent("Compared at the next stop: ", "在下一站比较：")
        m.putIfAbsent("Your train", "你的列车")
        m.putIfAbsent("The train ahead is running late and could slow yours down.", "前方列车晚点，可能拖慢你的列车。")
        m.putIfAbsent("Trains in the same direction passing that stop in the 45 minutes before and after yours. Source: ViaggiaTreno.", "在你前后45分钟内经过该站、方向相同的列车。来源：ViaggiaTreno。")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "每个圆点是未来一小时内从某枢纽出发的列车，围绕枢纽排列：并非其GPS位置。这只是样本，不是整个路网。来源：ViaggiaTreno、SBB（transport.opendata.ch）、Transitous。轨道：© OpenStreetMap 贡献者，样式 CC-BY-SA 2.0 OpenRailwayMap。")
        m.putIfAbsent("Watch and smartwatch", "手表和智能手表")
        m.putIfAbsent("Followed train status on the watch too", "在手表上同时显示所跟踪列车的状态")
        m.putIfAbsent("Sends a normal (not pinned) notification when the delay, platform or next stop changes, so Mi Band, Wear OS and other watches show it.", "当晚点、站台或下一站变化时，发送一条普通（非固定）通知，这样 Mi Band、Wear OS 和其他手表都能显示。")
        m.putIfAbsent("Send a test notification", "发送测试通知")
        m.putIfAbsent("Test: if you see this on your watch, all is well.", "测试：如果你在手表上看到这条消息，就一切正常。")
        m.putIfAbsent("Watch status", "手表状态")
        m.putIfAbsent("Binario does not talk to the watch directly: notifications (alerts, strikes, platform changes, delays, reminders) reach your wrist through the watch's own app. Mi Band: in Mi Fitness or Zepp Life open your device › Notifications and reminders › App alerts and turn on Binario. Wear OS: they arrive on their own (check in the Wear OS app › Notifications). In both cases set Binario to «no restrictions» in battery settings. The pinned train notification (with «Stop following») is usually not forwarded: that is why the separate alerts above exist.", "Binario 不会直接与手表通信：通知（提醒、罢工、站台变更、晚点、提示）通过手表自带的应用转发到手腕。Mi Band：在 Mi Fitness 或 Zepp Life 中打开你的设备 › 通知和提醒 › 应用提醒，并开启 Binario。Wear OS：会自动到达（可在 Wear OS 应用 › 通知中检查）。两种情况下都请在电池设置中将 Binario 设为“无限制”。固定的列车通知（带“停止跟踪”）通常不会被转发：所以才有上面的单独提醒。")
        m.putIfAbsent("Cancelled", "已取消")
        m.putIfAbsent("Next: ", "下一站：")
        m.putIfAbsent("Pl. ", "站台 ")
        m.putIfAbsent("Delays right now: Italy, Switzerland, Germany", "当前晚点：意大利、瑞士、德国")
        m.putIfAbsent("Not enough data right now", "目前数据不足")
        m.putIfAbsent("Trains by delay band", "按晚点档位统计的列车")
        m.putIfAbsent("Average delay", "平均晚点")
        m.putIfAbsent("On time (up to 5 min)", "准点（5分钟以内）")
        m.putIfAbsent("Trains with a delay reading", "已获取晚点数据的列车")
        m.putIfAbsent("Hubs with the highest average delay", "平均晚点最多的枢纽")
        m.putIfAbsent("Sample of trains departing from the big hubs in the next hour, not the whole network. For Italian trains the delay is known only after departure from the origin (ViaggiaTreno): so only trains with a delay reading are counted, and the comparison with Switzerland and Germany, which also give the predicted delay, is only indicative. For monthly statistics and the comparison between companies see below.", "这是未来一小时内从大型枢纽出发的列车样本，不是整个路网。意大利列车只有在始发站发车后才有晚点数据（ViaggiaTreno）：因此只统计有晚点数据的列车，与同时提供预测晚点的瑞士和德国的比较仅供参考。月度统计和公司对比见下方。")
        m.putIfAbsent("Train map", "列车地图")
        m.putIfAbsent("Delay", "晚点")
        m.putIfAbsent("Send by email", "通过电子邮件发送")
        m.putIfAbsent("Info and sources", "信息与来源")
        m.putIfAbsent("Rainbow theme", "彩虹主题")
        m.putIfAbsent("Each tile has a rainbow colour", "每个方块使用一种彩虹色")
        m.putIfAbsent("Custom colours", "自定义颜色")
        m.putIfAbsent("Choose your own main colour", "自选主色")
        m.putIfAbsent("Main colour", "主色")
        m.putIfAbsent("Colour code (hex)", "颜色代码（十六进制）")
        m.putIfAbsent("Dark background", "深色背景")
        m.putIfAbsent("Apply", "应用")
        m.putIfAbsent("Text size", "文字大小")
        m.putIfAbsent("Large", "大")
        m.putIfAbsent("Very large", "特大")
        m.putIfAbsent("Huge", "超大")
        m.putIfAbsent("Enlarges the text across the app; lines wrap instead of being cut off.", "放大整个应用的文字；文字会自动换行而不会被截断。")
        m.putIfAbsent("Weather at", "车站天气：")
        m.putIfAbsent("Feels like", "体感")
        m.putIfAbsent("Wind", "风")
        m.putIfAbsent("Arriving", "即将到站")
        m.putIfAbsent("Departs in", "发车倒计时")
        m.putIfAbsent("Last 30 days history", "近30天历史")
        m.putIfAbsent("Cancelled", "取消")
        m.putIfAbsent("Measured on arrival at", "在到达时测得：")
        m.putIfAbsent("runs operated", "已运行班次")
        m.putIfAbsent("Data collected by Binario, unofficial.", "数据由 Binario 收集，非官方。")
        m.putIfAbsent("Delay ranking", "晚点排行")
        m.putIfAbsent("By day", "按日")
        m.putIfAbsent("30 days", "30天")
        m.putIfAbsent("Sample from the main hubs: not the list of the whole network.", "主要枢纽的样本，并非全网列表。")
        m.putIfAbsent("Most delayed", "晚点最多")
        m.putIfAbsent("Most punctual", "最准点")
        m.putIfAbsent("runs", "班次")
        m.putIfAbsent("The history is still filling up.", "历史数据仍在积累中。")
        m.putIfAbsent("Binario collects delays every day: in a few days the ranking will be here.", "Binario 每天收集晚点数据：几天后这里会出现排行。")
        m.putIfAbsent("Last 30 days, trains observed by Binario", "近30天，Binario 观测的列车")
        m.putIfAbsent("Choose the style", "选择样式")
        m.putIfAbsent("The style changes colours, shapes and the layout of the Home, widgets included. You can change it whenever you like.", "样式会改变主页的颜色、形状和布局，小组件也一样。可随时更改。")
        m.putIfAbsent("The usual look, green", "一贯的绿色外观")
        m.putIfAbsent("Dark amber Solari board", "深色琥珀 Solari 翻牌屏")
        m.putIfAbsent("Find a train", "查找列车")
        m.putIfAbsent("By number or line", "按车次或线路")
        m.putIfAbsent("Arrivals and departures", "到发")
        m.putIfAbsent("Around you", "你附近")
        m.putIfAbsent("Train map", "列车地图")
        m.putIfAbsent("Where they are now", "当前位置")
        m.putIfAbsent("Who is most delayed", "谁晚点最多")
        m.putIfAbsent("What changes", "有何变化")
        m.putIfAbsent("Alarms and reminders", "闹钟与提醒")
        m.putIfAbsent("Saved on the phone", "保存在手机上")
        m.putIfAbsent("Statistics", "统计")
        m.putIfAbsent("Refunds", "退款")
        m.putIfAbsent("Passenger rights", "乘客权利")
        m.putIfAbsent("Help", "帮助")
        m.putIfAbsent("Frequently asked questions", "常见问题")
        m.putIfAbsent("Clear", "晴")
        m.putIfAbsent("Partly cloudy", "少云")
        m.putIfAbsent("Overcast", "阴")
        m.putIfAbsent("Fog", "雾")
        m.putIfAbsent("Drizzle", "毛毛雨")
        m.putIfAbsent("Rain", "雨")
        m.putIfAbsent("Snow", "雪")
        m.putIfAbsent("Showers", "阵雨")
        m.putIfAbsent("Thunderstorm", "雷暴")
        m.putIfAbsent("Variable", "多变")
        m.putIfAbsent("Light tiles", "浅色方块")
        m.putIfAbsent("White tiles on a light blue background, blue header", "浅蓝背景上的白色方块，蓝色顶栏")
        m.putIfAbsent("Coloured tiles", "彩色方块")
        m.putIfAbsent("Each function has its own pastel colour", "每个功能都有专属的柔和色彩")
        m.putIfAbsent("Dark board", "深色看板")
        m.putIfAbsent("Black and gold, fixed-width numbers", "黑金配色，等宽数字")
        m.putIfAbsent("Wide-tile list", "宽幅方块列表")
        m.putIfAbsent("Wide rows split into sections", "分区的宽行")
        m.putIfAbsent("My train up front", "我的列车置顶")
        m.putIfAbsent("Your next train on top, with a countdown", "顶部显示你的下一班列车及倒计时")
        m.putIfAbsent("Four big tiles and a list", "四个大方块加列表")
        m.putIfAbsent("Four big tiles, then rows for the rest", "四个大方块，其余为行")
        m.putIfAbsent("Lines and codes", "线路与代码")
        m.putIfAbsent("Rows with a coloured code on the left, like on the lines", "左侧带彩色代码的行，如线路标识")
        m.putIfAbsent("High contrast", "高对比度")
        m.putIfAbsent("Black and yellow, big tiles and thick borders", "黑黄配色，大方块与粗边框")
        m.putIfAbsent("Three columns by section", "按分区三列")
        m.putIfAbsent("Compact icons in three columns, with sections", "三列紧凑图标，含分区")
        m.putIfAbsent("Today's dashboard", "今日仪表盘")
        m.putIfAbsent("Last 30 days, current delays and shortcuts", "近30天、当前晚点与快捷入口")
        m.putIfAbsent("Fixes, service status, privacy", "修正、服务状态、隐私")
        m.putIfAbsent("Weather at the station (Open-Meteo)", "车站天气（Open-Meteo）")
        m.putIfAbsent("Real time", "实时")
        m.putIfAbsent("Mine", "我的")
        m.putIfAbsent("Prefer to write by email?", "想通过邮件联系？")
        m.putIfAbsent("Conditions and fares by company", "各公司条件与票价")
        m.putIfAbsent("Fares and tickets", "票价与车票")
        m.putIfAbsent("Rights and refunds", "权利与退款")
        m.putIfAbsent("Source: official website of", "来源：官方网站")
        m.putIfAbsent("links checked on", "链接核对于")
        m.putIfAbsent("Conditions and fares change: the app opens each company's official pages without copying their prices. The company's own text prevails.", "条件和票价会变化：应用会打开各公司的官方页面，不复制价格，以公司官方文本为准。")
        m.putIfAbsent("Trains departing soon from the main hubs of Italy, Switzerland and Germany, coloured by delay", "即将从意大利、瑞士和德国主要枢纽出发的列车，按晚点着色")
        m.putIfAbsent("On time", "准点")
        m.putIfAbsent("1–5 min late", "晚点1–5分钟")
        m.putIfAbsent("6–14 min late", "晚点6–14分钟")
        m.putIfAbsent("15+ min late", "晚点15分钟以上")
        m.putIfAbsent("Delay n.a.", "晚点未知")
        m.putIfAbsent("Trains shown", "显示的列车")
        m.putIfAbsent("Open train", "打开列车")
        m.putIfAbsent("Refresh", "刷新")
        m.putIfAbsent("Italy", "意大利")
        m.putIfAbsent("Switzerland", "瑞士")
        m.putIfAbsent("Germany", "德国")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous.", "每个圆点是未来一小时内从某枢纽出发的列车，围绕枢纽排列：并非其GPS位置。这只是样本，不是整个路网。来源：ViaggiaTreno、SBB（transport.opendata.ch）、Transitous。")
        m.putIfAbsent("App style", "应用风格")
        m.putIfAbsent("Traditional", "传统")
        m.putIfAbsent("Vintage (split-flap board)", "复古（翻页看板）")
        m.putIfAbsent("Refreshing the board…", "正在刷新看板…")
        m.putIfAbsent("TAP THE TITLE TO CHOOSE", "点按标题进行选择")
        m.putIfAbsent("NO DATA", "无数据")
        m.putIfAbsent("Departure board style", "发车看板样式")
        m.putIfAbsent("Classic", "经典")
        m.putIfAbsent("Vintage (split-flap)", "复古（翻页式）")
        m.putIfAbsent(". After the timetable change buses may be missing until Trenord publishes the new file.", "。换季调整后，在 Trenord 发布新文件之前，可能缺少巴士。")
        m.putIfAbsent(": Transitous timetables are used for Trenord instead.", "：Trenord 改用 Transitous 的时刻表。")
        m.putIfAbsent("Sources: official Trenord GTFS timetable from Lombardy Region open data (Transitous as a fallback); Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements.", "来源：伦巴第大区开放数据中的 Trenord 官方 GTFS 时刻表（以 Transitous 为备用）；Trenitalia 和 SBB 通过 Transitous（transitous.org）；站内显示屏上的巴士来自 ViaggiaTreno（RFI）。每个班次都标明来源。时间为计划时间：出现干扰时请听车站广播。")
        m.putIfAbsent("The Trenord replacement-bus timetable is valid until", "Trenord 替代巴士时刻表有效期至")
        m.putIfAbsent("The Trenord timetable file (Lombardy Region) expired on", "Trenord 时刻表文件（伦巴第大区）已于")
        m.putIfAbsent("Lombardy Region open data · official Trenord timetable (GTFS)", "伦巴第大区开放数据 · Trenord 官方时刻表（GTFS）")
        m.putIfAbsent("Which time is most punctual", "哪个时间最准点")
        m.putIfAbsent("on time", "准点")
        m.putIfAbsent("Each option counts as its least punctual train. Statistics of the latest month, not a forecast: strikes and works can change everything.", "每个方案以其中最不准点的列车计算。数据为最近一个月的统计，并非预测：罢工和施工可能改变一切。")
        m.putIfAbsent("Text copied", "文本已复制")
        m.putIfAbsent("Copy the request text", "复制申请文本")
        m.putIfAbsent("Most delayed trains right now", "目前晚点最多的列车")
        m.putIfAbsent("No significant delays at the main hubs, or the service is not responding.", "主要枢纽没有明显晚点，或服务无响应。")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Source: ViaggiaTreno.", "样本来自主要枢纽未来几小时的发车信息：并非全网列表。来源：ViaggiaTreno。")
        m.putIfAbsent("Dual numbering", "双重车次编号")
        m.putIfAbsent("This service changes number when it passes from one network to another (RFI, FerrovieNord, SBB).", "这趟列车在不同路网（RFI、FerrovieNord、SBB）之间转换时会更换车次号。")
        m.putIfAbsent("From the official Trenord timetables in force: the numbers can change with every timetable change.", "来自现行的 Trenord 官方时刻表：每次调整时刻表，车次号都可能变化。")
        m.putIfAbsent("After", "在")
        m.putIfAbsent("the train becomes", "列车变为")
        m.putIfAbsent("Reported by ViaggiaTreno.", "由 ViaggiaTreno 提供。")
        m.putIfAbsent("Strike tomorrow", "明天罢工")
        m.putIfAbsent("Line", "线路")
        m.putIfAbsent("Line page", "线路页面")
        m.putIfAbsent("Tap for the official line page: stops, timetables and notices.", "点击查看线路官方页面：车站、时刻表和通知。")
        m.putIfAbsent("Lines through this station", "经过本站的线路")
        m.putIfAbsent("From the departures of the next few hours. Frecce, Intercity and Trenitalia regional trains have no line in the official timetables.", "根据未来几小时的发车信息。Frecce、Intercity 和 Trenitalia 区域列车在官方时刻表中没有线路。")
        m.putIfAbsent("Official website", "官方网站")
        m["Automatic (mobile network)"] = "自动（移动网络）"
        m.putIfAbsent("Germany", "德国")
        m.putIfAbsent("Italy", "意大利")
        m["Country for emergencies and defibrillators"] = "紧急情况和除颤器所在国家"
        m["Expected occupancy in DB Navigator"] = "在 DB Navigator 中查看预计拥挤度"
        m["Expected occupancy on sbb.ch"] = "在 sbb.ch 查看预计拥挤度"
        m["SBB assistance for people with disabilities (Contact Center Handicap)"] = "瑞士联邦铁路残障人士协助（Contact Center Handicap）"
        m["No official data: DB publishes expected occupancy only in DB Navigator and on bahn.de. This is an estimate by time of day."] = "无官方数据：DB 仅在 DB Navigator 和 bahn.de 发布预计拥挤度。这里是按时段的估计。"
        m["German companies do not publish per-train services (wheelchair spaces, bikes) in open data: you can find them in DB Navigator or on bahn.de. "] = "德国铁路公司不在开放数据中公布各列车的服务（轮椅位、自行车）：可在 DB Navigator 或 bahn.de 查询。"
        m.putIfAbsent("Switzerland", "瑞士")
        m["The Rega (air rescue) app sends your location to the operations centre. Ambulance: 144."] = "Rega（空中救援）应用会把你的位置发送给调度中心。救护车：144。"
        m["The official emergency app of the German federal states: reach 112 and 110 also in writing, with your location."] = "德国各州官方紧急应用：可通过文字联系 112 和 110，并发送你的位置。"
        m.putIfAbsent("Train cancelled", "列车已取消")
        m.putIfAbsent("Train heavily delayed", "列车严重晚点")
        m.putIfAbsent("No connection", "无网络连接")
        m.putIfAbsent("Last reading: %d min ago", "上次读取：%d分钟前")
        m.putIfAbsent("It updates as soon as the network is back.", "网络恢复后会立即更新。")
    }

    private fun p14(m: HashMap<String, String>) {
        m.putIfAbsent("No connection. Check your Wi-Fi or mobile data.", "没有网络连接。请检查 Wi-Fi 或移动数据。")
        m.putIfAbsent("The service is not responding. Try again shortly.", "服务没有响应。请稍后再试。")
        m.putIfAbsent("Too many requests. Wait a minute and try again.", "请求过多。请等待一分钟后再试。")
        m.putIfAbsent("Not found: the service does not have this data.", "未找到：该服务没有这项数据。")
        m.putIfAbsent("The service has a problem. Try again later.", "服务出现问题。请稍后再试。")
        m.putIfAbsent("Something went wrong. Try again.", "出了点问题。请重试。")
        m.putIfAbsent("You are offline. Showing the latest available data.", "您处于离线状态。显示最近可用的数据。")
        m.putIfAbsent("The service is not responding: some data is %d min old.", "服务没有响应：部分数据是 %d 分钟前的。")
        m.putIfAbsent("With the app's latest network errors (service addresses only, no personal data).", "附带应用最近的网络错误（仅服务地址，不含个人数据）。")
        m.putIfAbsent("Try changing the time or the station.", "请尝试更改时间或车站。")
        m.putIfAbsent("Looking for alternatives…", "正在查找替代方案…")
        m.putIfAbsent("Advanced", "进阶")
        m.putIfAbsent("Just the essentials: timetable search, strikes and your shortcuts.", "仅保留基本功能：查询时刻、罢工信息和你的快捷键。")
        m.putIfAbsent("Also: passengers, train type, prices, My trips, offline timetables, lines and fares.", "另外还有：乘客、列车类型、票价、我的行程、离线时刻表、线路和票价规则。")
        m.putIfAbsent("All features: also maps, other countries, emergency, assistant and style tiles.", "全部功能：还包括地图、国外、紧急情况、助手和风格卡片。")
        m.putIfAbsent("Show all features", "显示全部功能")
        m.putIfAbsent("Accessible", "无障碍")
        m.putIfAbsent("Accessible stations", "无障碍车站")
        m.putIfAbsent("Other services", "其他服务")
        m.putIfAbsent("Open the notice document (PDF)", "打开通知文件（PDF）")
        m.putIfAbsent("Open the station page", "打开车站页面")
        m.putIfAbsent("Trenord notice", "Trenord通知")
        m.putIfAbsent("Bars and restaurants", "酒吧和餐厅")
        m.putIfAbsent("Bike sharing", "共享单车")
        m.putIfAbsent("Get directions", "查看路线")
        m.putIfAbsent("Car sharing", "共享汽车")
        m.putIfAbsent("With ticket office", "有售票处")
        m.putIfAbsent("With ticket machines", "有自动售票机")
        m.putIfAbsent("From the Trenord website. Tap a station for its address and other services.", "来自Trenord网站。点按车站查看地址和其他服务。")
        m.putIfAbsent("Defibrillator", "除颤器")
        m.putIfAbsent("Left luggage", "行李寄存")
        m.putIfAbsent("Machines", "售票机")
        m.putIfAbsent("Ticket machines", "自动售票机")
        m.putIfAbsent("Newsstand", "报亭")
        m.putIfAbsent("Address", "地址")
        m.putIfAbsent("Reading the station page from the Trenord website…", "正在从Trenord网站读取车站信息…")
        m.putIfAbsent("Show all", "全部显示")
        m.putIfAbsent("No services listed", "未列出服务")
        m.putIfAbsent("No stations with these services.", "没有提供这些服务的车站。")
        m.putIfAbsent("Parking", "停车场")
        m.putIfAbsent("Car park", "汽车停车场")
        m.putIfAbsent("Bike parking", "自行车停车处")
        m.putIfAbsent("Waiting room", "候车室")
        m.putIfAbsent("Escalators", "自动扶梯")
        m.putIfAbsent("Station page not available right now.", "车站信息暂时无法获取。")
        m.putIfAbsent("Accessibility services", "无障碍服务")
        m.putIfAbsent("Stations on the line", "线路上的车站")
        m.putIfAbsent("Wi-Fi", "Wi-Fi")
        m.putIfAbsent("TILO trains that left in the last 3 hours, in both directions, from the Swiss timetable: it counts delays over 15 minutes, not cancelled trains. For cancellations see the SBB notices below.", "过去3小时内双向发出的TILO列车，数据来自瑞士时刻表：只统计晚点超过15分钟的列车，不含停运列车。停运信息请看下方的SBB通知。")
        m.putIfAbsent("SBB notices on the line", "本线路的SBB通知")
        m.putIfAbsent("Checking SBB notices…", "正在查看SBB通知…")
        m.putIfAbsent("No current SBB notices: according to SBB, service is running normally.", "目前没有SBB通知：据SBB，列车运行正常。")
        m.putIfAbsent("SBB open data (texts in English).", "SBB开放数据（英文文本）。")
        m.putIfAbsent("SBB service status", "SBB运行状况")
        m.putIfAbsent("Delete this trip?", "删除这次行程？")
        m.putIfAbsent("Across all trips on the chosen route", "所选线路的全部行程")
        m.putIfAbsent("Morning (5–10)", "早上（5–10 点）")
        m.putIfAbsent("Daytime (10–16)", "白天（10–16 点）")
        m.putIfAbsent("Evening (16–21)", "傍晚（16–21 点）")
        m.putIfAbsent("Night (21–5)", "夜间（21–5 点）")
        m.putIfAbsent("When your trains are most late", "你的列车在什么时段晚点最多")
        m.putIfAbsent("Across all trips in the log", "基于记录中的全部行程")
        m.putIfAbsent("{0} trips · average delay {1} min · {2} with 15 min or more", "{0} 次行程 · 平均晚点 {1} 分钟 · {2} 次晚点 15 分钟或以上")
        m.putIfAbsent("most delays", "晚点最多")
        m.putIfAbsent("today", "今天")
        m.putIfAbsent("yesterday", "昨天")
        m.putIfAbsent("Last few days (worst moment)", "最近几天（最严重时）")
        m.putIfAbsent("All routes", "全部线路")
        m.putIfAbsent("Compensation claim", "赔偿申请")
        m.putIfAbsent("Not today", "今天不再提醒")
        m.putIfAbsent("Year", "年度")
        m.putIfAbsent("Arrival delay, day by day", "每日到达晚点")
        m.putIfAbsent("Filled bar: minutes late (top = 60 or more). Empty bar: train cancelled.", "实心条：晚点分钟数（顶端 = 60 分钟或以上）。空心条：列车停运。")
        m.putIfAbsent("Days with trips: {0}. No delays. Cancelled: {1}.", "有行程的天数：{0}。无晚点。停运：{1}。")
        m.putIfAbsent("Days with trips: {0}. Highest delay: {1} minutes on day {2}. Cancelled: {3}.", "有行程的天数：{0}。最大晚点：{2} 日 {1} 分钟。停运：{3}。")
        m.putIfAbsent("{0} minutes late", "晚点 {0} 分钟")
        m.putIfAbsent("Date", "日期")
        m.putIfAbsent("Scheduled arrival", "计划到达")
        m.putIfAbsent("Delay (min)", "晚点（分钟）")
        m.putIfAbsent("Yes", "是")
        m.putIfAbsent("Delays this month", "本月晚点")
        m.putIfAbsent("Search the guide", "在指南中搜索")
        m.putIfAbsent("No topic found", "未找到相关主题")
        m.putIfAbsent("Tap to open «My trips» and share the month.", "点按打开“我的行程”并分享本月。")
        m.putIfAbsent("added by hand", "手动添加")
        m.putIfAbsent("Add a trip", "添加行程")
        m.putIfAbsent("Train (e.g. R 2727)", "列车（例如 R 2727）")
        m.putIfAbsent("Date (dd/mm/yyyy)", "日期（日/月/年）")
        m.putIfAbsent("Scheduled arrival (hh:mm)", "计划到达（时:分）")
        m.putIfAbsent("Minutes late on arrival", "到达晚点分钟数")
        m.putIfAbsent("Write the train with its number, for example R 2727.", "请填写列车及车次，例如 R 2727。")
        m.putIfAbsent("Write the departure and arrival stations.", "请填写出发站和到达站。")
        m.putIfAbsent("Check date and time: for example 09/11/2026 and 08:15.", "请检查日期和时间：例如 09/11/2026 和 08:15。")
        m.putIfAbsent("The trip cannot be in the future.", "行程不能是将来的时间。")
        m.putIfAbsent("The delay must be from 0 to 999 minutes.", "晚点须在 0 到 999 分钟之间。")
        m.putIfAbsent("Low disruption", "影响较小")
        m.putIfAbsent("Moderate disruption", "影响中等")
        m.putIfAbsent("High disruption", "影响严重")
        m.putIfAbsent("1 strike hidden by the filter", "筛选隐藏了 1 条罢工")
        m.putIfAbsent("{0} strikes hidden by the filter", "筛选隐藏了 {0} 条罢工")
        m.putIfAbsent("1 notice hidden by the filter", "筛选隐藏了 1 条通知")
        m.putIfAbsent("{0} notices hidden by the filter", "筛选隐藏了 {0} 条通知")
        m.putIfAbsent("Share the month", "分享本月")
        m.putIfAbsent("Times recorded by the Binario app: they do not replace the operator's official certificates.", "由 Binario 应用记录的时刻：不能代替运营公司的正式证明。")
        m.putIfAbsent("{0}: scheduled {1}, actual {2}", "{0}：计划 {1}，实际 {2}")
        m.putIfAbsent("{0}: scheduled {1}, expected {2}", "{0}：计划 {1}，预计 {2}")
        m.putIfAbsent("{0}: scheduled {1}", "{0}：计划 {1}")
        m.putIfAbsent("How to read the times", "如何看时刻")
        m.putIfAbsent("Actual time: the train passed on time", "实际时刻：列车准点经过")
        m.putIfAbsent("Actual time: the train passed late", "实际时刻：列车晚点经过")
        m.putIfAbsent("Expected time: scheduled plus the current delay reported by the operator", "预计时刻：计划时刻加上运营公司通报的当前晚点")
        m.putIfAbsent("When data comes from several operators, the source is shown under the stop name (e.g. Trenord, SBB).", "数据来自多家公司时，站名下方会显示来源（如 Trenord、SBB）。")
        m.putIfAbsent("Disruption on the line (last 3 hours)", "线路受影响程度（最近 3 小时）")
        m.putIfAbsent("Checking the trains of the last few hours…", "正在检查最近几小时的列车…")
        m.putIfAbsent("No trains departed in the last 3 hours.", "最近 3 小时没有列车发车。")
        m.putIfAbsent("{0} critical trains out of {1}", "{1} 列中有 {0} 列受严重影响")
        m.putIfAbsent("Short-run", "缩短运行")
        m.putIfAbsent("Over 15 min", "超过 15 分钟")
        m.putIfAbsent("Trains that departed in the last 3 hours, in both directions. Critical: cancelled, short-run or more than 15 minutes late.", "最近 3 小时内发车的列车，双向。严重：停运、缩短运行或晚点超过 15 分钟。")
        m.putIfAbsent("My trips", "我的行程")
        m.putIfAbsent("Trains followed to arrival, delays this month", "跟踪至到达的列车，本月晚点")
        m.putIfAbsent("Previous month", "上个月")
        m.putIfAbsent("Next month", "下个月")
        m.putIfAbsent("No trips yet", "还没有行程")
        m.putIfAbsent("When you follow a train (the «Follow» button on the train page) until it arrives, the trip appears here with its delay. It stays on this phone only.", "当你跟踪一列火车（列车页面上的「跟踪」按钮）直到到达，行程会连同晚点显示在这里。数据只保存在这部手机上。")
        m.putIfAbsent("No trips this month.", "本月没有行程。")
        m.putIfAbsent("The trip log stays on this phone only.", "行程记录只保存在这部手机上。")
        m.putIfAbsent("Clear the trip log", "清除行程记录")
        m.putIfAbsent("Delete all saved trips?", "删除所有已保存的行程？")
        m.putIfAbsent("Trips", "行程")
        m.putIfAbsent("Delay of 15 min or more", "晚点 15 分钟或以上")
        m.putIfAbsent("Delay of 60 min or more", "晚点 60 分钟或以上")
        m.putIfAbsent("Total minutes of delay", "晚点总分钟数")
        m.putIfAbsent("With a delay of 60 minutes or more you can claim compensation.", "晚点 60 分钟或以上可以申请赔偿。")
        m.putIfAbsent("If you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation.", "如果你有月票，晚点会计入月度奖励（Trenord）或赔偿。")
    }
}
