package com.binario.treni.data

/** Perché un treno conta come «critico» per il grado di disagio della linea. */
enum class Disruption { CANCELLED, LIMITED, LATE }

/** Cosa controllare in sfondo: una linea preferita o una tratta preferita (trattata come linea tra le due stazioni). */
data class DisruptionTarget(val line: Linea, val isRoute: Boolean)

/** Grado di disagio: treni critici sui treni controllati (partiti di recente, in entrambe le direzioni). */
data class DisruptionSummary(val checked: Int, val cancelled: Int, val limited: Int, val late: Int) {
    val critical: Int get() = cancelled + limited + late

    /** Percentuale di treni critici, arrotondata; 0 se non c'è nessun treno controllato. */
    val percent: Int get() = if (checked == 0) 0 else Math.round(critical * 100f / checked)
}

/**
 * «Grado di disagio» di una linea, calcolato sul telefono quando si apre la linea.
 * Un treno è critico se è soppresso, limitato o parzialmente soppresso, oppure ha più di [LATE_MIN] minuti di ritardo
 * (all'arrivo se è arrivato, altrimenti adesso). Si guardano solo i treni partiti nelle ultime [WINDOW_MS]:
 * quelli non ancora partiti non dicono nulla sul disagio di oggi.
 */
object LineDisruption {
    const val LATE_MIN = 15
    const val WINDOW_MS = 3 * 3_600_000L

    /** Al massimo tanti treni per linea: ogni treno è una richiesta. */
    const val MAX_TRAINS = 16

    /** Le note di ViaggiaTreno/Trenord che indicano un treno limitato o soppresso solo in parte. */
    private val LIMITED = Regex(
        "(?i)limitat[oa]|limitazione|parzialmente soppress|soppress[oa] parzialmente|parzialmente cancellat|" +
            "soppress[oa] (da|tra|fra|fino|nella tratta|sulla tratta)|" +
            "origine anticipata|destinazione anticipata|partially cancel|terminates at",
    )

    fun isLimited(info: String): Boolean = LIMITED.containsMatchIn(info)

    /** Ritardo che conta: quello all'arrivo se il treno è arrivato, altrimenti quello attuale. */
    fun delayOf(st: TrainStatus): Int = if (st.arrived) (st.stops.lastOrNull()?.delay ?: st.delay) else st.delay

    fun classify(st: TrainStatus): Disruption? = when {
        st.cancelled -> Disruption.CANCELLED
        isLimited(st.info) -> Disruption.LIMITED
        st.departed && delayOf(st) > LATE_MIN -> Disruption.LATE
        else -> null
    }

    /** Si contano i treni partiti (o soppressi); quelli non ancora partiti restano fuori. */
    fun summarize(list: List<TrainStatus>): DisruptionSummary {
        val seen = list.filter { it.cancelled || it.departed }
        val kinds = seen.map { classify(it) }
        return DisruptionSummary(
            checked = seen.size,
            cancelled = kinds.count { it == Disruption.CANCELLED },
            limited = kinds.count { it == Disruption.LIMITED },
            late = kinds.count { it == Disruption.LATE },
        )
    }

    /** Livello del disagio, uguale ai colori della scheda: 0 basso (sotto il 10%), 1 medio (fino al 25%), 2 alto. */
    fun level(percent: Int): Int = when {
        percent < 10 -> 0
        percent <= 25 -> 1
        else -> 2
    }

    /** Giorni tenuti nell'andamento del disagio. */
    const val HISTORY_DAYS = 7

    /**
     * Andamento: per ogni giorno («aaaa-mm-gg») il disagio peggiore visto, dal più recente; testo «giorno:percentuale,…».
     * Aggiunge [percent] a [day] (tiene il più alto) e lascia solo gli ultimi [HISTORY_DAYS] giorni.
     */
    fun historyAdd(encoded: String?, day: String, percent: Int): String {
        val m = historyDecode(encoded).toMap().toMutableMap()
        m[day] = maxOf(m[day] ?: 0, percent.coerceIn(0, 100))
        return m.entries.sortedByDescending { it.key }.take(HISTORY_DAYS).joinToString(",") { "${it.key}:${it.value}" }
    }

    fun historyDecode(encoded: String?): List<Pair<String, Int>> =
        encoded.orEmpty().split(',').mapNotNull { p ->
            val d = p.substringBefore(':', "")
            val v = p.substringAfter(':', "").toIntOrNull()
            if (d.length == 10 && v != null) d to v else null
        }.sortedByDescending { it.first }

    /** «Non avvisare oggi»: silenzio fino alla prossima mezzanotte, ora italiana (anche nei giorni del cambio d'ora). */
    fun endOfDay(now: Long): Long = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Rome")).apply {
        timeInMillis = now
        add(java.util.Calendar.DAY_OF_MONTH, 1)
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis

    /**
     * Percentuale da ricordare per il controllo successivo: con meno di [ALERT_MIN_CHECKED] treni (sera, rete lenta)
     * la lettura non dice nulla e si tiene quella di prima; altrimenti un «0%» su 1 treno farebbe ripartire l'avviso
     * entro le 3 ore anche se il disagio non è mai finito.
     */
    fun percentToKeep(s: DisruptionSummary, lastPercent: Int): Int = if (s.checked < ALERT_MIN_CHECKED) lastPercent else s.percent

    /** Notifica per una linea preferita: oltre il 25% di treni critici, su almeno 4 treni controllati. */
    const val ALERT_PERCENT = 25
    const val ALERT_MIN_CHECKED = 4

    /** Se il disagio resta alto, la notifica si ripete al massimo ogni 3 ore. */
    const val ALERT_REPEAT_MS = 3 * 3_600_000L

    /**
     * Avvisare? Sì se il disagio è alto e prima non lo era ([lastPercent] del controllo precedente),
     * oppure se è ancora alto ma l'ultima notifica ([lastAlertAt]) è di più di 3 ore fa.
     */
    fun shouldAlert(s: DisruptionSummary, lastPercent: Int, lastAlertAt: Long, now: Long): Boolean =
        s.checked >= ALERT_MIN_CHECKED && s.percent > ALERT_PERCENT &&
            (lastPercent <= ALERT_PERCENT || now - lastAlertAt >= ALERT_REPEAT_MS)

    /**
     * Linee e tratte preferite da controllare: prima le linee, poi le tratte; niente svizzere (limite di richieste);
     * una tratta con gli stessi capolinea di una linea (in qualunque verso) conta una volta sola; al massimo [max].
     */
    fun targets(lines: List<Linea>, routes: List<Tratta>, max: Int): List<DisruptionTarget> {
        fun swiss(id: String) = id.startsWith(SwissNews.SWISS_ID)
        fun pair(a: Station, b: Station) = setOf(a.id, b.id)
        val out = mutableListOf<DisruptionTarget>()
        val seen = mutableSetOf<Set<String>>()
        // Le linee TILO usano l'orario svizzero, che ha un limite di richieste al giorno: in sfondo non si controllano
        lines.filter { !swiss(it.a.id) && !swiss(it.b.id) && !it.operator.equals("TILO", true) }.forEach { l -> if (seen.add(pair(l.a, l.b))) out += DisruptionTarget(l, false) }
        routes.filter { !swiss(it.from.id) && !swiss(it.to.id) && it.from.id != it.to.id }.forEach { r ->
            if (seen.add(pair(r.from, r.to))) out += DisruptionTarget(Linea("", r.from, r.to), true)
        }
        return out.take(max)
    }

    /** Numeri dei treni diretti partiti nella finestra, senza doppioni, al massimo [MAX_TRAINS]. */
    fun candidates(solutions: List<Solution>, now: Long): List<String> =
        solutions.asSequence()
            .filter { it.legs.size == 1 && it.dep in (now - WINDOW_MS)..now }
            .sortedByDescending { it.dep }
            .map { it.legs.first().number }
            .filter { it.isNotBlank() }
            .distinct()
            .take(MAX_TRAINS)
            .toList()
}
