package com.binario.treni.data

/**
 * Traduzione francese dell'interfaccia. Le chiavi sono i testi inglesi (EN e tr(it, en)): una sola tabella copre
 * entrambi i sistemi; PAIRS risolve le poche parole inglesi ambigue (iniziali dei giorni, "Notes").
 * I testi senza traduzione restano in inglese. Divisa in più funzioni per non superare i limiti del bytecode.
 */
object Fr {
    private const val SEP = "\u0001"
    private val PAIRS: Map<String, String> = mapOf(
        "M" + SEP + "T" to "M",
        "G" + SEP + "T" to "J",
        "S" + SEP + "S" to "S",
        "D" + SEP + "S" to "D",
        "L" + SEP + "M" to "L",
        "M" + SEP + "W" to "M",
        "V" + SEP + "F" to "V",
        "Banconote" + SEP + "Notes" to "Billets",
    )
    private val MAP: HashMap<String, String> by lazy { HashMap<String, String>(2400).also { m -> m.putAll(mapOf("Price with a change: check sbb.ch or Trainline" to "Prix avec changement : à vérifier sur sbb.ch ou Trainline", "SBB fare (single ticket, adult)" to "Prix CFF (aller simple, adulte)", "Read on sbb.ch on" to "Relevé sur sbb.ch le", "Open on sbb.ch" to "Ouvrir sur sbb.ch", "2nd class" to "2e classe", "Where there is no 1st class (e.g. many regional trains) the 2nd class price is shown." to "Là où il n'y a pas de 1re classe (p. ex. beaucoup de régionaux), le prix de 2e classe est indiqué.", "App updates" to "Mises à jour de l'app", "Only strikes on my route" to "Seulement les grèves sur mon trajet", "at my times" to "à mes horaires", "change it in News › My route and times" to "à modifier dans Actualités › Mon trajet et mes horaires", "No route chosen: set your route in News › My route and times. Meanwhile you get national strikes and those in your region." to "Aucun trajet choisi : définis ton trajet dans Actualités › Mon trajet et mes horaires. En attendant, tu reçois les grèves nationales et celles de ta région.", "1st and 2nd class" to "1re et 2e classe", "Accessible to people with disabilities or reduced mobility" to "Accessible aux personnes handicapées ou à mobilité réduite", "Add shortcut" to "Ajouter un raccourci", "Replacement buses" to "Bus de remplacement", "Defibrillators" to "Défibrillateurs", "Remove shortcut" to "Supprimer un raccourci", "Remove the shortcut?" to "Supprimer le raccourci ?", "Done" to "Terminé", "The official app to call 112 sending your exact location." to "L'app officielle pour appeler le 112 en envoyant ta position exacte.", "No shortcuts: tap + to add the features you use most." to "Aucun raccourci : touche + pour ajouter les fonctions que tu utilises le plus.", "This route" to "Ce trajet", "This shortcut already exists" to "Ce raccourci existe déjà", "AREU Lombardy website" to "Site AREU Lombardie", "2nd class only" to "2e classe uniquement", "A station's departure board" to "Tableau des départs d'une gare", "Shortcuts" to "Raccourcis", "Tap the shortcut to remove." to "Touche le raccourci à supprimer.", "Bikes allowed" to "Vélos admis", "A specific train (by number)" to "Un train précis (par numéro)", "Do you really want to remove it? You can add it again with +." to "Veux-tu vraiment le supprimer ? Tu pourras l'ajouter de nouveau avec +.", "Station toilets" to "Toilettes en gare", "not available" to "non disponible", "1st class" to "1re classe")); p0(m); p1(m); p2(m); p3(m); p4(m); p5(m); p6(m); p7(m); p8(m); p9(m); p10(m); p11(m); p12(m); p13(m); p14(m); mapOf("SBB services at the station" to "Services CFF en gare", "SBB services not reachable right now." to "Services CFF injoignables pour le moment.", "Tap to retry" to "Touchez pour réessayer", "Reading services from the SBB website…" to "Lecture des services sur le site CFF…", "Hide shops and food" to "Masquer commerces et restauration", "Shops and food" to "Commerces et restauration", "open" to "ouverts", "Open" to "Ouvert", "Closed" to "Fermé", "Open/closed and hours: SBB website, refreshed every 5 minutes. All data without guarantee." to "Ouvert/fermé et horaires : site CFF, mis à jour toutes les 5 minutes. Toutes les données sans garantie.", "Station page on sbb.ch" to "Page de la gare sur sbb.ch").forEach { (k, v) -> m.putIfAbsent(k, v) }; mapOf("No region chosen" to "Aucune région choisie", "Notices and strikes in: " to "Avis et grèves en : ", " (and with no region given)" to " (et sans région indiquée)", "Change" to "Modifier", "Show only notices and strikes that affect these regions (plus national ones). You can pick more than one." to "Afficher uniquement les avis et grèves qui concernent ces régions (plus les nationaux). Tu peux en choisir plusieurs.", "Reset" to "Réinitialiser").forEach { (k, v) -> m.putIfAbsent(k, v) } } }

    private val TEMPLATES: List<Pair<String, String>> = listOf(
        "No out-of-service elevators or escalators reported at {0} (FerrovieNord/RFI). The station screen lists lifts per platform." to "Aucun ascenseur ou escalier mécanique hors service signalé à {0} (FerrovieNord/RFI). L'écran de la gare liste les ascenseurs par voie.",
        "Binario · scheduled times from Trenitalia/LeFrecce, generated on {0}. Check delays and changes before travelling." to "Binario · horaires prévus de Trenitalia/LeFrecce, générés le {0}. Vérifiez les retards et modifications avant de voyager.",
        "I can't find train {0} today. Check the number (it's on your ticket or the board) or search by station." to "Je ne trouve pas le train {0} aujourd'hui. Vérifiez le numéro (il figure sur votre billet ou le tableau) ou cherchez par gare.",
        "Band estimated from distance (about {0} km): check at the ticket office or in the Trenord app" to "Tranche estimée d'après la distance (environ {0} km) : vérifiez au guichet ou dans l'appli Trenord",
        "By car it would take about {0} minutes less each way, but you couldn't use the travel time." to "En voiture, vous mettriez environ {0} minutes de moins par trajet, mais vous ne pourriez pas utiliser le temps de trajet.",
        "By train you save about {0} minutes each way at rush hour (and you can read or work)." to "En train, vous gagnez environ {0} minutes par trajet aux heures de pointe (et vous pouvez lire ou travailler).",
        "Stops from {0} to the terminus · official Swiss timetable (transport.opendata.ch)" to "Arrêts de {0} au terminus · horaire officiel suisse (transport.opendata.ch)",
        "Which station do you leave from? Say for example \"from Varese to {0}\"." to "De quelle gare partez-vous ? Dites par exemple \"de Varese à {0}\".",
        "I can't find bus, metro, tram or taxi stops mapped within 400 m of {0}." to "Je ne trouve aucun arrêt de bus, métro, tram ou taxi référencé dans un rayon de 400 m autour de {0}.",
        "You board at {0}. Where do you get off? I'll warn you before the stop." to "Vous montez à {0}. Où descendez-vous ? Je vous préviendrai avant l'arrêt.",
        "You have already sent {0} messages today: try again tomorrow. Thanks!" to "Vous avez déjà envoyé {0} messages aujourd'hui : réessayez demain. Merci !",
        "No connection: timetable downloaded at {0} on {1}. Delays not updated." to "Pas de connexion : horaire téléchargé à {0} le {1}. Retards non actualisés.",
        "Platform change at {0}: train {1} now uses platform {2} instead of {3}." to "Changement de voie à {0} : le train {1} utilise maintenant la voie {2} au lieu de la {3}.",
        "The nearest station is {0} ({1}). Here are the next departures:" to "La gare la plus proche est {0} ({1}). Voici les prochains départs :",
        "In about {0} minutes you arrive at {1}. Start getting ready." to "Dans environ {0} minutes, vous arrivez à {1}. Commencez à vous préparer.",
        "You are already following {0}. Here is how it's going:" to "Vous suivez déjà {0}. Voici où ça en est :",
        "The {0} board isn't responding. Try again shortly." to "Le tableau de {0} ne répond pas. Réessayez dans un instant.",
        "Platform change: leaves from {0} instead of {1}." to "Changement de voie : part de la voie {0} au lieu de la {1}.",
        "Transitous · official {0} timetable (GTFS)" to "Transitous · horaire officiel de {0} (GTFS)",
        "I see no departures from {0} at that time." to "Je ne vois aucun départ de {0} à cette heure.",
        "Transport data not reachable now for {0}." to "Données de transport injoignables pour le moment pour {0}.",
        "≈ the CO₂ absorbed in a year by {0} trees" to "≈ le CO₂ absorbé en un an par {0} arbres",
        "{0} is not installed: choose another app" to "{0} n'est pas installé : choisissez une autre appli",
        "Expected delay: {0} minutes, leaves at " to "Retard prévu : {0} minutes, part à ",
        "I found {0} trains: which one is yours?" to "J'ai trouvé {0} trains : lequel est le vôtre ?",
        ", and shortly before {0} with the alarm" to ", et peu avant {0} avec l'alarme",
        "Departure: {0} — now choose the arrival" to "Départ : {0} — choisissez maintenant l'arrivée",
        "Message too long (max {0} characters)." to "Message trop long ({0} caractères maximum).",
        "No connections found from {0} to {1}." to "Aucune correspondance trouvée de {0} à {1}.",
        "Great, I'm following {0} for you. " to "Parfait, je suis {0} pour vous. ",
        "No disruptions reported for: {0}." to "Aucune perturbation signalée pour : {0}.",
        "Warning: train {0} is cancelled." to "Attention : le train {0} est supprimé.",
        "Train {0} is now {1} minutes late." to "Le train {0} a maintenant {1} minutes de retard.",
        "I can't find train {0} today." to "Je ne trouve pas le train {0} aujourd'hui.",
        "Board not available for {0}." to "Tableau indisponible pour {0}.",
        " I will warn you before {0}." to " Je vous préviendrai avant {0}.",
        "Does this train stop at {0}?" to "Ce train s'arrête-t-il à {0} ?",
        "So far in {0} ({1} days logged)" to "Jusqu'ici en {0} ({1} jours enregistrés)",
        "What time do you leave {0}?" to "À quelle heure partez-vous de {0} ?",
        "In a year ({0} travel days)" to "En un an ({0} jours de déplacement)",
        "Italo real-time data ({0})" to "Données en temps réel Italo ({0})",
        "You get off at {0} around " to "Vous descendez à {0} vers ",
        ", expected delay {0} min." to ", retard prévu {0} min.",
        "Out of service at {0}:\n" to "Hors service à {0} :\n",
        "Platform confirmed: {0}." to "Voie confirmée : {0}.",
        "Data from {0} (offline)" to "Données de {0} (hors ligne)",
        "Running {0} min early." to "Circule avec {0} min d'avance.",
        "Running {0} min late." to "Circule avec {0} min de retard.",
        "Next trains {0} → {1}:\n" to "Prochains trains {0} → {1} :\n",
        "Board at {0}: due at {1}" to "Embarquement à {0} : prévu à {1}",
        "Departures from {0}:" to "Départs de {0} :",
        "Departs from {0} at {1}" to "Part de {0} à {1}",
        "Outbound: {0} runs…" to "Aller : {0} courses…",
        ", {0} minutes late." to ", {0} minutes de retard.",
        "Train {0} not found" to "Train {0} introuvable",
        "Train {0} not found" to "Train {0} introuvable",
        " (contactless {0})" to " (sans contact {0})",
        " from platform {0}" to " de la voie {0}",
        "Return: {0} runs…" to "Retour : {0} courses…",
        "{0} minutes late." to "{0} minutes de retard.",
        "Alarm set for {0}" to "Alarme réglée pour {0}",
        "Services at {0}:" to "Services à {0} :",
        "Departs from {0}" to "Part de {0}",
        "Arrivals at {0}:" to "Arrivées à {0} :",
        "Board at {0} at {1}" to "Embarquement à {0} à {1}",
        "Days logged: {0}" to "Jours enregistrés : {0}",
        " {0} min late." to " {0} min de retard.",
        "Arrived at {0}" to "Arrivé à {0}",
        ", platform {0}" to ", voie {0}",
        ", platform {0}" to ", voie {0}",
        "Next stop: {0}" to "Prochain arrêt : {0}",
        "{0} min early" to "{0} min d'avance",
        "Next stop {0}" to "Prochain arrêt {0}",
        "{0} o'clock, {1}" to "{0} heures, {1}",
        "{0} min late" to "{0} min de retard",
        "Near {0}:" to "Près de {0} :",
        ", at {0}." to ", à {0}.",
        "Train {0}" to "Train {0}",
        " at {0}" to " à {0}",
    )
    private val compiled: List<Pair<Regex, String>> by lazy {
        TEMPLATES.map { (en, tr) ->
            val parts = en.split(Regex("\\{\\d\\}"))
            Regex("^" + parts.joinToString("(.+?)") { Regex.escape(it) } + "$", RegexOption.DOT_MATCHES_ALL) to tr
        }
    }
    private val cache = java.util.Collections.synchronizedMap(object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 300
    })

    private fun fromTemplate(en: String): String? {
        cache[en]?.let { return it.ifEmpty { null } }
        for ((re, tr) in compiled) {
            val m = re.matchEntire(en) ?: continue
            var z = tr
            for (g in 1 until m.groupValues.size) z = z.replace("{${g - 1}}", m.groupValues[g])
            cache[en] = z
            return z
        }
        cache[en] = ""
        return null
    }

    /** Testo tradotto per la coppia italiano/inglese; se manca, l'inglese. */
    fun of(it: String, en: String): String = PAIRS[it + SEP + en] ?: MAP[en] ?: (if (en.length in 4..400) fromTemplate(en) else null) ?: en

    fun has(en: String) = MAP.containsKey(en)

    private fun p0(m: HashMap<String, String>) {
        m[" early"] = " d'avance"
        m[" late"] = " de retard"
        m[" · contactless"] = " · sans contact"
        m["1 hour before"] = "1 heure avant"
        m["Cross-border passes"] = "Abonnements transfrontaliers"
        m["Accessibility"] = "Accessibilité"
        m["Buy"] = "Acheter"
        m["Now"] = "Maintenant"
        m["Crowding"] = "Affluence"
        m["Refresh"] = "Actualiser"
        m["Add"] = "Ajouter"
        m["Add a line, e.g. S5 Varese – Treviglio, to see the next trains in both directions."] = "Ajoutez une ligne, par ex. S5 Varese – Treviglio, pour voir les prochains trains dans les deux sens."
        m["Help & FAQ"] = "Aide et FAQ"
        m["Alarm when the train leaves the previous stop"] = "Alarme quand le train quitte l'arrêt précédent"
        m["Alarms"] = "Alarmes"
        m["NTV high speed"] = "Grande vitesse NTV"
        m["More"] = "Plus"
        m["Outbound"] = "Aller"
        m["Round trip"] = "Aller-retour"
        m["Cancel"] = "Annuler"
        m["Open in browser"] = "Ouvrir dans le navigateur"
        m["Open keyboard when choosing a station"] = "Ouvrir le clavier au choix de la gare"
        m["Open a departure board and tap ★ to save the station."] = "Ouvrez un tableau des départs et touchez ★ pour enregistrer la gare."
        m["Open a train and tap ★ to add it here."] = "Ouvrez un train et touchez ★ pour l'ajouter ici."
        m["Arcobaleno (Swiss section) + Trenord (Lombardy section): check the price when buying"] = "Arcobaleno (tronçon suisse) + Trenord (tronçon lombard) : vérifiez le prix à l'achat"
        m["Trenitalia personal area"] = "Espace personnel Trenitalia"
        m["Arrived on time"] = "Arrivé à l'heure"
        m["Arrivals"] = "Arrivées"
        m["Arrivals at "] = "Arrivées à "
        m["Arrival"] = "Arrivée"
        m["Out-of-service elevators and escalators"] = "Ascenseurs et escaliers mécaniques hors service"
        m["Assistance"] = "Assistance"
        m["Notify me"] = "Me prévenir"
        m["Notify me 10 minutes before arriving here"] = "Me prévenir 10 minutes avant l'arrivée ici"
        m["Notices"] = "Avis"
        m["Disruption alerts on favourite routes, lines and trains"] = "Alertes de perturbations sur les trajets, lignes et trains favoris"
        m["Alerts for deaf or hard-of-hearing people"] = "Alertes pour les personnes sourdes ou malentendantes"
        m["Backup saved"] = "Sauvegarde enregistrée"
        m["Bikes and light mobility"] = "Vélos et mobilité légère"
        m["Ticket offices, machines, validators, contactless"] = "Guichets, distributeurs, composteurs, sans contact"
        m["Tickets"] = "Billets"
        m["Tickets, passes and QR codes"] = "Billets, abonnements et codes QR"
        m["Ticket"] = "Billet"
        m["Regional ticket"] = "Billet régional"
        m["Cross-border ticket"] = "Billet transfrontalier"
        m["Platforms: elevators and ramps"] = "Quais : ascenseurs et rampes"
        m["Platform"] = "Voie"
        m["Calendar"] = "Calendrier"
        m["Strike calendar (Ministry)"] = "Calendrier des grèves (Ministère)"
        m["Change a Trenitalia booking"] = "Modifier une réservation Trenitalia"
        m["Terminus A"] = "Terminus A"
        m["Terminus A (e.g. Varese)"] = "Terminus A (par ex. Varese)"
        m["Terminus B"] = "Terminus B"
        m["Terminus B (e.g. Treviglio)"] = "Terminus B (par ex. Treviglio)"
        m["Loading station list (first time only)…"] = "Chargement de la liste des gares (première fois uniquement)…"
        m["Loading…"] = "Chargement…"
        m["Search"] = "Rechercher"
        m["Search timetable"] = "Rechercher un horaire"
        m["Search & Buy"] = "Rechercher et acheter"
        m["Search a station"] = "Rechercher une gare"
        m["Search a station for the departure board"] = "Rechercher une gare pour le tableau des départs"
        m["Search within 2 km"] = "Rechercher dans un rayon de 2 km"
        m["Close"] = "Fermer"
        m["Traffic"] = "Circulation"
        m["Connection very much at risk"] = "Correspondance très compromise"
        m["Tight connection"] = "Correspondance courte"
        m["How it works"] = "Comment ça marche"
        m["Same as system"] = "Comme le système"
        m["Operator announcements"] = "Communiqués des opérateurs"
        m["With delays of at least 60 minutes you are entitled to assistance: meals and refreshments in relation to the waiting time and, if needed, accommodation."] = "En cas de retard d'au moins 60 minutes, vous avez droit à une assistance : repas et rafraîchissements en rapport avec la durée de l'attente et, si nécessaire, un hébergement."
        m["Share"] = "Partager"
        m["Share timetable"] = "Partager l'horaire"
        m["Malpensa Express conditions"] = "Conditions du Malpensa Express"
        m["Trenitalia conditions"] = "Conditions de Trenitalia"
        m["Trenord conditions"] = "Conditions de Trenord"
        m["Conditions of carriage"] = "Conditions de transport"
        m["Conditions of carriage and rights"] = "Conditions de transport et droits"
        m["Conditions of carriage, tickets, bikes, pets, fines"] = "Conditions de transport, billets, vélos, animaux, amendes"
        m["General conditions of carriage (regional and long distance)"] = "Conditions générales de transport (régional et longue distance)"
        m["Specific conditions for the airport link"] = "Conditions spécifiques de la liaison aéroport"
        m["Compare"] = "Comparer"
        m["Compare routes"] = "Comparer les itinéraires"
        m["Contacts"] = "Contacts"
        m["Always check the updated document before travelling."] = "Consultez toujours le document à jour avant de voyager."
        m["Station coordinates not available"] = "Coordonnées de la gare indisponibles"
        m["Stop coordinates not available"] = "Coordonnées de l'arrêt indisponibles"
        m["From mobiles +39 02 32 32 32 · 6:45–21:30"] = "Depuis un mobile +39 02 32 32 32 · 6h45–21h30"
        m["Data imported"] = "Données importées"
        m["Direct"] = "Direct"
        m["Rail passengers' rights and obligations (PDF)"] = "Droits et obligations des voyageurs ferroviaires (PDF)"
        m["Disable maps"] = "Désactiver les cartes"
        m["Official documents"] = "Documents officiels"
        m["After a search, tap the download icon to save the timetable."] = "Après une recherche, touchez l'icône de téléchargement pour enregistrer l'horaire."
        m["During regional rail strikes, trains are normally guaranteed between 6:00–9:00 and 18:00–21:00, "] = "Lors des grèves du trafic régional, les trains sont normalement garantis entre 6h00–9h00 et 18h00–21h00, "
        m["Updated official lists"] = "Listes officielles mises à jour"
        m["List"] = "Liste"
        m["Full FerrovieNord list"] = "Liste complète FerrovieNord"
        m["Station list not available"] = "Liste des gares indisponible"
        m["Delete"] = "Supprimer"
        m["Ticket machines, validators, tobacconists, contactless payment"] = "Distributeurs de billets, composteurs, bureaux de tabac, paiement sans contact"
        m["Network error"] = "Erreur réseau"
        m["Error while saving"] = "Erreur lors de l'enregistrement"
        m["e.g. Varese → Como via Mendrisio or via Milan"] = "par ex. Varese → Côme via Mendrisio ou via Milan"
        m["e.g. Varese → Como: via Mendrisio (TILO) or via Milan. Duration, changes, cost and feasibility."] = "par ex. Varese → Côme : via Mendrisio (TILO) ou via Milan. Durée, changements, coût et faisabilité."
        m["Exclude categories"] = "Exclure des catégories"
        m["Export data"] = "Exporter les données"
        m["Feasible"] = "Faisable"
        m["Invalid file"] = "Fichier non valide"
        m["Source: OpenStreetMap. Tobacconists and newsagents often sell regional tickets, but not always: "] = "Source : OpenStreetMap. Les bureaux de tabac et les kiosques vendent souvent des billets régionaux, mais pas toujours : "
        m["Frecce, Intercity and Regional"] = "Frecce, Intercity et régionaux"
        m["General"] = "Général"
        m["My tickets"] = "Mes billets"
        m["My Italo trips"] = "Mes voyages Italo"
        m["On-board services (bikes, wheelchair spaces, classes) are not published in real-time data. "] = "Les services à bord (vélos, places pour fauteuils roulants, classes) ne sont pas publiés dans les données en temps réel. "
        m["Your rights in brief (EU 2021/782)"] = "Vos droits en bref (UE 2021/782)"
        m["The price via Milan is the Trenitalia/Trenord fare; the cross-border price is indicative: check at the ticket office or in the Trenord/SBB app."] = "Le prix via Milan est le tarif Trenitalia/Trenord ; le prix transfrontalier est indicatif : vérifiez au guichet ou dans l'appli Trenord/CFF."
        m["Import data"] = "Importer les données"
        m["Unable to load train data"] = "Impossible de charger les données du train"
        m["Settings"] = "Paramètres"
        m["Set"] = "Définir"
        m["On time"] = "À l'heure"
        m["Delay compensation: 25% of the ticket price for 60–119 minutes, 50% from 120 minutes. Operators may not pay amounts below €4."] = "Indemnisation en cas de retard : 25 % du prix du billet pour 60–119 minutes, 50 % à partir de 120 minutes. Les opérateurs peuvent ne pas verser les montants inférieurs à 4 €."
        m["Back"] = "Retour"
        m["Info"] = "Infos"
        m["RFI accessibility info"] = "Infos accessibilité RFI"
        m["Customer information and lost property"] = "Informations clients et objets trouvés"
        m["Information and bookings (replies on weekdays)"] = "Informations et réservations (réponse en semaine)"
        m["Swap"] = "Échanger"
        m["Italo · assistance"] = "Italo · assistance"
        m["Italo · news"] = "Italo · actualités"
        m["Purchases are made on the operator's official website: in-app purchase and synchronisation "] = "Les achats se font sur le site officiel de l'opérateur : achat et synchronisation dans l'appli "
        m["Delay compensation may not be due in cases of force majeure (e.g. extreme weather, natural disasters, major public health crises)."] = "L'indemnisation du retard peut ne pas être due en cas de force majeure (par ex. conditions météo extrêmes, catastrophes naturelles, graves crises sanitaires)."
        m["Flash blinking for alerts"] = "Clignotement du flash pour les alertes"
        m["Works"] = "Travaux"
        m["National and regional conditions may set different rules for passes and regional trains."] = "Les conditions nationales et régionales peuvent prévoir des règles différentes pour les abonnements et les trains régionaux."
        m["Legal"] = "Mentions légales"
        m["Lines"] = "Lignes"
        m["Favourite lines"] = "Lignes favorites"
        m["Lines, cross-border fares, services"] = "Lignes, tarifs transfrontaliers, services"
        m["Map"] = "Carte"
        m["FerrovieNord maintenance map"] = "Carte des travaux FerrovieNord"
        m["Max changes"] = "Changements max."
        m["Monthly and annual"] = "Mensuel et annuel"
        m["Change date, time or class"] = "Modifier la date, l'heure ou la classe"
        m["Show Buy button"] = "Afficher le bouton Acheter"
        m["Show later connections"] = "Afficher les correspondances suivantes"
        m["Later connections"] = "Correspondances suivantes"
        m["No elevators mapped for this station."] = "Aucun ascenseur recensé pour cette gare."
        m["No notices"] = "Aucun avis"
        m["No browser available"] = "Aucun navigateur disponible"
        m["No list published at the moment."] = "Aucune liste publiée pour le moment."
        m["No routes found for this time. Try later or another day (some lines do not run on Sundays)."] = "Aucun itinéraire trouvé à cette heure. Essayez plus tard ou un autre jour (certaines lignes ne circulent pas le dimanche)."
        m["No direct trains found in this direction"] = "Aucun train direct trouvé dans cette direction"
        m["No trains in the next hours"] = "Aucun train dans les prochaines heures"
        m["No traffic disruptions reported"] = "Aucune perturbation signalée"
        m["No calendar app found"] = "Aucune appli de calendrier trouvée"
        m["No email app"] = "Aucune appli de messagerie"
        m["No notifications. Use \"Notify me\" on a train or a connection."] = "Aucune notification. Utilisez \"Me prévenir\" sur un train ou une correspondance."
        m["No connections"] = "Aucune correspondance"
        m["No station found"] = "Aucune gare trouvée"
        m["No rail strikes announced"] = "Aucune grève ferroviaire annoncée"
        m["Nothing to save"] = "Rien à enregistrer"
        m["Not departed yet"] = "Pas encore parti"
        m["Not available at this time"] = "Indisponible pour le moment"
        m["Persistent notification on"] = "Notification permanente activée"
        m["Persistent notification enabled"] = "Notification permanente activée"
        m["Scheduled notification"] = "Notification programmée"
        m["Strike notifications"] = "Notifications de grève"
        m["Notifications"] = "Notifications"
        m["Scheduled notifications"] = "Notifications programmées"
        m["Scheduled notifications and wake-up alarms"] = "Notifications programmées et réveils"
        m["News"] = "Actualités"
        m["Name (e.g. S5, RE2)"] = "Nom (par ex. S5, RE2)"
        m["New favourite line"] = "Nouvelle ligne favorite"
        m["Train number"] = "Numéro du train"
        m["Station name"] = "Nom de la gare"
        m["Advanced options"] = "Options avancées"
        m["Times and changes: official Swiss timetable (transport.opendata.ch) and Trenitalia/LeFrecce. "] = "Horaires et changements : horaire officiel suisse (transport.opendata.ch) et Trenitalia/LeFrecce. "
        m["Offline timetables"] = "Horaires hors ligne"
        m["Timetable saved for offline use"] = "Horaire enregistré pour une utilisation hors ligne"
        m["Time already passed"] = "Heure déjà passée"
        m["Strike observatory unreachable right now"] = "Observatoire des grèves injoignable pour le moment"
        m["Official pages"] = "Pages officielles"
        m["Departure"] = "Départ"
        m["Origin and destination are the same"] = "L'origine et la destination sont identiques"
        m["Departures"] = "Départs"
        m["Departures from "] = "Départs de "
        m["Departures and arrivals from here"] = "Départs et arrivées d'ici"
        m["Step-free routes, 55 cm platforms"] = "Parcours sans marches, quais de 55 cm"
        m["People with disabilities or reduced mobility: free assistance in stations and on board, normally to be requested at least 24 hours in advance."] = "Personnes handicapées ou à mobilité réduite : assistance gratuite en gare et à bord, à demander normalement au moins 24 heures à l'avance."
        m["Arcobaleno zone map"] = "Plan des zones Arcobaleno"
        m["Several runs with this number"] = "Plusieurs courses portent ce numéro"
        m["Location & Maps"] = "Position et cartes"
        m["Location not available. Turn on GPS and try again."] = "Position indisponible. Activez le GPS et réessayez."
        m["Location not available: open the map first or turn on GPS."] = "Position indisponible : ouvrez d'abord la carte ou activez le GPS."
        m["Favourite"] = "Favori"
        m["Favourites"] = "Favoris"
        m["Trenitalia/Trenord fare"] = "Tarif Trenitalia/Trenord"
        m["Trenitalia/Trenord fare (1 adult)"] = "Tarif Trenitalia/Trenord (1 adulte)"
        m["Before arrival"] = "Avant l'arrivée"
        m["Before departure"] = "Avant le départ"
        m["Privacy & permissions"] = "Confidentialité et autorisations"
        m["You can check them in the operator's official timetable."] = "Vous pouvez les vérifier dans l'horaire officiel de l'opérateur."
        m["Recent"] = "Récents"
        m["Recent & favourites"] = "Récents et favoris"
        m["Complaints: the operator must reply within one month (up to three months in justified cases)."] = "Réclamations : l'opérateur doit répondre dans un délai d'un mois (jusqu'à trois mois dans les cas justifiés)."
        m["Lombardy regional trains and Malpensa Express"] = "Trains régionaux de Lombardie et Malpensa Express"
        m["Finding your location…"] = "Recherche de votre position…"
        m["Refunds and complaints"] = "Remboursements et réclamations"
        m["Remove"] = "Retirer"
        m["Expected arrival delay of at least 60 minutes: you can choose a refund, continuation, or re-routing."] = "Retard d'arrivée prévu d'au moins 60 minutes : vous pouvez choisir le remboursement, la poursuite du voyage ou le réacheminement."
        m["Return"] = "Retour"
        m["Ticket sellers"] = "Points de vente de billets"
        m["Nearby ticket sellers and offices"] = "Points de vente et guichets à proximité"
        m["Nearby ticket sellers"] = "Points de vente à proximité"
        m["Save"] = "Enregistrer"
        m["Save offline"] = "Enregistrer hors ligne"
        m["Saved offline"] = "Enregistré hors ligne"
        m["Choose the run"] = "Choisir la course"
        m["Choose origin and destination"] = "Choisir l'origine et la destination"
        m["Choose departure and arrival stations"] = "Choisir les gares de départ et d'arrivée"
        m["Start screen"] = "Écran d'accueil"
        m["Strikes"] = "Grèves"
        m["Strikes, traffic and works"] = "Grèves, circulation et travaux"
        m["Dark"] = "Sombre"
        m["If the operator offers no alternative within 100 minutes, you may arrange it yourself with other trains or buses and claim reasonable costs."] = "Si l'opérateur n'offre aucune alternative dans les 100 minutes, vous pouvez poursuivre par vos propres moyens avec d'autres trains ou bus et demander le remboursement des frais raisonnables."
        m["Report problems between train and station"] = "Signaler des problèmes entre le train et le quai"
        m["Follow"] = "Suivre"
        m["Following"] = "Suivi"
        m["Location permission needed"] = "Autorisation de localisation requise"
        m["Location permission is needed to find nearby stations."] = "L'autorisation de localisation est nécessaire pour trouver les gares proches."
        m["Grant permission"] = "Accorder l'autorisation"
        m["TILO services"] = "Services TILO"
        m["Services & accessibility"] = "Services et accessibilité"
        m["Station services"] = "Services en gare"
        m["Map service temporarily unreachable"] = "Service de cartes momentanément injoignable"
        m["TILO Pigiama night service"] = "Train de nuit TILO Pigiama"
        m["Summary for information only: the official text of the regulation and each operator's conditions prevails. "] = "Résumé à titre d'information uniquement : le texte officiel du règlement et les conditions de chaque opérateur prévalent. "
        m["Connections"] = "Correspondances"
        m["Cancelled"] = "Supprimé"
        m["Station"] = "Gare"
        m["Arrival station"] = "Gare d'arrivée"
        m["Departure station"] = "Gare de départ"
        m["Stations"] = "Gares"
        m["Favourite stations"] = "Gares favorites"
        m["Nearby stations"] = "Gares à proximité"
        m["Nearby stations and map"] = "Gares à proximité et carte"
        m["Wake me before this stop"] = "Me réveiller avant cet arrêt"
        m["TILO · Ticino and Lombardy"] = "TILO · Tessin et Lombardie"
        m["TILO · notices"] = "TILO · avis"
        m["Full fare tables"] = "Tableaux complets des tarifs"
        m["Departure board not available"] = "Tableau des départs indisponible"
        m["Station board"] = "Tableau de la gare"
        m["Lombardy regional fare: check the price"] = "Tarif régional de Lombardie : vérifiez le prix"
        m["Official Arcobaleno fare"] = "Tarif officiel Arcobaleno"
        m["Cross-border fares"] = "Tarifs transfrontaliers"
        m["Theme"] = "Thème"
        m["Leisure"] = "Loisirs"
        m["Type of connections"] = "Type de correspondances"
        m["Tickets and passes"] = "Billets et abonnements"
        m["Tickets, bikes, assistance"] = "Billets, vélos, assistance"
        m["Tap again for the departure board"] = "Touchez à nouveau pour le tableau des départs"
        m["Tap to open"] = "Touchez pour ouvrir"
        m["Tap a category to exclude it (struck through) or include it."] = "Touchez une catégorie pour l'exclure (barrée) ou l'inclure."
        m["Tap a stop for the board or the alarm."] = "Touchez un arrêt pour le tableau ou l'alarme."
        m["Traffic, delays and strikes"] = "Circulation, retards et grèves"
        m["Route"] = "Itinéraire"
        m["Favourite and recent routes"] = "Itinéraires favoris et récents"
        m["Trains"] = "Trains"
        m["Guaranteed trains"] = "Trains garantis"
        m["Guaranteed trains during strikes"] = "Trains garantis pendant les grèves"
        m["Guaranteed trains: updated official lists"] = "Trains garantis : listes officielles mises à jour"
        m["Favourite trains"] = "Trains favoris"
        m["Trenitalia · refunds and compensation"] = "Trenitalia · remboursements et indemnisation"
        m["Trenitalia · guaranteed trains"] = "Trenitalia · trains garantis"
        m["Trenitalia · travel information"] = "Trenitalia · informations voyageurs"
        m["Trenord · real-time traffic"] = "Trenord · circulation en temps réel"
        m["Train"] = "Train"
        m["Train not found"] = "Train introuvable"
        m["Followed train"] = "Train suivi"
        m["Train cancelled"] = "Train supprimé"
        m["Trenord · notices"] = "Trenord · avis"
        m["Trenord · notices and strikes"] = "Trenord · avis et grèves"
        m["Trenord · refunds and compensation"] = "Trenord · remboursements et indemnisation"
        m["Trenord: assistance for people with disabilities"] = "Trenord : assistance aux personnes handicapées"
        m["All"] = "Tout"
        m["Every day 8:15–19:45 · book at least 24 hours ahead"] = "Tous les jours 8h15–19h45 · réserver au moins 24 heures à l'avance"
        m["Use your location"] = "Utiliser ma position"
        m["Light green"] = "Vert clair"
        m["App version"] = "Version de l'appli"
        m["Via Mendrisio (TILO, cross-border)"] = "Via Mendrisio (TILO, transfrontalier)"
        m["Via Milan (Italy only)"] = "Via Milan (Italie uniquement)"
        m["Travellers with disabilities"] = "Voyageurs handicapés"
        m["Strong vibration with a different pattern per alert: stop alarm (3 long, repeated), reminder (3 short ×2), disruptions (2 long)"] = "Forte vibration avec un motif différent selon l'alerte : alarme d'arrêt (3 longues, répétées), rappel (3 courtes ×2), perturbations (2 longues)"
        m["Favourites widget"] = "Widget Favoris"
        m["Station widget"] = "Widget Gare"
        m["Route / Line widget"] = "Widget Itinéraire / Ligne"
        m["Train widget"] = "Widget Train"
        m["Arcobaleno zones"] = "Zones Arcobaleno"
        m["from "] = "de "
    }

    private fun p1(m: HashMap<String, String>) {
        m["of tickets require a commercial agreement with Trenitalia, Italo and Trenord."] = "de billets nécessitent un accord commercial avec Trenitalia, Italo et Trenord."
        m["no changes (direct only)"] = "sans changement (direct uniquement)"
        m["no data"] = "aucune donnée"
        m["not wheelchair accessible"] = "non accessible en fauteuil roulant"
        m["not set"] = "non défini"
        m["plus the trains listed by the operators. For long-distance trains, each operator's published lists apply. "] = "ainsi que les trains indiqués par les opérateurs. Pour les trains longue distance, les listes publiées par chaque opérateur s'appliquent. "
        m["direct only"] = "direct uniquement"
        m["check on site. Contactless payment is shown only if mapped."] = "à vérifier sur place. Le paiement sans contact n'est indiqué que s'il est référencé."
        m["♿ accessible"] = "♿ accessible"
        m["♿ limited access"] = "♿ accès limité"
        m["💳 cards"] = "💳 cartes"
        m["📶 contactless"] = "📶 sans contact"
        m["🛗 elevator"] = "🛗 ascenseur"
        m["RFI accessibility page"] = "Page accessibilité RFI"
        m["No out-of-service facilities reported for this station."] = "Aucune installation hors service signalée pour cette gare."
        m["Checking FerrovieNord and RFI…"] = "Vérification de FerrovieNord et RFI…"
        m["OpenStreetMap data unreachable."] = "Données OpenStreetMap injoignables."
        m["Source: OpenStreetMap (volunteer data, may be incomplete). Does not show today's faults."] = "Source : OpenStreetMap (données de bénévoles, éventuellement incomplètes). N'affiche pas les pannes du jour."
        m["FerrovieNord: station and elevator notices"] = "FerrovieNord : avis sur les gares et les ascenseurs"
        m["Varese, Como, Novara, Brescia–Iseo–Edolo lines"] = "Lignes Varese, Côme, Novare, Brescia–Iseo–Edolo"
        m["RFI Sala Blu assistance"] = "Assistance RFI Sala Blu"
        m["Book help getting on and off"] = "Réserver de l'aide pour monter et descendre"
        m["Wheelchair access"] = "Accès en fauteuil roulant"
        m["Open official timetable"] = "Ouvrir l'horaire officiel"
        m["Sala Blu assistance (people with disabilities)"] = "Assistance Sala Blu (personnes handicapées)"
        m["Not available for this train."] = "Non disponible pour ce train."
        m["Check on the Trenord website"] = "À vérifier sur le site de Trenord"
        m["Estimate provided by Trenord"] = "Estimation fournie par Trenord"
        m["Open announcement"] = "Ouvrir le communiqué"
        m["Source: Strike Observatory – Italian Ministry of Transport"] = "Source : Observatoire des grèves – Ministère italien des Transports"
        m["Strikes and travel info"] = "Grèves et infos voyageurs"
        m["No news"] = "Aucune actualité"
        m["I took the train today"] = "J'ai pris le train aujourd'hui"
        m["Latest news"] = "Dernières actualités"
        m["Strike calendar"] = "Calendrier des grèves"
        m["Official list of the Ministry of Transport"] = "Liste officielle du Ministère des Transports"
        m["Trenitalia travel info"] = "Infos voyageurs Trenitalia"
        m["Real-time traffic"] = "Circulation en temps réel"
        m["Choose what to show"] = "Choisir ce qu'il faut afficher"
        m["Real delays and platforms"] = "Retards et voies réels"
        m["Best connections"] = "Meilleures correspondances"
        m["High speed"] = "Grande vitesse"
        m["Regional"] = "Régional"
        m["All connections"] = "Toutes les correspondances"
        m["Ticket office"] = "Guichet"
        m["Self-service ticket machine"] = "Distributeur de billets"
        m["Validator"] = "Composteur"
        m["Authorised reseller"] = "Revendeur agréé"
        m["Elevator"] = "Ascenseur"
        m["Ramp"] = "Rampe"
        m["Strike"] = "Grève"
        m["Works and changes"] = "Travaux et modifications"
        m["Notice"] = "Avis"
        m["How green are you"] = "Votre empreinte verte"
        m["Train assistant"] = "Assistant train"
        m["How much CO₂, fuel, tolls and time you save"] = "Combien de CO₂, de carburant, de péages et de temps vous économisez"
        m["Ask about trains, delays, strikes and traffic"] = "Posez vos questions sur les trains, retards, grèves et la circulation"
        m["Language"] = "Langue"
        m["Legal notes"] = "Mentions légales"
        m["Colour-blind colours"] = "Couleurs pour daltoniens"
        m["Off"] = "Désactivé"
        m["Red-green (protanopia, deuteranopia)"] = "Rouge-vert (protanopie, deutéranopie)"
        m["Blue-yellow (tritanopia)"] = "Bleu-jaune (tritanopie)"
        m["version"] = "version"
        m["Version"] = "Version"
        m["Before you start"] = "Avant de commencer"
        m["Read the full legal notes"] = "Lire les mentions légales complètes"
        m["I understand and accept"] = "Je comprends et j'accepte"
        m["Binario is an independent app, not affiliated with Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO or SBB. Data comes from public sources and may contain errors: station boards, announcements and official channels always prevail. Estimated crowding, costs and times are indicative. All sources are public, free and cited in the legal notes. The app is free, ad-free, does not sell tickets and does not collect personal data."] = "Binario est une appli indépendante, non affiliée à Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO ou CFF. Les données proviennent de sources publiques et peuvent contenir des erreurs : les tableaux de gare, les annonces et les canaux officiels prévalent toujours. L'affluence, les coûts et les durées estimés sont indicatifs. Toutes les sources sont publiques, gratuites et citées dans les mentions légales. L'appli est gratuite, sans publicité, ne vend pas de billets et ne collecte aucune donnée personnelle."
        m["App created by Marco Jannino"] = "Appli créée par Marco Jannino"
        m["Punctuality"] = "Ponctualité"
        m["Monthly statistics by operator, station and train"] = "Statistiques mensuelles par opérateur, gare et train"
        m["of seats taken"] = "des places occupées"
        m["Source"] = "Source"
        m["No official data: estimate by time of day (weekday rush hours, trains to/from Milan)."] = "Pas de données officielles : estimation selon l'heure de la journée (heures de pointe en semaine, trains depuis/vers Milan)."
        m["Green: plenty of seats · Yellow: look for seats · Red: full, better wait for the next train"] = "Vert : beaucoup de places · Jaune : cherchez une place · Rouge : complet, mieux vaut attendre le train suivant"
        m["Real-time crowding in the Trenord app"] = "Affluence en temps réel dans l'appli Trenord"
        m["Scheduled"] = "Prévu"
        m["Actual"] = "Réel"
        m["Scheduled platform"] = "Voie prévue"
        m["Actual platform"] = "Voie réelle"
        m["Switzerland"] = "Suisse"
        m["All lines"] = "Toutes les lignes"
        m["Extracting the line list from the Trenord website…"] = "Extraction de la liste des lignes depuis le site de Trenord…"
        m["Trenord list not available right now."] = "Liste Trenord indisponible pour le moment."
        m["Open lines on the Trenord website"] = "Ouvrir les lignes sur le site de Trenord"
        m["FerrovieNord manages the infrastructure: trains on these lines are run by Trenord."] = "FerrovieNord gère l'infrastructure : les trains de ces lignes sont exploités par Trenord."
        m["Line added to favourites"] = "Ligne ajoutée aux favoris"
        m["Choose the two termini"] = "Choisissez les deux terminus"
        m["SBB rail traffic information"] = "Informations sur le trafic ferroviaire CFF"
        m["Real-time disruption map"] = "Carte des perturbations en temps réel"
        m["TILO notices"] = "Avis TILO"
        m["TILO cross-border lines"] = "Lignes transfrontalières TILO"
        m["Line status, notices and stations"] = "État des lignes, avis et gares"
        m["Official page"] = "Page officielle"
        m["Trenord, TILO, FerrovieNord, Switzerland"] = "Trenord, TILO, FerrovieNord, Suisse"
        m["Refresh now"] = "Actualiser maintenant"
        m["Updated at"] = "Mis à jour à"
        m["refreshes every 5 minutes"] = "actualisation toutes les 5 minutes"
        m["Official websites"] = "Sites officiels"
        m["Trenitalia · travel news"] = "Trenitalia · actualités voyageurs"
        m["Open source"] = "Code source ouvert"
        m["no date"] = "sans date"
        m["The full text is on the source website."] = "Le texte complet se trouve sur le site source."
        m["Hours"] = "Horaires"
        m["Who"] = "Qui"
        m["Where"] = "Où"
        m["Sector"] = "Secteur"
        m["Unions"] = "Syndicats"
        m["Notes"] = "Remarques"
        m["Station overview"] = "Aperçu de la gare"
        m["Platforms"] = "Voies"
        m["Platforms in use"] = "Voies utilisées"
        m["from today's trains"] = "d'après les trains du jour"
        m["not mapped"] = "non référencé"
        m["Lifts"] = "Ascenseurs"
        m["none mapped"] = "aucun référencé"
        m["escalators"] = "escaliers mécaniques"
        m["ramps"] = "rampes"
        m["none / not mapped"] = "aucun / non référencé"
        m["present"] = "présent"
        m["Ticket machines"] = "Distributeurs de billets"
        m["Validators"] = "Composteurs"
        m["none within 500 m"] = "aucun dans un rayon de 500 m"
        m["nearest at"] = "le plus proche à"
        m["Toilets"] = "Toilettes"
        m["available"] = "disponible"
        m["wheelchair accessible station"] = "gare accessible en fauteuil roulant"
        m["limited access"] = "accès limité"
        m["Lifts per platform"] = "Ascenseurs par voie"
        m["no lift mapped"] = "aucun ascenseur référencé"
        m["ramp"] = "rampe"
        m["Loading station services…"] = "Chargement des services de la gare…"
        m["Retry"] = "Réessayer"
        m["OpenStreetMap data unreachable right now."] = "Données OpenStreetMap injoignables pour le moment."
        m["OpenStreetMap volunteer data: may be incomplete. Today's faults are in the box below."] = "Données de bénévoles OpenStreetMap : peuvent être incomplètes. Les pannes du jour figurent dans l'encadré ci-dessous."
        m["Italo · info and support"] = "Italo · infos et assistance"
        m["Your position"] = "Votre position"
        m["Voice assistant (microphone on at start)"] = "Assistant vocal (micro activé au démarrage)"
        m["Followed train: alert on platform change or bigger delay"] = "Train suivi : alerte en cas de changement de voie ou de retard important"
        m["Voice alerts for blind or visually impaired people"] = "Alertes vocales pour les personnes aveugles ou malvoyantes"
        m["The phone's voice tells you where to catch the train (platform), when it leaves, platform changes and delays, and warns you with an insistent sound when your stop is near."] = "La voix du téléphone vous indique où prendre le train (voie), l'heure de départ, les changements de voie et les retards, et vous prévient par un son insistant quand votre arrêt approche."
        m["Voice alerts on. I will tell you the platform, the departure and the stop where to get off."] = "Alertes vocales activées. Je vous indiquerai la voie, le départ et l'arrêt où descendre."
        m["Announce every stop of the followed train"] = "Annoncer chaque arrêt du train suivi"
        m["Voice speed"] = "Vitesse de la voix"
        m["Slow"] = "Lente"
        m["Normal"] = "Normale"
        m["Fast"] = "Rapide"
        m["Voice test."] = "Test de la voix."
        m["Try the sounds: each one has a different meaning."] = "Essayez les sons : chacun a une signification différente."
        m["Stop coming up"] = "Arrêt imminent"
        m["Problem"] = "Problème"
        m["To ask by voice: long-press the Binario icon and choose “Ask by voice” (you can drag it to the Home screen), or add the “Binario · Ask by voice” tile to Quick Settings. With your phone's assistant say “Open Binario”. Works with TalkBack too."] = "Pour poser une question à la voix : appuyez longuement sur l'icône Binario et choisissez « Demander à la voix » (vous pouvez la glisser sur l'écran d'accueil), ou ajoutez la tuile « Binario · Demander à la voix » aux Réglages rapides. Avec l'assistant de votre téléphone, dites « Ouvre Binario ». Fonctionne aussi avec TalkBack."
        m["Connection at risk: the previous train is"] = "Correspondance compromise : le train précédent a"
        m["min late"] = "min de retard"
        m["Short change"] = "Correspondance courte"
        m["Change"] = "Changement"
        m["at"] = "à"
        m["planned"] = "prévu"
        m["Delay compensation"] = "Indemnisation du retard"
        m["Delay over 2 hours: you can claim 50% of the ticket price."] = "Retard de plus de 2 heures : vous pouvez demander 50 % du prix du billet."
        m["Delay over 1 hour: you can claim 25% of the ticket price."] = "Retard de plus d'1 heure : vous pouvez demander 25 % du prix du billet."
        m["Frecce 30–59 minutes late: Trenitalia grants compensation. Check the conditions on its website."] = "Frecce avec 30–59 minutes de retard : Trenitalia accorde une indemnisation. Consultez les conditions sur son site."
        m["The delay at your arrival station counts; season tickets have their own rules. Source: EU Regulation 2021/782 and operators' conditions."] = "Le retard à la gare d'arrivée est pris en compte ; les abonnements ont leurs propres règles. Source : règlement UE 2021/782 et conditions des opérateurs."
        m["Claim from Italo"] = "Demander à Italo"
        m["Claim from Trenitalia"] = "Demander à Trenitalia"
        m["Trenord refunds"] = "Remboursements Trenord"
        m["Trenitalia Regional compensation"] = "Indemnisation Trenitalia Regional"
        m["I board here"] = "Je monte ici"
        m["Platform, time and alerts for this stop (also by voice)"] = "Voie, heure et alertes pour cet arrêt (aussi à la voix)"
        m["I will alert you for boarding at"] = "Je vous préviendrai pour l'embarquement à"
        m["Only upcoming stop"] = "Seulement le prochain arrêt"
        m["All: platform, departure, changes, delays, stops"] = "Tout : voie, départ, changements, retards, arrêts"
        m["I will alert you by voice only when your stop is coming up."] = "Je vous préviendrai à la voix uniquement quand votre arrêt approchera."
        m["Do you want to turn this feature on?"] = "Voulez-vous activer cette fonction ?"
        m["Strong vibration with a different pattern for each alert (stop alarm, reminders, disruptions) and flashlight blinking. You can change it any time in Settings → Accessibility."] = "Forte vibration avec un motif différent pour chaque alerte (alarme d'arrêt, rappels, perturbations) et clignotement de la lampe torche. Vous pouvez la modifier à tout moment dans Paramètres → Accessibilité."
        m["Try the vibration"] = "Essayer la vibration"
        m["Yes, turn on"] = "Oui, activer"
        m["No, thanks"] = "Non, merci"
        m["Voice alerts for blind people"] = "Alertes vocales pour les personnes aveugles"
        m["The phone's voice tells you the platform, when the train leaves, platform changes and delays, and an insistent sound warns you when your stop is coming up."] = "La voix du téléphone vous indique la voie, l'heure de départ, les changements de voie et les retards, et un son insistant vous prévient quand votre arrêt approche."
        m["Yes, all voice alerts"] = "Oui, toutes les alertes vocales"
        m["Answer by voice"] = "Répondre à la voix"
        m["Hear the question again"] = "Réécouter la question"
        m["I heard"] = "J'ai entendu"
        m["Say yes, only stop, or no"] = "Dites oui, seulement l'arrêt, ou non"
        m["I didn't understand. Answer yes, only stop, or no. Or tap one of the buttons."] = "Je n'ai pas compris. Répondez oui, seulement l'arrêt, ou non. Ou touchez l'un des boutons."
        m["Voice alerts for blind or visually impaired people. Do you want to turn this feature on? You can choose: yes, for all voice alerts about platform, departure and stops; only stop, to be alerted only when your stop is coming up; or no."] = "Alertes vocales pour les personnes aveugles ou malvoyantes. Voulez-vous activer cette fonction ? Vous pouvez choisir : oui, pour toutes les alertes vocales sur la voie, le départ et les arrêts ; seulement l'arrêt, pour être prévenu uniquement quand votre arrêt approche ; ou non."
        m["Timetable PDF"] = "Horaire en PDF"
        m["All the day's runs, saved on your phone and available offline."] = "Toutes les courses de la journée, enregistrées sur votre téléphone et disponibles hors ligne."
        m["Today"] = "Aujourd'hui"
        m["Tomorrow"] = "Demain"
        m["Include return"] = "Inclure le retour"
        m["Saved in Download/Binario."] = "Enregistré dans Download/Binario."
        m["Open"] = "Ouvrir"
        m["No app to open PDFs"] = "Aucune appli pour ouvrir les PDF"
        m["Download PDF"] = "Télécharger le PDF"
        m["Could not create the timetable"] = "Impossible de créer l'horaire"
        m["Download the day's timetable as PDF"] = "Télécharger l'horaire du jour en PDF"
        m["Free"] = "Gratuit"
        m["Paid"] = "Payant"
        m["Free or paid: not stated"] = "Gratuit ou payant : non précisé"
        m["hours"] = "heures"
        m["Ask by voice"] = "Demander à la voix"
        m["Strikes and news"] = "Grèves et actualités"
        m["Current journey"] = "Trajet en cours"
        m["Stop"] = "Arrêter"
        m["Updating…"] = "Mise à jour…"
        m["Board at"] = "Embarquement à"
        m["platform"] = "voie"
        m["Next stop"] = "Prochain arrêt"
        m["Alarm before"] = "Alarme avant"
        m["Your journey"] = "Votre trajet"
        m["Open live status"] = "Ouvrir l'état en direct"
        m["Stop following"] = "Ne plus suivre"
        m["Assistant: trains, delays, platforms, strikes"] = "Assistant : trains, retards, voies, grèves"
        m["Downloaded PDFs are also in Download/Binario"] = "Les PDF téléchargés se trouvent aussi dans Download/Binario"
        m["Information"] = "Informations"
        m["Official sources, updated every 5 minutes"] = "Sources officielles, mises à jour toutes les 5 minutes"
        m["Regional vs regional, high speed vs high speed"] = "Régional contre régional, grande vitesse contre grande vitesse"
        m["Conditions of carriage, rights and refunds"] = "Conditions de transport, droits et remboursements"
        m["Operators' websites"] = "Sites des opérateurs"
        m["At the station and tickets"] = "En gare et billets"
        m["Nearby stations on the map"] = "Gares à proximité sur la carte"
        m["Official ticket sites and personal area"] = "Sites officiels de billetterie et espace personnel"
        m["Tools"] = "Outils"
        m["On: all alerts"] = "Activé : toutes les alertes"
        m["On: upcoming stop only"] = "Activé : seulement le prochain arrêt"
        m["Alerts for deaf people"] = "Alertes pour les personnes sourdes"
        m["On: vibration and flash"] = "Activé : vibration et flash"
        m["App"] = "Appli"
        m["What's new in each version"] = "Nouveautés de chaque version"
        m["Fix report"] = "Rapport de corrections"
        m["Problems fixed in each version"] = "Problèmes corrigés dans chaque version"
        m["Bus, metro, tram and taxi"] = "Bus, métro, tram et taxi"
        m["Looking for nearby stops and taxi ranks…"] = "Recherche des arrêts et stations de taxi à proximité…"
        m["No bus, metro, tram or taxi stop mapped within 400 m."] = "Aucun arrêt de bus, métro, tram ou taxi référencé dans un rayon de 400 m."
        m["Metro"] = "Métro"
        m["Tram"] = "Tram"
        m["Bus"] = "Bus"
        m["Taxi"] = "Taxi"
        m["Bike sharing"] = "Vélos en libre-service"
        m["Stops in maps"] = "Arrêts sur les cartes"
        m["Find a taxi"] = "Trouver un taxi"
        m["bus stop"] = "arrêt de bus"
        m["Lines and stops from OpenStreetMap data: for bus times and routes check the local transport company."] = "Lignes et arrêts issus des données OpenStreetMap : pour les horaires et itinéraires des bus, consultez la compagnie de transport locale."
        m["Metro entrance"] = "Entrée de métro"
        m["Tram stop"] = "Arrêt de tram"
        m["Bus stop"] = "Arrêt de bus"
        m["shelter"] = "abri"
        m["Taxi rank"] = "Station de taxi"
        m["spaces"] = "places"
        m["Tobacconists"] = "Bureaux de tabac"
        m["Newsagents"] = "Marchands de journaux"
        m["Ticket offices"] = "Guichets"
        m["Bus stops"] = "Arrêts de bus"
        m["Search on Google Maps:"] = "Rechercher sur Google Maps :"
        m["Can't find it? Search on Google Maps:"] = "Introuvable ? Rechercher sur Google Maps :"
        m["Looking for ticket sellers within"] = "Recherche de points de vente dans un rayon de"
        m["saved data"] = "données enregistrées"
        m["OpenStreetMap servers are not responding (tried 3 Overpass servers and Postpass). Try again shortly or search on Google Maps."] = "Les serveurs OpenStreetMap ne répondent pas (3 serveurs Overpass et Postpass essayés). Réessayez dans un instant ou cherchez sur Google Maps."
        m["OpenStreetMap data unreachable right now (tried 3 Overpass servers and Postpass)."] = "Données OpenStreetMap injoignables pour le moment (3 serveurs Overpass et Postpass essayés)."
        m["Pull down to retry"] = "Tirez vers le bas pour réessayer"
        m["Pull down to refresh."] = "Tirez vers le bas pour actualiser."
        m["refreshes every 5 minutes or when you pull down"] = "actualisation toutes les 5 minutes ou en tirant vers le bas"
        m["No ticket sellers within"] = "Aucun point de vente dans un rayon de"
        m["No ticket sellers found and the OpenStreetMap servers are not responding. Use the official Trenitalia map or try again."] = "Aucun point de vente trouvé et les serveurs OpenStreetMap ne répondent pas. Utilisez la carte officielle Trenitalia ou réessayez."
        m["Mooney outlets"] = "Points de vente Mooney"
        m["Official Trenitalia map (all of Italy)"] = "Carte officielle Trenitalia (toute l'Italie)"
        m["Sources"] = "Sources"
        m["Trenord authorised resellers and ticket offices"] = "Revendeurs agréés et guichets Trenord"
        m["list of"] = "liste de"
        m["updated weekly; open/closed checked now"] = "mise à jour chaque semaine ; ouvert/fermé vérifié maintenant"
        m["SBB ticket machines (open data data.sbb.ch)"] = "Distributeurs de billets CFF (données ouvertes data.sbb.ch)"
        m["ticket offices, machines and validators from"] = "guichets, distributeurs et composteurs de"
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney outlets: the official Trenitalia map shows them."] = "Ailleurs en Italie, les billets régionaux Trenitalia sont vendus aux points de vente PuntoLIS et Mooney : la carte officielle Trenitalia les indique."
        m["Nearest station"] = "Gare la plus proche"
        m["Authorised resellers"] = "Revendeurs agréés"
        m["nearest"] = "le plus proche"
        m["see the official Trenitalia map in Resellers"] = "voir la carte officielle Trenitalia dans Revendeurs"
        m["Downloading Trenord sellers…"] = "Téléchargement des revendeurs Trenord…"
        m["Checking who is open now…"] = "Vérification des ouvertures en cours…"
        m["Sells"] = "Vend"
        m["altoadigemobilità outlets (South Tyrol)"] = "Points de vente altoadigemobilità (Tyrol du Sud)"
        m["Railway companies"] = "Compagnies ferroviaires"
        m["All companies in Italy and Switzerland: sites, tickets, data"] = "Toutes les compagnies d'Italie et de Suisse : sites, billets, données"
        m["Search company or region"] = "Rechercher une compagnie ou une région"
        m["no public data"] = "pas de données publiques"
        m["Website"] = "Site web"
        m["Where to buy"] = "Où acheter"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. Italian railways with their own network (EAV, FSE, Ferrotramviaria, FAL, Circumetnea, ARST and others) publish real-time data only on their own site and app."] = "Les données en temps réel des trains du réseau RFI proviennent de ViaggiaTreno ; pour toutes les compagnies suisses, de l'horaire officiel suisse. Les chemins de fer italiens avec leur propre réseau (EAV, FSE, Ferrotramviaria, FAL, Circumetnea, ARST et autres) ne publient les données en temps réel que sur leur site et leur appli."
        m["Only departures are available for Swiss stations"] = "Seuls les départs sont disponibles pour les gares suisses"
        m["not yet included (data only in daily files too heavy for a phone: see note in Punctuality)"] = "pas encore inclus (données uniquement dans des fichiers quotidiens trop lourds pour un téléphone : voir la note dans Ponctualité)"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. For EAV, ARST, Trentino Trasporti and Cotral the app shows scheduled times (Transitous). The other railways with their own network publish timetables and real-time data only on their site and app."] = "Les données en temps réel des trains du réseau RFI proviennent de ViaggiaTreno ; pour toutes les compagnies suisses, de l'horaire officiel suisse. Pour EAV, ARST, Trentino Trasporti et Cotral, l'appli affiche les horaires prévus (Transitous). Les autres chemins de fer avec leur propre réseau ne publient horaires et données en temps réel que sur leur site et leur appli."
        m["Only departures are available for this station"] = "Seuls les départs sont disponibles pour cette gare"
        m["Operator's scheduled times (Transitous): delays appear only if the operator publishes them."] = "Horaires prévus par l'opérateur (Transitous) : les retards n'apparaissent que si l'opérateur les publie."
        m["Nearby toilets"] = "Toilettes à proximité"
        m["Free or paid, accessible, opening hours"] = "Gratuites ou payantes, accessibles, horaires d'ouverture"
        m["Free or paid, accessible, baby changing, opening hours"] = "Gratuites ou payantes, accessibles, table à langer, horaires d'ouverture"
        m["Authorised resellers, ticket offices, machines, contactless"] = "Revendeurs agréés, guichets, distributeurs, sans contact"
    }

    private fun p2(m: HashMap<String, String>) {
        m["Looking for toilets within"] = "Recherche de toilettes dans un rayon de"
        m["OpenStreetMap servers are not responding. Try again shortly or search on Google Maps."] = "Les serveurs OpenStreetMap ne répondent pas. Réessayez dans un instant ou cherchez sur Google Maps."
        m["Accessible ♿"] = "Accessibles ♿"
        m["Within 2 km"] = "Dans un rayon de 2 km"
        m["Public toilets"] = "Toilettes publiques"
        m["No toilets mapped within"] = "Aucune toilette référencée dans un rayon de"
        m["Prices, hours and accessibility come from OpenStreetMap volunteers: check on site."] = "Les prix, horaires et l'accessibilité proviennent de bénévoles OpenStreetMap : vérifiez sur place."
        m["♿ partly accessible"] = "♿ partiellement accessible"
        m["🚼 baby changing"] = "🚼 table à langer"
        m["customers only"] = "clients uniquement"
        m["for customers"] = "pour les clients"
        m["min walk"] = "min à pied"
        m["Service status"] = "État du service"
        m["Check that all data sources respond"] = "Vérifier que toutes les sources de données répondent"
        m["Check again"] = "Vérifier à nouveau"
        m["Checking all data sources…"] = "Vérification de toutes les sources de données…"
        m["All sources respond correctly."] = "Toutes les sources répondent correctement."
        m["sources with problems: related features use fallbacks or the last saved data."] = "sources avec problèmes : les fonctions concernées utilisent des solutions de secours ou les dernières données enregistrées."
        m["Working"] = "Fonctionne"
        m["Checked at"] = "Vérifié à"
        m["Sources are external public services: if one is down the app tries alternatives (other servers, saved data, Google Maps)."] = "Les sources sont des services publics externes : si l'une est en panne, l'appli essaie des solutions alternatives (autres serveurs, données enregistrées, Google Maps)."
        m["Trains and boards"] = "Trains et tableaux"
        m["Journeys"] = "Trajets"
        m["News and strikes"] = "Actualités et grèves"
        m["Maps and station services"] = "Cartes et services en gare"
        m["The app closed unexpectedly"] = "L'appli s'est fermée de manière inattendue"
        m["Do you want to send the report to the developer? It contains only the technical error details, the phone model and the Android version: no personal data, location or trips."] = "Voulez-vous envoyer le rapport au développeur ? Il ne contient que les détails techniques de l'erreur, le modèle du téléphone et la version d'Android : aucune donnée personnelle, position ni trajet."
        m["Binario error report"] = "Rapport d'erreur Binario"
        m["Send report"] = "Envoyer le rapport"
        m["Ignore"] = "Ignorer"
        m["Your next train"] = "Votre prochain train"
        m["I won't suggest it again"] = "Ne plus le proposer"
        m["Not mine"] = "Pas le mien"
        m["to"] = "vers"
        m["leaves at"] = "part à"
        m["changed!"] = "modifié !"
        m["Alternatives"] = "Alternatives"
        m["Leaving earlier"] = "Partir plus tôt"
        m["Looking for alternatives…"] = "Recherche d'alternatives…"
        m["No alternative soon."] = "Aucune alternative prochainement."
        m["Route ready in the Search tab"] = "Itinéraire prêt dans l'onglet Recherche"
        m["Learn the trains I take often"] = "Apprendre les trains que je prends souvent"
        m["From the board, journeys, Follow and favourites. Stays on the phone only."] = "À partir du tableau, des trajets, de Suivre et des favoris. Reste uniquement sur le téléphone."
        m["Alert me automatically about my usual train"] = "Me prévenir automatiquement pour mon train habituel"
        m["In the 45 minutes before departure: delay, cancellation, platform change and ready alternatives"] = "Dans les 45 minutes avant le départ : retard, suppression, changement de voie et alternatives prêtes"
        m["Forget"] = "Oublier"
        m["No usual train yet: it appears after you open it at least twice on the same weekday."] = "Pas encore de train habituel : il apparaît après l'avoir ouvert au moins deux fois le même jour de la semaine."
        m["Download failed. Check your connection and try again."] = "Échec du téléchargement. Vérifiez votre connexion et réessayez."
        m["A new version is available"] = "Une nouvelle version est disponible"
        m["Downloading the update…"] = "Téléchargement de la mise à jour…"
        m["To install the update allow Binario to install apps (Android asks only once), then come back here."] = "Pour installer la mise à jour, autorisez Binario à installer des applis (Android ne le demande qu'une fois), puis revenez ici."
        m["Update downloaded. Confirm the installation in the Android window: favourites and settings are kept."] = "Mise à jour téléchargée. Confirmez l'installation dans la fenêtre Android : les favoris et les paramètres sont conservés."
        m["Do you want to update Binario? The app downloads the new version by itself; favourites and settings are kept."] = "Voulez-vous mettre à jour Binario ? L'appli télécharge elle-même la nouvelle version ; les favoris et les paramètres sont conservés."
        m["What's new"] = "Nouveautés"
        m["Allow"] = "Autoriser"
        m["Install"] = "Installer"
        m["Later"] = "Plus tard"
        m["Feedback and bug reports"] = "Avis et rapports de bugs"
        m["Write to the developer: ideas, suggestions, problems"] = "Écrire au développeur : idées, suggestions, problèmes"
        m["Suggestions, ideas or something not working? Write it here: the message goes straight to the developer."] = "Une suggestion, une idée ou quelque chose ne fonctionne pas ? Écrivez-le ici : le message va directement au développeur."
        m["Suggestion"] = "Suggestion"
        m["Report a bug"] = "Signaler un bug"
        m["Full name"] = "Nom complet"
        m["Enter your full name"] = "Saisissez votre nom complet"
        m["Invalid email"] = "E-mail non valide"
        m["Only used to reply to you"] = "Utilisé uniquement pour vous répondre"
        m["Describe the problem"] = "Décrivez le problème"
        m["Your feedback"] = "Votre avis"
        m["What you were doing, what happened and what you expected (e.g. station, train number, time)."] = "Ce que vous faisiez, ce qui s'est passé et ce que vous attendiez (par ex. gare, numéro de train, heure)."
        m["What you like, what you would improve, what is missing."] = "Ce que vous aimez, ce que vous amélioreriez, ce qui manque."
        m["Write at least a few words"] = "Écrivez au moins quelques mots"
        m["Attach technical details"] = "Joindre les détails techniques"
        m["App version, phone model and Android version: they help find the problem."] = "Version de l'appli, modèle du téléphone et version d'Android : ils aident à trouver le problème."
        m["Thank you! Message sent."] = "Merci ! Message envoyé."
        m["No connection: the message is saved and will be sent automatically as soon as possible."] = "Pas de connexion : le message est enregistré et sera envoyé automatiquement dès que possible."
        m["Sending…"] = "Envoi…"
        m["Send"] = "Envoyer"
        m["Name and email are only used to reply to you and nothing else. The message contains no location, trips or favourites."] = "Le nom et l'e-mail servent uniquement à vous répondre, rien d'autre. Le message ne contient ni position, ni trajets, ni favoris."
        m["Email"] = "E-mail"
        m["I recommend Binario, the free train app for Italy and Switzerland: timetables, live delays, platforms, strikes, Trenord and FerrovieNord, alerts for your train. No ads."] = "Je recommande Binario, l'appli de trains gratuite pour l'Italie et la Suisse : horaires, retards en direct, voies, grèves, Trenord et FerrovieNord, alertes pour votre train. Sans publicité."
        m["Download the latest version for Android:"] = "Téléchargez la dernière version pour Android :"
        m["After downloading, open the file and allow the installation: the app then updates itself."] = "Après le téléchargement, ouvrez le fichier et autorisez l'installation : l'appli se met ensuite à jour toute seule."
        m["App not installed: choose another app"] = "Appli non installée : choisissez une autre appli"
        m["Share Binario"] = "Partager Binario"
        m["Send your contacts the link to download the latest version of the app."] = "Envoyez à vos contacts le lien pour télécharger la dernière version de l'appli."
        m["Other apps (SMS, email…)"] = "Autres applis (SMS, e-mail…)"
        m["Send the app to your contacts on WhatsApp, Telegram…"] = "Envoyez l'appli à vos contacts sur WhatsApp, Telegram…"
        m["STIBM area"] = "Zone STIBM"
        m["How much it costs"] = "Combien ça coûte"
        m["From"] = "De"
        m["To"] = "À"
        m["The journey goes through Milan"] = "Le trajet passe par Milan"
        m["In that case zone Mi1 is also needed"] = "Dans ce cas, la zone Mi1 est également nécessaire"
        m["zones"] = "zones"
        m["Same zone: the minimum 2-zone fare still applies (the one with the inner zone is fine too)."] = "Même zone : le tarif minimum de 2 zones s'applique quand même (celui avec la zone intérieure convient aussi)."
        m["Note: this station is outside the STIBM area. It is only valid for changing train or bus, not as start or end of a STIBM ticket."] = "Remarque : cette gare est en dehors de la zone STIBM. Elle ne sert que pour changer de train ou de bus, pas comme départ ou arrivée d'un billet STIBM."
        m["Single ticket"] = "Billet simple"
        m["min"] = "min"
        m["Carnet of 10 (Trenord website and app)"] = "Carnet de 10 (site et appli Trenord)"
        m["Daily (24 hours)"] = "Journalier (24 heures)"
        m["3 days"] = "3 jours"
        m["Weekly (Mon–Sun)"] = "Hebdomadaire (lun–dim)"
        m["Monthly"] = "Mensuel"
        m["Yearly"] = "Annuel"
        m["Monthly under 26 / over 65"] = "Mensuel moins de 26 ans / plus de 65 ans"
        m["Yearly under 26 / over 65"] = "Annuel moins de 26 ans / plus de 65 ans"
        m["Yearly ISEE below €6,000"] = "Annuel ISEE inférieur à 6 000 €"
        m["Prices valid from"] = "Prix valables à partir du"
        m["Valid on Trenord and Trenitalia regional trains in 2nd class, metro, trams and buses."] = "Valable sur les trains régionaux Trenord et Trenitalia en 2e classe, dans le métro, les trams et les bus."
        m["Main rules"] = "Règles principales"
        m["Zone map"] = "Plan des zones"
        m["Fares"] = "Tarifs"
        m["Rules"] = "Règles"
        m["Stations in the STIBM area"] = "Gares de la zone STIBM"
        m["Search station or town"] = "Rechercher une gare ou une ville"
        m["outside the area, interchange only"] = "hors de la zone, correspondance uniquement"
        m["service suspended"] = "service suspendu"
        m["Use for the calculation"] = "Utiliser pour le calcul"
        m["Source: Trenord, STIBM area – areas and fares"] = "Source : Trenord, zone STIBM – zones et tarifs"
        m["Choose the station"] = "Choisir la gare"
        m["Station not found"] = "Gare introuvable"
        m["Outside the STIBM area (interchange only)"] = "Hors de la zone STIBM (correspondance uniquement)"
        m["zone"] = "zone"
        m["fares"] = "tarifs"
        m["STIBM area · Milan and Monza Brianza"] = "Zone STIBM · Milan et Monza Brianza"
        m["Zones, prices and stations of the integrated ticket"] = "Zones, prix et gares du billet intégré"
        m["One ticket for Trenord and Trenitalia regional trains, metro, trams and buses in the Metropolitan City of Milan, the province of Monza and Brianza and some nearby towns. The price depends on the number of zones (Mi1…Mi9) between start and end, not on the vehicle."] = "Un seul billet pour les trains régionaux Trenord et Trenitalia, le métro, les trams et les bus de la Ville métropolitaine de Milan, de la province de Monza et Brianza et de quelques communes voisines. Le prix dépend du nombre de zones (Mi1…Mi9) entre le départ et l'arrivée, pas du véhicule."
        m["How much your pass costs"] = "Combien coûte votre abonnement"
        m["My Conductor"] = "Mon contrôleur"
        m["Follow your train: alerts before, during and after the trip"] = "Suivez votre train : alertes avant, pendant et après le trajet"
        m["Tell me your train: I'll alert you about platform, delays and arrival. All trains, no sign-up."] = "Dites-moi votre train : je vous alerte pour la voie, les retards et l'arrivée. Tous les trains, sans inscription."
        m["Trenord from A to B: weekly, monthly, yearly, Trenocittà, tickets"] = "Trenord de A à B : hebdomadaire, mensuel, annuel, Trenocittà, billets"
        m["Trenord regional fare (Lombardy) by distance band, valid from"] = "Tarif régional Trenord (Lombardie) par tranche de distance, valable à partir du"
        m["Cannot work out the distance between these stations. Check your connection or choose stations in Lombardy."] = "Impossible de calculer la distance entre ces gares. Vérifiez votre connexion ou choisissez des gares en Lombardie."
        m["Journey within the STIBM area"] = "Trajet dans la zone STIBM"
        m["Between these stations the integrated STIBM ticket applies (also valid on metro, trams and buses):"] = "Entre ces gares, le billet intégré STIBM s'applique (valable aussi dans le métro, les trams et les bus) :"
        m["Tap for prices and rules."] = "Touchez pour les prix et les règles."
        m["distance band"] = "tranche de distance"
        m["Passes"] = "Abonnements"
        m["Weekly"] = "Hebdomadaire"
        m["Trenocittà monthly"] = "Trenocittà mensuel"
        m["Trenocittà: train plus city transport in the town shown. "] = "Trenocittà : train plus transports urbains dans la ville indiquée. "
        m["Passes on the Io Viaggio card (€10, valid 4 years). Families: 2nd minor child −20%, from the 3rd free (Io Viaggio in Famiglia)."] = "Abonnements sur la carte Io Viaggio (10 €, valable 4 ans). Familles : 2e enfant mineur −20 %, gratuit à partir du 3e (Io Viaggio in Famiglia)."
        m["Adult single"] = "Aller simple adulte"
        m["Children 4–14"] = "Enfants 4–14 ans"
        m["Senior"] = "Senior"
        m["Carnet of 10"] = "Carnet de 10"
        m["Children under 4 free; children 4–14 free with an adult family member holding a ticket."] = "Enfants de moins de 4 ans gratuit ; enfants de 4–14 ans gratuit avec un membre adulte de la famille muni d'un billet."
        m["Io Viaggio Ovunque (all trains and public transport)"] = "Io Viaggio Ovunque (tous les trains et transports publics)"
        m["All of Lombardy"] = "Toute la Lombardie"
        m["Province, monthly"] = "Province, mensuel"
        m["1 day"] = "1 jour"
        m["2 days"] = "2 jours"
        m["7 days"] = "7 jours"
        m["Quarterly"] = "Trimestriel"
        m["1st class supplement:"] = "Supplément 1re classe :"
        m["per trip"] = "par trajet"
        m["per month"] = "par mois"
        m["per year (Io Viaggio Ovunque in Lombardia)"] = "par an (Io Viaggio Ovunque in Lombardia)"
        m["Bikes on lines leaving Lombardy: €3.50."] = "Vélos sur les lignes quittant la Lombardie : 3,50 €."
        m["Official fares"] = "Tarifs officiels"
        m["Trenord passes"] = "Abonnements Trenord"
        m["2nd cl."] = "2e cl."
        m["1st cl."] = "1re cl."
        m["Trains: 2nd class only. First class supplement: €2.80 per trip, €31 per month, €310 per year."] = "Trains : 2e classe uniquement. Supplément 1re classe : 2,80 € par trajet, 31 € par mois, 310 € par an."
        m["Malpensa Express · fares"] = "Malpensa Express · tarifs"
        m["Prices from every station, lines, classes and restrictions"] = "Prix depuis chaque gare, lignes, classes et restrictions"
        m["The two lines"] = "Les deux lignes"
        m["Prices from every station"] = "Prix depuis chaque gare"
        m["Single adult / child"] = "Aller simple adulte / enfant"
        m["Same-day return"] = "Aller-retour le même jour"
        m["Weekly pass"] = "Abonnement hebdomadaire"
        m["Monthly pass"] = "Abonnement mensuel"
        m["Yearly pass"] = "Abonnement annuel"
        m["Other tickets"] = "Autres billets"
        m["Return within 30 days (online only), adult / child"] = "Retour sous 30 jours (en ligne uniquement), adulte / enfant"
        m["Malpensa Family (2 adults + 2 children 4–17)"] = "Malpensa Family (2 adultes + 2 enfants 4–17 ans)"
        m["Terminal 1 ⇄ Terminal 2 transfer, adult / child"] = "Transfert Terminal 1 ⇄ Terminal 2, adulte / enfant"
        m["Rules and restrictions"] = "Règles et restrictions"
        m["Milan ⇄ Malpensa"] = "Milan ⇄ Malpensa"
        m["To or from Malpensa airport (Terminal 1 and 2) the airport fare applies. Prices valid from"] = "Vers ou depuis l'aéroport de Malpensa (Terminaux 1 et 2), le tarif aéroport s'applique. Prix valables à partir du"
        m["Malpensa airport: Malpensa Express fare"] = "Aéroport de Malpensa : tarif Malpensa Express"
        m["single"] = "aller simple"
        m["monthly 2nd cl."] = "mensuel 2e cl."
        m["monthly 1st cl."] = "mensuel 1re cl."
        m["There is no direct airport fare for this station. Tap for all fares and rules."] = "Il n'existe pas de tarif aéroport direct pour cette gare. Touchez pour tous les tarifs et règles."
        m["The prices below (regional fare) are not valid to or from the airport. Tap for all fares and restrictions."] = "Les prix ci-dessous (tarif régional) ne sont pas valables vers ou depuis l'aéroport. Touchez pour tous les tarifs et restrictions."
        m["2nd class, single ticket, CHF · valid from 14.12.2025 (source: Arcobaleno)"] = "2e classe, billet simple, CHF · valable à partir du 14.12.2025 (source : Arcobaleno)"
        m["Trenord passes and tickets"] = "Abonnements et billets Trenord"
        m["Add to calendar"] = "Ajouter au calendrier"
        m["Some features may have bugs or change. Tap here to report a problem."] = "Certaines fonctions peuvent contenir des bugs ou changer. Touchez ici pour signaler un problème."
        m["Alarms and saved timetables"] = "Alarmes et horaires enregistrés"
        m["More options (voice, vibration for deaf people) in Settings → Accessibility."] = "Plus d'options (voix, vibration pour les personnes sourdes) dans Paramètres → Accessibilité."
        m["Also just for your route and your times"] = "Aussi uniquement pour votre trajet et vos horaires"
        m["Cancelled."] = "Supprimé."
        m["Travel assistance for disabled passengers"] = "Assistance au voyage pour les passagers handicapés"
        m["Remind me (scheduled notification)"] = "Me rappeler (notification programmée)"
        m["Trenord notices"] = "Avis Trenord"
        m["Biasca – Bellinzona – Lugano – Chiasso – Como"] = "Biasca – Bellinzone – Lugano – Chiasso – Côme"
        m["Biasca – Bellinzona – Lugano – Varese – Malpensa"] = "Biasca – Bellinzone – Lugano – Varese – Malpensa"
        m["Tickets and prices"] = "Billets et prix"
        m["Cadenazzo – Luino – Gallarate"] = "Cadenazzo – Luino – Gallarate"
        m["Arcobaleno fare calculator"] = "Calculateur de tarifs Arcobaleno"
        m["Dogs, cats and pet carriers: rules and prices by operator"] = "Chiens, chats et paniers de transport : règles et prix par opérateur"
        m["Castione-Arbedo – Bellinzona – Locarno"] = "Castione-Arbedo – Bellinzone – Locarno"
        m["Find an Italo train by number"] = "Trouver un train Italo par numéro"
        m["Who to call and how to book: Sale Blu 800 90 60 60, Trenord, Italo, SBB"] = "Qui appeler et comment réserver : Sale Blu 800 90 60 60, Trenord, Italo, CFF"
        m["Colour-blind colours. Do you want to turn this on? Tap yes red-green, yes blue-yellow, or no."] = "Couleurs pour daltoniens. Voulez-vous l'activer ? Touchez oui rouge-vert, oui bleu-jaune, ou non."
        m["What's your name? Tell me your first and last name."] = "Comment vous appelez-vous ? Dites-moi votre prénom et votre nom."
        m["Como – Mendrisio – Varese"] = "Côme – Mendrisio – Varese"
        m["Conditions of carriage, delays, compensation"] = "Conditions de transport, retards, indemnisation"
        m["Contacts and support"] = "Contacts et assistance"
        m["Validate before departure and at every change of vehicle (between two trains the first validation is enough)."] = "Validez avant le départ et à chaque changement de véhicule (entre deux trains, la première validation suffit)."
        m["Single ticket valid 4 hours for the whole journey (in Italy from validation). Monthly cross-border passes: in Italy from the 1st of the month, only on an Io Viaggio card; in Ticino 30 days from purchase."] = "Billet simple valable 4 heures pour tout le trajet (en Italie à partir de la validation). Abonnements mensuels transfrontaliers : en Italie à partir du 1er du mois, uniquement sur une carte Io Viaggio ; au Tessin 30 jours à compter de l'achat."
        m["What to do and who to contact: Trenord, Trenitalia, Italo, SBB"] = "Que faire et qui contacter : Trenord, Trenitalia, Italo, CFF"
        m["From A to B: passes and tickets, also to Switzerland"] = "De A à B : abonnements et billets, aussi vers la Suisse"
        m["From: "] = "De : "
        m["Describe the problem."] = "Décrivez le problème."
        m["Describe the problem: what you were doing and what happened."] = "Décrivez le problème : ce que vous faisiez et ce qui s'est passé."
        m["Dictate the message"] = "Dicter le message"
        m["Shall I send, correct or cancel? Say send, correct or cancel."] = "J'envoie, je corrige ou j'annule ? Dites envoyer, corriger ou annuler."
        m["Tell me your suggestion."] = "Dites-moi votre suggestion."
        m["Rights and refunds"] = "Droits et remboursements"
        m["Where am I"] = "Où suis-je"
        m["Where I am, platforms, lifts, stairs, nearby services; guidance to a place"] = "Où je suis, voies, ascenseurs, escaliers, services à proximité ; guidage vers un lieu"
        m["Where I am, platforms, lifts, services; guidance to a place"] = "Où je suis, voies, ascenseurs, services ; guidage vers un lieu"
        m["Duration"] = "Durée"
        m["Sold out"] = "Complet"
        m["Explore by voice"] = "Explorer à la voix"
        m["Voice feedback"] = "Avis vocal"
        m["Voice feedback. After the tone, tell me: is it a suggestion or do you want to report a problem? You can say cancel at any time."] = "Avis vocal. Après le bip, dites-moi : s'agit-il d'une suggestion ou voulez-vous signaler un problème ? Vous pouvez dire annuler à tout moment."
        m["Feedback and reports. Tap the \"Voice feedback\" button at the top to dictate your message."] = "Avis et signalements. Touchez le bouton \"Avis vocal\" en haut pour dicter votre message."
        m["Intermediate stops only at stations in the STIBM area; outside the area only to change vehicle (e.g. Saronno, Busto Arsizio, Treviglio)."] = "Arrêts intermédiaires uniquement dans les gares de la zone STIBM ; en dehors de la zone, seulement pour changer de véhicule (par ex. Saronno, Busto Arsizio, Treviglio)."
        m["Giubiasco – Lugano – Mendrisio"] = "Giubiasco – Lugano – Mendrisio"
        m["Got it"] = "Compris"
        m["Tickets cannot be transferred after validation. Passes on an Io Viaggio or ATM card."] = "Les billets ne sont pas cessibles après validation. Abonnements sur une carte Io Viaggio ou ATM."
        m["Your trains during the strike"] = "Vos trains pendant la grève"
        m["The standard ticket is valid 75 minutes for 2 zones, +15 minutes per zone up to 4 zones, +30 minutes per zone from 5 zones up; in Milan (Mi1–Mi3) it is valid 90 minutes. Unlimited journeys within the validity time."] = "Le billet standard est valable 75 minutes pour 2 zones, +15 minutes par zone jusqu'à 4 zones, +30 minutes par zone à partir de 5 zones ; à Milan (Mi1–Mi3), il est valable 90 minutes. Trajets illimités pendant la durée de validité."
        m["The message is too short."] = "Le message est trop court."
        m["Speech recognition is not available on this phone."] = "La reconnaissance vocale n'est pas disponible sur ce téléphone."
        m["At the station and tools"] = "En gare et outils"
        m["Travel updates, guaranteed trains, tickets"] = "Informations de voyage, trains garantis, billets"
        m["About the app"] = "À propos de l'appli"
        m["Full fare"] = "Plein tarif"
        m["Italy and Switzerland: websites, tickets, data"] = "Italie et Suisse : sites, billets, données"
        m["The Lombardy regional fare is not valid across the border. The price adds the Lombardy section (Trenord distance bands) and the Ticino section (Arcobaleno zones): Trenord sells it in euros, Arcobaleno in francs."] = "Le tarif régional de Lombardie n'est pas valable de l'autre côté de la frontière. Le prix additionne le tronçon lombard (tranches de distance Trenord) et le tronçon tessinois (zones Arcobaleno) : Trenord le vend en euros, Arcobaleno en francs."
        m["Trenord and FerrovieNord lines"] = "Lignes Trenord et FerrovieNord"
        m["FerrovieNord network lines"] = "Lignes du réseau FerrovieNord"
        m["Lines, Malpensa Express, STIBM area, notices"] = "Lignes, Malpensa Express, zone STIBM, avis"
        m["Locarno – Lugano – Chiasso – Milan"] = "Locarno – Lugano – Chiasso – Milan"
        m["Malpensa Express: valid only within the city of Milan (not in the 21 towns of zone Mi3) and between Milan and Rescaldina (Mi1–Mi7), only on trains to/from Milano Centrale."] = "Malpensa Express : valable uniquement dans la ville de Milan (pas dans les 21 communes de la zone Mi3) et entre Milan et Rescaldina (Mi1–Mi7), uniquement sur les trains depuis/vers Milano Centrale."
        m["The name is missing."] = "Le nom est manquant."
        m["A valid email is missing."] = "Un e-mail valide est manquant."
        m["Half fare"] = "Demi-tarif"
        m["Also show these options on the Home screen"] = "Afficher aussi ces options sur l'écran d'accueil"
        m["Hide"] = "Masquer"
        m["Hide fares"] = "Masquer les tarifs"
        m["During guaranteed hours (weekdays 6–9 and 18–21) regional trains run. Outside those hours check your operator's list of guaranteed trains."] = "Pendant les plages garanties (en semaine 6–9 et 18–21 h), les trains régionaux circulent. En dehors de ces horaires, consultez la liste des trains garantis de votre opérateur."
        m["No strike announced in your region"] = "Aucune grève annoncée dans votre région"
        m["No announced strike affects your route at your times"] = "Aucune grève annoncée n'affecte votre trajet à vos horaires"
        m["No"] = "Non"
        m["I didn't understand the email. Say it again slowly, saying at and dot."] = "Je n'ai pas compris l'e-mail. Répétez lentement, en disant arobase et point."
        m["I didn't hear you. Tap \"Voice feedback\" again to try again."] = "Je ne vous ai pas entendu. Touchez à nouveau \"Avis vocal\" pour réessayer."
        m["Note: the malpensaexpress.it passes page shows lower \"from\" prices (€25 weekly, €87 monthly, €840 yearly): here are the prices from the current Trenord fare table."] = "Remarque : la page des abonnements de malpensaexpress.it affiche des prix « à partir de » plus bas (25 € hebdomadaire, 87 € mensuel, 840 € annuel) : voici les prix du barème Trenord actuel."
        m["Scheduled notifications, alarms, offline timetables"] = "Notifications programmées, alarmes, horaires hors ligne"
        m["Travel update news"] = "Actualités sur les informations de voyage"
        m["What's new, fixes, service status, privacy"] = "Nouveautés, corrections, état du service, confidentialité"
        m["Lost property"] = "Objets trouvés"
        m["Spoken mode"] = "Mode vocal"
        m["Spoken mode (blind users)"] = "Mode vocal (utilisateurs aveugles)"
        m["Spoken mode on."] = "Mode vocal activé."
        m["Time"] = "Heure"
        m["Sort:"] = "Trier :"
        m["By operator"] = "Par opérateur"
        m["For people who are blind or prefer to talk: the app asks the questions aloud and you answer by voice."] = "Pour les personnes aveugles ou qui préfèrent parler : l'appli pose les questions à voix haute et vous répondez à la voix."
        m["Trenord doesn't publish a price table for this route: the exact price in euros is in the Trenord online shop."] = "Trenord ne publie pas de barème pour ce trajet : le prix exact en euros se trouve dans la boutique en ligne Trenord."
        m["Ranks outside the station, radio taxis to call, apps"] = "Stations hors de la gare, radio-taxis à appeler, applis"
        m["Taxi ranks, radio taxis to call, apps"] = "Stations de taxi, radio-taxis à appeler, applis"
        m["Best prices by day and time of day"] = "Meilleurs prix par jour et moment de la journée"
        m["Prices for 1 adult from LeFrecce (Trenitalia); they may change until purchase."] = "Prix pour 1 adulte de LeFrecce (Trenitalia) ; ils peuvent changer jusqu'à l'achat."
        m["Price"] = "Prix"
        m["Arcobaleno price (2nd class, single ticket):"] = "Prix Arcobaleno (2e classe, billet simple) :"
        m["Trenord price (adult single ticket)"] = "Prix Trenord (billet simple adulte)"
        m["Price and booking on italotreno.com"] = "Prix et réservation sur italotreno.com"
        m["Price on the Trenord website"] = "Prix sur le site de Trenord"
        m["Sales points"] = "Points de vente"
        m["FerrovieNord punctuality"] = "Ponctualité FerrovieNord"
        m["What's your email? For example: mario dot rossi at gmail dot com."] = "Quelle est votre adresse e-mail ? Par exemple : mario point rossi arobase gmail point com."
        m["RFI Sala Blu · 800 90 60 60"] = "RFI Sala Blu · 800 90 60 60"
        m["Children under 14 travel free with a paying adult; on their own they need the Under 14 card."] = "Les enfants de moins de 14 ans voyagent gratuitement avec un adulte payant ; seuls, ils ont besoin de la carte Under 14."
        m["EU Regulation 2021/782"] = "Règlement UE 2021/782"
        m["Delays, cancellations, platforms, crowding and punctuality use distinguishable colours (orange and blue instead of red and green) and extra symbols. You can change it at any time from Home or Settings → Accessibility."] = "Retards, suppressions, voies, affluence et ponctualité utilisent des couleurs distinguables (orange et bleu au lieu de rouge et vert) et des symboles supplémentaires. Vous pouvez le modifier à tout moment depuis l'accueil ou dans Paramètres → Accessibilité."
        m["Problem report."] = "Signalement de problème."
        m["You are here"] = "Vous êtes ici"
        m["FerrovieNord website"] = "Site de FerrovieNord"
        m["Suggestion."] = "Suggestion."
        m["Yes, blue-yellow"] = "Oui, bleu-jaune"
        m["Yes, turn off"] = "Oui, désactiver"
        m["Yes, red-green (the most common)"] = "Oui, rouge-vert (le plus courant)"
        m["TILO (Ticino–Lombardy)"] = "TILO (Tessin–Lombardie)"
    }

    private fun p3(m: HashMap<String, String>) {
        m["TILO and Switzerland"] = "TILO et Suisse"
        m["TILO · Services"] = "TILO · Services"
        m["Departures and arrivals board"] = "Tableau des départs et arrivées"
        m["Nearby taxis"] = "Taxis à proximité"
        m["Ticino–Lombardy, cross-border fares"] = "Tessin–Lombardie, tarifs transfrontaliers"
        m["Between two Swiss stations Arcobaleno (Ticino) or SBB fares apply: Trenord's distance bands don't apply."] = "Entre deux gares suisses, les tarifs Arcobaleno (Tessin) ou CFF s'appliquent : les tranches de distance de Trenord ne s'appliquent pas."
        m["Between places outside Milan: the zones between them; if you cross Milan you always also need Mi1. Minimum 2 zones."] = "Entre des lieux hors de Milan : les zones entre eux ; si vous traversez Milan, il faut toujours aussi Mi1. Minimum 2 zones."
        m["Real-time trains, contacts"] = "Trains en temps réel, contacts"
        m["Trenord · 800 210 955"] = "Trenord · 800 210 955"
        m["All railway operators"] = "Tous les opérateurs ferroviaires"
        m["All accessibility options"] = "Toutes les options d'accessibilité"
        m["All fares and classes"] = "Tous les tarifs et classes"
        m["Checked on the Trenord website on"] = "Vérifié sur le site de Trenord le"
        m["Travelling with pets"] = "Voyager avec des animaux"
        m["Italy ⇄ Switzerland trip: cross-border ticket"] = "Trajet Italie ⇄ Suisse : billet transfrontalier"
        m["Trip within Switzerland"] = "Trajet en Suisse"
        m["Do you want to turn on spoken mode? The phone's voice will tell you the platform, departure, delays and the stop where to get off."] = "Voulez-vous activer le mode vocal ? La voix du téléphone vous indiquera la voie, le départ, les retards et l'arrêt où descendre."
        m["Do you want to turn off spoken mode?"] = "Voulez-vous désactiver le mode vocal ?"
        m["application/json"] = "application/json"
        m["contactless"] = "sans contact"
        m["from"] = "à partir de"
        m["data saved on the phone"] = "données enregistrées sur le téléphone"
        m["sold out"] = "complet"
        m["in testing"] = "en test"
        m["half price"] = "demi-tarif"
        m["last"] = "dernier"
        m["Departures from Cadorna at minutes 27 and 57 (from 4.27 to 00.20), 37 minutes. Stops at Milano Bovisa, Saronno, Busto Arsizio Nord. FIRST class only."] = "Départs de Cadorna aux minutes 27 et 57 (de 4h27 à 00h20), 37 minutes. Arrêts à Milano Bovisa, Saronno, Busto Arsizio Nord. 1re classe uniquement."
        m["Departures from Centrale at minutes 25 and 55 (from 5.25 to 23.25), 51 minutes. Stops at Porta Garibaldi, Bovisa, Saronno, Busto Arsizio; the :25 trains also at Rescaldina, Castellanza and Ferno-Lonate Pozzolo. First and second class, but second class is only for trips that do NOT start or end at the airport."] = "Départs de Centrale aux minutes 25 et 55 (de 5h25 à 23h25), 51 minutes. Arrêts à Porta Garibaldi, Bovisa, Saronno, Busto Arsizio ; les trains de :25 s'arrêtent aussi à Rescaldina, Castellanza et Ferno-Lonate Pozzolo. 1re et 2e classe, mais la 2e classe uniquement pour les trajets qui ne commencent ni ne finissent à l'aéroport."
        m["To or from Malpensa Terminal 1 and 2 you always need an airport-fare ticket: regional passes, Io Viaggio Ovunque (Lombardy or Varese province) and STIBM are valid on Malpensa Express trains only between the other stations."] = "Vers ou depuis les Terminaux 1 et 2 de Malpensa, il faut toujours un billet au tarif aéroport : les abonnements régionaux, Io Viaggio Ovunque (Lombardie ou province de Varese) et STIBM ne sont valables sur les trains Malpensa Express qu'entre les autres gares."
        m["The Malpensa ticket is valid for both terminals."] = "Le billet Malpensa est valable pour les deux terminaux."
        m["Single ticket: valid on the chosen day until the end of service, no validation needed; the date can be changed up to 3 times until the day before."] = "Billet simple : valable le jour choisi jusqu'à la fin du service, sans validation ; la date peut être modifiée jusqu'à 3 fois jusqu'à la veille."
        m["Return ticket: same-day at ticket offices and machines; within 30 days only online and in the app (Milan ⇄ Malpensa, €25 instead of €30), only the return date can be changed."] = "Billet aller-retour : le jour même aux guichets et distributeurs ; sous 30 jours uniquement en ligne et dans l'appli (Milan ⇄ Malpensa, 25 € au lieu de 30 €), seule la date de retour peut être modifiée."
        m["Malpensa Family €36: 2 adults and 2 young people aged 4 to 17, between a Milan station and the airport. Children under 4 travel free."] = "Malpensa Family 36 € : 2 adultes et 2 jeunes de 4 à 17 ans, entre une gare de Milan et l'aéroport. Gratuit pour les enfants de moins de 4 ans."
        m["Young people: reduced fare from 4 to 13 years."] = "Jeunes : tarif réduit de 4 à 13 ans."
        m["The Malpensa Express ticket to/from Milan is also valid on all trains between stations in the Milan area."] = "Le billet Malpensa Express depuis/vers Milan est aussi valable sur tous les trains entre les gares de la zone de Milan."
        m["On urban sections (Cadorna–Domodossola–Bovisa and Centrale–Porta Garibaldi–Bovisa) urban Trenord and STIBM tickets are also valid. STIBM is valid only in 2nd class, and on trains to/from Milano Centrale also as far as Rescaldina (Mi1–Mi7)."] = "Sur les tronçons urbains (Cadorna–Domodossola–Bovisa et Centrale–Porta Garibaldi–Bovisa), les billets urbains Trenord et STIBM sont aussi valables. STIBM n'est valable qu'en 2e classe, et sur les trains depuis/vers Milano Centrale aussi jusqu'à Rescaldina (Mi1–Mi7)."
        m["Malpensa Express passes: weekly (on sale from the Thursday before, activate within 5 days), monthly (from the 22nd of the previous month, within 15 days), yearly (within 30 days); on an Io Viaggio card or Phone Pass."] = "Abonnements Malpensa Express : hebdomadaire (en vente à partir du jeudi précédent, à activer sous 5 jours), mensuel (à partir du 22 du mois précédent, sous 15 jours), annuel (sous 30 jours) ; sur une carte Io Viaggio ou Phone Pass."
        m["Bikes and dogs travel free as luggage with a boarding pass; without a boarding pass dogs pay the pet supplement."] = "Les vélos et les chiens voyagent gratuitement comme bagages avec une carte d'embarquement ; sans carte d'embarquement, les chiens paient le supplément animal."
        m["Transfer between Terminal 1 and Terminal 2: €2 adults, €1 young people."] = "Transfert entre le Terminal 1 et le Terminal 2 : 2 € adultes, 1 € jeunes."
        m["via Terminal 2"] = "via le Terminal 2"
        m["via Busto Arsizio"] = "via Busto Arsizio"
        m["Share Binario: coming soon"] = "Partager Binario : bientôt disponible"
        m["Network, lifts out of service, accessibility, defibrillators"] = "Réseau, ascenseurs hors service, accessibilité, défibrillateurs"
        m["FERROVIENORD network info"] = "Infos réseau FERROVIENORD"
        m["Lifts and escalators out of service, accessibility, assistance, AEDs, documents"] = "Ascenseurs et escaliers mécaniques hors service, accessibilité, assistance, DAE, documents"
        m["Replacement buses"] = "Bus de remplacement"
        m["Stops and times of buses replacing trains · Trenord, Trenitalia, TILO"] = "Arrêts et horaires des bus de remplacement · Trenord, Trenitalia, TILO"
        m["Defibrillators (AED)"] = "Défibrillateurs (DAE)"
        m["Where they are, near you or the station · call 112"] = "Où ils se trouvent, près de vous ou de la gare · appelez le 112"
        m["Share Binario, not available: coming soon"] = "Partager Binario, indisponible : bientôt disponible"
        m["Coming soon"] = "Bientôt disponible"
        m["solutions · saved on "] = "solutions · enregistrées le "
        m["Reminder at "] = "Rappel à "
        m["arrival"] = "arrivée"
        m["departure"] = "départ"
        m["Ticket offices, machines, resellers · nearby or by province"] = "Guichets, distributeurs, revendeurs · à proximité ou par province"
        m["Location not available: turn on GPS."] = "Position indisponible : activez le GPS."
        m["Looking for taxi ranks…"] = "Recherche de stations de taxi…"
        m["OpenStreetMap servers are not responding. Use the numbers below or Google Maps."] = "Les serveurs OpenStreetMap ne répondent pas. Utilisez les numéros ci-dessous ou Google Maps."
        m["Call a taxi"] = "Appeler un taxi"
        m["I don't have a verified radio taxi number for this city: use an app or search for the number."] = "Je n'ai pas de numéro de radio-taxi vérifié pour cette ville : utilisez une appli ou cherchez le numéro."
        m["Search for the taxi number"] = "Rechercher le numéro de taxi"
        m["Italian radio taxi app: book and pay in the app"] = "Appli italienne de radio-taxi : réserver et payer dans l'appli"
        m["Taxis in many Italian cities"] = "Taxis dans de nombreuses villes italiennes"
        m["Uber Taxi in cities where available"] = "Uber Taxi dans les villes où il est disponible"
        m["Where to get a taxi"] = "Où trouver un taxi"
        m["No taxi rank mapped within 1.5 km. The rank is usually in front of the station's main exit."] = "Aucune station de taxi référencée dans un rayon de 1,5 km. La station se trouve généralement devant la sortie principale de la gare."
        m["Local taxi companies"] = "Compagnies de taxi locales"
        m["Taxi ranks"] = "Stations de taxi"
        m["Ranks and phones from OpenStreetMap (volunteers), radio taxis from city services: check on site. 112 is for emergencies only."] = "Stations et téléphones issus d'OpenStreetMap (bénévoles), radio-taxis issus des services municipaux : vérifiez sur place. Le 112 est réservé aux urgences."
        m["Tap to open the location"] = "Touchez pour ouvrir l'emplacement"
        m["Tap to call"] = "Touchez pour appeler"
        m["Best prices"] = "Meilleurs prix"
        m["Choose origin and destination first."] = "Choisissez d'abord l'origine et la destination."
        m["All trains"] = "Tous les trains"
        m["Lowest price for 1 adult among trains in that time band (LeFrecce · Trenitalia). Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "Prix le plus bas pour 1 adulte parmi les trains de cette tranche horaire (LeFrecce · Trenitalia). Touchez une case pour voir les solutions. Les tarifs économiques varient selon la disponibilité : le prix final est celui affiché au paiement."
        m["In short"] = "En bref"
        m["Small animals (cats, small dogs, rabbits, birds) in a carrier: almost always free."] = "Petits animaux (chats, petits chiens, lapins, oiseaux) en panier de transport : presque toujours gratuit."
        m["Larger dogs: leash and muzzle; a dog ticket is often needed."] = "Chiens plus grands : laisse et muselière ; un billet pour chien est souvent nécessaire."
        m["Guide and assistance dogs: always free, on all trains and classes, with no time limits."] = "Chiens guides et d'assistance : toujours gratuit, dans tous les trains et classes, sans limite de durée."
        m["Always carry the dog-registry certificate and health booklet (from abroad: EU pet passport)."] = "Ayez toujours le certificat d'inscription du chien et le carnet de santé (de l'étranger : passeport européen pour animaux de compagnie)."
        m["The animal must not take up seats or disturb others: staff may ask you to leave if it causes danger or disturbance."] = "L'animal ne doit pas occuper de sièges ni gêner les autres : le personnel peut vous demander de descendre s'il cause un danger ou une gêne."
        m["Small animals in a carrier (max 70×30×50 cm): free within Lombardy."] = "Petits animaux en panier de transport (max. 70×30×50 cm) : gratuit en Lombardie."
        m["Dogs of any size: muzzle, leash and dog-registry certificate; free within Lombardy."] = "Chiens de toute taille : muselière, laisse et certificat d'inscription ; gratuit en Lombardie."
        m["Not allowed on weekdays (Monday–Friday) 7:00–9:30 and 17:30–19:30, small animals included. Guide dogs can always travel."] = "Interdit en semaine (lundi–vendredi) 7h00–9h30 et 17h30–19h30, petits animaux compris. Les chiens guides peuvent toujours voyager."
        m["Beyond Lombardy and to Switzerland an animal supplement is needed, under the rules of the operating company."] = "Au-delà de la Lombardie et vers la Suisse, un supplément animal est nécessaire, selon les règles de l'entreprise exploitante."
        m["Malpensa Express: dogs travel free as luggage with a boarding pass; without one they pay the animal supplement."] = "Malpensa Express : les chiens voyagent gratuitement comme bagages avec une carte d'embarquement ; sans elle, ils paient le supplément animal."
        m["Small animals in a carrier (max 70×30×50 cm): always free, on all trains."] = "Petits animaux en panier de transport (max. 70×30×50 cm) : toujours gratuit, dans tous les trains."
        m["Regional trains: larger dogs travel with a 2nd-class ticket at 50% off, with leash and muzzle."] = "Trains régionaux : les chiens plus grands voyagent avec un billet de 2e classe à moitié prix, avec laisse et muselière."
        m["Frecce and Intercity: a dog outside the carrier must be added when buying (\"Travel with your dog\"); the price is the one shown at checkout, with promotions in some periods (e.g. dogs free in summer)."] = "Frecce et Intercity : un chien hors du panier doit être ajouté à l'achat (\"Voyagez avec votre chien\") ; le prix est celui affiché au paiement, avec des promotions à certaines périodes (par ex. chiens gratuits en été)."
        m["Documents: dog-registry certificate and health booklet; staff may ask for them. Assistance dogs are also allowed in bar/restaurant cars and replacement buses."] = "Documents : certificat d'inscription du chien et carnet de santé ; le personnel peut les demander. Les chiens d'assistance sont aussi admis dans les voitures bar/restaurant et les bus de remplacement."
        m["Small animals (up to about 5 kg) in a carrier: free."] = "Petits animaux (jusqu'à environ 5 kg) en panier de transport : gratuit."
        m["Larger dogs: allowed in Smart and Prima by booking the \"Dog\" service (online or Pronto Italo 06 07 08, up to 2 hours before); always on a leash, muzzle when boarding/leaving or on request. Price shown at checkout."] = "Chiens plus grands : admis en Smart et Prima en réservant le service « Chien » (en ligne ou Pronto Italo 06 07 08, jusqu'à 2 heures avant) ; toujours en laisse, muselière à la montée/descente ou sur demande. Prix affiché au paiement."
        m["Guide dogs: free, any size."] = "Chiens guides : gratuit, toute taille."
        m["Switzerland · SBB and TILO"] = "Suisse · CFF et TILO"
        m["Dogs up to 30 cm at the withers and other small animals in a bag or carrier: free, as hand luggage."] = "Chiens jusqu'à 30 cm au garrot et autres petits animaux dans un sac ou un panier de transport : gratuit, comme bagage à main."
        m["Larger dogs (or outside a carrier): half the 2nd-class fare, or the dog day pass CHF 25 (also valid on buses, trams and boats); dog pass CHF 60 a month or CHF 350 a year."] = "Chiens plus grands (ou hors panier) : moitié du tarif de 2e classe, ou la carte journalière pour chien CHF 25 (valable aussi dans les bus, trams et bateaux) ; abonnement chien CHF 60 par mois ou CHF 350 par an."
        m["The dog stays under your seat without blocking the aisle. Not allowed in restaurant cars (except guide and assistance dogs)."] = "Le chien reste sous votre siège sans bloquer l'allée. Interdit dans les voitures-restaurants (sauf chiens guides et d'assistance)."
        m["Rules from the operators' official pages (October 2026). Prices and promotions change: before travelling check the operator's page with the button above."] = "Règles issues des pages officielles des opérateurs (octobre 2026). Les prix et promotions changent : avant de voyager, consultez la page de l'opérateur avec le bouton ci-dessus."
        m["Official page "] = "Page officielle "
        m["Enter town or station"] = "Saisissez une ville ou une gare"
        m["Clear"] = "Effacer"
        m["Near me"] = "Près de moi"
        m["Show map"] = "Afficher la carte"
        m["Show list"] = "Afficher la liste"
        m["towards "] = "vers "
        m["straight ahead"] = "tout droit"
        m["to your right"] = "à votre droite"
        m["behind you"] = "derrière vous"
        m["to your left"] = "à votre gauche"
        m["ahead on the right"] = "devant à droite"
        m["ahead on the left"] = "devant à gauche"
        m["behind on the right"] = "derrière à droite"
        m["behind on the left"] = "derrière à gauche"
        m["metres"] = "mètres"
        m["Travelling, near the station of "] = "En déplacement, près de la gare de "
        m["You are at "] = "Vous êtes à "
        m["Warning, out of service: "] = "Attention, hors service : "
        m["You have arrived: "] = "Vous êtes arrivé : "
        m["Explore"] = "Explorer"
        m["Categories"] = "Catégories"
        m["Guiding you to: "] = "Je vous guide vers : "
        m["Walking navigation"] = "Navigation à pied"
        m["Stop guiding"] = "Arrêter le guidage"
        m["Location permission is needed to explore."] = "L'autorisation de localisation est nécessaire pour explorer."
        m["Finding your position… Turn on GPS."] = "Recherche de votre position… Activez le GPS."
        m["Guiding you to "] = "Je vous guide vers "
        m["Exploring. I'll tell you about nearby stations, platforms, lifts, stairs and services."] = "Exploration. Je vous indiquerai les gares, voies, ascenseurs, escaliers et services à proximité."
        m["Exploring stopped."] = "Exploration arrêtée."
        m["Stop exploring"] = "Arrêter l'exploration"
        m["Start spoken exploration"] = "Démarrer l'exploration vocale"
        m["Nearest station: "] = "Gare la plus proche : "
        m["You are moving at "] = "Vous vous déplacez à "
        m["No useful places found nearby."] = "Aucun lieu utile trouvé à proximité."
        m["Where am I? Tell me"] = "Où suis-je ? Dites-le-moi"
        m["Last announcement"] = "Dernière annonce"
        m["GPS accuracy: "] = "Précision du GPS : "
        m[" · no compass: directions by compass points"] = " · pas de boussole : directions selon les points cardinaux"
        m["Hold the phone in front of you: \"12 o'clock\" is ahead, \"3\" right, \"9\" left. In stations GPS can be off by a few metres: ask staff or the Sale Blu for help (More → Disability assistance)."] = "Tenez le téléphone devant vous : « 12 heures » est devant, « 3 » à droite, « 9 » à gauche. En gare, le GPS peut être décalé de quelques mètres : demandez de l'aide au personnel ou à la Sale Blu (Plus → Assistance aux personnes handicapées)."
        m["None of these mapped nearby (300 m)."] = "Aucun de ces lieux référencé à proximité (300 m)."
        m["Guide me"] = "Guidez-moi"
        m["Board"] = "Embarquer"
        m["No results for "] = "Aucun résultat pour "
        m["Found "] = "Trouvé : "
        m[" results. First: "] = " résultats. Premier : "
        m["Place, address, station…"] = "Lieu, adresse, gare…"
        m["Voice search"] = "Recherche vocale"
        m["Save this spot"] = "Enregistrer cet endroit"
        m["E.g. \"Platform 3, front of the train\", \"Lift by the café\", \"Taxi exit\": then \"Guide me\" brings you back. Favourite stations and trains are in the Stations and Trains tabs."] = "Par ex. « Voie 3, tête du train », « Ascenseur près du café », « Sortie taxis » : « Guidez-moi » vous y ramènera. Les gares et trains favoris sont dans les onglets Gares et Trains."
        m["No saved places."] = "Aucun lieu enregistré."
        m["Name"] = "Nom"
        m["Current position, accuracy ±"] = "Position actuelle, précision ±"
        m["Saved spot"] = "Endroit enregistré"
        m["Saved: "] = "Enregistré : "
        m["No solutions found for the chosen time."] = "Aucune solution trouvée pour l'heure choisie."
        m["Cannot reach the server. Check your connection."] = "Impossible de joindre le serveur. Vérifiez votre connexion."
        m["Departing from "] = "Départ de "
        m["FASTEST"] = "LE PLUS RAPIDE"
        m[" · first train +"] = " · premier train +"
        m["Not reachable now: "] = "Injoignable pour le moment : "
        m["Train "] = "Train "
        m["I'll remind you at "] = "Je vous le rappellerai à "
        m["Where to catch the bus when trains don't run · Trenord, Trenitalia, TILO"] = "Où prendre le bus quand les trains ne circulent pas · Trenord, Trenitalia, TILO"
        m["The nearest to you · call 112"] = "Le plus proche de vous · appelez le 112"
        m["FERROVIENORD · source: ferrovienord.it (station accessibility notices). Assistance: 800 210 955"] = "FERROVIENORD · source : ferrovienord.it (avis d'accessibilité des gares). Assistance : 800 210 955"
        m["Show later trains (+6 hours)"] = "Afficher les trains suivants (+6 heures)"
        m["Platform "] = "Voie "
        m["What to do right away"] = "Que faire tout de suite"
        m["If you are still on the train or in the station, tell the conductor or staff straight away: it's the fastest way to find it."] = "Si vous êtes encore dans le train ou en gare, prévenez immédiatement le chef de train ou le personnel : c'est le moyen le plus rapide de le retrouver."
        m["Note the train number, day, time, coach and seat, and describe the item well (brand, colour, contents)."] = "Notez le numéro du train, le jour, l'heure, la voiture et la place, et décrivez bien l'objet (marque, couleur, contenu)."
        m["Contact the train's operator (below): each has its own lost property service."] = "Contactez l'opérateur du train (ci-dessous) : chacun a son propre service des objets trouvés."
        m["Documents, cards or phone: block your cards and, for theft or documents, report it to the Railway Police (Polfer) or Carabinieri."] = "Documents, cartes ou téléphone : bloquez vos cartes et, en cas de vol ou pour les documents, signalez-le à la police ferroviaire (Polfer) ou aux carabiniers."
        m["After a few days unclaimed items go to the town's lost property office: ask there."] = "Après quelques jours, les objets non réclamés sont remis au bureau des objets trouvés de la ville : renseignez-vous là-bas."
        m["The train you are following: "] = "Le train que vous suivez : "
        m["Trenord, Malpensa Express and FerrovieNord stations"] = "Gares Trenord, Malpensa Express et FerrovieNord"
        m["Trenord Contact Center: items lost on trains or platforms"] = "Centre de contact Trenord : objets perdus dans les trains ou sur les quais"
        m["Found items are kept at the My Link Points in Milano Cadorna and Milano Porta Garibaldi for a few days (up to 6), then go to the City of Milan lost property office."] = "Les objets trouvés sont conservés aux My Link Points de Milano Cadorna et Milano Porta Garibaldi pendant quelques jours (jusqu'à 6), puis remis au bureau des objets trouvés de la Ville de Milan."
        m["City of Milan · Lost property"] = "Ville de Milan · Objets trouvés"
        m["Via Friuli 30, Milan · 02 884 53900"] = "Via Friuli 30, Milan · 02 884 53900"
        m["Trenord lost property page"] = "Page des objets trouvés Trenord"
        m["Frecce: go to the Frecciadesk or customer service in the station as soon as you notice, staff can have your seat checked. Regional and Intercity: found items are usually handed to the lost property office of the town where the train terminates."] = "Frecce : adressez-vous au Frecciadesk ou au service client en gare dès que vous vous en apercevez, le personnel peut faire vérifier votre place. Régional et Intercity : les objets trouvés sont généralement remis au bureau des objets trouvés de la ville où le train termine son parcours."
        m["Lost items search service"] = "Service de recherche d'objets perdus"
        m["Customer service offices"] = "Bureaux du service client"
        m["Pronto Italo, daily 7–23: report the item with train number, coach and seat"] = "Pronto Italo, tous les jours 7h–23h : signalez l'objet avec le numéro du train, la voiture et la place"
        m["Report the loss online"] = "Signaler la perte en ligne"
        m["SBB Contact Center, 24 hours"] = "Centre de contact CFF, 24 heures sur 24"
        m["On collection you pay CHF 20 (CHF 10 with a GA travelcard); electronics and bulky items CHF 25 (CHF 15). On TILO trains between Italy and Switzerland report to both SBB and Trenord."] = "Au retrait, vous payez CHF 20 (CHF 10 avec un abonnement général) ; appareils électroniques et objets volumineux CHF 25 (CHF 15). Sur les trains TILO entre l'Italie et la Suisse, signalez la perte aux CFF et à Trenord."
        m["Information from the official Trenord, Trenitalia and SBB pages (October 2026): times and procedures may change."] = "Informations tirées des pages officielles de Trenord, Trenitalia et CFF (octobre 2026) : les horaires et procédures peuvent changer."
        m["Location not available: search a town or station."] = "Position indisponible : recherchez une ville ou une gare."
        m["Search a town or station above."] = "Recherchez une ville ou une gare ci-dessus."
        m["Looking for defibrillators…"] = "Recherche de défibrillateurs…"
        m["Looking for defibrillators within "] = "Recherche de défibrillateurs dans un rayon de "
        m["Station "] = "Gare "
        m["Station AED: usually on the outside wall, in a marked case"] = "DAE de gare : généralement sur le mur extérieur, dans un boîtier signalé"
        m["ferrovienord.it · AEDs in all FERROVIENORD stations"] = "ferrovienord.it · DAE dans toutes les gares FERROVIENORD"
        m["Defibrillator"] = "Défibrillateur"
        m["Emilia-Romagna regional AED register (open data)"] = "Registre régional des DAE d'Émilie-Romagne (données ouvertes)"
        m["OpenStreetMap (volunteers): check on site"] = "OpenStreetMap (bénévoles) : vérifiez sur place"
        m["OpenStreetMap servers are not responding: use the official map below or retry."] = "Les serveurs OpenStreetMap ne répondent pas : utilisez la carte officielle ci-dessous ou réessayez."
        m["Defibrillators"] = "Défibrillateurs"
        m["Emergency: call "] = "Urgence : appelez le "
        m["The operator guides you through CPR and tells you where the nearest AED is. AEDs can be used on children too and give voice instructions."] = "L'opérateur vous guide pour le massage cardiaque et vous indique où se trouve le DAE le plus proche. Les DAE peuvent aussi être utilisés sur les enfants et donnent des instructions vocales."
        m["Public access"] = "Accès public"
        m["Always available"] = "Toujours disponible"
        m["Outdoors"] = "En extérieur"
        m["Nearby defibrillators"] = "Défibrillateurs à proximité"
        m["No defibrillator in the open lists here. Call 112: the dispatch centre knows all registered AEDs and guides you."] = "Aucun défibrillateur dans les listes ouvertes utilisées ici. Appelez le 112 : la centrale connaît tous les DAE enregistrés et vous guide."
        m["Where to get help nearby"] = "Où trouver de l'aide à proximité"
        m["Emergency departments and pharmacies: many pharmacies have an AED, but it isn't guaranteed."] = "Services d'urgences et pharmacies : de nombreuses pharmacies ont un DAE, mais ce n'est pas garanti."
        m["Official maps and sources"] = "Cartes et sources officielles"
        m["AREU Lombardy · AED map (official)"] = "AREU Lombardie · carte des DAE (officielle)"
        m["Ticino Cuore · AEDs in Ticino"] = "Ticino Cuore · DAE au Tessin"
        m["FERROVIENORD · station AEDs"] = "FERROVIENORD · DAE des gares"
        m["FERROVIENORD: 125 AEDs installed in 2022–2023 in all its stations, where possible on the outside wall so they can be reached at night, in alarmed cases linked to 112/118 dispatch. Other AEDs come from OpenStreetMap (volunteers): check on site. Trenitalia/RFI, Italo and SBB don't publish a list of station AEDs: ask staff or call 112 (144 in Switzerland)."] = "FERROVIENORD : 125 DAE installés en 2022–2023 dans toutes ses gares, si possible sur le mur extérieur pour être accessibles la nuit, dans des boîtiers avec alarme reliés à la centrale 112/118. Les autres DAE proviennent d'OpenStreetMap (bénévoles) : vérifiez sur place. Trenitalia/RFI, Italo et les CFF ne publient pas de liste des DAE en gare : demandez au personnel ou appelez le 112 (144 en Suisse)."
        m["Tap again for directions"] = "Touchez à nouveau pour l'itinéraire"
        m["Searched place"] = "Lieu recherché"
        m["Hospital · ask for help here"] = "Hôpital · demandez de l'aide ici"
        m["Pharmacy · ask if they have an AED"] = "Pharmacie · demandez s'ils ont un DAE"
        m["Operator not stated"] = "Exploitant non indiqué"
        m["Available 24/7"] = "Disponible 24h/24 et 7j/7"
        m["Restricted access"] = "Accès restreint"
        m["At or next to a station"] = "Dans ou à côté d'une gare"
        m["Source: "] = "Source : "
        m["Get directions"] = "Obtenir l'itinéraire"
        m["View on MapComplete"] = "Voir sur MapComplete"
        m["Nearest defibrillator"] = "Défibrillateur le plus proche"
        m["List and map of AEDs · tap to see them"] = "Liste et carte des DAE · touchez pour les voir"
        m["Complete official list"] = "Liste officielle complète"
        m["⏳ Waiting for official AREU data: Binario has asked to use Lombardy's official defibrillator register. Until permission arrives the list below may be incomplete: open the official AREU map to see them all."] = "⏳ En attente des données officielles AREU : Binario a demandé à utiliser le registre officiel des défibrillateurs de Lombardie. Tant que l'autorisation n'est pas arrivée, la liste ci-dessous peut être incomplète : ouvrez la carte officielle AREU pour tous les voir."
        m["Below are the AEDs from open lists (OpenStreetMap, FERROVIENORD, Emilia-Romagna register)."] = "Ci-dessous, les DAE issus de listes ouvertes (OpenStreetMap, FERROVIENORD, registre d'Émilie-Romagne)."
        m["Official AREU map"] = "Carte officielle AREU"
        m["Ticino Cuore map"] = "Carte Ticino Cuore"
        m["Search Google Maps"] = "Rechercher sur Google Maps"
        m["Station coordinates not available: search a town or station."] = "Coordonnées de la gare indisponibles : recherchez une ville ou une gare."
        m["Location not available: turn on GPS or search a town or station."] = "Position indisponible : activez le GPS ou recherchez une ville ou une gare."
        m["Location permission needed, or search a town or station."] = "Autorisation de localisation requise, ou recherchez une ville ou une gare."
        m["Looking for public toilets within"] = "Recherche de toilettes publiques dans un rayon de"
        m["Place not found: try the town or station name."] = "Lieu introuvable : essayez le nom de la ville ou de la gare."
        m["Accessible"] = "Accessibles"
        m["Baby changing"] = "Table à langer"
        m["Open to all"] = "Ouvert à tous"
        m["near"] = "près de"
        m["No public toilets mapped here with these filters."] = "Aucune toilette publique référencée ici avec ces filtres."
        m["Data © OpenStreetMap, the same as the MapComplete \"Public toilets\" map ("] = "Données © OpenStreetMap, les mêmes que la carte MapComplete « Toilettes publiques » ("
        m["Prices, hours and accessibility are entered by volunteers: check on site. If something is wrong you can fix it via \"View on MapComplete\"."] = "Les prix, horaires et l'accessibilité sont saisis par des bénévoles : vérifiez sur place. Si quelque chose est inexact, vous pouvez le corriger via « Voir sur MapComplete »."
        m["Public toilet"] = "Toilettes publiques"
        m["♿ Wheelchair accessible"] = "♿ Accessible en fauteuil roulant"
        m["♿ Partly accessible"] = "♿ Partiellement accessible"
        m["Not wheelchair accessible"] = "Non accessible en fauteuil roulant"
        m["🚼 Baby changing table"] = "🚼 Table à langer"
        m["Unisex"] = "Mixtes"
        m["Men and women"] = "Hommes et femmes"
        m["Men only"] = "Hommes uniquement"
        m["Women only"] = "Femmes uniquement"
        m["Seated and urinals"] = "Cuvettes et urinoirs"
        m["Urinals only"] = "Urinoirs uniquement"
        m["Squat toilet"] = "Toilettes turques"
        m["Seated"] = "Cuvette"
        m["toilet paper"] = "papier toilette"
        m["hand washing"] = "lavage des mains"
        m["With "] = "Avec "
        m["Customers only"] = "Clients uniquement"
        m["Not open to the public"] = "Non ouvert au public"
        m["Level"] = "Niveau"
        m["Operated by"] = "Exploité par"
        m["Calculation failed"] = "Échec du calcul"
        m["Edit"] = "Modifier"
        m["Every day (round trip)"] = "Tous les jours (aller-retour)"
        m["of CO₂ saved"] = "de CO₂ économisé"
        m["saved"] = "économisé"
        m["extra cost"] = "coût supplémentaire"
        m["Travel time (one way)"] = "Durée du trajet (aller simple)"
        m["avg delay"] = "retard moyen"
        m["Car"] = "Voiture"
        m["free flow"] = "circulation fluide"
        m["rush hour"] = "heure de pointe"
        m["Daily breakdown (round trip)"] = "Détail quotidien (aller-retour)"
        m["yours"] = "le vôtre"
        m["Road distance"] = "Distance routière"
        m["of which tolled"] = "dont à péage"
        m["Consumption"] = "Consommation"
        m["Fuel"] = "Carburant"
        m["Motorway tolls"] = "Péages autoroutiers"
        m[" (estimate)"] = " (estimation)"
        m["Parking"] = "Stationnement"
        m["Car total"] = "Total voiture"
        m["Train (daily share of pass)"] = "Train (part quotidienne de l'abonnement)"
        m["Tap an item with ✎ to enter your own value: everything is recalculated at once and saved."] = "Touchez un élément avec ✎ pour saisir votre propre valeur : tout est recalculé aussitôt et enregistré."
        m["Car CO₂"] = "CO₂ voiture"
        m["Train CO₂"] = "CO₂ train"
        m["CO₂ avoided"] = "CO₂ évité"
        m["Road distance (one way)"] = "Distance routière (aller simple)"
        m["Tolls per day (round trip)"] = "Péages par jour (aller-retour)"
        m["Fuel price"] = "Prix du carburant"
        m["Parking per day"] = "Stationnement par jour"
        m["Train pass per month"] = "Abonnement train par mois"
        m["Car consumption"] = "Consommation de la voiture"
        m["Back to the app's estimate"] = "Revenir à l'estimation de l'appli"
        m["Save and recalculate"] = "Enregistrer et recalculer"
        m["Trip and delay log"] = "Journal des trajets et des retards"
    }

    private fun p4(m: HashMap<String, String>) {
        m[" · avg delay "] = " · retard moyen "
        m[" · max "] = " · max. "
        m["Remove today"] = "Retirer aujourd'hui"
        m["out "] = "aller "
        m["  back "] = "  retour "
        m["On travel days after 9 pm the app automatically logs the delays of your usual trains."] = "Les jours de déplacement, après 21 h, l'appli enregistre automatiquement les retards de vos trains habituels."
        m["Your commute"] = "Votre trajet domicile-travail"
        m["choose"] = "choisir"
        m["To: "] = "Vers : "
        m["Outbound train"] = "Train aller"
        m["Return train"] = "Train retour"
        m["Travel days"] = "Jours de déplacement"
        m["M"] = "L"
        m["W"] = "M"
        m["T"] = "M"
        m["F"] = "V"
        m["S"] = "S"
        m["Car fuel"] = "Carburant de la voiture"
        m["Consumption l/100 km"] = "Consommation l/100 km"
        m["Parking € per day"] = "Stationnement € par jour"
        m["Train pass € per month"] = "Abonnement train € par mois"
        m["Calculate"] = "Calculer"
        m["A network error occurred. Please try again."] = "Une erreur réseau s'est produite. Veuillez réessayer."
        m[". You can follow the train with voice alerts."] = ". Vous pouvez suivre le train avec des alertes vocales."
        m["Ask about a train, station or route"] = "Posez une question sur un train, une gare ou un itinéraire"
        m["Speech recognition is not available on this phone. Install or enable the Google app."] = "La reconnaissance vocale n'est pas disponible sur ce téléphone. Installez ou activez l'appli Google."
        m["Read aloud on"] = "Lecture à voix haute activée"
        m["Read aloud off"] = "Lecture à voix haute désactivée"
        m["Open train"] = "Ouvrir le train"
        m["Following the train. I will give you voice alerts."] = "Je suis le train. Je vous donnerai des alertes vocales."
        m["Follow with voice alerts"] = "Suivre avec alertes vocales"
        m["Open station"] = "Ouvrir la gare"
        m["Where is my train?"] = "Où est mon train ?"
        m["Any strikes?"] = "Y a-t-il des grèves ?"
        m["Can I bring my bike?"] = "Puis-je emporter mon vélo ?"
        m["Disability assistance"] = "Assistance aux personnes handicapées"
        m["e.g. delay train 2070"] = "par ex. retard train 2070"
        m["Speak: ask a question"] = "Parler : poser une question"
        m["Finding the station…"] = "Recherche de la gare…"
        m["Search a station or town above."] = "Recherchez une gare ou une ville ci-dessus."
        m["Location not available: search a station."] = "Position indisponible : recherchez une gare."
        m["No station found."] = "Aucune gare trouvée."
        m["Place not found: try the station name."] = "Lieu introuvable : essayez le nom de la gare."
        m["Looking for replacement buses at"] = "Recherche de bus de remplacement à"
        m["Other operators"] = "Autres opérateurs"
        m["Replacement bus stop"] = "Arrêt de bus de remplacement"
        m["Replacement buses in the next 6 hours"] = "Bus de remplacement dans les 6 prochaines heures"
        m["Timetable services are not responding: retry or check the official pages below."] = "Les services d'horaires ne répondent pas : réessayez ou consultez les pages officielles ci-dessous."
        m["No replacement buses scheduled here in the next hours according to official timetables. After sudden disruptions buses may not be in the timetables yet: check the official pages and station announcements."] = "Aucun bus de remplacement prévu ici dans les prochaines heures selon les horaires officiels. Après des perturbations soudaines, les bus peuvent ne pas encore figurer dans les horaires : consultez les pages officielles et les annonces en gare."
        m["Sources: official GTFS timetables of Trenord, Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements."] = "Sources : horaires GTFS officiels de Trenord, Trenitalia et CFF via Transitous (transitous.org) ; bus du tableau de ViaggiaTreno (RFI). Chaque trajet indique sa source. Les horaires sont théoriques : en cas de perturbation, suivez les annonces en gare."
        m["Board at: "] = "Embarquement : "
        m[" from the station"] = " depuis la gare"
        m["Bay / platform: "] = "Quai / emplacement : "
        m["Real time"] = "Temps réel"
        m["Scheduled time"] = "Horaire prévu"
        m["Directions to the stop"] = "Itinéraire vers l'arrêt"
        m["My region"] = "Ma région"
        m["My route and times"] = "Mon trajet et mes horaires"
        m["National strikes and in: "] = "Grèves nationales et en : "
        m["back "] = "retour "
        m["Set your route and the time of your outbound and/or return train"] = "Définissez votre trajet et l'heure de votre train aller et/ou retour"
        m["Mon"] = "Lun"
        m["Tue"] = "Mar"
        m["Wed"] = "Mer"
        m["Thu"] = "Jeu"
        m["Fri"] = "Ven"
        m["Sat"] = "Sam"
        m["Sun"] = "Dim"
        m["Mon–Fri"] = "Lun–Ven"
        m["every day"] = "tous les jours"
        m["My route"] = "Mon trajet"
        m["Out "] = "Aller "
        m["Back "] = "Retour "
        m["No outbound"] = "Pas d'aller"
        m["No return"] = "Pas de retour"
        m["Days"] = "Jours"
        m["Operators you use"] = "Opérateurs que vous utilisez"
        m["Regions (also for the \"My region\" filter)"] = "Régions (aussi pour le filtre « Ma région »)"
        m["A strike shows in \"My route\" if it is national or in one of your regions, involves one of your operators (or all) and its hours cover your outbound or return train on one of your travel days."] = "Une grève apparaît dans « Mon trajet » si elle est nationale ou dans l'une de vos régions, concerne l'un de vos opérateurs (ou tous) et si ses horaires couvrent votre train aller ou retour un de vos jours de déplacement."
        m["arrival at "] = "arrivée à "
        m["Arrival "] = "Arrivée "
        m["Departure "] = "Départ "
        m["On Xiaomi: Settings → Apps → Binario → Battery saver → No restrictions, and also enable \"Autostart\"."] = "Sur Xiaomi : Paramètres → Applis → Binario → Économiseur de batterie → Aucune restriction, et activez aussi « Démarrage automatique »."
        m["On Oppo, Realme and OnePlus: Settings → Apps → Binario → Battery usage → allow background activity and auto launch."] = "Sur Oppo, Realme et OnePlus : Paramètres → Applis → Binario → Utilisation de la batterie → autoriser l'activité en arrière-plan et le lancement automatique."
        m["On Huawei and Honor: Settings → Battery → App launch → Binario → manage manually, with all three options on."] = "Sur Huawei et Honor : Paramètres → Batterie → Lancement des applis → Binario → gérer manuellement, avec les trois options activées."
        m["On Samsung: Settings → Apps → Binario → Battery → Unrestricted, and remove Binario from \"Sleeping apps\"."] = "Sur Samsung : Paramètres → Applis → Binario → Batterie → Sans restriction, et retirez Binario des « Applis en veille »."
        m["On Vivo: Settings → Battery → Background power consumption → allow Binario."] = "Sur Vivo : Paramètres → Batterie → Consommation en arrière-plan → autoriser Binario."
        m["If the followed train stops by itself: Settings → Apps → Binario → Battery → Unrestricted."] = "Si le train suivi s'arrête tout seul : Paramètres → Applis → Binario → Batterie → Sans restriction."
        m["Alerts even with the app closed"] = "Alertes même avec l'appli fermée"
        m["The train is followed even with Binario closed. Some phones, however, stop the alerts after a while to save battery. To avoid missing platform, delays and the wake-up alarm, allow Binario to run without battery restrictions: consumption stays low and it stops by itself on arrival."] = "Le train est suivi même avec Binario fermé. Certains téléphones arrêtent toutefois les alertes après un moment pour économiser la batterie. Pour ne pas manquer la voie, les retards et le réveil, autorisez Binario à fonctionner sans restrictions de batterie : la consommation reste faible et l'appli s'arrête toute seule à l'arrivée."
        m["Guide for your phone"] = "Guide pour votre téléphone"
        m["Not now"] = "Pas maintenant"
        m["Infrastructure manager of the Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa and Brescia–Iseo–Edolo network. Trains are run by Trenord."] = "Gestionnaire d'infrastructure du réseau Milano Cadorna–Saronno–Varese, Côme, Novare, Laveno, Asso, Seregno, Malpensa et Brescia–Iseo–Edolo. Les trains sont exploités par Trenord."
        m["Lifts and escalators out of service"] = "Ascenseurs et escaliers mécaniques hors service"
        m["The FERROVIENORD site is not responding. Open the official page or retry."] = "Le site de FERROVIENORD ne répond pas. Ouvrez la page officielle ou réessayez."
        m["No equipment reported out of service."] = "Aucun équipement signalé hors service."
        m["No equipment out of service at this station."] = "Aucun équipement hors service dans cette gare."
        m["Platform not accessible: "] = "Quai non accessible : "
        m["Out of service since "] = "Hors service depuis "
        m["Expected back: "] = "Remise en service prévue : "
        m["Source: ferrovienord.it · Station accessibility notices (read now, refreshed every 30 minutes)."] = "Source : ferrovienord.it · Avis d'accessibilité des gares (lus maintenant, actualisés toutes les 30 minutes)."
        m["Accessibility and assistance"] = "Accessibilité et assistance"
        m["Live lift and escalator status"] = "État en direct des ascenseurs et escaliers mécaniques"
        m["Assistance for disabled passengers: 800 210 955"] = "Assistance aux passagers handicapés : 800 210 955"
        m["Trenord/FERROVIENORD free number · book at least 48 hours ahead"] = "Numéro gratuit Trenord/FERROVIENORD · réserver au moins 48 heures à l'avance"
        m["Assistance request by email"] = "Demande d'assistance par e-mail"
        m["Book assistance online"] = "Réserver l'assistance en ligne"
        m["Station accessibility sheets · Milan branches"] = "Fiches d'accessibilité des gares · lignes de Milan"
        m["Station accessibility sheets · Brescia–Iseo–Edolo"] = "Fiches d'accessibilité des gares · Brescia–Iseo–Edolo"
        m["Station accessibility and reduced mobility"] = "Accessibilité des gares et mobilité réduite"
        m["Every FERROVIENORD station has a defibrillator (125 installed in 2022–2023): where possible on the outside wall so it can be reached at night, in an alarmed, marked case with a first-aid kit. It is remotely monitored and registered with the regional emergency centres. It can be used on children too. In an emergency call 112."] = "Chaque gare FERROVIENORD dispose d'un défibrillateur (125 installés en 2022–2023) : si possible sur le mur extérieur pour être accessible la nuit, dans un boîtier signalé et alarmé avec une trousse de premiers secours. Il est surveillé à distance et enregistré auprès des centrales d'urgence régionales. Il peut aussi être utilisé sur les enfants. En cas d'urgence, appelez le 112."
        m["Map of nearby defibrillators"] = "Carte des défibrillateurs à proximité"
        m["FERROVIENORD stations and other AEDs"] = "Gares FERROVIENORD et autres DAE"
        m["Defibrillators page"] = "Page des défibrillateurs"
        m["Network documents (PIR web)"] = "Documents du réseau (PIR web)"
        m["Service quality indicators 2026"] = "Indicateurs de qualité de service 2026"
        m["Line and facility characteristics"] = "Caractéristiques des lignes et installations"
        m["Station usage plan"] = "Plan d'utilisation des gares"
        m["Station upgrades for reduced mobility"] = "Aménagements des gares pour la mobilité réduite"
        m["Network statement"] = "Document de référence du réseau"
        m["All documents"] = "Tous les documents"
        m["Sources: ferrovienord.it (PIR web, station accessibility notices, defibrillators) and trenord.it (assistance). Restore dates are the manager's estimates."] = "Sources : ferrovienord.it (PIR web, avis d'accessibilité des gares, défibrillateurs) et trenord.it (assistance). Les dates de remise en service sont des estimations du gestionnaire."
        m["Customer service"] = "Service client"
        m["Validators & more"] = "Composteurs et plus"
        m[" (open/closed from Trenord)"] = " (ouvert/fermé selon Trenord)"
        m["trenitalia.com · Customer service offices (April 2025 hours)"] = "trenitalia.com · Bureaux du service client (horaires d'avril 2025)"
        m["italotreno.com · Station ticket offices"] = "italotreno.com · Guichets en gare"
        m["SBB open data (data.sbb.ch)"] = "Données ouvertes CFF (data.sbb.ch)"
        m["Loading sales points…"] = "Chargement des points de vente…"
        m["you"] = "vous"
        m["nearest to"] = "le plus proche de"
        m["Trenord sales points are in Lombardy. Nearby: SBB machines, altoadigemobilità and OpenStreetMap points; elsewhere in Italy use the official Trenitalia map (at the bottom)."] = "Les points de vente Trenord sont en Lombardie. À proximité : distributeurs CFF, altoadigemobilità et points OpenStreetMap ; ailleurs en Italie, utilisez la carte officielle Trenitalia (en bas)."
        m["Open/closed updated now from Trenord for the province of"] = "Ouvert/fermé mis à jour maintenant par Trenord pour la province de"
        m["No sales points found."] = "Aucun point de vente trouvé."
        m["Showing the nearest 300: search a town or station for the others."] = "Affichage des 300 plus proches : recherchez une ville ou une gare pour les autres."
        m["Distance: "] = "Distance : "
        m["Sells: "] = "Vend : "
        m["Weekly opening hours"] = "Horaires d'ouverture hebdomadaires"
        m["Visit the page"] = "Visiter la page"
        m["Card"] = "Carte"
        m["Coins"] = "Pièces"
        m[", limited operation"] = ", fonctionnement limité"
        m["*Limited operation"] = "*Fonctionnement limité"
        m["closed"] = "fermé"
        m["Trenord offices, machines and resellers"] = "Guichets, distributeurs et revendeurs Trenord"
        m["open/closed read now"] = "ouvert/fermé lu maintenant"
        m["SBB ticket machines (data.sbb.ch)"] = "Distributeurs de billets CFF (data.sbb.ch)"
        m["other points from"] = "autres points de"
        m["1 machine"] = "1 distributeur"
        m["machines"] = "distributeurs"
        m["Overview"] = "Vue d'ensemble"
        m["Statistics not available right now."] = "Statistiques indisponibles pour le moment."
        m["Search station"] = "Rechercher une gare"
        m["Train number or destination"] = "Numéro du train ou destination"
        m["Least punctual"] = "Les moins ponctuels"
        m["Most punctual"] = "Les plus ponctuels"
        m["FerrovieNord network"] = "Réseau FerrovieNord"
        m["Milan Passante"] = "Passante de Milan"
        m["collected by the app · "] = "collecté par l'appli · "
        m[" days"] = " jours"
        m["No results"] = "Aucun résultat"
        m["on time (within 5 min)"] = "à l'heure (à moins de 5 min)"
        m[" points vs "] = " points contre "
        m["arrivals observed"] = "arrivées observées"
        m["cancelled runs"] = "courses supprimées"
        m["Avg delay "] = "Retard moyen "
        m[" arrivals"] = " arrivées"
        m[" cancelled"] = " supprimés"
        m[" trains"] = " trains"
        m["Your trains"] = "Vos trains"
        m["Your stations"] = "Vos gares"
        m["Switzerland · SBB"] = "Suisse · CFF"
        m["SBB data not reachable right now."] = "Données CFF injoignables pour le moment."
        m[" stop arrivals"] = " arrivées aux arrêts"
        m[" cancelled stops"] = " arrêts supprimés"
        m["Data for "] = "Données pour "
        m["Average of "] = "Moyenne de "
        m[" days ("] = " jours ("
        m["Why BLS, SOB, Rhaetian Railway and the other Swiss companies are missing"] = "Pourquoi BLS, SOB, les Chemins de fer rhétiques et les autres compagnies suisses sont absents"
        m["FerrovieNord network · Trenord"] = "Réseau FerrovieNord · Trenord"
        m["Collection just started: first data after a few hours, reliable figures after a couple of weeks."] = "Collecte tout juste commencée : premières données après quelques heures, chiffres fiables après environ deux semaines."
        m["Today's data"] = "Données du jour"
        m["Last "] = "Derniers "
        m[" days collected ("] = " jours collectés ("
        m["Stations are in the Stations tab (FerrovieNord filter)."] = "Les gares sont dans l'onglet Gares (filtre FerrovieNord)."
        m["Collection on"] = "Collecte le"
        m[" runs"] = " courses"
        m[" severe delays"] = " retards importants"
        m["recent days (collected by the app)"] = "derniers jours (collectés par l'appli)"
        m[" runs observed"] = " courses observées"
        m["Recent punctuality (FN network): "] = "Ponctualité récente (réseau FN) : "
        m["Last month punctuality: "] = "Ponctualité du dernier mois : "
        m["avg delay "] = "retard moyen "
        m[". On time = arrival within 5 minutes."] = ". À l'heure = arrivée à moins de 5 minutes."
        m["How shall I find your train? Type its number, or I find the station nearest to you, or pick a station and time."] = "Comment retrouver votre train ? Saisissez son numéro, ou je trouve la gare la plus proche de vous, ou choisissez une gare et une heure."
        m["No sign-up needed and your data stays on the phone. To send you alerts I need permission for notifications: tap Allow."] = "Aucune inscription nécessaire et vos données restent sur le téléphone. Pour vous envoyer des alertes, j'ai besoin de l'autorisation de notifications : touchez Autoriser."
        m["Without notifications I can only update you here in the app. You can turn them on any time in the phone settings."] = "Sans notifications, je ne peux vous tenir informé qu'ici dans l'appli. Vous pouvez les activer à tout moment dans les paramètres du téléphone."
        m["I found this train: is it yours?"] = "J'ai trouvé ce train : est-ce le vôtre ?"
        m["I can't connect. Check your connection and try again."] = "Je n'arrive pas à me connecter. Vérifiez votre connexion et réessayez."
        m["plat. "] = "voie "
        m["Without location I can't find the nearby station: pick the station yourself."] = "Sans localisation, je ne peux pas trouver la gare proche : choisissez la gare vous-même."
        m["I can't find your location. Turn on location or pick the station."] = "Je ne trouve pas votre position. Activez la localisation ou choisissez la gare."
        m["Station list unavailable, try again."] = "Liste des gares indisponible, réessayez."
        m["I can't answer right now: check your connection."] = "Je ne peux pas répondre pour le moment : vérifiez votre connexion."
        m["They said: "] = "Ils ont dit : "
        m["Hold the phone close to the speaker"] = "Approchez le téléphone du haut-parleur"
        m["Say the train number or ask a question"] = "Dites le numéro du train ou posez une question"
        m["Speech recognition isn't available on this phone: install or enable the Google app."] = "La reconnaissance vocale n'est pas disponible sur ce téléphone : installez ou activez l'appli Google."
        m["I can't read this train's data right now. Try again shortly."] = "Je ne peux pas lire les données de ce train pour le moment. Réessayez dans un instant."
        m["Where do you board?"] = "Où montez-vous ?"
        m["I'll alert you when the platform is announced or changes, if the delay grows, if the train is cancelled"] = "Je vous préviendrai quand la voie est annoncée ou change, si le retard augmente, si le train est supprimé"
        m[", and on arrival I'll send you a summary. Everything is in the ongoing notification too."] = ", et à l'arrivée je vous enverrai un récapitulatif. Tout figure aussi dans la notification permanente."
        m["Trip completed: I'm no longer following the train. Want to follow another one?"] = "Trajet terminé : je ne suis plus le train. Voulez-vous en suivre un autre ?"
        m["OK, no more updates on this train."] = "OK, plus de mises à jour sur ce train."
        m["Where do you get off? I'll warn you before the stop."] = "Où descendez-vous ? Je vous préviendrai avant l'arrêt."
        m["To the terminus"] = "Jusqu'au terminus"
        m["No alarm needed: follow to the terminus"] = "Pas d'alarme nécessaire : suivre jusqu'au terminus"
        m["+1 hour"] = "+1 heure"
        m["+2 hours"] = "+2 heures"
        m["+3 hours"] = "+3 heures"
        m["Pick time"] = "Choisir l'heure"
        m["Type or say the train number (it's on your ticket or the board)."] = "Saisissez ou dites le numéro du train (il figure sur votre billet ou le tableau)."
        m["Station and time"] = "Gare et heure"
        m["Follow another train"] = "Suivre un autre train"
        m["Delayed? Your rights"] = "En retard ? Vos droits"
        m["Transcribe speech"] = "Transcrire la parole"
        m["Let the phone speak"] = "Faire parler le téléphone"
        m["Train number, e.g. 2070"] = "Numéro du train, par ex. 2070"
        m["Type a train number or a question"] = "Saisissez un numéro de train ou une question"
        m["Speak"] = "Parler"
        m["Which station do you leave from?"] = "De quelle gare partez-vous ?"
        m["platform "] = "voie "
        m["platform not yet announced"] = "voie pas encore annoncée"
        m["Next stop: "] = "Prochain arrêt : "
        m["Last seen: "] = "Dernière position : "
        m["They said"] = "Ils ont dit"
        m["I am deaf: could you please write it down?"] = "Je suis sourd : pourriez-vous l'écrire, s'il vous plaît ?"
        m["Which platform does the train leave from?"] = "De quelle voie part le train ?"
        m["Could you tell me when we reach my stop?"] = "Pourriez-vous me dire quand nous arrivons à mon arrêt ?"
        m["How late is the train?"] = "De combien le train est-il en retard ?"
        m["Where can I buy a ticket?"] = "Où puis-je acheter un billet ?"
        m["Show the screen to the person in front of you: the phone is also reading it aloud."] = "Montrez l'écran à la personne en face de vous : le téléphone le lit aussi à voix haute."
        m["Type what you want to say"] = "Saisissez ce que vous voulez dire"
        m["Ready phrases"] = "Phrases toutes faites"
        m["Read aloud"] = "Lire à voix haute"
        m["Assistance is free, in the station and for getting on and off the train."] = "L'assistance est gratuite, en gare et pour monter et descendre du train."
        m["It covers wheelchair users and people with walking difficulties (even temporary), blind or partially sighted, deaf or with communication difficulties, people with intellectual or mental disabilities, older people and pregnant women."] = "Elle concerne les personnes en fauteuil roulant et celles qui ont des difficultés à marcher (même temporaires), aveugles ou malvoyantes, sourdes ou ayant des difficultés de communication, les personnes ayant un handicap intellectuel ou psychique, les personnes âgées et les femmes enceintes."
        m["Who to call depends on the station and train: at RFI stations (almost all Italian stations) the Sale Blu assist for every operator; at FerrovieNord stations Trenord does; in Switzerland, SBB."] = "Qui appeler dépend de la gare et du train : dans les gares RFI (presque toutes les gares italiennes), les Sale Blu assistent pour tous les opérateurs ; dans les gares FerrovieNord, c'est Trenord ; en Suisse, les CFF."
        m["RFI Sale Blu · Trenitalia, Italo, Trenord at RFI stations"] = "RFI Sale Blu · Trenitalia, Italo, Trenord dans les gares RFI"
        m["Toll-free from landlines · daily 6:45–21:30"] = "Gratuit depuis un poste fixe · tous les jours 6h45–21h30"
        m["From mobiles and abroad (standard rate)"] = "Depuis un mobile et l'étranger (tarif normal)"
        m["At least 6 hours before: stations, date, train, type of assistance, phone"] = "Au moins 6 heures avant : gares, date, train, type d'assistance, téléphone"
        m["SalaBlu Online and SalaBlu+ app"] = "SalaBlu Online et appli SalaBlu+"
        m["Booking up to 3 hours before; chat for deaf people"] = "Réservation jusqu'à 3 heures avant ; chat pour les personnes sourdes"
        m["How far ahead: at major stations (e.g. Milano Porta Garibaldi) up to 1 hour before for trains between 7:45 and 22:30; at other stations and at night at least 12 hours before. Groups of 3+: 24 hours. Trips abroad: 24–48 hours."] = "Délai : dans les grandes gares (par ex. Milano Porta Garibaldi) jusqu'à 1 heure avant pour les trains entre 7h45 et 22h30 ; dans les autres gares et la nuit au moins 12 heures avant. Groupes de 3 personnes et plus : 24 heures. Voyages à l'étranger : 24–48 heures."
        m["Be at the meeting point at least 30 minutes before: staff wear orange vests. To cancel, give at least 4 hours' notice."] = "Soyez au point de rendez-vous au moins 30 minutes avant : le personnel porte des gilets orange. Pour annuler, prévenez au moins 4 heures à l'avance."
        m["Trenord and FerrovieNord stations"] = "Gares Trenord et FerrovieNord"
        m["Trenord assistance toll-free · book preferably 48 hours ahead"] = "Numéro gratuit d'assistance Trenord · réserver de préférence 48 heures à l'avance"
        m["Trenord contact centre (also from mobiles)"] = "Centre de contact Trenord (aussi depuis un mobile)"
        m["Information and bookings"] = "Informations et réservations"
        m["Report barriers between train and station"] = "Signaler des obstacles entre le train et le quai"
        m["Pronto Italo · daily 7–23: suitable seat and assistance booking (provided in station by RFI)"] = "Pronto Italo · tous les jours 7h–23h : réservation d'une place adaptée et de l'assistance (assurée en gare par RFI)"
        m["Italo assistance page"] = "Page d'assistance Italo"
        m["SBB Contact Center Handicap from Italy · daily 5–24 (from Switzerland 0800 007 102, free)"] = "Centre de contact CFF Handicap depuis l'Italie · tous les jours 5h–24h (depuis la Suisse 0800 007 102, gratuit)"
        m["Book online"] = "Réserver en ligne"
        m["swisspass.ch/handicap · at least 1 hour before (international trips 24 hours)"] = "swisspass.ch/handicap · au moins 1 heure avant (voyages internationaux 24 heures)"
        m["Tips by type of disability"] = "Conseils selon le type de handicap"
        m["Wheelchair: boarding with ramp or lift. Wheelchair at most 70 cm wide, 120 cm long and 250 kg including the person. The station screen shows lifts per platform and current faults."] = "Fauteuil roulant : montée avec rampe ou élévateur. Fauteuil de 70 cm de large, 120 cm de long et 250 kg au maximum, personne comprise. L'écran de la gare indique les ascenseurs par voie et les pannes en cours."
        m["Blind or partially sighted: guide dogs travel free; you can ask for a suitable seat when booking. Turn on the spoken option: the app tells you platform, departure and your stop."] = "Aveugles ou malvoyants : les chiens guides voyagent gratuitement ; vous pouvez demander une place adaptée à la réservation. Activez l'option vocale : l'appli vous indique la voie, le départ et votre arrêt."
        m["Deaf people: the Sale Blu have a chat (after registering on SalaBlu Online). In My Conductor use \"Transcribe speech\" and \"Let the phone speak\"; turn on vibration and flash alerts."] = "Personnes sourdes : les Sale Blu ont un chat (après inscription sur SalaBlu Online). Dans Mon contrôleur, utilisez « Transcrire la parole » et « Faire parler le téléphone » ; activez les alertes par vibration et flash."
        m["Intellectual or mental disabilities, or people who are not self-sufficient: a companion may be needed; staff escort you from the meeting point to the train and connection."] = "Handicaps intellectuels ou psychiques, ou personnes non autonomes : un accompagnateur peut être nécessaire ; le personnel vous accompagne du point de rendez-vous au train et à la correspondance."
        m["Older people, pregnant women, casts or temporary difficulties: assistance is for you too, with a wheelchair on request and help with one piece of hand luggage."] = "Personnes âgées, femmes enceintes, plâtre ou difficultés temporaires : l'assistance est aussi pour vous, avec un fauteuil roulant sur demande et une aide pour un bagage à main."
        m["Connections: allow at least 30 minutes between trains when booking assistance."] = "Correspondances : prévoyez au moins 30 minutes entre les trains lors de la réservation de l'assistance."
        m["Open My Conductor"] = "Ouvrir Mon contrôleur"
        m["Emergency"] = "Urgence"
        m["Single emergency number (Italy and Switzerland)"] = "Numéro d'urgence unique (Italie et Suisse)"
        m["Numbers and rules from the official RFI, Trenord, Italo and SBB pages (October 2026): if in doubt, check the operator's site."] = "Numéros et règles issus des pages officielles de RFI, Trenord, Italo et CFF (octobre 2026) : en cas de doute, consultez le site de l'opérateur."
        m["Page"] = "Page"
        m["Changes"] = "Changements"
        m["direct"] = "direct"
        m["Downloading outbound…"] = "Téléchargement de l'aller…"
        m["Downloading return…"] = "Téléchargement du retour…"
        m["No runs found for that day"] = "Aucune course trouvée ce jour-là"
        m["Timetable for"] = "Horaire pour"
        m["runs"] = "courses"
        m["No runs found."] = "Aucune course trouvée."
        m["Real time from the operator · "] = "Temps réel de l'opérateur · "
        m["Scheduled times: delays not published by the operator · "] = "Horaires prévus : retards non publiés par l'opérateur · "
        m["Departure station not found"] = "Gare de départ introuvable"
        m["Arrival station not found"] = "Gare d'arrivée introuvable"
        m["responds but the format changed"] = "répond mais le format a changé"
        m["OK (backup server: "] = "OK (serveur de secours : "
        m["no response"] = "pas de réponse"
        m["Foreign operators (ÖBB, DB)"] = "Opérateurs étrangers (ÖBB, DB)"
        m["Replacement bus"] = "Bus de remplacement"
        m["SBB timetable (transport.opendata.ch)"] = "Horaire CFF (transport.opendata.ch)"
        m["ViaggiaTreno (RFI) · station board"] = "ViaggiaTreno (RFI) · tableau de la gare"
        m["Trenord · replacement bus map"] = "Trenord · carte des bus de remplacement"
        m["RFI · travel updates (works and replacement buses)"] = "RFI · infos de voyage (travaux et bus de remplacement)"
        m["SBB · S-Bahn and regional"] = "CFF · RER et régional"
    }

    private fun p5(m: HashMap<String, String>) {
        m["Wi-Fi and sockets: on Frecce and Italo on-board Wi-Fi is free and there are power sockets at the seats. Regional trains usually have no Wi-Fi and only some new trains have sockets. In Switzerland many SBB stations have free Wi-Fi."] = "Wi-Fi et prises : dans les Frecce et chez Italo, le Wi-Fi à bord est gratuit et il y a des prises aux places. Les trains régionaux n'ont généralement pas de Wi-Fi et seuls certains trains récents ont des prises. En Suisse, de nombreuses gares CFF ont le Wi-Fi gratuit."
        m["Seats: on Frecce, Intercity and Italo the seat is assigned with the ticket and you can choose it when buying (window, aisle…). Regional trains (Trenord, Trenitalia Regional, TILO) have no reservations: you sit wherever there is room."] = "Places assises : dans les Frecce, les Intercity et chez Italo, la place est attribuée avec le billet et tu peux la choisir à l'achat (fenêtre, couloir…). Dans les trains régionaux (Trenord, Trenitalia Regionale, TILO) on ne réserve pas : on s'assoit là où il y a de la place."
        m["First class: Frecciarossa trains have Standard, Premium, Business and Executive levels; Italo has Smart, Comfort, Prima and Club Executive. Many Trenord regional trains have 1st class, with a supplement of €2.80 per trip (€31 a month, €310 a year with a pass). In the search results you can see 1st-class prices with the \"1st class\" selector."] = "Première classe : le Frecciarossa propose les niveaux Standard, Premium, Business et Executive ; Italo propose Smart, Comfort, Prima et Club Executive. Beaucoup de trains régionaux Trenord ont une 1re classe, avec un supplément de 2,80 € par trajet (31 € par mois, 310 € par an avec un abonnement). Dans les résultats de recherche, tu vois les prix en 1re classe avec le sélecteur \"1re classe\"."
        m["Ticket validity: it depends on the ticket. STIBM area (Milan and surroundings): 75 minutes for 2 zones, 90 minutes in the city, longer with more zones. Arcobaleno/Trenord cross-border tickets: 4 hours for the whole trip. Digital regional tickets are valid for the day or train shown; paper ones must be validated before boarding. Frecce and Italo: valid for the booked train."] = "Validité du billet : elle dépend du billet. Zone STIBM (Milan et environs) : 75 minutes pour 2 zones, 90 minutes en ville, plus longtemps avec plus de zones. Billets transfrontaliers Arcobaleno/Trenord : 4 heures pour tout le trajet. Les billets régionaux numériques sont valables pour le jour ou le train indiqué ; les billets papier doivent être compostés avant de monter. Frecce et Italo : valables pour le train réservé."
        m["Parking: many stations have a car park (often paid) and bike racks or bike stations. The app does not list car parks yet: open the map from the station screen and search for \"parking\"."] = "Stationnement : beaucoup de gares ont un parking (souvent payant) et des arceaux ou des vélostations. L'appli ne liste pas encore les parkings : ouvre la carte depuis la fiche de la gare et cherche \"parking\"."
        m["Night trains: Trenitalia runs Intercity Notte trains (for example to southern Italy and Sicily); ÖBB Nightjets link Italy with Austria and Germany; in Ticino there is the TILO Pigiama night service on some nights. Search the route with an evening time."] = "Trains de nuit : Trenitalia fait circuler des Intercity Notte (par exemple vers le sud de l'Italie et la Sicile) ; les Nightjet ÖBB relient l'Italie à l'Autriche et à l'Allemagne ; au Tessin, il y a certaines nuits le service nocturne TILO Pigiama. Cherche le trajet avec un horaire du soir."
        m["Italo (NTV) is the private high-speed operator, on the high-speed lines between Turin, Milan, Venice, Bologna, Florence, Rome and Naples. Tickets are sold on italotreno.com, in the app, at Italo ticket offices and machines in stations; levels are Smart, Comfort, Prima and Club Executive. Binario shows Italo trains in the solutions and in real time. Pronto Italo: 06 07 08."] = "Italo (NTV) est la compagnie privée de grande vitesse, sur les lignes à grande vitesse entre Turin, Milan, Venise, Bologne, Florence, Rome et Naples. Les billets se vendent sur italotreno.com, dans l'appli, aux guichets et distributeurs Italo en gare ; les niveaux sont Smart, Comfort, Prima et Club Executive. Binario affiche les trains Italo dans les itinéraires et en temps réel. Pronto Italo : 06 07 08."
        m["Food and drink: on every train you can eat and drink what you bring. Frecce have a bar/FRECCIABistrò, Italo offers snacks and drinks; regional trains have no catering."] = "Boire et manger : dans tous les trains, tu peux manger et boire ce que tu apportes. Les Frecce ont un bar/FRECCIABistrò, Italo propose des snacks et des boissons ; les trains régionaux n'ont pas de restauration."
        m["Smoking is forbidden on all trains and in enclosed station areas, e-cigarettes on board included. Smokers risk a fine."] = "Il est interdit de fumer dans tous les trains et dans les espaces fermés des gares, y compris la cigarette électronique à bord. Les fumeurs risquent une amende."
        m["Discounts: Trenitalia has Economy and Super Economy fares (limited seats), discounts for young people and over-60s with CartaFRECCIA, and group offers. Italo has Low Cost and Economy fares and the Italo Più programme. In Lombardy Trenord has reduced passes for under-26s and over-65s and the Io Viaggio in Famiglia family discount. The app's \"Best prices\" calendar shows the lowest prices by time of day."] = "Réductions : Trenitalia propose les tarifs Economy et Super Economy (places limitées), des réductions pour les jeunes et les plus de 60 ans avec la CartaFRECCIA, et des offres de groupe. Italo propose les tarifs Low Cost et Economy et le programme Italo Più. En Lombardie, Trenord a des abonnements réduits pour les moins de 26 ans et les plus de 65 ans et la réduction famille Io Viaggio in Famiglia. Le calendrier \"Meilleurs prix\" de l'appli montre les prix les plus bas par tranche horaire."
        m["Groups: Trenitalia and Italo have group offers (usually from 10 people, to be requested in advance); Trenord has tickets for groups and school classes. Conditions and forms are on the operators' websites."] = "Groupes : Trenitalia et Italo ont des offres de groupe (en général à partir de 10 personnes, à demander à l'avance) ; Trenord a des billets pour les groupes et les classes. Conditions et formulaires sont sur les sites des compagnies."
        m["Minors travelling alone: the rules differ between operators. In general older children can travel alone with a valid ticket, while young children must be accompanied by an adult. Before travelling check the conditions of carriage of Trenord, Trenitalia or Italo."] = "Mineurs voyageant seuls : les règles diffèrent selon les compagnies. En général, les enfants plus âgés peuvent voyager seuls avec un billet valable, tandis que les jeunes enfants doivent être accompagnés d'un adulte. Avant de partir, vérifie les conditions de transport de Trenord, Trenitalia ou Italo."
        m["Digital tickets: no need to print them, just show them on your phone (PDF, app or QR code) with enough battery. Some tickets require check-in or activation before boarding: it is stated on the ticket and in the operator's app."] = "Billets numériques : inutile de les imprimer, il suffit de les montrer sur ton téléphone (PDF, appli ou QR code) avec assez de batterie. Certains billets demandent un check-in ou une activation avant de monter : c'est indiqué sur le billet et dans l'appli de la compagnie."
        m["Emergency or safety: call 112, the single emergency number. On board use the intercom or emergency button and tell the conductor; in stations there is the Railway Police (Polfer). For a theft report it to the Polfer or Carabinieri and block your cards and phone. The nearest defibrillator is on the Home screen."] = "Urgence ou sécurité : appelle le 112, le numéro d'urgence unique. À bord, utilise l'interphone ou le bouton d'urgence et préviens le contrôleur ; en gare, il y a la police ferroviaire (Polfer). En cas de vol, porte plainte auprès de la Polfer ou des Carabinieri et fais bloquer tes cartes et ton téléphone. Le défibrillateur le plus proche est sur l'écran d'accueil."
        m["Payments: ticket machines take cards (also contactless) and often cash; apps and websites take cards, PayPal and digital wallets depending on the operator; ticket offices also take cash. On some lines and metros you can tap a contactless card directly at the validators."] = "Paiements : les distributeurs acceptent les cartes (aussi sans contact) et souvent les espèces ; les applis et les sites acceptent les cartes, PayPal et les portefeuilles numériques selon la compagnie ; les guichets acceptent aussi les espèces. Sur certaines lignes et dans les métros, tu peux payer directement aux valideurs avec une carte sans contact."
        m["Replacement buses: when trains are replaced by buses, Stations → Replacement buses shows stops, times and sources for your station; notices are in News. The bus stop is usually signposted in front of the station."] = "Bus de remplacement : quand des trains sont remplacés par des bus, Gares → Bus de remplacement indique arrêts, horaires et sources pour ta gare ; les avis sont dans Actualités. L'arrêt du bus est généralement signalé devant la gare."
        m["Language: tap the flag at the top of the Home screen or go to More → Settings → Language. Italian, English, Chinese, German, French, Spanish and Japanese are available; the voice changes language too."] = "Langue : touche le drapeau en haut de l'écran d'accueil ou va dans Plus → Réglages → Langue. Il y a l'italien, l'anglais, le chinois, l'allemand, le français, l'espagnol et le japonais ; la voix change aussi de langue."
        m["Favourites: tap the star ★ on a train, a station board or a route. You find them in the Trains and Stations tabs, in Quick (recent and favourites) and in the Favourites widget; you can also add them to the Home shortcuts with +."] = "Favoris : touche l'étoile ★ sur un train, un tableau de gare ou un trajet. Tu les retrouves dans les onglets Trains et Gares, dans Rapide (récents et favoris) et dans le widget Favoris ; tu peux aussi les ajouter aux raccourcis de l'accueil avec +."
        m["Searching a timetable: in the Search tab choose departure and arrival, date and time (and return if needed), then tap Search. The results show times, changes, prices and delays; tap a train for stops and platforms. You can also ask me \"trains from Varese to Milano\"."] = "Chercher un horaire : dans l'onglet Rechercher, choisis le départ et l'arrivée, la date et l'heure (et le retour si besoin), puis touche Rechercher. Les résultats indiquent horaires, changements, prix et retards ; touche un train pour voir les arrêts et les voies. Tu peux aussi me demander \"trains de Varese à Milano\"."
        m["Ticket on board: on regional trains you buy the ticket before boarding. If the station has no way to buy one (office closed, machine broken), tell the conductor as soon as you board: usually you can pay with a surcharge, but rules differ between operators. The conditions of carriage say when this is possible and how much it costs."] = "Billet à bord : dans les trains régionaux, on achète le billet avant de monter. Si la gare ne permet pas d'en acheter (guichet fermé, distributeur en panne), préviens le contrôleur dès que tu montes : en général tu peux régulariser avec un supplément, mais les règles varient selon les compagnies. Les conditions de transport indiquent quand c'est possible et combien cela coûte."
        m["SBB · InterRegio, InterCity, EuroCity"] = "CFF · InterRegio, InterCity, EuroCity"
        m[" · guaranteed band 6–9 / 18–21"] = " · plage garantie 6–9 / 18–21"
        m["Incomplete download"] = "Téléchargement incomplet"
        m["accessible"] = "accessible"
        m["tactile paving"] = "bandes podotactiles"
        m["steps"] = "marches"
        m["handrail"] = "main courante"
        m["level "] = "niveau "
        m["Hospital"] = "Hôpital"
        m["Pharmacy"] = "Pharmacie"
        m["emergency department"] = "service d'urgences"
        m["hospital"] = "hôpital"
        m["pharmacy"] = "pharmacie"
        m["You are not following any train. Ask for example \"train 2512\" and then tap \"Follow with voice alerts\"."] = "Vous ne suivez aucun train. Demandez par exemple \"train 2512\" puis touchez \"Suivre avec alertes vocales\"."
        m["Which station? Ask for example \"bus and taxi at Varese\"."] = "Quelle gare ? Demandez par exemple \"bus et taxi à Varese\"."
        m["Which station? Ask for example \"toilets at Saronno\"."] = "Quelle gare ? Demandez par exemple \"toilettes à Saronno\"."
        m["Tell me the train number, for example \"delay train 2512\" or \"platform of 9544\"."] = "Dites-moi le numéro du train, par exemple \"retard train 2512\" ou \"voie du 9544\"."
        m["Sorry, I didn't understand. Try one of these topics: "] = "Désolé, je n'ai pas compris. Essayez l'un de ces sujets : "
        m["lines "] = "lignes "
        m["Toilets: not mapped"] = "Toilettes : non référencées"
        m["Toilets: "] = "Toilettes : "
        m[", accessible"] = ", accessibles"
        m[", hours "] = ", horaires "
        m["Platforms: "] = "Voies : "
        m["Lifts: "] = "Ascenseurs : "
        m["Ticket office: "] = "Guichet : "
        m["Ticket machines: "] = "Distributeurs de billets : "
        m["Validators: "] = "Composteurs : "
        m["Station data not reachable now."] = "Données de la gare injoignables pour le moment."
        m["Train cancelled."] = "Train supprimé."
        m["Arrived"] = "Arrivé"
        m["Running on time."] = "Circule à l'heure."
        m[" (scheduled)"] = " (prévu)"
        m[", platform not yet announced"] = ", voie pas encore annoncée"
        m[" · scheduled platform "] = " · voie prévue "
        m[" · actual "] = " · réelle "
        m[" · CANCELLED"] = " · SUPPRIMÉ"
        m[" · on time"] = " · à l'heure"
        m[" · plat. "] = " · voie "
        m["Timetable service unreachable."] = "Service d'horaires injoignable."
        m[" plat."] = " voie"
        m["No rail strikes announced (source: Italian Ministry strike observatory)."] = "Aucune grève ferroviaire annoncée (source : observatoire des grèves du ministère italien)."
        m["Announced rail strikes:\n"] = "Grèves ferroviaires annoncées :\n"
        m["\n\nGuaranteed trains: More → Guaranteed trains."] = "\n\nTrains garantis : Plus → Trains garantis."
        m["Strike observatory unreachable."] = "Observatoire des grèves injoignable."
        m["No traffic disruptions reported right now."] = "Aucune perturbation signalée pour le moment."
        m["Take a few seconds to write the message."] = "Prenez quelques secondes pour écrire le message."
        m["You just sent a message: wait a few minutes before the next one."] = "Vous venez d'envoyer un message : attendez quelques minutes avant le suivant."
        m["This message has already been sent."] = "Ce message a déjà été envoyé."
        m["Too many links in the message: at most 2."] = "Trop de liens dans le message : 2 au maximum."
        m["The message does not look like text: describe the problem or suggestion in words."] = "Le message ne ressemble pas à du texte : décrivez le problème ou la suggestion avec des mots."
        m["Information, help during disruption, reduced mobility, Carta Blu, complaints"] = "Informations, aide en cas de perturbation, mobilité réduite, Carta Blu, réclamations"
        m["Italo tickets, changes, refunds and help"] = "Billets Italo, modifications, remboursements et assistance"
        m["Italo ticket machines (unstaffed)"] = "Distributeurs de billets Italo (sans personnel)"
        m["TILO/SBB and Arcobaleno tickets, passes, information and help"] = "Billets TILO/CFF et Arcobaleno, abonnements, informations et assistance"
        m["Live data not yet available"] = "Données en direct pas encore disponibles"
        m["Departed"] = "Parti"
        m[" changes"] = " changements"
        m["Downloading South Tyrol ticket outlets…"] = "Téléchargement des points de vente du Tyrol du Sud…"
        m["Locating outlets…"] = "Localisation des points de vente…"
        m["Downloading Trenord sales points…"] = "Téléchargement des points de vente Trenord…"
        m["Downloading ticket office hours…"] = "Téléchargement des horaires des guichets…"
        m["Downloading the sales points list…"] = "Téléchargement de la liste des points de vente…"
        m["Downloading the sellers list…"] = "Téléchargement de la liste des revendeurs…"
        m["Ticket machine"] = "Distributeur de billets"
        m["Price you entered"] = "Prix que vous avez saisi"
        m["platform not accessible: "] = "quai non accessible : "
        m["expected back on "] = "remise en service prévue le "
        m["Band from the official regional ticket price"] = "Tranche issue du prix officiel du billet régional"
        m["delay compensation"] = "indemnisation du retard"
        m["bikes on trains"] = "vélos dans les trains"
        m["children"] = "enfants"
        m["disability assistance"] = "assistance handicap"
        m["lost property"] = "objets trouvés"
        m["ticket validation"] = "validation des billets"
        m["bus and taxi at Varese"] = "bus et taxi à Varese"
        m["toilets at Saronno"] = "toilettes à Saronno"
        m["\nLast reported: "] = "\nDernier signalement : "
        m["\nNext: "] = "\nSuivant : "
        m["on time"] = "à l'heure"
        m["FN network"] = "réseau FN"
        m["Departure and arrival reminders"] = "Rappels de départ et d'arrivée"
        m["Disruptions on favourite routes and lines"] = "Perturbations sur les trajets et lignes favoris"
        m["Stop alarm"] = "Alarme d'arrêt"
        m["Board at "] = "Embarquement à "
        m[" at "] = " à "
        m[" · platform "] = " · voie "
        m["Alarm before "] = "Alarme avant "
        m["Data temporarily unavailable"] = "Données temporairement indisponibles"
        m[" on time."] = " à l'heure."
        m["\nWith a delay of 60 minutes or more you can claim compensation: see More › Conditions, rights and refunds."] = "\nAvec un retard de 60 minutes ou plus, vous pouvez demander une indemnisation : voir Plus › Conditions, droits et remboursements."
        m["\nIf you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation."] = "\nAvec un abonnement, les retards comptent pour le bonus mensuel (Trenord) ou l'indemnisation."
        m["\nI've stopped following the train. Have a good day!"] = "\nJe ne suis plus le train. Bonne journée !"
        m["trip completed"] = "trajet terminé"
        m["Platform change"] = "Changement de voie"
        m["Wake up! Next stop: "] = "Réveillez-vous ! Prochain arrêt : "
        m["Expected arrival at "] = "Arrivée prévue à "
        m["Expected departure at "] = "Départ prévu à "
        m["Arrival at "] = "Arrivée à "
        m["Departure from "] = "Départ de "
        m["Warning: the train is cancelled"] = "Attention : le train est supprimé"
        m["Follow train"] = "Suivre le train"
        m["cancelled"] = "supprimé"
        m["It is cancelled."] = "Il est supprimé."
        m["Back on time."] = "De nouveau à l'heure."
        m["Alternatives:"] = "Alternatives :"
        m["No alternative found soon: open the app for more options."] = "Aucune alternative trouvée prochainement : ouvrez l'appli pour plus d'options."
        m["Refreshing widget…"] = "Actualisation du widget…"
        m["refreshing…"] = "actualisation…"
        m["Tap to set up"] = "Touchez pour configurer"
        m["Tap the title to choose what to show"] = "Touchez le titre pour choisir ce qui s'affiche"
        m["Tap ⟳ to refresh"] = "Touchez ⟳ pour actualiser"
        m["Refreshes automatically · ⟳ to retry"] = "Actualisation automatique · ⟳ pour réessayer"
        m["not updated"] = "non actualisé"
        m["Data service temporarily unreachable"] = "Service de données temporairement injoignable"
        m["Tap ⟳ to retry"] = "Touchez ⟳ pour réessayer"
        m["No departures in the next hours"] = "Aucun départ dans les prochaines heures"
        m["The widget refreshes itself; tap ⟳ to retry"] = "Le widget s'actualise tout seul ; touchez ⟳ pour réessayer"
        m["First departures"] = "Premiers départs"
        m["No trains now: here are the first scheduled"] = "Aucun train maintenant : voici les premiers prévus"
        m[" · not updated"] = " · non actualisé"
        m["Status not available yet"] = "État pas encore disponible"
        m["Resume following "] = "Reprendre le suivi de "
        m["The phone restarted: tap to keep receiving platform, delay and arrival alerts."] = "Le téléphone a redémarré : touchez pour continuer à recevoir les alertes de voie, de retard et d'arrivée."
        m["is cancelled."] = "est supprimé."
        m["Search by voice"] = "Recherche vocale"
        m["OpenStreetMap servers are not responding. Try again shortly or search Google Maps."] = "Les serveurs OpenStreetMap ne répondent pas. Réessayez dans un instant ou cherchez sur Google Maps."
        m["Set up"] = "Configurer"
        m["Share train status"] = "Partager l'état du train"
        m["Other apps"] = "Autres applis"
        m["Resellers"] = "Revendeurs"
        m["Mooney points"] = "Points Mooney"
        m["list from"] = "liste de"
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney points: see the official Trenitalia map."] = "Ailleurs en Italie, les billets régionaux Trenitalia sont vendus aux points PuntoLIS et Mooney : voir la carte officielle Trenitalia."
        m["Official Trenitalia map (all Italy)"] = "Carte officielle Trenitalia (toute l'Italie)"
        m["No data for this station. TrovaTreno does not publish the FerrovieNord network: for those stations the app collects arrivals from ViaggiaTreno by itself and data appears here after a few hours."] = "Pas de données pour cette gare. TrovaTreno ne publie pas le réseau FerrovieNord : pour ces gares, l'appli collecte elle-même les arrivées auprès de ViaggiaTreno et les données apparaissent ici au bout de quelques heures."
        m["Average delay "] = "Retard moyen "
        m["Each box compares only services of the same kind. Based on trains with at least 30 observed arrivals in the month; runs without a category are not included. Regional operators other than Trenord and Trenitalia (Tper, EAV, Ferrovie del Gargano, TUA, BLS…) are identified by route and train number; only those running on the RFI network tracked by ViaggiaTreno are included."] = "Chaque case compare uniquement des services de même type. Basé sur les trains avec au moins 30 arrivées observées dans le mois ; les courses sans catégorie ne sont pas incluses. Les opérateurs régionaux autres que Trenord et Trenitalia (Tper, EAV, Ferrovie del Gargano, TUA, BLS…) sont identifiés par l'itinéraire et le numéro du train ; seuls ceux circulant sur le réseau RFI suivi par ViaggiaTreno sont inclus."
        m["SBB counts a train as punctual under 3 minutes late (5 in Italy), so the comparison with Italy is conservative. SBB publishes only the previous day: the app collects one per day."] = "Les CFF considèrent un train comme ponctuel s'il a moins de 3 minutes de retard (5 en Italie), la comparaison avec l'Italie est donc prudente. Les CFF ne publient que la veille : l'appli en collecte un par jour."
        m["Their actual times exist as open data (opentransportdata.swiss, \"Ist-Daten\"), but only as a single daily file with all Swiss public transport: hundreds of MB, to be downloaded every day. On a phone that would use too much data and battery, and there is no service returning per-company totals as SBB does. They can be added in future if such a service appears, or with a small server that downloads the file and prepares the totals for the app."] = "Leurs horaires réels existent en données ouvertes (opentransportdata.swiss, « Ist-Daten »), mais seulement sous la forme d'un fichier quotidien unique avec tous les transports publics suisses : des centaines de Mo, à télécharger chaque jour. Sur un téléphone, cela consommerait trop de données et de batterie, et il n'existe aucun service fournissant des totaux par compagnie comme le font les CFF. Elles pourront être ajoutées à l'avenir si un tel service apparaît, ou avec un petit serveur qui télécharge le fichier et prépare les totaux pour l'appli."
        m["TrovaTreno does not publish the FerrovieNord network. The app reads arrivals from ViaggiaTreno by itself: every 80 minutes on Wi-Fi, every 3 hours on mobile data (about 0.3 MB). On time = within 5 minutes. Figures depend on when the phone is on and connected."] = "TrovaTreno ne publie pas le réseau FerrovieNord. L'appli lit elle-même les arrivées auprès de ViaggiaTreno : toutes les 80 minutes en Wi-Fi, toutes les 3 heures en données mobiles (environ 0,3 Mo). À l'heure = à moins de 5 minutes. Les chiffres dépendent des moments où le téléphone est allumé et connecté."
        m["Hi, I'm your Conductor! 🚆 I keep you posted about your train before, during and after the trip: platform, delays, platform changes, cancellations, next stops and arrival. It works with all trains: Trenord, Trenitalia, FerrovieNord, Italo, TILO and SBB."] = "Bonjour, je suis votre contrôleur ! 🚆 Je vous tiens informé de votre train avant, pendant et après le trajet : voie, retards, changements de voie, suppressions, prochains arrêts et arrivée. Cela fonctionne avec tous les trains : Trenord, Trenitalia, FerrovieNord, Italo, TILO et CFF."
        m["Departs"] = "Part"
        m["Arrives"] = "Arrive"
        m["Italy"] = "Italie"
        m["International"] = "International"
        m["Long distance"] = "Longue distance"
        m["Regional and long distance"] = "Régional et longue distance"
        m["Real time: ViaggiaTreno (RFI network)"] = "Temps réel : ViaggiaTreno (réseau RFI)"
        m["Real time: official Swiss timetable"] = "Temps réel : horaire officiel suisse"
        m["Real time only on the company's site/app"] = "Temps réel uniquement sur le site/l'appli de la compagnie"
        m["Scheduled times in the app (Transitous); real time only on the company's site/app"] = "Horaires prévus dans l'appli (Transitous) ; temps réel uniquement sur le site/l'appli de la compagnie"
        m["Regional and suburban"] = "Régional et banlieue"
        m["Intercity and long distance"] = "Intercity et longue distance"
        m["Plenty of seats"] = "Beaucoup de places"
        m["Moderately busy: look for seats"] = "Moyennement fréquenté : cherchez une place"
        m["Very crowded"] = "Très bondé"
        m["Trenord (sensors or previous days' history)"] = "Trenord (capteurs ou historique des jours précédents)"
        m["SBB forecast"] = "Prévision CFF"
        m["Binario estimate by time of day"] = "Estimation Binario selon l'heure de la journée"
        m["I can help with:\n• \"delay train 2070\" or \"where is 9544\"\n• \"trains from Varese to Milano\"\n• \"departures from Varese\" / \"arrivals at Como\"\n• \"any strikes?\"\n• \"traffic on S5\" / \"problems at Saronno\"\n• \"elevators at Saronno\"\n• \"guaranteed trains\"\n• \"where is my train?\" (the train you follow)\n• \"next train to Milano\"\n• \"bus, metro and taxi at Milano Centrale\"\n• \"toilets at Saronno\" / \"services at Varese\"\n• \"delay compensation\", \"can I bring my bike?\", \"children\", \"disability assistance\", \"lost property\"\nTap the microphone to ask by voice."] = "Je peux vous aider pour :\n• \"retard train 2070\" ou \"où est le 9544\"\n• \"trains de Varese à Milano\"\n• \"départs de Varese\" / \"arrivées à Como\"\n• \"y a-t-il des grèves ?\"\n• \"circulation sur la S5\" / \"problèmes à Saronno\"\n• \"ascenseurs à Saronno\"\n• \"trains garantis\"\n• \"où est mon train ?\" (le train que vous suivez)\n• \"prochain train pour Milano\"\n• \"bus, métro et taxi à Milano Centrale\"\n• \"toilettes à Saronno\" / \"services à Varese\"\n• \"indemnisation retard\", \"puis-je emporter mon vélo ?\", \"enfants\", \"assistance handicap\", \"objets trouvés\"\nTouchez le micro pour poser votre question à la voix."
        m["During regional rail strikes trains are normally guaranteed 6:00–9:00 and 18:00–21:00 on weekdays (7:00–10:00 and 18:00–21:00 on holidays). Updated official lists are in More → Guaranteed trains."] = "Lors des grèves du trafic ferroviaire régional, les trains sont normalement garantis de 6h00 à 9h00 et de 18h00 à 21h00 en semaine (7h00–10h00 et 18h00–21h00 les jours fériés). Les listes officielles mises à jour sont dans Plus → Trains garantis."
        m["yes"] = "oui"
        m[", platform not yet shown"] = ", voie pas encore affichée"
        m["Delay compensation (EU Regulation 2021/782):\n• 60–119 minutes late on arrival: 25% of the ticket\n• 120 minutes or more: 50%\n• Trenitalia Frecce: compensation also for 30–59 minutes, under Trenitalia's conditions\n• season tickets: own rules (Trenord gives season-ticket bonuses based on line punctuality)\nIf the expected delay exceeds 60 minutes you can also give up the trip with a full refund or be re-routed. The train screen shows whether you are entitled to compensation."] = "Indemnisation du retard (règlement UE 2021/782) :\n• 60–119 minutes de retard à l'arrivée : 25 % du billet\n• 120 minutes ou plus : 50 %\n• Trenitalia Frecce : indemnisation aussi pour 30–59 minutes, selon les conditions de Trenitalia\n• abonnements : règles propres (Trenord accorde des bonus d'abonnement selon la ponctualité de la ligne)\nSi le retard prévu dépasse 60 minutes, vous pouvez aussi renoncer au voyage avec remboursement intégral ou être réacheminé. L'écran du train indique si vous avez droit à une indemnisation."
        m["Ticket refund or change: it depends on the fare (cheap offers are often non-refundable). Trenitalia: request on the website or app with the ticket code (PNR). Trenord: from the refunds page. If the train is cancelled or expected more than 60 minutes late a refund is always due."] = "Remboursement ou échange du billet : cela dépend du tarif (les offres économiques ne sont souvent pas remboursables). Trenitalia : demande sur le site ou l'appli avec le code du billet (PNR). Trenord : depuis la page des remboursements. Si le train est supprimé ou attendu avec plus de 60 minutes de retard, un remboursement est toujours dû."
        m["Validation: paper regional tickets without date and time must be validated before boarding (validating machine in the station). Digital tickets bought online or in the app already show the train or the day: check on the ticket whether check-in is needed. The nearest validators are in Stations → station → Overview, or More → Nearby resellers."] = "Validation : les billets régionaux papier sans date ni heure doivent être validés avant de monter (composteur en gare). Les billets numériques achetés en ligne ou dans l'appli indiquent déjà le train ou le jour : vérifiez sur le billet si un enregistrement est nécessaire. Les composteurs les plus proches se trouvent dans Gares → gare → Aperçu, ou Plus → Revendeurs à proximité."
        m["Without a valid ticket you pay the fare plus a fine; amounts and how to pay (reduced if you pay at once or within a few days) are in the operator's conditions of carriage. If the ticket machine was broken, tell the conductor straight away."] = "Sans billet valable, vous payez le tarif plus une amende ; les montants et les modalités de paiement (réduit si vous payez tout de suite ou sous quelques jours) figurent dans les conditions de transport de l'opérateur. Si le distributeur était en panne, signalez-le tout de suite au contrôleur."
        m["Bikes and scooters:\n• Trenord (Lombardy): regular, folding, electric bikes and scooters travel free on all trains, at any time, space permitting\n• Trenitalia Regional: usually on trains with the bike symbol, with a supplement\n• Frecce and Italo: normally only folded bikes in a bag\n• TILO: SBB rules in Ticino, Trenord rules in Lombardy"] = "Vélos et trottinettes :\n• Trenord (Lombardie) : vélos classiques, pliants, électriques et trottinettes voyagent gratuitement dans tous les trains, à toute heure, selon la place disponible\n• Trenitalia Regional : généralement dans les trains avec le symbole du vélo, avec supplément\n• Frecce et Italo : normalement seulement les vélos pliés dans une housse\n• TILO : règles CFF au Tessin, règles Trenord en Lombardie"
        m["Pets on trains:\n• Trenord: free within Lombardy (carrier max 70×30×50 cm; dogs with muzzle, leash and registry certificate); not allowed on weekdays 7:00–9:30 and 17:30–19:30; beyond Lombardy an animal supplement is needed\n• Trenitalia: carrier free; on regional trains large dogs pay 50% of 2nd class; on Frecce and Intercity add \"Travel with your dog\" when buying\n• Italo: free up to about 5 kg in a carrier; larger dogs with the \"Dog\" service in Smart and Prima\n• SBB/TILO: free up to 30 cm in a bag; otherwise half fare or dog day pass CHF 25\n• Guide and assistance dogs: always free. Details in More → Travelling with pets."] = "Animaux dans les trains :\n• Trenord : gratuit en Lombardie (panier max. 70×30×50 cm ; chiens avec muselière, laisse et certificat d'inscription) ; interdit en semaine 7h00–9h30 et 17h30–19h30 ; au-delà de la Lombardie, un supplément animal est nécessaire\n• Trenitalia : panier gratuit ; dans les trains régionaux, les grands chiens paient 50 % de la 2e classe ; pour les Frecce et Intercity, ajoutez \"Voyagez avec votre chien\" à l'achat\n• Italo : gratuit jusqu'à environ 5 kg en panier ; chiens plus grands avec le service \"Chien\" en Smart et Prima\n• CFF/TILO : gratuit jusqu'à 30 cm dans un sac ; sinon demi-tarif ou carte journalière pour chien CHF 25\n• Chiens guides et d'assistance : toujours gratuit. Détails dans Plus → Voyager avec des animaux."
        m["Children:\n• Regional trains in Lombardy: free under 4 without a seat, 50% off from 4 to under 14\n• Trenitalia national trains: free under 4 without a seat, 50% off the Base fare from 4 to under 15\n• Other regions and Italo have their own rules"] = "Enfants :\n• Trains régionaux en Lombardie : gratuit en dessous de 4 ans sans siège, 50 % de réduction de 4 à moins de 14 ans\n• Trains nationaux Trenitalia : gratuit en dessous de 4 ans sans siège, 50 % de réduction sur le tarif Base de 4 à moins de 15 ans\n• Les autres régions et Italo ont leurs propres règles"
        m["Assistance for people with disabilities or reduced mobility:\n• RFI Sala Blu (RFI stations): 800 90 60 60, from mobiles +39 02 32 32 32\n• Trenord: 800 210 955 (daily 8:15–19:45) or +39 02 72 49 49 49; book preferably 48 hours ahead\n• SBB (Ticino): 0800 007 102\nThe station screen shows lifts per platform and current faults."] = "Assistance aux personnes handicapées ou à mobilité réduite :\n• RFI Sala Blu (gares RFI) : 800 90 60 60, depuis un mobile +39 02 32 32 32\n• Trenord : 800 210 955 (tous les jours 8h15–19h45) ou +39 02 72 49 49 49 ; réserver de préférence 48 heures à l'avance\n• CFF (Tessin) : 0800 007 102\nL'écran de la gare indique les ascenseurs par voie et les pannes en cours."
        m["Lost property: tell the conductor straight away. Trenord: 02 72 49 49 49, items kept at the Cadorna and Garibaldi My Link Points for a few days, then at the City of Milan office (via Friuli 30). Trenitalia: lost items search service and Frecciadesk. Italo: Pronto Italo 06 07 08. SBB/TILO: report online at lostandfound.sbb.ch. Details in More → Lost property."] = "Objets trouvés : prévenez tout de suite le contrôleur. Trenord : 02 72 49 49 49, objets conservés quelques jours aux My Link Points de Cadorna et Garibaldi, puis au bureau de la Ville de Milan (via Friuli 30). Trenitalia : service de recherche d'objets perdus et Frecciadesk. Italo : Pronto Italo 06 07 08. CFF/TILO : signalement en ligne sur lostandfound.sbb.ch. Détails dans Plus → Objets trouvés."
        m["Strikes and tickets: Trenord refunds on request within 30 days of the strike. Trenitalia refunds from the announcement: Frecce and Intercity up to departure time, regional trains until midnight of the day before. In the guaranteed time bands (weekdays 6–9 and 18–21) the trains on the official list run."] = "Grèves et billets : Trenord rembourse sur demande dans les 30 jours suivant la grève. Trenitalia rembourse dès l'annonce : Frecce et Intercity jusqu'à l'heure de départ, trains régionaux jusqu'à minuit la veille. Dans les plages garanties (en semaine 6–9 et 18–21 h), les trains de la liste officielle circulent."
        m["Cancelled train: you are entitled to a full refund or to travel on the first available train to the same destination. A replacement bus is often provided: see the notices (More → Strikes, traffic and works). Tell me the train number to check it."] = "Train supprimé : vous avez droit à un remboursement intégral ou à voyager sur le premier train disponible vers la même destination. Un bus de remplacement est souvent prévu : voir les avis (Plus → Grèves, circulation et travaux). Donnez-moi le numéro du train pour le vérifier."
        m["Missed connection because of a delay: with a single ticket you can continue on the first available train at no extra cost. For journeys with a change the app shows the minutes to change and warns \"connection at risk\" if the first train is late."] = "Correspondance manquée à cause d'un retard : avec un billet unique, vous pouvez continuer sur le premier train disponible sans frais supplémentaires. Pour les trajets avec changement, l'appli indique les minutes de correspondance et avertit « correspondance compromise » si le premier train est en retard."
        m["Luggage: you travel with your own bags in the luggage spaces at no cost for normal use; they must stay under your control and not block aisles and doors. Large stations often have a paid left-luggage office."] = "Bagages : vous voyagez avec vos propres bagages dans les espaces prévus sans frais pour un usage normal ; ils doivent rester sous votre contrôle et ne pas bloquer les couloirs et les portes. Les grandes gares ont souvent une consigne payante."
        m["Tickets: on the official websites and apps (Trenitalia, Trenord, Italo), at ticket offices and machines in the station, and at authorised resellers (tobacconists, newsagents). More → Nearby resellers shows ticket offices, machines (also contactless) and resellers near you."] = "Billets : sur les sites et applis officiels (Trenitalia, Trenord, Italo), aux guichets et distributeurs en gare, et chez les revendeurs agréés (bureaux de tabac, marchands de journaux). Plus → Revendeurs à proximité indique les guichets, distributeurs (aussi sans contact) et revendeurs près de vous."
        m["Season tickets: Trenord offers monthly and annual tickets and the integrated Io Viaggio passes (train + public transport in Lombardy). Trenitalia has regional and Frecce passes. Season-ticket holders have their own refund and delay-bonus rules."] = "Abonnements : Trenord propose des abonnements mensuels et annuels et les abonnements intégrés Io Viaggio (train + transports publics en Lombardie). Trenitalia propose des abonnements régionaux et Frecce. Les abonnés ont leurs propres règles de remboursement et de bonus de retard."
        m["Airports:\n• Malpensa: Malpensa Express from Milano Cadorna and Milano Centrale, stops T1 and T2\n• Linate: metro line M4 (no train)\n• Orio al Serio (Bergamo): bus from Bergamo station\nAsk me for example \"trains from Milano Cadorna to Malpensa\"."] = "Aéroports :\n• Malpensa : Malpensa Express depuis Milano Cadorna et Milano Centrale, arrêts T1 et T2\n• Linate : ligne de métro M4 (pas de train)\n• Orio al Serio (Bergame) : bus depuis la gare de Bergame\nDemandez-moi par exemple \"trains de Milano Cadorna à Malpensa\"."
        m["Switzerland and TILO: trips between Lombardy and Ticino need cross-border tickets (Arcobaleno in CHF or Trenord in euros). TILO lines, fares and services are in More → TILO; for a route ask \"trains from Como to Lugano\"."] = "Suisse et TILO : les trajets entre la Lombardie et le Tessin nécessitent des billets transfrontaliers (Arcobaleno en CHF ou Trenord en euros). Les lignes, tarifs et services TILO sont dans Plus → TILO ; pour un itinéraire, demandez \"trains de Como à Lugano\"."
        m["Contacts:\n• Trenitalia: 892021 (call centre)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (disability assistance): 800 90 60 60\nFor complaints use the forms on the official websites."] = "Contacts :\n• Trenitalia : 892021 (centre d'appels)\n• Trenord : +39 02 72 49 49 49\n• Italo : 892020\n• RFI Sala Blu (assistance handicap) : 800 90 60 60\nPour les réclamations, utilisez les formulaires des sites officiels."
        m["Your rights (EU Regulation 2021/782): travel information, refund or re-routing if the expected delay exceeds 60 minutes, compensation of 25% (60–119 minutes) or 50% (120+), assistance (drinks, meals, accommodation if needed), free assistance for people with disabilities."] = "Vos droits (règlement UE 2021/782) : informations de voyage, remboursement ou réacheminement si le retard prévu dépasse 60 minutes, indemnisation de 25 % (60–119 minutes) ou 50 % (120 et plus), assistance (boissons, repas, hébergement si nécessaire), assistance gratuite aux personnes handicapées."
        m["Platforms in the app: the scheduled platform comes from the timetable; the actual one (blue) is confirmed by the station. A change is shown in red (e.g. 3 → 5) and, if you follow the train, you get a notification and a voice alert."] = "Voies dans l'appli : la voie prévue vient de l'horaire ; la voie réelle (bleue) est confirmée par la gare. Un changement s'affiche en rouge (par ex. 3 → 5) et, si vous suivez le train, vous recevez une notification et une alerte vocale."
        m["Stop alarm: open the train, tap the stop where you get off and choose \"Wake me before this stop\". It rings when the train leaves the previous stop (or 4 minutes before); with voice alerts you also hear the voice."] = "Alarme d'arrêt : ouvrez le train, touchez l'arrêt où vous descendez et choisissez \"Me réveiller avant cet arrêt\". Elle sonne quand le train quitte l'arrêt précédent (ou 4 minutes avant) ; avec les alertes vocales, vous entendez aussi la voix."
        m["Where I board: open the train, tap the stop where you get on and choose \"I board here\". Platform, time and alerts refer to that stop."] = "Où je monte : ouvrez le train, touchez l'arrêt où vous montez et choisissez \"Je monte ici\". La voie, l'heure et les alertes se rapportent à cet arrêt."
        m["Timetables offline: search the route and tap the PDF icon in the results to download the day's timetable (outbound and return) to Download/Binario. The app also remembers the latest times of every route you searched."] = "Horaires hors ligne : recherchez le trajet et touchez l'icône PDF dans les résultats pour télécharger l'horaire du jour (aller et retour) dans Download/Binario. L'appli mémorise aussi les derniers horaires de chaque trajet recherché."
        m["Voice alerts: in Settings → Accessibility choose \"All\" or \"Only upcoming stop\". To ask by voice tap the microphone below, or long-press the Binario icon and choose \"Ask by voice\"."] = "Alertes vocales : dans Paramètres → Accessibilité, choisissez \"Tout\" ou \"Seulement le prochain arrêt\". Pour poser une question à la voix, touchez le micro ci-dessous, ou appuyez longuement sur l'icône Binario et choisissez \"Demander à la voix\"."
        m["Alerts for deaf people: in Settings → Accessibility turn on strong vibration (one pattern per alert) and the flashlight."] = "Alertes pour les personnes sourdes : dans Paramètres → Accessibilité, activez la forte vibration (un motif par alerte) et la lampe torche."
        m["Widgets: long-press an empty spot on the Home screen → Widgets → Binario. There are Route, Train, Station and Favourites; tap the title to change it."] = "Widgets : appuyez longuement sur un endroit vide de l'écran d'accueil → Widgets → Binario. Il y a Itinéraire, Train, Gare et Favoris ; touchez le titre pour le modifier."
        m["Following a train: open the train and tap \"Follow\": a pinned notification updates every minute and warns of platform changes and delays."] = "Suivre un train : ouvrez le train et touchez \"Suivre\" : une notification épinglée se met à jour chaque minute et signale les changements de voie et les retards."
        m["Punctuality: More → Punctuality has monthly statistics, with regional trains compared with regional ones and high speed separately, plus every station and train (TrovaTreno.it data)."] = "Ponctualité : Plus → Ponctualité contient des statistiques mensuelles, avec les trains régionaux comparés aux régionaux et la grande vitesse à part, ainsi que chaque gare et chaque train (données TrovaTreno.it)."
        m["Milan – Saronno – Varese – Laveno"] = "Milan – Saronno – Varese – Laveno"
        m["Milan – Saronno – Como"] = "Milan – Saronno – Côme"
        m["Milan – Saronno – Novara"] = "Milan – Saronno – Novare"
        m["Milan – Seveso – Asso"] = "Milan – Seveso – Asso"
        m["Brescia – Iseo – Edolo"] = "Brescia – Iseo – Edolo"
        m["Other trains (S lines and Passante)"] = "Autres trains (lignes S et Passante)"
        m["Check for updates"] = "Rechercher des mises à jour"
        m["Checking…"] = "Vérification…"
        m["You already have the latest version"] = "Vous avez déjà la dernière version"
        m["Couldn't check for updates: check your connection and try again."] = "Impossible de rechercher les mises à jour : vérifiez votre connexion et réessayez."
        m["Euro amounts are indicative (rate about €1.135 per CHF): the rate may differ at purchase."] = "Les montants en euros sont indicatifs (taux d'environ 1,135 € pour 1 CHF) : le taux peut différer à l'achat."
        m["More actions"] = "Plus d'actions"
        m["Not a railway station: opening it on the map"] = "Ce n'est pas une gare : ouverture sur la carte"
        m["Transport:"] = "Transport :"
        m["Trains only"] = "Trains uniquement"
        m["Also metro and bus"] = "Aussi métro et bus"
        m["There are no train-only solutions at this time: solutions with metro or bus are shown too."] = "Il n'y a aucune solution en train uniquement pour le moment : les solutions avec métro ou bus sont aussi affichées."
        m["Hidden"] = "Masqué"
        m["solutions with metro or bus"] = "solutions avec métro ou bus"
        m["Prices:"] = "Prix :"
        m["2nd class"] = "2e classe"
        m["1st class"] = "1re classe"
        m["1st class estimated: check sbb.ch"] = "1re classe estimée : vérifiez sur sbb.ch"
        m["New version available"] = "Nouvelle version disponible"
        m["Tap to download and install"] = "Touchez pour télécharger et installer"
        m["Quick"] = "Rapide"
        m["Active filters"] = "Filtres actifs"
        m["Nearby stations, toilets, replacement buses, taxis, defibrillators"] = "Gares proches, WC, bus de remplacement, taxis, défibrillateurs"
        m["Show these options on the Quick page too"] = "Afficher ces options aussi dans l'onglet Rapide"
        m["Send the link or the app file via WhatsApp, Telegram…"] = "Envoyer le lien ou le fichier de l'app par WhatsApp, Telegram…"
        m["Or send the app file directly (installed version):"] = "Ou envoyez directement le fichier de l'app (version installée) :"
        m["App file (APK)"] = "Fichier de l'app (APK)"
        m["The recipient must open it and allow installation. WhatsApp may refuse APK files: in that case use the link."] = "Le destinataire doit l'ouvrir et autoriser l'installation. WhatsApp peut refuser les fichiers APK : utilisez alors le lien."
        m["Binario, the free app for trains in Italy and Switzerland. Open the file and allow installation."] = "Binario, l'app gratuite pour les trains en Italie et en Suisse. Ouvrez le fichier et autorisez l'installation."
        m["Could not prepare the app file"] = "Impossible de préparer le fichier de l'app"
    }

    /** 0.1.23: Italo, prezzi migliori, cambi rischiosi, condivisione solo Android. */
    private fun p6(m: HashMap<String, String>) {
        m["Android smartphones and tablets only: it does not work on iPhone and iPad."] = "Uniquement pour smartphones et tablettes Android : ne fonctionne pas sur iPhone et iPad."
        m["Risky change"] = "Correspondance risquée"
        m["Tight change"] = "Correspondance serrée"
        m["For this change we recommend at least"] = "Pour cette correspondance, il est conseillé de prévoir au moins"
        m["a small delay could make you miss the connection."] = "un petit retard pourrait vous faire manquer la correspondance."
        m["Find an alternative with later trains"] = "Trouver une alternative avec des trains suivants"
        m["Two tickets: Italo on italotreno.com, the other train on trenitalia.com or trenord.it"] = "Deux billets : Italo sur italotreno.com, l'autre train sur trenitalia.com ou trenord.it"
        m["Change station not found"] = "Gare de correspondance introuvable"
        m["Arrival station not found"] = "Gare d'arrivée introuvable"
        m["Alternatives for the change at"] = "Alternatives à la correspondance à"
        m["Arriving on"] = "Arrivée avec le"
        m["Later trains with at least"] = "Trains suivants avec au moins"
        m["min to change"] = "min pour changer"
        m["No alternative found after this time."] = "Aucune alternative trouvée après cette heure."
        m["Comfortable changes"] = "Correspondances confortables"
        m["With tickets for a fixed train and time (Frecce, Italo, Intercity) taking another train may require changing the ticket. Regional tickets are valid on any regional train on the route."] = "Avec les billets liés à un train et un horaire (Frecce, Italo, Intercity), prendre un autre train peut nécessiter un échange du billet. Les billets régionaux sont valables dans tout train régional du trajet."
        m["Cannot reach the server. Check your connection."] = "Impossible de joindre le serveur. Vérifiez la connexion."
        m["Some time bands did not respond: tap to retry"] = "Certaines tranches horaires n'ont pas répondu : touchez pour réessayer"
        m["Lowest price for 1 adult among trains in that time band (Trenitalia, Trenord and Italo). «—» = no price available, «?» = service not reachable. Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "Prix le plus bas pour 1 adulte parmi les trains de cette tranche (Trenitalia, Trenord et Italo). «—» = aucun prix disponible, «?» = service injoignable. Touchez une case pour voir les solutions. Les tarifs économiques varient selon la disponibilité : le prix final est celui à l'achat."
        m["next 7 days, morning, afternoon and evening"] = "7 prochains jours, matin, après-midi et soir"
        m["Choose origin and destination to see the lowest prices for the next 7 days."] = "Choisissez le départ et l'arrivée pour voir les prix les plus bas des 7 prochains jours."
    }

    /** 0.1.24: silenzio degli avvisi di sciopero. */
    private fun p7(m: HashMap<String, String>) {
        m["Mute strike alerts"] = "Couper les alertes de grève"
        m["Muted until"] = "Coupées jusqu'au"
        m["On · tap to mute them for a while"] = "Activées · touchez pour les couper un moment"
        m["Turn back on"] = "Réactiver"
        m["1 hour"] = "1 heure"
        m["3 hours"] = "3 heures"
        m["8 hours"] = "8 heures"
        m["1 week"] = "1 semaine"
        m["1 month"] = "1 mois"
        m["For how long? Strikes stay visible in News."] = "Pour combien de temps ? Les grèves restent visibles dans Actualités."
        m["Until a day and time…"] = "Jusqu'à un jour et une heure…"
    }

    /** 0.1.25: passeggeri, menù laterale, prossimo sciopero, notifica del treno seguito. */
    private fun p8(m: HashMap<String, String>) {
        m["Travel"] = "Voyage"
        m["Best prices"] = "Meilleurs prix"
        m["At the station"] = "En gare"
        m["Tickets and passes"] = "Billets et abonnements"
        m["Fares"] = "Tarifs"
        m["Send feedback"] = "Envoyer un avis"
        m["Next train strike"] = "Prochaine grève des trains"
        m.putIfAbsent("Details", "Détails")
        m.putIfAbsent("Menu", "Menu")
        m["1 adult"] = "1 adulte"
        m["adults"] = "adultes"
        m["1 child"] = "1 enfant"
        m["children"] = "enfants"
        m["Passengers"] = "Passagers"
        m["Adults"] = "Adultes"
        m["Children"] = "Enfants"
        m["aged 4 to 14 (under 4 free without a seat)"] = "de 4 à 14 ans (moins de 4 ans gratuit sans place)"
        m["Prices shown are the total for all passengers. Discounts for children and families: check when buying."] = "Les prix affichés sont le total pour tous les passagers. Réductions enfants et familles : à vérifier à l'achat."
        m["Less"] = "Moins"
        m["More"] = "Plus"
        m.putIfAbsent("total price", "prix total")
        m.putIfAbsent("min early", "min d'avance")
        m.putIfAbsent("late", "de retard")
        m.putIfAbsent("Refresh", "Actualiser")
        m.putIfAbsent("On time", "À l'heure")
        m.putIfAbsent("Cancelled", "Supprimé")
    }

    /** 0.1.26: menù Accessibilità. */
    private fun p9(m: HashMap<String, String>) {
        m["Colour-blind, voice and vibration"] = "Daltoniens, voix et vibration"
    }

    /** Germania: treni, aziende, stazioni e biglietti. */
    private fun p10(m: HashMap<String, String>) {
        m["Trains in Germany"] = "Trains en Allemagne"
        m["Times, delays and platforms in real time for all German operators"] = "Horaires, retards et voies en temps réel de toutes les compagnies allemandes"
        m["Search a German station like an Italian one, also by its Italian name: «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Journey search (also Italy ⇄ Germany), departure and arrival boards, train details and «Follow» all work."] = "Cherchez une gare allemande comme une gare italienne, même avec son nom italien : «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Recherche d'itinéraires (aussi Italie ⇄ Allemagne), tableaux des départs et arrivées, fiche du train et «Suivre» fonctionnent."
        m["Data: official German DELFI timetables via Transitous. Prices are not public: buy on bahn.de or in the DB Navigator app."] = "Données : horaires officiels allemands DELFI via Transitous. Les prix ne sont pas publics : achat sur bahn.de ou dans l'appli DB Navigator."
        m["Train types"] = "Types de trains"
        m["DB high-speed trains between major cities; seat reservation recommended."] = "Grande vitesse DB entre les grandes villes ; réservation conseillée."
        m["Intercity and EuroCity: long distance, also to Austria, Switzerland and Italy."] = "Intercity et EuroCity : grandes lignes, aussi vers l'Autriche, la Suisse et l'Italie."
        m["Regional trains (DB Regio and many other companies): valid with the Deutschlandticket."] = "Trains régionaux (DB Regio et beaucoup d'autres) : valables avec le Deutschlandticket."
        m["City S-Bahn (Munich, Berlin, Hamburg, Stuttgart…): valid with the Deutschlandticket."] = "S-Bahn des villes (Munich, Berlin, Hambourg, Stuttgart…) : valables avec le Deutschlandticket."
        m["FlixTrain: low-cost long distance, Flix tickets only."] = "FlixTrain : grandes lignes à bas prix, billet Flix uniquement."
        m["Night trains: ÖBB Nightjet and European Sleeper."] = "Trains de nuit : ÖBB Nightjet et European Sleeper."
        m["Monthly pass for all regional trains (RE, RB, S-Bahn), buses, trams and metro in Germany. Not valid on ICE, IC, EC and FlixTrain. Cancel by the 10th of the month. It costs €63 until 31/12/2026 and €66.80 from 1 January 2027."] = "Abonnement mensuel pour tous les trains régionaux (RE, RB, S-Bahn), bus, trams et métros en Allemagne. Non valable dans les ICE, IC, EC et FlixTrain. Résiliable jusqu'au 10 du mois. 63 € jusqu'au 31/12/2026, 66,80 € à partir du 1er janvier 2027."
        m["Full fare: valid on any train on the chosen day."] = "Plein tarif : valable dans n'importe quel train du jour choisi."
        m["Cheaper when bought early, but tied to the chosen train (Zugbindung)."] = "Moins chers achetés à l'avance, mais liés au train choisi (Zugbindung)."
        m["DB annual discount cards (25% or 50%, or unlimited travel with the 100)."] = "Cartes de réduction annuelles DB (25 % ou 50 %, ou voyages illimités avec la 100)."
        m["Buy on bahn.de"] = "Acheter sur bahn.de"
        m["Deutschlandticket: information and purchase"] = "Deutschlandticket : informations et achat"
        m["DB Navigator app (tickets on your phone)"] = "Appli DB Navigator (billets sur le téléphone)"
        m["Delays: your rights"] = "Retards : vos droits"
        m["60 minutes or more late on arrival: 25% of the fare back; 120 minutes or more: 50% (minimum €4)."] = "60 minutes de retard ou plus à l'arrivée : 25 % du billet remboursé ; 120 minutes ou plus : 50 % (minimum 4 €)."
        m["Expected delay over 20 minutes: train binding is lifted and even with a Sparpreis you can take another train."] = "Retard prévu de plus de 20 minutes : la Zugbindung est levée et même avec un Sparpreis vous pouvez prendre un autre train."
        m["Expected arrival between midnight and 5 am with at least 60 minutes' delay: taxi refunded up to €120."] = "Arrivée prévue entre minuit et 5 h avec au moins 60 minutes de retard : taxi remboursé jusqu'à 120 €."
        m["Claim within 3 months on bahn.de, in DB Navigator or with the Fahrgastrechte form."] = "La demande se fait sous 3 mois sur bahn.de, dans DB Navigator ou avec le formulaire Fahrgastrechte."
        m["Passenger rights (Fahrgastrechte)"] = "Droits des voyageurs (Fahrgastrechte)"
        m["Assistance for people with disabilities"] = "Assistance aux personnes handicapées"
        m["Mon–Fri 6–22, Sat–Sun and holidays 8–20"] = "lun–ven 6h–22h, sam–dim et fériés 8h–20h"
        m["Book assistance online (by 8 pm the day before)"] = "Réserver l'assistance en ligne (avant 20 h la veille)"
        m["Companies and stations"] = "Compagnies et gares"
        m["All German railway companies"] = "Toutes les compagnies ferroviaires allemandes"
        m["DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… («Germany» filter)"] = "DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… (filtre «Allemagne»)"
        m["Open a German station's board › «Station» tab: services, lifts and accessibility from bahnhof.de"] = "Ouvrez le tableau d'une gare allemande › onglet «Gare» : services, ascenseurs et accessibilité depuis bahnhof.de"
        m["Germany: official DELFI timetables with delays and platforms in real time when published (Transitous)."] = "Allemagne : horaires officiels DELFI avec retards et voies en temps réel quand ils sont publiés (Transitous)."
        m["Station services (Germany)"] = "Services en gare (Allemagne)"
        m["Services, shops, DB Lounge and map"] = "Services, boutiques, DB Lounge et plan"
        m["Lifts with real-time status"] = "Ascenseurs avec état en temps réel"
        m["Station accessibility"] = "Accessibilité de la gare"
        m["Assistance for people with disabilities (DB)"] = "Assistance aux personnes handicapées (DB)"
        m["Valid with the Deutschlandticket"] = "Valable avec le Deutschlandticket"
        m["/month"] = "/mois"
        m["Price and tickets on bahn.de (Sparpreis tied to the train)"] = "Prix et billets sur bahn.de (Sparpreis liés au train)"
        m["ICE, regional trains, S-Bahn, Deutschlandticket, rights and companies"] = "ICE, régionaux, S-Bahn, Deutschlandticket, droits et compagnies"
        m["Italy, Switzerland and Germany: websites, tickets, data"] = "Italie, Suisse et Allemagne : sites, billets, données"
        m.putIfAbsent("Germany", "Allemagne")
        m["Times and real time in the app: official German DELFI data (Transitous)"] = "Horaires et temps réel dans l'appli : données officielles allemandes DELFI (Transitous)"
        m["Trip not found"] = "Trajet introuvable"
        m.putIfAbsent("Real time · ", "Temps réel · ")
        m["Scheduled times (no real time for this trip) · "] = "Horaires prévus (pas de temps réel pour ce trajet) · "
    }

    /** Puntualità: confronto tra aziende e paesi. */
    private fun p11(m: HashMap<String, String>) {
        m["Companies and countries compared"] = "Compagnies et pays comparés"
        m["Companies to compare"] = "Compagnies à comparer"
        m["Deutsche Bahn · official figures"] = "Deutsche Bahn · chiffres officiels"
        m["Each country measures differently: in Italy (TrovaTreno) and Austria a train is on time within 5 minutes, in Germany under 6 minutes, for SBB under 3 minutes (stricter). DB and ÖBB count stops along the route, TrovaTreno counts arrivals. The fairest comparison is between trains of the same type: use the Regional or Long distance filter."] = "Chaque pays mesure différemment : en Italie (TrovaTreno) et en Autriche un train est à l'heure jusqu'à 5 minutes, en Allemagne sous 6 minutes, pour les CFF sous 3 minutes (plus strict). DB et ÖBB comptent les arrêts en route, TrovaTreno les arrivées. La comparaison la plus juste est entre trains du même type : utilisez le filtre Régionaux ou Grandes lignes."
        m["How to read the comparison"] = "Comment lire la comparaison"
        m["No companies to compare: tap «Add»."] = "Aucune compagnie à comparer : touchez «Ajouter»."
        m["Remove from comparison"] = "Retirer de la comparaison"
        m["Some chosen companies have no data yet: they will appear when available."] = "Certaines compagnies choisies n'ont pas encore de données : elles apparaîtront dès que possible."
        m["Trenord · FerrovieNord network"] = "Trenord · réseau FerrovieNord"
        m.putIfAbsent("last ", "derniers ")
        m["long distance (Railjet, IC, Nightjet)"] = "grandes lignes (Railjet, IC, Nightjet)"
        m.putIfAbsent("regional", "régionaux")
        m["regional and S-Bahn"] = "régionaux et S-Bahn"
        m["ÖBB · official figures"] = "ÖBB · chiffres officiels"
    }

    /** Germania: scioperi e prezzi. */
    private fun p12(m: HashMap<String, String>) {
        m["Train strikes in Germany"] = "Grèves des trains en Allemagne"
        m["News not reachable right now."] = "Actualités injoignables pour le moment."
        m["No train strike announced in Germany in the last 14 days."] = "Aucune grève des trains annoncée en Allemagne ces 14 derniers jours."
        m["News in German (Google News): in Germany strikes are announced by the GDL and EVG unions a few days in advance, with no official calendar."] = "Actualités en allemand (Google News) : en Allemagne, les syndicats GDL et EVG annoncent les grèves quelques jours avant, sans calendrier officiel."
        m["Traffic in Germany: disruptions and engineering works (DB)"] = "Trafic en Allemagne : perturbations et travaux (DB)"
        m["Open on bahn.de"] = "Ouvrir sur bahn.de"
        m["For trains in Germany prices are not public: the lowest-price calendar is on bahn.de («Bestpreissuche»). With regional trains only, the Deutschlandticket is valid."] = "Pour les trains en Allemagne, les prix ne sont pas publics : le calendrier des prix les plus bas est sur bahn.de («Bestpreissuche»). Avec uniquement des trains régionaux, le Deutschlandticket est valable."
        m["Train strike in Germany"] = "Grève des trains en Allemagne"
    }

    /** Emergenze per paese, affollamento e accessibilita' all'estero. */
    private fun p13(m: HashMap<String, String>) {
        m.putIfAbsent("Lombardy: Trenord and FerrovieNord trains from Trenord's official timetable (Regione Lombardia Open Data), with the delay from Trenord's live service.", "Lombardie : trains Trenord et FerrovieNord d'après l'horaire officiel de Trenord (Open Data de la Région Lombardie), avec le retard du service live de Trenord.")
        m.putIfAbsent("Austria", "Autriche")
        m.putIfAbsent("France", "France")
        m.putIfAbsent("Germany, Austria, Switzerland and France: running trains placed on the line from the timetable and the realtime data the companies publish (Transitous); where there is no realtime the position follows the timetable.", "Allemagne, Autriche, Suisse et France : trains en marche placés sur la ligne d'après l'horaire et les données en temps réel publiées par les entreprises (Transitous) ; sans temps réel, la position suit l'horaire.")
        m.putIfAbsent("Finland (GPS)", "Finlande (GPS)")
        m.putIfAbsent("Norway (GPS)", "Norvège (GPS)")
        m.putIfAbsent("GPS position", "Position GPS")
        m.putIfAbsent("trains running or about to depart", "trains en circulation ou sur le point de partir")
        m.putIfAbsent("Location unavailable", "Position indisponible")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour. In Italy the position is estimated along the route from the timetable and the last stop (shortly after opening the dots move onto the line); elsewhere it stays around the hub: not GPS. It is a sample, not the whole network. Finland and Norway show the real GPS position (Digitraffic, Entur). Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "Chaque point est un train au départ d'un nœud dans l'heure qui vient. En Italie la position est estimée le long du trajet d'après l'horaire et le dernier arrêt (peu après l'ouverture les points se placent sur la ligne) ; ailleurs elle reste autour du nœud : pas de GPS. C'est un échantillon, pas tout le réseau. La Finlande et la Norvège affichent la vraie position GPS (Digitraffic, Entur). Sources : ViaggiaTreno, CFF (transport.opendata.ch), Transitous. Voies : © contributeurs OpenStreetMap, style CC-BY-SA 2.0 OpenRailwayMap.")
        m.putIfAbsent("Colored dots by delay, zoom and «Near me»", "Points colorés selon le retard, zoom et «Près de moi»")
        m.putIfAbsent("Alerts for my trip", "Alertes pour mon trajet")
        m.putIfAbsent("Minutes from home to the departure station", "Minutes de chez vous à la gare de départ")
        m.putIfAbsent("«Leave home» before the outbound train, «Last useful train» in the evening on the return and «Connection at risk» when a delay endangers a change. The departure is the station near home.", "«Partez de chez vous» avant le train aller, «Dernier train utile» le soir au retour et «Correspondance menacée» quand un retard met en danger un changement. Le départ est la gare proche de chez vous.")
        m.putIfAbsent("Leave home", "Partez de chez vous")
        m.putIfAbsent("Leave home by", "Partez de chez vous avant")
        m.putIfAbsent("for the train at", "pour le train de")
        m.putIfAbsent("Last useful train", "Dernier train utile")
        m.putIfAbsent("Last useful train to", "Dernier train utile vers")
        m.putIfAbsent("departs at", "part à")
        m.putIfAbsent("Connection at risk at", "Correspondance menacée à")
        m.putIfAbsent("expected arrival", "arrivée prévue")
        m.putIfAbsent("departure", "départ")
        m.putIfAbsent("Your history on this train", "Votre historique sur ce train")
        m.putIfAbsent("Average delay", "Retard moyen")
        m.putIfAbsent("On time (within 5 min)", "À l'heure (moins de 5 min)")
        m.putIfAbsent("Worst", "Pire")
        m.putIfAbsent("Days recorded", "Jours enregistrés")
        m.putIfAbsent("Data stays on your phone only.", "Données uniquement sur votre téléphone.")
        m.putIfAbsent("Most punctual among the next trains", "Le plus ponctuel parmi les prochains trains")
        m.putIfAbsent("runs observed", "circulations observées")
        m.putIfAbsent("TrovaTreno data from last month; they do not guarantee today's delay.", "Données TrovaTreno du dernier mois ; elles ne garantissent pas le retard d'aujourd'hui.")
        m.putIfAbsent("RFI notice on your route", "Avis RFI sur votre trajet")
        m.putIfAbsent("Notices on your routes", "Avis sur vos trajets")
        m.putIfAbsent("Until", "Jusqu'au")
        m.putIfAbsent("Timetable notice", "Avis sur l'horaire")
        m.putIfAbsent("From", "Du")
        m.putIfAbsent("to", "au")
        m.putIfAbsent("arrival at destination with", "arrivée à destination avec")
        m.putIfAbsent("minutes", "minutes")
        m.putIfAbsent("Tap for the source", "Touchez pour la source")
        m.putIfAbsent("Service interruption between Rho and Parabiago", "Interruption de la circulation entre Rho et Parabiago")
        m.putIfAbsent("Timetable remodulation 126.1: staff shifts remain unchanged.", "Modulation d'horaire 126.1 : les roulements du personnel restent inchangés.")
        m.putIfAbsent("From the departures of the next hours. High-speed, Intercity and Trenitalia regional trains have no line in the official timetables: they are shown by category and route.", "D'après les départs des prochaines heures. Les trains à grande vitesse, Intercity et régionaux Trenitalia n'ont pas de ligne dans les horaires officiels : ils sont indiqués par catégorie et trajet.")
        m.putIfAbsent("Trenord network / Lombardy", "Réseau Trenord / Lombardie")
        m.putIfAbsent("Other network or region", "Autre réseau ou région")
        m.putIfAbsent("Over 60 with CartaFreccia: FrecciaSENIOR offer on Frecce trains (from €29). Discounts and conditions detailed on the official page.", "Plus de 60 ans avec CartaFreccia : offre FrecciaSENIOR sur les trains Frecce (dès 29 €). Réductions et conditions détaillées sur la page officielle.")
        m.putIfAbsent("From age 65, single tickets are 20% off the Lombardy Regional Single Fare; in the STIBM area 25% off ordinary monthly and annual passes (to be loaded on the Io Viaggio card, €10).", "Dès 65 ans, billets simples à -20 % sur le tarif régional unique de Lombardie ; dans la zone STIBM -25 % sur les abonnements mensuels et annuels ordinaires (à charger sur la carte Io Viaggio, 10 €).")
        m.putIfAbsent("Over 60: Italo Senior, 40% to 60% off the Flex fare, in Smart and Prima Business; non-refundable, changeable up to 72 hours before departure.", "Plus de 60 ans : Italo Senior, de 40 % à 60 % de réduction sur le tarif Flex, en Smart et Prima Business ; non remboursable, modifiable jusqu'à 72 heures avant le départ.")
        m.putIfAbsent("Reduced General Abonnement (GA) for women from their 64th birthday (from 65 starting in 2028) and for men from 65.", "Abonnement général (AG) réduit pour les femmes dès leur 64e anniversaire (dès 65 ans à partir de 2028) et pour les hommes dès 65 ans.")
        m.putIfAbsent("Senior BahnCard from age 65; the BahnCard 50 (ages 27 to 64) gives 50% off the Flexpreis and 25% off long-distance Sparpreis fares.", "BahnCard Senior dès 65 ans ; la BahnCard 50 (de 27 à 64 ans) donne 50 % sur le Flexpreis et 25 % sur les Sparpreis longue distance.")
        m.putIfAbsent("From age 65, men and women: Vorteilscard Senior at €31 (valid 1 year).", "Dès 65 ans, hommes et femmes : Vorteilscard Senior à 31 € (valable 1 an).")
        m.putIfAbsent("From age 60: Carte Avantage Senior at €49 (confirm the price when buying): 30% off trips in 2nd and 1st class, 60% for up to 3 accompanying children aged 4-11; TER discounts vary by region.", "Dès 60 ans : Carte Avantage Senior à 49 € (confirme le prix à l'achat) : 30 % sur les voyages en 2de et 1re classe, 60 % pour jusqu'à 3 enfants de 4 à 11 ans qui t'accompagnent ; réductions TER variables selon la région.")
        m.putIfAbsent("The prices shown are the total for all passengers.", "Les prix affichés sont le total pour tous les passagers.")
        m.putIfAbsent("Age discounts vary by country and company: here kids are 4 to 14, but other companies use other ages. Family discounts: check when buying.", "Les réductions selon l'âge varient selon le pays et la compagnie : ici les enfants ont de 4 à 14 ans, mais d'autres compagnies utilisent d'autres âges. Réductions famille : à vérifier à l'achat.")
        m.putIfAbsent("Age rules for each company", "Règles d'âge de chaque compagnie")
        m.putIfAbsent("Age rules: companies and countries", "Règles d'âge : compagnies et pays")
        m.putIfAbsent("Age reductions depend on the country, company, train type and fare. Summary from the official sites (3/11/2026): they may change, always check the source before buying.", "Les réductions d'âge dépendent du pays, de la compagnie, du type de train et du tarif. Synthèse des sites officiels (3/11/2026) : elles peuvent changer, vérifie toujours la source avant d'acheter.")
        m.putIfAbsent("National trains: under 4 free without a seat; ages 4 to 14 (until the 15th birthday) 50% off the Base fare.", "Trains nationaux : gratuit avant 4 ans sans place ; de 4 à 14 ans (jusqu'au 15e anniversaire) 50 % de réduction sur le tarif Base.")
        m.putIfAbsent("Regional trains: under 4 free (with an adult, without a seat); ages 4 to under 12 get 50% off. Some regions have their own rules (Lombardy, Campania, Abruzzo, Sardinia, Apulia, Trento, Bolzano).", "Trains régionaux : gratuit avant 4 ans (avec un adulte, sans place) ; de 4 à moins de 12 ans 50 % de réduction. Certaines régions ont leurs propres règles (Lombardie, Campanie, Abruzzes, Sardaigne, Pouilles, Trente, Bolzano).")
        m.putIfAbsent("International trains (EuroCity, EuroNight): free up to age 5 without a seat; ages 6 to 14 get the «CHILD» offer (about 50%), varies by service.", "Trains internationaux (EuroCity, EuroNight) : gratuit jusqu'à 5 ans sans place ; de 6 à 14 ans offre «CHILD» (environ 50 %), variable selon le service.")
        m.putIfAbsent("Up to age 3 free on the whole fleet, without taking a seat; ages 4 to under 14 get 50% off the Regional Single Fare; in the STIBM area under-14s travel free (with a document proving their age).", "Jusqu'à 3 ans gratuit sur toute la flotte, sans occuper de place ; de 4 à moins de 14 ans 50 % de réduction sur le tarif régional unique ; dans la zone STIBM les moins de 14 ans voyagent gratuitement (avec un document prouvant l'âge).")
        m.putIfAbsent("Under 3 free, without an assigned seat and held by an adult (with more than one child per adult a paid seat is required). Italo Family offer for 2–4 people: details on the site.", "Moins de 3 ans gratuit, sans place attribuée et dans les bras d'un adulte (avec plus d'un enfant par adulte, une place payante est obligatoire). Offre Italo Famille pour 2 à 4 personnes : détails sur le site.")
        m.putIfAbsent("Under 6 free; ages 6 to under 16 pay half price (or the minimum fare), or travel free with a parent holding a valid ticket if you have the Junior Card. Under 25: Youth Half-Fare.", "Moins de 6 ans gratuit ; de 6 à moins de 16 ans demi-tarif (ou prix minimum), ou gratuit avec un parent muni d'un billet valable si tu as la Carte Junior. Moins de 25 ans : Demi-tarif jeunes.")
        m.putIfAbsent("Under 6 free; ages 6 to 14 travel free on long-distance trains when accompanied by an adult or a sibling aged 15 or over. Regional trains and discounted tickets may have different rules.", "Moins de 6 ans gratuit ; de 6 à 14 ans gratuit sur les trains longue distance accompagnés d'un adulte ou d'un frère ou d'une sœur de 15 ans ou plus. Les trains régionaux et les billets à prix réduit peuvent avoir d'autres règles.")
        m.putIfAbsent("Under 6 free without a ticket, with an adult; ages 6 to 14 (until the day before the 15th birthday) free with the Vorteilscard Family (€21, up to 4 children), only on ÖBB trains in Austria; from 15 adult fare.", "Moins de 6 ans gratuit sans billet, avec un adulte ; de 6 à 14 ans (jusqu'à la veille du 15e anniversaire) gratuit avec la Vorteilscard Family (21 €, jusqu'à 4 enfants), uniquement sur les trains ÖBB en Autriche ; dès 15 ans tarif adulte.")
        m.putIfAbsent("Under 4 free on the lap (TGV INOUI, TER, Intercités), one child per traveller; own seat with the Forfait Bambin at €9. Ages 4 to 11: 60% off for those accompanying a Carte Avantage Adulte holder. OUIGO has its own fares.", "Moins de 4 ans gratuit sur les genoux (TGV INOUI, TER, Intercités), un seul enfant par voyageur ; place à part avec le Forfait Bambin à 9 €. De 4 à 11 ans : 60 % de réduction pour ceux qui accompagnent un titulaire de la Carte Avantage Adulte. OUIGO a ses propres tarifs.")
        m.putIfAbsent("Plan B", "Plan B")
        m.putIfAbsent("Missed the train or the connection? Find alternatives from where you are now.", "Train ou correspondance manqués ? Trouve des alternatives depuis l'endroit où tu es.")
        m.putIfAbsent("Where you are now", "Où tu es maintenant")
        m.putIfAbsent("Another station…", "Une autre gare…")
        m.putIfAbsent("Alternatives to", "Alternatives vers")
        m.putIfAbsent("Looking for alternatives…", "Je cherche des alternatives…")
        m.putIfAbsent("How Binario works", "Comment fonctionne Binario")
        m.putIfAbsent("Basic or Full", "Basique ou Complet")
        m.putIfAbsent("On the Search screen choose how many features to see. You can change it any time: your choice is saved.", "Sur l'écran Recherche, choisissez combien de fonctions afficher. Vous pouvez changer à tout moment : le choix est enregistré.")
        m.putIfAbsent("Offline timetables", "Horaires hors ligne")
        m.putIfAbsent("In the results tap «Save these times to use them offline»: you will find them in Offline timetables even without a network.", "Dans les résultats, touchez «Enregistrer ces horaires pour les utiliser hors ligne» : vous les retrouvez dans Horaires hors ligne, même sans réseau.")
        m.putIfAbsent("Widgets", "Widgets")
        m.putIfAbsent("Long-press the home screen, choose Widgets and add Binario: departures and delays always in sight.", "Appuyez longuement sur l'écran d'accueil, choisissez Widgets et ajoutez Binario : départs et retards toujours sous les yeux.")
        m.putIfAbsent("Punctuality", "Ponctualité")
        m.putIfAbsent("Under each icon is the tab name: search a station or a train and see how many arrive on time.", "Sous chaque icône figure le nom de l'onglet : cherchez une gare ou un train et voyez combien arrivent à l'heure.")
        m.putIfAbsent("Got it", "Compris")
        m.putIfAbsent("less than a minute ago", "il y a moins d'une minute")
        m.putIfAbsent("%d min ago", "il y a %d min")
        m.putIfAbsent("%d h ago", "il y a %d h")
        m.putIfAbsent("%d days ago", "il y a %d jours")
        m.putIfAbsent("Timetables saved %s. They may have changed: connect to refresh them.", "Horaires enregistrés %s. Ils ont pu changer : connectez-vous pour les actualiser.")
        m.putIfAbsent("Last saved message: the Trenord page is not responding right now.", "Dernier message enregistré : la page Trenord ne répond pas pour le moment.")
        m.putIfAbsent("The downloaded file is not a valid APK. Try downloading it again.", "Le fichier téléchargé n'est pas un APK valide. Réessayez de le télécharger.")
        m.putIfAbsent("The downloaded file is not Binario.", "Le fichier téléchargé n'est pas Binario.")
        m.putIfAbsent("This version is already installed or is older.", "Cette version est déjà installée ou plus ancienne.")
        m.putIfAbsent("Your Binario was installed with a different signature from the updates (for example a test build or another source): Android cannot update it and would show “App not installed”. Uninstall Binario and install the latest version from the download page: you will lose favourites and settings.", "Votre Binario a été installé avec une signature différente de celle des mises à jour (par exemple une version de test ou une autre source) : Android ne peut pas le mettre à jour et afficherait « Application non installée ». Désinstallez Binario et installez la dernière version depuis la page de téléchargement : vous perdrez favoris et réglages.")
        m.putIfAbsent("Open the download page", "Ouvrir la page de téléchargement")
        m.putIfAbsent("Show the message", "Afficher le message")
        m.putIfAbsent("1 source has problems: related features use backups or the latest saved data.", "1 source a des problèmes : les fonctions liées utilisent les secours ou les dernières données enregistrées.")
        m.putIfAbsent("%d sources have problems: related features use backups or the latest saved data.", "%d sources ont des problèmes : les fonctions liées utilisent les secours ou les dernières données enregistrées.")
        m.putIfAbsent("All sources respond, but some are busy (too many requests): the app uses backups.", "Toutes les sources répondent, mais certaines sont saturées (trop de requêtes) : l'app utilise les secours.")
        m.putIfAbsent("Latest message from Trenord", "Dernier message de Trenord")
        m.putIfAbsent("Reading the message from the Trenord site…", "Lecture du message sur le site de Trenord…")
        m.putIfAbsent("Message not available right now.", "Message indisponible pour le moment.")
        m.putIfAbsent("Line status", "État de la ligne")
        m.putIfAbsent("Latest notice", "Dernier avis")
        m.putIfAbsent("Show all", "Tout afficher")
        m.putIfAbsent("Show less", "Afficher moins")
        m.putIfAbsent("Open the line page", "Ouvrir la page de la ligne")
        m.putIfAbsent("Save these times to use them offline", "Enregistrer ces horaires pour les utiliser hors ligne")
        m.putIfAbsent("Saved: find it in Offline timetables", "Enregistré : à retrouver dans Horaires hors ligne")
        m.putIfAbsent("No saved timetables", "Aucun horaire enregistré")
        m.putIfAbsent("To have timetables without a network: search for a trip, then in the results tap «Save these times to use them offline». You will find it here.", "Pour avoir les horaires sans réseau : cherchez un trajet, puis dans les résultats touchez «Enregistrer ces horaires pour les utiliser hors ligne». Vous le retrouverez ici.")
        m.putIfAbsent("Tap a search to reopen it, even without a network.", "Touchez une recherche pour la rouvrir, même sans réseau.")
        m.putIfAbsent("Search for a trip", "Chercher un trajet")
        m.putIfAbsent("Busy: too many requests from your address (429). The app tries the other servers and then Postpass; retry in 15 seconds.", "Saturé : trop de requêtes depuis votre adresse (429). L'app essaie les autres serveurs puis Postpass ; réessayez dans 15 secondes.")
        m.putIfAbsent("Share of trains on time for each station in the chosen month. Type a name to search, then tap it to open.", "Part des trains à l'heure pour chaque gare dans le mois choisi. Tapez un nom pour chercher, puis touchez-le pour l'ouvrir.")
        m.putIfAbsent("Share of runs on time for each train in the chosen month. Search by number or destination, then tap it to open.", "Part des circulations à l'heure pour chaque train dans le mois choisi. Cherchez par numéro ou destination, puis touchez pour ouvrir.")
        m.putIfAbsent("Search station", "Chercher une gare")
        m.putIfAbsent("Train number or destination", "Numéro de train ou destination")
        m.putIfAbsent("Clear", "Effacer")
        m.putIfAbsent("Least punctual", "Les moins ponctuels")
        m.putIfAbsent("Most punctual", "Les plus ponctuels")
        m.putIfAbsent("Milan Passante", "Passante de Milan")
        m.putIfAbsent("RFI network", "Réseau RFI")
        m.putIfAbsent("FerrovieNord network", "Réseau FerrovieNord")
        m.putIfAbsent("%d results", "%d résultats")
        m.putIfAbsent("%d results for «%s»", "%d résultats pour «%s»")
        m.putIfAbsent("No results", "Aucun résultat")
        m.putIfAbsent("No alternatives found in the next hours.", "Aucune alternative trouvée dans les prochaines heures.")
        m.putIfAbsent("direct", "direct")
        m.putIfAbsent("changes", "changements")
        m.putIfAbsent("Tap a train to open it. Times are scheduled: check delays and platforms on its page.", "Touche un train pour l'ouvrir. Les horaires sont théoriques : vérifie retards et voies sur sa fiche.")
        m.putIfAbsent("Trains in Austria", "Trains en Autriche")
        m.putIfAbsent("Trains in France", "Trains en France")
        m.putIfAbsent("Trains in Italy", "Trains en Italie")
        m.putIfAbsent("Features", "Fonctions")
        m.putIfAbsent("Basic", "Essentielles")
        m.putIfAbsent("Full", "Complètes")
        m.putIfAbsent("Estimate: scheduled time plus the known delay.", "Estimation : horaire prévu plus le retard connu.")
        m.putIfAbsent("This train usually arrives with", "Ce train arrive en général avec")
        m.putIfAbsent("Updated just now", "Mis à jour à l'instant")
        m.putIfAbsent("Data from %d min ago", "Données d'il y a %d min")
        m.putIfAbsent("tap ↻ to refresh", "touchez ↻ pour actualiser")
        m.putIfAbsent("Cancelled today", "Supprimé aujourd'hui")
        m.putIfAbsent("Extra train today", "Train supplémentaire aujourd'hui")
        m.putIfAbsent("Replaced by train", "Remplacé par le train")
        m.putIfAbsent("Runs in place of train", "Circule à la place du train")
        m.putIfAbsent("Other times", "Autres fois")
        m.putIfAbsent("replaced by", "remplacé par")
        m.putIfAbsent("in place of", "à la place du")
        m.putIfAbsent("network", "réseau")
        m.putIfAbsent("Trenord · TILO", "Trenord · TILO")
        m.putIfAbsent("All networks", "Tous les réseaux")
        m.putIfAbsent("Switzerland · SBB", "Suisse · CFF")
        m.putIfAbsent("All", "Tous")
        m.putIfAbsent("FerrovieNord", "FerrovieNord")
        m.putIfAbsent("RFI", "RFI")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Sources: ViaggiaTreno (Italy, Trenord, FerrovieNord) and transport.opendata.ch (TILO, Switzerland). Trenord and TILO are a single service.", "Échantillon des tableaux de départs des principaux nœuds (prochaines heures) : pas tout le réseau. Sources : ViaggiaTreno (Italie, Trenord, FerrovieNord) et transport.opendata.ch (TILO, Suisse). Trenord et TILO forment un seul service.")
        m.putIfAbsent("Italia · RFI", "Italie · RFI")
        m.putIfAbsent("Trenord · rete RFI", "Trenord · réseau RFI")
        m.putIfAbsent("Trenord · rete FerrovieNord", "Trenord · réseau FerrovieNord")
        m.putIfAbsent("TILO", "TILO")
        m.putIfAbsent("Svizzera · FFS/SBB", "Suisse · CFF")
        m.putIfAbsent("Nessun ritardo di 5 minuti o più nei nodi controllati.", "Aucun retard de 5 minutes ou plus aux gares contrôlées.")
        m.putIfAbsent("Campione dai tabelloni dei principali nodi (partenze delle prossime ore): non è l'elenco di tutta la rete. Fonti: ViaggiaTreno (Italia, Trenord, FerrovieNord) e transport.opendata.ch (TILO, Svizzera).", "Échantillon des tableaux de départs des principaux nœuds (prochaines heures) : pas tout le réseau. Sources : ViaggiaTreno (Italie, Trenord, FerrovieNord) et transport.opendata.ch (TILO, Suisse).")
        m.putIfAbsent("Trains in Switzerland", "Trains en Suisse")
        m.putIfAbsent("Timetables, delays and platforms of Italian trains (Trenitalia, Italo, Trenord, FerrovieNord and regional railways).", "Horaires, retards et voies des trains italiens (Trenitalia, Italo, Trenord, FerrovieNord et chemins de fer régionaux).")
        m.putIfAbsent("Timetables, delays and platforms of Swiss trains (SBB, TILO and regional railways), with crowding and station services where SBB publishes them.", "Horaires, retards et voies des trains suisses (CFF, TILO et chemins de fer régionaux), avec affluence et services en gare là où les CFF les publient.")
        m.putIfAbsent("Search a station by name, a train by number, or a route. Journey search, departure board, train page and “Follow” work.", "Cherche une gare par son nom, un train par son numéro ou un trajet. La recherche de trajets, le tableau des départs, la fiche du train et « Suivre » fonctionnent.")
        m.putIfAbsent("Data: ViaggiaTreno, Trenord and Italo. Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "Données : ViaggiaTreno, Trenord et Italo. Le temps réel dépend de ce que publient les entreprises et peut manquer pour certains trains. Les tableaux et les annonces font toujours foi.")
        m.putIfAbsent("Data: SBB (open data). Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "Données : CFF (données ouvertes). Le temps réel dépend de ce que publient les entreprises et peut manquer pour certains trains. Les tableaux et les annonces font toujours foi.")
        m.putIfAbsent("Timetables, delays and platforms of Austrian trains (ÖBB, Westbahn and regional operators), when real-time data is published.", "Horaires, retards et voies des trains autrichiens (ÖBB, Westbahn et compagnies régionales), quand les données en temps réel sont publiées.")
        m.putIfAbsent("Timetables, delays and platforms of French trains (TGV, TER, Intercités, RER), when real-time data is published.", "Horaires, retards et voies des trains français (TGV, TER, Intercités, RER), quand les données en temps réel sont publiées.")
        m.putIfAbsent("Search the station with its Italian name too: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Trip search (also with Italy), station board, train page and «Follow» all work.", "Cherche la gare aussi avec le nom italien : «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». La recherche de trajets (aussi avec l'Italie), le tableau, la fiche du train et «Suivre» fonctionnent.")
        m.putIfAbsent("Data: official timetables via Transitous; real time depends on what operators publish and may be missing for some trips. Prices are not public: tickets on the official sites. Station boards and announcements always prevail.", "Données : horaires officiels via Transitous ; le temps réel dépend de ce que publient les compagnies et peut manquer pour certains trajets. Les prix ne sont pas publics : billets sur les sites officiels. Les tableaux et annonces font toujours foi.")
        m.putIfAbsent("Tickets and official information", "Billets et informations officielles")
        m.putIfAbsent("Prices for these trains are not public: the lowest-price calendar is on the operators' sites (ÖBB, SNCF) or on bahn.de.", "Les prix de ces trains ne sont pas publics : le calendrier des prix les plus bas se trouve sur les sites des compagnies (ÖBB, SNCF) ou sur bahn.de.")
        m.putIfAbsent("Austria and France: official timetables with real-time delays and platforms when published (Transitous).", "Autriche et France : horaires officiels avec retards et voies en temps réel quand ils sont publiés (Transitous).")
        m.putIfAbsent("Prices and tickets on the operators' sites (ÖBB, SNCF) or on bahn.de", "Prix et billets sur les sites des compagnies (ÖBB, SNCF) ou sur bahn.de")
        m.putIfAbsent("Sharing? When the time is right…", "Partage ? Le moment venu…")
        m.putIfAbsent("Unofficial app: not affiliated with, sponsored or endorsed by Trenitalia, RFI, Italo, Trenord or any other transport company. Data comes from public sources.", "Appli non officielle : non affiliée, ni sponsorisée ni approuvée par Trenitalia, RFI, Italo, Trenord ou toute autre société de transport. Les données proviennent de sources publiques.")
        m.putIfAbsent("Tap again for the board and services", "Touchez à nouveau pour le tableau et les services")
        m.putIfAbsent("Services near this station", "Services près de cette gare")
        m.putIfAbsent("Board", "Tableau")
        m.putIfAbsent("Platform ", "Voie ")
        m.putIfAbsent("Delay now: ", "Retard actuel : ")
        m.putIfAbsent("Scheduled times: the delay may change. Created with Binario.", "Horaires prévus : le retard peut changer. Créé avec Binario.")
        m.putIfAbsent("Tracks", "Voies")
        m.putIfAbsent("Ahead", "Devant")
        m.putIfAbsent("Behind", "Derrière")
        m.putIfAbsent("Trains ahead and behind yours", "Trains devant et derrière le vôtre")
        m.putIfAbsent("Compared at the next stop: ", "Comparaison au prochain arrêt : ")
        m.putIfAbsent("Your train", "Votre train")
        m.putIfAbsent("The train ahead is running late and could slow yours down.", "Le train qui vous précède est en retard et pourrait ralentir le vôtre.")
        m.putIfAbsent("Trains in the same direction passing that stop in the 45 minutes before and after yours. Source: ViaggiaTreno.", "Trains dans la même direction qui passent à cet arrêt dans les 45 minutes avant et après le vôtre. Source : ViaggiaTreno.")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "Chaque point est un train qui part d'un nœud dans l'heure qui vient, placé autour du nœud : ce n'est pas sa position GPS. C'est un échantillon, pas tout le réseau. Sources : ViaggiaTreno, CFF (transport.opendata.ch), Transitous. Voies : © contributeurs OpenStreetMap, style CC-BY-SA 2.0 OpenRailwayMap.")
        m.putIfAbsent("Watch and smartwatch", "Montre et smartwatch")
        m.putIfAbsent("Followed train status on the watch too", "État du train suivi aussi sur la montre")
        m.putIfAbsent("Sends a normal (not pinned) notification when the delay, platform or next stop changes, so Mi Band, Wear OS and other watches show it.", "Envoie une notification normale (non épinglée) quand le retard, la voie ou le prochain arrêt change, pour que Mi Band, Wear OS et les autres montres l'affichent.")
        m.putIfAbsent("Send a test notification", "Envoyer une notification de test")
        m.putIfAbsent("Test: if you see this on your watch, all is well.", "Test : si vous voyez ceci sur votre montre, tout va bien.")
        m.putIfAbsent("Watch status", "État sur la montre")
        m.putIfAbsent("Binario does not talk to the watch directly: notifications (alerts, strikes, platform changes, delays, reminders) reach your wrist through the watch's own app. Mi Band: in Mi Fitness or Zepp Life open your device › Notifications and reminders › App alerts and turn on Binario. Wear OS: they arrive on their own (check in the Wear OS app › Notifications). In both cases set Binario to «no restrictions» in battery settings. The pinned train notification (with «Stop following») is usually not forwarded: that is why the separate alerts above exist.", "Binario ne parle pas directement à la montre : les notifications (alertes, grèves, changements de voie, retards, rappels) arrivent au poignet via l'appli de la montre. Mi Band : dans Mi Fitness ou Zepp Life, ouvrez votre appareil › Notifications et rappels › Alertes des applis et activez Binario. Wear OS : elles arrivent toutes seules (vérifiez dans l'appli Wear OS › Notifications). Dans les deux cas, réglez Binario sur «aucune restriction» dans la batterie. La notification épinglée du train (avec «Ne plus suivre») n'est généralement pas transmise : c'est pourquoi les alertes séparées ci-dessus existent.")
        m.putIfAbsent("Cancelled", "Supprimé")
        m.putIfAbsent("Next: ", "Prochain : ")
        m.putIfAbsent("Pl. ", "Voie ")
        m.putIfAbsent("Delays right now: Italy, Switzerland, Germany", "Retards en ce moment : Italie, Suisse, Allemagne")
        m.putIfAbsent("Not enough data right now", "Pas assez de données pour le moment")
        m.putIfAbsent("Trains by delay band", "Trains par tranche de retard")
        m.putIfAbsent("Average delay", "Retard moyen")
        m.putIfAbsent("On time (up to 5 min)", "À l'heure (jusqu'à 5 min)")
        m.putIfAbsent("Trains with a delay reading", "Trains avec retard relevé")
        m.putIfAbsent("Hubs with the highest average delay", "Nœuds avec le retard moyen le plus élevé")
        m.putIfAbsent("Sample of trains departing from the big hubs in the next hour, not the whole network. For Italian trains the delay is known only after departure from the origin (ViaggiaTreno): so only trains with a delay reading are counted, and the comparison with Switzerland and Germany, which also give the predicted delay, is only indicative. For monthly statistics and the comparison between companies see below.", "Échantillon des trains qui partent des grands nœuds dans l'heure qui vient, pas tout le réseau. Pour les trains italiens, le retard n'est connu qu'après le départ de l'origine (ViaggiaTreno) : on ne compte donc que les trains avec un retard relevé, et la comparaison avec la Suisse et l'Allemagne, qui donnent aussi le retard prévu, n'est qu'indicative. Pour les statistiques mensuelles et la comparaison entre compagnies, voir plus bas.")
        m.putIfAbsent("Train map", "Carte des trains")
        m.putIfAbsent("Delay", "Retard")
        m.putIfAbsent("Send by email", "Envoyer par e-mail")
        m.putIfAbsent("Info and sources", "Infos et sources")
        m.putIfAbsent("Rainbow theme", "Thème arc-en-ciel")
        m.putIfAbsent("Each tile has a rainbow colour", "Chaque tuile a une couleur de l'arc-en-ciel")
        m.putIfAbsent("Custom colours", "Couleurs personnalisées")
        m.putIfAbsent("Choose your own main colour", "Choisissez la couleur principale")
        m.putIfAbsent("Main colour", "Couleur principale")
        m.putIfAbsent("Colour code (hex)", "Code couleur (hexadécimal)")
        m.putIfAbsent("Dark background", "Fond sombre")
        m.putIfAbsent("Apply", "Appliquer")
        m.putIfAbsent("Text size", "Taille du texte")
        m.putIfAbsent("Large", "Grand")
        m.putIfAbsent("Very large", "Très grand")
        m.putIfAbsent("Huge", "Énorme")
        m.putIfAbsent("Enlarges the text across the app; lines wrap instead of being cut off.", "Agrandit le texte dans toute l'appli ; les lignes passent à la ligne au lieu d'être coupées.")
        m.putIfAbsent("Weather at", "Météo à")
        m.putIfAbsent("Feels like", "Ressentie")
        m.putIfAbsent("Wind", "Vent")
        m.putIfAbsent("Arriving", "En approche")
        m.putIfAbsent("Departs in", "Départ dans")
        m.putIfAbsent("Last 30 days history", "Historique des 30 derniers jours")
        m.putIfAbsent("Cancelled", "Supprimés")
        m.putIfAbsent("Measured on arrival at", "Mesuré à l'arrivée à")
        m.putIfAbsent("runs operated", "courses effectuées")
        m.putIfAbsent("Data collected by Binario, unofficial.", "Données collectées par Binario, non officielles.")
        m.putIfAbsent("Delay ranking", "Classement des retards")
        m.putIfAbsent("By day", "Par jour")
        m.putIfAbsent("30 days", "30 jours")
        m.putIfAbsent("Sample from the main hubs: not the list of the whole network.", "Échantillon des principaux nœuds : pas tout le réseau.")
        m.putIfAbsent("Most delayed", "Plus en retard")
        m.putIfAbsent("Most punctual", "Plus ponctuels")
        m.putIfAbsent("runs", "courses")
        m.putIfAbsent("The history is still filling up.", "L'historique se remplit encore.")
        m.putIfAbsent("Binario collects delays every day: in a few days the ranking will be here.", "Binario collecte les retards chaque jour : dans quelques jours le classement sera ici.")
        m.putIfAbsent("Last 30 days, trains observed by Binario", "30 derniers jours, trains observés par Binario")
        m.putIfAbsent("Choose the style", "Choisir le style")
        m.putIfAbsent("The style changes colours, shapes and the layout of the Home, widgets included. You can change it whenever you like.", "Le style change les couleurs, les formes et la disposition de l'accueil, widgets compris. Tu peux le changer quand tu veux.")
        m.putIfAbsent("The usual look, green", "L'apparence habituelle, verte")
        m.putIfAbsent("Dark amber Solari board", "Tableau Solari sombre et ambre")
        m.putIfAbsent("Find a train", "Chercher un train")
        m.putIfAbsent("By number or line", "Par numéro ou ligne")
        m.putIfAbsent("Arrivals and departures", "Arrivées et départs")
        m.putIfAbsent("Around you", "Autour de toi")
        m.putIfAbsent("Train map", "Carte des trains")
        m.putIfAbsent("Where they are now", "Où ils sont maintenant")
        m.putIfAbsent("Who is most delayed", "Qui a le plus de retard")
        m.putIfAbsent("What changes", "Ce qui change")
        m.putIfAbsent("Alarms and reminders", "Réveils et rappels")
        m.putIfAbsent("Saved on the phone", "Enregistrés sur le téléphone")
        m.putIfAbsent("Statistics", "Statistiques")
        m.putIfAbsent("Refunds", "Remboursements")
        m.putIfAbsent("Passenger rights", "Droits du voyageur")
        m.putIfAbsent("Help", "Aide")
        m.putIfAbsent("Frequently asked questions", "Questions fréquentes")
        m.putIfAbsent("Clear", "Dégagé")
        m.putIfAbsent("Partly cloudy", "Peu nuageux")
        m.putIfAbsent("Overcast", "Couvert")
        m.putIfAbsent("Fog", "Brouillard")
        m.putIfAbsent("Drizzle", "Bruine")
        m.putIfAbsent("Rain", "Pluie")
        m.putIfAbsent("Snow", "Neige")
        m.putIfAbsent("Showers", "Averses")
        m.putIfAbsent("Thunderstorm", "Orage")
        m.putIfAbsent("Variable", "Variable")
        m.putIfAbsent("Light tiles", "Tuiles claires")
        m.putIfAbsent("White tiles on a light blue background, blue header", "Tuiles blanches sur fond bleu clair, en-tête bleu")
        m.putIfAbsent("Coloured tiles", "Tuiles colorées")
        m.putIfAbsent("Each function has its own pastel colour", "Chaque fonction a sa couleur pastel")
        m.putIfAbsent("Dark board", "Tableau sombre")
        m.putIfAbsent("Black and gold, fixed-width numbers", "Noir et or, chiffres à chasse fixe")
        m.putIfAbsent("Wide-tile list", "Liste de larges tuiles")
        m.putIfAbsent("Wide rows split into sections", "Lignes larges par sections")
        m.putIfAbsent("My train up front", "Mon train au premier plan")
        m.putIfAbsent("Your next train on top, with a countdown", "En haut, ton prochain train avec compte à rebours")
        m.putIfAbsent("Four big tiles and a list", "Quatre grandes tuiles et une liste")
        m.putIfAbsent("Four big tiles, then rows for the rest", "Quatre grandes tuiles, puis des lignes pour le reste")
        m.putIfAbsent("Lines and codes", "Lignes et sigles")
        m.putIfAbsent("Rows with a coloured code on the left, like on the lines", "Lignes avec le sigle coloré à gauche, comme sur les lignes")
        m.putIfAbsent("High contrast", "Contraste élevé")
        m.putIfAbsent("Black and yellow, big tiles and thick borders", "Noir et jaune, grandes tuiles et bordures épaisses")
        m.putIfAbsent("Three columns by section", "Trois colonnes par sections")
        m.putIfAbsent("Compact icons in three columns, with sections", "Icônes compactes sur trois colonnes, avec sections")
        m.putIfAbsent("Today's dashboard", "Tableau de bord du jour")
        m.putIfAbsent("Last 30 days, current delays and shortcuts", "30 derniers jours, retards du moment et raccourcis")
        m.putIfAbsent("Fixes, service status, privacy", "Corrections, état des services, confidentialité")
        m.putIfAbsent("Weather at the station (Open-Meteo)", "Météo en gare (Open-Meteo)")
        m.putIfAbsent("Real time", "En temps réel")
        m.putIfAbsent("Mine", "Les miens")
        m.putIfAbsent("Prefer to write by email?", "Vous préférez écrire par e-mail ?")
        m.putIfAbsent("Conditions and fares by company", "Conditions et tarifs par entreprise")
        m.putIfAbsent("Fares and tickets", "Tarifs et billets")
        m.putIfAbsent("Rights and refunds", "Droits et remboursements")
        m.putIfAbsent("Source: official website of", "Source : site officiel de")
        m.putIfAbsent("links checked on", "liens vérifiés le")
        m.putIfAbsent("Conditions and fares change: the app opens each company's official pages without copying their prices. The company's own text prevails.", "Les conditions et les tarifs changent : l'appli ouvre les pages officielles de chaque entreprise sans copier leurs prix. Le texte de l'entreprise fait foi.")
        m.putIfAbsent("Trains departing soon from the main hubs of Italy, Switzerland and Germany, coloured by delay", "Trains qui partent bientôt des principaux nœuds d'Italie, de Suisse et d'Allemagne, colorés selon le retard")
        m.putIfAbsent("On time", "À l'heure")
        m.putIfAbsent("1–5 min late", "1–5 min de retard")
        m.putIfAbsent("6–14 min late", "6–14 min de retard")
        m.putIfAbsent("15+ min late", "15+ min de retard")
        m.putIfAbsent("Delay n.a.", "Retard n.d.")
        m.putIfAbsent("Trains shown", "Trains affichés")
        m.putIfAbsent("Open train", "Ouvrir le train")
        m.putIfAbsent("Refresh", "Actualiser")
        m.putIfAbsent("Italy", "Italie")
        m.putIfAbsent("Switzerland", "Suisse")
        m.putIfAbsent("Germany", "Allemagne")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous.", "Chaque point est un train qui part d'un nœud dans l'heure qui vient, placé autour du nœud : ce n'est pas sa position GPS. C'est un échantillon, pas tout le réseau. Sources : ViaggiaTreno, CFF (transport.opendata.ch), Transitous.")
        m.putIfAbsent("App style", "Style de l'appli")
        m.putIfAbsent("Traditional", "Traditionnel")
        m.putIfAbsent("Vintage (split-flap board)", "Vintage (tableau à palettes)")
        m.putIfAbsent("Refreshing the board…", "Actualisation du tableau…")
        m.putIfAbsent("TAP THE TITLE TO CHOOSE", "TOUCHEZ LE TITRE POUR CHOISIR")
        m.putIfAbsent("NO DATA", "AUCUNE DONNÉE")
        m.putIfAbsent("Departure board style", "Style des tableaux de départs")
        m.putIfAbsent("Classic", "Classique")
        m.putIfAbsent("Vintage (split-flap)", "Vintage (à palettes)")
        m.putIfAbsent(". After the timetable change buses may be missing until Trenord publishes the new file.", ". Après le changement d'horaire, des bus peuvent manquer jusqu'à ce que Trenord publie le nouveau fichier.")
        m.putIfAbsent(": Transitous timetables are used for Trenord instead.", " : pour Trenord, les horaires de Transitous sont utilisés à la place.")
        m.putIfAbsent("Sources: official Trenord GTFS timetable from Lombardy Region open data (Transitous as a fallback); Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements.", "Sources : horaire GTFS officiel de Trenord issu des données ouvertes de la Région Lombardie (Transitous en secours) ; Trenitalia et CFF via Transitous (transitous.org) ; bus du tableau depuis ViaggiaTreno (RFI). Chaque course indique sa source. Les horaires sont théoriques : en cas de perturbation, suivez les annonces en gare.")
        m.putIfAbsent("The Trenord replacement-bus timetable is valid until", "L'horaire des bus de remplacement Trenord est valable jusqu'au")
        m.putIfAbsent("The Trenord timetable file (Lombardy Region) expired on", "Le fichier d'horaires Trenord (Région Lombardie) a expiré le")
        m.putIfAbsent("Lombardy Region open data · official Trenord timetable (GTFS)", "Données ouvertes de la Région Lombardie · horaire officiel Trenord (GTFS)")
        m.putIfAbsent("Which time is most punctual", "Quel horaire est le plus ponctuel")
        m.putIfAbsent("on time", "à l'heure")
        m.putIfAbsent("Each option counts as its least punctual train. Statistics of the latest month, not a forecast: strikes and works can change everything.", "Chaque solution compte avec son train le moins ponctuel. Statistiques du dernier mois, pas une prévision : grèves et travaux peuvent tout changer.")
        m.putIfAbsent("Text copied", "Texte copié")
        m.putIfAbsent("Copy the request text", "Copier le texte de la demande")
        m.putIfAbsent("Most delayed trains right now", "Trains les plus en retard en ce moment")
        m.putIfAbsent("No significant delays at the main hubs, or the service is not responding.", "Aucun retard notable dans les principaux nœuds, ou le service ne répond pas.")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Source: ViaggiaTreno.", "Échantillon tiré des tableaux de départs des principaux nœuds (prochaines heures) : ce n'est pas la liste de tout le réseau. Source : ViaggiaTreno.")
        m.putIfAbsent("Dual numbering", "Double numérotation")
        m.putIfAbsent("This service changes number when it passes from one network to another (RFI, FerrovieNord, SBB).", "Cette course change de numéro en passant d'un réseau à l'autre (RFI, FerrovieNord, CFF).")
        m.putIfAbsent("From the official Trenord timetables in force: the numbers can change with every timetable change.", "D'après les horaires officiels Trenord en vigueur : les numéros peuvent changer à chaque changement d'horaire.")
        m.putIfAbsent("After", "Après")
        m.putIfAbsent("the train becomes", "le train devient")
        m.putIfAbsent("Reported by ViaggiaTreno.", "Signalé par ViaggiaTreno.")
        m.putIfAbsent("Strike tomorrow", "Grève demain")
        m.putIfAbsent("Line", "Ligne")
        m.putIfAbsent("Line page", "Page de la ligne")
        m.putIfAbsent("Tap for the official line page: stops, timetables and notices.", "Touchez pour la page officielle de la ligne : arrêts, horaires et avis.")
        m.putIfAbsent("Lines through this station", "Lignes qui passent ici")
        m.putIfAbsent("From the departures of the next few hours. Frecce, Intercity and Trenitalia regional trains have no line in the official timetables.", "D'après les départs des prochaines heures. Les Frecce, Intercity et régionaux Trenitalia n'ont pas de ligne dans les horaires officiels.")
        m.putIfAbsent("Official website", "Site officiel")
        m["Automatic (mobile network)"] = "Automatique (réseau mobile)"
        m.putIfAbsent("Germany", "Allemagne")
        m.putIfAbsent("Italy", "Italie")
        m["Country for emergencies and defibrillators"] = "Pays pour les urgences et les défibrillateurs"
        m["Expected occupancy in DB Navigator"] = "Affluence prévue dans DB Navigator"
        m["Expected occupancy on sbb.ch"] = "Affluence prévue sur sbb.ch"
        m["SBB assistance for people with disabilities (Contact Center Handicap)"] = "Assistance CFF pour personnes handicapées (Contact Center Handicap)"
        m["No official data: DB publishes expected occupancy only in DB Navigator and on bahn.de. This is an estimate by time of day."] = "Pas de donnée officielle : la DB publie l'affluence prévue uniquement dans DB Navigator et sur bahn.de. Voici une estimation selon l'heure."
        m["German companies do not publish per-train services (wheelchair spaces, bikes) in open data: you can find them in DB Navigator or on bahn.de. "] = "Les compagnies allemandes ne publient pas en données ouvertes les services de chaque train (places fauteuil roulant, vélos) : vous les trouvez dans DB Navigator ou sur bahn.de. "
        m.putIfAbsent("Switzerland", "Suisse")
        m["The Rega (air rescue) app sends your location to the operations centre. Ambulance: 144."] = "L'appli de la Rega (sauvetage aérien) envoie votre position à la centrale. Ambulance : 144."
        m["The official emergency app of the German federal states: reach 112 and 110 also in writing, with your location."] = "L'appli d'urgence officielle des Länder allemands : joindre le 112 et le 110 aussi par écrit, avec votre position."
        m.putIfAbsent("Train cancelled", "Train supprimé")
        m.putIfAbsent("Train heavily delayed", "Train très en retard")
        m.putIfAbsent("No connection", "Pas de connexion")
        m.putIfAbsent("Last reading: %d min ago", "Dernière lecture : il y a %d min")
        m.putIfAbsent("It updates as soon as the network is back.", "Mise à jour dès le retour du réseau.")
    }

    private fun p14(m: HashMap<String, String>) {
        m.putIfAbsent("No connection. Check your Wi-Fi or mobile data.", "Pas de connexion. Vérifie le Wi-Fi ou les données mobiles.")
        m.putIfAbsent("The service is not responding. Try again shortly.", "Le service ne répond pas. Réessaie dans un instant.")
        m.putIfAbsent("Too many requests. Wait a minute and try again.", "Trop de requêtes. Attends une minute et réessaie.")
        m.putIfAbsent("Not found: the service does not have this data.", "Introuvable : le service n'a pas cette donnée.")
        m.putIfAbsent("The service has a problem. Try again later.", "Le service rencontre un problème. Réessaie plus tard.")
        m.putIfAbsent("Something went wrong. Try again.", "Quelque chose n'a pas fonctionné. Réessaie.")
        m.putIfAbsent("You are offline. Showing the latest available data.", "Tu es hors ligne. Affichage des dernières données disponibles.")
        m.putIfAbsent("The service is not responding: some data is %d min old.", "Le service ne répond pas : certaines données datent d'il y a %d min.")
        m.putIfAbsent("With the app's latest network errors (service addresses only, no personal data).", "Avec les dernières erreurs réseau de l'appli (adresses des services uniquement, aucune donnée personnelle).")
        m.putIfAbsent("Try changing the time or the station.", "Essaie de changer l'heure ou la gare.")
        m.putIfAbsent("Looking for alternatives…", "Recherche d'alternatives…")
        m.putIfAbsent("Advanced", "Avancées")
        m.putIfAbsent("Just the essentials: timetable search, strikes and your shortcuts.", "L'essentiel : recherche d'horaires, grèves et vos raccourcis.")
        m.putIfAbsent("Also: passengers, train type, prices, My trips, offline timetables, lines and fares.", "En plus : voyageurs, type de trains, prix, Mes voyages, horaires hors ligne, lignes et tarifs.")
        m.putIfAbsent("All features: also maps, other countries, emergency, assistant and style tiles.", "Toutes les fonctions : aussi cartes, étranger, urgence, assistant et tuiles du style.")
        m.putIfAbsent("Show all features", "Afficher toutes les fonctions")
        m.putIfAbsent("Accessible", "Accessible")
        m.putIfAbsent("Accessible stations", "Accessibles")
        m.putIfAbsent("Other services", "Autres services")
        m.putIfAbsent("Open the notice document (PDF)", "Ouvrir le document de l'avis (PDF)")
        m.putIfAbsent("Open the station page", "Ouvrir la page de la gare")
        m.putIfAbsent("Trenord notice", "Avis Trenord")
        m.putIfAbsent("Bars and restaurants", "Bars et restaurants")
        m.putIfAbsent("Bike sharing", "Vélos en libre-service")
        m.putIfAbsent("Get directions", "Itinéraire")
        m.putIfAbsent("Car sharing", "Autopartage")
        m.putIfAbsent("With ticket office", "Avec guichet")
        m.putIfAbsent("With ticket machines", "Avec distributeurs")
        m.putIfAbsent("From the Trenord website. Tap a station for its address and other services.", "Depuis le site Trenord. Touchez une gare pour l'adresse et les autres services.")
        m.putIfAbsent("Defibrillator", "Défibrillateur")
        m.putIfAbsent("Left luggage", "Consigne à bagages")
        m.putIfAbsent("Machines", "Distributeurs")
        m.putIfAbsent("Ticket machines", "Distributeurs automatiques")
        m.putIfAbsent("Newsstand", "Kiosque")
        m.putIfAbsent("Address", "Adresse")
        m.putIfAbsent("Reading the station page from the Trenord website…", "Lecture de la page de la gare sur le site Trenord…")
        m.putIfAbsent("Show all", "Tout afficher")
        m.putIfAbsent("No services listed", "Aucun service indiqué")
        m.putIfAbsent("No stations with these services.", "Aucune gare avec ces services.")
        m.putIfAbsent("Parking", "Parking")
        m.putIfAbsent("Car park", "Parking voitures")
        m.putIfAbsent("Bike parking", "Parking vélos")
        m.putIfAbsent("Waiting room", "Salle d'attente")
        m.putIfAbsent("Escalators", "Escalators")
        m.putIfAbsent("Station page not available right now.", "Page de la gare indisponible pour le moment.")
        m.putIfAbsent("Accessibility services", "Services d'accessibilité")
        m.putIfAbsent("Stations on the line", "Gares de la ligne")
        m.putIfAbsent("Wi-Fi", "Wi-Fi")
        m.putIfAbsent("TILO trains that left in the last 3 hours, in both directions, from the Swiss timetable: it counts delays over 15 minutes, not cancelled trains. For cancellations see the SBB notices below.", "Trains TILO partis ces 3 dernières heures, dans les deux sens, selon l'horaire suisse : seuls les retards de plus de 15 minutes sont comptés, pas les trains supprimés. Pour les suppressions, voir les avis CFF ci-dessous.")
        m.putIfAbsent("SBB notices on the line", "Avis CFF sur la ligne")
        m.putIfAbsent("Checking SBB notices…", "Vérification des avis CFF…")
        m.putIfAbsent("No current SBB notices: according to SBB, service is running normally.", "Aucun avis CFF en cours : selon les CFF, la circulation est normale.")
        m.putIfAbsent("SBB open data (texts in English).", "Données ouvertes CFF (textes en anglais).")
        m.putIfAbsent("SBB service status", "Situation du trafic CFF")
        m.putIfAbsent("Delete this trip?", "Supprimer ce trajet ?")
        m.putIfAbsent("Across all trips on the chosen route", "Sur tous les trajets de l'itinéraire choisi")
        m.putIfAbsent("Morning (5–10)", "Matin (5–10)")
        m.putIfAbsent("Daytime (10–16)", "Journée (10–16)")
        m.putIfAbsent("Evening (16–21)", "Soir (16–21)")
        m.putIfAbsent("Night (21–5)", "Nuit (21–5)")
        m.putIfAbsent("When your trains are most late", "À quelle heure vos trains ont le plus de retard")
        m.putIfAbsent("Across all trips in the log", "Sur tous les trajets du journal")
        m.putIfAbsent("{0} trips · average delay {1} min · {2} with 15 min or more", "{0} trajets · retard moyen {1} min · {2} avec 15 min ou plus")
        m.putIfAbsent("most delays", "le plus de retard")
        m.putIfAbsent("today", "aujourd'hui")
        m.putIfAbsent("yesterday", "hier")
        m.putIfAbsent("Last few days (worst moment)", "Derniers jours (pire moment)")
        m.putIfAbsent("All routes", "Tous les trajets")
        m.putIfAbsent("Compensation claim", "Demande d'indemnisation")
        m.putIfAbsent("Not today", "Pas aujourd'hui")
        m.putIfAbsent("Year", "Année")
        m.putIfAbsent("Arrival delay, day by day", "Retard à l'arrivée, jour par jour")
        m.putIfAbsent("Filled bar: minutes late (top = 60 or more). Empty bar: train cancelled.", "Barre pleine : minutes de retard (en haut = 60 ou plus). Barre vide : train supprimé.")
        m.putIfAbsent("Days with trips: {0}. No delays. Cancelled: {1}.", "Jours avec trajets : {0}. Aucun retard. Supprimés : {1}.")
        m.putIfAbsent("Days with trips: {0}. Highest delay: {1} minutes on day {2}. Cancelled: {3}.", "Jours avec trajets : {0}. Retard le plus élevé : {1} minutes le jour {2}. Supprimés : {3}.")
        m.putIfAbsent("{0} minutes late", "{0} minutes de retard")
        m.putIfAbsent("Date", "Date")
        m.putIfAbsent("Scheduled arrival", "Arrivée prévue")
        m.putIfAbsent("Delay (min)", "Retard (min)")
        m.putIfAbsent("Yes", "Oui")
        m.putIfAbsent("Delays this month", "Retards du mois")
        m.putIfAbsent("Search the guide", "Rechercher dans le guide")
        m.putIfAbsent("No topic found", "Aucun sujet trouvé")
        m.putIfAbsent("Tap to open «My trips» and share the month.", "Touchez pour ouvrir «Mes trajets» et partager le mois.")
        m.putIfAbsent("added by hand", "ajouté à la main")
        m.putIfAbsent("Add a trip", "Ajouter un trajet")
        m.putIfAbsent("Train (e.g. R 2727)", "Train (ex. R 2727)")
        m.putIfAbsent("Date (dd/mm/yyyy)", "Date (jj/mm/aaaa)")
        m.putIfAbsent("Scheduled arrival (hh:mm)", "Arrivée prévue (hh:mm)")
        m.putIfAbsent("Minutes late on arrival", "Minutes de retard à l'arrivée")
        m.putIfAbsent("Write the train with its number, for example R 2727.", "Indiquez le train avec son numéro, par exemple R 2727.")
        m.putIfAbsent("Write the departure and arrival stations.", "Indiquez la gare de départ et celle d'arrivée.")
        m.putIfAbsent("Check date and time: for example 09/11/2026 and 08:15.", "Vérifiez la date et l'heure : par exemple 09/11/2026 et 08:15.")
        m.putIfAbsent("The trip cannot be in the future.", "Le trajet ne peut pas être dans le futur.")
        m.putIfAbsent("The delay must be from 0 to 999 minutes.", "Le retard doit être de 0 à 999 minutes.")
        m.putIfAbsent("Low disruption", "Perturbation faible")
        m.putIfAbsent("Moderate disruption", "Perturbation moyenne")
        m.putIfAbsent("High disruption", "Perturbation forte")
        m.putIfAbsent("1 strike hidden by the filter", "1 grève masquée par le filtre")
        m.putIfAbsent("{0} strikes hidden by the filter", "{0} grèves masquées par le filtre")
        m.putIfAbsent("1 notice hidden by the filter", "1 avis masqué par le filtre")
        m.putIfAbsent("{0} notices hidden by the filter", "{0} avis masqués par le filtre")
        m.putIfAbsent("Share the month", "Partager le mois")
        m.putIfAbsent("Times recorded by the Binario app: they do not replace the operator's official certificates.", "Horaires relevés par l'app Binario : ils ne remplacent pas les attestations officielles de l'entreprise.")
        m.putIfAbsent("{0}: scheduled {1}, actual {2}", "{0} : prévu {1}, réel {2}")
        m.putIfAbsent("{0}: scheduled {1}, expected {2}", "{0} : prévu {1}, estimé {2}")
        m.putIfAbsent("{0}: scheduled {1}", "{0} : prévu {1}")
        m.putIfAbsent("How to read the times", "Comment lire les horaires")
        m.putIfAbsent("Actual time: the train passed on time", "Horaire réel : le train est passé à l'heure")
        m.putIfAbsent("Actual time: the train passed late", "Horaire réel : le train est passé en retard")
        m.putIfAbsent("Expected time: scheduled plus the current delay reported by the operator", "Horaire estimé : horaire prévu plus le retard actuel communiqué par l'entreprise")
        m.putIfAbsent("When data comes from several operators, the source is shown under the stop name (e.g. Trenord, SBB).", "Quand les données viennent de plusieurs entreprises, la source s'affiche sous le nom de l'arrêt (ex. Trenord, CFF).")
        m.putIfAbsent("Disruption on the line (last 3 hours)", "Perturbations sur la ligne (3 dernières heures)")
        m.putIfAbsent("Checking the trains of the last few hours…", "Je vérifie les trains des dernières heures…")
        m.putIfAbsent("No trains departed in the last 3 hours.", "Aucun train parti au cours des 3 dernières heures.")
        m.putIfAbsent("{0} critical trains out of {1}", "{0} trains critiques sur {1}")
        m.putIfAbsent("Short-run", "Limités")
        m.putIfAbsent("Over 15 min", "Plus de 15 min")
        m.putIfAbsent("Trains that departed in the last 3 hours, in both directions. Critical: cancelled, short-run or more than 15 minutes late.", "Trains partis au cours des 3 dernières heures, dans les deux sens. Critique : supprimé, limité ou plus de 15 minutes de retard.")
        m.putIfAbsent("My trips", "Mes trajets")
        m.putIfAbsent("Trains followed to arrival, delays this month", "Trains suivis jusqu'à l'arrivée, retards du mois")
        m.putIfAbsent("Previous month", "Mois précédent")
        m.putIfAbsent("Next month", "Mois suivant")
        m.putIfAbsent("No trips yet", "Aucun trajet pour l'instant")
        m.putIfAbsent("When you follow a train (the «Follow» button on the train page) until it arrives, the trip appears here with its delay. It stays on this phone only.", "Quand vous suivez un train (bouton «Suivre» sur la fiche du train) jusqu'à l'arrivée, le trajet apparaît ici avec son retard. Il reste uniquement sur ce téléphone.")
        m.putIfAbsent("No trips this month.", "Aucun trajet ce mois-ci.")
        m.putIfAbsent("The trip log stays on this phone only.", "Le journal reste uniquement sur ce téléphone.")
        m.putIfAbsent("Clear the trip log", "Effacer le journal")
        m.putIfAbsent("Delete all saved trips?", "Supprimer tous les trajets enregistrés ?")
        m.putIfAbsent("Trips", "Trajets")
        m.putIfAbsent("Delay of 15 min or more", "Retard de 15 min ou plus")
        m.putIfAbsent("Delay of 60 min or more", "Retard de 60 min ou plus")
        m.putIfAbsent("Total minutes of delay", "Minutes de retard au total")
        m.putIfAbsent("With a delay of 60 minutes or more you can claim compensation.", "Avec 60 minutes de retard ou plus, vous pouvez demander une indemnisation.")
        m.putIfAbsent("If you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation.", "Avec un abonnement, les retards comptent pour le bonus mensuel (Trenord) ou l'indemnisation.")
    }
}
