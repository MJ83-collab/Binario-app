package com.binario.treni.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.BoardItem
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class Neighbors(val station: String, val ahead: List<BoardItem>, val behind: List<BoardItem>)

/**
 * Treni davanti e dietro al tuo: stessa linea e stessa direzione, nei 45 minuti prima e dopo il tuo alla prossima fermata (o all'origine,
 * se non è partito). Fonti: tabellone ViaggiaTreno della fermata e, per Trenord e FerrovieNord, l'orario ufficiale (così funziona anche
 * dove ViaggiaTreno non ha il tabellone). Se quello davanti è in ritardo, può rallentare il tuo.
 * Regole (con i test in LineMatchTest): stesse fermate nello stesso ordine, stesso codice linea quando noto, mai un treno con lo stesso
 * numero ma di un'altra rete.
 */
private fun load(st: TrainStatus): Neighbors? {
    // Fermata di riferimento: la prossima (non l'ultima, dove non ci sono partenze)
    val idx = st.stops.indexOfFirst { !it.passed }
    if (idx < 0 || idx >= st.stops.size - 1) return null
    val ref = st.stops[idx]
    val mine = if (ref.schedDep > 0) ref.schedDep else ref.schedArr
    if (mine <= 0) return null
    val norm = com.binario.treni.data.LineMatch::norm
    val later = st.stops.drop(idx + 1).map { it.name.trim().uppercase() }.toSet()
    val mineLater = st.stops.drop(idx + 1).map { norm(it.name) }
    val refName = norm(ref.name)
    val window = 45 * 60_000L
    fun isSelf(number: String, origin: String) = number == st.number && (origin.isBlank() || st.originCode.isBlank() || origin == st.originCode)

    // 1) tabellone ViaggiaTreno della fermata
    val fromBoard = try {
        Api.departures(ref.station, mine - window)
            .filter { it.time in (mine - window)..(mine + window) && !isSelf(it.number, it.originCode) }
            .filter { it.otherEnd.trim().uppercase() in later }
    } catch (_: Exception) { emptyList() }

    // 2) orario ufficiale Trenord/FerrovieNord: corse che passano dalla stessa fermata e poi dalle stesse fermate
    val fromTimetable: List<BoardItem> = if (!com.binario.treni.data.TrainAliases.isTrenordRun(st)) emptyList() else try {
        com.binario.treni.data.TrenordGtfs.allTrips().mapNotNull { t ->
            val i = t.stops.indexOfFirst { it.id == ref.id || norm(it.name) == refName }
            if (i < 0 || i >= t.stops.size - 1) return@mapNotNull null
            val time = t.stops[i].dep.takeIf { it > 0 } ?: t.stops[i].arr
            if (time !in (mine - window)..(mine + window) || isSelf(t.number, t.stops.first().id)) return@mapNotNull null
            if (!com.binario.treni.data.LineMatch.sameCorridor(mineLater, t.stops.drop(i + 1).map { norm(it.name) })) return@mapNotNull null
            BoardItem(t.number, t.line, t.head, time, 0, "", false, t.stops.first().id, t.midnight, false, operator = "Trenord")
        }
    } catch (_: Exception) { emptyList() }
    val tripByKey = HashMap<String, com.binario.treni.data.TrenordGtfs.RunTrip>()
    runCatching {
        com.binario.treni.data.TrenordGtfs.allTrips().forEach { tripByKey[it.number + "/" + it.stops.firstOrNull()?.id + "/" + it.midnight] = it }
    }

    val myLine = runCatching { com.binario.treni.data.TrainLines.forTrain(st) }.getOrNull()?.code

    // Verifica in parallelo del percorso dei treni del tabellone; quelli dell'orario sono già confermati
    val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
    try {
        fun sameLine(b: BoardItem): Boolean {
            val cs = runCatching { Api.status(b.ref) }.getOrNull()
            // Percorso non leggibile: si tiene solo se ha la stessa sigla e la stessa destinazione del tuo
            if (cs == null || cs.stops.isEmpty()) return b.category.equals(st.category, true) && norm(b.otherEnd) == norm(st.destination)
            val ci = cs.stops.indexOfFirst { norm(it.name) == refName }
            if (ci < 0) return false
            if (!com.binario.treni.data.LineMatch.sameCorridor(mineLater, cs.stops.drop(ci + 1).map { norm(it.name) })) return false
            if (myLine != null) {
                val cl = runCatching { com.binario.treni.data.TrainLines.forTrain(cs) }.getOrNull()?.code
                if (!com.binario.treni.data.LineMatch.sameLineCode(myLine, cl)) return false
            }
            return true
        }
        fun pickSide(items: List<BoardItem>, ahead: Boolean): List<BoardItem> {
            val sorted = if (ahead) items.sortedByDescending { it.time } else items.sortedBy { it.time }
            val cands = sorted.take(6)
            val checks = cands.map { b -> pool.submit(java.util.concurrent.Callable { sameLine(b) }) }
            return cands.filterIndexed { i, _ ->
                try { checks[i].get(10, java.util.concurrent.TimeUnit.SECONDS) } catch (_: Exception) { false }
            }.take(2)
        }
        val boardKeys = fromBoard.map { it.number + "/" + it.time / 60_000L }.toSet()
        val ttOnly = fromTimetable.filter { (it.number + "/" + it.time / 60_000L) !in boardKeys }
        fun side(ahead: Boolean): List<BoardItem> {
            val vt = fromBoard.filter { if (ahead) it.time < mine else it.time > mine }
            val tt = ttOnly.filter { if (ahead) it.time < mine else it.time > mine }
            val ok = pickSide(vt, ahead)
            // Dall'orario ufficiale: il ritardo si legge da Trenord (solo corse della stessa linea per costruzione)
            val sortedTt = if (ahead) tt.sortedByDescending { it.time } else tt.sortedBy { it.time }
            val withDelay = sortedTt.take(2).map { b ->
                val trip = tripByKey[b.number + "/" + b.originCode + "/" + b.departureDate]
                val d = runCatching { Api.trenordDelayBest(b.number, b.ref, trip?.stops?.map { it.id to norm(it.name) } ?: emptyList()) }.getOrNull()
                if (d != null && d.second) b.copy(delay = d.first, inStation = true) else b
            }
            val all = (ok + withDelay).distinctBy { it.number + "/" + it.time / 60_000L }
            return (if (ahead) all.sortedByDescending { it.time } else all.sortedBy { it.time }).take(2)
        }
        return Neighbors(ref.name, side(true), side(false))
    } finally {
        pool.shutdownNow()
    }
}

@Composable
fun NeighborTrainsCard(st: TrainStatus, onTrain: (TrainRef) -> Unit) {
    if (st.cancelled || st.arrived) return
    var data by remember(st.number, st.originCode) { mutableStateOf<Neighbors?>(null) }
    var done by remember(st.number, st.originCode) { mutableStateOf(false) }
    LaunchedEffect(st.number, st.originCode) {
        data = withContext(Dispatchers.IO) { runCatching { load(st) }.getOrNull() }
        done = true
    }
    if (done && (data == null || (data!!.ahead.isEmpty() && data!!.behind.isEmpty()))) return
    WhiteCard {
        CardTitle(I18n.tr("Treni davanti e dietro al tuo", "Trains ahead and behind yours"))
        val d = data
        if (d == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), color = Green)
            return@WhiteCard
        }
        Text(I18n.tr("Confronto alla prossima fermata: ", "Compared at the next stop: ") + d.station, color = Muted, fontSize = 12.sp,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 4.dp))
        d.ahead.forEach { NeighborRow(it, I18n.tr("Davanti", "Ahead"), onTrain) }
        Text("▼ " + I18n.tr("Il tuo treno", "Your train") + " · " + st.title + (if (st.delay != 0) "  " + (if (st.delay > 0) "+" else "") + st.delay + " min" else ""),
            fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        d.behind.forEach { NeighborRow(it, I18n.tr("Dietro", "Behind"), onTrain) }
        val front = d.ahead.firstOrNull()
        if (front != null && front.delay >= st.delay + 5) {
            Text("⚠ " + I18n.tr("Il treno davanti è in ritardo e potrebbe rallentare il tuo.", "The train ahead is running late and could slow yours down."),
                color = LateRed, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        Text(I18n.tr("Treni della stessa linea e nella stessa direzione che passano da quella fermata nei 45 minuti prima e dopo il tuo. Fonte: ViaggiaTreno.",
            "Trains on the same line and in the same direction passing that stop in the 45 minutes before and after yours. Source: ViaggiaTreno."),
            color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 10.dp))
    }
}

@Composable
private fun NeighborRow(b: BoardItem, label: String, onTrain: (TrainRef) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onTrain(b.ref) }.padding(horizontal = 16.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.width(64.dp.fs()))
        Column(Modifier.weight(1f)) {
            Text("${b.category} ${b.number}".trim() + " → " + b.otherEnd, fontSize = 15.sp, maxLines = com.binario.treni.data.TextScale.lines(1), overflow = TextOverflow.Ellipsis)
            Text(Fmt.time(b.time), color = Muted, fontSize = 12.sp)
        }
        if (b.inStation || b.delay != 0) {
            Text((if (b.delay > 0) "+" else "") + b.delay + " min", fontWeight = FontWeight.Bold, fontSize = 14.sp,
                color = if (b.delay > 0) LateRed else OnTime)
        }
    }
}
