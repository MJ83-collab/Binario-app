package com.binario.treni.data

/**
 * Traduzione giapponese dell'interfaccia (generata dalle chiavi inglesi di De.kt). Le chiavi sono i testi inglesi
 * (EN e tr(it, en)); PAIRS risolve le iniziali dei giorni. I testi senza traduzione restano in inglese.
 * Divisa in più funzioni per non superare i limiti del bytecode.
 */
object Ja {
    private const val SEP = "\u0001"
    private val PAIRS: Map<String, String> = mapOf(
        "L" + SEP + "M" to "月",
        "M" + SEP + "T" to "火",
        "M" + SEP + "W" to "水",
        "G" + SEP + "T" to "木",
        "V" + SEP + "F" to "金",
        "S" + SEP + "S" to "土",
        "D" + SEP + "S" to "日",
        "Banconote" + SEP + "Notes" to "紙幣",
    )

    private val TEMPLATES: List<Pair<String, String>> = listOf(
        "No out-of-service elevators or escalators reported at {0} (FerrovieNord/RFI). The station screen lists lifts per platform." to "{0}で運休中のエレベーターやエスカレーターの報告はありません（FerrovieNord/RFI）。駅の画面でホームごとのエレベーターを確認できます。",
        "Binario · scheduled times from Trenitalia/LeFrecce, generated on {0}. Check delays and changes before travelling." to "Binario · Trenitalia/LeFrecceの時刻表、{0}作成。ご旅行前に遅延や変更をご確認ください。",
        "I can't find train {0} today. Check the number (it's on your ticket or the board) or search by station." to "本日の{0}列車が見つかりません。番号（切符または発車案内に記載）を確認するか、駅で検索してください。",
        "Band estimated from distance (about {0} km): check at the ticket office or in the Trenord app" to "距離から推定したゾーン（約{0} km）：窓口またはTrenordアプリでご確認ください",
        "By car it would take about {0} minutes less each way, but you couldn't use the travel time." to "車なら片道約{0}分早く着きますが、移動時間を有効に使えません。",
        "By train you save about {0} minutes each way at rush hour (and you can read or work)." to "電車ならラッシュ時に片道約{0}分節約できます（読書や仕事もできます）。",
        "Stops from {0} to the terminus · official Swiss timetable (transport.opendata.ch)" to "{0}から終点までの停車駅 · スイス公式時刻表（transport.opendata.ch）",
        "Which station do you leave from? Say for example \"from Varese to {0}\"." to "どの駅から出発しますか？たとえば\"Vareseから{0}まで\"と言ってください。",
        "I can't find bus, metro, tram or taxi stops mapped within 400 m of {0}." to "{0}から400 m以内にバス、地下鉄、トラム、タクシーの乗り場が見つかりません。",
        "You board at {0}. Where do you get off? I'll warn you before the stop." to "{0}で乗車します。どこで降りますか？降車駅の前にお知らせします。",
        "You have already sent {0} messages today: try again tomorrow. Thanks!" to "本日はすでに{0}件のメッセージを送信しました。明日もう一度お試しください。ありがとうございます！",
        "No connection: timetable downloaded at {0} on {1}. Delays not updated." to "オフライン：{1}の{0}にダウンロードした時刻表です。遅延情報は更新されていません。",
        "Platform change at {0}: train {1} now uses platform {2} instead of {3}." to "{0}で番線変更：{1}列車は{3}番線ではなく{2}番線から発車します。",
        "The nearest station is {0} ({1}). Here are the next departures:" to "最寄り駅は{0}（{1}）です。次の発車はこちら：",
        "In about {0} minutes you arrive at {1}. Start getting ready." to "あと約{0}分で{1}に到着します。降りる準備をしてください。",
        "You are already following {0}. Here is how it's going:" to "すでに{0}をフォロー中です。運行状況：",
        "The {0} board isn't responding. Try again shortly." to "{0}の発車案内が応答しません。しばらくしてからもう一度お試しください。",
        "Platform change: leaves from {0} instead of {1}." to "番線変更：{1}番線ではなく{0}番線から発車します。",
        "Transitous · official {0} timetable (GTFS)" to "Transitous · {0}公式時刻表（GTFS）",
        "I see no departures from {0} at that time." to "その時間に{0}からの発車はありません。",
        "Transport data not reachable now for {0}." to "{0}の交通データに現在アクセスできません。",
        "≈ the CO₂ absorbed in a year by {0} trees" to "≈ {0}本の木が1年間に吸収するCO₂",
        "{0} is not installed: choose another app" to "{0}がインストールされていません：別のアプリを選んでください",
        "Expected delay: {0} minutes, leaves at " to "予想遅延：{0}分、発車時刻 ",
        "I found {0} trains: which one is yours?" to "{0}本の列車が見つかりました。どれに乗りますか？",
        ", and shortly before {0} with the alarm" to "、アラームで{0}の少し前に",
        "Departure: {0} — now choose the arrival" to "出発：{0} — 次に到着駅を選んでください",
        "Message too long (max {0} characters)." to "メッセージが長すぎます（最大{0}文字）。",
        "No connections found from {0} to {1}." to "{0}から{1}への経路が見つかりません。",
        "Great, I'm following {0} for you. " to "了解しました。{0}をフォローします。 ",
        "No disruptions reported for: {0}." to "{0}について運行障害の報告はありません。",
        "Warning: train {0} is cancelled." to "注意：{0}列車は運休です。",
        "Train {0} is now {1} minutes late." to "{0}列車は現在{1}分遅れています。",
        "I can't find train {0} today." to "本日の{0}列車が見つかりません。",
        "Board not available for {0}." to "{0}の発車案内は利用できません。",
        " I will warn you before {0}." to " {0}の前にお知らせします。",
        "Does this train stop at {0}?" to "この列車は{0}に停車しますか？",
        "So far in {0} ({1} days logged)" to "これまでの{0}（{1}日記録）",
        "What time do you leave {0}?" to "{0}を何時に出発しますか？",
        "In a year ({0} travel days)" to "1年間（{0}日の移動）",
        "Italo real-time data ({0})" to "Italoのリアルタイムデータ（{0}）",
        "You get off at {0} around " to "{0}で降車、到着予定 ",
        ", expected delay {0} min." to "、予想遅延{0}分。",
        "Out of service at {0}:\n" to "{0}で運休中：\n",
        "Platform confirmed: {0}." to "番線確定：{0}。",
        "Data from {0} (offline)" to "{0}のデータ（オフライン）",
        "Running {0} min early." to "{0}分早く運行中。",
        "Running {0} min late." to "{0}分遅れで運行中。",
        "Next trains {0} → {1}:\n" to "次の列車 {0} → {1}：\n",
        "Board at {0}: due at {1}" to "{0}で乗車：予定 {1}",
        "Departures from {0}:" to "{0}発：",
        "Departs from {0} at {1}" to "{0}を{1}に発車",
        "Outbound: {0} runs…" to "往路：{0}本…",
        ", {0} minutes late." to "、{0}分遅れ。",
        "Train {0} not found" to "{0}列車が見つかりません",
        " (contactless {0})" to " （タッチ決済 {0}）",
        " from platform {0}" to " {0}番線から",
        "Return: {0} runs…" to "復路：{0}本…",
        "{0} minutes late." to "{0}分遅れ。",
        "Alarm set for {0}" to "{0}にアラームを設定しました",
        "Services at {0}:" to "{0}の設備：",
        "Departs from {0}" to "{0}発",
        "Arrivals at {0}:" to "{0}着：",
        "Board at {0} at {1}" to "{0}で{1}に乗車",
        "Days logged: {0}" to "記録日数：{0}",
        " {0} min late." to " {0}分遅れ。",
        "Arrived at {0}" to "{0}に到着",
        ", platform {0}" to "、{0}番線",
        "Next stop: {0}" to "次の停車駅：{0}",
        "{0} min early" to "{0}分早着",
        "Next stop {0}" to "次は{0}",
        "{0} o'clock, {1}" to "{0}時、{1}",
        "{0} min late" to "{0}分遅れ",
        "Near {0}:" to "{0}付近：",
        ", at {0}." to "、{0}に。",
        "Train {0}" to "{0}列車",
        " at {0}" to " {0}に",
    )
    private val compiled: List<Pair<Regex, String>> by lazy {
        TEMPLATES.map { (en, tr) ->
            val parts = en.split(Regex("\\{\\d\\}"))
            Regex("^" + parts.joinToString("(.+?)") { Regex.escape(it) } + "$", RegexOption.DOT_MATCHES_ALL) to tr
        }
    }
    private val cache = java.util.Collections.synchronizedMap(object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 300
    })

    private fun fromTemplate(en: String): String? {
        cache[en]?.let { return it.ifEmpty { null } }
        for ((re, tr) in compiled) {
            val m = re.matchEntire(en) ?: continue
            var z = tr
            for (g in 1 until m.groupValues.size) z = z.replace("{${g - 1}}", m.groupValues[g])
            cache[en] = z
            return z
        }
        cache[en] = ""
        return null
    }

    /** Testo tradotto per la coppia italiano/inglese; se manca, l'inglese. */
    fun of(it: String, en: String): String = PAIRS[it + SEP + en] ?: MAP[en] ?: (if (en.length in 4..400) fromTemplate(en) else null) ?: en

    fun has(en: String) = MAP.containsKey(en)

    private val MAP: HashMap<String, String> by lazy { HashMap<String, String>(2400).also { m -> p0(m); p1(m); p2(m); p3(m); p4(m); p5(m); p6(m); p7(m); p8(m); p9(m); p10(m); p11(m); p12(m); p13(m); p14(m) } }

    private fun p0(m: HashMap<String, String>) {
        m["Price with a change: check sbb.ch or Trainline"] = "乗り換えありの運賃：sbb.chまたはTrainlineでご確認ください"
        m["SBB fare (single ticket, adult)"] = "SBB運賃（片道、大人）"
        m["Read on sbb.ch on"] = "sbb.chで確認した日："
        m["Open on sbb.ch"] = "sbb.chで開く"
        m["2nd class"] = "2等"
        m["Where there is no 1st class (e.g. many regional trains) the 2nd class price is shown."] = "1等がない列車（多くの普通列車など）は2等の料金を表示しています。"
        m["App updates"] = "アプリの更新"
        m["Only strikes on my route"] = "自分のルートのストライキのみ"
        m["at my times"] = "自分の時間帯"
        m["change it in News › My route and times"] = "ニュース › マイルートと時間で変更できます"
        m["No route chosen: set your route in News › My route and times. Meanwhile you get national strikes and those in your region."] = "ルートが選択されていません：ニュース › マイルートと時間でルートを設定してください。それまでは全国と地域のストライキが届きます。"
        m["1st and 2nd class"] = "1等と2等"
        m["Accessible to people with disabilities or reduced mobility"] = "障がいのある方や移動が困難な方も利用可能"
        m["Add shortcut"] = "ショートカットを追加"
        m["Replacement buses"] = "代行バス"
        m["Defibrillators"] = "AED（除細動器）"
        m["Remove shortcut"] = "ショートカットを削除"
        m["Remove the shortcut?"] = "ショートカットを削除しますか？"
        m["Done"] = "完了"
        m["The official app to call 112 sending your exact location."] = "正確な位置情報を送って112に通報できる公式アプリ。"
        m["No shortcuts: tap + to add the features you use most."] = "ショートカットがありません：+をタップしてよく使う機能を追加してください。"
        m["This route"] = "このルート"
        m["This shortcut already exists"] = "このショートカットはすでにあります"
        m["AREU Lombardy website"] = "AREUロンバルディアのウェブサイト"
        m["2nd class only"] = "2等のみ"
        m["A station's departure board"] = "駅の発車案内"
        m["Shortcuts"] = "ショートカット"
        m["Tap the shortcut to remove."] = "削除するショートカットをタップしてください。"
        m["Bikes allowed"] = "自転車持ち込み可"
        m["A specific train (by number)"] = "特定の列車（番号で）"
        m["Do you really want to remove it? You can add it again with +."] = "本当に削除しますか？+でまた追加できます。"
        m["Station toilets"] = "駅のトイレ"
        m["not available"] = "利用不可"
        m["1st class"] = "1等"
        m[" early"] = " 早着"
        m[" late"] = " 遅れ"
        m[" · contactless"] = " · タッチ決済"
        m["1 hour before"] = "1時間前"
        m["Cross-border passes"] = "国境を越える定期券"
        m["Accessibility"] = "アクセシビリティ"
        m["Buy"] = "購入"
        m["Now"] = "今すぐ"
        m["Crowding"] = "混雑状況"
        m["Refresh"] = "更新"
        m["Add"] = "追加"
        m["Add a line, e.g. S5 Varese – Treviglio, to see the next trains in both directions."] = "路線を追加すると（例：S5 Varese – Treviglio）、両方向の次の列車を確認できます。"
        m["Help & FAQ"] = "ヘルプとよくある質問"
        m["Alarm when the train leaves the previous stop"] = "列車が前の駅を出発したらアラーム"
        m["Alarms"] = "アラーム"
        m["NTV high speed"] = "NTV高速鉄道"
        m["More"] = "その他"
        m["Outbound"] = "往路"
        m["Round trip"] = "往復"
        m["Cancel"] = "キャンセル"
        m["Open in browser"] = "ブラウザで開く"
        m["Open keyboard when choosing a station"] = "駅を選ぶときにキーボードを開く"
        m["Open a departure board and tap ★ to save the station."] = "発車案内を開いて★をタップすると駅を保存できます。"
        m["Open a train and tap ★ to add it here."] = "列車を開いて★をタップするとここに追加できます。"
        m["Arcobaleno (Swiss section) + Trenord (Lombardy section): check the price when buying"] = "Arcobaleno（スイス区間）+ Trenord（ロンバルディア区間）：購入時に料金をご確認ください"
        m["Trenitalia personal area"] = "Trenitaliaマイページ"
        m["Arrived on time"] = "定刻に到着"
        m["Arrivals"] = "到着"
        m["Arrivals at "] = "到着 "
        m["Arrival"] = "到着"
        m["Out-of-service elevators and escalators"] = "運休中のエレベーターとエスカレーター"
        m["Assistance"] = "サポート"
        m["Notify me"] = "通知する"
        m["Notify me 10 minutes before arriving here"] = "ここに到着する10分前に通知"
        m["Notices"] = "お知らせ"
        m["Disruption alerts on favourite routes, lines and trains"] = "お気に入りのルート、路線、列車の運行障害を通知"
        m["Alerts for deaf or hard-of-hearing people"] = "聴覚に障がいのある方向けの通知"
        m["Backup saved"] = "バックアップを保存しました"
        m["Bikes and light mobility"] = "自転車と小型モビリティ"
        m["Ticket offices, machines, validators, contactless"] = "切符売り場、券売機、改札機、タッチ決済"
        m["Tickets"] = "切符"
        m["Tickets, passes and QR codes"] = "切符、定期券、QRコード"
        m["Ticket"] = "切符"
        m["Regional ticket"] = "普通乗車券"
        m["Cross-border ticket"] = "国境を越える切符"
        m["Platforms: elevators and ramps"] = "ホーム：エレベーターとスロープ"
        m["Platform"] = "番線"
        m["Calendar"] = "カレンダー"
        m["Strike calendar (Ministry)"] = "ストライキ予定表（省庁）"
        m["Change a Trenitalia booking"] = "Trenitaliaの予約を変更"
        m["Terminus A"] = "終点A"
        m["Terminus A (e.g. Varese)"] = "終点A（例：Varese）"
        m["Terminus B"] = "終点B"
        m["Terminus B (e.g. Treviglio)"] = "終点B（例：Treviglio）"
        m["Loading station list (first time only)…"] = "駅リストを読み込み中（初回のみ）…"
        m["Loading…"] = "読み込み中…"
        m["Search"] = "検索"
        m["Search timetable"] = "時刻表を検索"
        m["Search & Buy"] = "検索と購入"
        m["Search a station"] = "駅を検索"
        m["Search a station for the departure board"] = "発車案内を見る駅を検索"
        m["Search within 2 km"] = "2 km以内で検索"
        m["Close"] = "閉じる"
        m["Traffic"] = "運行状況"
        m["Connection very much at risk"] = "乗り換えが非常に危うい"
        m["Tight connection"] = "乗り換え時間が短い"
        m["How it works"] = "使い方"
        m["Same as system"] = "システムと同じ"
        m["Operator announcements"] = "鉄道会社からのお知らせ"
        m["With delays of at least 60 minutes you are entitled to assistance: meals and refreshments in relation to the waiting time and, if needed, accommodation."] = "60分以上の遅延の場合、待ち時間に応じた食事や飲み物、必要に応じて宿泊の支援を受ける権利があります。"
        m["Share"] = "共有"
        m["Share timetable"] = "時刻表を共有"
        m["Malpensa Express conditions"] = "Malpensa Expressの運送約款"
        m["Trenitalia conditions"] = "Trenitaliaの運送約款"
        m["Trenord conditions"] = "Trenordの運送約款"
        m["Conditions of carriage"] = "運送約款"
        m["Conditions of carriage and rights"] = "運送約款と乗客の権利"
        m["Conditions of carriage, tickets, bikes, pets, fines"] = "運送約款、切符、自転車、動物、罰金"
        m["General conditions of carriage (regional and long distance)"] = "一般運送約款（普通列車と長距離列車）"
        m["Specific conditions for the airport link"] = "空港アクセス列車の特別約款"
        m["Compare"] = "比較"
        m["Compare routes"] = "経路を比較"
        m["Contacts"] = "連絡先"
        m["Always check the updated document before travelling."] = "ご旅行前に必ず最新の文書をご確認ください。"
        m["Station coordinates not available"] = "駅の座標がありません"
        m["Stop coordinates not available"] = "停留所の座標がありません"
        m["From mobiles +39 02 32 32 32 · 6:45–21:30"] = "携帯電話から +39 02 32 32 32 · 6:45～21:30"
        m["Data imported"] = "データをインポートしました"
        m["Direct"] = "直通"
        m["Rail passengers' rights and obligations (PDF)"] = "鉄道利用者の権利と義務（PDF）"
        m["Disable maps"] = "地図を無効にする"
        m["Official documents"] = "公式文書"
        m["After a search, tap the download icon to save the timetable."] = "検索後、ダウンロードアイコンをタップすると時刻表を保存できます。"
        m["During regional rail strikes, trains are normally guaranteed between 6:00–9:00 and 18:00–21:00, "] = "普通列車のストライキ中は、通常6:00～9:00と18:00～21:00の列車が保証されます。 "
        m["Updated official lists"] = "最新の公式リスト"
        m["List"] = "リスト"
        m["Full FerrovieNord list"] = "FerrovieNordの全リスト"
        m["Station list not available"] = "駅リストを利用できません"
        m["Delete"] = "削除"
        m["Ticket machines, validators, tobacconists, contactless payment"] = "券売機、改札機、タバコ店、タッチ決済"
        m["Network error"] = "ネットワークエラー"
        m["Error while saving"] = "保存中にエラーが発生しました"
        m["e.g. Varese → Como via Mendrisio or via Milan"] = "例：Varese → Como、Mendrisio経由またはMilano経由"
        m["e.g. Varese → Como: via Mendrisio (TILO) or via Milan. Duration, changes, cost and feasibility."] = "例：Varese → Como：Mendrisio経由（TILO）またはMilano経由。所要時間、乗り換え、料金、実現性。"
        m["Exclude categories"] = "除外する種別"
        m["Export data"] = "データをエクスポート"
        m["Feasible"] = "可能"
        m["Invalid file"] = "無効なファイル"
        m["Source: OpenStreetMap. Tobacconists and newsagents often sell regional tickets, but not always: "] = "出典：OpenStreetMap。タバコ店や売店では普通乗車券を販売していることが多いですが、必ずではありません： "
        m["Frecce, Intercity and Regional"] = "Frecce、Intercity、普通列車"
        m["General"] = "一般"
        m["My tickets"] = "マイチケット"
        m["My Italo trips"] = "Italoの旅程"
        m["On-board services (bikes, wheelchair spaces, classes) are not published in real-time data. "] = "車内設備（自転車、車椅子スペース、座席等級）はリアルタイムデータでは公開されていません。 "
        m["Your rights in brief (EU 2021/782)"] = "あなたの権利の概要（EU 2021/782）"
        m["The price via Milan is the Trenitalia/Trenord fare; the cross-border price is indicative: check at the ticket office or in the Trenord/SBB app."] = "Milano経由の料金はTrenitalia/Trenordの運賃です。国境を越える料金は目安です：窓口またはTrenord/SBBアプリでご確認ください。"
        m["Import data"] = "データをインポート"
        m["Unable to load train data"] = "列車データを読み込めません"
        m["Settings"] = "設定"
        m["Set"] = "設定する"
        m["On time"] = "定刻"
        m["Delay compensation: 25% of the ticket price for 60–119 minutes, 50% from 120 minutes. Operators may not pay amounts below €4."] = "遅延補償：60～119分で切符代の25%、120分以上で50%。4ユーロ未満は支払われない場合があります。"
        m["Back"] = "戻る"
        m["Info"] = "情報"
        m["RFI accessibility info"] = "RFIのバリアフリー情報"
        m["Customer information and lost property"] = "お客様案内と忘れ物"
        m["Information and bookings (replies on weekdays)"] = "案内と予約（平日に返信）"
        m["Swap"] = "入れ替え"
        m["Italo · assistance"] = "Italo · サポート"
        m["Italo · news"] = "Italo · ニュース"
        m["Purchases are made on the operator's official website: in-app purchase and synchronisation "] = "購入は鉄道会社の公式サイトで行います。アプリ内購入と同期は "
        m["Delay compensation may not be due in cases of force majeure (e.g. extreme weather, natural disasters, major public health crises)."] = "不可抗力の場合（例：異常気象、自然災害、重大な公衆衛生上の危機）は遅延補償が支払われないことがあります。"
        m["Flash blinking for alerts"] = "通知時にフラッシュを点滅"
        m["Works"] = "工事"
        m["National and regional conditions may set different rules for passes and regional trains."] = "国や地域の約款で、定期券や普通列車に異なる規則が定められている場合があります。"
        m["Legal"] = "法的情報"
        m["Lines"] = "路線"
        m["Favourite lines"] = "お気に入りの路線"
        m["Lines, cross-border fares, services"] = "路線、国境を越える運賃、設備"
        m["Map"] = "地図"
        m["FerrovieNord maintenance map"] = "FerrovieNordの保守地図"
        m["Max changes"] = "最大乗り換え回数"
        m["Monthly and annual"] = "月間・年間"
        m["Change date, time or class"] = "日付、時刻、座席等級を変更"
        m["Show Buy button"] = "購入ボタンを表示"
        m["Show later connections"] = "後の便を表示"
        m["Later connections"] = "後の便"
        m["No elevators mapped for this station."] = "この駅の地図にエレベーターがありません。"
        m["No notices"] = "お知らせはありません"
        m["No browser available"] = "利用できるブラウザがありません"
        m["No list published at the moment."] = "現在公開されているリストはありません。"
        m["No routes found for this time. Try later or another day (some lines do not run on Sundays)."] = "この時間の経路が見つかりません。後で、または別の日にお試しください（日曜運休の路線もあります）。"
        m["No direct trains found in this direction"] = "この方向の直通列車は見つかりません"
        m["No trains in the next hours"] = "今後数時間の列車はありません"
        m["No traffic disruptions reported"] = "運行障害の報告はありません"
        m["No calendar app found"] = "カレンダーアプリが見つかりません"
        m["No email app"] = "メールアプリがありません"
        m["No notifications. Use \"Notify me\" on a train or a connection."] = "通知はありません。列車や経路で\"通知する\"を使ってください。"
        m["No connections"] = "経路がありません"
        m["No station found"] = "駅が見つかりません"
        m["No rail strikes announced"] = "予定されている鉄道ストライキはありません"
        m["Nothing to save"] = "保存するものがありません"
        m["Not departed yet"] = "まだ出発していません"
        m["Not available at this time"] = "現在利用できません"
        m["Persistent notification on"] = "常時通知オン"
        m["Persistent notification enabled"] = "常時通知を有効にしました"
        m["Scheduled notification"] = "予約通知"
        m["Strike notifications"] = "ストライキの通知"
        m["Notifications"] = "通知"
        m["Scheduled notifications"] = "予約した通知"
        m["Scheduled notifications and wake-up alarms"] = "予約した通知と降車アラーム"
        m["News"] = "ニュース"
        m["Name (e.g. S5, RE2)"] = "名前（例：S5、RE2）"
        m["New favourite line"] = "新しいお気に入り路線"
        m["Train number"] = "列車番号"
        m["Station name"] = "駅名"
        m["Advanced options"] = "詳細オプション"
        m["Times and changes: official Swiss timetable (transport.opendata.ch) and Trenitalia/LeFrecce. "] = "時刻と乗り換え：スイス公式時刻表（transport.opendata.ch）とTrenitalia/LeFrecce。 "
        m["Offline timetables"] = "オフライン時刻表"
        m["Timetable saved for offline use"] = "時刻表をオフライン用に保存しました"
        m["Time already passed"] = "すでに過ぎた時刻です"
        m["Strike observatory unreachable right now"] = "ストライキ監視機関に現在アクセスできません"
        m["Official pages"] = "公式ページ"
        m["Departure"] = "出発"
        m["Origin and destination are the same"] = "出発地と目的地が同じです"
        m["Departures"] = "出発"
        m["Departures from "] = "出発 "
        m["Departures and arrivals from here"] = "ここからの出発と到着"
        m["Step-free routes, 55 cm platforms"] = "段差のない経路、高さ55 cmのホーム"
        m["People with disabilities or reduced mobility: free assistance in stations and on board, normally to be requested at least 24 hours in advance."] = "障がいのある方や移動が困難な方：駅と車内で無料のサポートが受けられます。通常、24時間前までに申し込みが必要です。"
        m["Arcobaleno zone map"] = "Arcobalenoゾーン地図"
        m["Several runs with this number"] = "この番号の列車が複数あります"
        m["Location & Maps"] = "位置情報と地図"
        m["Location not available. Turn on GPS and try again."] = "位置情報を取得できません。GPSをオンにしてもう一度お試しください。"
        m["Location not available: open the map first or turn on GPS."] = "位置情報を取得できません：先に地図を開くかGPSをオンにしてください。"
        m["Favourite"] = "お気に入り"
        m["Favourites"] = "お気に入り"
        m["Trenitalia/Trenord fare"] = "Trenitalia/Trenordの運賃"
        m["Trenitalia/Trenord fare (1 adult)"] = "Trenitalia/Trenordの運賃（大人1名）"
        m["Before arrival"] = "到着前"
        m["Before departure"] = "出発前"
        m["Privacy & permissions"] = "プライバシーと権限"
        m["You can check them in the operator's official timetable."] = "鉄道会社の公式時刻表でご確認いただけます。"
        m["Recent"] = "最近"
        m["Recent & favourites"] = "最近とお気に入り"
        m["Complaints: the operator must reply within one month (up to three months in justified cases)."] = "苦情：鉄道会社は1か月以内に回答する必要があります（正当な理由がある場合は最長3か月）。"
        m["Lombardy regional trains and Malpensa Express"] = "ロンバルディアの普通列車とMalpensa Express"
        m["Finding your location…"] = "現在地を取得中…"
        m["Refunds and complaints"] = "払い戻しと苦情"
        m["Remove"] = "削除"
        m["Expected arrival delay of at least 60 minutes: you can choose a refund, continuation, or re-routing."] = "到着の遅延が60分以上見込まれる場合：払い戻し、旅行の継続、または別経路を選べます。"
        m["Return"] = "復路"
        m["Ticket sellers"] = "切符販売所"
        m["Nearby ticket sellers and offices"] = "近くの切符販売所と窓口"
        m["Nearby ticket sellers"] = "近くの切符販売所"
        m["Save"] = "保存"
        m["Save offline"] = "オフライン保存"
        m["Saved offline"] = "オフライン保存済み"
        m["Choose the run"] = "便を選択"
        m["Choose origin and destination"] = "出発地と目的地を選択"
        m["Choose departure and arrival stations"] = "出発駅と到着駅を選択"
        m["Start screen"] = "起動時の画面"
        m["Strikes"] = "ストライキ"
        m["Strikes, traffic and works"] = "ストライキ、運行状況、工事"
        m["Dark"] = "ダーク"
        m["If the operator offers no alternative within 100 minutes, you may arrange it yourself with other trains or buses and claim reasonable costs."] = "鉄道会社が100分以内に代替手段を提供しない場合、ほかの列車やバスを自分で手配し、妥当な費用を請求できます。"
        m["Report problems between train and station"] = "列車と駅の間の問題を報告"
        m["Follow"] = "フォロー"
        m["Following"] = "フォロー中"
        m["Location permission needed"] = "位置情報の許可が必要です"
        m["Location permission is needed to find nearby stations."] = "近くの駅を探すには位置情報の許可が必要です。"
        m["Grant permission"] = "許可する"
        m["TILO services"] = "TILOの設備・サービス"
        m["Services & accessibility"] = "設備とアクセシビリティ"
        m["Station services"] = "駅の設備"
        m["Map service temporarily unreachable"] = "地図サービスに一時的にアクセスできません"
        m["TILO Pigiama night service"] = "TILO Pigiama深夜便"
        m["Summary for information only: the official text of the regulation and each operator's conditions prevails. "] = "参考用の要約です：規則の公式文書と各鉄道会社の約款が優先されます。 "
        m["Connections"] = "経路"
        m["Cancelled"] = "運休"
        m["Station"] = "駅"
        m["Arrival station"] = "到着駅"
        m["Departure station"] = "出発駅"
        m["Stations"] = "駅"
        m["Favourite stations"] = "お気に入りの駅"
        m["Nearby stations"] = "近くの駅"
        m["Nearby stations and map"] = "近くの駅と地図"
        m["Wake me before this stop"] = "この駅の前に起こして"
        m["TILO · Ticino and Lombardy"] = "TILO · ティチーノとロンバルディア"
        m["TILO · notices"] = "TILO · お知らせ"
        m["Full fare tables"] = "運賃表（全体）"
        m["Departure board not available"] = "発車案内を利用できません"
        m["Station board"] = "駅の発車案内"
        m["Lombardy regional fare: check the price"] = "ロンバルディア州の普通運賃：料金をご確認ください"
        m["Official Arcobaleno fare"] = "Arcobaleno公式運賃"
        m["Cross-border fares"] = "国境を越える運賃"
        m["Theme"] = "テーマ"
        m["Leisure"] = "レジャー"
        m["Type of connections"] = "経路の種類"
        m["Tickets and passes"] = "切符と定期券"
        m["Tickets, bikes, assistance"] = "切符、自転車、サポート"
        m["Tap again for the departure board"] = "もう一度タップすると発車案内"
        m["Tap to open"] = "タップして開く"
        m["Tap a category to exclude it (struck through) or include it."] = "種別をタップすると除外（取り消し線）または追加できます。"
        m["Tap a stop for the board or the alarm."] = "停車駅をタップすると発車案内またはアラーム。"
        m["Traffic, delays and strikes"] = "運行状況、遅延、ストライキ"
    }

    private fun p1(m: HashMap<String, String>) {
        m["Route"] = "ルート"
        m["Favourite and recent routes"] = "お気に入りと最近のルート"
        m["Trains"] = "列車"
        m["Guaranteed trains"] = "保証列車"
        m["Guaranteed trains during strikes"] = "ストライキ中の保証列車"
        m["Guaranteed trains: updated official lists"] = "保証列車：最新の公式リスト"
        m["Favourite trains"] = "お気に入りの列車"
        m["Trenitalia · refunds and compensation"] = "Trenitalia · 払い戻しと補償"
        m["Trenitalia · guaranteed trains"] = "Trenitalia · 保証列車"
        m["Trenitalia · travel information"] = "Trenitalia · 運行情報"
        m["Trenord · real-time traffic"] = "Trenord · リアルタイム運行状況"
        m["Train"] = "列車"
        m["Train not found"] = "列車が見つかりません"
        m["Followed train"] = "フォロー中の列車"
        m["Train cancelled"] = "運休"
        m["Trenord · notices"] = "Trenord · お知らせ"
        m["Trenord · notices and strikes"] = "Trenord · お知らせとストライキ"
        m["Trenord · refunds and compensation"] = "Trenord · 払い戻しと補償"
        m["Trenord: assistance for people with disabilities"] = "Trenord：障がいのある方へのサポート"
        m["All"] = "すべて"
        m["Every day 8:15–19:45 · book at least 24 hours ahead"] = "毎日 8:15～19:45 · 24時間前までに予約"
        m["Use your location"] = "現在地を使う"
        m["Light green"] = "ライトグリーン"
        m["App version"] = "アプリのバージョン"
        m["Via Mendrisio (TILO, cross-border)"] = "Mendrisio経由（TILO、国境越え）"
        m["Via Milan (Italy only)"] = "Milano経由（イタリア国内のみ）"
        m["Travellers with disabilities"] = "障がいのある旅行者"
        m["Strong vibration with a different pattern per alert: stop alarm (3 long, repeated), reminder (3 short ×2), disruptions (2 long)"] = "通知ごとに異なるパターンの強い振動：降車アラーム（長3回、繰り返し）、リマインダー（短3回×2）、運行障害（長2回）"
        m["Favourites widget"] = "お気に入りウィジェット"
        m["Station widget"] = "駅ウィジェット"
        m["Route / Line widget"] = "ルート／路線ウィジェット"
        m["Train widget"] = "列車ウィジェット"
        m["Arcobaleno zones"] = "Arcobaleno ゾーン"
        m["from "] = "発 "
        m["of tickets require a commercial agreement with Trenitalia, Italo and Trenord."] = "の切符にはTrenitalia、Italo、Trenordとの商業契約が必要です。"
        m["no changes (direct only)"] = "乗り換えなし（直通のみ）"
        m["no data"] = "データなし"
        m["not wheelchair accessible"] = "車椅子非対応"
        m["not set"] = "未設定"
        m["plus the trains listed by the operators. For long-distance trains, each operator's published lists apply. "] = "に加えて鉄道会社が掲載する列車。長距離列車は各社が公表するリストに従います。 "
        m["direct only"] = "直通のみ"
        m["check on site. Contactless payment is shown only if mapped."] = "現地でご確認ください。タッチ決済は地図に登録されている場合のみ表示されます。"
        m["♿ accessible"] = "♿ バリアフリー"
        m["♿ limited access"] = "♿ 一部バリアフリー"
        m["💳 cards"] = "💳 カード"
        m["📶 contactless"] = "📶 タッチ決済"
        m["🛗 elevator"] = "🛗 エレベーター"
        m["RFI accessibility page"] = "RFIのバリアフリーページ"
        m["No out-of-service facilities reported for this station."] = "この駅で運休中の設備の報告はありません。"
        m["Checking FerrovieNord and RFI…"] = "FerrovieNordとRFIを確認中…"
        m["OpenStreetMap data unreachable."] = "OpenStreetMapのデータにアクセスできません。"
        m["Source: OpenStreetMap (volunteer data, may be incomplete). Does not show today's faults."] = "出典：OpenStreetMap（ボランティアのデータで、不完全な場合があります）。本日の故障は表示されません。"
        m["FerrovieNord: station and elevator notices"] = "FerrovieNord：駅とエレベーターのお知らせ"
        m["Varese, Como, Novara, Brescia–Iseo–Edolo lines"] = "Varese線、Como線、Novara線、Brescia–Iseo–Edolo線"
        m["RFI Sala Blu assistance"] = "RFI Sala Bluサポート"
        m["Book help getting on and off"] = "乗降のサポートを予約"
        m["Wheelchair access"] = "車椅子でのアクセス"
        m["Open official timetable"] = "公式時刻表を開く"
        m["Sala Blu assistance (people with disabilities)"] = "Sala Bluサポート（障がいのある方）"
        m["Not available for this train."] = "この列車では利用できません。"
        m["Check on the Trenord website"] = "Trenordのサイトで確認"
        m["Estimate provided by Trenord"] = "Trenordによる推定"
        m["Open announcement"] = "お知らせを開く"
        m["Source: Strike Observatory – Italian Ministry of Transport"] = "出典：ストライキ監視機関 – イタリア運輸省"
        m["Strikes and travel info"] = "ストライキと運行情報"
        m["No news"] = "ニュースはありません"
        m["I took the train today"] = "今日電車に乗りました"
        m["Latest news"] = "最新ニュース"
        m["Strike calendar"] = "ストライキ予定表"
        m["Official list of the Ministry of Transport"] = "運輸省の公式リスト"
        m["Trenitalia travel info"] = "Trenitaliaの運行情報"
        m["Real-time traffic"] = "リアルタイム運行状況"
        m["Choose what to show"] = "表示する内容を選択"
        m["Real delays and platforms"] = "実際の遅延と番線"
        m["Best connections"] = "おすすめの経路"
        m["High speed"] = "高速列車"
        m["Regional"] = "普通列車"
        m["All connections"] = "すべての経路"
        m["Ticket office"] = "切符売り場"
        m["Self-service ticket machine"] = "自動券売機"
        m["Validator"] = "改札機"
        m["Authorised reseller"] = "正規販売店"
        m["Elevator"] = "エレベーター"
        m["Ramp"] = "スロープ"
        m["Strike"] = "ストライキ"
        m["Works and changes"] = "工事と変更"
        m["Notice"] = "お知らせ"
        m["How green are you"] = "あなたのエコ度"
        m["Train assistant"] = "列車アシスタント"
        m["How much CO₂, fuel, tolls and time you save"] = "CO₂、燃料、高速料金、時間をどれだけ節約できるか"
        m["Ask about trains, delays, strikes and traffic"] = "列車、遅延、ストライキ、運行状況について質問"
        m["Language"] = "言語"
        m["Legal notes"] = "法的情報"
        m["Colour-blind colours"] = "色覚多様性向けの色"
        m["Off"] = "オフ"
        m["Red-green (protanopia, deuteranopia)"] = "赤緑（1型・2型色覚）"
        m["Blue-yellow (tritanopia)"] = "青黄（3型色覚）"
        m["version"] = "バージョン"
        m["Version"] = "バージョン"
        m["Before you start"] = "はじめる前に"
        m["Read the full legal notes"] = "法的情報をすべて読む"
        m["I understand and accept"] = "理解して同意します"
        m["Binario is an independent app, not affiliated with Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO or SBB. Data comes from public sources and may contain errors: station boards, announcements and official channels always prevail. Estimated crowding, costs and times are indicative. All sources are public, free and cited in the legal notes. The app is free, ad-free, does not sell tickets and does not collect personal data."] = "BinarioはTrenitalia、RFI、Italo、Trenord、FerrovieNord、TILO、SBBとは関係のない独立したアプリです。データは公開情報源から取得しており、誤りを含む場合があります：駅の発車案内、構内放送、公式チャンネルが常に優先されます。混雑、費用、時間の推定値は目安です。すべての情報源は公開・無料で、法的情報に記載しています。アプリは無料で広告がなく、切符は販売せず、個人データも収集しません。"
        m["App created by Marco Jannino"] = "アプリ制作：Marco Jannino"
        m["Punctuality"] = "定時運行率"
        m["Monthly statistics by operator, station and train"] = "鉄道会社・駅・列車別の月間統計"
        m["of seats taken"] = "の座席が埋まっています"
        m["Source"] = "出典"
        m["No official data: estimate by time of day (weekday rush hours, trains to/from Milan)."] = "公式データなし：時間帯による推定（平日のラッシュ時、Milano発着の列車）。"
        m["Green: plenty of seats · Yellow: look for seats · Red: full, better wait for the next train"] = "緑：空席多数 · 黄：空席を探してください · 赤：満席、次の列車をお待ちください"
        m["Real-time crowding in the Trenord app"] = "Trenordアプリのリアルタイム混雑状況"
        m["Scheduled"] = "予定"
        m["Actual"] = "実際"
        m["Scheduled platform"] = "予定番線"
        m["Actual platform"] = "実際の番線"
        m["Switzerland"] = "スイス"
        m["All lines"] = "全路線"
        m["Extracting the line list from the Trenord website…"] = "Trenordのサイトから路線リストを取得中…"
        m["Trenord list not available right now."] = "Trenordのリストは現在利用できません。"
        m["Open lines on the Trenord website"] = "Trenordのサイトで路線を開く"
        m["FerrovieNord manages the infrastructure: trains on these lines are run by Trenord."] = "FerrovieNordはインフラを管理しています：これらの路線の列車はTrenordが運行しています。"
        m["Line added to favourites"] = "路線をお気に入りに追加しました"
        m["Choose the two termini"] = "両端の駅を選択"
        m["SBB rail traffic information"] = "SBBの鉄道運行情報"
        m["Real-time disruption map"] = "リアルタイム運行障害マップ"
        m["TILO notices"] = "TILOのお知らせ"
        m["TILO cross-border lines"] = "TILOの国境を越える路線"
        m["Line status, notices and stations"] = "路線の状況、お知らせ、駅"
        m["Official page"] = "公式ページ"
        m["Trenord, TILO, FerrovieNord, Switzerland"] = "Trenord、TILO、FerrovieNord、スイス"
        m["Refresh now"] = "今すぐ更新"
        m["Updated at"] = "更新時刻"
        m["refreshes every 5 minutes"] = "5分ごとに更新"
        m["Official websites"] = "公式サイト"
        m["Trenitalia · travel news"] = "Trenitalia · 運行ニュース"
        m["Open source"] = "出典を開く"
        m["no date"] = "日付なし"
        m["The full text is on the source website."] = "全文は出典のサイトにあります。"
        m["Hours"] = "時間"
        m["Who"] = "対象"
        m["Where"] = "場所"
        m["Sector"] = "部門"
        m["Unions"] = "労働組合"
        m["Notes"] = "備考"
        m["Station overview"] = "駅の概要"
        m["Platforms"] = "番線"
        m["Platforms in use"] = "使用中の番線"
        m["from today's trains"] = "本日の列車から"
        m["not mapped"] = "地図に未登録"
        m["Lifts"] = "エレベーター"
        m["none mapped"] = "地図に登録なし"
        m["escalators"] = "エスカレーター"
        m["ramps"] = "スロープ"
        m["none / not mapped"] = "なし／地図に未登録"
        m["present"] = "あり"
        m["Ticket machines"] = "券売機"
        m["Validators"] = "改札機"
        m["none within 500 m"] = "500 m以内になし"
        m["nearest at"] = "最寄り："
        m["Toilets"] = "トイレ"
        m["available"] = "利用可"
        m["wheelchair accessible station"] = "車椅子で利用できる駅"
        m["limited access"] = "一部バリアフリー"
        m["Lifts per platform"] = "番線ごとのエレベーター"
        m["no lift mapped"] = "地図にエレベーターなし"
        m["ramp"] = "スロープ"
        m["Loading station services…"] = "駅の設備を読み込み中…"
        m["Retry"] = "再試行"
        m["OpenStreetMap data unreachable right now."] = "OpenStreetMapのデータに現在アクセスできません。"
        m["OpenStreetMap volunteer data: may be incomplete. Today's faults are in the box below."] = "OpenStreetMapのボランティアデータです：不完全な場合があります。本日の故障は下の枠に表示されます。"
        m["Italo · info and support"] = "Italo · 案内とサポート"
        m["Your position"] = "現在地"
        m["Voice assistant (microphone on at start)"] = "音声アシスタント（起動時にマイクをオン）"
        m["Followed train: alert on platform change or bigger delay"] = "フォロー中の列車：番線変更や遅延拡大を通知"
        m["Voice alerts for blind or visually impaired people"] = "視覚に障がいのある方向けの音声通知"
        m["The phone's voice tells you where to catch the train (platform), when it leaves, platform changes and delays, and warns you with an insistent sound when your stop is near."] = "乗車する番線、発車時刻、番線変更や遅延をスマートフォンの音声でお知らせし、降車駅が近づくと繰り返し音で知らせます。"
        m["Voice alerts on. I will tell you the platform, the departure and the stop where to get off."] = "音声通知をオンにしました。番線、発車、降りる駅をお知らせします。"
        m["Announce every stop of the followed train"] = "フォロー中の列車の停車駅をすべて案内"
        m["Voice speed"] = "音声の速さ"
        m["Slow"] = "遅い"
        m["Normal"] = "普通"
        m["Fast"] = "速い"
        m["Voice test."] = "音声テスト。"
        m["Try the sounds: each one has a different meaning."] = "音を試す：それぞれ意味が異なります。"
        m["Stop coming up"] = "まもなく停車"
        m["Problem"] = "問題"
        m["To ask by voice: long-press the Binario icon and choose “Ask by voice” (you can drag it to the Home screen), or add the “Binario · Ask by voice” tile to Quick Settings. With your phone's assistant say “Open Binario”. Works with TalkBack too."] = "音声で質問するには：Binarioのアイコンを長押しして「音声で質問」を選びます（ホーム画面にドラッグできます）。または「Binario · 音声で質問」タイルをクイック設定に追加します。スマートフォンのアシスタントに「Binarioを開いて」と言ってもOK。TalkBackでも使えます。"
        m["Connection at risk: the previous train is"] = "乗り換えが危うい：前の列車が遅れています"
        m["min late"] = "分遅れ"
        m["Short change"] = "短い乗り換え"
        m["Change"] = "乗り換え"
        m["at"] = "時刻"
        m["planned"] = "予定"
        m["Delay compensation"] = "遅延補償"
        m["Delay over 2 hours: you can claim 50% of the ticket price."] = "2時間以上の遅延：切符代の50%を請求できます。"
        m["Delay over 1 hour: you can claim 25% of the ticket price."] = "1時間以上の遅延：切符代の25%を請求できます。"
        m["Frecce 30–59 minutes late: Trenitalia grants compensation. Check the conditions on its website."] = "Frecceが30～59分遅れた場合：Trenitaliaが補償を行います。条件は公式サイトでご確認ください。"
        m["The delay at your arrival station counts; season tickets have their own rules. Source: EU Regulation 2021/782 and operators' conditions."] = "到着駅での遅延が基準です。定期券には独自の規則があります。出典：EU規則2021/782と各社の約款。"
        m["Claim from Italo"] = "Italoに請求"
        m["Claim from Trenitalia"] = "Trenitaliaに請求"
        m["Trenord refunds"] = "Trenordの払い戻し"
        m["Trenitalia Regional compensation"] = "Trenitalia Regionaleの補償"
        m["I board here"] = "ここで乗車"
        m["Platform, time and alerts for this stop (also by voice)"] = "この駅の番線、時刻、通知（音声も可）"
        m["I will alert you for boarding at"] = "乗車のお知らせ："
        m["Only upcoming stop"] = "次の停車駅のみ"
        m["All: platform, departure, changes, delays, stops"] = "すべて：番線、発車、変更、遅延、停車駅"
        m["I will alert you by voice only when your stop is coming up."] = "降車駅が近づいたときだけ音声でお知らせします。"
        m["Do you want to turn this feature on?"] = "この機能をオンにしますか？"
        m["Strong vibration with a different pattern for each alert (stop alarm, reminders, disruptions) and flashlight blinking. You can change it any time in Settings → Accessibility."] = "通知ごとに異なるパターンの強い振動（降車アラーム、リマインダー、運行障害）とライトの点滅。設定 → アクセシビリティでいつでも変更できます。"
        m["Try the vibration"] = "振動を試す"
        m["Yes, turn on"] = "はい、オンにする"
        m["No, thanks"] = "いいえ、結構です"
        m["Voice alerts for blind people"] = "視覚に障がいのある方向けの音声通知"
        m["The phone's voice tells you the platform, when the train leaves, platform changes and delays, and an insistent sound warns you when your stop is coming up."] = "番線、発車時刻、番線変更や遅延をスマートフォンの音声でお知らせし、降車駅が近づくと繰り返し音で知らせます。"
        m["Yes, all voice alerts"] = "はい、すべての音声通知"
        m["Answer by voice"] = "音声で答える"
        m["Hear the question again"] = "質問をもう一度聞く"
        m["I heard"] = "聞き取った内容"
        m["Say yes, only stop, or no"] = "はい、降車駅のみ、いいえ、のどれかを言ってください"
        m["I didn't understand. Answer yes, only stop, or no. Or tap one of the buttons."] = "聞き取れませんでした。はい、降車駅のみ、いいえ、で答えるか、ボタンをタップしてください。"
        m["Voice alerts for blind or visually impaired people. Do you want to turn this feature on? You can choose: yes, for all voice alerts about platform, departure and stops; only stop, to be alerted only when your stop is coming up; or no."] = "視覚に障がいのある方向けの音声通知です。この機能をオンにしますか？選べるのは：はい（番線、発車、停車駅のすべての音声通知）、降車駅のみ（降車駅が近づいたときだけ通知）、いいえ、です。"
        m["Timetable PDF"] = "時刻表PDF"
        m["All the day's runs, saved on your phone and available offline."] = "その日の全便をスマートフォンに保存し、オフラインで利用できます。"
        m["Today"] = "今日"
        m["Tomorrow"] = "明日"
        m["Include return"] = "復路も含める"
        m["Saved in Download/Binario."] = "Download/Binarioに保存しました。"
        m["Open"] = "開く"
        m["No app to open PDFs"] = "PDFを開くアプリがありません"
        m["Download PDF"] = "PDFをダウンロード"
        m["Could not create the timetable"] = "時刻表を作成できませんでした"
        m["Download the day's timetable as PDF"] = "その日の時刻表をPDFでダウンロード"
        m["Free"] = "無料"
        m["Paid"] = "有料"
        m["Free or paid: not stated"] = "無料か有料か：記載なし"
        m["hours"] = "営業時間"
        m["Ask by voice"] = "音声で質問"
        m["Strikes and news"] = "ストライキとニュース"
        m["Current journey"] = "現在の旅程"
        m["Stop"] = "停止"
        m["Updating…"] = "更新中…"
        m["Board at"] = "乗車駅"
        m["platform"] = "番線"
        m["Next stop"] = "次の停車駅"
        m["Alarm before"] = "アラーム："
        m["Your journey"] = "あなたの旅程"
        m["Open live status"] = "リアルタイム状況を開く"
        m["Stop following"] = "フォローをやめる"
        m["Assistant: trains, delays, platforms, strikes"] = "アシスタント：列車、遅延、番線、ストライキ"
        m["Downloaded PDFs are also in Download/Binario"] = "ダウンロードしたPDFはDownload/Binarioにもあります"
        m["Information"] = "情報"
        m["Official sources, updated every 5 minutes"] = "公式情報源、5分ごとに更新"
        m["Regional vs regional, high speed vs high speed"] = "普通列車は普通列車と、高速列車は高速列車と比較"
        m["Conditions of carriage, rights and refunds"] = "運送約款、権利、払い戻し"
        m["Operators' websites"] = "鉄道会社のサイト"
        m["At the station and tickets"] = "駅と切符"
        m["Nearby stations on the map"] = "地図上の近くの駅"
        m["Official ticket sites and personal area"] = "公式切符サイトとマイページ"
        m["Tools"] = "ツール"
        m["On: all alerts"] = "オン：すべての通知"
        m["On: upcoming stop only"] = "オン：次の停車駅のみ"
        m["Alerts for deaf people"] = "聴覚に障がいのある方向けの通知"
        m["On: vibration and flash"] = "オン：振動とフラッシュ"
        m["App"] = "アプリ"
        m["What's new in each version"] = "各バージョンの新機能"
        m["Fix report"] = "修正レポート"
        m["Problems fixed in each version"] = "各バージョンで修正した問題"
        m["Bus, metro, tram and taxi"] = "バス、地下鉄、トラム、タクシー"
        m["Looking for nearby stops and taxi ranks…"] = "近くの停留所とタクシー乗り場を検索中…"
        m["No bus, metro, tram or taxi stop mapped within 400 m."] = "400 m以内にバス、地下鉄、トラム、タクシーの乗り場が地図に登録されていません。"
        m["Metro"] = "地下鉄"
        m["Tram"] = "トラム"
        m["Bus"] = "バス"
        m["Taxi"] = "タクシー"
        m["Bike sharing"] = "シェアサイクル"
        m["Stops in maps"] = "地図上の停留所"
        m["Find a taxi"] = "タクシーを探す"
        m["bus stop"] = "バス停"
        m["Lines and stops from OpenStreetMap data: for bus times and routes check the local transport company."] = "OpenStreetMapのデータによる路線と停留所です：バスの時刻と経路は地元の交通会社でご確認ください。"
        m["Metro entrance"] = "地下鉄の入口"
        m["Tram stop"] = "トラム停留所"
        m["Bus stop"] = "バス停"
        m["shelter"] = "屋根付き"
        m["Taxi rank"] = "タクシー乗り場"
        m["spaces"] = "台分"
        m["Tobacconists"] = "タバコ店"
        m["Newsagents"] = "新聞・雑誌売店"
        m["Ticket offices"] = "切符売り場"
        m["Bus stops"] = "バス停"
        m["Search on Google Maps:"] = "Googleマップで検索："
        m["Can't find it? Search on Google Maps:"] = "見つかりませんか？Googleマップで検索："
        m["Looking for ticket sellers within"] = "切符販売所を検索中：範囲"
        m["saved data"] = "保存済みデータ"
        m["OpenStreetMap servers are not responding (tried 3 Overpass servers and Postpass). Try again shortly or search on Google Maps."] = "OpenStreetMapのサーバーが応答しません（Overpassサーバー3台とPostpassを試しました）。しばらくしてからもう一度試すか、Googleマップで検索してください。"
        m["OpenStreetMap data unreachable right now (tried 3 Overpass servers and Postpass)."] = "OpenStreetMapのデータに現在アクセスできません（Overpassサーバー3台とPostpassを試しました）。"
        m["Pull down to retry"] = "下に引いて再試行"
        m["Pull down to refresh."] = "下に引いて更新。"
        m["refreshes every 5 minutes or when you pull down"] = "5分ごと、または下に引くと更新"
        m["No ticket sellers within"] = "切符販売所がありません：範囲"
    }

    private fun p2(m: HashMap<String, String>) {
        m["No ticket sellers found and the OpenStreetMap servers are not responding. Use the official Trenitalia map or try again."] = "切符販売所が見つからず、OpenStreetMapのサーバーも応答しません。Trenitaliaの公式地図を使うか、もう一度お試しください。"
        m["Mooney outlets"] = "Mooney取扱店"
        m["Official Trenitalia map (all of Italy)"] = "Trenitalia公式地図（イタリア全土）"
        m["Sources"] = "出典"
        m["Trenord authorised resellers and ticket offices"] = "Trenordの正規販売店と切符売り場"
        m["list of"] = "リスト："
        m["updated weekly; open/closed checked now"] = "毎週更新、営業中かどうかは今確認"
        m["SBB ticket machines (open data data.sbb.ch)"] = "SBBの券売機（オープンデータ data.sbb.ch）"
        m["ticket offices, machines and validators from"] = "切符売り場、券売機、改札機の出典："
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney outlets: the official Trenitalia map shows them."] = "イタリアのその他の地域では、Trenitaliaの普通乗車券はPuntoLISとMooneyの取扱店で販売されています：Trenitaliaの公式地図に表示されます。"
        m["Nearest station"] = "最寄り駅"
        m["Authorised resellers"] = "正規販売店"
        m["nearest"] = "最寄り"
        m["see the official Trenitalia map in Resellers"] = "販売店でTrenitaliaの公式地図をご覧ください"
        m["Downloading Trenord sellers…"] = "Trenordの販売所をダウンロード中…"
        m["Checking who is open now…"] = "現在営業中の店を確認中…"
        m["Sells"] = "販売"
        m["altoadigemobilità outlets (South Tyrol)"] = "altoadigemobilità取扱店（南チロル）"
        m["Railway companies"] = "鉄道会社"
        m["All companies in Italy and Switzerland: sites, tickets, data"] = "イタリアとスイスのすべての鉄道会社：サイト、切符、データ"
        m["Search company or region"] = "会社名または地域で検索"
        m["no public data"] = "公開データなし"
        m["Website"] = "ウェブサイト"
        m["Where to buy"] = "購入場所"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. Italian railways with their own network (EAV, FSE, Ferrotramviaria, FAL, Circumetnea, ARST and others) publish real-time data only on their own site and app."] = "RFI路線網の列車のリアルタイムデータはViaggiaTrenoから、スイスの全鉄道会社はスイス公式時刻表から取得しています。独自の路線網を持つイタリアの鉄道（EAV、FSE、Ferrotramviaria、FAL、Circumetnea、ARSTなど）は、リアルタイムデータを自社のサイトとアプリでのみ公開しています。"
        m["Only departures are available for Swiss stations"] = "スイスの駅は出発のみ表示できます"
        m["not yet included (data only in daily files too heavy for a phone: see note in Punctuality)"] = "未対応（データがスマートフォンには重すぎる日次ファイルでしか提供されていません：定時運行率の注記を参照）"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. For EAV, ARST, Trentino Trasporti and Cotral the app shows scheduled times (Transitous). The other railways with their own network publish timetables and real-time data only on their site and app."] = "RFI路線網の列車のリアルタイムデータはViaggiaTrenoから、スイスの全鉄道会社はスイス公式時刻表から取得しています。EAV、ARST、Trentino Trasporti、Cotralについては予定時刻（Transitous）を表示します。独自の路線網を持つその他の鉄道は、時刻表とリアルタイムデータを自社のサイトとアプリでのみ公開しています。"
        m["Only departures are available for this station"] = "この駅は出発のみ表示できます"
        m["Operator's scheduled times (Transitous): delays appear only if the operator publishes them."] = "鉄道会社の予定時刻（Transitous）：遅延は会社が公開している場合のみ表示されます。"
        m["Nearby toilets"] = "近くのトイレ"
        m["Free or paid, accessible, opening hours"] = "無料か有料か、バリアフリー、営業時間"
        m["Free or paid, accessible, baby changing, opening hours"] = "無料か有料か、バリアフリー、おむつ交換台、営業時間"
        m["Authorised resellers, ticket offices, machines, contactless"] = "正規販売店、切符売り場、券売機、タッチ決済"
        m["Looking for toilets within"] = "トイレを検索中：範囲"
        m["OpenStreetMap servers are not responding. Try again shortly or search on Google Maps."] = "OpenStreetMapのサーバーが応答しません。しばらくしてからもう一度試すか、Googleマップで検索してください。"
        m["Accessible ♿"] = "バリアフリー ♿"
        m["Within 2 km"] = "2 km以内"
        m["Public toilets"] = "公衆トイレ"
        m["No toilets mapped within"] = "地図にトイレがありません：範囲"
        m["Prices, hours and accessibility come from OpenStreetMap volunteers: check on site."] = "料金、営業時間、バリアフリー情報はOpenStreetMapのボランティアによるものです：現地でご確認ください。"
        m["♿ partly accessible"] = "♿ 一部バリアフリー"
        m["🚼 baby changing"] = "🚼 おむつ交換台"
        m["customers only"] = "利用客のみ"
        m["for customers"] = "利用客向け"
        m["min walk"] = "分（徒歩）"
        m["Service status"] = "サービスの状態"
        m["Check that all data sources respond"] = "すべてのデータソースが応答するか確認"
        m["Check again"] = "もう一度確認"
        m["Checking all data sources…"] = "すべてのデータソースを確認中…"
        m["All sources respond correctly."] = "すべてのデータソースが正常に応答しています。"
        m["sources with problems: related features use fallbacks or the last saved data."] = "件のデータソースに問題があります：関連する機能は代替手段か最後に保存したデータを使います。"
        m["Working"] = "正常"
        m["Checked at"] = "確認時刻"
        m["Sources are external public services: if one is down the app tries alternatives (other servers, saved data, Google Maps)."] = "データソースは外部の公共サービスです：停止している場合、アプリは代替手段（ほかのサーバー、保存済みデータ、Googleマップ）を試します。"
        m["Trains and boards"] = "列車と発車案内"
        m["Journeys"] = "経路"
        m["News and strikes"] = "ニュースとストライキ"
        m["Maps and station services"] = "地図と駅の設備"
        m["The app closed unexpectedly"] = "アプリが予期せず終了しました"
        m["Do you want to send the report to the developer? It contains only the technical error details, the phone model and the Android version: no personal data, location or trips."] = "開発者にレポートを送信しますか？エラーの技術情報、スマートフォンの機種、Androidのバージョンのみが含まれます：個人データ、位置情報、旅程は含まれません。"
        m["Binario error report"] = "Binarioのエラーレポート"
        m["Send report"] = "レポートを送信"
        m["Ignore"] = "無視"
        m["Your next train"] = "次の列車"
        m["I won't suggest it again"] = "今後は提案しません"
        m["Not mine"] = "自分の列車ではない"
        m["to"] = "行き"
        m["leaves at"] = "発車時刻"
        m["changed!"] = "変更されました！"
        m["Alternatives"] = "代替案"
        m["Leaving earlier"] = "早めに出発"
        m["Looking for alternatives…"] = "代替案を検索中…"
        m["No alternative soon."] = "すぐに乗れる代替案はありません。"
        m["Route ready in the Search tab"] = "検索タブにルートを用意しました"
        m["Learn the trains I take often"] = "よく乗る列車を学習する"
        m["From the board, journeys, Follow and favourites. Stays on the phone only."] = "発車案内、経路、フォロー、お気に入りから。データはスマートフォン内にのみ保存されます。"
        m["Alert me automatically about my usual train"] = "いつもの列車を自動で通知"
        m["In the 45 minutes before departure: delay, cancellation, platform change and ready alternatives"] = "出発前45分間：遅延、運休、番線変更、すぐ使える代替案"
        m["Forget"] = "削除する"
        m["No usual train yet: it appears after you open it at least twice on the same weekday."] = "いつもの列車はまだありません：同じ曜日に2回以上開くと表示されます。"
        m["Download failed. Check your connection and try again."] = "ダウンロードに失敗しました。接続を確認してもう一度お試しください。"
        m["A new version is available"] = "新しいバージョンがあります"
        m["Downloading the update…"] = "アップデートをダウンロード中…"
        m["To install the update allow Binario to install apps (Android asks only once), then come back here."] = "アップデートをインストールするには、Binarioにアプリのインストールを許可してから（Androidで1回だけ確認されます）、ここに戻ってください。"
        m["Update downloaded. Confirm the installation in the Android window: favourites and settings are kept."] = "アップデートをダウンロードしました。Androidの画面でインストールを確定してください：お気に入りと設定は保持されます。"
        m["Do you want to update Binario? The app downloads the new version by itself; favourites and settings are kept."] = "Binarioをアップデートしますか？アプリが新しいバージョンを自動でダウンロードします。お気に入りと設定は保持されます。"
        m["What's new"] = "新機能"
        m["Allow"] = "許可"
        m["Install"] = "インストール"
        m["Later"] = "後で"
        m["Feedback and bug reports"] = "フィードバックと不具合報告"
        m["Write to the developer: ideas, suggestions, problems"] = "開発者に連絡：アイデア、提案、問題"
        m["Suggestions, ideas or something not working? Write it here: the message goes straight to the developer."] = "提案やアイデア、うまく動かないことはありますか？ここに書いてください：メッセージは開発者に直接届きます。"
        m["Suggestion"] = "提案"
        m["Report a bug"] = "不具合を報告"
        m["Full name"] = "氏名"
        m["Enter your full name"] = "氏名を入力してください"
        m["Invalid email"] = "メールアドレスが無効です"
        m["Only used to reply to you"] = "返信にのみ使用します"
        m["Describe the problem"] = "問題の内容"
        m["Your feedback"] = "ご意見"
        m["What you were doing, what happened and what you expected (e.g. station, train number, time)."] = "何をしていたか、何が起きたか、何を期待していたか（例：駅、列車番号、時刻）。"
        m["What you like, what you would improve, what is missing."] = "気に入っている点、改善したい点、足りない点。"
        m["Write at least a few words"] = "少なくとも数語は書いてください"
        m["Attach technical details"] = "技術情報を添付"
        m["App version, phone model and Android version: they help find the problem."] = "アプリのバージョン、スマートフォンの機種、Androidのバージョン：問題の特定に役立ちます。"
        m["Thank you! Message sent."] = "ありがとうございます！メッセージを送信しました。"
        m["No connection: the message is saved and will be sent automatically as soon as possible."] = "オフライン：メッセージは保存され、可能になり次第自動で送信されます。"
        m["Sending…"] = "送信中…"
        m["Send"] = "送信"
        m["Name and email are only used to reply to you and nothing else. The message contains no location, trips or favourites."] = "氏名とメールアドレスは返信にのみ使用し、それ以外には使いません。メッセージに位置情報、旅程、お気に入りは含まれません。"
        m["Email"] = "メール"
        m["I recommend Binario, the free train app for Italy and Switzerland: timetables, live delays, platforms, strikes, Trenord and FerrovieNord, alerts for your train. No ads."] = "Binarioをおすすめします。イタリアとスイスの無料の鉄道アプリで、時刻表、リアルタイムの遅延、番線、ストライキ、TrenordとFerrovieNord、乗る列車の通知に対応。広告なし。"
        m["Download the latest version for Android:"] = "Android用の最新版をダウンロード："
        m["After downloading, open the file and allow the installation: the app then updates itself."] = "ダウンロード後、ファイルを開いてインストールを許可してください：その後アプリは自動で更新されます。"
        m["App not installed: choose another app"] = "アプリがインストールされていません：別のアプリを選んでください"
        m["Share Binario"] = "Binarioを共有"
        m["Send your contacts the link to download the latest version of the app."] = "アプリの最新版をダウンロードできるリンクを連絡先に送ります。"
        m["Other apps (SMS, email…)"] = "その他のアプリ（SMS、メール…）"
        m["Send the app to your contacts on WhatsApp, Telegram…"] = "WhatsApp、Telegramなどで連絡先にアプリを送る"
        m["STIBM area"] = "STIBMエリア"
        m["How much it costs"] = "料金"
        m["From"] = "出発"
        m["To"] = "到着"
        m["The journey goes through Milan"] = "Milanoを経由します"
        m["In that case zone Mi1 is also needed"] = "その場合、Mi1ゾーンも必要です"
        m["zones"] = "ゾーン"
        m["Same zone: the minimum 2-zone fare still applies (the one with the inner zone is fine too)."] = "同じゾーン：最低2ゾーン運賃が適用されます（内側のゾーンを含むものでも可）。"
        m["Note: this station is outside the STIBM area. It is only valid for changing train or bus, not as start or end of a STIBM ticket."] = "注意：この駅はSTIBMエリア外です。列車やバスの乗り換えにのみ使え、STIBM切符の出発地・目的地にはできません。"
        m["Single ticket"] = "普通乗車券"
        m["min"] = "分"
        m["Carnet of 10 (Trenord website and app)"] = "10回券（Trenordのサイトとアプリ）"
        m["Daily (24 hours)"] = "1日券（24時間）"
        m["3 days"] = "3日券"
        m["Weekly (Mon–Sun)"] = "週間（月～日）"
        m["Monthly"] = "月間"
        m["Yearly"] = "年間"
        m["Monthly under 26 / over 65"] = "月間 26歳未満／65歳以上"
        m["Yearly under 26 / over 65"] = "年間 26歳未満／65歳以上"
        m["Yearly ISEE below €6,000"] = "年間 ISEE 6,000ユーロ未満"
        m["Prices valid from"] = "料金の適用開始日"
        m["Valid on Trenord and Trenitalia regional trains in 2nd class, metro, trams and buses."] = "Trenord・Trenitaliaの普通列車2等、地下鉄、トラム、バスで有効。"
        m["Main rules"] = "主な規則"
        m["Zone map"] = "ゾーン地図"
        m["Fares"] = "運賃"
        m["Rules"] = "規則"
        m["Stations in the STIBM area"] = "STIBMエリアの駅"
        m["Search station or town"] = "駅または市町村を検索"
        m["outside the area, interchange only"] = "エリア外、乗り換えのみ"
        m["service suspended"] = "運休中"
        m["Use for the calculation"] = "計算に使う"
        m["Source: Trenord, STIBM area – areas and fares"] = "出典：Trenord、STIBMエリア – 対象エリアと運賃"
        m["Choose the station"] = "駅を選択"
        m["Station not found"] = "駅が見つかりません"
        m["Outside the STIBM area (interchange only)"] = "STIBMエリア外（乗り換えのみ）"
        m["zone"] = "ゾーン"
        m["fares"] = "運賃"
        m["STIBM area · Milan and Monza Brianza"] = "STIBMエリア · Milanoとモンツァ・ブリアンツァ"
        m["Zones, prices and stations of the integrated ticket"] = "共通乗車券のゾーン、料金、駅"
        m["One ticket for Trenord and Trenitalia regional trains, metro, trams and buses in the Metropolitan City of Milan, the province of Monza and Brianza and some nearby towns. The price depends on the number of zones (Mi1…Mi9) between start and end, not on the vehicle."] = "Milano大都市圏、モンツァ・ブリアンツァ県と周辺の一部の市町村で、Trenord・Trenitaliaの普通列車、地下鉄、トラム、バスに使える1枚の切符です。料金は乗り物ではなく、出発地と目的地の間のゾーン数（Mi1…Mi9）で決まります。"
        m["How much your pass costs"] = "定期券の料金"
        m["My Conductor"] = "マイ車掌"
        m["Follow your train: alerts before, during and after the trip"] = "乗る列車をフォロー：旅行の前・最中・後に通知"
        m["Tell me your train: I'll alert you about platform, delays and arrival. All trains, no sign-up."] = "乗る列車を教えてください：番線、遅延、到着をお知らせします。すべての列車に対応、登録不要。"
        m["Trenord from A to B: weekly, monthly, yearly, Trenocittà, tickets"] = "TrenordのAからBまで：週間、月間、年間、Trenocittà、切符"
        m["Trenord regional fare (Lombardy) by distance band, valid from"] = "Trenord普通運賃（ロンバルディア）距離帯別、適用開始日"
        m["Cannot work out the distance between these stations. Check your connection or choose stations in Lombardy."] = "これらの駅間の距離を計算できません。接続を確認するか、ロンバルディアの駅を選んでください。"
        m["Journey within the STIBM area"] = "STIBMエリア内の移動"
        m["Between these stations the integrated STIBM ticket applies (also valid on metro, trams and buses):"] = "これらの駅間ではSTIBM共通乗車券が適用されます（地下鉄、トラム、バスでも有効）："
        m["Tap for prices and rules."] = "タップで料金と規則を表示。"
        m["distance band"] = "距離帯"
        m["Passes"] = "定期券"
        m["Weekly"] = "週間"
        m["Trenocittà monthly"] = "Trenocittà月間"
        m["Trenocittà: train plus city transport in the town shown. "] = "Trenocittà：列車と表示された都市の市内交通がセット。 "
        m["Passes on the Io Viaggio card (€10, valid 4 years). Families: 2nd minor child −20%, from the 3rd free (Io Viaggio in Famiglia)."] = "定期券はIo Viaggioカード（10ユーロ、4年間有効）に搭載。家族：2人目の未成年の子は−20%、3人目から無料（Io Viaggio in Famiglia）。"
        m["Adult single"] = "大人片道"
        m["Children 4–14"] = "子ども 4～14歳"
        m["Senior"] = "シニア"
        m["Carnet of 10"] = "10回券"
        m["Children under 4 free; children 4–14 free with an adult family member holding a ticket."] = "4歳未満は無料。4～14歳は切符を持つ大人の家族と一緒なら無料。"
        m["Io Viaggio Ovunque (all trains and public transport)"] = "Io Viaggio Ovunque（すべての列車と公共交通）"
        m["All of Lombardy"] = "ロンバルディア全域"
        m["Province, monthly"] = "県内、月間"
        m["1 day"] = "1日"
        m["2 days"] = "2日"
        m["7 days"] = "7日"
        m["Quarterly"] = "3か月"
        m["1st class supplement:"] = "1等の追加料金："
        m["per trip"] = "1回あたり"
        m["per month"] = "1か月あたり"
        m["per year (Io Viaggio Ovunque in Lombardia)"] = "1年あたり（Io Viaggio Ovunque in Lombardia）"
        m["Bikes on lines leaving Lombardy: €3.50."] = "ロンバルディア州外へ向かう路線の自転車：3.50ユーロ。"
        m["Official fares"] = "公式運賃"
        m["Trenord passes"] = "Trenordの定期券"
        m["2nd cl."] = "2等"
        m["1st cl."] = "1等"
        m["Trains: 2nd class only. First class supplement: €2.80 per trip, €31 per month, €310 per year."] = "列車：2等のみ。1等追加料金：1回2.80ユーロ、1か月31ユーロ、1年310ユーロ。"
        m["Malpensa Express · fares"] = "Malpensa Express · 運賃"
        m["Prices from every station, lines, classes and restrictions"] = "各駅からの料金、路線、座席等級、制限事項"
        m["The two lines"] = "2つの路線"
        m["Prices from every station"] = "各駅からの料金"
        m["Single adult / child"] = "片道 大人／子ども"
        m["Same-day return"] = "当日往復"
        m["Weekly pass"] = "週間定期券"
        m["Monthly pass"] = "月間定期券"
        m["Yearly pass"] = "年間定期券"
        m["Other tickets"] = "その他の切符"
        m["Return within 30 days (online only), adult / child"] = "30日以内の往復（オンラインのみ）、大人／子ども"
        m["Malpensa Family (2 adults + 2 children 4–17)"] = "Malpensa Family（大人2名＋4～17歳の子ども2名）"
        m["Terminal 1 ⇄ Terminal 2 transfer, adult / child"] = "ターミナル1 ⇄ ターミナル2 移動、大人／子ども"
        m["Rules and restrictions"] = "規則と制限事項"
        m["Milan ⇄ Malpensa"] = "Milano ⇄ Malpensa"
        m["To or from Malpensa airport (Terminal 1 and 2) the airport fare applies. Prices valid from"] = "Malpensa空港（ターミナル1と2）発着には空港運賃が適用されます。料金の適用開始日"
        m["Malpensa airport: Malpensa Express fare"] = "Malpensa空港：Malpensa Express運賃"
        m["single"] = "片道"
        m["monthly 2nd cl."] = "月間 2等"
        m["monthly 1st cl."] = "月間 1等"
        m["There is no direct airport fare for this station. Tap for all fares and rules."] = "この駅には空港への直通運賃がありません。タップしてすべての運賃と規則を表示。"
        m["The prices below (regional fare) are not valid to or from the airport. Tap for all fares and restrictions."] = "下の料金（普通運賃）は空港発着には使えません。タップしてすべての運賃と制限事項を表示。"
        m["2nd class, single ticket, CHF · valid from 14.12.2025 (source: Arcobaleno)"] = "2等、片道、CHF · 14.12.2025から有効（出典：Arcobaleno）"
        m["Trenord passes and tickets"] = "Trenordの定期券と切符"
        m["Add to calendar"] = "カレンダーに追加"
        m["Some features may have bugs or change. Tap here to report a problem."] = "一部の機能に不具合があったり変更されたりすることがあります。問題を報告するにはここをタップしてください。"
        m["Alarms and saved timetables"] = "アラームと保存した時刻表"
        m["More options (voice, vibration for deaf people) in Settings → Accessibility."] = "その他のオプション（音声、聴覚に障がいのある方向けの振動）は設定 → アクセシビリティにあります。"
        m["Also just for your route and your times"] = "自分のルートと時間帯だけに絞ることも可能"
        m["Cancelled."] = "キャンセルしました。"
        m["Travel assistance for disabled passengers"] = "障がいのある方の旅行サポート"
        m["Remind me (scheduled notification)"] = "リマインド（予約通知）"
        m["Trenord notices"] = "Trenordのお知らせ"
        m["Biasca – Bellinzona – Lugano – Chiasso – Como"] = "Biasca – Bellinzona – Lugano – Chiasso – Como"
        m["Biasca – Bellinzona – Lugano – Varese – Malpensa"] = "Biasca – Bellinzona – Lugano – Varese – Malpensa"
        m["Tickets and prices"] = "切符と料金"
        m["Cadenazzo – Luino – Gallarate"] = "Cadenazzo – Luino – Gallarate"
        m["Arcobaleno fare calculator"] = "Arcobaleno運賃計算"
        m["Dogs, cats and pet carriers: rules and prices by operator"] = "犬、猫、キャリー：鉄道会社別の規則と料金"
        m["Castione-Arbedo – Bellinzona – Locarno"] = "Castione-Arbedo – Bellinzona – Locarno"
        m["Find an Italo train by number"] = "番号でItaloの列車を探す"
        m["Who to call and how to book: Sale Blu 800 90 60 60, Trenord, Italo, SBB"] = "連絡先と予約方法：Sale Blu 800 90 60 60、Trenord、Italo、SBB"
        m["Colour-blind colours. Do you want to turn this on? Tap yes red-green, yes blue-yellow, or no."] = "色覚多様性向けの色。オンにしますか？「はい 赤緑」「はい 青黄」「いいえ」をタップしてください。"
        m["What's your name? Tell me your first and last name."] = "お名前を教えてください。姓と名をどうぞ。"
        m["Como – Mendrisio – Varese"] = "Como – Mendrisio – Varese"
        m["Conditions of carriage, delays, compensation"] = "運送約款、遅延、補償"
        m["Contacts and support"] = "連絡先とサポート"
        m["Validate before departure and at every change of vehicle (between two trains the first validation is enough)."] = "出発前と乗り物を乗り換えるたびに刻印してください（列車同士の乗り換えなら最初の刻印だけで十分です）。"
        m["Single ticket valid 4 hours for the whole journey (in Italy from validation). Monthly cross-border passes: in Italy from the 1st of the month, only on an Io Viaggio card; in Ticino 30 days from purchase."] = "片道切符は全行程で4時間有効（イタリアでは刻印から）。国境を越える月間定期券：イタリアでは月の1日から、Io Viaggioカードのみ。ティチーノでは購入から30日間。"
        m["What to do and who to contact: Trenord, Trenitalia, Italo, SBB"] = "対処方法と連絡先：Trenord、Trenitalia、Italo、SBB"
        m["From A to B: passes and tickets, also to Switzerland"] = "AからBまで：定期券と切符、スイス行きも"
        m["From: "] = "出発： "
        m["Describe the problem."] = "問題を説明してください。"
        m["Describe the problem: what you were doing and what happened."] = "問題を説明してください：何をしていて、何が起きたか。"
        m["Dictate the message"] = "メッセージを口述"
        m["Shall I send, correct or cancel? Say send, correct or cancel."] = "送信、修正、キャンセルのどれにしますか？「送信」「修正」「キャンセル」と言ってください。"
        m["Tell me your suggestion."] = "ご提案をどうぞ。"
        m["Rights and refunds"] = "権利と払い戻し"
        m["Where am I"] = "現在地"
        m["Where I am, platforms, lifts, stairs, nearby services; guidance to a place"] = "現在地、番線、エレベーター、階段、近くの設備、目的地への案内"
        m["Where I am, platforms, lifts, services; guidance to a place"] = "現在地、番線、エレベーター、設備、目的地への案内"
        m["Duration"] = "所要時間"
        m["Sold out"] = "売り切れ"
        m["Explore by voice"] = "音声で探索"
        m["Voice feedback"] = "音声フィードバック"
        m["Voice feedback. After the tone, tell me: is it a suggestion or do you want to report a problem? You can say cancel at any time."] = "音声フィードバック。発信音の後に、提案か問題の報告かを教えてください。いつでも「キャンセル」と言えます。"
        m["Feedback and reports. Tap the \"Voice feedback\" button at the top to dictate your message."] = "フィードバックと報告。上の\"音声フィードバック\"ボタンをタップしてメッセージを口述してください。"
        m["Intermediate stops only at stations in the STIBM area; outside the area only to change vehicle (e.g. Saronno, Busto Arsizio, Treviglio)."] = "途中駅はSTIBMエリア内の駅のみ。エリア外は乗り換えのみ（例：Saronno、Busto Arsizio、Treviglio）。"
        m["Giubiasco – Lugano – Mendrisio"] = "Giubiasco – Lugano – Mendrisio"
        m["Got it"] = "わかりました"
        m["Tickets cannot be transferred after validation. Passes on an Io Viaggio or ATM card."] = "刻印後の切符は譲渡できません。定期券はIo ViaggioまたはATMカードに搭載。"
        m["Your trains during the strike"] = "ストライキ中のあなたの列車"
        m["The standard ticket is valid 75 minutes for 2 zones, +15 minutes per zone up to 4 zones, +30 minutes per zone from 5 zones up; in Milan (Mi1–Mi3) it is valid 90 minutes. Unlimited journeys within the validity time."] = "普通券は2ゾーンで75分有効、4ゾーンまでは1ゾーンごとに+15分、5ゾーン以上は1ゾーンごとに+30分。Milano（Mi1～Mi3）では90分有効。有効時間内は乗り放題。"
        m["The message is too short."] = "メッセージが短すぎます。"
        m["Speech recognition is not available on this phone."] = "このスマートフォンでは音声認識を利用できません。"
        m["At the station and tools"] = "駅とツール"
        m["Travel updates, guaranteed trains, tickets"] = "運行情報、保証列車、切符"
        m["About the app"] = "アプリについて"
        m["Full fare"] = "正規料金"
        m["Italy and Switzerland: websites, tickets, data"] = "イタリアとスイス：ウェブサイト、切符、データ"
        m["The Lombardy regional fare is not valid across the border. The price adds the Lombardy section (Trenord distance bands) and the Ticino section (Arcobaleno zones): Trenord sells it in euros, Arcobaleno in francs."] = "ロンバルディア州の普通運賃は国境を越えて使えません。料金はロンバルディア区間（Trenordの距離帯）とティチーノ区間（Arcobaleno ゾーン）の合計です：Trenordはユーロで、Arcobalenoはフランで販売しています。"
        m["Trenord and FerrovieNord lines"] = "TrenordとFerrovieNordの路線"
        m["FerrovieNord network lines"] = "FerrovieNord路線網の路線"
        m["Lines, Malpensa Express, STIBM area, notices"] = "路線、Malpensa Express、STIBMエリア、お知らせ"
        m["Locarno – Lugano – Chiasso – Milan"] = "Locarno – Lugano – Chiasso – Milano"
        m["Malpensa Express: valid only within the city of Milan (not in the 21 towns of zone Mi3) and between Milan and Rescaldina (Mi1–Mi7), only on trains to/from Milano Centrale."] = "Malpensa Express：Milano市内のみ（Mi3ゾーンの21市町村を除く）と、MilanoとRescaldinaの間（Mi1～Mi7）で有効。Milano Centrale発着の列車のみ。"
        m["The name is missing."] = "名前が入力されていません。"
        m["A valid email is missing."] = "有効なメールアドレスが入力されていません。"
        m["Half fare"] = "半額"
        m["Also show these options on the Home screen"] = "これらのオプションをホーム画面にも表示"
        m["Hide"] = "非表示"
        m["Hide fares"] = "運賃を隠す"
        m["During guaranteed hours (weekdays 6–9 and 18–21) regional trains run. Outside those hours check your operator's list of guaranteed trains."] = "保証時間帯（平日6～9時と18～21時）は普通列車が運行します。それ以外の時間帯は鉄道会社の保証列車リストをご確認ください。"
        m["No strike announced in your region"] = "お住まいの地域で予定されているストライキはありません"
        m["No announced strike affects your route at your times"] = "あなたのルートと時間帯に影響するストライキは予定されていません"
        m["No"] = "いいえ"
        m["I didn't understand the email. Say it again slowly, saying at and dot."] = "メールアドレスを聞き取れませんでした。「アット」と「ドット」を入れて、ゆっくりもう一度言ってください。"
        m["I didn't hear you. Tap \"Voice feedback\" again to try again."] = "聞き取れませんでした。もう一度\"音声フィードバック\"をタップしてください。"
        m["Note: the malpensaexpress.it passes page shows lower \"from\" prices (€25 weekly, €87 monthly, €840 yearly): here are the prices from the current Trenord fare table."] = "注意：malpensaexpress.itの定期券ページには低い「～から」料金（週間25ユーロ、月間87ユーロ、年間840ユーロ）が表示されています：ここではTrenordの現行運賃表の料金を表示しています。"
        m["Scheduled notifications, alarms, offline timetables"] = "予約通知、アラーム、オフライン時刻表"
        m["Travel update news"] = "運行情報ニュース"
    }

    private fun p3(m: HashMap<String, String>) {
        m["What's new, fixes, service status, privacy"] = "新機能、修正、サービスの状態、プライバシー"
        m["Lost property"] = "忘れ物"
        m["Spoken mode"] = "音声モード"
        m["Spoken mode (blind users)"] = "音声モード（視覚障がいのある方）"
        m["Spoken mode on."] = "音声モードをオンにしました。"
        m["Time"] = "時刻"
        m["Sort:"] = "並べ替え："
        m["By operator"] = "鉄道会社別"
        m["For people who are blind or prefer to talk: the app asks the questions aloud and you answer by voice."] = "視覚に障がいのある方や話して使いたい方向け：アプリが質問を読み上げ、音声で答えます。"
        m["Trenord doesn't publish a price table for this route: the exact price in euros is in the Trenord online shop."] = "Trenordはこの区間の料金表を公開していません：ユーロでの正確な料金はTrenordのオンラインショップにあります。"
        m["Ranks outside the station, radio taxis to call, apps"] = "駅前のタクシー乗り場、呼べる無線タクシー、アプリ"
        m["Taxi ranks, radio taxis to call, apps"] = "タクシー乗り場、呼べる無線タクシー、アプリ"
        m["Best prices by day and time of day"] = "曜日・時間帯別の最安料金"
        m["Prices for 1 adult from LeFrecce (Trenitalia); they may change until purchase."] = "LeFrecce（Trenitalia）の大人1名の料金です。購入までに変わることがあります。"
        m["Price"] = "料金"
        m["Arcobaleno price (2nd class, single ticket):"] = "Arcobaleno料金（2等、片道）："
        m["Trenord price (adult single ticket)"] = "Trenord料金（大人片道）"
        m["Price and booking on italotreno.com"] = "italotreno.comで料金確認と購入"
        m["Price on the Trenord website"] = "Trenordのサイトの料金"
        m["Sales points"] = "販売所"
        m["FerrovieNord punctuality"] = "FerrovieNordの定時運行率"
        m["What's your email? For example: mario dot rossi at gmail dot com."] = "メールアドレスを教えてください。例：mario ドット rossi アット gmail ドット com。"
        m["RFI Sala Blu · 800 90 60 60"] = "RFI Sala Blu · 800 90 60 60"
        m["Children under 14 travel free with a paying adult; on their own they need the Under 14 card."] = "14歳未満は料金を支払う大人と一緒なら無料。単独の場合はUnder 14カードが必要です。"
        m["EU Regulation 2021/782"] = "EU規則2021/782"
        m["Delays, cancellations, platforms, crowding and punctuality use distinguishable colours (orange and blue instead of red and green) and extra symbols. You can change it at any time from Home or Settings → Accessibility."] = "遅延、運休、番線、混雑、定時運行率に見分けやすい色（赤と緑の代わりにオレンジと青）と追加の記号を使います。ホームまたは設定 → アクセシビリティでいつでも変更できます。"
        m["Problem report."] = "問題の報告。"
        m["You are here"] = "現在地"
        m["FerrovieNord website"] = "FerrovieNordのウェブサイト"
        m["Suggestion."] = "提案。"
        m["Yes, blue-yellow"] = "はい、青黄"
        m["Yes, turn off"] = "はい、オフにする"
        m["Yes, red-green (the most common)"] = "はい、赤緑（最も一般的）"
        m["TILO (Ticino–Lombardy)"] = "TILO（ティチーノ–ロンバルディア）"
        m["TILO and Switzerland"] = "TILOとスイス"
        m["TILO · Services"] = "TILO · サービス"
        m["Departures and arrivals board"] = "発着案内"
        m["Nearby taxis"] = "近くのタクシー"
        m["Ticino–Lombardy, cross-border fares"] = "ティチーノ–ロンバルディア、国境を越える運賃"
        m["Between two Swiss stations Arcobaleno (Ticino) or SBB fares apply: Trenord's distance bands don't apply."] = "スイスの2駅間ではArcobaleno（ティチーノ）またはSBBの運賃が適用されます：Trenordの距離帯は適用されません。"
        m["Between places outside Milan: the zones between them; if you cross Milan you always also need Mi1. Minimum 2 zones."] = "Milano以外の地点間：その間のゾーン。Milanoを通過する場合は必ずMi1も必要です。最低2ゾーン。"
        m["Real-time trains, contacts"] = "リアルタイムの列車、連絡先"
        m["Trenord · 800 210 955"] = "Trenord · 800 210 955"
        m["All railway operators"] = "すべての鉄道会社"
        m["All accessibility options"] = "すべてのアクセシビリティ設定"
        m["All fares and classes"] = "すべての運賃と座席等級"
        m["Checked on the Trenord website on"] = "Trenordのサイトで確認した日："
        m["Travelling with pets"] = "ペットと旅行"
        m["Italy ⇄ Switzerland trip: cross-border ticket"] = "イタリア ⇄ スイスの旅行：国境を越える切符"
        m["Trip within Switzerland"] = "スイス国内の旅行"
        m["Do you want to turn on spoken mode? The phone's voice will tell you the platform, departure, delays and the stop where to get off."] = "音声モードをオンにしますか？番線、発車、遅延、降りる駅をスマートフォンの音声でお知らせします。"
        m["Do you want to turn off spoken mode?"] = "音声モードをオフにしますか？"
        m["application/json"] = "application/json"
        m["contactless"] = "タッチ決済"
        m["from"] = "発"
        m["data saved on the phone"] = "スマートフォンに保存したデータ"
        m["sold out"] = "売り切れ"
        m["in testing"] = "テスト中"
        m["half price"] = "半額"
        m["last"] = "残り"
        m["Departures from Cadorna at minutes 27 and 57 (from 4.27 to 00.20), 37 minutes. Stops at Milano Bovisa, Saronno, Busto Arsizio Nord. FIRST class only."] = "Cadorna発は毎時27分と57分（4.27～00.20）、所要37分。停車駅：Milano Bovisa、Saronno、Busto Arsizio Nord。1等のみ。"
        m["Departures from Centrale at minutes 25 and 55 (from 5.25 to 23.25), 51 minutes. Stops at Porta Garibaldi, Bovisa, Saronno, Busto Arsizio; the :25 trains also at Rescaldina, Castellanza and Ferno-Lonate Pozzolo. First and second class, but second class is only for trips that do NOT start or end at the airport."] = "Centrale発は毎時25分と55分（5.25～23.25）、所要51分。停車駅：Porta Garibaldi、Bovisa、Saronno、Busto Arsizio。25分発はRescaldina、Castellanza、Ferno-Lonate Pozzoloにも停車。1等と2等がありますが、2等は空港を発着しない区間のみです。"
        m["To or from Malpensa Terminal 1 and 2 you always need an airport-fare ticket: regional passes, Io Viaggio Ovunque (Lombardy or Varese province) and STIBM are valid on Malpensa Express trains only between the other stations."] = "Malpensaターミナル1・2発着には必ず空港運賃の切符が必要です：普通列車の定期券、Io Viaggio Ovunque（ロンバルディアまたはVarese県）、STIBMは、Malpensa Expressの列車ではそれ以外の駅間でのみ有効です。"
        m["The Malpensa ticket is valid for both terminals."] = "Malpensaの切符は両ターミナルで有効です。"
        m["Single ticket: valid on the chosen day until the end of service, no validation needed; the date can be changed up to 3 times until the day before."] = "片道切符：選んだ日の運行終了まで有効、刻印不要。前日まで3回まで日付を変更できます。"
        m["Return ticket: same-day at ticket offices and machines; within 30 days only online and in the app (Milan ⇄ Malpensa, €25 instead of €30), only the return date can be changed."] = "往復切符：当日往復は窓口と券売機で購入。30日以内の往復はオンラインとアプリのみ（Milano ⇄ Malpensa、30ユーロのところ25ユーロ）、変更できるのは復路の日付のみ。"
        m["Malpensa Family €36: 2 adults and 2 young people aged 4 to 17, between a Milan station and the airport. Children under 4 travel free."] = "Malpensa Family 36ユーロ：大人2名と4～17歳の2名、Milanoの駅と空港の間。4歳未満は無料。"
        m["Young people: reduced fare from 4 to 13 years."] = "青少年：4～13歳は割引運賃。"
        m["The Malpensa Express ticket to/from Milan is also valid on all trains between stations in the Milan area."] = "Milano発着のMalpensa Expressの切符は、Milano地区の駅間のすべての列車でも有効です。"
        m["On urban sections (Cadorna–Domodossola–Bovisa and Centrale–Porta Garibaldi–Bovisa) urban Trenord and STIBM tickets are also valid. STIBM is valid only in 2nd class, and on trains to/from Milano Centrale also as far as Rescaldina (Mi1–Mi7)."] = "都市区間（Cadorna–Domodossola–BovisaとCentrale–Porta Garibaldi–Bovisa）ではTrenordの都市内切符とSTIBMも有効です。STIBMは2等のみ有効で、Milano Centrale発着の列車ではRescaldina（Mi1～Mi7）まで有効です。"
        m["Malpensa Express passes: weekly (on sale from the Thursday before, activate within 5 days), monthly (from the 22nd of the previous month, within 15 days), yearly (within 30 days); on an Io Viaggio card or Phone Pass."] = "Malpensa Expressの定期券：週間（前の週の木曜から販売、5日以内に開始）、月間（前月22日から、15日以内）、年間（30日以内）。Io ViaggioカードまたはPhone Passに搭載。"
        m["Bikes and dogs travel free as luggage with a boarding pass; without a boarding pass dogs pay the pet supplement."] = "自転車と犬は搭乗券があれば手荷物として無料です。搭乗券がない場合、犬はペット追加料金が必要です。"
        m["Transfer between Terminal 1 and Terminal 2: €2 adults, €1 young people."] = "ターミナル1とターミナル2の間の移動：大人2ユーロ、青少年1ユーロ。"
        m["via Terminal 2"] = "ターミナル2経由"
        m["via Busto Arsizio"] = "Busto Arsizio経由"
        m["Share Binario: coming soon"] = "Binarioを共有：近日公開"
        m["Network, lifts out of service, accessibility, defibrillators"] = "路線網、運休中のエレベーター、アクセシビリティ、AED"
        m["FERROVIENORD network info"] = "FERROVIENORD路線網の情報"
        m["Lifts and escalators out of service, accessibility, assistance, AEDs, documents"] = "運休中のエレベーターとエスカレーター、アクセシビリティ、サポート、AED、文書"
        m["Stops and times of buses replacing trains · Trenord, Trenitalia, TILO"] = "列車の代行バスの停留所と時刻 · Trenord、Trenitalia、TILO"
        m["Defibrillators (AED)"] = "AED（除細動器）"
        m["Where they are, near you or the station · call 112"] = "あなたや駅の近くの設置場所 · 112に通報"
        m["Share Binario, not available: coming soon"] = "Binarioを共有は利用できません：近日公開"
        m["Coming soon"] = "近日公開"
        m["solutions · saved on "] = "件の経路 · 保存日 "
        m["Reminder at "] = "リマインダー "
        m["arrival"] = "到着"
        m["departure"] = "出発"
        m["Ticket offices, machines, resellers · nearby or by province"] = "切符売り場、券売機、販売店 · 近くまたは県別"
        m["Location not available: turn on GPS."] = "位置情報を取得できません：GPSをオンにしてください。"
        m["Looking for taxi ranks…"] = "タクシー乗り場を検索中…"
        m["OpenStreetMap servers are not responding. Use the numbers below or Google Maps."] = "OpenStreetMapのサーバーが応答しません。下の番号かGoogleマップをお使いください。"
        m["Call a taxi"] = "タクシーを呼ぶ"
        m["I don't have a verified radio taxi number for this city: use an app or search for the number."] = "この都市の確認済み無線タクシー番号がありません：アプリを使うか番号を検索してください。"
        m["Search for the taxi number"] = "タクシーの番号を検索"
        m["Italian radio taxi app: book and pay in the app"] = "イタリアの無線タクシーアプリ：アプリで予約・支払い"
        m["Taxis in many Italian cities"] = "イタリアの多くの都市のタクシー"
        m["Uber Taxi in cities where available"] = "利用可能な都市ではUber Taxi"
        m["Where to get a taxi"] = "タクシーに乗れる場所"
        m["No taxi rank mapped within 1.5 km. The rank is usually in front of the station's main exit."] = "1.5 km以内にタクシー乗り場が地図に登録されていません。乗り場は通常、駅の正面出口の前にあります。"
        m["Local taxi companies"] = "地元のタクシー会社"
        m["Taxi ranks"] = "タクシー乗り場"
        m["Ranks and phones from OpenStreetMap (volunteers), radio taxis from city services: check on site. 112 is for emergencies only."] = "乗り場と電話番号はOpenStreetMap（ボランティア）、無線タクシーは市のサービスから：現地でご確認ください。112は緊急時専用です。"
        m["Tap to open the location"] = "タップして場所を開く"
        m["Tap to call"] = "タップして電話"
        m["Best prices"] = "最安料金"
        m["Choose origin and destination first."] = "先に出発地と目的地を選んでください。"
        m["All trains"] = "すべての列車"
        m["Lowest price for 1 adult among trains in that time band (LeFrecce · Trenitalia). Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "その時間帯の列車の大人1名の最安料金（LeFrecce · Trenitalia）。セルをタップすると経路が表示されます。割引運賃は空席状況で変わります：最終的な料金は支払い時のものです。"
        m["In short"] = "要点"
        m["Small animals (cats, small dogs, rabbits, birds) in a carrier: almost always free."] = "キャリーに入った小動物（猫、小型犬、ウサギ、鳥）：ほぼ常に無料。"
        m["Larger dogs: leash and muzzle; a dog ticket is often needed."] = "大型犬：リードと口輪が必要。犬用の切符が必要なことが多いです。"
        m["Guide and assistance dogs: always free, on all trains and classes, with no time limits."] = "盲導犬と介助犬：すべての列車・座席等級でいつでも無料、時間制限なし。"
        m["Always carry the dog-registry certificate and health booklet (from abroad: EU pet passport)."] = "犬の登録証明書と健康手帳を必ず携帯してください（海外からはEUペットパスポート）。"
        m["The animal must not take up seats or disturb others: staff may ask you to leave if it causes danger or disturbance."] = "動物が座席を占めたり他人に迷惑をかけたりしてはいけません：危険や迷惑がある場合、係員に降車を求められることがあります。"
        m["Small animals in a carrier (max 70×30×50 cm): free within Lombardy."] = "キャリーに入った小動物（最大70×30×50 cm）：ロンバルディア州内は無料。"
        m["Dogs of any size: muzzle, leash and dog-registry certificate; free within Lombardy."] = "すべてのサイズの犬：口輪、リード、犬の登録証明書が必要。ロンバルディア州内は無料。"
        m["Not allowed on weekdays (Monday–Friday) 7:00–9:30 and 17:30–19:30, small animals included. Guide dogs can always travel."] = "平日（月～金）の7:00～9:30と17:30～19:30は乗車不可（小動物も含む）。盲導犬はいつでも乗車できます。"
        m["Beyond Lombardy and to Switzerland an animal supplement is needed, under the rules of the operating company."] = "ロンバルディア州外やスイスへは、運行会社の規則に従って動物の追加料金が必要です。"
        m["Malpensa Express: dogs travel free as luggage with a boarding pass; without one they pay the animal supplement."] = "Malpensa Express：犬は搭乗券があれば手荷物として無料。ない場合は動物の追加料金が必要です。"
        m["Small animals in a carrier (max 70×30×50 cm): always free, on all trains."] = "キャリーに入った小動物（最大70×30×50 cm）：すべての列車で常に無料。"
        m["Regional trains: larger dogs travel with a 2nd-class ticket at 50% off, with leash and muzzle."] = "普通列車：大型犬は2等の50%割引の切符で乗車でき、リードと口輪が必要です。"
        m["Frecce and Intercity: a dog outside the carrier must be added when buying (\"Travel with your dog\"); the price is the one shown at checkout, with promotions in some periods (e.g. dogs free in summer)."] = "FrecceとIntercity：キャリーに入っていない犬は購入時に追加する必要があります（\"犬と一緒に旅行\"）。料金は支払い時に表示され、時期によってキャンペーンがあります（例：夏は犬無料）。"
        m["Documents: dog-registry certificate and health booklet; staff may ask for them. Assistance dogs are also allowed in bar/restaurant cars and replacement buses."] = "書類：犬の登録証明書と健康手帳。係員に提示を求められることがあります。介助犬はビュッフェ・食堂車や代行バスにも乗車できます。"
        m["Small animals (up to about 5 kg) in a carrier: free."] = "キャリーに入った小動物（約5 kgまで）：無料。"
        m["Larger dogs: allowed in Smart and Prima by booking the \"Dog\" service (online or Pronto Italo 06 07 08, up to 2 hours before); always on a leash, muzzle when boarding/leaving or on request. Price shown at checkout."] = "大型犬：SmartとPrimaで\"Dog\"サービスを予約すれば乗車可（オンラインまたはPronto Italo 06 07 08、2時間前まで）。常にリード着用、乗降時や求められたときは口輪。料金は支払い時に表示。"
        m["Guide dogs: free, any size."] = "盲導犬：サイズを問わず無料。"
        m["Switzerland · SBB and TILO"] = "スイス · SBBとTILO"
        m["Dogs up to 30 cm at the withers and other small animals in a bag or carrier: free, as hand luggage."] = "体高30 cmまでの犬とその他の小動物はバッグまたはキャリーに入れれば手荷物として無料。"
        m["Larger dogs (or outside a carrier): half the 2nd-class fare, or the dog day pass CHF 25 (also valid on buses, trams and boats); dog pass CHF 60 a month or CHF 350 a year."] = "それより大きい犬（またはキャリーに入れない場合）：2等の半額、または犬用1日券25 CHF（バス、トラム、船でも有効）。犬用定期券は月60 CHF、年350 CHF。"
        m["The dog stays under your seat without blocking the aisle. Not allowed in restaurant cars (except guide and assistance dogs)."] = "犬は通路をふさがないように座席の下に。食堂車には入れません（盲導犬・介助犬を除く）。"
        m["Rules from the operators' official pages (October 2026). Prices and promotions change: before travelling check the operator's page with the button above."] = "各鉄道会社の公式ページの規則（2026年10月）。料金とキャンペーンは変わります：ご旅行前に上のボタンから会社のページをご確認ください。"
        m["Official page "] = "公式ページ "
        m["Enter town or station"] = "市町村名または駅名を入力"
        m["Clear"] = "クリア"
        m["Near me"] = "現在地周辺"
        m["Show map"] = "地図を表示"
        m["Show list"] = "リストを表示"
        m["towards "] = "方向 "
        m["straight ahead"] = "まっすぐ"
        m["to your right"] = "右側"
        m["behind you"] = "後ろ"
        m["to your left"] = "左側"
        m["ahead on the right"] = "右前方"
        m["ahead on the left"] = "左前方"
        m["behind on the right"] = "右後方"
        m["behind on the left"] = "左後方"
        m["metres"] = "メートル"
        m["Travelling, near the station of "] = "移動中、次の駅の近く： "
        m["You are at "] = "現在地： "
        m["Warning, out of service: "] = "注意、運休中： "
        m["You have arrived: "] = "到着しました： "
        m["Explore"] = "探索"
        m["Categories"] = "カテゴリー"
        m["Guiding you to: "] = "案内中： "
        m["Walking navigation"] = "徒歩ナビ"
        m["Stop guiding"] = "案内をやめる"
        m["Location permission is needed to explore."] = "探索するには位置情報の許可が必要です。"
        m["Finding your position… Turn on GPS."] = "現在地を取得中… GPSをオンにしてください。"
        m["Guiding you to "] = "案内先： "
        m["Exploring. I'll tell you about nearby stations, platforms, lifts, stairs and services."] = "探索中です。近くの駅、番線、エレベーター、階段、設備をお知らせします。"
        m["Exploring stopped."] = "探索を停止しました。"
        m["Stop exploring"] = "探索をやめる"
        m["Start spoken exploration"] = "音声探索を開始"
        m["Nearest station: "] = "最寄り駅： "
        m["You are moving at "] = "移動速度： "
        m["No useful places found nearby."] = "近くに役立つ場所が見つかりません。"
        m["Where am I? Tell me"] = "ここはどこ？教えて"
        m["Last announcement"] = "最後の案内"
        m["GPS accuracy: "] = "GPSの精度： "
        m[" · no compass: directions by compass points"] = " · コンパスなし：方角で案内"
        m["Hold the phone in front of you: \"12 o'clock\" is ahead, \"3\" right, \"9\" left. In stations GPS can be off by a few metres: ask staff or the Sale Blu for help (More → Disability assistance)."] = "スマートフォンを体の前に持ってください：\"12時\"が前、\"3時\"が右、\"9時\"が左です。駅ではGPSが数メートルずれることがあります：係員やSale Bluに助けを求めてください（その他 → 障がいのある方のサポート）。"
        m["None of these mapped nearby (300 m)."] = "近く（300 m）にこれらは地図に登録されていません。"
        m["Guide me"] = "案内して"
        m["Board"] = "発車案内"
        m["No results for "] = "検索結果なし： "
        m["Found "] = "見つかりました： "
        m[" results. First: "] = " 件。最初： "
        m["Place, address, station…"] = "場所、住所、駅…"
        m["Voice search"] = "音声検索"
        m["Save this spot"] = "この場所を保存"
        m["E.g. \"Platform 3, front of the train\", \"Lift by the café\", \"Taxi exit\": then \"Guide me\" brings you back. Favourite stations and trains are in the Stations and Trains tabs."] = "例：\"3番線、列車の先頭\"、\"カフェ横のエレベーター\"、\"タクシー出口\"。後で\"案内して\"で戻れます。お気に入りの駅と列車は駅タブと列車タブにあります。"
        m["No saved places."] = "保存した場所はありません。"
        m["Name"] = "名前"
        m["Current position, accuracy ±"] = "現在地、精度 ±"
        m["Saved spot"] = "保存した場所"
        m["Saved: "] = "保存しました： "
        m["No solutions found for the chosen time."] = "選んだ時間の経路が見つかりません。"
        m["Cannot reach the server. Check your connection."] = "サーバーに接続できません。接続を確認してください。"
        m["Departing from "] = "出発： "
        m["FASTEST"] = "最速"
        m[" · first train +"] = " · 最初の列車 +"
        m["Not reachable now: "] = "現在アクセスできません： "
        m["Train "] = "列車 "
        m["I'll remind you at "] = "リマインド時刻： "
        m["Where to catch the bus when trains don't run · Trenord, Trenitalia, TILO"] = "列車が運休するときのバス乗り場 · Trenord、Trenitalia、TILO"
        m["The nearest to you · call 112"] = "あなたに最も近い場所 · 112に通報"
        m["FERROVIENORD · source: ferrovienord.it (station accessibility notices). Assistance: 800 210 955"] = "FERROVIENORD · 出典：ferrovienord.it（駅のバリアフリー情報）。サポート：800 210 955"
        m["Show later trains (+6 hours)"] = "後の列車を表示（+6時間）"
        m["Platform "] = "番線 "
        m["What to do right away"] = "すぐにすること"
        m["If you are still on the train or in the station, tell the conductor or staff straight away: it's the fastest way to find it."] = "まだ列車や駅にいる場合は、すぐに車掌か係員に伝えてください：見つけるための最も早い方法です。"
        m["Note the train number, day, time, coach and seat, and describe the item well (brand, colour, contents)."] = "列車番号、日付、時刻、号車、座席を控え、物の特徴（ブランド、色、中身）を詳しく説明してください。"
        m["Contact the train's operator (below): each has its own lost property service."] = "列車の運行会社（下記）に連絡してください：各社に忘れ物窓口があります。"
        m["Documents, cards or phone: block your cards and, for theft or documents, report it to the Railway Police (Polfer) or Carabinieri."] = "書類、カード、スマートフォン：カードを停止し、盗難や書類の場合は鉄道警察（Polfer）またはカラビニエリに届け出てください。"
        m["After a few days unclaimed items go to the town's lost property office: ask there."] = "数日経っても引き取りのない物は市の遺失物センターに送られます：そちらにお問い合わせください。"
        m["The train you are following: "] = "フォロー中の列車： "
        m["Trenord, Malpensa Express and FerrovieNord stations"] = "Trenord、Malpensa Express、FerrovieNordの駅"
        m["Trenord Contact Center: items lost on trains or platforms"] = "Trenordコンタクトセンター：列車やホームでの忘れ物"
        m["Found items are kept at the My Link Points in Milano Cadorna and Milano Porta Garibaldi for a few days (up to 6), then go to the City of Milan lost property office."] = "拾得物はMilano CadornaとMilano Porta GaribaldiのMy Link Pointで数日間（最長6日）保管され、その後Milano市の遺失物センターに送られます。"
        m["City of Milan · Lost property"] = "Milano市 · 遺失物センター"
        m["Via Friuli 30, Milan · 02 884 53900"] = "Via Friuli 30、Milano · 02 884 53900"
        m["Trenord lost property page"] = "Trenordの忘れ物ページ"
        m["Frecce: go to the Frecciadesk or customer service in the station as soon as you notice, staff can have your seat checked. Regional and Intercity: found items are usually handed to the lost property office of the town where the train terminates."] = "Frecce：気付いたらすぐに駅のFrecciadeskかカスタマーサービスへ。係員が座席を確認してくれます。普通列車とIntercity：拾得物は通常、列車の終着駅がある市の遺失物センターに届けられます。"
        m["Lost items search service"] = "忘れ物検索サービス"
        m["Customer service offices"] = "カスタマーサービス窓口"
        m["Pronto Italo, daily 7–23: report the item with train number, coach and seat"] = "Pronto Italo、毎日7～23時：列車番号、号車、座席を添えて届け出てください"
        m["Report the loss online"] = "オンラインで紛失を届け出る"
        m["SBB Contact Center, 24 hours"] = "SBBコンタクトセンター、24時間"
        m["On collection you pay CHF 20 (CHF 10 with a GA travelcard); electronics and bulky items CHF 25 (CHF 15). On TILO trains between Italy and Switzerland report to both SBB and Trenord."] = "受け取り時に20 CHF（GA定期券なら10 CHF）、電子機器や大型の物は25 CHF（15 CHF）。イタリアとスイスを結ぶTILOの列車ではSBBとTrenordの両方に届け出てください。"
        m["Information from the official Trenord, Trenitalia and SBB pages (October 2026): times and procedures may change."] = "Trenord、Trenitalia、SBBの公式ページの情報（2026年10月）：時間や手続きは変わることがあります。"
        m["Location not available: search a town or station."] = "位置情報を取得できません：市町村か駅を検索してください。"
        m["Search a town or station above."] = "上で市町村か駅を検索してください。"
        m["Looking for defibrillators…"] = "AEDを検索中…"
        m["Looking for defibrillators within "] = "AEDを検索中：範囲 "
        m["Station "] = "駅 "
        m["Station AED: usually on the outside wall, in a marked case"] = "駅のAED：通常は外壁の表示のあるケースの中"
        m["ferrovienord.it · AEDs in all FERROVIENORD stations"] = "ferrovienord.it · すべてのFERROVIENORD駅のAED"
        m["Defibrillator"] = "AED"
        m["Emilia-Romagna regional AED register (open data)"] = "エミリア＝ロマーニャ州のAED登録簿（オープンデータ）"
        m["OpenStreetMap (volunteers): check on site"] = "OpenStreetMap（ボランティア）：現地でご確認ください"
        m["OpenStreetMap servers are not responding: use the official map below or retry."] = "OpenStreetMapのサーバーが応答しません：下の公式地図を使うか、もう一度お試しください。"
        m["Emergency: call "] = "緊急時：通報 "
        m["The operator guides you through CPR and tells you where the nearest AED is. AEDs can be used on children too and give voice instructions."] = "通報を受けた担当者が心肺蘇生を案内し、最寄りのAEDの場所を教えてくれます。AEDは子どもにも使え、音声で指示してくれます。"
        m["Public access"] = "一般利用可"
        m["Always available"] = "常時利用可"
        m["Outdoors"] = "屋外"
        m["Nearby defibrillators"] = "近くのAED"
        m["No defibrillator in the open lists here. Call 112: the dispatch centre knows all registered AEDs and guides you."] = "ここの公開リストにAEDはありません。112に通報してください：指令センターは登録されたすべてのAEDを把握しており、案内してくれます。"
        m["Where to get help nearby"] = "近くで助けを求められる場所"
        m["Emergency departments and pharmacies: many pharmacies have an AED, but it isn't guaranteed."] = "救急外来と薬局：多くの薬局にAEDがありますが、必ずではありません。"
        m["Official maps and sources"] = "公式地図と情報源"
        m["AREU Lombardy · AED map (official)"] = "AREUロンバルディア · AED地図（公式）"
        m["Ticino Cuore · AEDs in Ticino"] = "Ticino Cuore · ティチーノのAED"
        m["FERROVIENORD · station AEDs"] = "FERROVIENORD · 駅のAED"
        m["FERROVIENORD: 125 AEDs installed in 2022–2023 in all its stations, where possible on the outside wall so they can be reached at night, in alarmed cases linked to 112/118 dispatch. Other AEDs come from OpenStreetMap (volunteers): check on site. Trenitalia/RFI, Italo and SBB don't publish a list of station AEDs: ask staff or call 112 (144 in Switzerland)."] = "FERROVIENORD：2022～2023年に全駅で125台のAEDを設置。夜間も使えるよう可能な限り外壁に、112/118指令センターにつながる警報付きケースで設置しています。その他のAEDはOpenStreetMap（ボランティア）によるもの：現地でご確認ください。Trenitalia/RFI、Italo、SBBは駅のAEDリストを公開していません：係員に尋ねるか112（スイスでは144）に通報してください。"
        m["Tap again for directions"] = "もう一度タップで経路案内"
        m["Searched place"] = "検索した場所"
        m["Hospital · ask for help here"] = "病院 · ここで助けを求める"
        m["Pharmacy · ask if they have an AED"] = "薬局 · AEDがあるか尋ねる"
        m["Operator not stated"] = "管理者の記載なし"
        m["Available 24/7"] = "24時間利用可"
        m["Restricted access"] = "利用制限あり"
        m["At or next to a station"] = "駅構内または駅の隣"
        m["Source: "] = "出典： "
        m["Get directions"] = "経路を表示"
        m["View on MapComplete"] = "MapCompleteで見る"
        m["Nearest defibrillator"] = "最寄りのAED"
        m["List and map of AEDs · tap to see them"] = "AEDのリストと地図 · タップして表示"
        m["Complete official list"] = "公式の全リスト"
        m["⏳ Waiting for official AREU data: Binario has asked to use Lombardy's official defibrillator register. Until permission arrives the list below may be incomplete: open the official AREU map to see them all."] = "⏳ AREUの公式データ待ち：Binarioはロンバルディア州の公式AED登録簿の利用を申請しています。許可が出るまで下のリストは不完全な場合があります：すべて見るにはAREUの公式地図を開いてください。"
        m["Below are the AEDs from open lists (OpenStreetMap, FERROVIENORD, Emilia-Romagna register)."] = "以下は公開リスト（OpenStreetMap、FERROVIENORD、エミリア＝ロマーニャ州登録簿）のAEDです。"
        m["Official AREU map"] = "AREU公式地図"
        m["Ticino Cuore map"] = "Ticino Cuoreの地図"
        m["Search Google Maps"] = "Googleマップで検索"
        m["Station coordinates not available: search a town or station."] = "駅の座標がありません：市町村か駅を検索してください。"
        m["Location not available: turn on GPS or search a town or station."] = "位置情報を取得できません：GPSをオンにするか、市町村か駅を検索してください。"
        m["Location permission needed, or search a town or station."] = "位置情報の許可が必要です。または市町村か駅を検索してください。"
        m["Looking for public toilets within"] = "公衆トイレを検索中：範囲"
        m["Place not found: try the town or station name."] = "場所が見つかりません：市町村名か駅名をお試しください。"
        m["Accessible"] = "バリアフリー"
        m["Baby changing"] = "おむつ交換台"
        m["Open to all"] = "誰でも利用可"
        m["near"] = "付近"
        m["No public toilets mapped here with these filters."] = "この条件で地図に登録された公衆トイレはありません。"
        m["Data © OpenStreetMap, the same as the MapComplete \"Public toilets\" map ("] = "データ © OpenStreetMap、MapCompleteの\"公衆トイレ\"地図と同じです（"
        m["Prices, hours and accessibility are entered by volunteers: check on site. If something is wrong you can fix it via \"View on MapComplete\"."] = "料金、営業時間、バリアフリー情報はボランティアが入力しています：現地でご確認ください。誤りがあれば\"MapCompleteで見る\"から修正できます。"
        m["Public toilet"] = "公衆トイレ"
        m["♿ Wheelchair accessible"] = "♿ 車椅子対応"
        m["♿ Partly accessible"] = "♿ 一部バリアフリー"
        m["Not wheelchair accessible"] = "車椅子非対応"
        m["🚼 Baby changing table"] = "🚼 おむつ交換台"
        m["Unisex"] = "男女共用"
        m["Men and women"] = "男性用と女性用"
        m["Men only"] = "男性専用"
        m["Women only"] = "女性専用"
        m["Seated and urinals"] = "洋式と小便器"
        m["Urinals only"] = "小便器のみ"
        m["Squat toilet"] = "和式"
        m["Seated"] = "洋式"
        m["toilet paper"] = "トイレットペーパー"
        m["hand washing"] = "手洗い"
        m["With "] = "あり： "
        m["Customers only"] = "利用客のみ"
        m["Not open to the public"] = "一般非公開"
        m["Level"] = "階"
        m["Operated by"] = "管理者"
        m["Calculation failed"] = "計算に失敗しました"
        m["Edit"] = "編集"
        m["Every day (round trip)"] = "毎日（往復）"
    }

    private fun p4(m: HashMap<String, String>) {
        m["of CO₂ saved"] = "のCO₂を削減"
        m["saved"] = "節約"
        m["extra cost"] = "追加費用"
        m["Travel time (one way)"] = "所要時間（片道）"
        m["avg delay"] = "平均遅延"
        m["Car"] = "車"
        m["free flow"] = "空いている時"
        m["rush hour"] = "ラッシュ時"
        m["Daily breakdown (round trip)"] = "1日あたりの内訳（往復）"
        m["yours"] = "あなたの値"
        m["Road distance"] = "道路距離"
        m["of which tolled"] = "うち有料区間"
        m["Consumption"] = "燃費"
        m["Fuel"] = "燃料"
        m["Motorway tolls"] = "高速道路料金"
        m[" (estimate)"] = " （推定）"
        m["Parking"] = "駐車場"
        m["Car total"] = "車の合計"
        m["Train (daily share of pass)"] = "電車（定期券の1日分）"
        m["Tap an item with ✎ to enter your own value: everything is recalculated at once and saved."] = "✎の付いた項目をタップすると自分の値を入力できます：すぐに再計算され保存されます。"
        m["Car CO₂"] = "車のCO₂"
        m["Train CO₂"] = "電車のCO₂"
        m["CO₂ avoided"] = "削減したCO₂"
        m["Road distance (one way)"] = "道路距離（片道）"
        m["Tolls per day (round trip)"] = "1日の高速料金（往復）"
        m["Fuel price"] = "燃料価格"
        m["Parking per day"] = "1日の駐車料金"
        m["Train pass per month"] = "1か月の電車定期券"
        m["Car consumption"] = "車の燃費"
        m["Back to the app's estimate"] = "アプリの推定値に戻す"
        m["Save and recalculate"] = "保存して再計算"
        m["Trip and delay log"] = "移動と遅延の記録"
        m[" · avg delay "] = " · 平均遅延 "
        m[" · max "] = " · 最大 "
        m["Remove today"] = "今日の記録を削除"
        m["out "] = "往路 "
        m["  back "] = "  復路 "
        m["On travel days after 9 pm the app automatically logs the delays of your usual trains."] = "移動日の21時以降、アプリがいつもの列車の遅延を自動で記録します。"
        m["Your commute"] = "あなたの通勤"
        m["choose"] = "選択"
        m["To: "] = "到着： "
        m["Outbound train"] = "往路の列車"
        m["Return train"] = "復路の列車"
        m["Travel days"] = "移動する曜日"
        m["M"] = "月"
        m["W"] = "水"
        m["T"] = "火"
        m["F"] = "金"
        m["S"] = "土"
        m["Car fuel"] = "車の燃料"
        m["Consumption l/100 km"] = "燃費 l/100 km"
        m["Parking € per day"] = "1日の駐車料金（ユーロ）"
        m["Train pass € per month"] = "1か月の電車定期券（ユーロ）"
        m["Calculate"] = "計算"
        m["A network error occurred. Please try again."] = "ネットワークエラーが発生しました。もう一度お試しください。"
        m[". You can follow the train with voice alerts."] = "。音声通知で列車をフォローできます。"
        m["Ask about a train, station or route"] = "列車、駅、ルートについて質問"
        m["Speech recognition is not available on this phone. Install or enable the Google app."] = "このスマートフォンでは音声認識を利用できません。Googleアプリをインストールするか有効にしてください。"
        m["Read aloud on"] = "読み上げオン"
        m["Read aloud off"] = "読み上げオフ"
        m["Open train"] = "列車を開く"
        m["Following the train. I will give you voice alerts."] = "列車をフォロー中です。音声でお知らせします。"
        m["Follow with voice alerts"] = "音声通知でフォロー"
        m["Open station"] = "駅を開く"
        m["Where is my train?"] = "私の列車はどこ？"
        m["Any strikes?"] = "ストライキはありますか？"
        m["Can I bring my bike?"] = "自転車を持ち込めますか？"
        m["Disability assistance"] = "障がいのある方へのサポート"
        m["e.g. delay train 2070"] = "例：2070列車の遅延"
        m["Speak: ask a question"] = "話す：質問する"
        m["Finding the station…"] = "駅を検索中…"
        m["Search a station or town above."] = "上で駅か市町村を検索してください。"
        m["Location not available: search a station."] = "位置情報を取得できません：駅を検索してください。"
        m["No station found."] = "駅が見つかりません。"
        m["Place not found: try the station name."] = "場所が見つかりません：駅名をお試しください。"
        m["Looking for replacement buses at"] = "代行バスを検索中："
        m["Other operators"] = "その他の鉄道会社"
        m["Replacement bus stop"] = "代行バスの停留所"
        m["Replacement buses in the next 6 hours"] = "今後6時間の代行バス"
        m["Timetable services are not responding: retry or check the official pages below."] = "時刻表サービスが応答しません：もう一度試すか、下の公式ページをご確認ください。"
        m["No replacement buses scheduled here in the next hours according to official timetables. After sudden disruptions buses may not be in the timetables yet: check the official pages and station announcements."] = "公式時刻表によると、今後数時間ここで予定されている代行バスはありません。急な運行障害の直後はバスがまだ時刻表に載っていないことがあります：公式ページと駅の案内をご確認ください。"
        m["Sources: official GTFS timetables of Trenord, Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements."] = "出典：Trenord、Trenitalia、SBBの公式GTFS時刻表（Transitous経由、transitous.org）、発車案内のバスはViaggiaTreno（RFI）から。各便に出典を表示しています。時刻は予定です：運行障害時は駅の案内に従ってください。"
        m["Board at: "] = "乗車場所： "
        m[" from the station"] = " （駅から）"
        m["Bay / platform: "] = "乗り場： "
        m["Real time"] = "リアルタイム"
        m["Scheduled time"] = "予定時刻"
        m["Directions to the stop"] = "停留所への経路"
        m["My region"] = "自分の地域"
        m["My route and times"] = "マイルートと時間"
        m["National strikes and in: "] = "全国のストライキと次の地域： "
        m["back "] = "復路 "
        m["Set your route and the time of your outbound and/or return train"] = "ルートと、往路・復路の列車の時刻を設定してください"
        m["Mon"] = "月"
        m["Tue"] = "火"
        m["Wed"] = "水"
        m["Thu"] = "木"
        m["Fri"] = "金"
        m["Sat"] = "土"
        m["Sun"] = "日"
        m["Mon–Fri"] = "月～金"
        m["every day"] = "毎日"
        m["My route"] = "マイルート"
        m["Out "] = "往路 "
        m["Back "] = "復路 "
        m["No outbound"] = "往路なし"
        m["No return"] = "復路なし"
        m["Days"] = "曜日"
        m["Operators you use"] = "利用する鉄道会社"
        m["Regions (also for the \"My region\" filter)"] = "地域（\"自分の地域\"フィルターにも使用）"
        m["A strike shows in \"My route\" if it is national or in one of your regions, involves one of your operators (or all) and its hours cover your outbound or return train on one of your travel days."] = "ストライキが全国規模または自分の地域で行われ、利用する鉄道会社（または全社）が対象で、その時間帯が移動日の往路か復路の列車にかかる場合、\"マイルート\"に表示されます。"
        m["arrival at "] = "到着 "
        m["Arrival "] = "到着 "
        m["Departure "] = "出発 "
        m["On Xiaomi: Settings → Apps → Binario → Battery saver → No restrictions, and also enable \"Autostart\"."] = "Xiaomiの場合：設定 → アプリ → Binario → バッテリーセーバー → 制限なし。さらに\"自動起動\"も有効にしてください。"
        m["On Oppo, Realme and OnePlus: Settings → Apps → Binario → Battery usage → allow background activity and auto launch."] = "Oppo、Realme、OnePlusの場合：設定 → アプリ → Binario → バッテリー使用量 → バックグラウンド動作と自動起動を許可。"
        m["On Huawei and Honor: Settings → Battery → App launch → Binario → manage manually, with all three options on."] = "HuaweiとHonorの場合：設定 → バッテリー → アプリ起動 → Binario → 手動で管理、3つのオプションをすべてオン。"
        m["On Samsung: Settings → Apps → Binario → Battery → Unrestricted, and remove Binario from \"Sleeping apps\"."] = "Samsungの場合：設定 → アプリ → Binario → バッテリー → 制限なし。さらに\"スリープ中のアプリ\"からBinarioを外してください。"
        m["On Vivo: Settings → Battery → Background power consumption → allow Binario."] = "Vivoの場合：設定 → バッテリー → バックグラウンドでの電力消費 → Binarioを許可。"
        m["If the followed train stops by itself: Settings → Apps → Binario → Battery → Unrestricted."] = "フォロー中の列車が勝手に止まる場合：設定 → アプリ → Binario → バッテリー → 制限なし。"
        m["Alerts even with the app closed"] = "アプリを閉じていても通知"
        m["The train is followed even with Binario closed. Some phones, however, stop the alerts after a while to save battery. To avoid missing platform, delays and the wake-up alarm, allow Binario to run without battery restrictions: consumption stays low and it stops by itself on arrival."] = "Binarioを閉じていても列車はフォローされます。ただし一部のスマートフォンは、バッテリー節約のためしばらくすると通知を止めてしまいます。番線、遅延、降車アラームを見逃さないよう、Binarioをバッテリー制限なしで動作させてください：消費は少なく、到着すると自動で停止します。"
        m["Guide for your phone"] = "お使いのスマートフォン向けガイド"
        m["Not now"] = "今はしない"
        m["Infrastructure manager of the Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa and Brescia–Iseo–Edolo network. Trains are run by Trenord."] = "Milano Cadorna–Saronno–Varese、Como、Novara、Laveno、Asso、Seregno、Malpensa、Brescia–Iseo–Edolo路線網のインフラ管理者。列車はTrenordが運行しています。"
        m["Lifts and escalators out of service"] = "運休中のエレベーターとエスカレーター"
        m["The FERROVIENORD site is not responding. Open the official page or retry."] = "FERROVIENORDのサイトが応答しません。公式ページを開くか、もう一度お試しください。"
        m["No equipment reported out of service."] = "運休中の設備の報告はありません。"
        m["No equipment out of service at this station."] = "この駅に運休中の設備はありません。"
        m["Platform not accessible: "] = "バリアフリーでないホーム： "
        m["Out of service since "] = "運休開始： "
        m["Expected back: "] = "復旧予定： "
        m["Source: ferrovienord.it · Station accessibility notices (read now, refreshed every 30 minutes)."] = "出典：ferrovienord.it · 駅のバリアフリー情報（今読み込み、30分ごとに更新）。"
        m["Accessibility and assistance"] = "アクセシビリティとサポート"
        m["Live lift and escalator status"] = "エレベーターとエスカレーターのリアルタイム状況"
        m["Assistance for disabled passengers: 800 210 955"] = "障がいのある旅行者のサポート：800 210 955"
        m["Trenord/FERROVIENORD free number · book at least 48 hours ahead"] = "Trenord/FERROVIENORDフリーダイヤル · 48時間前までに予約"
        m["Assistance request by email"] = "メールでサポートを依頼"
        m["Book assistance online"] = "オンラインでサポートを予約"
        m["Station accessibility sheets · Milan branches"] = "駅のバリアフリー情報シート · Milano方面"
        m["Station accessibility sheets · Brescia–Iseo–Edolo"] = "駅のバリアフリー情報シート · Brescia–Iseo–Edolo"
        m["Station accessibility and reduced mobility"] = "駅のバリアフリーと移動が困難な方"
        m["Every FERROVIENORD station has a defibrillator (125 installed in 2022–2023): where possible on the outside wall so it can be reached at night, in an alarmed, marked case with a first-aid kit. It is remotely monitored and registered with the regional emergency centres. It can be used on children too. In an emergency call 112."] = "FERROVIENORDの全駅にAEDがあります（2022～2023年に125台設置）：夜間も使えるよう可能な限り外壁に、救急箱付きの警報付き表示ケースで設置。遠隔監視され、州の救急指令センターに登録されています。子どもにも使えます。緊急時は112に通報してください。"
        m["Map of nearby defibrillators"] = "近くのAEDの地図"
        m["FERROVIENORD stations and other AEDs"] = "FERROVIENORDの駅とその他のAED"
        m["Defibrillators page"] = "AEDのページ"
        m["Network documents (PIR web)"] = "路線網の文書（PIR web）"
        m["Service quality indicators 2026"] = "2026年サービス品質指標"
        m["Line and facility characteristics"] = "路線と設備の特性"
        m["Station usage plan"] = "駅の利用計画"
        m["Station upgrades for reduced mobility"] = "移動が困難な方のための駅の改修"
        m["Network statement"] = "ネットワーク・ステートメント"
        m["All documents"] = "すべての文書"
        m["Sources: ferrovienord.it (PIR web, station accessibility notices, defibrillators) and trenord.it (assistance). Restore dates are the manager's estimates."] = "出典：ferrovienord.it（PIR web、駅のバリアフリー情報、AED）とtrenord.it（サポート）。復旧日は管理者による見込みです。"
        m["Customer service"] = "カスタマーサービス"
        m["Validators & more"] = "改札機など"
        m[" (open/closed from Trenord)"] = " （営業状況はTrenordから）"
        m["trenitalia.com · Customer service offices (April 2025 hours)"] = "trenitalia.com · カスタマーサービス窓口（2025年4月の営業時間）"
        m["italotreno.com · Station ticket offices"] = "italotreno.com · 駅の切符売り場"
        m["SBB open data (data.sbb.ch)"] = "SBBオープンデータ（data.sbb.ch）"
        m["Loading sales points…"] = "販売所を読み込み中…"
        m["you"] = "あなた"
        m["nearest to"] = "最寄り："
        m["Trenord sales points are in Lombardy. Nearby: SBB machines, altoadigemobilità and OpenStreetMap points; elsewhere in Italy use the official Trenitalia map (at the bottom)."] = "Trenordの販売所はロンバルディア州にあります。近くの場所：SBBの券売機、altoadigemobilità、OpenStreetMapの地点。イタリアのその他の地域ではTrenitaliaの公式地図（下）をお使いください。"
        m["Open/closed updated now from Trenord for the province of"] = "営業状況をTrenordから今更新しました：対象の県"
        m["No sales points found."] = "販売所が見つかりません。"
        m["Showing the nearest 300: search a town or station for the others."] = "最寄りの300件を表示しています：ほかは市町村か駅で検索してください。"
        m["Distance: "] = "距離： "
        m["Sells: "] = "販売： "
        m["Weekly opening hours"] = "週間の営業時間"
        m["Visit the page"] = "ページを開く"
        m["Card"] = "カード"
        m["Coins"] = "硬貨"
        m[", limited operation"] = "、一部機能のみ"
        m["*Limited operation"] = "*一部機能のみ"
        m["closed"] = "営業時間外"
        m["Trenord offices, machines and resellers"] = "Trenordの窓口、券売機、販売店"
        m["open/closed read now"] = "営業状況を今取得"
        m["SBB ticket machines (data.sbb.ch)"] = "SBBの券売機（data.sbb.ch）"
        m["other points from"] = "その他の地点の出典："
        m["1 machine"] = "券売機1台"
        m["machines"] = "台の券売機"
        m["Overview"] = "概要"
        m["Statistics not available right now."] = "統計は現在利用できません。"
        m["Search station"] = "駅を検索"
        m["Train number or destination"] = "列車番号または行き先"
        m["Least punctual"] = "定時率が低い"
        m["Most punctual"] = "定時率が高い"
        m["FerrovieNord network"] = "FerrovieNord路線網"
        m["Milan Passante"] = "Milano Passante"
        m["collected by the app · "] = "アプリが収集 · "
        m[" days"] = " 日"
        m["No results"] = "結果なし"
        m["on time (within 5 min)"] = "定時（5分以内）"
        m[" points vs "] = " ポイント差、比較： "
        m["arrivals observed"] = "観測した到着数"
        m["cancelled runs"] = "運休便"
        m["Avg delay "] = "平均遅延 "
        m[" arrivals"] = " 件の到着"
        m[" cancelled"] = " 件の運休"
        m[" trains"] = " 本の列車"
        m["Your trains"] = "あなたの列車"
        m["Your stations"] = "あなたの駅"
        m["Switzerland · SBB"] = "スイス · SBB"
        m["SBB data not reachable right now."] = "SBBのデータに現在アクセスできません。"
        m[" stop arrivals"] = " 回の停車駅到着"
        m[" cancelled stops"] = " 回の停車取り消し"
        m["Data for "] = "データ： "
        m["Average of "] = "平均： "
        m[" days ("] = " 日（"
        m["Why BLS, SOB, Rhaetian Railway and the other Swiss companies are missing"] = "BLS、SOB、レーティッシュ鉄道などのスイスの会社がない理由"
        m["FerrovieNord network · Trenord"] = "FerrovieNord路線網 · Trenord"
        m["Collection just started: first data after a few hours, reliable figures after a couple of weeks."] = "収集を始めたばかりです：最初のデータは数時間後、信頼できる数値は2週間ほどで揃います。"
        m["Today's data"] = "本日のデータ"
        m["Last "] = "直近 "
        m[" days collected ("] = " 日分を収集（"
        m["Stations are in the Stations tab (FerrovieNord filter)."] = "駅は駅タブ（FerrovieNordフィルター）にあります。"
        m["Collection on"] = "収集日"
        m[" runs"] = " 便"
        m[" severe delays"] = " 件の大幅遅延"
        m["recent days (collected by the app)"] = "直近の日（アプリが収集）"
        m[" runs observed"] = " 便を観測"
        m["Recent punctuality (FN network): "] = "最近の定時運行率（FN路線網）： "
        m["Last month punctuality: "] = "先月の定時運行率： "
        m["avg delay "] = "平均遅延 "
        m[". On time = arrival within 5 minutes."] = "。定時＝5分以内の到着。"
        m["How shall I find your train? Type its number, or I find the station nearest to you, or pick a station and time."] = "列車をどう探しますか？番号を入力するか、最寄りの駅を探すか、駅と時刻を選んでください。"
        m["No sign-up needed and your data stays on the phone. To send you alerts I need permission for notifications: tap Allow."] = "登録は不要で、データはスマートフォン内に保存されます。通知を送るには通知の許可が必要です：「許可」をタップしてください。"
        m["Without notifications I can only update you here in the app. You can turn them on any time in the phone settings."] = "通知がオフの場合、アプリ内でのみお知らせできます。スマートフォンの設定でいつでもオンにできます。"
        m["I found this train: is it yours?"] = "この列車が見つかりました：これですか？"
        m["I can't connect. Check your connection and try again."] = "接続できません。接続を確認してもう一度お試しください。"
        m["plat. "] = "番線 "
        m["Without location I can't find the nearby station: pick the station yourself."] = "位置情報がないと近くの駅を探せません：駅を選んでください。"
        m["I can't find your location. Turn on location or pick the station."] = "現在地が分かりません。位置情報をオンにするか、駅を選んでください。"
        m["Station list unavailable, try again."] = "駅リストを利用できません。もう一度お試しください。"
        m["I can't answer right now: check your connection."] = "今は回答できません：接続を確認してください。"
        m["They said: "] = "相手の発言： "
        m["Hold the phone close to the speaker"] = "話している人にスマートフォンを近づけてください"
        m["Say the train number or ask a question"] = "列車番号を言うか、質問してください"
        m["Speech recognition isn't available on this phone: install or enable the Google app."] = "このスマートフォンでは音声認識を利用できません：Googleアプリをインストールするか有効にしてください。"
        m["I can't read this train's data right now. Try again shortly."] = "この列車のデータを現在読み込めません。しばらくしてからもう一度お試しください。"
        m["Where do you board?"] = "どこで乗車しますか？"
        m["I'll alert you when the platform is announced or changes, if the delay grows, if the train is cancelled"] = "番線の発表や変更、遅延の拡大、運休のときにお知らせします"
        m[", and on arrival I'll send you a summary. Everything is in the ongoing notification too."] = "。到着時にはまとめをお送りします。すべて常時通知にも表示されます。"
        m["Trip completed: I'm no longer following the train. Want to follow another one?"] = "旅行が終わりました：列車のフォローを終了しました。別の列車をフォローしますか？"
        m["OK, no more updates on this train."] = "わかりました。この列車の通知は終了します。"
        m["Where do you get off? I'll warn you before the stop."] = "どこで降りますか？降車駅の前にお知らせします。"
        m["To the terminus"] = "終点まで"
        m["No alarm needed: follow to the terminus"] = "アラームなし：終点までフォロー"
        m["+1 hour"] = "+1時間"
        m["+2 hours"] = "+2時間"
        m["+3 hours"] = "+3時間"
        m["Pick time"] = "時刻を選ぶ"
        m["Type or say the train number (it's on your ticket or the board)."] = "列車番号を入力するか言ってください（切符や発車案内に記載されています）。"
        m["Station and time"] = "駅と時刻"
        m["Follow another train"] = "別の列車をフォロー"
        m["Delayed? Your rights"] = "遅延？あなたの権利"
        m["Transcribe speech"] = "話した内容を文字にする"
        m["Let the phone speak"] = "スマートフォンに話させる"
        m["Train number, e.g. 2070"] = "列車番号（例：2070）"
        m["Type a train number or a question"] = "列車番号か質問を入力"
        m["Speak"] = "話す"
        m["Which station do you leave from?"] = "どの駅から出発しますか？"
        m["platform "] = "番線 "
        m["platform not yet announced"] = "番線はまだ発表されていません"
        m["Next stop: "] = "次の停車駅： "
        m["Last seen: "] = "最終確認地点： "
        m["They said"] = "相手の発言"
        m["I am deaf: could you please write it down?"] = "耳が聞こえません：書いていただけますか？"
        m["Which platform does the train leave from?"] = "列車は何番線から出ますか？"
        m["Could you tell me when we reach my stop?"] = "私の降りる駅に着いたら教えていただけますか？"
        m["How late is the train?"] = "列車はどのくらい遅れていますか？"
        m["Where can I buy a ticket?"] = "切符はどこで買えますか？"
        m["Show the screen to the person in front of you: the phone is also reading it aloud."] = "目の前の人に画面を見せてください：スマートフォンも読み上げています。"
        m["Type what you want to say"] = "伝えたいことを入力"
        m["Ready phrases"] = "定型文"
        m["Read aloud"] = "読み上げ"
        m["Assistance is free, in the station and for getting on and off the train."] = "サポートは無料で、駅構内と列車の乗り降りで受けられます。"
        m["It covers wheelchair users and people with walking difficulties (even temporary), blind or partially sighted, deaf or with communication difficulties, people with intellectual or mental disabilities, older people and pregnant women."] = "車椅子の方、歩行が困難な方（一時的な場合も含む）、視覚障がいのある方、聴覚障がいやコミュニケーションに困難のある方、知的・精神障がいのある方、高齢者、妊娠中の方が対象です。"
        m["Who to call depends on the station and train: at RFI stations (almost all Italian stations) the Sale Blu assist for every operator; at FerrovieNord stations Trenord does; in Switzerland, SBB."] = "連絡先は駅と列車によって異なります：RFIの駅（イタリアのほぼすべての駅）ではSale Bluが全社の乗客をサポート、FerrovieNordの駅ではTrenord、スイスではSBBです。"
        m["RFI Sale Blu · Trenitalia, Italo, Trenord at RFI stations"] = "RFI Sale Blu · RFIの駅でのTrenitalia、Italo、Trenord"
        m["Toll-free from landlines · daily 6:45–21:30"] = "固定電話から無料 · 毎日6:45～21:30"
        m["From mobiles and abroad (standard rate)"] = "携帯電話と海外から（通常料金）"
        m["At least 6 hours before: stations, date, train, type of assistance, phone"] = "6時間前までに：駅、日付、列車、サポートの種類、電話番号"
        m["SalaBlu Online and SalaBlu+ app"] = "SalaBlu OnlineとSalaBlu+アプリ"
        m["Booking up to 3 hours before; chat for deaf people"] = "3時間前まで予約可能、聴覚障がいのある方向けチャット"
        m["How far ahead: at major stations (e.g. Milano Porta Garibaldi) up to 1 hour before for trains between 7:45 and 22:30; at other stations and at night at least 12 hours before. Groups of 3+: 24 hours. Trips abroad: 24–48 hours."] = "予約期限：主要駅（例：Milano Porta Garibaldi）では7:45～22:30の列車なら1時間前まで、その他の駅と夜間は12時間前まで。3名以上のグループ：24時間前。海外への旅行：24～48時間前。"
        m["Be at the meeting point at least 30 minutes before: staff wear orange vests. To cancel, give at least 4 hours' notice."] = "30分前までに待ち合わせ場所へ：係員はオレンジのベストを着ています。キャンセルは4時間前までにご連絡ください。"
        m["Trenord and FerrovieNord stations"] = "TrenordとFerrovieNordの駅"
        m["Trenord assistance toll-free · book preferably 48 hours ahead"] = "Trenordサポートのフリーダイヤル · できれば48時間前までに予約"
        m["Trenord contact centre (also from mobiles)"] = "Trenordコンタクトセンター（携帯電話からも可）"
        m["Information and bookings"] = "案内と予約"
        m["Report barriers between train and station"] = "列車と駅の間のバリアを報告"
        m["Pronto Italo · daily 7–23: suitable seat and assistance booking (provided in station by RFI)"] = "Pronto Italo · 毎日7～23時：適した座席とサポートの予約（駅でのサポートはRFIが提供）"
        m["Italo assistance page"] = "Italoのサポートページ"
        m["SBB Contact Center Handicap from Italy · daily 5–24 (from Switzerland 0800 007 102, free)"] = "SBB Contact Center Handicap（イタリアから）· 毎日5～24時（スイスからは0800 007 102、無料）"
        m["Book online"] = "オンラインで予約"
        m["swisspass.ch/handicap · at least 1 hour before (international trips 24 hours)"] = "swisspass.ch/handicap · 1時間前まで（国際列車は24時間前）"
        m["Tips by type of disability"] = "障がいの種類別のヒント"
        m["Wheelchair: boarding with ramp or lift. Wheelchair at most 70 cm wide, 120 cm long and 250 kg including the person. The station screen shows lifts per platform and current faults."] = "車椅子：スロープやリフトで乗車。車椅子は幅70 cm、長さ120 cm、人を含めて250 kgまで。駅の画面で番線ごとのエレベーターと現在の故障を確認できます。"
    }

    private fun p5(m: HashMap<String, String>) {
        m["Wi-Fi and sockets: on Frecce and Italo on-board Wi-Fi is free and there are power sockets at the seats. Regional trains usually have no Wi-Fi and only some new trains have sockets. In Switzerland many SBB stations have free Wi-Fi."] = "Wi-Fiとコンセント：FrecceとItaloでは車内Wi-Fiが無料で、座席にコンセントがあります。普通列車には通常Wi-Fiがなく、コンセントは一部の新しい車両のみです。スイスでは多くのSBBの駅で無料Wi-Fiが使えます。"
        m["Seats: on Frecce, Intercity and Italo the seat is assigned with the ticket and you can choose it when buying (window, aisle…). Regional trains (Trenord, Trenitalia Regional, TILO) have no reservations: you sit wherever there is room."] = "座席：Frecce、Intercity、Italoでは切符に座席が指定され、購入時に選べます（窓側、通路側など）。普通列車（Trenord、Trenitaliaの普通列車、TILO）は予約できません：空いている席に座ります。"
        m["First class: Frecciarossa trains have Standard, Premium, Business and Executive levels; Italo has Smart, Comfort, Prima and Club Executive. Many Trenord regional trains have 1st class, with a supplement of €2.80 per trip (€31 a month, €310 a year with a pass). In the search results you can see 1st-class prices with the \"1st class\" selector."] = "1等：FrecciarossaにはStandard、Premium、Business、Executiveの4つのクラスがあり、ItaloにはSmart、Comfort、Prima、Club Executiveがあります。Trenordの普通列車の多くに1等があり、追加料金は1回2.80ユーロ（定期券なら月31ユーロ、年310ユーロ）。検索結果では\"1等\"の切り替えで1等の料金を確認できます。"
        m["Ticket validity: it depends on the ticket. STIBM area (Milan and surroundings): 75 minutes for 2 zones, 90 minutes in the city, longer with more zones. Arcobaleno/Trenord cross-border tickets: 4 hours for the whole trip. Digital regional tickets are valid for the day or train shown; paper ones must be validated before boarding. Frecce and Italo: valid for the booked train."] = "切符の有効期間：切符の種類によります。STIBMエリア（Milanoと周辺）：2ゾーンで75分、市内は90分、ゾーンが増えるほど長くなります。国境を越えるArcobaleno/Trenordの切符：全行程で4時間。デジタルの普通乗車券は記載の日付または列車で有効、紙の切符は乗車前に刻印が必要です。FrecceとItalo：予約した列車のみ有効。"
        m["Parking: many stations have a car park (often paid) and bike racks or bike stations. The app does not list car parks yet: open the map from the station screen and search for \"parking\"."] = "駐車場：多くの駅に駐車場（有料が多い）と駐輪場があります。アプリにはまだ駐車場の一覧がありません：駅の画面から地図を開いて\"駐車場\"を検索してください。"
        m["Night trains: Trenitalia runs Intercity Notte trains (for example to southern Italy and Sicily); ÖBB Nightjets link Italy with Austria and Germany; in Ticino there is the TILO Pigiama night service on some nights. Search the route with an evening time."] = "夜行列車：TrenitaliaはIntercity Notteを運行しています（例：イタリア南部やシチリア行き）。ÖBBのNightjetがイタリアとオーストリア、ドイツを結んでいます。ティチーノでは一部の夜にTILO Pigiamaの深夜便があります。夜の時刻でルートを検索してください。"
        m["Italo (NTV) is the private high-speed operator, on the high-speed lines between Turin, Milan, Venice, Bologna, Florence, Rome and Naples. Tickets are sold on italotreno.com, in the app, at Italo ticket offices and machines in stations; levels are Smart, Comfort, Prima and Club Executive. Binario shows Italo trains in the solutions and in real time. Pronto Italo: 06 07 08."] = "Italo（NTV）は民間の高速鉄道会社で、トリノ、ミラノ、ヴェネツィア、ボローニャ、フィレンツェ、ローマ、ナポリを結ぶ高速線で運行しています。切符はitalotreno.com、アプリ、駅のItalo窓口と券売機で買えます。クラスはSmart、Comfort、Prima、Club Executiveです。BinarioではItaloの列車を経路検索とリアルタイムで確認できます。Pronto Italo：06 07 08。"
        m["Food and drink: on every train you can eat and drink what you bring. Frecce have a bar/FRECCIABistrò, Italo offers snacks and drinks; regional trains have no catering."] = "飲食：すべての列車で持ち込んだものを飲食できます。Frecceにはバー/FRECCIABistròがあり、Italoではスナックと飲み物を販売しています。普通列車には飲食サービスはありません。"
        m["Smoking is forbidden on all trains and in enclosed station areas, e-cigarettes on board included. Smokers risk a fine."] = "すべての列車と駅の屋内では禁煙で、車内での電子タバコも禁止です。喫煙すると罰金の対象になることがあります。"
        m["Discounts: Trenitalia has Economy and Super Economy fares (limited seats), discounts for young people and over-60s with CartaFRECCIA, and group offers. Italo has Low Cost and Economy fares and the Italo Più programme. In Lombardy Trenord has reduced passes for under-26s and over-65s and the Io Viaggio in Famiglia family discount. The app's \"Best prices\" calendar shows the lowest prices by time of day."] = "割引：TrenitaliaにはEconomyとSuper Economy（席数限定）、CartaFRECCIA会員の若者・60歳以上向け割引、団体割引があります。ItaloにはLow Cost、Economyの運賃とItalo Piùプログラムがあります。ロンバルディアではTrenordに26歳未満・65歳以上向けの割引定期券と家族割引Io Viaggio in Famigliaがあります。アプリの\"最安料金\"カレンダーで時間帯ごとの最安値を確認できます。"
        m["Groups: Trenitalia and Italo have group offers (usually from 10 people, to be requested in advance); Trenord has tickets for groups and school classes. Conditions and forms are on the operators' websites."] = "団体：TrenitaliaとItaloには団体割引があります（通常10名以上、事前申し込み）。Trenordには団体・学校向けの切符があります。条件と申込書は各社のサイトにあります。"
        m["Minors travelling alone: the rules differ between operators. In general older children can travel alone with a valid ticket, while young children must be accompanied by an adult. Before travelling check the conditions of carriage of Trenord, Trenitalia or Italo."] = "未成年の一人旅：規則は鉄道会社によって異なります。一般に、年長の子どもは有効な切符があれば一人で乗れますが、幼い子どもは大人の付き添いが必要です。ご旅行前にTrenord、Trenitalia、Italoの運送約款をご確認ください。"
        m["Digital tickets: no need to print them, just show them on your phone (PDF, app or QR code) with enough battery. Some tickets require check-in or activation before boarding: it is stated on the ticket and in the operator's app."] = "デジタル切符：印刷は不要で、スマートフォンで見せれば大丈夫です（PDF、アプリ、QRコード）。バッテリー残量にご注意ください。乗車前にチェックインや有効化が必要な切符もあります：切符と鉄道会社のアプリに記載されています。"
        m["Emergency or safety: call 112, the single emergency number. On board use the intercom or emergency button and tell the conductor; in stations there is the Railway Police (Polfer). For a theft report it to the Polfer or Carabinieri and block your cards and phone. The nearest defibrillator is on the Home screen."] = "緊急時・安全：共通の緊急通報番号112に電話してください。車内ではインターホンか非常ボタンを使い、車掌に知らせてください。駅には鉄道警察（Polfer）がいます。盗難はPolferまたはカラビニエリに届け出て、カードとスマートフォンを止めてください。最寄りのAEDはホーム画面にあります。"
        m["Payments: ticket machines take cards (also contactless) and often cash; apps and websites take cards, PayPal and digital wallets depending on the operator; ticket offices also take cash. On some lines and metros you can tap a contactless card directly at the validators."] = "支払い：券売機はカード（タッチ決済も）に対応し、多くは現金も使えます。アプリとサイトでは鉄道会社によってカード、PayPal、電子ウォレットが使えます。窓口では現金も使えます。一部の路線や地下鉄では、改札機でタッチ決済カードを直接使えます。"
        m["Replacement buses: when trains are replaced by buses, Stations → Replacement buses shows stops, times and sources for your station; notices are in News. The bus stop is usually signposted in front of the station."] = "代行バス：列車がバスで代行されるときは、駅 → 代行バスで、駅ごとの乗り場、時刻、出典を確認できます。お知らせはニュースにあります。バス乗り場は通常、駅前に表示されています。"
        m["Language: tap the flag at the top of the Home screen or go to More → Settings → Language. Italian, English, Chinese, German, French, Spanish and Japanese are available; the voice changes language too."] = "言語：ホーム画面上部の旗をタップするか、その他 → 設定 → 言語へ。イタリア語、英語、中国語、ドイツ語、フランス語、スペイン語、日本語を選べます。音声の言語も切り替わります。"
        m["Favourites: tap the star ★ on a train, a station board or a route. You find them in the Trains and Stations tabs, in Quick (recent and favourites) and in the Favourites widget; you can also add them to the Home shortcuts with +."] = "お気に入り：列車、駅の発車案内、ルートで星★をタップします。列車タブと駅タブ、クイック（最近とお気に入り）、お気に入りウィジェットに表示されます。+でホームのショートカットにも追加できます。"
        m["Searching a timetable: in the Search tab choose departure and arrival, date and time (and return if needed), then tap Search. The results show times, changes, prices and delays; tap a train for stops and platforms. You can also ask me \"trains from Varese to Milano\"."] = "時刻表の検索：検索タブで出発地と到着地、日付と時刻（必要なら復路も）を選び、検索をタップします。結果には時刻、乗り換え、料金、遅延が表示され、列車をタップすると停車駅と番線がわかります。\"VareseからMilanoへの列車\"と質問することもできます。"
        m["Ticket on board: on regional trains you buy the ticket before boarding. If the station has no way to buy one (office closed, machine broken), tell the conductor as soon as you board: usually you can pay with a surcharge, but rules differ between operators. The conditions of carriage say when this is possible and how much it costs."] = "車内での切符購入：普通列車では乗車前に切符を買います。駅で買えない場合（窓口が閉まっている、券売機が故障など）は、乗車したらすぐに車掌に伝えてください。通常は追加料金を払って精算できますが、規則は鉄道会社によって異なります。可能な場合と料金は運送約款に記載されています。"
        m["Blind or partially sighted: guide dogs travel free; you can ask for a suitable seat when booking. Turn on the spoken option: the app tells you platform, departure and your stop."] = "視覚障がいのある方：盲導犬は無料。予約時に適した座席を希望できます。音声オプションをオンにすると、番線、発車、降車駅をアプリがお知らせします。"
        m["Deaf people: the Sale Blu have a chat (after registering on SalaBlu Online). In My Conductor use \"Transcribe speech\" and \"Let the phone speak\"; turn on vibration and flash alerts."] = "聴覚障がいのある方：Sale Bluにはチャットがあります（SalaBlu Onlineに登録後）。マイ車掌では\"話した内容を文字にする\"と\"スマートフォンに話させる\"を使い、振動とフラッシュの通知をオンにしてください。"
        m["Intellectual or mental disabilities, or people who are not self-sufficient: a companion may be needed; staff escort you from the meeting point to the train and connection."] = "知的・精神障がいのある方や介助が必要な方：同伴者が必要な場合があります。係員が待ち合わせ場所から列車、乗り換えまで付き添います。"
        m["Older people, pregnant women, casts or temporary difficulties: assistance is for you too, with a wheelchair on request and help with one piece of hand luggage."] = "高齢者、妊娠中の方、ギプスや一時的な不自由がある方：サポートを受けられます。希望すれば車椅子を用意し、手荷物1個を運ぶ手伝いもします。"
        m["Connections: allow at least 30 minutes between trains when booking assistance."] = "乗り換え：サポートを予約するときは列車間に30分以上空けてください。"
        m["Open My Conductor"] = "マイ車掌を開く"
        m["Emergency"] = "緊急時"
        m["Single emergency number (Italy and Switzerland)"] = "共通の緊急通報番号（イタリアとスイス）"
        m["Numbers and rules from the official RFI, Trenord, Italo and SBB pages (October 2026): if in doubt, check the operator's site."] = "RFI、Trenord、Italo、SBBの公式ページの番号と規則（2026年10月）：不明な点は鉄道会社のサイトでご確認ください。"
        m["Page"] = "ページ"
        m["Changes"] = "乗り換え"
        m["direct"] = "直通"
        m["Downloading outbound…"] = "往路をダウンロード中…"
        m["Downloading return…"] = "復路をダウンロード中…"
        m["No runs found for that day"] = "その日の便が見つかりません"
        m["Timetable for"] = "時刻表："
        m["runs"] = "便"
        m["No runs found."] = "便が見つかりません。"
        m["Real time from the operator · "] = "鉄道会社のリアルタイム情報 · "
        m["Scheduled times: delays not published by the operator · "] = "予定時刻：遅延は鉄道会社が公開していません · "
        m["Departure station not found"] = "出発駅が見つかりません"
        m["Arrival station not found"] = "到着駅が見つかりません"
        m["responds but the format changed"] = "応答はありますが形式が変わっています"
        m["OK (backup server: "] = "OK（予備サーバー： "
        m["no response"] = "応答なし"
        m["Foreign operators (ÖBB, DB)"] = "海外の鉄道会社（ÖBB、DB）"
        m["Replacement bus"] = "代行バス"
        m["SBB timetable (transport.opendata.ch)"] = "SBB時刻表（transport.opendata.ch）"
        m["ViaggiaTreno (RFI) · station board"] = "ViaggiaTreno（RFI）· 駅の発車案内"
        m["Trenord · replacement bus map"] = "Trenord · 代行バスの地図"
        m["RFI · travel updates (works and replacement buses)"] = "RFI · 運行情報（工事と代行バス）"
        m["SBB · S-Bahn and regional"] = "SBB · Sバーンと普通列車"
        m["SBB · InterRegio, InterCity, EuroCity"] = "SBB · InterRegio、InterCity、EuroCity"
        m[" · guaranteed band 6–9 / 18–21"] = " · 保証時間帯 6～9時／18～21時"
        m["Incomplete download"] = "ダウンロードが不完全です"
        m["accessible"] = "バリアフリー"
        m["tactile paving"] = "点字ブロック"
        m["steps"] = "段差"
        m["handrail"] = "手すり"
        m["level "] = "階 "
        m["Hospital"] = "病院"
        m["Pharmacy"] = "薬局"
        m["emergency department"] = "救急外来"
        m["hospital"] = "病院"
        m["pharmacy"] = "薬局"
        m["You are not following any train. Ask for example \"train 2512\" and then tap \"Follow with voice alerts\"."] = "フォロー中の列車はありません。たとえば\"2512列車\"と質問し、\"音声通知でフォロー\"をタップしてください。"
        m["Which station? Ask for example \"bus and taxi at Varese\"."] = "どの駅ですか？たとえば\"Vareseのバスとタクシー\"と質問してください。"
        m["Which station? Ask for example \"toilets at Saronno\"."] = "どの駅ですか？たとえば\"Saronnoのトイレ\"と質問してください。"
        m["Tell me the train number, for example \"delay train 2512\" or \"platform of 9544\"."] = "列車番号を教えてください。たとえば\"2512列車の遅延\"や\"9544の番線\"。"
        m["Sorry, I didn't understand. Try one of these topics: "] = "すみません、わかりませんでした。次の話題を試してください： "
        m["lines "] = "路線 "
        m["Toilets: not mapped"] = "トイレ：地図に未登録"
        m["Toilets: "] = "トイレ： "
        m[", accessible"] = "、バリアフリー"
        m[", hours "] = "、営業時間 "
        m["Platforms: "] = "番線： "
        m["Lifts: "] = "エレベーター： "
        m["Ticket office: "] = "切符売り場： "
        m["Ticket machines: "] = "券売機： "
        m["Validators: "] = "改札機： "
        m["Station data not reachable now."] = "駅のデータに現在アクセスできません。"
        m["Train cancelled."] = "列車は運休です。"
        m["Arrived"] = "到着しました"
        m["Running on time."] = "定刻で運行中。"
        m[" (scheduled)"] = " （予定）"
        m[", platform not yet announced"] = "、番線はまだ発表されていません"
        m[" · scheduled platform "] = " · 予定番線 "
        m[" · actual "] = " · 実際 "
        m[" · CANCELLED"] = " · 運休"
        m[" · on time"] = " · 定刻"
        m[" · plat. "] = " · 番線 "
        m["Timetable service unreachable."] = "時刻表サービスにアクセスできません。"
        m[" plat."] = " 番線"
        m["No rail strikes announced (source: Italian Ministry strike observatory)."] = "予定されている鉄道ストライキはありません（出典：イタリア省庁のストライキ監視機関）。"
        m["Announced rail strikes:\n"] = "予定されている鉄道ストライキ：\n"
        m["\n\nGuaranteed trains: More → Guaranteed trains."] = "\n\n保証列車：その他 → 保証列車。"
        m["Strike observatory unreachable."] = "ストライキ監視機関にアクセスできません。"
        m["No traffic disruptions reported right now."] = "現在、運行障害の報告はありません。"
        m["Take a few seconds to write the message."] = "メッセージを書くのに少し時間をかけてください。"
        m["You just sent a message: wait a few minutes before the next one."] = "メッセージを送信したばかりです：次の送信まで数分お待ちください。"
        m["This message has already been sent."] = "このメッセージはすでに送信済みです。"
        m["Too many links in the message: at most 2."] = "メッセージ内のリンクが多すぎます：最大2つまでです。"
        m["The message does not look like text: describe the problem or suggestion in words."] = "メッセージが文章になっていないようです：問題や提案を言葉で説明してください。"
        m["Information, help during disruption, reduced mobility, Carta Blu, complaints"] = "案内、運行障害時の支援、移動が困難な方、Carta Blu、苦情"
        m["Italo tickets, changes, refunds and help"] = "Italoの切符、変更、払い戻し、サポート"
        m["Italo ticket machines (unstaffed)"] = "Italoの券売機（無人）"
        m["TILO/SBB and Arcobaleno tickets, passes, information and help"] = "TILO/SBBとArcobaleno の切符、定期券、案内、サポート"
        m["Live data not yet available"] = "リアルタイムデータはまだありません"
        m["Departed"] = "出発済み"
        m[" changes"] = " 回乗り換え"
        m["Downloading South Tyrol ticket outlets…"] = "南チロルの切符販売所をダウンロード中…"
        m["Locating outlets…"] = "販売所の位置を特定中…"
        m["Downloading Trenord sales points…"] = "Trenordの販売所をダウンロード中…"
        m["Downloading ticket office hours…"] = "切符売り場の営業時間をダウンロード中…"
        m["Downloading the sales points list…"] = "販売所リストをダウンロード中…"
        m["Downloading the sellers list…"] = "販売店リストをダウンロード中…"
        m["Ticket machine"] = "券売機"
        m["Price you entered"] = "入力した料金"
        m["platform not accessible: "] = "バリアフリーでない番線： "
        m["expected back on "] = "復旧予定日 "
        m["Band from the official regional ticket price"] = "公式の普通乗車券料金から算出した距離帯"
        m["delay compensation"] = "遅延補償"
        m["bikes on trains"] = "列車への自転車の持ち込み"
        m["children"] = "子ども"
        m["disability assistance"] = "障がいのある方へのサポート"
        m["lost property"] = "忘れ物"
        m["ticket validation"] = "切符の刻印"
        m["bus and taxi at Varese"] = "Vareseのバスとタクシー"
        m["toilets at Saronno"] = "Saronnoのトイレ"
        m["\nLast reported: "] = "\n最後の報告： "
        m["\nNext: "] = "\n次： "
        m["on time"] = "定刻"
        m["FN network"] = "FN路線網"
        m["Departure and arrival reminders"] = "出発と到着のリマインダー"
        m["Disruptions on favourite routes and lines"] = "お気に入りのルートと路線の運行障害"
        m["Stop alarm"] = "降車アラーム"
        m["Board at "] = "乗車： "
        m[" at "] = " 時刻 "
        m[" · platform "] = " · 番線 "
        m["Alarm before "] = "アラーム： "
        m["Data temporarily unavailable"] = "データを一時的に利用できません"
        m[" on time."] = " 定刻。"
        m["\nWith a delay of 60 minutes or more you can claim compensation: see More › Conditions, rights and refunds."] = "\n60分以上の遅延の場合は補償を請求できます：その他 › 運送約款、権利、払い戻しをご覧ください。"
        m["\nIf you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation."] = "\n定期券をお持ちの場合、遅延は月間ボーナス（Trenord）や補償に反映されます。"
        m["\nI've stopped following the train. Have a good day!"] = "\n列車のフォローを終了しました。よい一日を！"
        m["trip completed"] = "旅行完了"
        m["Platform change"] = "番線変更"
        m["Wake up! Next stop: "] = "起きてください！次の停車駅： "
        m["Expected arrival at "] = "到着予定時刻 "
        m["Expected departure at "] = "発車予定時刻 "
        m["Arrival at "] = "到着： "
        m["Departure from "] = "出発： "
        m["Warning: the train is cancelled"] = "注意：列車は運休です"
        m["Follow train"] = "列車をフォロー"
        m["cancelled"] = "運休"
        m["It is cancelled."] = "運休です。"
        m["Back on time."] = "定刻に戻りました。"
        m["Alternatives:"] = "代替案："
        m["No alternative found soon: open the app for more options."] = "すぐに乗れる代替案が見つかりません：アプリを開いてほかの選択肢をご確認ください。"
        m["Refreshing widget…"] = "ウィジェットを更新中…"
        m["refreshing…"] = "更新中…"
        m["Tap to set up"] = "タップして設定"
        m["Tap the title to choose what to show"] = "タイトルをタップして表示内容を選択"
        m["Tap ⟳ to refresh"] = "⟳をタップして更新"
        m["Refreshes automatically · ⟳ to retry"] = "自動で更新 · ⟳で再試行"
        m["not updated"] = "未更新"
        m["Data service temporarily unreachable"] = "データサービスに一時的にアクセスできません"
        m["Tap ⟳ to retry"] = "⟳をタップして再試行"
        m["No departures in the next hours"] = "今後数時間の発車はありません"
        m["The widget refreshes itself; tap ⟳ to retry"] = "ウィジェットは自動で更新されます。⟳をタップして再試行"
        m["First departures"] = "始発"
        m["No trains now: here are the first scheduled"] = "現在列車はありません：最初の予定便はこちら"
        m[" · not updated"] = " · 未更新"
        m["Status not available yet"] = "状況はまだわかりません"
        m["Resume following "] = "フォローを再開： "
        m["The phone restarted: tap to keep receiving platform, delay and arrival alerts."] = "スマートフォンが再起動しました：番線、遅延、到着の通知を受け取り続けるにはタップしてください。"
        m["is cancelled."] = "は運休です。"
        m["Search by voice"] = "音声で検索"
        m["OpenStreetMap servers are not responding. Try again shortly or search Google Maps."] = "OpenStreetMapのサーバーが応答しません。しばらくしてからもう一度試すか、Googleマップで検索してください。"
        m["Set up"] = "設定"
        m["Share train status"] = "列車の状況を共有"
        m["Other apps"] = "その他のアプリ"
        m["Resellers"] = "販売店"
        m["Mooney points"] = "Mooney取扱店"
        m["list from"] = "リスト出典："
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney points: see the official Trenitalia map."] = "イタリアのその他の地域では、Trenitaliaの普通乗車券はPuntoLISとMooneyの取扱店で販売されています：Trenitaliaの公式地図をご覧ください。"
        m["Official Trenitalia map (all Italy)"] = "Trenitalia公式地図（イタリア全土）"
        m["No data for this station. TrovaTreno does not publish the FerrovieNord network: for those stations the app collects arrivals from ViaggiaTreno by itself and data appears here after a few hours."] = "この駅のデータはありません。TrovaTrenoはFerrovieNord路線網を公開していないため、これらの駅ではアプリがViaggiaTrenoから到着情報を自分で収集し、数時間後にここに表示されます。"
        m["Average delay "] = "平均遅延 "
        m["Each box compares only services of the same kind. Based on trains with at least 30 observed arrivals in the month; runs without a category are not included. Regional operators other than Trenord and Trenitalia (Tper, EAV, Ferrovie del Gargano, TUA, BLS…) are identified by route and train number; only those running on the RFI network tracked by ViaggiaTreno are included."] = "各枠は同じ種類の列車だけを比較しています。その月に到着を30回以上観測した列車が対象で、種別のない便は含みません。TrenordとTrenitalia以外の地域鉄道会社（Tper、EAV、Ferrovie del Gargano、TUA、BLSなど）は経路と列車番号で識別し、ViaggiaTrenoが追跡するRFI路線網を走るものだけを含めています。"
        m["SBB counts a train as punctual under 3 minutes late (5 in Italy), so the comparison with Italy is conservative. SBB publishes only the previous day: the app collects one per day."] = "SBBは3分未満の遅れを定時とみなします（イタリアは5分）。そのためイタリアとの比較は控えめです。SBBは前日分のみを公開するため、アプリは1日1回収集します。"
        m["Their actual times exist as open data (opentransportdata.swiss, \"Ist-Daten\"), but only as a single daily file with all Swiss public transport: hundreds of MB, to be downloaded every day. On a phone that would use too much data and battery, and there is no service returning per-company totals as SBB does. They can be added in future if such a service appears, or with a small server that downloads the file and prepares the totals for the app."] = "実際の運行時刻はオープンデータ（opentransportdata.swiss、\"Ist-Daten\"）として存在しますが、スイスの全公共交通を含む1日1つのファイルとしてのみ提供されています：数百MBを毎日ダウンロードする必要があります。スマートフォンではデータ通信量とバッテリーを使いすぎるうえ、SBBのように会社別の合計を返すサービスもありません。そのようなサービスが現れるか、ファイルをダウンロードして合計を用意する小さなサーバーがあれば、今後追加できます。"
        m["TrovaTreno does not publish the FerrovieNord network. The app reads arrivals from ViaggiaTreno by itself: every 80 minutes on Wi-Fi, every 3 hours on mobile data (about 0.3 MB). On time = within 5 minutes. Figures depend on when the phone is on and connected."] = "TrovaTrenoはFerrovieNord路線網を公開していません。アプリがViaggiaTrenoから到着情報を自分で読み込みます：Wi-Fiでは80分ごと、モバイルデータでは3時間ごと（約0.3 MB）。定時＝5分以内。数値はスマートフォンの電源と接続の状況によって変わります。"
        m["Hi, I'm your Conductor! 🚆 I keep you posted about your train before, during and after the trip: platform, delays, platform changes, cancellations, next stops and arrival. It works with all trains: Trenord, Trenitalia, FerrovieNord, Italo, TILO and SBB."] = "こんにちは、あなたの車掌です！🚆 旅行の前・最中・後に、番線、遅延、番線変更、運休、次の停車駅、到着など、乗る列車の最新情報をお知らせします。Trenord、Trenitalia、FerrovieNord、Italo、TILO、SBBのすべての列車に対応しています。"
        m["Departs"] = "出発"
        m["Arrives"] = "到着"
        m["Italy"] = "イタリア"
        m["International"] = "国際"
        m["Long distance"] = "長距離"
        m["Regional and long distance"] = "普通列車と長距離"
        m["Real time: ViaggiaTreno (RFI network)"] = "リアルタイム：ViaggiaTreno（RFI路線網）"
        m["Real time: official Swiss timetable"] = "リアルタイム：スイス公式時刻表"
        m["Real time only on the company's site/app"] = "リアルタイムは会社のサイト・アプリのみ"
        m["Scheduled times in the app (Transitous); real time only on the company's site/app"] = "アプリでは予定時刻（Transitous）、リアルタイムは会社のサイト・アプリのみ"
        m["Regional and suburban"] = "普通列車と近郊列車"
        m["Intercity and long distance"] = "Intercityと長距離列車"
        m["Plenty of seats"] = "空席多数"
        m["Moderately busy: look for seats"] = "やや混雑：空席を探してください"
        m["Very crowded"] = "非常に混雑"
        m["Trenord (sensors or previous days' history)"] = "Trenord（センサーまたは過去の履歴）"
        m["SBB forecast"] = "SBBの予測"
        m["Binario estimate by time of day"] = "時間帯によるBinarioの推定"
        m["I can help with:\n• \"delay train 2070\" or \"where is 9544\"\n• \"trains from Varese to Milano\"\n• \"departures from Varese\" / \"arrivals at Como\"\n• \"any strikes?\"\n• \"traffic on S5\" / \"problems at Saronno\"\n• \"elevators at Saronno\"\n• \"guaranteed trains\"\n• \"where is my train?\" (the train you follow)\n• \"next train to Milano\"\n• \"bus, metro and taxi at Milano Centrale\"\n• \"toilets at Saronno\" / \"services at Varese\"\n• \"delay compensation\", \"can I bring my bike?\", \"children\", \"disability assistance\", \"lost property\"\nTap the microphone to ask by voice."] = "次のようなことをお手伝いできます：\n• \"2070列車の遅延\"、\"9544はどこ\"\n• \"VareseからMilanoへの列車\"\n• \"Vareseの出発\" / \"Comoの到着\"\n• \"ストライキはありますか？\"\n• \"S5の運行状況\" / \"Saronnoの問題\"\n• \"Saronnoのエレベーター\"\n• \"保証列車\"\n• \"私の列車はどこ？\"（フォロー中の列車）\n• \"Milano行きの次の列車\"\n• \"Milano Centraleのバス、地下鉄、タクシー\"\n• \"Saronnoのトイレ\" / \"Vareseの設備\"\n• \"遅延補償\"、\"自転車を持ち込めますか？\"、\"子ども\"、\"障がいのある方へのサポート\"、\"忘れ物\"\nマイクをタップすると音声で質問できます。"
        m["During regional rail strikes trains are normally guaranteed 6:00–9:00 and 18:00–21:00 on weekdays (7:00–10:00 and 18:00–21:00 on holidays). Updated official lists are in More → Guaranteed trains."] = "普通列車のストライキ中は、通常、平日6:00～9:00と18:00～21:00（休日は7:00～10:00と18:00～21:00）の列車が保証されます。最新の公式リストはその他 → 保証列車にあります。"
        m["yes"] = "はい"
        m[", platform not yet shown"] = "、番線はまだ表示されていません"
        m["Delay compensation (EU Regulation 2021/782):\n• 60–119 minutes late on arrival: 25% of the ticket\n• 120 minutes or more: 50%\n• Trenitalia Frecce: compensation also for 30–59 minutes, under Trenitalia's conditions\n• season tickets: own rules (Trenord gives season-ticket bonuses based on line punctuality)\nIf the expected delay exceeds 60 minutes you can also give up the trip with a full refund or be re-routed. The train screen shows whether you are entitled to compensation."] = "遅延補償（EU規則2021/782）：\n• 到着時に60～119分の遅れ：切符代の25%\n• 120分以上：50%\n• TrenitaliaのFrecce：Trenitaliaの約款により30～59分の遅れでも補償あり\n• 定期券：独自の規則（Trenordは路線の定時運行率に応じて定期券利用者に割引を提供）\n予想遅延が60分を超える場合は、全額払い戻しで旅行を取りやめるか、別経路に変更することもできます。補償を受けられるかどうかは列車の画面に表示されます。"
        m["Ticket refund or change: it depends on the fare (cheap offers are often non-refundable). Trenitalia: request on the website or app with the ticket code (PNR). Trenord: from the refunds page. If the train is cancelled or expected more than 60 minutes late a refund is always due."] = "切符の払い戻しや変更：運賃によります（割引運賃は払い戻しできないことが多いです）。Trenitalia：サイトかアプリで切符のコード（PNR）を使って申請。Trenord：払い戻しのページから。列車が運休した場合や60分を超える遅延が見込まれる場合は、必ず払い戻しを受けられます。"
        m["Validation: paper regional tickets without date and time must be validated before boarding (validating machine in the station). Digital tickets bought online or in the app already show the train or the day: check on the ticket whether check-in is needed. The nearest validators are in Stations → station → Overview, or More → Nearby resellers."] = "刻印：日付と時刻のない紙の普通乗車券は、乗車前に駅の刻印機で刻印する必要があります。オンラインやアプリで購入したデジタル切符には列車や日付がすでに記載されています：チェックインが必要か切符でご確認ください。最寄りの刻印機は駅 → 駅名 → 概要、またはその他 → 近くの販売店にあります。"
        m["Without a valid ticket you pay the fare plus a fine; amounts and how to pay (reduced if you pay at once or within a few days) are in the operator's conditions of carriage. If the ticket machine was broken, tell the conductor straight away."] = "有効な切符がない場合は運賃に加えて罰金を支払います。金額と支払い方法（その場や数日以内に払うと減額）は鉄道会社の運送約款に記載されています。券売機が故障していた場合は、すぐに車掌に伝えてください。"
        m["Bikes and scooters:\n• Trenord (Lombardy): regular, folding, electric bikes and scooters travel free on all trains, at any time, space permitting\n• Trenitalia Regional: usually on trains with the bike symbol, with a supplement\n• Frecce and Italo: normally only folded bikes in a bag\n• TILO: SBB rules in Ticino, Trenord rules in Lombardy"] = "自転車とキックボード：\n• Trenord（ロンバルディア）：通常の自転車、折りたたみ自転車、電動自転車、キックボードは、スペースがあればすべての列車でいつでも無料\n• Trenitalia Regionale：通常は自転車マークのある列車で、追加料金が必要\n• FrecceとItalo：通常は袋に入れた折りたたみ自転車のみ\n• TILO：ティチーノではSBBの規則、ロンバルディアではTrenordの規則"
        m["Pets on trains:\n• Trenord: free within Lombardy (carrier max 70×30×50 cm; dogs with muzzle, leash and registry certificate); not allowed on weekdays 7:00–9:30 and 17:30–19:30; beyond Lombardy an animal supplement is needed\n• Trenitalia: carrier free; on regional trains large dogs pay 50% of 2nd class; on Frecce and Intercity add \"Travel with your dog\" when buying\n• Italo: free up to about 5 kg in a carrier; larger dogs with the \"Dog\" service in Smart and Prima\n• SBB/TILO: free up to 30 cm in a bag; otherwise half fare or dog day pass CHF 25\n• Guide and assistance dogs: always free. Details in More → Travelling with pets."] = "列車でのペット：\n• Trenord：ロンバルディア州内は無料（キャリー最大70×30×50 cm、犬は口輪・リード・登録証明書が必要）。平日7:00～9:30と17:30～19:30は乗車不可。州外へは動物の追加料金が必要\n• Trenitalia：キャリーは無料。普通列車では大型犬は2等の50%、FrecceとIntercityでは購入時に\"犬と一緒に旅行\"を追加\n• Italo：キャリーに入った約5 kgまでは無料。大型犬はSmartとPrimaで\"Dog\"サービスを利用\n• SBB/TILO：バッグに入る体高30 cmまでは無料。それ以外は半額か犬用1日券25 CHF\n• 盲導犬と介助犬：常に無料。詳しくはその他 → ペットと旅行。"
        m["Children:\n• Regional trains in Lombardy: free under 4 without a seat, 50% off from 4 to under 14\n• Trenitalia national trains: free under 4 without a seat, 50% off the Base fare from 4 to under 15\n• Other regions and Italo have their own rules"] = "子ども：\n• ロンバルディアの普通列車：座席を使わない4歳未満は無料、4歳以上14歳未満は50%割引\n• Trenitaliaの全国列車：座席を使わない4歳未満は無料、4歳以上15歳未満はBase運賃の50%割引\n• ほかの地域とItaloには独自の規則があります"
        m["Assistance for people with disabilities or reduced mobility:\n• RFI Sala Blu (RFI stations): 800 90 60 60, from mobiles +39 02 32 32 32\n• Trenord: 800 210 955 (daily 8:15–19:45) or +39 02 72 49 49 49; book preferably 48 hours ahead\n• SBB (Ticino): 0800 007 102\nThe station screen shows lifts per platform and current faults."] = "障がいのある方や移動が困難な方へのサポート：\n• RFI Sala Blu（RFIの駅）：800 90 60 60、携帯電話から +39 02 32 32 32\n• Trenord：800 210 955（毎日8:15～19:45）または +39 02 72 49 49 49。できれば48時間前までに予約\n• SBB（ティチーノ）：0800 007 102\n駅の画面で番線ごとのエレベーターと現在の故障を確認できます。"
        m["Lost property: tell the conductor straight away. Trenord: 02 72 49 49 49, items kept at the Cadorna and Garibaldi My Link Points for a few days, then at the City of Milan office (via Friuli 30). Trenitalia: lost items search service and Frecciadesk. Italo: Pronto Italo 06 07 08. SBB/TILO: report online at lostandfound.sbb.ch. Details in More → Lost property."] = "忘れ物：すぐに車掌に伝えてください。Trenord：02 72 49 49 49。拾得物はCadornaとGaribaldiのMy Link Pointで数日間保管され、その後Milano市の窓口（via Friuli 30）へ。Trenitalia：忘れ物検索サービスとFrecciadesk。Italo：Pronto Italo 06 07 08。SBB/TILO：lostandfound.sbb.chからオンラインで届け出。詳しくはその他 → 忘れ物。"
        m["Strikes and tickets: Trenord refunds on request within 30 days of the strike. Trenitalia refunds from the announcement: Frecce and Intercity up to departure time, regional trains until midnight of the day before. In the guaranteed time bands (weekdays 6–9 and 18–21) the trains on the official list run."] = "ストライキと切符：Trenordはストライキ後30日以内の申請で払い戻します。Trenitaliaは発表時から払い戻しが可能：FrecceとIntercityは出発時刻まで、普通列車は前日の24時まで。保証時間帯（平日6～9時と18～21時）は公式リストの列車が運行します。"
        m["Cancelled train: you are entitled to a full refund or to travel on the first available train to the same destination. A replacement bus is often provided: see the notices (More → Strikes, traffic and works). Tell me the train number to check it."] = "運休になった列車：全額払い戻しか、同じ目的地への最初の列車での移動を選べます。代行バスが用意されることも多いです：お知らせ（その他 → ストライキ、運行状況、工事）をご確認ください。確認するには列車番号を教えてください。"
        m["Missed connection because of a delay: with a single ticket you can continue on the first available train at no extra cost. For journeys with a change the app shows the minutes to change and warns \"connection at risk\" if the first train is late."] = "遅延で乗り継ぎに間に合わなかった場合：1枚の切符なら、追加料金なしで最初の列車に乗って旅行を続けられます。乗り換えのある経路では、アプリが乗り換え時間を表示し、最初の列車が遅れると\"乗り換えが危うい\"と警告します。"
        m["Luggage: you travel with your own bags in the luggage spaces at no cost for normal use; they must stay under your control and not block aisles and doors. Large stations often have a paid left-luggage office."] = "手荷物：通常の範囲であれば、自分の荷物を荷物スペースに置いて無料で旅行できます。荷物は自分で管理し、通路やドアをふさがないでください。大きな駅には有料の手荷物預かり所があることが多いです。"
        m["Tickets: on the official websites and apps (Trenitalia, Trenord, Italo), at ticket offices and machines in the station, and at authorised resellers (tobacconists, newsagents). More → Nearby resellers shows ticket offices, machines (also contactless) and resellers near you."] = "切符：公式サイトとアプリ（Trenitalia、Trenord、Italo）、駅の窓口と券売機、正規販売店（タバコ店、売店）で購入できます。その他 → 近くの販売店で、近くの窓口、券売機（タッチ決済対応も）、販売店を確認できます。"
        m["Season tickets: Trenord offers monthly and annual tickets and the integrated Io Viaggio passes (train + public transport in Lombardy). Trenitalia has regional and Frecce passes. Season-ticket holders have their own refund and delay-bonus rules."] = "定期券：Trenordには月間・年間定期券と、共通定期券Io Viaggio（列車＋ロンバルディアの公共交通）があります。Trenitaliaには普通列車とFrecceの定期券があります。定期券利用者には独自の払い戻しと遅延割引の規則があります。"
        m["Airports:\n• Malpensa: Malpensa Express from Milano Cadorna and Milano Centrale, stops T1 and T2\n• Linate: metro line M4 (no train)\n• Orio al Serio (Bergamo): bus from Bergamo station\nAsk me for example \"trains from Milano Cadorna to Malpensa\"."] = "空港：\n• Malpensa：Milano CadornaとMilano CentraleからMalpensa Express、T1とT2に停車\n• Linate：地下鉄M4線（列車なし）\n• Orio al Serio（Bergamo）：Bergamo駅からバス\nたとえば\"Milano CadornaからMalpensaへの列車\"と質問してください。"
        m["Switzerland and TILO: trips between Lombardy and Ticino need cross-border tickets (Arcobaleno in CHF or Trenord in euros). TILO lines, fares and services are in More → TILO; for a route ask \"trains from Como to Lugano\"."] = "スイスとTILO：ロンバルディアとティチーノの間の移動には国境を越える切符（CHFのArcobalenoまたはユーロのTrenord）が必要です。TILOの路線、運賃、サービスはその他 → TILOにあります。区間を調べるには\"ComoからLuganoへの列車\"と質問してください。"
        m["Contacts:\n• Trenitalia: 892021 (call centre)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (disability assistance): 800 90 60 60\nFor complaints use the forms on the official websites."] = "連絡先：\n• Trenitalia：892021（コールセンター）\n• Trenord：+39 02 72 49 49 49\n• Italo：892020\n• RFI Sala Blu（障がいのある方へのサポート）：800 90 60 60\n苦情は公式サイトのフォームをご利用ください。"
        m["Your rights (EU Regulation 2021/782): travel information, refund or re-routing if the expected delay exceeds 60 minutes, compensation of 25% (60–119 minutes) or 50% (120+), assistance (drinks, meals, accommodation if needed), free assistance for people with disabilities."] = "あなたの権利（EU規則2021/782）：運行情報、予想遅延が60分を超える場合の払い戻しまたは経路変更、25%（60～119分）または50%（120分以上）の補償、支援（飲み物、食事、必要に応じて宿泊）、障がいのある方への無料サポート。"
        m["Platforms in the app: the scheduled platform comes from the timetable; the actual one (blue) is confirmed by the station. A change is shown in red (e.g. 3 → 5) and, if you follow the train, you get a notification and a voice alert."] = "アプリの番線：予定番線は時刻表から、実際の番線（青）は駅が確定したものです。変更は赤で表示され（例：3 → 5）、列車をフォローしていれば通知と音声でお知らせします。"
        m["Stop alarm: open the train, tap the stop where you get off and choose \"Wake me before this stop\". It rings when the train leaves the previous stop (or 4 minutes before); with voice alerts you also hear the voice."] = "降車アラーム：列車を開き、降りる駅をタップして\"この駅の前に起こして\"を選びます。列車が前の駅を出発したとき（または4分前）に鳴ります。音声通知がオンなら音声も流れます。"
        m["Where I board: open the train, tap the stop where you get on and choose \"I board here\". Platform, time and alerts refer to that stop."] = "乗車駅：列車を開き、乗る駅をタップして\"ここで乗車\"を選びます。番線、時刻、通知はその駅のものになります。"
        m["Timetables offline: search the route and tap the PDF icon in the results to download the day's timetable (outbound and return) to Download/Binario. The app also remembers the latest times of every route you searched."] = "オフライン時刻表：ルートを検索し、結果のPDFアイコンをタップすると、その日の時刻表（往路と復路）をDownload/Binarioにダウンロードできます。アプリは検索したすべてのルートの最新の時刻も記憶しています。"
        m["Voice alerts: in Settings → Accessibility choose \"All\" or \"Only upcoming stop\". To ask by voice tap the microphone below, or long-press the Binario icon and choose \"Ask by voice\"."] = "音声通知：設定 → アクセシビリティで\"すべて\"または\"次の停車駅のみ\"を選びます。音声で質問するには下のマイクをタップするか、Binarioのアイコンを長押しして\"音声で質問\"を選びます。"
        m["Alerts for deaf people: in Settings → Accessibility turn on strong vibration (one pattern per alert) and the flashlight."] = "聴覚に障がいのある方向けの通知：設定 → アクセシビリティで強い振動（通知ごとに異なるパターン）とライトをオンにしてください。"
        m["Widgets: long-press an empty spot on the Home screen → Widgets → Binario. There are Route, Train, Station and Favourites; tap the title to change it."] = "ウィジェット：ホーム画面の空いている場所を長押し → ウィジェット → Binario。ルート、列車、駅、お気に入りがあります。タイトルをタップすると変更できます。"
        m["Following a train: open the train and tap \"Follow\": a pinned notification updates every minute and warns of platform changes and delays."] = "列車をフォロー：列車を開いて\"フォロー\"をタップすると、常時通知が1分ごとに更新され、番線変更や遅延をお知らせします。"
        m["Punctuality: More → Punctuality has monthly statistics, with regional trains compared with regional ones and high speed separately, plus every station and train (TrovaTreno.it data)."] = "定時運行率：その他 → 定時運行率に月間統計があります。普通列車は普通列車と、高速列車は別に比較し、各駅・各列車のデータもあります（TrovaTreno.itのデータ）。"
        m["Milan – Saronno – Varese – Laveno"] = "Milano – Saronno – Varese – Laveno"
        m["Milan – Saronno – Como"] = "Milano – Saronno – Como"
        m["Milan – Saronno – Novara"] = "Milano – Saronno – Novara"
        m["Milan – Seveso – Asso"] = "Milano – Seveso – Asso"
        m["Brescia – Iseo – Edolo"] = "Brescia – Iseo – Edolo"
        m["Other trains (S lines and Passante)"] = "その他の列車（S線とPassante）"
        m["Check for updates"] = "アップデートを確認"
        m["Checking…"] = "確認中…"
        m["You already have the latest version"] = "すでに最新バージョンです"
        m["Couldn't check for updates: check your connection and try again."] = "アップデートを確認できませんでした：接続を確認してもう一度お試しください。"
        m["Euro amounts are indicative (rate about €1.135 per CHF): the rate may differ at purchase."] = "ユーロの金額は目安です（1 CHFあたり約1.135ユーロ）：購入時のレートは異なる場合があります。"
        m["More actions"] = "その他の操作"
        m["Not a railway station: opening it on the map"] = "鉄道駅ではありません：地図で開きます"
        m["Transport:"] = "交通手段："
        m["Trains only"] = "列車のみ"
        m["Also metro and bus"] = "地下鉄とバスも"
        m["There are no train-only solutions at this time: solutions with metro or bus are shown too."] = "この時間は列車だけの経路がありません：地下鉄やバスを含む経路も表示しています。"
        m["Hidden"] = "非表示"
        m["solutions with metro or bus"] = "件の地下鉄・バスを含む経路"
        m["Prices:"] = "料金："
        m["1st class estimated: check sbb.ch"] = "1等は推定値：sbb.chでご確認ください"
        m["New version available"] = "新しいバージョンがあります"
        m["Tap to download and install"] = "タップしてダウンロード・インストール"
        m["Quick"] = "クイック"
        m["Active filters"] = "有効なフィルター"
        m["Nearby stations, toilets, replacement buses, taxis, defibrillators"] = "近くの駅、トイレ、代行バス、タクシー、AED"
        m["Show these options on the Quick page too"] = "これらのオプションをクイックページにも表示"
        m["Send the link or the app file via WhatsApp, Telegram…"] = "WhatsApp、Telegramなどでリンクまたはアプリのファイルを送る"
        m["Or send the app file directly (installed version):"] = "またはアプリのファイルを直接送る（インストール済みのバージョン）："
        m["App file (APK)"] = "アプリのファイル（APK）"
        m["The recipient must open it and allow installation. WhatsApp may refuse APK files: in that case use the link."] = "受け取った人はファイルを開いてインストールを許可する必要があります。WhatsAppはAPKファイルを拒否することがあります：その場合はリンクを使ってください。"
        m["Binario, the free app for trains in Italy and Switzerland. Open the file and allow installation."] = "Binario、イタリアとスイスの無料の鉄道アプリ。ファイルを開いてインストールを許可してください。"
        m["Could not prepare the app file"] = "アプリのファイルを準備できませんでした"
        m["SBB services at the station"] = "駅のSBBサービス"
        m["SBB services not reachable right now."] = "SBBサービスに現在アクセスできません。"
        m["Tap to retry"] = "タップして再試行"
        m["Reading services from the SBB website…"] = "SBBのサイトからサービスを読み込み中…"
        m["Hide shops and food"] = "ショップと飲食を隠す"
        m["Shops and food"] = "ショップと飲食"
        m["open"] = "営業中"
        m["Closed"] = "閉店"
        m["Open/closed and hours: SBB website, refreshed every 5 minutes. All data without guarantee."] = "営業状況と営業時間：SBBのサイト、5分ごとに更新。すべての情報は保証されません。"
        m["Station page on sbb.ch"] = "sbb.chの駅ページ"
        m["No region chosen"] = "地域が選択されていません"
        m["Notices and strikes in: "] = "お知らせとストライキ： "
        m[" (and with no region given)"] = " （地域の記載がないものも含む）"
        m["Show only notices and strikes that affect these regions (plus national ones). You can pick more than one."] = "これらの地域に関係するお知らせとストライキ（全国的なものを含む）だけを表示します。複数選べます。"
        m["Reset"] = "リセット"
    }

    /** 0.1.23: Italo, prezzi migliori, cambi rischiosi, condivisione solo Android. */
    private fun p6(m: HashMap<String, String>) {
        m["Android smartphones and tablets only: it does not work on iPhone and iPad."] = "Android のスマートフォンとタブレット専用です。iPhone と iPad では使えません。"
        m["Risky change"] = "乗り換えに注意"
        m["Tight change"] = "乗り換え時間が短い"
        m["For this change we recommend at least"] = "この乗り換えの推奨時間は少なくとも"
        m["a small delay could make you miss the connection."] = "少しの遅れで乗り継ぎを逃す可能性があります。"
        m["Find an alternative with later trains"] = "後の列車で代わりのルートを探す"
        m["Two tickets: Italo on italotreno.com, the other train on trenitalia.com or trenord.it"] = "切符は2枚：Italo は italotreno.com、もう一方の列車は trenitalia.com または trenord.it で購入"
        m["Change station not found"] = "乗換駅が見つかりません"
        m["Arrival station not found"] = "到着駅が見つかりません"
        m["Alternatives for the change at"] = "乗り換えの代替案："
        m["Arriving on"] = "到着列車："
        m["Later trains with at least"] = "乗り換え時間が少なくとも"
        m["min to change"] = "分ある後の列車"
        m["No alternative found after this time."] = "この時刻以降の代替案は見つかりませんでした。"
        m["Comfortable changes"] = "余裕のある乗り換え"
        m["With tickets for a fixed train and time (Frecce, Italo, Intercity) taking another train may require changing the ticket. Regional tickets are valid on any regional train on the route."] = "列車と時刻が指定された切符（Frecce、Italo、Intercity）では、別の列車に乗るには切符の変更が必要な場合があります。地域列車の切符は区間内のどの地域列車でも有効です。"
        m["Cannot reach the server. Check your connection."] = "サーバーに接続できません。接続を確認してください。"
        m["Some time bands did not respond: tap to retry"] = "一部の時間帯が応答しませんでした。タップして再試行"
        m["Lowest price for 1 adult among trains in that time band (Trenitalia, Trenord and Italo). «—» = no price available, «?» = service not reachable. Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "その時間帯の列車での大人1名の最安値（Trenitalia、Trenord、Italo）。«—» = 価格なし、«?» = サービスに接続できません。マスをタップすると経路が表示されます。割引運賃は空席状況で変わります。最終価格は購入時の価格です。"
        m["next 7 days, morning, afternoon and evening"] = "今後7日間の朝・午後・夜"
        m["Choose origin and destination to see the lowest prices for the next 7 days."] = "出発駅と到着駅を選ぶと、今後7日間の最安値が表示されます。"
    }

    /** 0.1.24: silenzio degli avvisi di sciopero. */
    private fun p7(m: HashMap<String, String>) {
        m["Mute strike alerts"] = "ストライキ通知をミュート"
        m["Muted until"] = "ミュート期限："
        m["On · tap to mute them for a while"] = "オン · タップでしばらくミュート"
        m["Turn back on"] = "再開"
        m["1 hour"] = "1時間"
        m["3 hours"] = "3時間"
        m["8 hours"] = "8時間"
        m["1 week"] = "1週間"
        m["1 month"] = "1か月"
        m["For how long? Strikes stay visible in News."] = "どのくらいの間？ストライキ情報はニュースで引き続き見られます。"
        m["Until a day and time…"] = "日時を指定…"
    }

    /** 0.1.25: passeggeri, menù laterale, prossimo sciopero, notifica del treno seguito. */
    private fun p8(m: HashMap<String, String>) {
        m["Travel"] = "旅行"
        m["Best prices"] = "最安値"
        m["At the station"] = "駅で"
        m["Tickets and passes"] = "切符と定期券"
        m["Fares"] = "運賃"
        m["Send feedback"] = "フィードバックを送る"
        m["Next train strike"] = "次の鉄道ストライキ"
        m.putIfAbsent("Details", "詳細")
        m.putIfAbsent("Menu", "メニュー")
        m["1 adult"] = "大人1名"
        m["adults"] = "名（大人）"
        m["1 child"] = "子ども1名"
        m["children"] = "名（子ども）"
        m["Passengers"] = "乗客"
        m["Adults"] = "大人"
        m["Children"] = "子ども"
        m["aged 4 to 14 (under 4 free without a seat)"] = "4〜14歳（4歳未満は座席なしで無料）"
        m["Prices shown are the total for all passengers. Discounts for children and families: check when buying."] = "表示価格は全乗客の合計です。子ども・家族割引は購入時に確認してください。"
        m["Less"] = "減らす"
        m["More"] = "増やす"
        m.putIfAbsent("total price", "合計金額")
        m.putIfAbsent("min early", "分早着")
        m.putIfAbsent("late", "遅れ")
        m.putIfAbsent("Refresh", "更新")
        m.putIfAbsent("On time", "定刻")
        m.putIfAbsent("Cancelled", "運休")
    }

    /** 0.1.26: menù Accessibilità. */
    private fun p9(m: HashMap<String, String>) {
        m["Colour-blind, voice and vibration"] = "色覚、音声、振動"
    }

    /** Germania: treni, aziende, stazioni e biglietti. */
    private fun p10(m: HashMap<String, String>) {
        m["Trains in Germany"] = "ドイツの列車"
        m["Times, delays and platforms in real time for all German operators"] = "ドイツ全鉄道会社の時刻・遅延・番線をリアルタイムで"
        m["Search a German station like an Italian one, also by its Italian name: «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Journey search (also Italy ⇄ Germany), departure and arrival boards, train details and «Follow» all work."] = "ドイツの駅もイタリアの駅と同じように検索できます（イタリア語名も可）：«München»、«Monaco di Baviera»、«Colonia»、«Berlin Hbf»。経路検索（イタリア ⇄ ドイツも）、発車・到着案内、列車詳細、「フォロー」が使えます。"
        m["Data: official German DELFI timetables via Transitous. Prices are not public: buy on bahn.de or in the DB Navigator app."] = "データ：Transitous 経由のドイツ公式 DELFI 時刻表。運賃は公開されていないため、bahn.de または DB Navigator アプリで購入してください。"
        m["Train types"] = "列車の種類"
        m["DB high-speed trains between major cities; seat reservation recommended."] = "大都市間を結ぶ DB の高速列車。座席予約がおすすめ。"
        m["Intercity and EuroCity: long distance, also to Austria, Switzerland and Italy."] = "インターシティとユーロシティ：長距離列車。オーストリア、スイス、イタリアへも。"
        m["Regional trains (DB Regio and many other companies): valid with the Deutschlandticket."] = "地域列車（DB Regio ほか多くの会社）：Deutschlandticket で乗車可。"
        m["City S-Bahn (Munich, Berlin, Hamburg, Stuttgart…): valid with the Deutschlandticket."] = "都市の S-Bahn（ミュンヘン、ベルリン、ハンブルク、シュトゥットガルト…）：Deutschlandticket で乗車可。"
        m["FlixTrain: low-cost long distance, Flix tickets only."] = "FlixTrain：格安の長距離列車。Flix の切符のみ有効。"
        m["Night trains: ÖBB Nightjet and European Sleeper."] = "夜行列車：ÖBB Nightjet と European Sleeper。"
        m["Monthly pass for all regional trains (RE, RB, S-Bahn), buses, trams and metro in Germany. Not valid on ICE, IC, EC and FlixTrain. Cancel by the 10th of the month. It costs €63 until 31/12/2026 and €66.80 from 1 January 2027."] = "ドイツ全土の地域列車（RE、RB、S-Bahn）、バス、路面電車、地下鉄に乗れる月額定期。ICE、IC、EC、FlixTrain では使えません。毎月10日までに解約可能。2026年12月31日までは63ユーロ、2027年1月1日からは66.80ユーロ。"
        m["Full fare: valid on any train on the chosen day."] = "通常運賃：指定日のどの列車でも有効。"
        m["Cheaper when bought early, but tied to the chosen train (Zugbindung)."] = "早めに買うと安いが、選んだ列車に限定（Zugbindung）。"
        m["DB annual discount cards (25% or 50%, or unlimited travel with the 100)."] = "DB の年間割引カード（25％・50％、100 は乗り放題）。"
        m["Buy on bahn.de"] = "bahn.de で購入"
        m["Deutschlandticket: information and purchase"] = "Deutschlandticket：案内と購入"
        m["DB Navigator app (tickets on your phone)"] = "DB Navigator アプリ（スマホで切符）"
        m["Delays: your rights"] = "遅延：あなたの権利"
        m["60 minutes or more late on arrival: 25% of the fare back; 120 minutes or more: 50% (minimum €4)."] = "到着が60分以上遅れたら運賃の25％、120分以上なら50％を返金（最低4ユーロ）。"
        m["Expected delay over 20 minutes: train binding is lifted and even with a Sparpreis you can take another train."] = "20分を超える遅れが見込まれる場合は列車指定が解除され、Sparpreis でも別の列車に乗れます。"
        m["Expected arrival between midnight and 5 am with at least 60 minutes' delay: taxi refunded up to €120."] = "0時〜5時の到着予定で60分以上遅れる場合、タクシー代を120ユーロまで払い戻し。"
        m["Claim within 3 months on bahn.de, in DB Navigator or with the Fahrgastrechte form."] = "申請は3か月以内に bahn.de、DB Navigator、または Fahrgastrechte 用紙で。"
        m["Passenger rights (Fahrgastrechte)"] = "乗客の権利（Fahrgastrechte）"
        m["Assistance for people with disabilities"] = "障がいのある方へのサポート"
        m["Mon–Fri 6–22, Sat–Sun and holidays 8–20"] = "平日6〜22時、土日祝8〜20時"
        m["Book assistance online (by 8 pm the day before)"] = "オンラインで介助を予約（前日20時まで）"
        m["Companies and stations"] = "会社と駅"
        m["All German railway companies"] = "ドイツの全鉄道会社"
        m["DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… («Germany» filter)"] = "DB、FlixTrain、Arverio、Länderbahn、metronom、ODEG…（「ドイツ」で絞り込み）"
        m["Open a German station's board › «Station» tab: services, lifts and accessibility from bahnhof.de"] = "ドイツの駅の発車案内を開き ›「駅」タブ：bahnhof.de のサービス・エレベーター・バリアフリー情報"
        m["Germany: official DELFI timetables with delays and platforms in real time when published (Transitous)."] = "ドイツ：公式 DELFI 時刻表。公開されていれば遅延と番線をリアルタイム表示（Transitous）。"
        m["Station services (Germany)"] = "駅のサービス（ドイツ）"
        m["Services, shops, DB Lounge and map"] = "サービス、店舗、DB ラウンジ、構内図"
        m["Lifts with real-time status"] = "エレベーターの稼働状況（リアルタイム）"
        m["Station accessibility"] = "駅のバリアフリー"
        m["Assistance for people with disabilities (DB)"] = "障がいのある方へのサポート（DB）"
        m["Valid with the Deutschlandticket"] = "Deutschlandticket で乗車可"
        m["/month"] = "/月"
        m["Price and tickets on bahn.de (Sparpreis tied to the train)"] = "運賃と切符は bahn.de で（Sparpreis は列車指定）"
        m["ICE, regional trains, S-Bahn, Deutschlandticket, rights and companies"] = "ICE、地域列車、S-Bahn、Deutschlandticket、権利と会社"
        m["Italy, Switzerland and Germany: websites, tickets, data"] = "イタリア・スイス・ドイツ：サイト、切符、データ"
        m.putIfAbsent("Germany", "ドイツ")
        m["Times and real time in the app: official German DELFI data (Transitous)"] = "アプリ内で時刻とリアルタイム：ドイツ公式 DELFI データ（Transitous）"
        m["Trip not found"] = "運行が見つかりません"
        m.putIfAbsent("Real time · ", "リアルタイム · ")
        m["Scheduled times (no real time for this trip) · "] = "予定時刻（この列車はリアルタイムなし） · "
    }

    /** Puntualità: confronto tra aziende e paesi. */
    private fun p11(m: HashMap<String, String>) {
        m["Companies and countries compared"] = "会社・国の比較"
        m["Companies to compare"] = "比較する会社"
        m["Deutsche Bahn · official figures"] = "ドイツ鉄道 · 公式値"
        m["Each country measures differently: in Italy (TrovaTreno) and Austria a train is on time within 5 minutes, in Germany under 6 minutes, for SBB under 3 minutes (stricter). DB and ÖBB count stops along the route, TrovaTreno counts arrivals. The fairest comparison is between trains of the same type: use the Regional or Long distance filter."] = "国によって測り方が違います。イタリア（TrovaTreno）とオーストリアは5分以内、ドイツは6分未満、スイス連邦鉄道は3分未満（より厳しい）で定時とみなします。DB と ÖBB は途中の停車駅、TrovaTreno は到着を数えます。最も公平なのは同じ種類の列車どうしの比較です。「地域」または「長距離」の絞り込みを使ってください。"
        m["How to read the comparison"] = "比較の見方"
        m["No companies to compare: tap «Add»."] = "比較する会社がありません。「追加」をタップしてください。"
        m["Remove from comparison"] = "比較から外す"
        m["Some chosen companies have no data yet: they will appear when available."] = "選んだ会社の一部はまだデータがありません。利用可能になり次第表示されます。"
        m["Trenord · FerrovieNord network"] = "Trenord · FerrovieNord 線"
        m.putIfAbsent("last ", "直近 ")
        m["long distance (Railjet, IC, Nightjet)"] = "長距離（Railjet、IC、Nightjet）"
        m.putIfAbsent("regional", "地域列車")
        m["regional and S-Bahn"] = "地域列車と S-Bahn"
        m["ÖBB · official figures"] = "ÖBB · 公式値"
    }

    /** Germania: scioperi e prezzi. */
    private fun p12(m: HashMap<String, String>) {
        m["Train strikes in Germany"] = "ドイツの鉄道ストライキ"
        m["News not reachable right now."] = "ニュースに接続できません。"
        m["No train strike announced in Germany in the last 14 days."] = "過去14日間、ドイツで鉄道ストライキの発表はありません。"
        m["News in German (Google News): in Germany strikes are announced by the GDL and EVG unions a few days in advance, with no official calendar."] = "ドイツ語のニュース（Google ニュース）：ドイツでは GDL や EVG などの労組が数日前にストを発表し、公式の予定表はありません。"
        m["Traffic in Germany: disruptions and engineering works (DB)"] = "ドイツの運行状況：障害と工事（DB）"
        m["Open on bahn.de"] = "bahn.de で開く"
        m["For trains in Germany prices are not public: the lowest-price calendar is on bahn.de («Bestpreissuche»). With regional trains only, the Deutschlandticket is valid."] = "ドイツの列車の運賃は公開されていません。最安値カレンダーは bahn.de（«Bestpreissuche»）で。地域列車だけなら Deutschlandticket が使えます。"
        m["Train strike in Germany"] = "ドイツで鉄道スト"
    }

    /** Emergenze per paese, affollamento e accessibilita' all'estero. */
    private fun p13(m: HashMap<String, String>) {
        m.putIfAbsent("Lombardy: Trenord and FerrovieNord trains from Trenord's official timetable (Regione Lombardia Open Data), with the delay from Trenord's live service.", "ロンバルディア：TrenordとFerrovieNordの列車はTrenord公式時刻表（ロンバルディア州オープンデータ）から、遅れはTrenordのライブサービスから取得します。")
        m.putIfAbsent("Austria", "オーストリア")
        m.putIfAbsent("France", "フランス")
        m.putIfAbsent("Germany, Austria, Switzerland and France: running trains placed on the line from the timetable and the realtime data the companies publish (Transitous); where there is no realtime the position follows the timetable.", "ドイツ、オーストリア、スイス、フランス：運行中の列車を、時刻表と各社が公開するリアルタイムデータから路線上に配置します（Transitous）。リアルタイムがない場合は時刻表どおりの位置です。")
        m.putIfAbsent("Finland (GPS)", "フィンランド（GPS）")
        m.putIfAbsent("Norway (GPS)", "ノルウェー（GPS）")
        m.putIfAbsent("GPS position", "GPS位置")
        m.putIfAbsent("trains running or about to depart", "運行中または間もなく発車する列車")
        m.putIfAbsent("Location unavailable", "位置情報を取得できません")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour. In Italy the position is estimated along the route from the timetable and the last stop (shortly after opening the dots move onto the line); elsewhere it stays around the hub: not GPS. It is a sample, not the whole network. Finland and Norway show the real GPS position (Digitraffic, Entur). Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "各点は、1時間以内にハブ駅を出発する列車です。イタリアでは、時刻表と直前の停車駅から路線上の位置を推定します（開いてしばらくすると点が線路上に移動します）。それ以外はハブ駅の周囲に表示され、GPSではありません。サンプルであり、路線網全体ではありません。フィンランドとノルウェーは実際のGPS位置を表示します（Digitraffic、Entur）。出典：ViaggiaTreno、SBB (transport.opendata.ch)、Transitous。線路：© OpenStreetMap contributors、スタイル CC-BY-SA 2.0 OpenRailwayMap。")
        m.putIfAbsent("Colored dots by delay, zoom and «Near me»", "遅延で色分けした点、ズーム、「現在地周辺」")
        m.putIfAbsent("Alerts for my trip", "マイ旅行の通知")
        m.putIfAbsent("Minutes from home to the departure station", "自宅から出発駅までの分数")
        m.putIfAbsent("«Leave home» before the outbound train, «Last useful train» in the evening on the return and «Connection at risk» when a delay endangers a change. The departure is the station near home.", "「家を出る時間」は往路列車の前に、「最終の利用可能な列車」は夜の復路で、「乗り換えが危険」は遅延で乗り換えが難しいときに通知します。出発駅は自宅近くの駅です。")
        m.putIfAbsent("Leave home", "家を出る時間")
        m.putIfAbsent("Leave home by", "家を出る時刻")
        m.putIfAbsent("for the train at", "対象の列車")
        m.putIfAbsent("Last useful train", "最終の利用可能な列車")
        m.putIfAbsent("Last useful train to", "最終の利用可能な列車、行き先")
        m.putIfAbsent("departs at", "発車")
        m.putIfAbsent("Connection at risk at", "乗り換えが危険：")
        m.putIfAbsent("expected arrival", "到着予定")
        m.putIfAbsent("departure", "出発")
        m.putIfAbsent("Your history on this train", "この列車のあなたの履歴")
        m.putIfAbsent("Average delay", "平均遅延")
        m.putIfAbsent("On time (within 5 min)", "定刻（5分以内）")
        m.putIfAbsent("Worst", "最大")
        m.putIfAbsent("Days recorded", "記録日数")
        m.putIfAbsent("Data stays on your phone only.", "データは端末内のみに保存されます。")
        m.putIfAbsent("Most punctual among the next trains", "次の列車で最も定時性が高い便")
        m.putIfAbsent("runs observed", "観測された運行")
        m.putIfAbsent("TrovaTreno data from last month; they do not guarantee today's delay.", "TrovaTrenoの先月のデータです。今日の遅延を保証するものではありません。")
        m.putIfAbsent("RFI notice on your route", "あなたの区間に関するRFIのお知らせ")
        m.putIfAbsent("Notices on your routes", "あなたの区間のお知らせ")
        m.putIfAbsent("Until", "まで")
        m.putIfAbsent("Timetable notice", "時刻表のお知らせ")
        m.putIfAbsent("From", "から")
        m.putIfAbsent("to", "まで")
        m.putIfAbsent("arrival at destination with", "終点到着が")
        m.putIfAbsent("minutes", "分遅く")
        m.putIfAbsent("Tap for the source", "タップして出典を開く")
        m.putIfAbsent("Service interruption between Rho and Parabiago", "RhoとParabiagoの間の運行中断")
        m.putIfAbsent("Timetable remodulation 126.1: staff shifts remain unchanged.", "ダイヤ調整126.1：乗務員の勤務は変わりません。")
        m.putIfAbsent("From the departures of the next hours. High-speed, Intercity and Trenitalia regional trains have no line in the official timetables: they are shown by category and route.", "今後数時間の出発便から。Trenitaliaの高速列車・インターシティ・地域列車は公式時刻表に路線がないため、種別と区間で表示します。")
        m.putIfAbsent("Trenord network / Lombardy", "Trenord ネットワーク / ロンバルディア")
        m.putIfAbsent("Other network or region", "その他のネットワークまたは地域")
        m.putIfAbsent("Over 60 with CartaFreccia: FrecciaSENIOR offer on Frecce trains (from €29). Discounts and conditions detailed on the official page.", "60歳以上でCartaFrecciaをお持ちの方：Frecce列車のFrecciaSENIORオファー（29ユーロから）。割引と条件は公式ページで。")
        m.putIfAbsent("From age 65, single tickets are 20% off the Lombardy Regional Single Fare; in the STIBM area 25% off ordinary monthly and annual passes (to be loaded on the Io Viaggio card, €10).", "65歳から、ロンバルディア地域統一運賃の片道券が20％割引。STIBM地域では通常の月間・年間定期券が25％割引（Io Viaggioカードにチャージ、10ユーロ）。")
        m.putIfAbsent("Over 60: Italo Senior, 40% to 60% off the Flex fare, in Smart and Prima Business; non-refundable, changeable up to 72 hours before departure.", "60歳超：Italo Senior、Flex運賃より40〜60％割引、SmartとPrima Businessで利用可能。払い戻し不可、出発72時間前まで変更可能。")
        m.putIfAbsent("Reduced General Abonnement (GA) for women from their 64th birthday (from 65 starting in 2028) and for men from 65.", "割引ゼネラル・アボ（GA）：女性は64歳の誕生日から（2028年からは65歳）、男性は65歳から。")
        m.putIfAbsent("Senior BahnCard from age 65; the BahnCard 50 (ages 27 to 64) gives 50% off the Flexpreis and 25% off long-distance Sparpreis fares.", "シニアBahnCardは65歳から。BahnCard 50（27〜64歳）はFlexpreisが50％、長距離のSparpreisが25％割引。")
        m.putIfAbsent("From age 65, men and women: Vorteilscard Senior at €31 (valid 1 year).", "65歳から（男女とも）：Vorteilscard Senior 31ユーロ（有効期間1年）。")
        m.putIfAbsent("From age 60: Carte Avantage Senior at €49 (confirm the price when buying): 30% off trips in 2nd and 1st class, 60% for up to 3 accompanying children aged 4-11; TER discounts vary by region.", "60歳から：Carte Avantage Senior 49ユーロ（購入時に価格を確認）。2等・1等の乗車が30％割引、同伴する4〜11歳の子ども最大3人は60％割引。TERの割引は地域により異なります。")
        m.putIfAbsent("The prices shown are the total for all passengers.", "表示価格は全乗客の合計です。")
        m.putIfAbsent("Age discounts vary by country and company: here kids are 4 to 14, but other companies use other ages. Family discounts: check when buying.", "年齢割引は国や会社によって異なります。ここでは子どもは4〜14歳ですが、他社は別の年齢を使います。家族割引は購入時に確認してください。")
        m.putIfAbsent("Age rules for each company", "各社の年齢ルール")
        m.putIfAbsent("Age rules: companies and countries", "年齢ルール：会社と国")
        m.putIfAbsent("Age reductions depend on the country, company, train type and fare. Summary from the official sites (3/11/2026): they may change, always check the source before buying.", "年齢割引は国、会社、列車の種類、運賃によって異なります。公式サイトの要約（2026年11月3日）です。変更される場合があるため、購入前に必ず出典を確認してください。")
        m.putIfAbsent("National trains: under 4 free without a seat; ages 4 to 14 (until the 15th birthday) 50% off the Base fare.", "国内列車：4歳未満は座席なしで無料。4〜14歳（15歳の誕生日前まで）はベース運賃が50％割引。")
        m.putIfAbsent("Regional trains: under 4 free (with an adult, without a seat); ages 4 to under 12 get 50% off. Some regions have their own rules (Lombardy, Campania, Abruzzo, Sardinia, Apulia, Trento, Bolzano).", "地域列車：4歳未満は大人同伴・座席なしで無料。4歳以上12歳未満は50％割引。地域ごとに独自の規則があります（ロンバルディア、カンパニア、アブルッツォ、サルデーニャ、プーリア、トレント、ボルツァーノ）。")
        m.putIfAbsent("International trains (EuroCity, EuroNight): free up to age 5 without a seat; ages 6 to 14 get the «CHILD» offer (about 50%), varies by service.", "国際列車（EuroCity、EuroNight）：5歳以下は座席なしで無料。6〜14歳は「CHILD」オファー（約50％）、サービスにより異なります。")
        m.putIfAbsent("Up to age 3 free on the whole fleet, without taking a seat; ages 4 to under 14 get 50% off the Regional Single Fare; in the STIBM area under-14s travel free (with a document proving their age).", "3歳までは座席を使わなければ全線無料。4歳以上14歳未満は地域統一運賃が50％割引。STIBM地域では14歳未満は無料（年齢を証明する書類が必要）。")
        m.putIfAbsent("Under 3 free, without an assigned seat and held by an adult (with more than one child per adult a paid seat is required). Italo Family offer for 2–4 people: details on the site.", "3歳未満は無料。座席は割り当てられず、大人が抱きます（大人1人に子ども複数の場合は有料の座席が必要）。2〜4人向けのItalo家族オファー：詳細はサイトで。")
        m.putIfAbsent("Under 6 free; ages 6 to under 16 pay half price (or the minimum fare), or travel free with a parent holding a valid ticket if you have the Junior Card. Under 25: Youth Half-Fare.", "6歳未満は無料。6歳以上16歳未満は半額（または最低運賃）、ジュニアカードがあれば有効な切符を持つ親と同伴で無料。25歳未満：ユース・ハーフフェア。")
        m.putIfAbsent("Under 6 free; ages 6 to 14 travel free on long-distance trains when accompanied by an adult or a sibling aged 15 or over. Regional trains and discounted tickets may have different rules.", "6歳未満は無料。6〜14歳は、大人または15歳以上のきょうだいが同伴する場合、長距離列車で無料。地域列車や割引切符は規則が異なる場合があります。")
        m.putIfAbsent("Under 6 free without a ticket, with an adult; ages 6 to 14 (until the day before the 15th birthday) free with the Vorteilscard Family (€21, up to 4 children), only on ÖBB trains in Austria; from 15 adult fare.", "6歳未満は大人同伴で切符なしで無料。6〜14歳（15歳の誕生日の前日まで）はVorteilscard Family（21ユーロ、子ども最大4人）で無料。オーストリア国内のÖBB列車のみ。15歳から大人運賃。")
        m.putIfAbsent("Under 4 free on the lap (TGV INOUI, TER, Intercités), one child per traveller; own seat with the Forfait Bambin at €9. Ages 4 to 11: 60% off for those accompanying a Carte Avantage Adulte holder. OUIGO has its own fares.", "4歳未満は膝の上で無料（TGV INOUI、TER、Intercités）、旅行者1人につき子ども1人まで。専用席はForfait Bambin（9ユーロ）。4〜11歳：Carte Avantage Adulte保有者に同伴する子どもは60％割引。OUIGOは独自の運賃です。")
        m.putIfAbsent("Plan B", "プランB")
        m.putIfAbsent("Missed the train or the connection? Find alternatives from where you are now.", "列車や乗り継ぎを逃しましたか？今いる場所から代替案を探します。")
        m.putIfAbsent("Where you are now", "現在地")
        m.putIfAbsent("Another station…", "別の駅…")
        m.putIfAbsent("Alternatives to", "代替案：")
        m.putIfAbsent("Looking for alternatives…", "代替案を検索中…")
        m.putIfAbsent("How Binario works", "Binario の使い方")
        m.putIfAbsent("Basic or Full", "ベーシックまたはフル")
        m.putIfAbsent("On the Search screen choose how many features to see. You can change it any time: your choice is saved.", "検索画面で表示する機能の数を選べます。いつでも変更でき、選択は保存されます。")
        m.putIfAbsent("Offline timetables", "オフライン時刻表")
        m.putIfAbsent("In the results tap «Save these times to use them offline»: you will find them in Offline timetables even without a network.", "結果で「この時刻表をオフライン用に保存」をタップすると、ネットがなくても「オフライン時刻表」で見られます。")
        m.putIfAbsent("Widgets", "ウィジェット")
        m.putIfAbsent("Long-press the home screen, choose Widgets and add Binario: departures and delays always in sight.", "ホーム画面を長押ししてウィジェットを選び、Binario を追加すると、発車と遅延がいつでも見られます。")
        m.putIfAbsent("Punctuality", "定時性")
        m.putIfAbsent("Under each icon is the tab name: search a station or a train and see how many arrive on time.", "各アイコンの下にタブ名があります。駅や列車を検索して、定時に着く割合を確認できます。")
        m.putIfAbsent("Got it", "わかりました")
        m.putIfAbsent("less than a minute ago", "1分未満前")
        m.putIfAbsent("%d min ago", "%d分前")
        m.putIfAbsent("%d h ago", "%d時間前")
        m.putIfAbsent("%d days ago", "%d日前")
        m.putIfAbsent("Timetables saved %s. They may have changed: connect to refresh them.", "時刻表の保存：%s。変更されている可能性があります。接続して更新してください。")
        m.putIfAbsent("Last saved message: the Trenord page is not responding right now.", "最後に保存したメッセージです。現在 Trenord のページが応答していません。")
        m.putIfAbsent("The downloaded file is not a valid APK. Try downloading it again.", "ダウンロードしたファイルは有効な APK ではありません。もう一度ダウンロードしてください。")
        m.putIfAbsent("The downloaded file is not Binario.", "ダウンロードしたファイルは Binario ではありません。")
        m.putIfAbsent("This version is already installed or is older.", "このバージョンはすでにインストール済みか、より古いものです。")
        m.putIfAbsent("Your Binario was installed with a different signature from the updates (for example a test build or another source): Android cannot update it and would show “App not installed”. Uninstall Binario and install the latest version from the download page: you will lose favourites and settings.", "お使いの Binario は、アップデートとは異なる署名でインストールされています（テスト版や別の入手元など）。Android では更新できず「アプリがインストールされていません」と表示されます。Binario をアンインストールし、ダウンロードページから最新版をインストールしてください。お気に入りと設定は失われます。")
        m.putIfAbsent("Open the download page", "ダウンロードページを開く")
        m.putIfAbsent("Show the message", "メッセージを表示")
        m.putIfAbsent("1 source has problems: related features use backups or the latest saved data.", "1 件のデータ元に問題があります。関連機能は予備のデータ元か最後に保存したデータを使います。")
        m.putIfAbsent("%d sources have problems: related features use backups or the latest saved data.", "%d 件のデータ元に問題があります。関連機能は予備のデータ元か最後に保存したデータを使います。")
        m.putIfAbsent("All sources respond, but some are busy (too many requests): the app uses backups.", "すべてのデータ元が応答していますが、一部は混雑中です（リクエスト過多）。アプリは予備を使います。")
        m.putIfAbsent("Latest message from Trenord", "Trenord の最新メッセージ")
        m.putIfAbsent("Reading the message from the Trenord site…", "Trenord のサイトからメッセージを読み込み中…")
        m.putIfAbsent("Message not available right now.", "現在メッセージを取得できません。")
        m.putIfAbsent("Line status", "路線の状況")
        m.putIfAbsent("Latest notice", "最新のお知らせ")
        m.putIfAbsent("Show all", "すべて表示")
        m.putIfAbsent("Show less", "表示を減らす")
        m.putIfAbsent("Open the line page", "路線ページを開く")
        m.putIfAbsent("Save these times to use them offline", "この時刻表をオフライン用に保存")
        m.putIfAbsent("Saved: find it in Offline timetables", "保存しました：「オフライン時刻表」で見られます")
        m.putIfAbsent("No saved timetables", "保存された時刻表はありません")
        m.putIfAbsent("To have timetables without a network: search for a trip, then in the results tap «Save these times to use them offline». You will find it here.", "ネットなしで時刻表を使うには：経路を検索し、結果で「この時刻表をオフライン用に保存」をタップします。ここで見つかります。")
        m.putIfAbsent("Tap a search to reopen it, even without a network.", "検索をタップすると、ネットなしでも開き直せます。")
        m.putIfAbsent("Search for a trip", "経路を検索")
        m.putIfAbsent("Busy: too many requests from your address (429). The app tries the other servers and then Postpass; retry in 15 seconds.", "混雑中：お使いのアドレスからのリクエストが多すぎます (429)。アプリは他のサーバー、次に Postpass を試します。15 秒後にもう一度お試しください。")
        m.putIfAbsent("Share of trains on time for each station in the chosen month. Type a name to search, then tap it to open.", "選択した月の各駅の定時列車の割合。名前を入力して検索し、タップして開きます。")
        m.putIfAbsent("Share of runs on time for each train in the chosen month. Search by number or destination, then tap it to open.", "選択した月の各列車の定時運行の割合。番号または行き先で検索し、タップして開きます。")
        m.putIfAbsent("Search station", "駅を検索")
        m.putIfAbsent("Train number or destination", "列車番号または行き先")
        m.putIfAbsent("Clear", "クリア")
        m.putIfAbsent("Least punctual", "定時率が低い順")
        m.putIfAbsent("Most punctual", "定時率が高い順")
        m.putIfAbsent("Milan Passante", "ミラノ・パッサンテ")
        m.putIfAbsent("RFI network", "RFI 路線網")
        m.putIfAbsent("FerrovieNord network", "FerrovieNord 路線網")
        m.putIfAbsent("%d results", "%d 件")
        m.putIfAbsent("%d results for «%s»", "「%s」の %d 件")
        m.putIfAbsent("No results", "結果なし")
        m.putIfAbsent("No alternatives found in the next hours.", "今後数時間の代替案は見つかりませんでした。")
        m.putIfAbsent("direct", "直通")
        m.putIfAbsent("changes", "乗り換え")
        m.putIfAbsent("Tap a train to open it. Times are scheduled: check delays and platforms on its page.", "列車をタップすると開きます。時刻は予定です。遅延とホームは列車ページで確認してください。")
        m.putIfAbsent("Trains in Austria", "オーストリアの列車")
        m.putIfAbsent("Trains in France", "フランスの列車")
        m.putIfAbsent("Trains in Italy", "イタリアの列車")
        m.putIfAbsent("Features", "機能")
        m.putIfAbsent("Basic", "基本")
        m.putIfAbsent("Full", "すべて")
        m.putIfAbsent("Estimate: scheduled time plus the known delay.", "推定：時刻表の時刻＋現在わかっている遅れ。")
        m.putIfAbsent("This train usually arrives with", "この列車は通常")
        m.putIfAbsent("Updated just now", "たった今更新")
        m.putIfAbsent("Data from %d min ago", "%d分前のデータ")
        m.putIfAbsent("tap ↻ to refresh", "↻ をタップして更新")
        m.putIfAbsent("Cancelled today", "本日運休")
        m.putIfAbsent("Extra train today", "本日の増発列車")
        m.putIfAbsent("Replaced by train", "代替列車")
        m.putIfAbsent("Runs in place of train", "代わりに運転される列車")
        m.putIfAbsent("Other times", "ほかの日")
        m.putIfAbsent("replaced by", "代替:")
        m.putIfAbsent("in place of", "代替元:")
        m.putIfAbsent("network", "路線網")
        m.putIfAbsent("Trenord · TILO", "Trenord · TILO")
        m.putIfAbsent("All networks", "すべての路線網")
        m.putIfAbsent("Switzerland · SBB", "スイス · SBB")
        m.putIfAbsent("All", "すべて")
        m.putIfAbsent("FerrovieNord", "FerrovieNord")
        m.putIfAbsent("RFI", "RFI")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Sources: ViaggiaTreno (Italy, Trenord, FerrovieNord) and transport.opendata.ch (TILO, Switzerland). Trenord and TILO are a single service.", "主要駅の発車案内からの抽出（今後数時間）：路線網全体ではありません。出典：ViaggiaTreno（イタリア、Trenord、FerrovieNord）、transport.opendata.ch（TILO、スイス）。TrenordとTILOは一つのサービスです。")
        m.putIfAbsent("Italia · RFI", "イタリア · RFI")
        m.putIfAbsent("Trenord · rete RFI", "Trenord · RFI 路線網")
        m.putIfAbsent("Trenord · rete FerrovieNord", "Trenord · FerrovieNord 路線網")
        m.putIfAbsent("TILO", "TILO")
        m.putIfAbsent("Svizzera · FFS/SBB", "スイス · SBB")
        m.putIfAbsent("Nessun ritardo di 5 minuti o più nei nodi controllati.", "確認した主要駅に5分以上の遅れはありません。")
        m.putIfAbsent("Campione dai tabelloni dei principali nodi (partenze delle prossime ore): non è l'elenco di tutta la rete. Fonti: ViaggiaTreno (Italia, Trenord, FerrovieNord) e transport.opendata.ch (TILO, Svizzera).", "主要駅の発車案内からの抽出（今後数時間）：路線網全体ではありません。出典：ViaggiaTreno（イタリア、Trenord、FerrovieNord）、transport.opendata.ch（TILO、スイス）。")
        m.putIfAbsent("Trains in Switzerland", "スイスの列車")
        m.putIfAbsent("Timetables, delays and platforms of Italian trains (Trenitalia, Italo, Trenord, FerrovieNord and regional railways).", "イタリアの列車（Trenitalia、Italo、Trenord、FerrovieNord、地方鉄道）の時刻、遅延、ホーム情報。")
        m.putIfAbsent("Timetables, delays and platforms of Swiss trains (SBB, TILO and regional railways), with crowding and station services where SBB publishes them.", "スイスの列車（SBB、TILO、地方鉄道）の時刻、遅延、ホーム情報。SBBが公開している場合は混雑状況や駅のサービスも表示します。")
        m.putIfAbsent("Search a station by name, a train by number, or a route. Journey search, departure board, train page and “Follow” work.", "駅名、列車番号、区間で検索できます。経路検索、発車案内、列車ページ、「フォロー」が使えます。")
        m.putIfAbsent("Data: ViaggiaTreno, Trenord and Italo. Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "データ：ViaggiaTreno、Trenord、Italo。リアルタイム情報は各社の公開内容によるため、一部の列車では表示されないことがあります。常に案内表示とアナウンスを優先してください。")
        m.putIfAbsent("Data: SBB (open data). Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "データ：SBB（オープンデータ）。リアルタイム情報は各社の公開内容によるため、一部の列車では表示されないことがあります。常に案内表示とアナウンスを優先してください。")
        m.putIfAbsent("Timetables, delays and platforms of Austrian trains (ÖBB, Westbahn and regional operators), when real-time data is published.", "オーストリアの列車（ÖBB、Westbahn、地域事業者）の時刻表・遅延・ホーム。リアルタイムデータが公開されている場合に表示します。")
        m.putIfAbsent("Timetables, delays and platforms of French trains (TGV, TER, Intercités, RER), when real-time data is published.", "フランスの列車（TGV、TER、Intercités、RER）の時刻表・遅延・ホーム。リアルタイムデータが公開されている場合に表示します。")
        m.putIfAbsent("Search the station with its Italian name too: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Trip search (also with Italy), station board, train page and «Follow» all work.", "駅名はイタリア語でも検索できます：「Vienna」「Salisburgo」「Parigi」「Lione」「Marsiglia」。経路検索（イタリア発着も）、駅の掲示板、列車ページ、「追跡」が使えます。")
        m.putIfAbsent("Data: official timetables via Transitous; real time depends on what operators publish and may be missing for some trips. Prices are not public: tickets on the official sites. Station boards and announcements always prevail.", "データ：Transitous経由の公式時刻表。リアルタイム情報は各社の公開状況によるため、一部の列車では表示されないことがあります。運賃は非公開：切符は公式サイトで。常に駅の掲示板とアナウンスが優先されます。")
        m.putIfAbsent("Tickets and official information", "切符と公式情報")
        m.putIfAbsent("Prices for these trains are not public: the lowest-price calendar is on the operators' sites (ÖBB, SNCF) or on bahn.de.", "これらの列車の運賃は公開されていません。最安値カレンダーは各社のサイト（ÖBB、SNCF）またはbahn.deで確認してください。")
        m.putIfAbsent("Austria and France: official timetables with real-time delays and platforms when published (Transitous).", "オーストリアとフランス：公式時刻表。公開されている場合はリアルタイムの遅延とホームを表示（Transitous）。")
        m.putIfAbsent("Prices and tickets on the operators' sites (ÖBB, SNCF) or on bahn.de", "運賃と切符は各社のサイト（ÖBB、SNCF）またはbahn.deで")
        m.putIfAbsent("Sharing? When the time is right…", "シェア？その時が来たら…")
        m.putIfAbsent("Unofficial app: not affiliated with, sponsored or endorsed by Trenitalia, RFI, Italo, Trenord or any other transport company. Data comes from public sources.", "非公式アプリ：Trenitalia、RFI、Italo、Trenord その他の交通事業者とは提携・後援・承認関係にありません。データは公開情報源から取得しています。")
        m.putIfAbsent("Tap again for the board and services", "もう一度タップして案内板とサービスを表示")
        m.putIfAbsent("Services near this station", "この駅の近くのサービス")
        m.putIfAbsent("Board", "案内板")
        m.putIfAbsent("Platform ", "ホーム ")
        m.putIfAbsent("Delay now: ", "現在の遅延：")
        m.putIfAbsent("Scheduled times: the delay may change. Created with Binario.", "予定時刻です。遅延は変わることがあります。Binario で作成。")
        m.putIfAbsent("Tracks", "線路")
        m.putIfAbsent("Ahead", "前")
        m.putIfAbsent("Behind", "後")
        m.putIfAbsent("Trains ahead and behind yours", "あなたの列車の前後の列車")
        m.putIfAbsent("Compared at the next stop: ", "次の停車駅での比較：")
        m.putIfAbsent("Your train", "あなたの列車")
        m.putIfAbsent("The train ahead is running late and could slow yours down.", "前を走る列車が遅れており、あなたの列車を遅らせる可能性があります。")
        m.putIfAbsent("Trains in the same direction passing that stop in the 45 minutes before and after yours. Source: ViaggiaTreno.", "あなたの列車の前後45分以内にその駅を通る同方向の列車。出典：ViaggiaTreno。")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "各点は今後1時間以内に拠点から出発する列車で、拠点の周囲に配置されています。GPS位置ではありません。全路線ではなくサンプルです。出典：ViaggiaTreno、SBB（transport.opendata.ch）、Transitous。線路：© OpenStreetMap contributors、スタイル CC-BY-SA 2.0 OpenRailwayMap。")
        m.putIfAbsent("Watch and smartwatch", "腕時計とスマートウォッチ")
        m.putIfAbsent("Followed train status on the watch too", "追跡中の列車の状況を腕時計にも送る")
        m.putIfAbsent("Sends a normal (not pinned) notification when the delay, platform or next stop changes, so Mi Band, Wear OS and other watches show it.", "遅延・ホーム・次の停車駅が変わったときに、通常の（固定されない）通知を送ります。Mi Band、Wear OS などの腕時計に表示されます。")
        m.putIfAbsent("Send a test notification", "テスト通知を送る")
        m.putIfAbsent("Test: if you see this on your watch, all is well.", "テスト：腕時計にこれが表示されれば問題ありません。")
        m.putIfAbsent("Watch status", "腕時計の状況")
        m.putIfAbsent("Binario does not talk to the watch directly: notifications (alerts, strikes, platform changes, delays, reminders) reach your wrist through the watch's own app. Mi Band: in Mi Fitness or Zepp Life open your device › Notifications and reminders › App alerts and turn on Binario. Wear OS: they arrive on their own (check in the Wear OS app › Notifications). In both cases set Binario to «no restrictions» in battery settings. The pinned train notification (with «Stop following») is usually not forwarded: that is why the separate alerts above exist.", "Binario は腕時計と直接通信しません。通知（警報、ストライキ、ホーム変更、遅延、リマインダー）は腕時計のアプリ経由で手首に届きます。Mi Band：Mi Fitness または Zepp Life でデバイスを開き › 通知とリマインダー › アプリ通知 で Binario をオンにします。Wear OS：自動的に届きます（Wear OS アプリ › 通知 で確認）。どちらの場合も、バッテリー設定で Binario を「制限なし」にしてください。固定表示の列車通知（「追跡を停止」付き）は通常転送されません。そのため上記の個別の通知があります。")
        m.putIfAbsent("Cancelled", "運休")
        m.putIfAbsent("Next: ", "次：")
        m.putIfAbsent("Pl. ", "ホーム ")
        m.putIfAbsent("Delays right now: Italy, Switzerland, Germany", "現在の遅延：イタリア・スイス・ドイツ")
        m.putIfAbsent("Not enough data right now", "現在はデータが不足しています")
        m.putIfAbsent("Trains by delay band", "遅延幅別の列車")
        m.putIfAbsent("Average delay", "平均遅延")
        m.putIfAbsent("On time (up to 5 min)", "定刻（5分以内）")
        m.putIfAbsent("Trains with a delay reading", "遅延を取得できた列車")
        m.putIfAbsent("Hubs with the highest average delay", "平均遅延が最も大きい拠点")
        m.putIfAbsent("Sample of trains departing from the big hubs in the next hour, not the whole network. For Italian trains the delay is known only after departure from the origin (ViaggiaTreno): so only trains with a delay reading are counted, and the comparison with Switzerland and Germany, which also give the predicted delay, is only indicative. For monthly statistics and the comparison between companies see below.", "今後1時間に主要拠点を出発する列車のサンプルで、全路線ではありません。イタリアの列車は始発駅を出発した後でないと遅延が分かりません（ViaggiaTreno）。そのため遅延を取得できた列車のみ数え、予想遅延も提供するスイス・ドイツとの比較は目安にすぎません。月次統計と会社間の比較は下をご覧ください。")
        m.putIfAbsent("Train map", "列車マップ")
        m.putIfAbsent("Delay", "遅延")
        m.putIfAbsent("Send by email", "メールで送信")
        m.putIfAbsent("Info and sources", "情報と出典")
        m.putIfAbsent("Rainbow theme", "レインボーテーマ")
        m.putIfAbsent("Each tile has a rainbow colour", "タイルごとに虹の色")
        m.putIfAbsent("Custom colours", "カスタムカラー")
        m.putIfAbsent("Choose your own main colour", "メインカラーを選ぶ")
        m.putIfAbsent("Main colour", "メインカラー")
        m.putIfAbsent("Colour code (hex)", "カラーコード（16進）")
        m.putIfAbsent("Dark background", "暗い背景")
        m.putIfAbsent("Apply", "適用")
        m.putIfAbsent("Text size", "文字サイズ")
        m.putIfAbsent("Large", "大")
        m.putIfAbsent("Very large", "特大")
        m.putIfAbsent("Huge", "最大")
        m.putIfAbsent("Enlarges the text across the app; lines wrap instead of being cut off.", "アプリ全体の文字を大きくします。文字は切り捨てられず折り返されます。")
        m.putIfAbsent("Weather at", "天気：")
        m.putIfAbsent("Feels like", "体感")
        m.putIfAbsent("Wind", "風")
        m.putIfAbsent("Arriving", "まもなく到着")
        m.putIfAbsent("Departs in", "発車まで")
        m.putIfAbsent("Last 30 days history", "直近30日の履歴")
        m.putIfAbsent("Cancelled", "運休")
        m.putIfAbsent("Measured on arrival at", "到着時に計測：")
        m.putIfAbsent("runs operated", "運行本数")
        m.putIfAbsent("Data collected by Binario, unofficial.", "Binarioが収集したデータで、非公式です。")
        m.putIfAbsent("Delay ranking", "遅延ランキング")
        m.putIfAbsent("By day", "日別")
        m.putIfAbsent("30 days", "30日間")
        m.putIfAbsent("Sample from the main hubs: not the list of the whole network.", "主要ハブのサンプルで、全路線ではありません。")
        m.putIfAbsent("Most delayed", "遅延が大きい順")
        m.putIfAbsent("Most punctual", "定時性が高い順")
        m.putIfAbsent("runs", "本")
        m.putIfAbsent("The history is still filling up.", "履歴はまだ蓄積中です。")
        m.putIfAbsent("Binario collects delays every day: in a few days the ranking will be here.", "Binarioは毎日遅延を収集します。数日後にここにランキングが表示されます。")
        m.putIfAbsent("Last 30 days, trains observed by Binario", "直近30日、Binarioが観測した列車")
        m.putIfAbsent("Choose the style", "スタイルを選ぶ")
        m.putIfAbsent("The style changes colours, shapes and the layout of the Home, widgets included. You can change it whenever you like.", "スタイルはホームの色・形・配置を変え、ウィジェットにも反映されます。いつでも変更できます。")
        m.putIfAbsent("The usual look, green", "いつもの緑の外観")
        m.putIfAbsent("Dark amber Solari board", "暗い琥珀色のソラリ式案内板")
        m.putIfAbsent("Find a train", "列車を探す")
        m.putIfAbsent("By number or line", "番号または路線で")
        m.putIfAbsent("Arrivals and departures", "到着と出発")
        m.putIfAbsent("Around you", "現在地の近く")
        m.putIfAbsent("Train map", "列車マップ")
        m.putIfAbsent("Where they are now", "現在の位置")
        m.putIfAbsent("Who is most delayed", "最も遅れている列車")
        m.putIfAbsent("What changes", "変更点")
        m.putIfAbsent("Alarms and reminders", "アラームとリマインダー")
        m.putIfAbsent("Saved on the phone", "スマホに保存済み")
        m.putIfAbsent("Statistics", "統計")
        m.putIfAbsent("Refunds", "払い戻し")
        m.putIfAbsent("Passenger rights", "旅客の権利")
        m.putIfAbsent("Help", "ヘルプ")
        m.putIfAbsent("Frequently asked questions", "よくある質問")
        m.putIfAbsent("Clear", "晴れ")
        m.putIfAbsent("Partly cloudy", "薄曇り")
        m.putIfAbsent("Overcast", "曇り")
        m.putIfAbsent("Fog", "霧")
        m.putIfAbsent("Drizzle", "霧雨")
        m.putIfAbsent("Rain", "雨")
        m.putIfAbsent("Snow", "雪")
        m.putIfAbsent("Showers", "にわか雨")
        m.putIfAbsent("Thunderstorm", "雷雨")
        m.putIfAbsent("Variable", "変わりやすい")
        m.putIfAbsent("Light tiles", "明るいタイル")
        m.putIfAbsent("White tiles on a light blue background, blue header", "水色の背景に白いタイル、青いヘッダー")
        m.putIfAbsent("Coloured tiles", "カラータイル")
        m.putIfAbsent("Each function has its own pastel colour", "機能ごとにパステルカラー")
        m.putIfAbsent("Dark board", "暗い案内板")
        m.putIfAbsent("Black and gold, fixed-width numbers", "黒と金、等幅の数字")
        m.putIfAbsent("Wide-tile list", "幅広タイルのリスト")
        m.putIfAbsent("Wide rows split into sections", "セクション分けされた幅広の行")
        m.putIfAbsent("My train up front", "自分の列車を最前面に")
        m.putIfAbsent("Your next train on top, with a countdown", "上部に次の列車とカウントダウン")
        m.putIfAbsent("Four big tiles and a list", "大きな4つとリスト")
        m.putIfAbsent("Four big tiles, then rows for the rest", "大きな4つのタイル、残りは行表示")
        m.putIfAbsent("Lines and codes", "路線と略号")
        m.putIfAbsent("Rows with a coloured code on the left, like on the lines", "左側に色付きの略号が付いた行")
        m.putIfAbsent("High contrast", "ハイコントラスト")
        m.putIfAbsent("Black and yellow, big tiles and thick borders", "黒と黄色、大きなタイルと太い枠")
        m.putIfAbsent("Three columns by section", "セクション別3列")
        m.putIfAbsent("Compact icons in three columns, with sections", "セクション付きの3列コンパクトアイコン")
        m.putIfAbsent("Today's dashboard", "今日のダッシュボード")
        m.putIfAbsent("Last 30 days, current delays and shortcuts", "直近30日、現在の遅延、ショートカット")
        m.putIfAbsent("Fixes, service status, privacy", "修正、サービス状況、プライバシー")
        m.putIfAbsent("Weather at the station (Open-Meteo)", "駅の天気（Open-Meteo）")
        m.putIfAbsent("Real time", "リアルタイム")
        m.putIfAbsent("Mine", "マイ項目")
        m.putIfAbsent("Prefer to write by email?", "メールで連絡しますか？")
        m.putIfAbsent("Conditions and fares by company", "会社別の条件と運賃")
        m.putIfAbsent("Fares and tickets", "運賃と切符")
        m.putIfAbsent("Rights and refunds", "権利と払い戻し")
        m.putIfAbsent("Source: official website of", "出典：公式サイト")
        m.putIfAbsent("links checked on", "リンク確認日")
        m.putIfAbsent("Conditions and fares change: the app opens each company's official pages without copying their prices. The company's own text prevails.", "条件や運賃は変わります。アプリは各社の公式ページを開き、価格は複製しません。各社の文面が優先されます。")
        m.putIfAbsent("Trains departing soon from the main hubs of Italy, Switzerland and Germany, coloured by delay", "イタリア・スイス・ドイツの主要拠点からまもなく出発する列車（遅延で色分け）")
        m.putIfAbsent("On time", "定刻")
        m.putIfAbsent("1–5 min late", "1〜5分遅れ")
        m.putIfAbsent("6–14 min late", "6〜14分遅れ")
        m.putIfAbsent("15+ min late", "15分以上遅れ")
        m.putIfAbsent("Delay n.a.", "遅延情報なし")
        m.putIfAbsent("Trains shown", "表示中の列車")
        m.putIfAbsent("Open train", "列車を開く")
        m.putIfAbsent("Refresh", "更新")
        m.putIfAbsent("Italy", "イタリア")
        m.putIfAbsent("Switzerland", "スイス")
        m.putIfAbsent("Germany", "ドイツ")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous.", "各点は今後1時間以内に拠点から出発する列車で、拠点の周囲に配置されています。GPS位置ではありません。全路線ではなくサンプルです。出典：ViaggiaTreno、SBB（transport.opendata.ch）、Transitous。")
        m.putIfAbsent("App style", "アプリのスタイル")
        m.putIfAbsent("Traditional", "従来型")
        m.putIfAbsent("Vintage (split-flap board)", "ヴィンテージ（パタパタ案内板）")
        m.putIfAbsent("Refreshing the board…", "案内板を更新中…")
        m.putIfAbsent("TAP THE TITLE TO CHOOSE", "タイトルをタップして選択")
        m.putIfAbsent("NO DATA", "データなし")
        m.putIfAbsent("Departure board style", "発車案内板のスタイル")
        m.putIfAbsent("Classic", "クラシック")
        m.putIfAbsent("Vintage (split-flap)", "ヴィンテージ（パタパタ式）")
        m.putIfAbsent(". After the timetable change buses may be missing until Trenord publishes the new file.", "。ダイヤ改正後は、Trenord が新しいファイルを公開するまでバスが表示されない場合があります。")
        m.putIfAbsent(": Transitous timetables are used for Trenord instead.", "：Trenord には代わりに Transitous の時刻表を使います。")
        m.putIfAbsent("Sources: official Trenord GTFS timetable from Lombardy Region open data (Transitous as a fallback); Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements.", "出典：ロンバルディア州オープンデータの Trenord 公式 GTFS 時刻表（予備として Transitous）、Trenitalia と SBB は Transitous（transitous.org）経由、駅の案内板のバスは ViaggiaTreno（RFI）。各便に出典を表示します。時刻は予定です。運行障害時は駅の案内放送に従ってください。")
        m.putIfAbsent("The Trenord replacement-bus timetable is valid until", "Trenord 代替バスの時刻表の有効期限：")
        m.putIfAbsent("The Trenord timetable file (Lombardy Region) expired on", "Trenord の時刻表ファイル（ロンバルディア州）は期限切れです：")
        m.putIfAbsent("Lombardy Region open data · official Trenord timetable (GTFS)", "ロンバルディア州オープンデータ · Trenord 公式時刻表（GTFS）")
        m.putIfAbsent("Which time is most punctual", "最も時間どおりの便は")
        m.putIfAbsent("on time", "定刻")
        m.putIfAbsent("Each option counts as its least punctual train. Statistics of the latest month, not a forecast: strikes and works can change everything.", "各案は最も遅れやすい列車で数えます。直近 1 か月の統計で予測ではありません。ストライキや工事で状況は変わります。")
        m.putIfAbsent("Text copied", "テキストをコピーしました")
        m.putIfAbsent("Copy the request text", "申請文をコピー")
        m.putIfAbsent("Most delayed trains right now", "今いちばん遅れている列車")
        m.putIfAbsent("No significant delays at the main hubs, or the service is not responding.", "主要駅に大きな遅れはないか、サービスが応答していません。")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Source: ViaggiaTreno.", "主要駅の今後数時間の出発案内からの抜粋です。全路線の一覧ではありません。出典: ViaggiaTreno。")
        m.putIfAbsent("Dual numbering", "二重の列車番号")
        m.putIfAbsent("This service changes number when it passes from one network to another (RFI, FerrovieNord, SBB).", "この列車は、ネットワーク（RFI、FerrovieNord、SBB）を移るときに列車番号が変わります。")
        m.putIfAbsent("From the official Trenord timetables in force: the numbers can change with every timetable change.", "現行のトレノルド公式時刻表によります。ダイヤ改正のたびに番号が変わることがあります。")
        m.putIfAbsent("After", "次の駅の後:")
        m.putIfAbsent("the train becomes", "列車番号は")
        m.putIfAbsent("Reported by ViaggiaTreno.", "ViaggiaTreno による情報です。")
        m.putIfAbsent("Strike tomorrow", "明日ストライキ")
        m.putIfAbsent("Line", "路線")
        m.putIfAbsent("Line page", "路線のページ")
        m.putIfAbsent("Tap for the official line page: stops, timetables and notices.", "タップすると路線の公式ページ（停車駅・時刻表・お知らせ）を開きます。")
        m.putIfAbsent("Lines through this station", "この駅を通る路線")
        m.putIfAbsent("From the departures of the next few hours. Frecce, Intercity and Trenitalia regional trains have no line in the official timetables.", "今後数時間の発車情報より。Frecce、Intercity、Trenitalia の普通列車は公式時刻表に路線がありません。")
        m.putIfAbsent("Official website", "公式サイト")
        m["Automatic (mobile network)"] = "自動（モバイルネットワーク）"
        m.putIfAbsent("Germany", "ドイツ")
        m.putIfAbsent("Italy", "イタリア")
        m["Country for emergencies and defibrillators"] = "緊急時と AED の国"
        m["Expected occupancy in DB Navigator"] = "DB Navigator で混雑予想を見る"
        m["Expected occupancy on sbb.ch"] = "sbb.ch で混雑予想を見る"
        m["SBB assistance for people with disabilities (Contact Center Handicap)"] = "スイス連邦鉄道の障がい者サポート（Contact Center Handicap）"
        m["No official data: DB publishes expected occupancy only in DB Navigator and on bahn.de. This is an estimate by time of day."] = "公式データなし：DB は混雑予想を DB Navigator と bahn.de でのみ公開しています。ここでは時間帯による推定を表示します。"
        m["German companies do not publish per-train services (wheelchair spaces, bikes) in open data: you can find them in DB Navigator or on bahn.de. "] = "ドイツの鉄道会社は列車ごとのサービス（車いすスペース、自転車）をオープンデータで公開していません。DB Navigator か bahn.de で確認できます。"
        m.putIfAbsent("Switzerland", "スイス")
        m["The Rega (air rescue) app sends your location to the operations centre. Ambulance: 144."] = "Rega（航空救助）アプリが現在地を指令センターに送ります。救急車：144。"
        m["The official emergency app of the German federal states: reach 112 and 110 also in writing, with your location."] = "ドイツ各州の公式緊急通報アプリ：位置情報付きで、文字でも 112 と 110 に連絡できます。"
        m.putIfAbsent("Train cancelled", "列車は運休")
        m.putIfAbsent("Train heavily delayed", "列車が大幅に遅延")
        m.putIfAbsent("No connection", "接続なし")
        m.putIfAbsent("Last reading: %d min ago", "最終取得：%d分前")
        m.putIfAbsent("It updates as soon as the network is back.", "ネットワークが戻り次第、更新されます。")
    }

    private fun p14(m: HashMap<String, String>) {
        m.putIfAbsent("No connection. Check your Wi-Fi or mobile data.", "接続がありません。Wi-Fiまたはモバイルデータを確認してください。")
        m.putIfAbsent("The service is not responding. Try again shortly.", "サービスが応答しません。しばらくしてからもう一度お試しください。")
        m.putIfAbsent("Too many requests. Wait a minute and try again.", "リクエストが多すぎます。1分待ってからもう一度お試しください。")
        m.putIfAbsent("Not found: the service does not have this data.", "見つかりません：サービスにこのデータがありません。")
        m.putIfAbsent("The service has a problem. Try again later.", "サービスに問題が発生しています。後でもう一度お試しください。")
        m.putIfAbsent("Something went wrong. Try again.", "うまくいきませんでした。もう一度お試しください。")
        m.putIfAbsent("You are offline. Showing the latest available data.", "オフラインです。利用できる最新のデータを表示しています。")
        m.putIfAbsent("The service is not responding: some data is %d min old.", "サービスが応答しません：一部のデータは %d 分前のものです。")
        m.putIfAbsent("With the app's latest network errors (service addresses only, no personal data).", "アプリの最近のネットワークエラーを添付します（サービスのアドレスのみ。個人データは含みません）。")
        m.putIfAbsent("Try changing the time or the station.", "時刻または駅を変えてみてください。")
        m.putIfAbsent("Looking for alternatives…", "代替案を探しています…")
        m.putIfAbsent("Advanced", "詳細")
        m.putIfAbsent("Just the essentials: timetable search, strikes and your shortcuts.", "基本のみ：時刻検索、ストライキ、ショートカット。")
        m.putIfAbsent("Also: passengers, train type, prices, My trips, offline timetables, lines and fares.", "さらに：乗客、列車の種類、料金、マイ旅程、オフライン時刻表、路線、運賃。")
        m.putIfAbsent("All features: also maps, other countries, emergency, assistant and style tiles.", "すべての機能：地図、海外、緊急、アシスタント、スタイルのタイルも。")
        m.putIfAbsent("Show all features", "すべての機能を表示")
        m.putIfAbsent("Accessible", "バリアフリー")
        m.putIfAbsent("Accessible stations", "バリアフリーの駅")
        m.putIfAbsent("Other services", "その他のサービス")
        m.putIfAbsent("Open the notice document (PDF)", "お知らせの資料を開く（PDF）")
        m.putIfAbsent("Open the station page", "駅のページを開く")
        m.putIfAbsent("Trenord notice", "Trenordのお知らせ")
        m.putIfAbsent("Bars and restaurants", "バーとレストラン")
        m.putIfAbsent("Bike sharing", "シェアサイクル")
        m.putIfAbsent("Get directions", "経路を検索")
        m.putIfAbsent("Car sharing", "カーシェア")
        m.putIfAbsent("With ticket office", "窓口あり")
        m.putIfAbsent("With ticket machines", "券売機あり")
        m.putIfAbsent("From the Trenord website. Tap a station for its address and other services.", "Trenordのサイトより。駅をタップすると住所とその他のサービスが見られます。")
        m.putIfAbsent("Defibrillator", "AED（除細動器）")
        m.putIfAbsent("Left luggage", "手荷物預かり")
        m.putIfAbsent("Machines", "券売機")
        m.putIfAbsent("Ticket machines", "自動券売機")
        m.putIfAbsent("Newsstand", "売店")
        m.putIfAbsent("Address", "住所")
        m.putIfAbsent("Reading the station page from the Trenord website…", "Trenordのサイトから駅の情報を読み込み中…")
        m.putIfAbsent("Show all", "すべて表示")
        m.putIfAbsent("No services listed", "サービスの記載なし")
        m.putIfAbsent("No stations with these services.", "これらのサービスがある駅はありません。")
        m.putIfAbsent("Parking", "駐車場")
        m.putIfAbsent("Car park", "駐車場（車）")
        m.putIfAbsent("Bike parking", "駐輪場")
        m.putIfAbsent("Waiting room", "待合室")
        m.putIfAbsent("Escalators", "エスカレーター")
        m.putIfAbsent("Station page not available right now.", "駅の情報は現在利用できません。")
        m.putIfAbsent("Accessibility services", "バリアフリーサービス")
        m.putIfAbsent("Stations on the line", "路線の駅")
        m.putIfAbsent("Wi-Fi", "Wi-Fi")
        m.putIfAbsent("TILO trains that left in the last 3 hours, in both directions, from the Swiss timetable: it counts delays over 15 minutes, not cancelled trains. For cancellations see the SBB notices below.", "過去3時間に両方向で出発したTILOの列車（スイスの時刻表）。15分を超える遅れを数え、運休は含みません。運休は下のSBBのお知らせを見てください。")
        m.putIfAbsent("SBB notices on the line", "路線のSBBのお知らせ")
        m.putIfAbsent("Checking SBB notices…", "SBBのお知らせを確認中…")
        m.putIfAbsent("No current SBB notices: according to SBB, service is running normally.", "現在SBBのお知らせはありません。SBBによると運行は平常です。")
        m.putIfAbsent("SBB open data (texts in English).", "SBBのオープンデータ（英語のテキスト）。")
        m.putIfAbsent("SBB service status", "SBBの運行状況")
        m.putIfAbsent("Delete this trip?", "この旅程を削除しますか？")
        m.putIfAbsent("Across all trips on the chosen route", "選択した区間のすべての旅程")
        m.putIfAbsent("Morning (5–10)", "朝（5〜10時）")
        m.putIfAbsent("Daytime (10–16)", "日中（10〜16時）")
        m.putIfAbsent("Evening (16–21)", "夕方（16〜21時）")
        m.putIfAbsent("Night (21–5)", "夜（21〜5時）")
        m.putIfAbsent("When your trains are most late", "列車が最も遅れる時間帯")
        m.putIfAbsent("Across all trips in the log", "記録したすべての旅行から")
        m.putIfAbsent("{0} trips · average delay {1} min · {2} with 15 min or more", "{0}回 · 平均遅れ {1}分 · 15分以上 {2}回")
        m.putIfAbsent("most delays", "最も遅れる")
        m.putIfAbsent("today", "今日")
        m.putIfAbsent("yesterday", "昨日")
        m.putIfAbsent("Last few days (worst moment)", "直近の数日（最悪の時点）")
        m.putIfAbsent("All routes", "すべての区間")
        m.putIfAbsent("Compensation claim", "補償の申請")
        m.putIfAbsent("Not today", "今日は通知しない")
        m.putIfAbsent("Year", "年")
        m.putIfAbsent("Arrival delay, day by day", "到着時の遅れ（日ごと）")
        m.putIfAbsent("Filled bar: minutes late (top = 60 or more). Empty bar: train cancelled.", "塗りつぶし：遅れ（分、上端＝60分以上）。枠のみ：運休。")
        m.putIfAbsent("Days with trips: {0}. No delays. Cancelled: {1}.", "旅行のあった日：{0}日。遅れなし。運休：{1}。")
        m.putIfAbsent("Days with trips: {0}. Highest delay: {1} minutes on day {2}. Cancelled: {3}.", "旅行のあった日：{0}日。最大の遅れ：{2}日に{1}分。運休：{3}。")
        m.putIfAbsent("{0} minutes late", "{0}分遅れ")
        m.putIfAbsent("Date", "日付")
        m.putIfAbsent("Scheduled arrival", "到着予定")
        m.putIfAbsent("Delay (min)", "遅れ（分）")
        m.putIfAbsent("Yes", "はい")
        m.putIfAbsent("Delays this month", "今月の遅れ")
        m.putIfAbsent("Search the guide", "ガイド内を検索")
        m.putIfAbsent("No topic found", "該当する項目はありません")
        m.putIfAbsent("Tap to open «My trips» and share the month.", "タップして「私の旅行」を開き、この月を共有します。")
        m.putIfAbsent("added by hand", "手動で追加")
        m.putIfAbsent("Add a trip", "旅行を追加")
        m.putIfAbsent("Train (e.g. R 2727)", "列車（例：R 2727）")
        m.putIfAbsent("Date (dd/mm/yyyy)", "日付（日/月/年）")
        m.putIfAbsent("Scheduled arrival (hh:mm)", "到着予定（時:分）")
        m.putIfAbsent("Minutes late on arrival", "到着時の遅れ（分）")
        m.putIfAbsent("Write the train with its number, for example R 2727.", "列車を番号付きで入力してください（例：R 2727）。")
        m.putIfAbsent("Write the departure and arrival stations.", "出発駅と到着駅を入力してください。")
        m.putIfAbsent("Check date and time: for example 09/11/2026 and 08:15.", "日付と時刻を確認してください（例：09/11/2026、08:15）。")
        m.putIfAbsent("The trip cannot be in the future.", "未来の旅行は登録できません。")
        m.putIfAbsent("The delay must be from 0 to 999 minutes.", "遅れは0〜999分で入力してください。")
        m.putIfAbsent("Low disruption", "乱れ：小")
        m.putIfAbsent("Moderate disruption", "乱れ：中")
        m.putIfAbsent("High disruption", "乱れ：大")
        m.putIfAbsent("1 strike hidden by the filter", "フィルターで1件のストを非表示")
        m.putIfAbsent("{0} strikes hidden by the filter", "フィルターで{0}件のストを非表示")
        m.putIfAbsent("1 notice hidden by the filter", "フィルターで1件のお知らせを非表示")
        m.putIfAbsent("{0} notices hidden by the filter", "フィルターで{0}件のお知らせを非表示")
        m.putIfAbsent("Share the month", "この月を共有")
        m.putIfAbsent("Times recorded by the Binario app: they do not replace the operator's official certificates.", "Binarioアプリが記録した時刻です。事業者の公式な証明書の代わりにはなりません。")
        m.putIfAbsent("{0}: scheduled {1}, actual {2}", "{0}：予定 {1}、実績 {2}")
        m.putIfAbsent("{0}: scheduled {1}, expected {2}", "{0}：予定 {1}、見込み {2}")
        m.putIfAbsent("{0}: scheduled {1}", "{0}：予定 {1}")
        m.putIfAbsent("How to read the times", "時刻の見方")
        m.putIfAbsent("Actual time: the train passed on time", "実績時刻：定刻に通過")
        m.putIfAbsent("Actual time: the train passed late", "実績時刻：遅れて通過")
        m.putIfAbsent("Expected time: scheduled plus the current delay reported by the operator", "見込み時刻：予定時刻に事業者が発表した現在の遅れを加えたもの")
        m.putIfAbsent("When data comes from several operators, the source is shown under the stop name (e.g. Trenord, SBB).", "複数の事業者のデータを使う場合、駅名の下に情報源を表示します（例：Trenord、SBB）。")
        m.putIfAbsent("Disruption on the line (last 3 hours)", "路線の乱れ（直近3時間）")
        m.putIfAbsent("Checking the trains of the last few hours…", "直近数時間の列車を確認中…")
        m.putIfAbsent("No trains departed in the last 3 hours.", "直近3時間に発車した列車はありません。")
        m.putIfAbsent("{0} critical trains out of {1}", "{1}本中{0}本に大きな乱れ")
        m.putIfAbsent("Short-run", "区間運休・短縮")
        m.putIfAbsent("Over 15 min", "15分超")
        m.putIfAbsent("Trains that departed in the last 3 hours, in both directions. Critical: cancelled, short-run or more than 15 minutes late.", "直近3時間に発車した列車（両方向）。大きな乱れ：運休、区間運休・短縮、または15分を超える遅れ。")
        m.putIfAbsent("My trips", "私の旅行")
        m.putIfAbsent("Trains followed to arrival, delays this month", "到着まで追跡した列車、今月の遅れ")
        m.putIfAbsent("Previous month", "前の月")
        m.putIfAbsent("Next month", "次の月")
        m.putIfAbsent("No trips yet", "まだ旅行はありません")
        m.putIfAbsent("When you follow a train (the «Follow» button on the train page) until it arrives, the trip appears here with its delay. It stays on this phone only.", "列車を（列車ページの「フォロー」ボタンで）到着まで追跡すると、遅れとともにここに表示されます。この端末にのみ保存されます。")
        m.putIfAbsent("No trips this month.", "今月の旅行はありません。")
        m.putIfAbsent("The trip log stays on this phone only.", "記録はこの端末にのみ保存されます。")
        m.putIfAbsent("Clear the trip log", "記録を消去")
        m.putIfAbsent("Delete all saved trips?", "保存したすべての旅行を削除しますか？")
        m.putIfAbsent("Trips", "旅行")
        m.putIfAbsent("Delay of 15 min or more", "15分以上の遅れ")
        m.putIfAbsent("Delay of 60 min or more", "60分以上の遅れ")
        m.putIfAbsent("Total minutes of delay", "遅れの合計（分）")
        m.putIfAbsent("With a delay of 60 minutes or more you can claim compensation.", "60分以上遅れた場合は補償を請求できます。")
        m.putIfAbsent("If you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation.", "定期券をお持ちの場合、遅れは月間ボーナス（Trenord）や補償の対象になります。")
    }
}
