package com.binario.treni.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.binario.treni.data.Api
import com.binario.treni.data.perUtente
import com.binario.treni.data.Fmt
import com.binario.treni.data.SavedSearch
import com.binario.treni.data.SearchFilter
import com.binario.treni.data.Solution
import com.binario.treni.data.Station
import com.binario.treni.data.Store
import com.binario.treni.data.Tratta
import com.binario.treni.data.TrainStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    // Parametri di ricerca
    var from by mutableStateOf<Station?>(null)
    var to by mutableStateOf<Station?>(null)
    var roundTrip by mutableStateOf(false)
    var date by mutableStateOf(roundToQuarter(System.currentTimeMillis()))
    var returnDate by mutableStateOf(roundToQuarter(System.currentTimeMillis() + 3 * 3600_000L))
    var filter by mutableStateOf(SearchFilter.BEST)
    var maxChanges by mutableStateOf(store.maxChanges)
    var excluded by mutableStateOf(store.excluded)
    /** Passeggeri: adulti e ragazzi (i prezzi sono il totale per tutti). */
    var pax by mutableStateOf(com.binario.treni.data.Pax(store.paxAdults.coerceIn(1, 9), store.paxChildren.coerceIn(0, 9)))

    // Risultati
    var results by mutableStateOf<List<Solution>>(emptyList())
    var returnResults by mutableStateOf<List<Solution>>(emptyList())
    var loading by mutableStateOf(false)
    var loadingMore by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    /** true se l'errore è di rete o del servizio (si può riprovare); false se semplicemente non ci sono soluzioni. */
    var errorIsNetwork by mutableStateOf(false)
    var offlineTitle by mutableStateOf<String?>(null)
    var offlineSaved by mutableStateOf<SavedSearch?>(null)
    /** Avviso quando, senza rete, mostriamo gli ultimi orari salvati della tratta. */
    var staleNote by mutableStateOf<String?>(null)

    /** Treno da mostrare sulla mappa del tragitto. */
    var mapTrain by mutableStateOf<TrainStatus?>(null)

    fun saveAdvanced(max: Int, ex: Set<String>) {
        maxChanges = max; excluded = ex
        store.maxChanges = max; store.excluded = ex
    }

    /** Da dove si è aperto l'ultimo treno (tabellone o soluzioni): serve a imparare i treni abituali. */
    var tripBoard: Station? = null
    var tripAlight: Station? = null

    /** Linea da mostrare nella schermata linea. */
    var currentLine by mutableStateOf<com.binario.treni.data.Linea?>(null)

    fun swap() {
        val f = from; from = to; to = f
    }

    fun search() {
        val f = from ?: return
        val t = to ?: return
        store.addRecent(Tratta(f, t))
        offlineTitle = null
        offlineSaved = null
        loading = true
        error = null
        errorIsNetwork = false
        results = emptyList()
        returnResults = emptyList()
        staleNote = null
        viewModelScope.launch {
            try {
                results = withContext(Dispatchers.IO) { Api.solutions(f, t, date, filter, maxChanges, excluded, pax) }
                if (roundTrip) {
                    returnResults = withContext(Dispatchers.IO) { Api.solutions(t, f, returnDate, filter, maxChanges, excluded, pax) }
                }
                // Copia automatica degli ultimi orari della tratta, per quando manca la rete
                if (results.isNotEmpty()) withContext(Dispatchers.IO) { store.cacheResults(Tratta(f, t).key, results) }
                if (results.isEmpty()) error = com.binario.treni.data.I18n.tr("Nessuna soluzione trovata per l'orario scelto.", "No solutions found for the chosen time.")
            } catch (e: Exception) {
                // Senza rete: ultimi orari scaricati per la stessa tratta (dalle soluzioni successive all'ora scelta)
                val cached = withContext(Dispatchers.IO) { store.cachedResults(Tratta(f, t).key) }
                val useful = cached?.second?.filter { it.dep >= date - 30 * 60_000L }.orEmpty()
                if (cached != null && useful.isNotEmpty()) {
                    results = useful
                    staleNote = com.binario.treni.data.I18n.tr(
                        com.binario.treni.data.I18n.tr("Connessione assente: orari scaricati alle ${Fmt.time(cached.first)} del ${Fmt.day(cached.first)}. Ritardi non aggiornati.", "No connection: timetable downloaded at ${Fmt.time(cached.first)} on ${Fmt.day(cached.first)}. Delays not updated."),
                        "Offline: timetable downloaded at ${Fmt.time(cached.first)} on ${Fmt.day(cached.first)}. Delays not updated.")
                } else {
                    error = e.perUtente()
                    errorIsNetwork = true
                }
            }
            loading = false
        }
    }

    /** Carica le soluzioni successive all'ultima mostrata. */
    fun loadMore(returnLeg: Boolean) {
        val list = if (returnLeg) returnResults else results
        val last = list.lastOrNull() ?: return
        val f = (if (returnLeg) to else from) ?: return
        val t = (if (returnLeg) from else to) ?: return
        loadingMore = true
        viewModelScope.launch {
            try {
                val more = withContext(Dispatchers.IO) { Api.solutions(f, t, last.dep + 60_000, filter, maxChanges, excluded, pax) }
                val merged = (list + more).distinctBy { it.dep.toString() + it.legs.joinToString { l -> l.number } }
                if (returnLeg) returnResults = merged else results = merged
            } catch (_: Exception) {
            }
            loadingMore = false
        }
    }

    fun saveOffline(): Boolean {
        val f = from ?: return false
        val t = to ?: return false
        if (results.isEmpty()) return false
        val key = "${f.id}>${t.id}@${Fmt.day(date)}"
        store.saveSearch(SavedSearch(key, "${f.name} → ${t.name} · ${Fmt.dayTime(date)}", System.currentTimeMillis(), results))
        return true
    }

    /** Rifà la ricerca di un orario salvato con la rete: stessa tratta, orario del primo treno salvato (o adesso se è passato). */
    fun refreshSaved() {
        val s = offlineSaved ?: return
        val ids = com.binario.treni.data.SavedAge.parseKey(s.key) ?: return
        val names = com.binario.treni.data.SavedAge.parseTitle(s.title) ?: return
        from = Station(names.first, ids.first)
        to = Station(names.second, ids.second)
        val first = s.solutions.firstOrNull()?.dep ?: 0L
        date = roundToQuarter(maxOf(System.currentTimeMillis(), first))
        search()
    }

    fun openSaved(s: SavedSearch) {
        offlineTitle = s.title
        offlineSaved = s
        results = s.solutions
        returnResults = emptyList()
        roundTrip = false
        error = null
        errorIsNetwork = false
        loading = false
    }

    companion object {
        fun roundToQuarter(ms: Long): Long {
            val q = 15 * 60_000L
            return ms - ms % q
        }
    }
}
