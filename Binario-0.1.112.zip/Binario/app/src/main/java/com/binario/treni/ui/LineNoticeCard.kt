package com.binario.treni.ui

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessible
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.binario.treni.data.LineNotice
import com.binario.treni.data.LinkLoc
import com.binario.treni.data.Lru
import com.binario.treni.data.TrenordPage
import com.binario.treni.data.tx
import org.json.JSONArray

/** Colore dello stato: rosso per i problemi gravi, arancione per le criticità, verde se è regolare. Il testo dice sempre lo stesso. */
fun noticeColor(level: LineNotice.Level): Color = when (level) {
    LineNotice.Level.SEVERE -> LateRed
    LineNotice.Level.WARNING -> Color(0xFFE08A00)
    LineNotice.Level.REGULAR -> Green
    LineNotice.Level.OTHER -> Muted
}

/** Ultima lettura completa di ogni pagina (stazioni e documenti non si salvano sul telefono: si rileggono). */
private val lineCache = Lru<String, Pair<Long, TrenordPage.Line>>(40)
private val stationCache = Lru<String, TrenordPage.StationInfo>(200)

/**
 * Apre in un WebView invisibile una pagina Trenord (costruita con JavaScript), esegue [js] e passa il risultato a
 * [parse]; riprova qualche volta finché la pagina non è pronta ([ready]).
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun <T> PageReader(url: String, js: String, parse: (String) -> T?, ready: (T, Int) -> Boolean, onResult: (T?) -> Unit) {
    AndroidView(
        modifier = Modifier.size(1.dp),
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                var tries = 0
                var done = false
                var best: T? = null
                fun read(v: WebView) {
                    if (done) return
                    v.evaluateJavascript(js) { res ->
                        if (done) return@evaluateJavascript
                        val text = try { JSONArray("[" + res + "]").getString(0) } catch (e: Exception) { "" }
                        val r = try { parse(text) } catch (e: Exception) { null }
                        if (r != null) best = r
                        val b = best
                        if (b != null && ready(b, tries)) { done = true; onResult(b) }
                        else if (tries++ < 6) v.postDelayed({ read(v) }, 2500)
                        else { done = true; onResult(best) }
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, u: String?) { view.postDelayed({ read(view) }, 2000) }
                }
                loadUrl(LinkLoc.url(url))
            }
        },
        onRelease = { it.destroy() },
    )
}

/**
 * Messaggi di Trenord sulla linea, riportati nell'app senza aprire il sito: stato della linea, tutti gli avvisi (con i
 * documenti PDF allegati) e, con [showStations], le stazioni sulla linea con i loro servizi. Vale anche per le linee
 * TILO che hanno la pagina su trenord.it (S10, S30, S40, S50, RE80…).
 */
@Composable
fun LineNoticeCard(url: String, openWeb: ((String, String) -> Unit)? = null, name: String = "", showStations: Boolean = false) {
    if (!LineNotice.isTrenordLinePage(url)) return
    val ctx = LocalContext.current
    val fresh = lineCache[url]?.takeIf { System.currentTimeMillis() - it.first < 10 * 60_000L }?.second
    var line by remember(url) { mutableStateOf(fresh) }
    var page by remember(url) { mutableStateOf(fresh?.page ?: LineNotice.cached(url)) }
    var failed by remember(url) { mutableStateOf(false) }
    var stale by remember(url) { mutableStateOf(false) }
    var all by remember(url) { mutableStateOf(false) }
    val prefs = remember { ctx.applicationContext.getSharedPreferences("line_notice", android.content.Context.MODE_PRIVATE) }
    val key = "n_" + url.hashCode()
    fun open(title: String, u: String) { if (openWeb != null) openWeb(title, u) else openUrl(ctx, u) }
    if (line == null && !failed && !stale) {
        PageReader(
            url, TrenordPage.LINE_JS, { TrenordPage.parseLine(it) },
            // Le stazioni compaiono un po' dopo lo stato: si aspetta qualche tentativo in più se mancano
            ready = { l, tries -> l.page != null && (l.stations.isNotEmpty() || tries >= 3) },
        ) { l ->
            val p = l?.page
            if (l != null) { line = l; lineCache[url] = System.currentTimeMillis() to l }
            if (p != null) {
                LineNotice.put(url, p); page = p
                try { prefs.edit().putString(key, LineNotice.encode(p)).apply() } catch (_: Exception) { }
            } else if (page == null) {
                // Pagina non raggiungibile: si mostra l'ultimo messaggio letto, dichiarando che non è aggiornato
                val old = try { LineNotice.decode(prefs.getString(key, null)) } catch (_: Exception) { null }
                if (old != null) { page = old; stale = true } else failed = true
            }
        }
    }
    WhiteCard {
        CardTitle(tx("Ultimo messaggio di Trenord"))
        val p = page
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            when {
                p == null && !failed -> {
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                    Text(tx("Leggo il messaggio dal sito Trenord…"), color = Muted, fontSize = 13.sp)
                }
                p == null -> Text(tx("Messaggio non disponibile ora."), color = Muted, fontSize = 14.sp)
                else -> {
                    if (stale) Text(tx("Ultimo messaggio salvato: ora la pagina Trenord non risponde."), color = Muted, fontSize = 12.sp)
                    val s = p.status
                    if (s != null) {
                        val lvl = LineNotice.level(s.title)
                        val tint = noticeColor(lvl)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (lvl == LineNotice.Level.REGULAR) Icons.Filled.CheckCircle else Icons.Filled.Warning, null, tint = tint, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(s.title.ifBlank { tx("Stato della linea") }, fontWeight = FontWeight.Bold, color = tint, modifier = Modifier.weight(1f))
                        }
                        if (s.date.isNotBlank()) Text(s.date, color = Muted, fontSize = 12.sp)
                        if (s.body.isNotBlank()) Text(if (all) s.body else LineNotice.excerpt(s.body), fontSize = 14.sp)
                    }
                    // Tutti gli avvisi della pagina (prima solo il primo); senza la lettura completa, quello salvato
                    val notices = line?.notices?.takeIf { it.isNotEmpty() } ?: listOfNotNull(p.notice)
                    if (notices.isNotEmpty()) {
                        if (s != null) HorizontalDivider()
                        Text(if (notices.size > 1) tx("Avvisi") + " (${notices.size})" else tx("Ultimo avviso"), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        (if (all) notices else notices.take(2)).forEachIndexed { i, n ->
                            if (i > 0) HorizontalDivider(color = Muted.copy(alpha = 0.3f))
                            if (n.title.isNotBlank()) Text(n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            if (n.date.isNotBlank()) Text(n.date, color = Muted, fontSize = 12.sp)
                            if (n.body.isNotBlank()) Text(if (all) n.body else LineNotice.excerpt(n.body, 160), fontSize = 14.sp)
                        }
                    }
                    // Documenti allegati agli avvisi (PDF con i treni che cambiano): si aprono dall'app
                    line?.docs?.take(4)?.forEach { d ->
                        TextButton({ open(tx("Avviso Trenord"), d.url) }) {
                            Icon(Icons.Filled.Description, null, tint = Green, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(tx("Apri il documento dell'avviso (PDF)"), color = Green)
                        }
                    }
                    val long = (s?.body?.length ?: 0) > 220 || notices.size > 2 || notices.any { it.body.length > 160 }
                    if (long) TextButton({ all = !all }) { Text(if (all) tx("Mostra meno") else tx("Mostra tutto"), color = Green) }
                }
            }
            TextButton({ open(name.ifBlank { "Trenord" }, url) }) {
                Text(tx("Apri la pagina della linea"), color = Green)
            }
        }
    }
    val st = line?.stations.orEmpty()
    if (showStations && st.isNotEmpty()) LineStationsCard(st) { s -> open(s.name, s.url) }
}

/** Stazioni sulla linea (dalla pagina Trenord) con i servizi scritti a parole, i filtri come sul sito e la scheda di ogni stazione. */
@Composable
private fun LineStationsCard(stations: List<TrenordPage.LineStation>, openPage: (TrenordPage.LineStation) -> Unit) {
    var office by remember { mutableStateOf(false) }
    var machines by remember { mutableStateOf(false) }
    var access by remember { mutableStateOf(false) }
    var allRows by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<TrenordPage.LineStation?>(null) }
    val shown = stations.filter { (!office || it.ticketOffice) && (!machines || it.machines) && (!access || it.accessible) }
    WhiteCard {
        CardTitle(tx("Stazioni sulla linea") + " (${stations.size})")
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
            ChipRow {
                FilterChip(office, { office = !office }, label = { Text(tx("Con biglietteria"), fontSize = 13.sp) }, modifier = Modifier.padding(end = 6.dp))
                FilterChip(machines, { machines = !machines }, label = { Text(tx("Con distributori automatici"), fontSize = 13.sp) }, modifier = Modifier.padding(end = 6.dp))
                FilterChip(access, { access = !access }, label = { Text(tx("Accessibili"), fontSize = 13.sp) })
            }
            if (shown.isEmpty()) Text(tx("Nessuna stazione con questi servizi."), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp))
            (if (allRows) shown else shown.take(8)).forEach { s ->
                val services = listOfNotNull(
                    tx("Biglietteria").takeIf { s.ticketOffice },
                    tx("Distributori automatici").takeIf { s.machines },
                    tx("Accessibile").takeIf { s.accessible },
                )
                Column(
                    Modifier.fillMaxWidth().clickable { info = s }.padding(vertical = 8.dp)
                        .semantics(mergeDescendants = true) { contentDescription = s.name + ". " + services.joinToString(", ").ifBlank { tx("Nessun servizio indicato") } },
                ) {
                    Text(s.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (s.ticketOffice) ServiceTag(Icons.Filled.ConfirmationNumber, tx("Biglietteria"))
                        if (s.machines) ServiceTag(Icons.Filled.PointOfSale, tx("Distributori"))
                        if (s.accessible) ServiceTag(Icons.Filled.Accessible, tx("Accessibile"))
                        if (services.isEmpty()) Text(tx("Nessun servizio indicato"), color = Muted, fontSize = 12.sp)
                    }
                }
                HorizontalDivider(color = Muted.copy(alpha = 0.25f))
            }
            if (shown.size > 8) TextButton({ allRows = !allRows }) {
                Text(if (allRows) tx("Mostra meno") else tx("Mostra tutte") + " (${shown.size})", color = Green)
            }
            Text(tx("Dal sito Trenord. Tocca una stazione per indirizzo e altri servizi."), color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
        }
    }
    info?.let { s -> StationInfoDialog(s, onDismiss = { info = null }) { openPage(s) } }
}

@Composable
private fun ServiceTag(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Icon(icon, null, tint = Green, modifier = Modifier.size(16.dp))
    Spacer(Modifier.width(3.dp))
    Text(label, fontSize = 12.sp, color = Muted)
    Spacer(Modifier.width(10.dp))
}

/** Scheda della stazione dal sito Trenord: indirizzo e altri servizi (bar, deposito bagagli, ascensori, sala d'attesa…). */
@Composable
private fun StationInfoDialog(s: TrenordPage.LineStation, onDismiss: () -> Unit, onOpenPage: () -> Unit) {
    val ctx = LocalContext.current
    var info by remember(s.url) { mutableStateOf(stationCache[s.url]) }
    var failed by remember(s.url) { mutableStateOf(false) }
    if (info == null && !failed) {
        PageReader(s.url, TrenordPage.STATION_JS, { TrenordPage.parseStation(it) }, ready = { _, _ -> true }) { r ->
            if (r != null) { info = r; stationCache[s.url] = r } else failed = true
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(s.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val services = listOfNotNull(
                    tx("Biglietteria").takeIf { s.ticketOffice },
                    tx("Distributori automatici").takeIf { s.machines },
                    tx("Accessibile").takeIf { s.accessible },
                )
                if (services.isNotEmpty()) Text(services.joinToString(" · "), fontSize = 14.sp)
                val i = info
                when {
                    i == null && !failed -> {
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                        Text(tx("Leggo la scheda della stazione dal sito Trenord…"), color = Muted, fontSize = 13.sp)
                    }
                    i == null -> Text(tx("Scheda della stazione non disponibile ora."), color = Muted, fontSize = 13.sp)
                    else -> {
                        if (i.address.isNotBlank()) {
                            Text(tx("Indirizzo"), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(i.address, fontSize = 14.sp)
                            TextButton({ openUrl(ctx, "https://www.google.com/maps/search/?api=1&query=" + java.net.URLEncoder.encode(i.address, "UTF-8")) }) {
                                Text(tx("Calcola percorso"), color = Green)
                            }
                        }
                        if (i.services.isNotEmpty()) {
                            Text(tx("Altri servizi"), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(i.services.joinToString(" · ") { tx(it) }, fontSize = 14.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton({ onOpenPage(); onDismiss() }) { Text(tx("Apri la pagina della stazione"), color = Green) } },
        dismissButton = { TextButton(onDismiss) { Text(tx("Chiudi")) } },
    )
}
