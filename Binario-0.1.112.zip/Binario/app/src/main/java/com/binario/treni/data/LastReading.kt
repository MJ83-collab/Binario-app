package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ultima lettura di un treno, salvata sul telefono: se manca la rete la scheda Treno mostra questa (con l'età dichiarata
 * solo in quel caso) invece di una schermata vuota. In uso normale non compare nulla.
 */
object LastReading {
    private const val KEEP = 12
    private const val MAX_AGE_MS = 12 * 3600_000L

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("binario_last", Context.MODE_PRIVATE)
    fun key(ref: TrainRef) = ref.number + "@" + ref.originCode + "@" + ref.date

    fun toJson(s: TrainStatus): JSONObject = JSONObject()
        .put("n", s.number).put("c", s.category).put("o", s.origin).put("d", s.destination).put("oc", s.originCode)
        .put("dt", s.date).put("dl", s.delay).put("ls", s.lastStation).put("lt", s.lastTime).put("x", s.cancelled)
        .put("i", s.info).put("op", s.operator)
        .put("st", JSONArray().apply {
            s.stops.forEach {
                put(JSONObject().put("n", it.name).put("id", it.id).put("sa", it.schedArr).put("sd", it.schedDep)
                    .put("ra", it.realArr).put("rd", it.realDep).put("dl", it.delay).put("p", it.platform)
                    .put("pc", it.platformChanged).put("pf", it.platformConfirmed)
                    .put("sp", it.schedPlatform).put("rp", it.realPlatform).put("s", it.src))
            }
        })

    fun fromJson(o: JSONObject): TrainStatus {
        val arr = o.optJSONArray("st") ?: JSONArray()
        val stops = (0 until arr.length()).map { i ->
            val t = arr.getJSONObject(i)
            TrainStop(t.optString("n"), t.optString("id"), t.optLong("sa"), t.optLong("sd"), t.optLong("ra"), t.optLong("rd"),
                t.optInt("dl"), t.optString("p"), t.optBoolean("pc"), t.optBoolean("pf"), t.optString("sp"), t.optString("rp"), t.optString("s"))
        }
        return TrainStatus(o.optString("n"), o.optString("c"), o.optString("o"), o.optString("d"), o.optString("oc"), o.optLong("dt"),
            o.optInt("dl"), o.optString("ls"), o.optLong("lt"), o.optBoolean("x"), stops, o.optString("i"), o.optString("op"))
    }

    /** Vale la pena tenerla? Solo con fermate, così non si salva una risposta vuota. */
    fun worthSaving(s: TrainStatus) = s.stops.isNotEmpty()

    fun isFresh(savedAt: Long, now: Long) = savedAt in 1..now && now - savedAt <= MAX_AGE_MS

    @Synchronized
    fun save(ctx: Context, s: TrainStatus, now: Long = System.currentTimeMillis()) {
        if (!worthSaving(s)) return
        val p = prefs(ctx)
        val e = p.edit()
        val keys = p.all.keys.filter { it.startsWith("t|") }
        val dropping = keys.sortedBy { p.getLong("a|" + it.removePrefix("t|"), 0L) }.take((keys.size - KEEP + 1).coerceAtLeast(0))
        dropping.forEach { e.remove(it); e.remove("a|" + it.removePrefix("t|")) }
        val k = key(s.ref)
        e.putString("t|$k", toJson(s).toString()).putLong("a|$k", now).apply()
    }

    /** (stato, istante della lettura) se c'è una lettura recente. */
    @Synchronized
    fun load(ctx: Context, ref: TrainRef, now: Long = System.currentTimeMillis()): Pair<TrainStatus, Long>? {
        val p = prefs(ctx)
        val k = key(ref)
        val at = p.getLong("a|$k", 0L)
        if (!isFresh(at, now)) return null
        val raw = p.getString("t|$k", null) ?: return null
        return runCatching { fromJson(JSONObject(raw)) to at }.getOrNull()
    }
}
