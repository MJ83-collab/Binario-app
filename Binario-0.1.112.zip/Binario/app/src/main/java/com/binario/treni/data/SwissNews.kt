package com.binario.treni.data

/**
 * Avvisi che riguardano solo la Svizzera (per esempio lavori TILO tra Bellinzona e Lugano).
 * Regola decisa da Marco: con la regione Lombardia non si mostrano; si mostrano solo per la tratta,
 * se la tratta parte o arriva in Svizzera e l'avviso nomina uno dei suoi capolinea. Con «Tutte» si vedono sempre.
 * Logica pura, provata nei test.
 */
object SwissNews {
    /**
     * Località e parole che indicano la Svizzera. Non c'è «Ticino» da solo (è anche il fiume lombardo: «ponte sul Ticino»),
     * né Chiasso, stazione di confine servita anche dai treni italiani.
     */
    val PLACES = listOf(
        "LUGANO", "BELLINZONA", "LOCARNO", "MENDRISIO", "BALERNA", "STABIO", "CAPOLAGO", "MELIDE", "MAROGGIA", "BISSONE",
        "BIASCA", "GIUBIASCO", "CADENAZZO", "CASTIONE", "RIVERA", "TAVERNE", "LAMONE", "AIROLO", "FAIDO", "MAGADINO",
        "GOTTARDO", "CENERI", "CANTON TICINO", "ZURIGO", "ZÜRICH", "ZURICH", "BASILEA", "LUCERNA", "BERNA", "GINEVRA",
        "SVIZZERA", "FFS", "SBB", "CFF",
    )

    private fun word(text: String, w: String) = Regex("(?<![\\p{L}])" + Regex.escape(w) + "(?![\\p{L}])").containsMatchIn(text)

    fun mentionsSwiss(text: String): Boolean {
        val t = text.uppercase()
        return PLACES.any { word(t, it) }
    }

    /** Solo svizzero: nomina la Svizzera e nessun luogo italiano ([mentionsItaly] lo decide chi conosce città e regioni). */
    fun isSwissOnly(title: String, text: String, mentionsItaly: Boolean): Boolean = !mentionsItaly && mentionsSwiss("$title $text")

    /** Stazione in Svizzera: id dell'orario svizzero («CH…») oppure nome di una località svizzera. */
    fun isSwissStation(id: String, name: String): Boolean = id.startsWith(SWISS_ID) || mentionsSwiss(name)

    /** Come SwissLive.PREFIX: le stazioni dell'orario svizzero hanno id «CH» + codice UIC. */
    const val SWISS_ID = "CH"

    /**
     * Un avviso solo svizzero vale per la tratta se la tratta parte o arriva in Svizzera
     * e il testo nomina almeno uno dei capolinea ([keywords]: parole dei nomi di partenza e arrivo).
     */
    fun forRoute(title: String, text: String, ends: List<Pair<String, String>>, keywords: List<String>): Boolean {
        if (ends.none { (id, name) -> isSwissStation(id, name) }) return false
        val t = "$title $text".uppercase()
        return keywords.any { word(t, it.uppercase()) }
    }
}
