package com.binario.treni.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Funzioni della home su tre livelli (23/11/2026):
 * - **Base** (predefinito): solo l'essenziale. Cerca orario con andata e ritorno, prossimo sciopero, tasti rapidi; nel menu
 *   impostazioni, allarmi, stazioni vicine, notizie, biglietti, treni in Italia, aiuto e feedback.
 * - **Avanzate**: per chi viaggia spesso. In più passeggeri, tipo di treni, prezzi migliori e filtri attivi nella ricerca,
 *   il calendario dei prezzi in home; nel menu I miei viaggi, orari offline, tutte le linee, treni garantiti, Svizzera,
 *   tariffe, bagni, rivendite e assistenza disabili.
 * - **Complete**: tutto. In più i riquadri dello stile scelto, emergenza (DAE, AREU), assistente, mappa dei treni, estero
 *   (Germania, Austria, Francia), esplora a voce, defibrillatori.
 * Le funzioni nascoste non si perdono: si torna al livello più alto in un tocco (anche dal fondo del menu laterale).
 */
enum class HomeLevel(val label: String, val description: String) {
    BASE("Base", "Solo l'essenziale: cerca orario, scioperi e i tuoi tasti rapidi."),
    ADVANCED("Avanzate", "In più: passeggeri, tipo di treni, prezzi, I miei viaggi, orari offline, linee e tariffe."),
    FULL("Complete", "Tutte le funzioni: anche mappe, estero, emergenza, assistente e riquadri dello stile."),
    ;

    companion object {
        /** Livello salvato (nome dell'enum); senza scelta nuova vale la vecchia «Base sì/no» (false = aveva scelto Complete). */
        fun fromSaved(saved: String?, oldBasic: Boolean?): HomeLevel =
            entries.firstOrNull { it.name == saved } ?: if (oldBasic == false) FULL else BASE
    }
}

/** Modalità predefinita della home finché l'utente non ha scelto: base. */
const val BASIC_DEFAULT = true

object HomeMode {
    var level by mutableStateOf(HomeLevel.BASE)

    /** Solo l'essenziale (livello Base). */
    val basic: Boolean get() = level == HomeLevel.BASE

    /** Avanzate o Complete: passeggeri, tipo di treni, prezzi… */
    val advanced: Boolean get() = level != HomeLevel.BASE

    /** Tutte le funzioni (Complete). */
    val full: Boolean get() = level == HomeLevel.FULL

    fun load(ctx: Context) { level = Store(ctx).homeLevel }

    fun set(ctx: Context, value: HomeLevel) {
        Store(ctx).homeLevel = value
        level = value
    }
}

/** Regole pure (senza stato) su quali voci del menu restano a ogni livello. */
object HomeMenuRules {
    /** Voci del menu laterale del livello Base (percorso senza parametri). */
    val BASIC_ROUTES = setOf("settings", "reminders", "nearby", "news", "tickets", "help", "feedback", "italy")

    /** In più con «Avanzate»: le funzioni di chi viaggia spesso. */
    val ADVANCED_ROUTES = BASIC_ROUTES + setOf(
        "trips", "saved", "lines", "guaranteed", "switzerland", "fares", "toilets", "sellers", "assistance",
    )

    fun routeOf(entry: String): String = entry.substringBefore('?')

    /** La voce di menu [route] è visibile al livello [level]? */
    fun visibleInMenu(route: String, level: HomeLevel): Boolean = when (level) {
        HomeLevel.FULL -> true
        HomeLevel.ADVANCED -> routeOf(route) in ADVANCED_ROUTES
        HomeLevel.BASE -> routeOf(route) in BASIC_ROUTES
    }

    /** Compatibilità: vero = Base, falso = Complete. */
    fun visibleInMenu(route: String, basic: Boolean): Boolean = visibleInMenu(route, if (basic) HomeLevel.BASE else HomeLevel.FULL)

    /** Quante voci [routes] restano nascoste al livello [level] (per «Mostra tutte le funzioni»). */
    fun hiddenCount(routes: List<String>, level: HomeLevel): Int = routes.map { routeOf(it) }.distinct().count { !visibleInMenu(it, level) }
}
