package com.binario.treni.data

/** Orari salvati per l'uso senza rete: quanto sono vecchi e come ritrovare la tratta per aggiornarli. */
object SavedAge {
    const val STALE_MS = 12 * 3_600_000L

    fun isStale(now: Long, at: Long): Boolean = at > 0 && now - at > STALE_MS

    /** «5 min fa», «3 h fa», «2 giorni fa». */
    fun label(now: Long, at: Long): String {
        val min = ((now - at).coerceAtLeast(0L) / 60_000L)
        return when {
            min < 1 -> I18n.tr("meno di un minuto fa", "less than a minute ago")
            min < 60 -> I18n.tr("%d min fa", "%d min ago").replace("%d", min.toString())
            min < 48 * 60 -> I18n.tr("%d h fa", "%d h ago").replace("%d", (min / 60).toString())
            else -> I18n.tr("%d giorni fa", "%d days ago").replace("%d", (min / 1440).toString())
        }
    }

    /** Chiave «idPartenza>idArrivo@giorno» → (idPartenza, idArrivo), oppure null se non è nel formato atteso. */
    fun parseKey(key: String): Pair<String, String>? {
        val ids = key.substringBefore('@').split('>')
        return if (ids.size == 2 && ids[0].isNotBlank() && ids[1].isNotBlank()) ids[0] to ids[1] else null
    }

    /** Titolo «Partenza → Arrivo · data» → (Partenza, Arrivo), oppure null. */
    fun parseTitle(title: String): Pair<String, String>? {
        if (!title.contains(" → ")) return null
        val a = title.substringBefore(" → ").trim()
        val b = title.substringAfter(" → ").substringBefore(" · ").trim()
        return if (a.isNotEmpty() && b.isNotEmpty()) a to b else null
    }
}
