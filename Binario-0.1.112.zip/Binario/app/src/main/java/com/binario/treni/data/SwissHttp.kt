package com.binario.treni.data

import java.io.IOException

/**
 * Richieste a transport.opendata.ch, comuni a [Swiss] e [SwissLive].
 *
 * Il servizio concede un numero limitato di richieste al giorno per indirizzo IP (circa 1.000 ricerche di
 * collegamenti e 10.000 tabelloni) e poi risponde 429. Sulla rete del telefono l'IP è spesso condiviso,
 * quindi qui si chiede il meno possibile:
 * - le risposte restano in memoria per un tempo che dipende dal tipo (stazioni a lungo, tabelloni poco);
 * - dopo un 429 non si riprova subito: per un po' si usano i dati appena scaduti, oppure si dice «occupato»;
 * - per gli altri errori (rete lenta, server) un solo nuovo tentativo.
 */
object SwissHttp {
    const val UA = "Binario (+github.com/MJ83-collab/Binario-app; Android app com.binario.treni)"
    const val MIN_PAUSE_MS = 60_000L
    const val MAX_PAUSE_MS = 15 * 60_000L
    const val MAX_STALE_MS = 30 * 60_000L

    private val cache = TtlCache<String>(300)

    @Volatile var pausedUntil = 0L
        private set

    /** Quanto resta valida una risposta, secondo il tipo di richiesta. */
    fun life(url: String): Long = when {
        "/locations" in url -> 24 * 3_600_000L
        "/stationboard" in url -> 30_000L
        "/connections" in url -> 120_000L
        else -> 60_000L
    }

    /** Pausa dopo un 429: quella chiesta dal server, ma almeno 1 minuto e al massimo 15. */
    fun pauseMs(e: HttpStatusException): Long = e.retryAfterMs.coerceIn(MIN_PAUSE_MS, MAX_PAUSE_MS)

    fun isPaused(now: Long = System.currentTimeMillis()): Boolean = now < pausedUntil

    /** Testo per «Stato dei servizi» mentre l'app è in pausa dopo un 429 (null se non è in pausa). */
    fun pauseNotice(now: Long = System.currentTimeMillis()): String? = if (!isPaused(now)) null else I18n.tr(
        "In pausa fino alle ${Fmt.time(pausedUntil)} dopo troppe richieste (429): intanto l'app usa i dati degli ultimi 30 minuti.",
        "Paused until ${Fmt.time(pausedUntil)} after too many requests (429): meanwhile the app uses data from the last 30 minutes.",
    )

    fun text(
        url: String,
        connectMs: Int,
        readMs: Int,
        now: Long = System.currentTimeMillis(),
        fetch: (String) -> String = { Http.getText(it, connectMs, readMs, UA, retry = false) },
    ): String {
        cache.fresh(url, life(url), now)?.let { return it }
        if (isPaused(now)) {
            cache.stale(url, MAX_STALE_MS, now)?.let { return it.first }
            throw HttpStatusException(429)
        }
        var attempt = 0
        while (true) {
            try {
                return fetch(url).also { cache.put(url, it, now) }
            } catch (e: IOException) {
                if (e is HttpStatusException && e.code == 429) pausedUntil = now + pauseMs(e)
                val again = attempt == 0 && e !is OfflineException && !(e is HttpStatusException && e.code in 400..499)
                if (again) {
                    attempt++
                    continue
                }
                cache.stale(url, MAX_STALE_MS, now)?.let { return it.first }
                throw e
            }
        }
    }

    /** Solo per i test. */
    fun reset() {
        cache.clear()
        pausedUntil = 0L
    }
}
