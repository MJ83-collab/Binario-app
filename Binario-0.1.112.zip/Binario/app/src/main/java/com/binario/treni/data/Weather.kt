package com.binario.treni.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/**
 * Meteo alla stazione da Open-Meteo (open-meteo.com): servizio gratuito, senza chiave né account.
 * Alla richiesta vanno solo le coordinate della stazione (mai la posizione dell'utente).
 */
object Weather {
    data class Hour(val label: String, val temp: Int, val code: Int, val rainPercent: Int)

    data class Now(val temp: Int, val feels: Int, val code: Int, val windKmh: Int, val rainMm: Double, val hours: List<Hour>)

    private val cache = HashMap<String, Pair<Long, Now>>()
    private const val TTL = 15 * 60_000L

    /** Sulle coordinate arrotondate a due decimali (circa 1 km): stazioni vicine condividono la risposta. */
    fun load(lat: Double, lon: Double): Now? {
        val key = "%.2f,%.2f".format(java.util.Locale.US, lat, lon)
        synchronized(cache) { cache[key]?.let { (at, w) -> if (System.currentTimeMillis() - at < TTL) return w } }
        return try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f".format(java.util.Locale.US, lat, lon) +
                "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation" +
                "&hourly=temperature_2m,weather_code,precipitation_probability&forecast_days=2&timezone=auto&wind_speed_unit=kmh"
            val body = Http.getText(url, connectMs = 10_000, readMs = 10_000, ua = "Binario (Android; com.binario.treni)")
            val o = JSONObject(body)
            val cur = o.getJSONObject("current")
            val now = cur.optString("time") // "2026-11-05T15:00" nell'ora locale della stazione
            val h = o.getJSONObject("hourly")
            val times = h.getJSONArray("time")
            val temps = h.getJSONArray("temperature_2m")
            val codes = h.getJSONArray("weather_code")
            val prob = h.optJSONArray("precipitation_probability")
            val first = (0 until times.length()).firstOrNull { times.getString(it) >= now.take(13) + ":00" } ?: 0
            val hours = (first + 1 until minOf(times.length(), first + 7) step 2).map { i ->
                Hour(times.getString(i).takeLast(5), temps.optDouble(i).roundToInt(), codes.optInt(i), prob?.optInt(i, 0) ?: 0)
            }
            val w = Now(
                cur.optDouble("temperature_2m").roundToInt(), cur.optDouble("apparent_temperature").roundToInt(), cur.optInt("weather_code"),
                cur.optDouble("wind_speed_10m").roundToInt(), cur.optDouble("precipitation"), hours,
            )
            synchronized(cache) { cache[key] = System.currentTimeMillis() to w }
            w
        } catch (_: Exception) {
            null
        }
    }

    /** Descrizione breve (italiano, tradotta con tx) dal codice WMO di Open-Meteo. */
    fun label(code: Int): String = when (code) {
        0 -> "Sereno"
        1, 2 -> "Poco nuvoloso"
        3 -> "Coperto"
        45, 48 -> "Nebbia"
        51, 53, 55, 56, 57 -> "Pioggerella"
        61, 63, 65, 66, 67 -> "Pioggia"
        71, 73, 75, 77, 85, 86 -> "Neve"
        80, 81, 82 -> "Rovesci"
        95, 96, 99 -> "Temporale"
        else -> "Variabile"
    }

    fun icon(code: Int): String = when (code) {
        0 -> "☀️"
        1, 2 -> "🌤️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        51, 53, 55, 56, 57 -> "🌦️"
        61, 63, 65, 66, 67, 80, 81, 82 -> "🌧️"
        71, 73, 75, 77, 85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌥️"
    }
}
