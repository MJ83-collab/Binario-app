package com.binario.treni.ui

import androidx.compose.runtime.saveable.rememberSaveable
import com.binario.treni.data.tx
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.text.style.TextDecoration
import com.binario.treni.data.ALL_CATEGORIES
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.NewsItem
import com.binario.treni.data.Notice
import com.binario.treni.data.Sources
import com.binario.treni.data.Strike
import com.binario.treni.data.SavedSearch
import com.binario.treni.service.Reminders
import com.binario.treni.service.TrackingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Ultimi dati delle notizie in memoria: riaprendo la schermata si vedono subito, poi si aggiornano. */
object NewsCache {
    var strikes: List<Strike>? = null
    var notices: List<Notice>? = null
    var at: Long = 0L
    val details = HashMap<String, String>()
}

/** Scioperi (fonte ufficiale MIT) e comunicati delle aziende: circolazione, lavori, avvisi. Si aggiorna da sola ogni 5 minuti. */
@Composable
fun NewsScreen(onBack: () -> Unit, onGuaranteed: () -> Unit = {}) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var strikes by remember { mutableStateOf(NewsCache.strikes) }
    var strikesFailed by remember { mutableStateOf(false) }
    var notices by remember { mutableStateOf(NewsCache.notices) }
    var updatedAt by remember { mutableStateOf(NewsCache.at) }
    var refreshing by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<Notice?>(null) }
    var tick by rememberSaveable { mutableStateOf(0) }
    val store = remember { com.binario.treni.data.Store(ctx) }
    var filter by remember { mutableStateOf(store.newsFilter) }
    var route by remember { mutableStateOf(com.binario.treni.data.RouteNews.defaultRoute(store, ctx)) }
    var editRoute by remember { mutableStateOf(false) }
    // Aggiornamento automatico: subito (se i dati hanno più di 2 minuti) e poi ogni 5 minuti finché la schermata è aperta
    val fg = rememberForeground()
    LaunchedEffect(Unit) {
        if (System.currentTimeMillis() - NewsCache.at > 2 * 60_000L) tick++
        while (true) {
            kotlinx.coroutines.delay(5 * 60_000L)
            waitForeground(fg)
            tick++
        }
    }
    LaunchedEffect(tick) {
        if (tick == 0) return@LaunchedEffect
        refreshing = true
        coroutineScope {
            launch {
                try {
                    val l = withContext(Dispatchers.IO) { Sources.railStrikes() }
                    strikes = l; NewsCache.strikes = l; strikesFailed = false
                } catch (e: Exception) {
                    if (strikes == null) strikesFailed = true
                }
            }
            launch {
                val l = withContext(Dispatchers.IO) { Sources.allNotices() }
                if (l.isNotEmpty() || notices == null) { notices = l; NewsCache.notices = l }
            }
        }
        NewsCache.at = System.currentTimeMillis()
        updatedAt = NewsCache.at
        refreshing = false
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Notizie"), onBack) { IconButton({ tick++ }, enabled = !refreshing) { Icon(Icons.Filled.Refresh, tx("Aggiorna ora")) } }
        GreenTabs(listOf(tx("Scioperi"), tx("Circolazione"), tx("Lavori"), tx("Tutti")), tab) { tab = it }
        if (refreshing) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (updatedAt > 0) tx("Aggiornato alle") + " " + Fmt.time(updatedAt) + " · " + tx("si aggiorna da solo ogni 5 minuti o trascinando giù")
                else tx("Caricamento…"),
                color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f),
            )
            TextButton({ tick++ }, enabled = !refreshing) { Text(tx("Aggiorna ora"), color = Green) }
        }
        NewsFilterBar(filter, route, onFilter = { f ->
            filter = f; store.newsFilter = f
            if (f == "route" && !route.complete) editRoute = true
        }, onEdit = { editRoute = true }, onRegions = { g ->
            route = route.copy(regions = g); store.setMyRoute(route)
        })
        val rn = com.binario.treni.data.RouteNews
        fun keepStrike(st: Strike): Boolean = when (filter) {
            "region" -> rn.inRegion(st, route.regions)
            "route" -> route.complete && rn.affectsRoute(st, route)
            else -> true
        }
        fun keepNotice(n: Notice): Boolean = when (filter) {
            "region" -> rn.noticeInRegion(n, route.regions)
            "route" -> route.complete && rn.noticeForRoute(n, route)
            else -> true
        }
        PullRefresh(refreshing, { tick++ }) { LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 6.dp)) {
            if (tab == 0) {
                // Silenzia le notifiche di sciopero per un tempo scelto (anche da Impostazioni › Notifiche)
                if (store.strikeAlerts) item { WhiteCard { StrikeMuteSetting(store) } }
                val l = strikes?.filter { keepStrike(it) }
                when {
                    strikesFailed -> item { MessageBox(tx("Osservatorio scioperi non raggiungibile in questo momento")) }
                    l == null -> item { LoadingBox() }
                    l.isEmpty() -> item {
                        MessageBox(when (filter) {
                            "route" -> tx("Nessuno sciopero proclamato tocca la tua tratta nei tuoi orari") + " (" + route.label + ")"
                            "region" -> tx("Nessuno sciopero proclamato nella tua regione") + " (" + route.regions.joinToString() + ")"
                            else -> tx("Nessuno sciopero ferroviario proclamato")
                        })
                    }
                    else -> keyedItems(l) { st -> StrikeCard(st, if (filter == "route" && route.complete) rn.affectedTrips(st, route) else emptyList()) }
                }
                // Con un filtro attivo si dice quanti scioperi restano fuori, e con un tocco si vedono tutti
                val hiddenStrikes = hiddenCount(filter, strikes?.size ?: 0, l?.size ?: 0)
                if (hiddenStrikes > 0) item(key = "hidden-strikes") { HiddenByFilter(hiddenLabel(hiddenStrikes, strikes = true)) { filter = "all" } }
                // Germania: notizie sugli scioperi dei treni (non c'è un calendario ufficiale)
                item { GermanStrikesCard() }
                item {
                    WhiteCard(onClick = onGuaranteed) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.EventAvailable, null, tint = Green)
                            Spacer(Modifier.width(12.dp))
                            Text(tx("Treni garantiti: elenchi ufficiali aggiornati"), Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            Icon(Icons.Filled.ChevronRight, null, tint = Muted)
                        }
                    }
                }
                // Comunicati delle aziende sugli scioperi (treni garantiti ecc.)
                val comm = notices.orEmpty().filter { it.kind == Notice.Kind.STRIKE && keepNotice(it) }
                if (comm.isNotEmpty()) {
                    item { SectionHeader(tx("Comunicati delle aziende")) }
                    keyedItems(comm) { n -> NoticeCard(n) { open = n } }
                }
            } else {
                val l = notices
                val kind = when (tab) {
                    1 -> Notice.Kind.BLOCKED
                    2 -> Notice.Kind.WORKS
                    else -> null
                }
                when {
                    l == null -> item { LoadingBox() }
                    else -> {
                        val ofKind = if (kind == null) l else l.filter { it.kind == kind }
                        val f = ofKind.filter { keepNotice(it) }
                        if (f.isEmpty()) item {
                            MessageBox(
                                (if (tab == 1) tx("Nessuna anomalia di circolazione segnalata") else tx("Nessun avviso")) +
                                    (if (filter == "region") " (" + route.regions.joinToString() + ")" else ""),
                            )
                        }
                        keyedItems(f) { n -> NoticeCard(n) { open = n } }
                        val hidden = hiddenCount(filter, ofKind.size, f.size)
                        if (hidden > 0) item(key = "hidden-notices") { HiddenByFilter(hiddenLabel(hidden, strikes = false)) { filter = "all" } }
                    }
                }
                item {
                    Column(Modifier.padding(horizontal = 8.dp)) {
                        SectionHeader(tx("Siti ufficiali"))
                        TextButton({ openUrl(ctx, "https://www.trenord.it/linee-e-orari/circolazione/tempo-reale/") }) { Text(tx("Trenord · circolazione in tempo reale"), color = Green) }
                        TextButton({ openUrl(ctx, Sources.TRENITALIA_INFO_URL) }) { Text(tx("Trenitalia · notizie infomobilità"), color = Green) }
                        TextButton({ openUrl(ctx, "https://www.ferrovienord.it") }) { Text("FerrovieNord", color = Green) }
                        TextButton({ openUrl(ctx, "https://www.tilo.ch/avvisi.html") }) { Text(tx("TILO · avvisi"), color = Green) }
                    }
                }
            }
        } }
    }
    open?.let { n -> NoticeDialog(n) { open = null } }
    if (editRoute) MyRouteDialog(route, onDismiss = { editRoute = false }) { r ->
        route = r; store.setMyRoute(r); editRoute = false
    }
}

/** Dettaglio di un comunicato: testo completo letto dalla pagina della fonte, con link diretto. */
@Composable
private fun NoticeDialog(n: Notice, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var full by remember(n.url, n.title) { mutableStateOf(NewsCache.details[n.url + n.title]) }
    var loading by remember(n.url, n.title) { mutableStateOf(false) }
    LaunchedEffect(n.url, n.title) {
        // Il testo dell'elenco è già completo per Trenitalia; per gli altri leggiamo la pagina del comunicato
        if (full == null && n.text.length < 400 && n.url.isNotBlank() && !n.url.endsWith(".pdf", true) &&
            n.url != Sources.TRENITALIA_INFO_URL
        ) {
            loading = true
            val t = withContext(Dispatchers.IO) { runCatching { Sources.noticeDetail(n.url) }.getOrDefault("") }
            if (t.isNotBlank()) { full = t; NewsCache.details[n.url + n.title] = t }
            loading = false
        }
    }
    val body = full?.takeIf { it.length > n.text.length } ?: n.text
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(n.title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("${n.kind.label} · ${n.date.ifBlank { tx("data non indicata") }}", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                if (body.isNotBlank()) Text(body, lineHeight = 20.sp)
                else if (!loading) Text(tx("Il testo completo è disponibile sul sito della fonte."), color = Muted)
                Spacer(Modifier.height(12.dp))
                SourceLink(n.source, n.url)
            }
        },
        confirmButton = { TextButton({ openUrl(ctx, n.url); onClose() }) { Text(tx("Apri la fonte"), color = Green) } },
        dismissButton = {
            TextButton({ shareText(ctx, n.title + (if (n.date.isNotBlank()) " (" + n.date + ")" else "") + "\n" + body.take(800) + "\n" + tx("Fonte") + ": " + n.url) }) {
                Text(tx("Condividi"))
            }
        },
    )
}

/** "Fonte: nome · sito ↗", toccabile: apre il link diretto. */
@Composable
fun SourceLink(name: String, url: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    if (url.isBlank()) return
    val site = Regex("^https?://(?:www\\.)?([^/]+)").find(url)?.groupValues?.get(1) ?: url
    Row(
        modifier.clickable { openUrl(ctx, url) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Link, null, tint = Green, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(tx("Fonte") + ": " + (if (name.isNotBlank() && !site.contains(name.substringBefore(" ").lowercase())) "$name · " else "") + site,
            color = Green, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StrikeCard(s: Strike, trips: List<com.binario.treni.data.RouteNews.Trip> = emptyList()) {
    val ctx = LocalContext.current
    val national = s.relevance.contains("nazional", true)
    WhiteCard(onClick = {
        shareText(ctx, "${s.title}\n${tx("Orari")}: ${s.modality}\n${tx("Chi")}: ${s.company}\n${tx("Dove")}: ${s.region}\n" +
            tx("Fonte") + ": " + s.url)
    }) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Warning, null, tint = LateRed, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(tx("Sciopero") + " " + s.start + (if (s.end.isNotBlank() && s.end != s.start) " → ${s.end}" else ""),
                    fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(s.relevance.uppercase(), color = if (national) LateRed else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            StrikeLine(tx("Orari"), s.modality)
            StrikeLine(tx("Chi"), s.company)
            StrikeLine(tx("Dove"), s.region + if (s.province.isNotBlank() && s.province != "Tutte") " (${s.province})" else "")
            StrikeLine(tx("Settore"), s.sector)
            StrikeLine(tx("Sindacati"), s.unions)
            if (s.note.isNotBlank()) StrikeLine(tx("Note"), s.note)
            if (trips.isNotEmpty()) {
                Text("🚆 " + tx("I tuoi treni durante lo sciopero"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LateRed,
                    modifier = Modifier.padding(top = 8.dp))
                trips.forEach { t -> Text("• " + com.binario.treni.data.RouteNews.describe(t), fontSize = 14.sp) }
                Text(tx("Nelle fasce garantite (feriali 6–9 e 18–21) i treni regionali circolano. Fuori fascia controlla l'elenco dei treni garantiti della tua impresa."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
            SourceLink(s.sourceName, s.url, Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun StrikeLine(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.padding(top = 3.dp)) {
        Text("$label: ", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 14.sp)
    }
}

@Composable
private fun NoticeCard(n: Notice, onClick: () -> Unit) {
    WhiteCard(onClick = onClick) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val col = when (n.kind) {
                    Notice.Kind.STRIKE, Notice.Kind.BLOCKED -> LateRed
                    Notice.Kind.WORKS -> Color(0xFFEF6C00)
                    Notice.Kind.OTHER -> Muted
                }
                Text(n.kind.label.uppercase(), color = col, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(n.date, color = Muted, fontSize = 12.sp)
            }
            Text(n.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.padding(top = 2.dp))
            if (n.text.isNotBlank()) Text(n.text.take(220) + if (n.text.length > 220) "…" else "", color = Muted, fontSize = 13.sp)
            SourceLink(n.source, n.url, Modifier.padding(top = 2.dp))
        }
    }
}

/** Quanti elementi il filtro nasconde (0 senza filtro). */
internal fun hiddenCount(filter: String, total: Int, shown: Int): Int = if (filter == "all") 0 else (total - shown).coerceAtLeast(0)

/** «3 avvisi nascosti dal filtro» / «1 sciopero nascosto dal filtro». */
internal fun hiddenLabel(count: Int, strikes: Boolean): String = when {
    strikes && count == 1 -> tx("1 sciopero nascosto dal filtro")
    strikes -> tx("{0} scioperi nascosti dal filtro").replace("{0}", count.toString())
    count == 1 -> tx("1 avviso nascosto dal filtro")
    else -> tx("{0} avvisi nascosti dal filtro").replace("{0}", count.toString())
}

/** Riga sotto un elenco filtrato: quanti elementi restano fuori e «Mostra tutti». Il filtro salvato non cambia. */
@Composable
private fun HiddenByFilter(label: String, onShowAll: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onShowAll).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.FilterList, null, tint = Muted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(tx("Mostra tutti"), color = Green, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
