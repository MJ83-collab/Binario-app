package com.binario.treni.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Formati di data, ora, prezzo e durata usati in tutta l'app (sempre nel fuso orario italiano). */
object Fmt {
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")
    fun time(ms: Long): String = if (ms <= 0) "--:--" else SimpleDateFormat("HH:mm", Locale.ITALY).apply { timeZone = rome }.format(Date(ms))
    fun day(ms: Long): String = SimpleDateFormat(if (I18n.cjk) "M月d日" else "dd MMM", I18n.locale).apply { timeZone = rome }.format(Date(ms))
    fun dayLong(ms: Long): String = SimpleDateFormat(if (I18n.cjk) "M月d日 EEEE" else "EEEE d MMMM", I18n.locale).apply { timeZone = rome }.format(Date(ms))
        .replaceFirstChar { it.uppercase() }
    fun dayTime(ms: Long): String = SimpleDateFormat(if (I18n.cjk) "M月d日 HH:mm" else "dd MMM HH:mm", I18n.locale).apply { timeZone = rome }.format(Date(ms))
    fun price(p: Double?): String = if (p == null) "" else String.format(Locale.ITALY, "%.2f €", p)
    /** Distanza in metri («850 m», «1,2 km»): sempre con la virgola italiana, qualunque sia la lingua del telefono. */
    fun distance(meters: Double): String =
        if (meters < 1000) "${meters.toInt()} m" else String.format(Locale.ITALY, "%.1f km", meters / 1000.0)
    fun duration(dep: Long, arr: Long): String {
        if (dep <= 0 || arr <= dep) return ""
        val m = ((arr - dep) / 60000).toInt()
        return "${m / 60}h ${"%02d".format(m % 60)}m"
    }

    /**
     * Momento in cui lo stato di una corsa (partito/arrivato/ritardo) torna a «non ancora partito» con i dati del giorno dopo:
     * a mezzanotte, oppure alle 5 del mattino se il treno arriva dopo mezzanotte.
     */
    fun resetAt(runDay: Long, lastArr: Long): Long {
        val nextMidnight = midnight(runDay + 27 * 3_600_000L)
        return if (lastArr > nextMidnight) nextMidnight + 5 * 3_600_000L else nextMidnight
    }

    fun midnight(ms: Long = System.currentTimeMillis()): Long = Calendar.getInstance(rome).apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
