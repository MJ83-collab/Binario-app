package com.binario.treni.data

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Risposta HTTP non riuscita. Il testo resta «HTTP 503» come prima, per il codice che lo controlla. */
class HttpStatusException(val code: Int, val retryAfterMs: Long = 0L) : IOException("HTTP $code")

/** Quando e quanto aspettare prima di riprovare (logica pura, provata nei test). */
object RetryPolicy {
    const val MAX_ATTEMPTS = 3
    const val BASE_MS = 700L
    const val MAX_WAIT_MS = 10_000L

    fun shouldRetry(e: IOException, attempt: Int): Boolean = when {
        attempt >= MAX_ATTEMPTS - 1 -> false
        e is OfflineException -> false
        e is HttpStatusException -> e.code == 429 || e.code == 408 || e.code >= 500
        // tempo scaduto: un solo nuovo tentativo, per non far aspettare troppo
        e is java.net.SocketTimeoutException -> attempt == 0
        else -> true
    }

    /** Attesa prima del tentativo successivo: 0,7 s, 1,4 s… più un po' di casualità; con «Retry-After» si rispetta quello (massimo 10 s). */
    fun waitMs(e: IOException, attempt: Int, jitter: Int = 0): Long {
        if (e is HttpStatusException && e.retryAfterMs > 0) return minOf(e.retryAfterMs, MAX_WAIT_MS)
        return BASE_MS * (1L shl attempt.coerceIn(0, 4)) + jitter
    }

    /** «Retry-After» in secondi (la forma con data non si usa) → millisecondi; 0 se assente o non valido. */
    fun parseRetryAfter(h: String?): Long = h?.trim()?.toLongOrNull()?.takeIf { it in 1..3600 }?.times(1000L) ?: 0L
}

/**
 * Cliente di rete unico per l'app: tempi di attesa, tentativi e registro degli errori sono in un punto solo.
 * Le richieste con casi particolari (POST, accesso con cookie, scaricamento dell'APK) restano nei loro file.
 */
object Http {
    const val DEFAULT_UA = "Mozilla/5.0 (Android) Binario/1.0"

    /** GET con testo come risposta. Riprova da solo con attese crescenti; fallisce subito se manca la rete. */
    fun getText(
        url: String,
        connectMs: Int = 10_000,
        readMs: Int = 20_000,
        ua: String = DEFAULT_UA,
        lang: String? = null,
        redirects: Boolean = true,
        retry: Boolean = true,
    ): String = if (retry) withRetry { once(url, connectMs, readMs, ua, lang, redirects) } else once(url, connectMs, readMs, ua, lang, redirects)

    /** Apre una connessione dopo aver controllato la rete: senza rete fallisce subito (OfflineException) invece di attendere i tempi scaduti. */
    fun open(url: String): HttpURLConnection {
        Net.requireOnline()
        return URL(url).openConnection() as HttpURLConnection
    }

    fun <T> withRetry(block: () -> T): T {
        var last: IOException? = null
        for (attempt in 0 until RetryPolicy.MAX_ATTEMPTS) {
            try {
                return block()
            } catch (e: IOException) {
                last = e
                if (!RetryPolicy.shouldRetry(e, attempt)) break
                try { Thread.sleep(RetryPolicy.waitMs(e, attempt, (Math.random() * 300).toInt())) } catch (_: InterruptedException) { break }
            }
        }
        throw last ?: IOException("Errore di rete")
    }

    private fun once(url: String, connectMs: Int, readMs: Int, ua: String, lang: String?, redirects: Boolean): String {
        try {
            Net.requireOnline()
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = connectMs
                readTimeout = readMs
                instanceFollowRedirects = redirects
                setRequestProperty("User-Agent", ua)
                if (lang != null) setRequestProperty("Accept-Language", lang)
            }
            try {
                val code = c.responseCode
                if (code !in 200..299) throw HttpStatusException(code, RetryPolicy.parseRetryAfter(c.getHeaderField("Retry-After")))
                return c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        } catch (e: IOException) {
            Diag.record(url, e)
            throw e
        }
    }
}
