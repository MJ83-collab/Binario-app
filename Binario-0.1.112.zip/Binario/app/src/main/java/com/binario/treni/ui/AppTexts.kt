package com.binario.treni.ui

// Testi lunghi dell'app (guida, privacy, note legali, widget), spostati da OtherScreens.kt.
// Il changelog resta in OtherScreens.kt: la build di GitHub lo legge da lì per le note della release.

const val HELP_TEXT = """Come cerco un orario?
Nella scheda Cerca scegli partenza e arrivo, data e ora, poi tocca Cerca. Tocca il nome di un treno (es. "TI FR 9627") per vedere ritardi, fermate e binari.

Come vedo il tabellone di una fermata?
Nella scheda del treno tocca una fermata e scegli "Partenze e arrivi da qui".

Come funziona la sveglia?
Nella scheda del treno tocca la fermata dove scendi e scegli "Svegliami prima di questa fermata". L'allarme suona quando il treno lascia la fermata precedente (o 4 minuti prima dell'arrivo previsto). Attiva "Avvisi per persone sorde" nelle Impostazioni per vibrazione forte e flash.

Come aggiungo una linea?
Scheda Treni → Linee preferite → Aggiungi, es. S5 con capolinea Varese e Treviglio.

Come configuro un widget?
Aggiungilo dalla Home e scegli cosa mostrare. Per cambiarlo, tocca il titolo del widget.

Come scarico l'orario per usarlo senza rete?
Cerca la tratta e nei risultati tocca l'icona PDF: scegli il giorno e se includere il ritorno. Il file si salva in Download/Binario e si apre anche offline. Inoltre l'app ricorda da sola gli ultimi orari di ogni tratta cercata.

Come dico all'app dove salgo?
Apri il treno, tocca la fermata dove sali e scegli "Salgo qui": binario, orario e avvisi (anche vocali) si riferiscono a quella fermata.

Come uso l'app senza vedere lo schermo?
In Impostazioni → Accessibilità scegli gli avvisi vocali (tutti o solo fermata imminente). Per chiedere a voce tieni premuta l'icona di Binario e scegli "Chiedi a voce", oppure usa il riquadro nelle Impostazioni rapide.

Perché un treno non ha prezzo o affollamento?
I prezzi arrivano da Trenitalia; l'affollamento solo da Trenord, quando disponibile.

Posso fare domande?
Sì: apri l'assistente dei treni (icona del fumetto in Cerca) e chiedi per esempio "ritardo treno 2070" o "treni da Varese a Milano".

Dove vedo i treni sulla mappa?
Apri «Mappa dei treni» dal menu (☰): parte con la sola Italia, poi puoi aggiungere altri paesi e l'app ricorda la scelta. Tocca un pallino per numero, azienda, ritardo e prossima fermata.

Dove trovo condizioni e tariffe di un'azienda?
Menu (☰) › Condizioni di trasporto › Condizioni e tariffe per azienda: apri l'azienda e tocca il link ufficiale. Sono indicati fonte e data di verifica.

Come invio un feedback?
Menu (☰) › Invia un feedback."""

const val FIXES_TEXT = """2.4 · IN LAVORAZIONE
• Correzioni in corso: verranno elencate qui al rilascio
"""

const val WIDGETS_TEXT = """Tieni premuto su uno spazio vuoto della schermata Home → Widget → Binario, poi scegli cosa mostrare. Tocca il titolo del widget per cambiarlo.

• Tragitto / Linea: i prossimi treni di una tratta o di una linea preferita (es. S5), con ritardo e binario.
• Treno: l'andamento di un treno fermata per fermata.
• Stazione: le partenze da una stazione a scelta.
• Preferiti: lo stato di tutti i treni preferiti in un colpo solo.

Tocca una riga per aprire il treno o il tabellone.

Tocca ⟳ sul widget per aggiornarlo; si aggiorna da solo ogni 30 minuti."""

const val PRIVACY_TEXT = """Informativa sulla privacy (GDPR) · aggiornata a novembre 2026

Titolare del trattamento: Marco Jannino, sviluppatore indipendente di Binario. Contatto: «Feedback e segnala un bug» nell'app.

In breve
• Nessun account, nessuna pubblicità, nessuno strumento di statistiche o tracciamento. Binario non ha un proprio server e non riceve i tuoi dati.
• Preferiti, ricerche recenti, treni abituali, promemoria, impostazioni, registro «green» e diario «I miei viaggi» restano solo sul telefono. Si cancellano disinstallando l'app o dalle impostazioni di Android.

Servizi esterni
Per mostrare orari, ritardi e mappe l'app contatta direttamente i servizi pubblici: ViaggiaTreno (RFI/Trenitalia), Open-Meteo, LeFrecce, Italo, Trenord, FerrovieNord, TILO, FFS/SBB, DB, Transitous, TrovaTreno, Osservatorio scioperi del MIT, OpenStreetMap (mappe, Overpass, Nominatim, OSRM) e simili. Come qualsiasi sito web, ricevono il tuo indirizzo IP e i dati della richiesta (ad esempio stazione o numero del treno) e li trattano secondo le proprie informative. Binario non li invia a nessun altro.

Posizione
Solo se concedi il permesso e solo nelle schermate che la usano (stazioni vicine, rivendite, servizi). Per cercare i luoghi vicini le coordinate sono inviate ai server di OpenStreetMap (Overpass), che ricevono anche il tuo IP. Binario non le salva e non usa la posizione in background.

Feedback
Se invii «Feedback e segnala un bug», nome, email e messaggio (e, se lo scegli, versione dell'app e modello del telefono) arrivano a un modulo Google dello sviluppatore e servono solo per risponderti; Google tratta quei dati per conto dello sviluppatore. L'indirizzo del modulo è letto da un file pubblico su GitHub. Senza rete il messaggio resta sul telefono e parte appena possibile. Viene conservato finché serve a gestire la richiesta: puoi chiederne la cancellazione.

Aggiornamenti
L'app controlla su GitHub se esiste una versione nuova (all'apertura e circa ogni ora in background, con una notifica se c'è) e, se accetti, scarica da lì l'APK (GitHub riceve il tuo IP). Per installarlo Android chiede il permesso «installa app sconosciute».

Voce
Gli avvisi vocali usano la sintesi vocale del telefono, senza inviare dati. Le domande a voce passano dal riconoscimento vocale del telefono (di solito Google): Binario non chiede il permesso del microfono.

Permessi
• Notifiche: notifica fissa del treno, promemoria e avvisi scioperi (programmati sul telefono, senza server di notifiche).
• Servizio in primo piano, blocco stand-by e ottimizzazione batteria: per aggiornare il treno seguito senza che l'app venga sospesa.
• Esecuzione all'avvio, sveglie e promemoria: per riattivare e consegnare in orario le notifiche programmate.
• Posizione: stazioni e servizi vicini, mappa.
• Installa app sconosciute: solo per aggiornare Binario.
• Vibrazione.

Base giuridica e diritti
Il solo trattamento fatto dallo sviluppatore (il feedback) si basa sul tuo consenso, cioè sull'invio del messaggio. Hai diritto di accesso, rettifica, cancellazione, limitazione, opposizione e portabilità (artt. 15-22 GDPR): scrivi dall'app. Puoi presentare reclamo al Garante per la protezione dei dati personali (garanteprivacy.it). Per i dati trattati dai servizi esterni rivolgiti a loro.

Questa app non è affiliata a Trenitalia, RFI, Italo o Trenord."""

const val WIDGETS_TEXT_EN = """Long-press an empty area of the Home screen → Widgets → Binario, then choose what to show. Tap the widget title to change it.

• Route / Line: next trains on a route or favourite line (e.g. S5), with delay and platform.
• Train: a train's progress stop by stop.
• Station: departures from a station of your choice.
• Favourites: the status of all your favourite trains at a glance.

Tap a row to open the train or the departure board."""

const val HELP_TEXT_EN = """How do I search a timetable?
In the Search tab choose origin and destination, date and time, then tap Search. Tap a train name (e.g. "TI FR 9627") to see delays, stops and platforms.

How do I see the departure board of a stop?
In the train view tap a stop and choose "Departures and arrivals from here".

How does the wake-up alarm work?
In the train view tap the stop where you get off and choose "Wake me before this stop". The alarm rings when the train leaves the previous stop (or 4 minutes before the expected arrival). Turn on "Alerts for deaf or hard-of-hearing people" in Settings for strong vibration and flash.

How do I add a line?
Trains tab → Favourite lines → Add, e.g. S5 with termini Varese and Treviglio.

How do I set up a widget?
Add it from the Home screen and choose what to show. To change it, tap the widget title.

How do I download a timetable to use it offline?
Search the route and in the results tap the PDF icon: choose the day and whether to include the return trip. The file is saved in Download/Binario and also opens offline. The app also remembers the latest timetables of every route you searched.

How do I tell the app where I board?
Open the train, tap the stop where you board and choose "I board here": platform, time and alerts (also spoken) refer to that stop.

How do I use the app without seeing the screen?
In Settings → Accessibility choose the spoken alerts (all, or only the approaching stop). To ask by voice, long-press the Binario icon and choose "Ask by voice", or use the tile in Quick Settings.

Why does a train have no price or crowding?
Prices come from Trenitalia; crowding only from Trenord, when available.

Can I ask questions?
Yes: open the train assistant (speech-bubble icon in Search) and ask e.g. "delay train 2070" or "trains from Varese to Milano".

Where do I see trains on the map?
Open “Train map” from the menu (☰): it starts with Italy only, then you can add other countries and the app remembers your choice. Tap a dot for number, operator, delay and next stop.

Where do I find a company's conditions and fares?
Menu (☰) › Conditions of carriage › Conditions and fares by company: open the company and tap the official link. Source and check date are shown.

How do I send feedback?
Menu (☰) › Send feedback."""

const val PRIVACY_TEXT_EN = """Privacy notice (GDPR) · updated November 2026

Data controller: Marco Jannino, independent developer of Binario. Contact: "Feedback and report a bug" in the app.

In short
• No account, no ads, no analytics or tracking tools. Binario has no server of its own and does not receive your data.
• Favourites, recent searches, usual trains, reminders, settings, the green log and the «My trips» log stay on your phone only. They are deleted by uninstalling the app or from Android settings.

External services
To show timetables, delays and maps the app contacts public services directly: ViaggiaTreno (RFI/Trenitalia), Open-Meteo, LeFrecce, Italo, Trenord, FerrovieNord, TILO, SBB, DB, Transitous, TrovaTreno, the Ministry's strike observatory, OpenStreetMap (maps, Overpass, Nominatim, OSRM) and similar. Like any website, they receive your IP address and the request data (e.g. station or train number) and handle them under their own policies. Binario sends them to no one else.

Location
Only if you grant permission and only on the screens that use it (nearby stations, ticket sellers, services). To find nearby places the coordinates are sent to OpenStreetMap servers (Overpass), which also receive your IP. Binario does not store them and does not use location in the background.

Feedback
If you send "Feedback and report a bug", name, email and message (and, if you choose, app version and phone model) go to a Google form owned by the developer and are used only to reply to you; Google processes that data on the developer's behalf. The form address is read from a public file on GitHub. Without a network the message stays on the phone and is sent as soon as possible. It is kept as long as needed to handle your request: you can ask for deletion.

Updates
The app checks GitHub for a new version (on opening and about every hour in the background, with a notification if there is one) and, if you accept, downloads the APK from there (GitHub receives your IP). To install it Android asks for the "install unknown apps" permission.

Voice
Spoken alerts use the phone's text-to-speech, sending no data. Voice questions go through the phone's speech recognition (usually Google): Binario does not ask for microphone permission.

Permissions
• Notifications: ongoing train notification, reminders and strike alerts (scheduled on the phone, no push server).
• Foreground service, wake lock and battery optimisation: to keep the followed train updated without the app being suspended.
• Run at startup, alarms and reminders: to restore and deliver scheduled notifications on time.
• Location: nearby stations and services, map.
• Install unknown apps: only to update Binario.
• Vibration.

Legal basis and rights
The only processing done by the developer (feedback) is based on your consent, i.e. sending the message. You have the right of access, rectification, erasure, restriction, objection and portability (Arts. 15-22 GDPR): write from the app. You can lodge a complaint with the Italian data protection authority (garanteprivacy.it). For data handled by external services, contact them.

This app is not affiliated with Trenitalia, RFI, Italo or Trenord."""

/** Note legali (italiano). La versione e l'autore sono inseriti dove la pagina viene mostrata. */
const val LEGAL_TEXT = """1. Chi siamo
Binario è un'app indipendente e gratuita, creata da Marco Jannino. Non è affiliata, sponsorizzata o approvata da Trenitalia, RFI, Gruppo FS, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB, né da altre aziende di trasporto o enti citati.

2. Marchi
Nomi, marchi e loghi delle aziende citate appartengono ai rispettivi titolari e sono usati solo per indicare la fonte delle informazioni o il servizio a cui si riferiscono. L'app non usa loghi ufficiali delle aziende.

3. Dati e affidabilità
Orari, ritardi, binari, soppressioni, prezzi, scioperi, avvisi, accessibilità, affollamento e statistiche provengono da fonti pubbliche di terze parti e sono mostrati "così come sono", senza garanzia di correttezza, completezza o aggiornamento. Possono contenere errori o ritardi di aggiornamento.
Fanno sempre fede le informazioni ufficiali delle aziende: tabelloni e annunci in stazione, personale, siti e app ufficiali.

4. Stime
Affollamento indicato con "≈", calcoli "Quanto sei green" (CO₂, carburante, pedaggi, tempi con traffico), confronto itinerari e tariffe transfrontaliere indicative sono stime a scopo informativo e non costituiscono offerta né garanzia di prezzo o di tempo di viaggio.

5. Biglietti e acquisti
L'app non vende biglietti né gestisce pagamenti. I pulsanti di acquisto aprono i siti ufficiali delle aziende, le cui condizioni di vendita e di trasporto si applicano integralmente. Condizioni, tariffe e diritti dei passeggeri di ogni azienda sono raccolti come link alle sue pagine ufficiali in «Condizioni di trasporto».

6. Limitazione di responsabilità
Nei limiti consentiti dalla legge, l'autore non è responsabile per danni diretti o indiretti derivanti dall'uso dell'app o dall'affidamento sulle sue informazioni, inclusi treni persi, coincidenze mancate, spese, sanzioni o disagi. Notifiche, promemoria e sveglia fermata possono non arrivare (risparmio energetico, assenza di rete, impostazioni del telefono): non usarli come unico sistema di allerta.
I diritti dei passeggeri (rimborsi, indennizzi, assistenza) vanno esercitati nei confronti dell'azienda di trasporto, secondo il Regolamento UE 2021/782 e le sue condizioni.

7. Privacy (GDPR)
L'app non richiede registrazione, non ha pubblicità, non ha strumenti di statistiche o tracciamento e non ha un proprio server: l'autore non riceve né vende dati personali. Preferiti, impostazioni, promemoria e registro "green" restano solo sul telefono e si cancellano disinstallando l'app.
Per funzionare l'app contatta direttamente i servizi delle fonti indicate: come per qualsiasi sito web, questi ricevono l'indirizzo IP e i dati della richiesta (es. stazione o numero di treno), secondo le loro informative.
La posizione si usa solo con il tuo permesso e solo nelle schermate che la richiedono (stazioni vicine, rivendite, servizi). Per trovare i luoghi vicini le coordinate sono inviate ai server di OpenStreetMap (Overpass); l'app non le salva e non le usa in background.
Il feedback inviato dall'app passa da un modulo Google dello sviluppatore, e gli aggiornamenti dell'app da GitHub. Dettagli, base giuridica e diritti: «Privacy e permessi».

8. Fonti dei dati (citate)
Tutte le informazioni provengono da fonti pubblicamente accessibili e consultabili gratuitamente da chiunque, senza registrazione, abbonamento o accordo commerciale. L'app non acquista dati, non usa servizi a pagamento e non rivende nulla: si limita a mostrare, citandone la fonte, ciò che le aziende e gli enti pubblicano.
• Orari, ritardi, binari previsti e reali: ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Soluzioni di viaggio e prezzi: LeFrecce – Trenitalia (lefrecce.it)
• Scioperi: Osservatorio sugli scioperi nei trasporti – Ministero delle Infrastrutture e dei Trasporti (scioperi.mit.gov.it)
• Avvisi, linee, affollamento, condizioni di trasporto: Trenord (trenord.it)
• Stato degli impianti e notizie: FerrovieNord (ferrovienord.it)
• Ascensori e accessibilità stazioni, Sala Blu: RFI (rfi.it)
• Orari dei bus sostitutivi Trenord: Open Data Regione Lombardia, feed GTFS ufficiale di Trenord, licenza CC BY 4.0 (dati.lombardia.it); se non è disponibile, in alternativa Transitous
• Orari regionali e locali di altre aziende e bus sostitutivi di altre aziende: Transitous (transitous.org), che raccoglie i feed GTFS pubblicati dalle aziende
• Treni Italo: italotreno.com
• Treni e servizi in Germania: Deutsche Bahn (bahn.de)
• Treni e servizi transfrontalieri: TILO (tilo.ch)
• Orario svizzero e affollamento previsto: transport.opendata.ch / opentransportdata.swiss (FFS/SBB)
• Tariffe Arcobaleno: Comunità tariffale Ticino e Moesano (arcobaleno.ch)
• Condizioni di trasporto, tariffe e diritti: pagine ufficiali di ogni azienda (vedi «Condizioni di trasporto»)
• Diritti dei passeggeri: Regolamento (UE) 2021/782 (eur-lex.europa.eu)
• Statistiche di puntualità: TrovaTreno.it – open data, licenza CC BY 4.0
• Meteo alla stazione: Open-Meteo.com (open-meteo.com), servizio gratuito, dati CC BY 4.0; riceve solo le coordinate della stazione
• Storico dei ritardi: raccolto da Binario dai tabelloni di ViaggiaTreno, dati non ufficiali
• Prezzi carburanti: open data Ministero delle Imprese e del Made in Italy (mimit.gov.it), licenza IODL 2.0
• Mappe, rivendite, obliteratrici, ascensori: © OpenStreetMap contributors (openstreetmap.org), licenza ODbL
• Percorsi stradali: OSRM (project-osrm.org) su dati OpenStreetMap
• Software: osmdroid e componenti Android/Jetpack, licenza Apache 2.0

9. Gratuità e uso delle fonti
Binario è gratuita, senza pubblicità, senza acquisti in-app e senza scopo di lucro. Le fonti sono consultate come farebbe un normale utente dal proprio telefono, con richieste limitate e su azione dell'utente o a intervalli moderati; i contenuti restano di proprietà dei rispettivi titolari. Le pagine ufficiali sono mostrate integre nel lettore integrato o aprendo il sito originale.
Se un'azienda o un titolare di dati chiede di modificare o non mostrare più un contenuto, la funzione relativa verrà rimossa.

10. Contatti e segnalazioni
Per segnalazioni, richieste di rimozione o correzioni: contatta l'autore, Marco Jannino.
Per reclami sul servizio ferroviario rivolgiti all'azienda di trasporto interessata.

11. Modifiche
Queste note possono essere aggiornate con le nuove versioni dell'app. La versione in uso è indicata in alto. Ultimo aggiornamento: novembre 2026."""

const val LEGAL_TEXT_EN = """1. About
Binario is an independent, free app created by Marco Jannino. It is not affiliated with, sponsored or endorsed by Trenitalia, RFI, FS Group, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB, or any other transport company or body mentioned.

2. Trademarks
Company names and trademarks belong to their respective owners and are used only to identify the source of information or the service referred to. The app does not use official company logos.

3. Data and reliability
Timetables, delays, platforms, cancellations, fares, strikes, notices, accessibility, crowding and statistics come from public third-party sources and are provided "as is", without any warranty of accuracy, completeness or timeliness.
Official information always prevails: station boards and announcements, staff, official websites and apps.

4. Estimates
Crowding marked "≈", "How green are you" figures (CO₂, fuel, tolls, traffic times), route comparisons and indicative cross-border fares are estimates for information only and are not an offer or a guarantee of price or travel time.

5. Tickets and purchases
The app does not sell tickets or handle payments. Buy buttons open the operators' official websites, whose sales and carriage conditions fully apply. Each company's conditions, fares and passenger rights are collected as links to its official pages in "Conditions of carriage".

6. Limitation of liability
To the extent permitted by law, the author is not liable for any direct or indirect damage arising from the use of the app or reliance on its information, including missed trains or connections, costs, fines or inconvenience. Notifications, reminders and stop alarms may not arrive (battery saving, no network, phone settings): do not rely on them as your only alert.
Passenger rights (refunds, compensation, assistance) must be claimed from the transport operator under EU Regulation 2021/782 and its conditions.

7. Privacy (GDPR)
The app requires no registration, shows no ads, has no analytics or tracking tools and has no server of its own: the author neither receives nor sells personal data. Favourites, settings, reminders and the green log stay on your phone and are deleted when you uninstall the app.
To work, the app contacts the listed sources directly: like any website, they receive your IP address and the request data (e.g. station or train number), under their own privacy policies.
Location is used only with your permission and only on the screens that need it (nearby stations, ticket sellers, services). To find nearby places the coordinates are sent to OpenStreetMap servers (Overpass); the app does not store them or use them in the background.
Feedback sent from the app goes through a Google form owned by the developer, and app updates come from GitHub. Details, legal basis and rights: "Privacy & permissions".

8. Data sources (cited)
All information comes from publicly accessible sources that anyone can consult free of charge, without registration, subscription or commercial agreement. The app does not buy data, does not use paid services and resells nothing: it only shows, citing the source, what companies and public bodies publish.
• Timetables, delays, scheduled and actual platforms: ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Journey solutions and fares: LeFrecce – Trenitalia (lefrecce.it)
• Strikes: Transport Strike Observatory – Italian Ministry of Infrastructure and Transport (scioperi.mit.gov.it)
• Notices, lines, crowding, conditions of carriage: Trenord (trenord.it)
• Facility status and news: FerrovieNord (ferrovienord.it)
• Elevators and station accessibility, Sala Blu: RFI (rfi.it)
• Trenord replacement-bus timetables: Lombardy Region open data, official Trenord GTFS feed, CC BY 4.0 licence (dati.lombardia.it); if unavailable, Transitous as a fallback
• Regional and local timetables and replacement buses of other companies: Transitous (transitous.org), which collects the GTFS feeds published by the companies
• Italo trains: italotreno.com
• Trains and services in Germany: Deutsche Bahn (bahn.de)
• Cross-border trains and services: TILO (tilo.ch)
• Swiss timetable and expected crowding: transport.opendata.ch / opentransportdata.swiss (SBB)
• Arcobaleno fares: Ticino and Moesano fare network (arcobaleno.ch)
• Conditions of carriage, fares and rights: official pages of each company (see "Conditions of carriage")
• Passenger rights: Regulation (EU) 2021/782 (eur-lex.europa.eu)
• Punctuality statistics: TrovaTreno.it – open data, CC BY 4.0 licence
• Weather at the station: Open-Meteo.com (open-meteo.com), free service, CC BY 4.0 data; it only receives the station coordinates
• Delay history: collected by Binario from the ViaggiaTreno boards, unofficial data
• Fuel prices: Italian Ministry of Enterprises and Made in Italy open data (mimit.gov.it), IODL 2.0 licence
• Maps, ticket sellers, validators, elevators: © OpenStreetMap contributors (openstreetmap.org), ODbL licence
• Road routes: OSRM (project-osrm.org) on OpenStreetMap data
• Software: osmdroid and Android/Jetpack components, Apache 2.0 licence

9. Free of charge and use of sources
Binario is free, ad-free, with no in-app purchases and non-profit. Sources are queried as a normal user would from their own phone, with limited requests, on user action or at moderate intervals; content remains the property of its owners. Official pages are shown unaltered in the built-in reader or by opening the original site.
If a company or data owner asks to change or stop showing some content, the related feature will be removed.

10. Contact
For reports, removal requests or corrections: contact the author, Marco Jannino.
For complaints about rail services, contact the transport operator concerned.

11. Changes
These notes may be updated with new app versions. The version in use is shown at the top. Last updated: November 2026."""

/** Testi lunghi in cinese (semplificato). Le note legali restano in inglese con un avviso: fa fede il testo originale. */
const val WIDGETS_TEXT_ZH = """长按主屏幕空白处 → 小组件 → Binario，然后选择要显示的内容。点击小组件标题可更改。

• 路线 / 线路：某条路线或常用线路（例如 S5）的下一班列车，含延误和站台。
• 列车：一趟列车逐站的运行情况。
• 车站：您所选车站的出发班次。
• 收藏：一眼看到所有收藏列车的状态。

点击一行可打开列车或时刻牌。"""

const val HELP_TEXT_ZH = """如何查询时刻表？
在“搜索”页选择出发地和目的地、日期和时间，然后点击“搜索”。点击列车名称（例如 "TI FR 9627"）可查看延误、停靠站和站台。

如何查看某一站的时刻牌？
在列车页面点击一个停靠站，选择“从这里出发和到达”。

到站闹钟如何使用？
在列车页面点击您下车的车站，选择“在此站前叫醒我”。列车离开前一站时（或预计到达前4分钟）闹钟会响。在设置中开启“聋人或听障人士提醒”可获得强振动和闪光。

如何添加线路？
“列车”页 → 常用线路 → 添加，例如 S5，终点站 Varese 和 Treviglio。

如何设置小组件？
在主屏幕添加并选择要显示的内容。要更改，请点击小组件标题。

如何下载时刻表以便离线使用？
搜索线路，在结果中点按 PDF 图标：选择日期以及是否包含返程。文件保存在 Download/Binario 中，离线也能打开。此外，应用会自动记住每条已搜索线路的最新时刻。

如何告诉应用我在哪里上车？
打开列车，点按你上车的车站并选择“我在这里上车”：站台、时间和提醒（包括语音）都以该站为准。

如何在看不到屏幕的情况下使用应用？
在“设置 → 无障碍”中选择语音提醒（全部或仅即将到站）。要语音提问，请长按 Binario 图标并选择“语音提问”，或使用快速设置中的图块。

为什么有的列车没有价格或拥挤度？
价格来自 Trenitalia；拥挤度仅来自 Trenord（如有）。

可以提问吗？
可以：打开列车助手（搜索页中的对话气泡图标），例如问 "delay train 2070" 或 "trains from Varese to Milano"。助手目前能理解意大利语和英语的问题；车次也可以直接输入。

在哪里查看地图上的列车？
在菜单（☰）中打开“列车地图”：默认只显示意大利，之后可添加其他国家，应用会记住你的选择。点按圆点可查看车次、公司、晚点和下一站。

在哪里查看公司的条件和票价？
菜单（☰）› 运输条件 › 各公司条件与票价：打开公司后点按官方链接。会显示来源和核对日期。

如何发送反馈？
菜单（☰）› 发送反馈。"""

const val PRIVACY_TEXT_ZH = """隐私声明（GDPR）· 2026 年 11 月更新

数据控制者：Marco Jannino，Binario 的独立开发者。联系方式：应用内的“反馈与报告错误”。

简述
• 无账号、无广告、无统计或跟踪工具。Binario 没有自己的服务器，不会接收你的数据。
• 收藏、最近搜索、常乘列车、提醒、设置、“绿色”记录和“我的行程”记录只保存在手机上，卸载应用或在 Android 设置中即可删除。

外部服务
为显示时刻表、晚点和地图，应用会直接连接公共服务：ViaggiaTreno（RFI/Trenitalia）、Open-Meteo、LeFrecce、Italo、Trenord、FerrovieNord、TILO、SBB、DB、Transitous、TrovaTreno、意大利交通部罢工观测站、OpenStreetMap（地图、Overpass、Nominatim、OSRM）等。与任何网站一样，它们会收到你的 IP 地址和请求数据（如车站或车次），并按各自的政策处理。Binario 不会把这些数据发给其他任何人。

位置
仅在你授权后，且仅在使用位置的页面（附近车站、售票点、服务）。为查找附近地点，坐标会发送到 OpenStreetMap 服务器（Overpass），对方也会收到你的 IP。Binario 不保存坐标，也不在后台使用位置。

反馈
如果你发送“反馈与报告错误”，姓名、邮箱和消息（以及你选择时的应用版本和手机型号）会发到开发者的 Google 表单，仅用于回复你；Google 代开发者处理这些数据。表单地址从 GitHub 上的公开文件读取。没有网络时消息保留在手机上，并在可能时尽快发送。信息保留至处理完你的请求为止，你可以要求删除。

更新
应用会在 GitHub 上检查新版本（打开时以及后台大约每小时一次，有新版本时发出通知），若你同意，则从那里下载 APK（GitHub 会收到你的 IP）。安装时 Android 会请求“安装未知应用”权限。

语音
语音提醒使用手机的语音合成，不发送数据。语音提问通过手机的语音识别（通常是 Google）：Binario 不请求麦克风权限。

权限
• 通知：列车常驻通知、提醒和罢工提醒（在手机上定时，没有推送服务器）。
• 前台服务、唤醒锁和电池优化：让被关注的列车保持更新而不被系统挂起。
• 开机启动、闹钟和提醒：恢复并按时发送定时通知。
• 位置：附近车站和服务、地图。
• 安装未知应用：仅用于更新 Binario。
• 振动。

法律依据与权利
开发者唯一进行的处理（反馈）基于你的同意，即发送消息。你有权访问、更正、删除、限制处理、反对和数据可携带（GDPR 第 15–22 条）：请在应用内联系。你可以向意大利数据保护机构（garanteprivacy.it）投诉。对于外部服务处理的数据，请直接联系对方。

本应用与 Trenitalia、RFI、Italo、Trenord 无任何关联。"""

const val LEGAL_NOTE_ZH = "法律声明暂无中文版本，以下为英文原文，以原文为准。\n\n"
