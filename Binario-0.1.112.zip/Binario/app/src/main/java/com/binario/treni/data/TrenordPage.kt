package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Tutto quello che la pagina di una linea su trenord.it dà, anche per le linee TILO (S10, S30, S40, S50, RE80):
 * stato, tutti gli avvisi con i documenti allegati (PDF), le stazioni sulla linea con i servizi (biglietteria,
 * distributori automatici, accessibilità) e il link alla scheda di ogni stazione (indirizzo e altri servizi).
 * La pagina è costruita con JavaScript: la legge un WebView invisibile con [LINE_JS]; qui c'è solo la logica pura.
 * Struttura vista il 9/11/2026 (linea S50): righe stazione `a[href*="mir-code="]`, icone `img.biglietteria`,
 * `img.distributori`, `img.disabili`; avvisi con link a PDF (a.mktgcdn.com, trenord.it/fileadmin).
 */
object TrenordPage {
    /** Una stazione sulla linea: codice della scheda Trenord («mir-code», es. S01205) e servizi indicati dalle icone. */
    data class LineStation(
        val name: String,
        val url: String,
        val code: String,
        val ticketOffice: Boolean,
        val machines: Boolean,
        val accessible: Boolean,
    )

    /** Documento allegato a un avviso. */
    data class Doc(val label: String, val url: String)

    data class Line(
        val page: LineNotice.Page?,
        val notices: List<LineNotice.Message>,
        val docs: List<Doc>,
        val stations: List<LineStation>,
    )

    /** Scheda di una stazione: indirizzo e altri servizi (bar, deposito bagagli, ascensori…). */
    data class StationInfo(val address: String, val services: List<String>)

    /**
     * Script per la pagina della linea: testo visibile, stazioni con le icone dei servizi e documenti PDF.
     * Le icone si cercano nella riga della stazione: il più grande contenitore che ha un solo link a una stazione.
     */
    const val LINE_JS = "(function(){" +
        "function row(a){var p=a;while(p.parentElement&&p.parentElement.querySelectorAll('a[href*=\"mir-code=\"]').length===1){p=p.parentElement;}return p;}" +
        "var seen={};var st=[];" +
        "Array.prototype.forEach.call(document.querySelectorAll('a[href*=\"mir-code=\"]'),function(a){" +
        "if(seen[a.href])return;seen[a.href]=1;var r=row(a);" +
        "function has(c){return !!(r.querySelector('img.'+c)||r.querySelector('.'+c));}" +
        "st.push([(a.innerText||a.textContent||'').trim(),a.href,has('biglietteria'),has('distributori'),has('disabili')]);});" +
        "var docs=[];Array.prototype.forEach.call(document.querySelectorAll('a[href]'),function(a){" +
        "if(/\\.pdf(\\?|#|$)/i.test(a.href))docs.push([(a.innerText||'').trim(),a.href]);});" +
        "return JSON.stringify({text:document.body?document.body.innerText:'',stations:st,docs:docs});})()"

    /** Script per la scheda di una stazione: basta il testo visibile. */
    const val STATION_JS = "(function(){return document.body?document.body.innerText:'';})()"

    /** Codice della stazione dal link («…/stazione/?mir-code=S01205&no_cache=1» → S01205). */
    fun codeOf(url: String): String = Regex("[?&]mir-code=([A-Za-z0-9]+)").find(url)?.groupValues?.get(1).orEmpty()

    private val URL_LINE = Regex("""^(https?://)?[\w.-]+\.[a-z]{2,}/\S+$""", RegexOption.IGNORE_CASE)

    /** Riga che è solo un indirizzo web (il link del PDF scritto nel testo): nel testo non serve, diventa un pulsante. */
    fun isUrlLine(l: String) = URL_LINE.matches(l.trim())

    /** Risultato di [LINE_JS] → dati della linea (null se illeggibile o se la pagina non è ancora pronta). */
    fun parseLine(json: String): Line? {
        val o = try { JSONObject(json) } catch (e: Exception) { return null }
        val text = o.optString("text")
        val page = LineNotice.parse(text)
        val stations = ArrayList<LineStation>()
        val a = o.optJSONArray("stations") ?: JSONArray()
        for (i in 0 until a.length()) {
            val r = a.optJSONArray(i) ?: continue
            val url = r.optString(1)
            val name = r.optString(0).lines().map { it.trim() }.firstOrNull { it.isNotEmpty() }.orEmpty()
            if (name.isBlank() || !url.startsWith("https://")) continue
            stations += LineStation(name, url, codeOf(url), r.optBoolean(2), r.optBoolean(3), r.optBoolean(4))
        }
        val docs = ArrayList<Doc>()
        val d = o.optJSONArray("docs") ?: JSONArray()
        for (i in 0 until d.length()) {
            val r = d.optJSONArray(i) ?: continue
            val url = r.optString(1)
            if (url.startsWith("https://")) docs += Doc(r.optString(0).trim(), url)
        }
        if (page == null && stations.isEmpty()) return null
        return Line(page, notices(text), docs.distinctBy { it.url }, stations.distinctBy { it.url })
    }

    private val DATE_ONLY = Regex("""^\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}$""")
    private fun isHeading(l: String, name: String) = l.trim().trimEnd(':').equals(name, ignoreCase = true)

    /**
     * Tutti gli avvisi della sezione «AVVISI» (non solo il primo): ognuno comincia con la sua data.
     * Si ferma a «Vedi avvisi precedenti» o alla sezione delle stazioni. Le righe che sono solo un indirizzo web si tolgono.
     */
    fun notices(text: String): List<LineNotice.Message> {
        val lines = text.lines().map { it.trim().replace(' ', ' ') }.filter { it.isNotEmpty() }
        val start = lines.indexOfFirst { isHeading(it, "AVVISI") }
        if (start < 0) return emptyList()
        val out = ArrayList<LineNotice.Message>()
        var date = ""
        var body = ArrayList<String>()
        fun flush() {
            val b = body.filter { !isUrlLine(it) }
            if (date.isNotEmpty() || b.isNotEmpty()) out += LineNotice.Message("", date, b.joinToString("\n"))
            date = ""; body = ArrayList()
        }
        for (l in lines.drop(start + 1)) {
            if (l.startsWith("Vedi ", true) && l.contains("precedent", true)) break
            if (isHeading(l, "STAZIONI SULLA LINEA") || isHeading(l, "STATO DELLA LINEA") || l.startsWith("Filtra per servizio", true)) break
            if (l.startsWith("Ultimo aggiornamento", true)) continue
            if (DATE_ONLY.matches(l)) {
                if (date.isNotEmpty() || body.isNotEmpty()) flush()
                date = l
            } else body += l
        }
        flush()
        return out.filter { it.body.isNotBlank() }
    }

    /** Servizi che la scheda stazione Trenord elenca sotto «Altri servizi». */
    val STATION_SERVICES = listOf(
        "Bar e ristoranti", "Deposito bagagli", "Ascensori", "Parcheggio biciclette", "Parcheggio auto", "Parcheggio",
        "Servizi igienici", "Sala d'attesa", "Servizi per l'accessibilità", "Biglietteria", "Distributori automatici",
        "Edicola", "Scale mobili", "Bike sharing", "Car sharing", "Taxi", "Wi-Fi", "Defibrillatore",
    )

    /** Testo della scheda stazione → indirizzo e servizi (null se la pagina non è pronta). */
    fun parseStation(text: String): StationInfo? {
        val lines = text.lines().map { it.trim().replace(' ', ' ').replace('’', '\'') }.filter { it.isNotEmpty() }
        val iAddr = lines.indexOfFirst { isHeading(it, "Indirizzo") }
        val address = if (iAddr >= 0) lines.getOrNull(iAddr + 1)?.takeIf { !isHeading(it, "Altri servizi") }.orEmpty() else ""
        val iServ = lines.indexOfFirst { isHeading(it, "Altri servizi") }
        val services = if (iServ < 0) emptyList() else {
            // Le etichette possono andare a capo («Deposito / bagagli»): si uniscono le righe e si cercano i nomi noti
            val block = lines.drop(iServ + 1).takeWhile { !isHeading(it, "Linee") && !isHeading(it, "Orari") }.joinToString(" ")
            val norm = block.lowercase().replace(Regex("\\s+"), " ")
            STATION_SERVICES.filter { s -> norm.contains(s.lowercase()) }
                .filterNot { s -> s == "Parcheggio" && STATION_SERVICES.any { it != s && it.startsWith("Parcheggio") && norm.contains(it.lowercase()) } }
        }
        if (address.isBlank() && services.isEmpty()) return null
        return StationInfo(address, services)
    }

    /** Pagina Trenord delle linee TILO quando non c'è ancora l'elenco Trenord salvato sul telefono. */
    val KNOWN_TILO = mapOf(
        "S50" to "https://www.trenord.it/linee-e-orari/circolazione/le-nostre-linee/biasca-bellinzona-lugano-varese-malpensa/?code=S50",
    )

    /**
     * Pagina trenord.it di una linea (logica pura): quella della linea se è già di Trenord, altrimenti quella con lo
     * stesso codice nell'elenco Trenord salvato (le linee TILO ci sono, con stato, avvisi e stazioni), altrimenti la nota.
     */
    fun pageFor(code: String, url: String, saved: List<Pair<String, String>>): String? {
        if (LineNotice.isTrenordLinePage(url)) return url
        if (code.isBlank()) return null
        val c = code.replace("_", "").uppercase()
        return saved.firstOrNull { (k, u) -> k.replace("_", "").uppercase() == c && LineNotice.isTrenordLinePage(u) }?.second
            ?: KNOWN_TILO[c]
    }
}
