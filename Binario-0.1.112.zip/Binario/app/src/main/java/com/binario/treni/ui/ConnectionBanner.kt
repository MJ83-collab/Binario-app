package com.binario.treni.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Freshness
import com.binario.treni.data.Net
import com.binario.treni.data.tx

/**
 * Striscia sopra la barra in basso: «Sei offline» se non c'è rete, oppure «alcuni dati sono di N min fa»
 * se un servizio non risponde e l'app mostra l'ultimo dato noto. Sparisce da sola.
 */
@Composable
fun ConnectionBanner() {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(5_000)
            now = System.currentTimeMillis()
        }
    }
    val age = Freshness.ageIfRecent(now)
    val text = when {
        !Net.online -> tx("Sei offline. Mostro gli ultimi dati disponibili.")
        age != null -> tx("Il servizio non risponde: alcuni dati sono di %d min fa.").replace("%d", maxOf(1L, age / 60_000L).toString())
        else -> null
    } ?: return
    Box(Modifier.fillMaxWidth().background(Color(0xFFFFE9C7)).padding(horizontal = 12.dp, vertical = 6.dp).semantics { liveRegion = LiveRegionMode.Polite }) {
        Text(text, color = Color(0xFF6B3B00), fontSize = 13.sp)
    }
}
