package com.binario.treni.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Dimensione del testo scelta dall'utente (si somma a quella di sistema). Con il testo ingrandito le righe vanno a capo
 * invece di essere tagliate, così nessuna parola sparisce.
 */
object TextScale {
    var value by mutableStateOf(1f)

    val big: Boolean get() = value > 1.05f

    fun load(ctx: Context) { value = Store(ctx).textScale.coerceIn(1f, 1.6f) }

    fun set(ctx: Context, v: Float) { Store(ctx).textScale = v; value = v }

    /** Numero massimo di righe: quello richiesto con il testo normale, nessun limite con il testo ingrandito. */
    fun lines(n: Int): Int = if (big) Int.MAX_VALUE else n
}
