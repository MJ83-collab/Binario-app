package com.binario.treni.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Diag
import com.binario.treni.data.Fmt
import com.binario.treni.data.Linea
import com.binario.treni.data.SwissTraffic
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Avvisi FFS in corso per una linea TILO o svizzera (lo stesso contenuto del feed RSS «Informazioni sul traffico
 * ferroviario in Svizzera»). Se non ce n'è nessuno lo dice: la circolazione per le FFS è regolare.
 */
@Composable
fun SwissTrafficCard(line: Linea, refresh: Int, openWeb: (String, String) -> Unit) {
    var notices by remember(line.key) { mutableStateOf<List<SwissTraffic.Notice>?>(null) }
    var failed by remember(line.key) { mutableStateOf(false) }
    LaunchedEffect(line.key, refresh) {
        val places = (line.route.split("–", " - ") + listOf(line.a.name, line.b.name)).map { it.trim() }.filter { it.isNotBlank() }
        val r = withContext(Dispatchers.IO) {
            try {
                SwissTraffic.forLine(SwissTraffic.load(), line.name, places, System.currentTimeMillis())
            } catch (e: Exception) {
                Diag.record("avvisi-ffs", e)
                null
            }
        }
        failed = r == null
        notices = r
    }
    if (failed) return
    WhiteCard {
        CardTitle(tx("Avvisi FFS sulla linea"))
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            val list = notices
            when {
                list == null -> Text(tx("Controllo gli avvisi delle FFS…"), color = Muted, fontSize = 13.sp)
                list.isEmpty() -> Text(tx("Nessun avviso FFS in corso: per le FFS la circolazione è regolare."), fontSize = 14.sp)
                else -> list.take(5).forEach { n ->
                    Column(
                        Modifier.fillMaxWidth().clickable { if (n.link.isNotBlank()) openWeb("FFS", n.link) }.padding(vertical = 6.dp),
                    ) {
                        Text(n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        val period = listOfNotNull(
                            n.start.takeIf { it > 0 }?.let { Fmt.dayTime(it) },
                            n.end.takeIf { it > 0 }?.let { Fmt.dayTime(it) },
                        ).joinToString(" → ")
                        if (period.isNotBlank()) Text(period, color = Muted, fontSize = 12.sp)
                        Text(n.text.take(400), fontSize = 13.sp)
                    }
                }
            }
            Text(tx("Dati aperti FFS (testi in inglese)."), color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            TextButton({ openWeb("FFS", SwissTraffic.PAGE) }) { Text(tx("Situazione dell'esercizio FFS"), color = Green) }
        }
    }
}
