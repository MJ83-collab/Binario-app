package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.HelpTopic
import com.binario.treni.data.HelpTopics
import com.binario.treni.data.tx

/**
 * «Aiuto e FAQ» divisa per argomenti: un elenco di domande che si aprono con un tocco, più una ricerca
 * (senza accenti né maiuscole). Il testo è quello della guida nella lingua dell'app.
 */
@Composable
fun HelpScreen(text: String, onBack: () -> Unit) {
    val topics = remember(text) { HelpTopics.parse(text) }
    var query by rememberSaveable { mutableStateOf("") }
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    val shown = topics.filter { helpMatches(query, it) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Aiuto e FAQ"), onBack)
        OutlinedTextField(
            query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            placeholder = { Text(tx("Cerca nella guida")) }, singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, null) },
        )
        if (shown.isEmpty()) MessageBox(tx("Nessun argomento trovato"))
        LazyColumn(Modifier.weight(1f)) {
            keyedItems(shown, key = { it.title }) { t ->
                // Con una ricerca le risposte sono già aperte: si legge subito dove compare la parola cercata
                HelpRow(t, expanded = open == t.title || query.isNotBlank()) { open = if (open == t.title) null else t.title }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun HelpRow(t: HelpTopic, expanded: Boolean, onToggle: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null, tint = Muted)
            }
            if (expanded && t.body.isNotBlank()) Text(t.body, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

/** Ricerca nella guida: come in Puntualità (senza accenti né maiuscole); per cinese e giapponese si cerca il testo così com'è. */
internal fun helpMatches(q: String, t: HelpTopic): Boolean =
    if (q.isNotBlank() && foldText(q).isEmpty()) (t.title + " " + t.body).contains(q.trim(), ignoreCase = true)
    else matchesQuery(q, t.title, t.body)
