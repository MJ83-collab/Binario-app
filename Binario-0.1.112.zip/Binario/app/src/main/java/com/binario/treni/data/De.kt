package com.binario.treni.data

/**
 * Traduzione tedesca dell'interfaccia. Le chiavi sono i testi inglesi (EN e tr(it, en)): una sola tabella copre
 * entrambi i sistemi; PAIRS risolve le poche parole inglesi ambigue (iniziali dei giorni, "Notes").
 * I testi senza traduzione restano in inglese. Divisa in più funzioni per non superare i limiti del bytecode.
 */
object De {
    private const val SEP = "\u0001"
    private val PAIRS: Map<String, String> = mapOf(
        "M" + SEP + "T" to "D",
        "G" + SEP + "T" to "D",
        "S" + SEP + "S" to "S",
        "D" + SEP + "S" to "S",
        "L" + SEP + "M" to "M",
        "M" + SEP + "W" to "M",
        "V" + SEP + "F" to "F",
        "Banconote" + SEP + "Notes" to "Scheine",
    )
    private val MAP: HashMap<String, String> by lazy { HashMap<String, String>(2400).also { m -> m.putAll(mapOf("Price with a change: check sbb.ch or Trainline" to "Preis mit Umstieg: auf sbb.ch oder Trainline prüfen", "SBB fare (single ticket, adult)" to "SBB-Preis (einfache Fahrt, Erwachsene)", "Read on sbb.ch on" to "Auf sbb.ch gelesen am", "Open on sbb.ch" to "Auf sbb.ch öffnen", "2nd class" to "2. Klasse", "Where there is no 1st class (e.g. many regional trains) the 2nd class price is shown." to "Wo es keine 1. Klasse gibt (z. B. viele Regionalzüge), wird der Preis der 2. Klasse angezeigt.", "App updates" to "App-Updates", "Only strikes on my route" to "Nur Streiks auf meiner Strecke", "at my times" to "zu meinen Zeiten", "change it in News › My route and times" to "änderbar unter Nachrichten › Meine Strecke und Zeiten", "No route chosen: set your route in News › My route and times. Meanwhile you get national strikes and those in your region." to "Keine Strecke gewählt: Lege deine Strecke unter Nachrichten › Meine Strecke und Zeiten fest. Bis dahin bekommst du landesweite Streiks und die deiner Region.", "1st and 2nd class" to "1. und 2. Klasse", "Accessible to people with disabilities or reduced mobility" to "Zugänglich für Menschen mit Behinderung oder eingeschränkter Mobilität", "Add shortcut" to "Schnelltaste hinzufügen", "Replacement buses" to "Ersatzbusse", "Defibrillators" to "Defibrillatoren", "Remove shortcut" to "Schnelltaste entfernen", "Remove the shortcut?" to "Schnelltaste entfernen?", "Done" to "Fertig", "The official app to call 112 sending your exact location." to "Die offizielle App, um die 112 anzurufen und deinen genauen Standort zu senden.", "No shortcuts: tap + to add the features you use most." to "Keine Schnelltasten: Tippe auf +, um die Funktionen hinzuzufügen, die du am meisten nutzt.", "This route" to "Diese Strecke", "This shortcut already exists" to "Diese Schnelltaste gibt es schon", "AREU Lombardy website" to "Website von AREU Lombardei", "2nd class only" to "Nur 2. Klasse", "A station's departure board" to "Abfahrtstafel eines Bahnhofs", "Shortcuts" to "Schnelltasten", "Tap the shortcut to remove." to "Tippe auf die Schnelltaste, die du entfernen möchtest.", "Bikes allowed" to "Fahrradmitnahme", "A specific train (by number)" to "Ein bestimmter Zug (nach Nummer)", "Do you really want to remove it? You can add it again with +." to "Möchtest du sie wirklich entfernen? Du kannst sie mit + wieder hinzufügen.", "Station toilets" to "Toiletten im Bahnhof", "not available" to "nicht verfügbar", "1st class" to "1. Klasse")); p0(m); p1(m); p2(m); p3(m); p4(m); p5(m); p6(m); p7(m); p8(m); p9(m); p10(m); p11(m); p12(m); p13(m); p14(m); mapOf("SBB services at the station" to "SBB-Services im Bahnhof", "SBB services not reachable right now." to "SBB-Services gerade nicht erreichbar.", "Tap to retry" to "Tippen, um es erneut zu versuchen", "Reading services from the SBB website…" to "Services werden von der SBB-Website gelesen…", "Hide shops and food" to "Geschäfte und Verpflegung ausblenden", "Shops and food" to "Geschäfte und Verpflegung", "open" to "geöffnet", "Open" to "Geöffnet", "Closed" to "Geschlossen", "Open/closed and hours: SBB website, refreshed every 5 minutes. All data without guarantee." to "Geöffnet/geschlossen und Öffnungszeiten: SBB-Website, alle 5 Minuten aktualisiert. Alle Angaben ohne Gewähr.", "Station page on sbb.ch" to "Bahnhofseite auf sbb.ch").forEach { (k, v) -> m.putIfAbsent(k, v) }; mapOf("No region chosen" to "Keine Region gewählt", "Notices and strikes in: " to "Meldungen und Streiks in: ", " (and with no region given)" to " (und ohne Regionsangabe)", "Change" to "Ändern", "Show only notices and strikes that affect these regions (plus national ones). You can pick more than one." to "Nur Meldungen und Streiks anzeigen, die diese Regionen betreffen (plus landesweite). Du kannst mehrere wählen.", "Reset" to "Zurücksetzen").forEach { (k, v) -> m.putIfAbsent(k, v) } } }

    private val TEMPLATES: List<Pair<String, String>> = listOf(
        "No out-of-service elevators or escalators reported at {0} (FerrovieNord/RFI). The station screen lists lifts per platform." to "In {0} sind keine Aufzüge oder Rolltreppen außer Betrieb gemeldet (FerrovieNord/RFI). Der Bahnhofsbildschirm listet die Aufzüge pro Gleis auf.",
        "Binario · scheduled times from Trenitalia/LeFrecce, generated on {0}. Check delays and changes before travelling." to "Binario · planmäßige Zeiten von Trenitalia/LeFrecce, erstellt am {0}. Prüfe Verspätungen und Änderungen vor der Reise.",
        "I can't find train {0} today. Check the number (it's on your ticket or the board) or search by station." to "Ich finde heute keinen Zug {0}. Prüfe die Nummer (sie steht auf deiner Fahrkarte oder der Tafel) oder suche über den Bahnhof.",
        "Band estimated from distance (about {0} km): check at the ticket office or in the Trenord app" to "Stufe aus der Entfernung geschätzt (etwa {0} km): am Schalter oder in der Trenord-App prüfen",
        "By car it would take about {0} minutes less each way, but you couldn't use the travel time." to "Mit dem Auto wärst du etwa {0} Minuten pro Strecke schneller, könntest die Reisezeit aber nicht nutzen.",
        "By train you save about {0} minutes each way at rush hour (and you can read or work)." to "Mit dem Zug sparst du in der Hauptverkehrszeit etwa {0} Minuten pro Strecke (und kannst lesen oder arbeiten).",
        "Stops from {0} to the terminus · official Swiss timetable (transport.opendata.ch)" to "Halte von {0} bis zur Endstation · offizieller Schweizer Fahrplan (transport.opendata.ch)",
        "Which station do you leave from? Say for example \"from Varese to {0}\"." to "Von welchem Bahnhof fährst du ab? Sage zum Beispiel \"von Varese nach {0}\".",
        "I can't find bus, metro, tram or taxi stops mapped within 400 m of {0}." to "Ich finde keine Bus-, U-Bahn-, Tram- oder Taxihaltestellen im Umkreis von 400 m um {0}.",
        "You board at {0}. Where do you get off? I'll warn you before the stop." to "Du steigst in {0} ein. Wo steigst du aus? Ich warne dich vor der Haltestelle.",
        "You have already sent {0} messages today: try again tomorrow. Thanks!" to "Du hast heute bereits {0} Nachrichten gesendet: Versuche es morgen wieder. Danke!",
        "No connection: timetable downloaded at {0} on {1}. Delays not updated." to "Keine Verbindung: Fahrplan um {0} am {1} heruntergeladen. Verspätungen nicht aktualisiert.",
        "Platform change at {0}: train {1} now uses platform {2} instead of {3}." to "Gleisänderung in {0}: Zug {1} fährt jetzt auf Gleis {2} statt {3}.",
        "The nearest station is {0} ({1}). Here are the next departures:" to "Der nächste Bahnhof ist {0} ({1}). Hier die nächsten Abfahrten:",
        "In about {0} minutes you arrive at {1}. Start getting ready." to "In etwa {0} Minuten kommst du in {1} an. Mach dich bereit.",
        "You are already following {0}. Here is how it's going:" to "Du folgst bereits {0}. So läuft es:",
        "The {0} board isn't responding. Try again shortly." to "Die Tafel von {0} antwortet nicht. Versuche es gleich noch einmal.",
        "Platform change: leaves from {0} instead of {1}." to "Gleisänderung: Abfahrt von {0} statt {1}.",
        "Transitous · official {0} timetable (GTFS)" to "Transitous · offizieller Fahrplan von {0} (GTFS)",
        "I see no departures from {0} at that time." to "Ich sehe keine Abfahrten ab {0} zu dieser Zeit.",
        "Transport data not reachable now for {0}." to "Verkehrsdaten für {0} zurzeit nicht erreichbar.",
        "≈ the CO₂ absorbed in a year by {0} trees" to "≈ das CO₂, das {0} Bäume in einem Jahr aufnehmen",
        "{0} is not installed: choose another app" to "{0} ist nicht installiert: Wähle eine andere App",
        "Expected delay: {0} minutes, leaves at " to "Erwartete Verspätung: {0} Minuten, Abfahrt um ",
        "I found {0} trains: which one is yours?" to "Ich habe {0} Züge gefunden: Welcher ist deiner?",
        ", and shortly before {0} with the alarm" to ", und kurz vor {0} mit dem Alarm",
        "Departure: {0} — now choose the arrival" to "Abfahrt: {0} — jetzt den Ankunftsbahnhof wählen",
        "Message too long (max {0} characters)." to "Nachricht zu lang (max. {0} Zeichen).",
        "No connections found from {0} to {1}." to "Keine Verbindungen von {0} nach {1} gefunden.",
        "Great, I'm following {0} for you. " to "Super, ich folge {0} für dich. ",
        "No disruptions reported for: {0}." to "Keine Störungen gemeldet für: {0}.",
        "Warning: train {0} is cancelled." to "Achtung: Zug {0} fällt aus.",
        "Train {0} is now {1} minutes late." to "Zug {0} hat jetzt {1} Minuten Verspätung.",
        "I can't find train {0} today." to "Ich finde heute keinen Zug {0}.",
        "Board not available for {0}." to "Tafel für {0} nicht verfügbar.",
        " I will warn you before {0}." to " Ich warne dich vor {0}.",
        "Does this train stop at {0}?" to "Hält dieser Zug in {0}?",
        "So far in {0} ({1} days logged)" to "Bisher in {0} ({1} Tage erfasst)",
        "What time do you leave {0}?" to "Um wie viel Uhr fährst du ab {0}?",
        "In a year ({0} travel days)" to "In einem Jahr ({0} Reisetage)",
        "Italo real-time data ({0})" to "Italo-Echtzeitdaten ({0})",
        "You get off at {0} around " to "Du steigst in {0} gegen ",
        ", expected delay {0} min." to ", erwartete Verspätung {0} Min.",
        "Out of service at {0}:\n" to "Außer Betrieb in {0}:\n",
        "Platform confirmed: {0}." to "Gleis bestätigt: {0}.",
        "Data from {0} (offline)" to "Daten von {0} (offline)",
        "Running {0} min early." to "Fährt {0} Min. zu früh.",
        "Running {0} min late." to "Fährt {0} Min. verspätet.",
        "Next trains {0} → {1}:\n" to "Nächste Züge {0} → {1}:\n",
        "Board at {0}: due at {1}" to "Einsteigen in {0}: fällig um {1}",
        "Departures from {0}:" to "Abfahrten ab {0}:",
        "Departs from {0} at {1}" to "Abfahrt von {0} um {1}",
        "Outbound: {0} runs…" to "Hinfahrt: {0} Fahrten…",
        ", {0} minutes late." to ", {0} Minuten verspätet.",
        "Train {0} not found" to "Zug {0} nicht gefunden",
        "Train {0} not found" to "Zug {0} nicht gefunden",
        " (contactless {0})" to " (kontaktlos {0})",
        " from platform {0}" to " von Gleis {0}",
        "Return: {0} runs…" to "Rückfahrt: {0} Fahrten…",
        "{0} minutes late." to "{0} Minuten verspätet.",
        "Alarm set for {0}" to "Alarm gestellt für {0}",
        "Services at {0}:" to "Services in {0}:",
        "Departs from {0}" to "Abfahrt von {0}",
        "Arrivals at {0}:" to "Ankünfte in {0}:",
        "Board at {0} at {1}" to "Einsteigen in {0} um {1}",
        "Days logged: {0}" to "Erfasste Tage: {0}",
        " {0} min late." to " {0} Min. verspätet.",
        "Arrived at {0}" to "Angekommen in {0}",
        ", platform {0}" to ", Gleis {0}",
        ", platform {0}" to ", Gleis {0}",
        "Next stop: {0}" to "Nächster Halt: {0}",
        "{0} min early" to "{0} Min. zu früh",
        "Next stop {0}" to "Nächster Halt {0}",
        "{0} o'clock, {1}" to "{0} Uhr, {1}",
        "{0} min late" to "{0} Min. verspätet",
        "Near {0}:" to "In der Nähe von {0}:",
        ", at {0}." to ", in {0}.",
        "Train {0}" to "Zug {0}",
        " at {0}" to " in {0}",
    )
    private val compiled: List<Pair<Regex, String>> by lazy {
        TEMPLATES.map { (en, tr) ->
            val parts = en.split(Regex("\\{\\d\\}"))
            Regex("^" + parts.joinToString("(.+?)") { Regex.escape(it) } + "$", RegexOption.DOT_MATCHES_ALL) to tr
        }
    }
    private val cache = java.util.Collections.synchronizedMap(object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 300
    })

    private fun fromTemplate(en: String): String? {
        cache[en]?.let { return it.ifEmpty { null } }
        for ((re, tr) in compiled) {
            val m = re.matchEntire(en) ?: continue
            var z = tr
            for (g in 1 until m.groupValues.size) z = z.replace("{${g - 1}}", m.groupValues[g])
            cache[en] = z
            return z
        }
        cache[en] = ""
        return null
    }

    /** Testo tradotto per la coppia italiano/inglese; se manca, l'inglese. */
    fun of(it: String, en: String): String = PAIRS[it + SEP + en] ?: MAP[en] ?: (if (en.length in 4..400) fromTemplate(en) else null) ?: en

    fun has(en: String) = MAP.containsKey(en)

    private fun p0(m: HashMap<String, String>) {
        m[" early"] = " zu früh"
        m[" late"] = " verspätet"
        m[" · contactless"] = " · kontaktlos"
        m["1 hour before"] = "1 Stunde vorher"
        m["Cross-border passes"] = "Grenzüberschreitende Abos"
        m["Accessibility"] = "Barrierefreiheit"
        m["Buy"] = "Kaufen"
        m["Now"] = "Jetzt"
        m["Crowding"] = "Auslastung"
        m["Refresh"] = "Aktualisieren"
        m["Add"] = "Hinzufügen"
        m["Add a line, e.g. S5 Varese – Treviglio, to see the next trains in both directions."] = "Füge eine Linie hinzu, z. B. S5 Varese – Treviglio, um die nächsten Züge in beide Richtungen zu sehen."
        m["Help & FAQ"] = "Hilfe & FAQ"
        m["Alarm when the train leaves the previous stop"] = "Alarm, wenn der Zug die vorherige Haltestelle verlässt"
        m["Alarms"] = "Alarme"
        m["NTV high speed"] = "NTV-Hochgeschwindigkeit"
        m["More"] = "Mehr"
        m["Outbound"] = "Hinfahrt"
        m["Round trip"] = "Hin- und Rückfahrt"
        m["Cancel"] = "Abbrechen"
        m["Open in browser"] = "Im Browser öffnen"
        m["Open keyboard when choosing a station"] = "Tastatur bei der Bahnhofswahl öffnen"
        m["Open a departure board and tap ★ to save the station."] = "Öffne eine Abfahrtstafel und tippe auf ★, um den Bahnhof zu speichern."
        m["Open a train and tap ★ to add it here."] = "Öffne einen Zug und tippe auf ★, um ihn hier hinzuzufügen."
        m["Arcobaleno (Swiss section) + Trenord (Lombardy section): check the price when buying"] = "Arcobaleno (Schweizer Abschnitt) + Trenord (lombardischer Abschnitt): Preis beim Kauf prüfen"
        m["Trenitalia personal area"] = "Trenitalia-Kundenbereich"
        m["Arrived on time"] = "Pünktlich angekommen"
        m["Arrivals"] = "Ankünfte"
        m["Arrivals at "] = "Ankünfte in "
        m["Arrival"] = "Ankunft"
        m["Out-of-service elevators and escalators"] = "Außer Betrieb befindliche Aufzüge und Rolltreppen"
        m["Assistance"] = "Hilfe"
        m["Notify me"] = "Benachrichtige mich"
        m["Notify me 10 minutes before arriving here"] = "Benachrichtige mich 10 Minuten vor der Ankunft hier"
        m["Notices"] = "Mitteilungen"
        m["Disruption alerts on favourite routes, lines and trains"] = "Störungsmeldungen für Lieblingsstrecken, Linien und Züge"
        m["Alerts for deaf or hard-of-hearing people"] = "Hinweise für gehörlose oder schwerhörige Menschen"
        m["Backup saved"] = "Sicherung gespeichert"
        m["Bikes and light mobility"] = "Fahrräder und Mikromobilität"
        m["Ticket offices, machines, validators, contactless"] = "Schalter, Automaten, Entwerter, kontaktlos"
        m["Tickets"] = "Fahrkarten"
        m["Tickets, passes and QR codes"] = "Fahrkarten, Abos und QR-Codes"
        m["Ticket"] = "Fahrkarte"
        m["Regional ticket"] = "Regionalfahrkarte"
        m["Cross-border ticket"] = "Grenzüberschreitende Fahrkarte"
        m["Platforms: elevators and ramps"] = "Bahnsteige: Aufzüge und Rampen"
        m["Platform"] = "Gleis"
        m["Calendar"] = "Kalender"
        m["Strike calendar (Ministry)"] = "Streikkalender (Ministerium)"
        m["Change a Trenitalia booking"] = "Trenitalia-Buchung ändern"
        m["Terminus A"] = "Endstation A"
        m["Terminus A (e.g. Varese)"] = "Endstation A (z. B. Varese)"
        m["Terminus B"] = "Endstation B"
        m["Terminus B (e.g. Treviglio)"] = "Endstation B (z. B. Treviglio)"
        m["Loading station list (first time only)…"] = "Bahnhofsliste wird geladen (nur beim ersten Mal)…"
        m["Loading…"] = "Wird geladen…"
        m["Search"] = "Suchen"
        m["Search timetable"] = "Fahrplan suchen"
        m["Search & Buy"] = "Suchen & Kaufen"
        m["Search a station"] = "Bahnhof suchen"
        m["Search a station for the departure board"] = "Bahnhof für die Abfahrtstafel suchen"
        m["Search within 2 km"] = "Im Umkreis von 2 km suchen"
        m["Close"] = "Schließen"
        m["Traffic"] = "Verkehr"
        m["Connection very much at risk"] = "Anschluss sehr gefährdet"
        m["Tight connection"] = "Knapper Anschluss"
        m["How it works"] = "So funktioniert's"
        m["Same as system"] = "Wie das System"
        m["Operator announcements"] = "Mitteilungen der Bahnunternehmen"
        m["With delays of at least 60 minutes you are entitled to assistance: meals and refreshments in relation to the waiting time and, if needed, accommodation."] = "Bei Verspätungen von mindestens 60 Minuten haben Sie Anspruch auf Betreuung: Mahlzeiten und Erfrischungen im Verhältnis zur Wartezeit und bei Bedarf eine Unterkunft."
        m["Share"] = "Teilen"
        m["Share timetable"] = "Fahrplan teilen"
        m["Malpensa Express conditions"] = "Beförderungsbedingungen Malpensa Express"
        m["Trenitalia conditions"] = "Beförderungsbedingungen Trenitalia"
        m["Trenord conditions"] = "Beförderungsbedingungen Trenord"
        m["Conditions of carriage"] = "Beförderungsbedingungen"
        m["Conditions of carriage and rights"] = "Beförderungsbedingungen und Rechte"
        m["Conditions of carriage, tickets, bikes, pets, fines"] = "Beförderungsbedingungen, Fahrkarten, Fahrräder, Haustiere, Bußgelder"
        m["General conditions of carriage (regional and long distance)"] = "Allgemeine Beförderungsbedingungen (Regional- und Fernverkehr)"
        m["Specific conditions for the airport link"] = "Besondere Bedingungen für die Flughafenverbindung"
        m["Compare"] = "Vergleichen"
        m["Compare routes"] = "Strecken vergleichen"
        m["Contacts"] = "Kontakte"
        m["Always check the updated document before travelling."] = "Prüfe vor der Reise immer das aktuelle Dokument."
        m["Station coordinates not available"] = "Bahnhofskoordinaten nicht verfügbar"
        m["Stop coordinates not available"] = "Haltestellenkoordinaten nicht verfügbar"
        m["From mobiles +39 02 32 32 32 · 6:45–21:30"] = "Vom Handy +39 02 32 32 32 · 6:45–21:30"
        m["Data imported"] = "Daten importiert"
        m["Direct"] = "Direkt"
        m["Rail passengers' rights and obligations (PDF)"] = "Rechte und Pflichten der Bahnreisenden (PDF)"
        m["Disable maps"] = "Karten deaktivieren"
        m["Official documents"] = "Offizielle Dokumente"
        m["After a search, tap the download icon to save the timetable."] = "Tippe nach einer Suche auf das Download-Symbol, um den Fahrplan zu speichern."
        m["During regional rail strikes, trains are normally guaranteed between 6:00–9:00 and 18:00–21:00, "] = "Bei Streiks im Regionalverkehr sind die Züge normalerweise zwischen 6:00–9:00 und 18:00–21:00 Uhr garantiert, "
        m["Updated official lists"] = "Aktuelle offizielle Listen"
        m["List"] = "Liste"
        m["Full FerrovieNord list"] = "Vollständige FerrovieNord-Liste"
        m["Station list not available"] = "Bahnhofsliste nicht verfügbar"
        m["Delete"] = "Löschen"
        m["Ticket machines, validators, tobacconists, contactless payment"] = "Fahrkartenautomaten, Entwerter, Tabakläden, kontaktloses Bezahlen"
        m["Network error"] = "Netzwerkfehler"
        m["Error while saving"] = "Fehler beim Speichern"
        m["e.g. Varese → Como via Mendrisio or via Milan"] = "z. B. Varese → Como über Mendrisio oder über Mailand"
        m["e.g. Varese → Como: via Mendrisio (TILO) or via Milan. Duration, changes, cost and feasibility."] = "z. B. Varese → Como: über Mendrisio (TILO) oder über Mailand. Dauer, Umstiege, Kosten und Machbarkeit."
        m["Exclude categories"] = "Kategorien ausschließen"
        m["Export data"] = "Daten exportieren"
        m["Feasible"] = "Machbar"
        m["Invalid file"] = "Ungültige Datei"
        m["Source: OpenStreetMap. Tobacconists and newsagents often sell regional tickets, but not always: "] = "Quelle: OpenStreetMap. Tabakläden und Kioske verkaufen oft Regionalfahrkarten, aber nicht immer: "
        m["Frecce, Intercity and Regional"] = "Frecce, Intercity und Regional"
        m["General"] = "Allgemein"
        m["My tickets"] = "Meine Fahrkarten"
        m["My Italo trips"] = "Meine Italo-Reisen"
        m["On-board services (bikes, wheelchair spaces, classes) are not published in real-time data. "] = "Bordservices (Fahrräder, Rollstuhlplätze, Klassen) werden in den Echtzeitdaten nicht veröffentlicht. "
        m["Your rights in brief (EU 2021/782)"] = "Deine Rechte in Kürze (EU 2021/782)"
        m["The price via Milan is the Trenitalia/Trenord fare; the cross-border price is indicative: check at the ticket office or in the Trenord/SBB app."] = "Der Preis über Mailand ist der Trenitalia/Trenord-Tarif; der grenzüberschreitende Preis ist ein Richtwert: am Schalter oder in der Trenord/SBB-App prüfen."
        m["Import data"] = "Daten importieren"
        m["Unable to load train data"] = "Zugdaten konnten nicht geladen werden"
        m["Settings"] = "Einstellungen"
        m["Set"] = "Festlegen"
        m["On time"] = "Pünktlich"
        m["Delay compensation: 25% of the ticket price for 60–119 minutes, 50% from 120 minutes. Operators may not pay amounts below €4."] = "Entschädigung bei Verspätung: 25 % des Fahrpreises bei 60–119 Minuten, 50 % ab 120 Minuten. Die Unternehmen müssen Beträge unter 4 € nicht auszahlen."
        m["Back"] = "Zurück"
        m["Info"] = "Info"
        m["RFI accessibility info"] = "RFI-Informationen zur Barrierefreiheit"
        m["Customer information and lost property"] = "Kundeninformation und Fundbüro"
        m["Information and bookings (replies on weekdays)"] = "Auskunft und Buchungen (Antwort an Werktagen)"
        m["Swap"] = "Tauschen"
        m["Italo · assistance"] = "Italo · Hilfe"
        m["Italo · news"] = "Italo · Nachrichten"
        m["Purchases are made on the operator's official website: in-app purchase and synchronisation "] = "Käufe erfolgen auf der offiziellen Website des Anbieters: Kauf und Synchronisierung in der App "
        m["Delay compensation may not be due in cases of force majeure (e.g. extreme weather, natural disasters, major public health crises)."] = "Bei höherer Gewalt (z. B. extremes Wetter, Naturkatastrophen, schwere Gesundheitskrisen) besteht eventuell kein Anspruch auf Entschädigung bei Verspätung."
        m["Flash blinking for alerts"] = "Blinkendes Licht bei Alarmen"
        m["Works"] = "Bauarbeiten"
        m["National and regional conditions may set different rules for passes and regional trains."] = "Nationale und regionale Bedingungen können für Abos und Regionalzüge abweichende Regeln vorsehen."
        m["Legal"] = "Rechtliches"
        m["Lines"] = "Linien"
        m["Favourite lines"] = "Lieblingslinien"
        m["Lines, cross-border fares, services"] = "Linien, grenzüberschreitende Tarife, Services"
        m["Map"] = "Karte"
        m["FerrovieNord maintenance map"] = "FerrovieNord-Baustellenkarte"
        m["Max changes"] = "Max. Umstiege"
        m["Monthly and annual"] = "Monats- und Jahresabo"
        m["Change date, time or class"] = "Datum, Uhrzeit oder Klasse ändern"
        m["Show Buy button"] = "Kaufen-Schaltfläche anzeigen"
        m["Show later connections"] = "Spätere Verbindungen anzeigen"
        m["Later connections"] = "Spätere Verbindungen"
        m["No elevators mapped for this station."] = "Für diesen Bahnhof sind keine Aufzüge verzeichnet."
        m["No notices"] = "Keine Mitteilungen"
        m["No browser available"] = "Kein Browser verfügbar"
        m["No list published at the moment."] = "Zurzeit ist keine Liste veröffentlicht."
        m["No routes found for this time. Try later or another day (some lines do not run on Sundays)."] = "Für diese Zeit wurden keine Verbindungen gefunden. Versuche es später oder an einem anderen Tag (einige Linien fahren sonntags nicht)."
        m["No direct trains found in this direction"] = "Keine Direktzüge in dieser Richtung gefunden"
        m["No trains in the next hours"] = "Keine Züge in den nächsten Stunden"
        m["No traffic disruptions reported"] = "Keine Verkehrsstörungen gemeldet"
        m["No calendar app found"] = "Keine Kalender-App gefunden"
        m["No email app"] = "Keine E-Mail-App"
        m["No notifications. Use \"Notify me\" on a train or a connection."] = "Keine Benachrichtigungen. Nutze \"Benachrichtige mich\" bei einem Zug oder einer Verbindung."
        m["No connections"] = "Keine Verbindungen"
        m["No station found"] = "Kein Bahnhof gefunden"
        m["No rail strikes announced"] = "Keine Bahnstreiks angekündigt"
        m["Nothing to save"] = "Nichts zu speichern"
        m["Not departed yet"] = "Noch nicht abgefahren"
        m["Not available at this time"] = "Zurzeit nicht verfügbar"
        m["Persistent notification on"] = "Dauerbenachrichtigung ein"
        m["Persistent notification enabled"] = "Dauerbenachrichtigung aktiviert"
        m["Scheduled notification"] = "Geplante Benachrichtigung"
        m["Strike notifications"] = "Streikbenachrichtigungen"
        m["Notifications"] = "Benachrichtigungen"
        m["Scheduled notifications"] = "Geplante Benachrichtigungen"
        m["Scheduled notifications and wake-up alarms"] = "Geplante Benachrichtigungen und Wecker"
        m["News"] = "Nachrichten"
        m["Name (e.g. S5, RE2)"] = "Name (z. B. S5, RE2)"
        m["New favourite line"] = "Neue Lieblingslinie"
        m["Train number"] = "Zugnummer"
        m["Station name"] = "Bahnhofsname"
        m["Advanced options"] = "Erweiterte Optionen"
        m["Times and changes: official Swiss timetable (transport.opendata.ch) and Trenitalia/LeFrecce. "] = "Zeiten und Umstiege: offizieller Schweizer Fahrplan (transport.opendata.ch) und Trenitalia/LeFrecce. "
        m["Offline timetables"] = "Offline-Fahrpläne"
        m["Timetable saved for offline use"] = "Fahrplan für die Offline-Nutzung gespeichert"
        m["Time already passed"] = "Zeit bereits vorbei"
        m["Strike observatory unreachable right now"] = "Streik-Observatorium zurzeit nicht erreichbar"
        m["Official pages"] = "Offizielle Seiten"
        m["Departure"] = "Abfahrt"
        m["Origin and destination are the same"] = "Start und Ziel sind gleich"
        m["Departures"] = "Abfahrten"
        m["Departures from "] = "Abfahrten ab "
        m["Departures and arrivals from here"] = "Abfahrten und Ankünfte von hier"
        m["Step-free routes, 55 cm platforms"] = "Stufenfreie Wege, 55-cm-Bahnsteige"
        m["People with disabilities or reduced mobility: free assistance in stations and on board, normally to be requested at least 24 hours in advance."] = "Menschen mit Behinderung oder eingeschränkter Mobilität: kostenlose Hilfe an Bahnhöfen und im Zug, normalerweise mindestens 24 Stunden im Voraus anzufordern."
        m["Arcobaleno zone map"] = "Arcobaleno-Zonenplan"
        m["Several runs with this number"] = "Mehrere Fahrten mit dieser Nummer"
        m["Location & Maps"] = "Standort & Karten"
        m["Location not available. Turn on GPS and try again."] = "Standort nicht verfügbar. Schalte das GPS ein und versuche es erneut."
        m["Location not available: open the map first or turn on GPS."] = "Standort nicht verfügbar: Öffne zuerst die Karte oder schalte das GPS ein."
        m["Favourite"] = "Favorit"
        m["Favourites"] = "Favoriten"
        m["Trenitalia/Trenord fare"] = "Trenitalia/Trenord-Tarif"
        m["Trenitalia/Trenord fare (1 adult)"] = "Trenitalia/Trenord-Tarif (1 Erwachsener)"
        m["Before arrival"] = "Vor der Ankunft"
        m["Before departure"] = "Vor der Abfahrt"
        m["Privacy & permissions"] = "Datenschutz & Berechtigungen"
        m["You can check them in the operator's official timetable."] = "Du kannst sie im offiziellen Fahrplan des Unternehmens nachprüfen."
        m["Recent"] = "Zuletzt"
        m["Recent & favourites"] = "Zuletzt & Favoriten"
        m["Complaints: the operator must reply within one month (up to three months in justified cases)."] = "Beschwerden: Das Unternehmen muss innerhalb eines Monats antworten (in begründeten Fällen bis zu drei Monate)."
        m["Lombardy regional trains and Malpensa Express"] = "Regionalzüge der Lombardei und Malpensa Express"
        m["Finding your location…"] = "Standort wird ermittelt…"
        m["Refunds and complaints"] = "Erstattungen und Beschwerden"
        m["Remove"] = "Entfernen"
        m["Expected arrival delay of at least 60 minutes: you can choose a refund, continuation, or re-routing."] = "Erwartete Ankunftsverspätung von mindestens 60 Minuten: Du kannst zwischen Erstattung, Weiterfahrt oder Umleitung wählen."
        m["Return"] = "Rückfahrt"
        m["Ticket sellers"] = "Fahrkartenverkaufsstellen"
        m["Nearby ticket sellers and offices"] = "Verkaufsstellen und Schalter in der Nähe"
        m["Nearby ticket sellers"] = "Verkaufsstellen in der Nähe"
        m["Save"] = "Speichern"
        m["Save offline"] = "Offline speichern"
        m["Saved offline"] = "Offline gespeichert"
        m["Choose the run"] = "Fahrt wählen"
        m["Choose origin and destination"] = "Start und Ziel wählen"
        m["Choose departure and arrival stations"] = "Abfahrts- und Ankunftsbahnhof wählen"
        m["Start screen"] = "Startbildschirm"
        m["Strikes"] = "Streiks"
        m["Strikes, traffic and works"] = "Streiks, Verkehr und Bauarbeiten"
        m["Dark"] = "Dunkel"
        m["If the operator offers no alternative within 100 minutes, you may arrange it yourself with other trains or buses and claim reasonable costs."] = "Bietet das Unternehmen innerhalb von 100 Minuten keine Alternative an, kannst du selbst mit anderen Zügen oder Bussen weiterreisen und angemessene Kosten geltend machen."
        m["Report problems between train and station"] = "Probleme zwischen Zug und Bahnsteig melden"
        m["Follow"] = "Folgen"
        m["Following"] = "Gefolgt"
        m["Location permission needed"] = "Standortberechtigung erforderlich"
        m["Location permission is needed to find nearby stations."] = "Die Standortberechtigung wird benötigt, um Bahnhöfe in der Nähe zu finden."
        m["Grant permission"] = "Berechtigung erteilen"
        m["TILO services"] = "TILO-Services"
        m["Services & accessibility"] = "Services & Barrierefreiheit"
        m["Station services"] = "Bahnhofsservices"
        m["Map service temporarily unreachable"] = "Kartendienst zurzeit nicht erreichbar"
        m["TILO Pigiama night service"] = "TILO-Nachtzug Pigiama"
        m["Summary for information only: the official text of the regulation and each operator's conditions prevails. "] = "Nur zur Information zusammengefasst: Maßgeblich sind der offizielle Verordnungstext und die Bedingungen des jeweiligen Unternehmens. "
        m["Connections"] = "Verbindungen"
        m["Cancelled"] = "Ausgefallen"
        m["Station"] = "Bahnhof"
        m["Arrival station"] = "Zielbahnhof"
        m["Departure station"] = "Abfahrtsbahnhof"
        m["Stations"] = "Bahnhöfe"
        m["Favourite stations"] = "Lieblingsbahnhöfe"
        m["Nearby stations"] = "Bahnhöfe in der Nähe"
        m["Nearby stations and map"] = "Bahnhöfe in der Nähe und Karte"
        m["Wake me before this stop"] = "Weck mich vor dieser Haltestelle"
        m["TILO · Ticino and Lombardy"] = "TILO · Tessin und Lombardei"
        m["TILO · notices"] = "TILO · Mitteilungen"
        m["Full fare tables"] = "Vollständige Preistabellen"
        m["Departure board not available"] = "Abfahrtstafel nicht verfügbar"
        m["Station board"] = "Bahnhofstafel"
        m["Lombardy regional fare: check the price"] = "Regionaltarif Lombardei: Preis prüfen"
        m["Official Arcobaleno fare"] = "Offizieller Arcobaleno-Tarif"
        m["Cross-border fares"] = "Grenzüberschreitende Tarife"
        m["Theme"] = "Design"
        m["Leisure"] = "Freizeit"
        m["Type of connections"] = "Art der Verbindungen"
        m["Tickets and passes"] = "Fahrkarten und Abos"
        m["Tickets, bikes, assistance"] = "Fahrkarten, Fahrräder, Hilfe"
        m["Tap again for the departure board"] = "Erneut tippen für die Abfahrtstafel"
        m["Tap to open"] = "Zum Öffnen tippen"
        m["Tap a category to exclude it (struck through) or include it."] = "Tippe auf eine Kategorie, um sie auszuschließen (durchgestrichen) oder einzuschließen."
        m["Tap a stop for the board or the alarm."] = "Tippe auf eine Haltestelle für die Tafel oder den Alarm."
        m["Traffic, delays and strikes"] = "Verkehr, Verspätungen und Streiks"
        m["Route"] = "Strecke"
        m["Favourite and recent routes"] = "Lieblings- und letzte Strecken"
        m["Trains"] = "Züge"
        m["Guaranteed trains"] = "Garantierte Züge"
        m["Guaranteed trains during strikes"] = "Garantierte Züge bei Streiks"
        m["Guaranteed trains: updated official lists"] = "Garantierte Züge: aktuelle offizielle Listen"
        m["Favourite trains"] = "Lieblingszüge"
        m["Trenitalia · refunds and compensation"] = "Trenitalia · Erstattungen und Entschädigung"
        m["Trenitalia · guaranteed trains"] = "Trenitalia · garantierte Züge"
        m["Trenitalia · travel information"] = "Trenitalia · Reiseinformationen"
        m["Trenord · real-time traffic"] = "Trenord · Echtzeit-Verkehr"
        m["Train"] = "Zug"
        m["Train not found"] = "Zug nicht gefunden"
        m["Followed train"] = "Verfolgter Zug"
        m["Train cancelled"] = "Zug ausgefallen"
        m["Trenord · notices"] = "Trenord · Mitteilungen"
        m["Trenord · notices and strikes"] = "Trenord · Mitteilungen und Streiks"
        m["Trenord · refunds and compensation"] = "Trenord · Erstattungen und Entschädigung"
        m["Trenord: assistance for people with disabilities"] = "Trenord: Hilfe für Menschen mit Behinderung"
        m["All"] = "Alle"
        m["Every day 8:15–19:45 · book at least 24 hours ahead"] = "Täglich 8:15–19:45 · mindestens 24 Stunden im Voraus buchen"
        m["Use your location"] = "Meinen Standort verwenden"
        m["Light green"] = "Hellgrün"
        m["App version"] = "App-Version"
        m["Via Mendrisio (TILO, cross-border)"] = "Über Mendrisio (TILO, grenzüberschreitend)"
        m["Via Milan (Italy only)"] = "Über Mailand (nur Italien)"
        m["Travellers with disabilities"] = "Reisende mit Behinderung"
        m["Strong vibration with a different pattern per alert: stop alarm (3 long, repeated), reminder (3 short ×2), disruptions (2 long)"] = "Starke Vibration mit je einem eigenen Muster pro Alarm: Haltestellenalarm (3 lang, wiederholt), Erinnerung (3 kurz ×2), Störungen (2 lang)"
        m["Favourites widget"] = "Favoriten-Widget"
        m["Station widget"] = "Bahnhofs-Widget"
        m["Route / Line widget"] = "Strecken-/Linien-Widget"
        m["Train widget"] = "Zug-Widget"
        m["Arcobaleno zones"] = "Arcobaleno-Zonen"
        m["from "] = "ab "
    }

    private fun p1(m: HashMap<String, String>) {
        m["of tickets require a commercial agreement with Trenitalia, Italo and Trenord."] = "von Fahrkarten erfordern eine Handelsvereinbarung mit Trenitalia, Italo und Trenord."
        m["no changes (direct only)"] = "keine Umstiege (nur direkt)"
        m["no data"] = "keine Daten"
        m["not wheelchair accessible"] = "nicht rollstuhlgerecht"
        m["not set"] = "nicht festgelegt"
        m["plus the trains listed by the operators. For long-distance trains, each operator's published lists apply. "] = "plus die von den Unternehmen aufgeführten Züge. Im Fernverkehr gelten die veröffentlichten Listen des jeweiligen Unternehmens. "
        m["direct only"] = "nur direkt"
        m["check on site. Contactless payment is shown only if mapped."] = "vor Ort prüfen. Kontaktloses Bezahlen wird nur angezeigt, wenn es erfasst ist."
        m["♿ accessible"] = "♿ barrierefrei"
        m["♿ limited access"] = "♿ eingeschränkt zugänglich"
        m["💳 cards"] = "💳 Karten"
        m["📶 contactless"] = "📶 kontaktlos"
        m["🛗 elevator"] = "🛗 Aufzug"
        m["RFI accessibility page"] = "RFI-Seite zur Barrierefreiheit"
        m["No out-of-service facilities reported for this station."] = "Für diesen Bahnhof sind keine Ausfälle von Einrichtungen gemeldet."
        m["Checking FerrovieNord and RFI…"] = "FerrovieNord und RFI werden geprüft…"
        m["OpenStreetMap data unreachable."] = "OpenStreetMap-Daten nicht erreichbar."
        m["Source: OpenStreetMap (volunteer data, may be incomplete). Does not show today's faults."] = "Quelle: OpenStreetMap (Daten von Freiwilligen, möglicherweise unvollständig). Zeigt keine aktuellen Störungen."
        m["FerrovieNord: station and elevator notices"] = "FerrovieNord: Bahnhofs- und Aufzugsmeldungen"
        m["Varese, Como, Novara, Brescia–Iseo–Edolo lines"] = "Linien Varese, Como, Novara, Brescia–Iseo–Edolo"
        m["RFI Sala Blu assistance"] = "RFI Sala Blu Hilfe"
        m["Book help getting on and off"] = "Hilfe beim Ein- und Aussteigen buchen"
        m["Wheelchair access"] = "Rollstuhlzugang"
        m["Open official timetable"] = "Offiziellen Fahrplan öffnen"
        m["Sala Blu assistance (people with disabilities)"] = "Sala-Blu-Hilfe (Menschen mit Behinderung)"
        m["Not available for this train."] = "Für diesen Zug nicht verfügbar."
        m["Check on the Trenord website"] = "Auf der Trenord-Website prüfen"
        m["Estimate provided by Trenord"] = "Schätzung von Trenord"
        m["Open announcement"] = "Mitteilung öffnen"
        m["Source: Strike Observatory – Italian Ministry of Transport"] = "Quelle: Streik-Observatorium – Italienisches Verkehrsministerium"
        m["Strikes and travel info"] = "Streiks und Reiseinfos"
        m["No news"] = "Keine Nachrichten"
        m["I took the train today"] = "Ich bin heute Zug gefahren"
        m["Latest news"] = "Neueste Nachrichten"
        m["Strike calendar"] = "Streikkalender"
        m["Official list of the Ministry of Transport"] = "Offizielle Liste des Verkehrsministeriums"
        m["Trenitalia travel info"] = "Trenitalia-Reiseinfos"
        m["Real-time traffic"] = "Echtzeit-Verkehr"
        m["Choose what to show"] = "Anzeige auswählen"
        m["Real delays and platforms"] = "Echte Verspätungen und Gleise"
        m["Best connections"] = "Beste Verbindungen"
        m["High speed"] = "Hochgeschwindigkeit"
        m["Regional"] = "Regional"
        m["All connections"] = "Alle Verbindungen"
        m["Ticket office"] = "Fahrkartenschalter"
        m["Self-service ticket machine"] = "Fahrkartenautomat"
        m["Validator"] = "Entwerter"
        m["Authorised reseller"] = "Autorisierter Verkäufer"
        m["Elevator"] = "Aufzug"
        m["Ramp"] = "Rampe"
        m["Strike"] = "Streik"
        m["Works and changes"] = "Bauarbeiten und Änderungen"
        m["Notice"] = "Hinweis"
        m["How green are you"] = "Wie grün bist du"
        m["Train assistant"] = "Zugassistent"
        m["How much CO₂, fuel, tolls and time you save"] = "Wie viel CO₂, Kraftstoff, Maut und Zeit du sparst"
        m["Ask about trains, delays, strikes and traffic"] = "Frag nach Zügen, Verspätungen, Streiks und Verkehr"
        m["Language"] = "Sprache"
        m["Legal notes"] = "Rechtliche Hinweise"
        m["Colour-blind colours"] = "Farben für Farbenblinde"
        m["Off"] = "Aus"
        m["Red-green (protanopia, deuteranopia)"] = "Rot-Grün (Protanopie, Deuteranopie)"
        m["Blue-yellow (tritanopia)"] = "Blau-Gelb (Tritanopie)"
        m["version"] = "Version"
        m["Version"] = "Version"
        m["Before you start"] = "Bevor du loslegst"
        m["Read the full legal notes"] = "Vollständige rechtliche Hinweise lesen"
        m["I understand and accept"] = "Ich verstehe und akzeptiere"
        m["Binario is an independent app, not affiliated with Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO or SBB. Data comes from public sources and may contain errors: station boards, announcements and official channels always prevail. Estimated crowding, costs and times are indicative. All sources are public, free and cited in the legal notes. The app is free, ad-free, does not sell tickets and does not collect personal data."] = "Binario ist eine unabhängige App und steht in keiner Verbindung zu Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO oder SBB. Die Daten stammen aus öffentlichen Quellen und können Fehler enthalten: Bahnhofstafeln, Durchsagen und offizielle Kanäle haben stets Vorrang. Geschätzte Auslastung, Kosten und Zeiten sind Richtwerte. Alle Quellen sind öffentlich, kostenlos und in den rechtlichen Hinweisen genannt. Die App ist kostenlos, werbefrei, verkauft keine Fahrkarten und erhebt keine personenbezogenen Daten."
        m["App created by Marco Jannino"] = "App erstellt von Marco Jannino"
        m["Punctuality"] = "Pünktlichkeit"
        m["Monthly statistics by operator, station and train"] = "Monatsstatistiken nach Unternehmen, Bahnhof und Zug"
        m["of seats taken"] = "der Sitzplätze belegt"
        m["Source"] = "Quelle"
        m["No official data: estimate by time of day (weekday rush hours, trains to/from Milan)."] = "Keine offiziellen Daten: Schätzung nach Tageszeit (Hauptverkehrszeiten an Werktagen, Züge von/nach Mailand)."
        m["Green: plenty of seats · Yellow: look for seats · Red: full, better wait for the next train"] = "Grün: viele freie Plätze · Gelb: Platz suchen · Rot: voll, besser auf den nächsten Zug warten"
        m["Real-time crowding in the Trenord app"] = "Echtzeit-Auslastung in der Trenord-App"
        m["Scheduled"] = "Planmäßig"
        m["Actual"] = "Tatsächlich"
        m["Scheduled platform"] = "Planmäßiges Gleis"
        m["Actual platform"] = "Tatsächliches Gleis"
        m["Switzerland"] = "Schweiz"
        m["All lines"] = "Alle Linien"
        m["Extracting the line list from the Trenord website…"] = "Die Linienliste wird von der Trenord-Website gelesen…"
        m["Trenord list not available right now."] = "Trenord-Liste zurzeit nicht verfügbar."
        m["Open lines on the Trenord website"] = "Linien auf der Trenord-Website öffnen"
        m["FerrovieNord manages the infrastructure: trains on these lines are run by Trenord."] = "FerrovieNord betreibt die Infrastruktur: Auf diesen Linien fährt Trenord."
        m["Line added to favourites"] = "Linie zu den Favoriten hinzugefügt"
        m["Choose the two termini"] = "Wähle die beiden Endstationen"
        m["SBB rail traffic information"] = "SBB-Betriebsinformationen"
        m["Real-time disruption map"] = "Echtzeit-Störungskarte"
        m["TILO notices"] = "TILO-Mitteilungen"
        m["TILO cross-border lines"] = "Grenzüberschreitende TILO-Linien"
        m["Line status, notices and stations"] = "Linienstatus, Mitteilungen und Bahnhöfe"
        m["Official page"] = "Offizielle Seite"
        m["Trenord, TILO, FerrovieNord, Switzerland"] = "Trenord, TILO, FerrovieNord, Schweiz"
        m["Refresh now"] = "Jetzt aktualisieren"
        m["Updated at"] = "Aktualisiert um"
        m["refreshes every 5 minutes"] = "aktualisiert alle 5 Minuten"
        m["Official websites"] = "Offizielle Websites"
        m["Trenitalia · travel news"] = "Trenitalia · Reisenachrichten"
        m["Open source"] = "Open Source"
        m["no date"] = "kein Datum"
        m["The full text is on the source website."] = "Den vollständigen Text findest du auf der Quellwebsite."
        m["Hours"] = "Uhrzeiten"
        m["Who"] = "Wer"
        m["Where"] = "Wo"
        m["Sector"] = "Sektor"
        m["Unions"] = "Gewerkschaften"
        m["Notes"] = "Anmerkungen"
        m["Station overview"] = "Bahnhofsübersicht"
        m["Platforms"] = "Gleise"
        m["Platforms in use"] = "Genutzte Gleise"
        m["from today's trains"] = "aus den heutigen Zügen"
        m["not mapped"] = "nicht erfasst"
        m["Lifts"] = "Aufzüge"
        m["none mapped"] = "keine erfasst"
        m["escalators"] = "Rolltreppen"
        m["ramps"] = "Rampen"
        m["none / not mapped"] = "keine / nicht erfasst"
        m["present"] = "vorhanden"
        m["Ticket machines"] = "Fahrkartenautomaten"
        m["Validators"] = "Entwerter"
        m["none within 500 m"] = "keine im Umkreis von 500 m"
        m["nearest at"] = "nächster in"
        m["Toilets"] = "Toiletten"
        m["available"] = "vorhanden"
        m["wheelchair accessible station"] = "rollstuhlgerechter Bahnhof"
        m["limited access"] = "eingeschränkt zugänglich"
        m["Lifts per platform"] = "Aufzüge pro Gleis"
        m["no lift mapped"] = "kein Aufzug erfasst"
        m["ramp"] = "Rampe"
        m["Loading station services…"] = "Bahnhofsservices werden geladen…"
        m["Retry"] = "Erneut versuchen"
        m["OpenStreetMap data unreachable right now."] = "OpenStreetMap-Daten zurzeit nicht erreichbar."
        m["OpenStreetMap volunteer data: may be incomplete. Today's faults are in the box below."] = "OpenStreetMap-Daten von Freiwilligen: möglicherweise unvollständig. Die heutigen Störungen stehen im Feld unten."
        m["Italo · info and support"] = "Italo · Info und Support"
        m["Your position"] = "Dein Standort"
        m["Voice assistant (microphone on at start)"] = "Sprachassistent (Mikrofon beim Start an)"
        m["Followed train: alert on platform change or bigger delay"] = "Verfolgter Zug: Alarm bei Gleisänderung oder größerer Verspätung"
        m["Voice alerts for blind or visually impaired people"] = "Sprachhinweise für blinde oder sehbehinderte Menschen"
        m["The phone's voice tells you where to catch the train (platform), when it leaves, platform changes and delays, and warns you with an insistent sound when your stop is near."] = "Die Stimme des Handys sagt dir, wo du den Zug erreichst (Gleis), wann er abfährt, Gleisänderungen und Verspätungen und warnt dich mit einem eindringlichen Ton, wenn deine Haltestelle naht."
        m["Voice alerts on. I will tell you the platform, the departure and the stop where to get off."] = "Sprachhinweise an. Ich sage dir das Gleis, die Abfahrt und die Haltestelle zum Aussteigen."
        m["Announce every stop of the followed train"] = "Jeden Halt des verfolgten Zuges ansagen"
        m["Voice speed"] = "Sprechgeschwindigkeit"
        m["Slow"] = "Langsam"
        m["Normal"] = "Normal"
        m["Fast"] = "Schnell"
        m["Voice test."] = "Sprachtest."
        m["Try the sounds: each one has a different meaning."] = "Probiere die Töne aus: Jeder hat eine andere Bedeutung."
        m["Stop coming up"] = "Haltestelle naht"
        m["Problem"] = "Problem"
        m["To ask by voice: long-press the Binario icon and choose “Ask by voice” (you can drag it to the Home screen), or add the “Binario · Ask by voice” tile to Quick Settings. With your phone's assistant say “Open Binario”. Works with TalkBack too."] = "Für die Spracheingabe: Halte das Binario-Symbol gedrückt und wähle „Per Sprache fragen“ (du kannst es auf den Startbildschirm ziehen) oder füge die Kachel „Binario · Per Sprache fragen“ zu den Schnelleinstellungen hinzu. Sage mit dem Assistenten deines Handys „Binario öffnen“. Funktioniert auch mit TalkBack."
        m["Connection at risk: the previous train is"] = "Anschluss gefährdet: Der vorherige Zug ist"
        m["min late"] = "Min. verspätet"
        m["Short change"] = "Knapper Umstieg"
        m["Change"] = "Umstieg"
        m["at"] = "in"
        m["planned"] = "geplant"
        m["Delay compensation"] = "Entschädigung bei Verspätung"
        m["Delay over 2 hours: you can claim 50% of the ticket price."] = "Verspätung über 2 Stunden: Du kannst 50 % des Fahrpreises verlangen."
        m["Delay over 1 hour: you can claim 25% of the ticket price."] = "Verspätung über 1 Stunde: Du kannst 25 % des Fahrpreises verlangen."
        m["Frecce 30–59 minutes late: Trenitalia grants compensation. Check the conditions on its website."] = "Frecce mit 30–59 Minuten Verspätung: Trenitalia gewährt eine Entschädigung. Prüfe die Bedingungen auf der Website."
        m["The delay at your arrival station counts; season tickets have their own rules. Source: EU Regulation 2021/782 and operators' conditions."] = "Maßgeblich ist die Verspätung am Zielbahnhof; für Zeitkarten gelten eigene Regeln. Quelle: EU-Verordnung 2021/782 und Bedingungen der Unternehmen."
        m["Claim from Italo"] = "Bei Italo beantragen"
        m["Claim from Trenitalia"] = "Bei Trenitalia beantragen"
        m["Trenord refunds"] = "Trenord-Erstattungen"
        m["Trenitalia Regional compensation"] = "Trenitalia-Regional-Entschädigung"
        m["I board here"] = "Ich steige hier ein"
        m["Platform, time and alerts for this stop (also by voice)"] = "Gleis, Zeit und Hinweise für diese Haltestelle (auch per Sprache)"
        m["I will alert you for boarding at"] = "Ich erinnere dich ans Einsteigen in"
        m["Only upcoming stop"] = "Nur nächste Haltestelle"
        m["All: platform, departure, changes, delays, stops"] = "Alle: Gleis, Abfahrt, Umstiege, Verspätungen, Halte"
        m["I will alert you by voice only when your stop is coming up."] = "Ich melde mich per Sprache nur, wenn deine Haltestelle naht."
        m["Do you want to turn this feature on?"] = "Möchtest du diese Funktion einschalten?"
        m["Strong vibration with a different pattern for each alert (stop alarm, reminders, disruptions) and flashlight blinking. You can change it any time in Settings → Accessibility."] = "Starke Vibration mit einem eigenen Muster für jeden Alarm (Haltestellenalarm, Erinnerungen, Störungen) und blinkende Taschenlampe. Du kannst es jederzeit unter Einstellungen → Barrierefreiheit ändern."
        m["Try the vibration"] = "Vibration testen"
        m["Yes, turn on"] = "Ja, einschalten"
        m["No, thanks"] = "Nein, danke"
        m["Voice alerts for blind people"] = "Sprachhinweise für blinde Menschen"
        m["The phone's voice tells you the platform, when the train leaves, platform changes and delays, and an insistent sound warns you when your stop is coming up."] = "Die Stimme des Handys sagt dir das Gleis, wann der Zug abfährt, Gleisänderungen und Verspätungen, und ein eindringlicher Ton warnt dich, wenn deine Haltestelle naht."
        m["Yes, all voice alerts"] = "Ja, alle Sprachhinweise"
        m["Answer by voice"] = "Per Sprache antworten"
        m["Hear the question again"] = "Frage noch einmal anhören"
        m["I heard"] = "Ich habe gehört"
        m["Say yes, only stop, or no"] = "Sage Ja, nur Haltestelle oder Nein"
        m["I didn't understand. Answer yes, only stop, or no. Or tap one of the buttons."] = "Ich habe nicht verstanden. Antworte Ja, nur Haltestelle oder Nein. Oder tippe auf eine der Schaltflächen."
        m["Voice alerts for blind or visually impaired people. Do you want to turn this feature on? You can choose: yes, for all voice alerts about platform, departure and stops; only stop, to be alerted only when your stop is coming up; or no."] = "Sprachhinweise für blinde oder sehbehinderte Menschen. Möchtest du diese Funktion einschalten? Du kannst wählen: Ja, für alle Sprachhinweise zu Gleis, Abfahrt und Haltestellen; nur Haltestelle, um nur benachrichtigt zu werden, wenn deine Haltestelle naht; oder Nein."
        m["Timetable PDF"] = "Fahrplan-PDF"
        m["All the day's runs, saved on your phone and available offline."] = "Alle Fahrten des Tages, auf dem Handy gespeichert und offline verfügbar."
        m["Today"] = "Heute"
        m["Tomorrow"] = "Morgen"
        m["Include return"] = "Rückfahrt einschließen"
        m["Saved in Download/Binario."] = "Gespeichert in Download/Binario."
        m["Open"] = "Öffnen"
        m["No app to open PDFs"] = "Keine App zum Öffnen von PDFs"
        m["Download PDF"] = "PDF herunterladen"
        m["Could not create the timetable"] = "Fahrplan konnte nicht erstellt werden"
        m["Download the day's timetable as PDF"] = "Tagesfahrplan als PDF herunterladen"
        m["Free"] = "Kostenlos"
        m["Paid"] = "Kostenpflichtig"
        m["Free or paid: not stated"] = "Kostenlos oder kostenpflichtig: nicht angegeben"
        m["hours"] = "Stunden"
        m["Ask by voice"] = "Per Sprache fragen"
        m["Strikes and news"] = "Streiks und Nachrichten"
        m["Current journey"] = "Aktuelle Fahrt"
        m["Stop"] = "Stopp"
        m["Updating…"] = "Wird aktualisiert…"
        m["Board at"] = "Einsteigen in"
        m["platform"] = "Gleis"
        m["Next stop"] = "Nächster Halt"
        m["Alarm before"] = "Alarm vorher"
        m["Your journey"] = "Deine Fahrt"
        m["Open live status"] = "Live-Status öffnen"
        m["Stop following"] = "Nicht mehr folgen"
        m["Assistant: trains, delays, platforms, strikes"] = "Assistent: Züge, Verspätungen, Gleise, Streiks"
        m["Downloaded PDFs are also in Download/Binario"] = "Heruntergeladene PDFs liegen auch in Download/Binario"
        m["Information"] = "Informationen"
        m["Official sources, updated every 5 minutes"] = "Offizielle Quellen, alle 5 Minuten aktualisiert"
        m["Regional vs regional, high speed vs high speed"] = "Regional gegen Regional, Hochgeschwindigkeit gegen Hochgeschwindigkeit"
        m["Conditions of carriage, rights and refunds"] = "Beförderungsbedingungen, Rechte und Erstattungen"
        m["Operators' websites"] = "Websites der Unternehmen"
        m["At the station and tickets"] = "Am Bahnhof und Fahrkarten"
        m["Nearby stations on the map"] = "Bahnhöfe in der Nähe auf der Karte"
        m["Official ticket sites and personal area"] = "Offizielle Fahrkartenseiten und Kundenbereich"
        m["Tools"] = "Werkzeuge"
        m["On: all alerts"] = "An: alle Hinweise"
        m["On: upcoming stop only"] = "An: nur nächste Haltestelle"
        m["Alerts for deaf people"] = "Hinweise für gehörlose Menschen"
        m["On: vibration and flash"] = "An: Vibration und Blitz"
        m["App"] = "App"
        m["What's new in each version"] = "Neuigkeiten in jeder Version"
        m["Fix report"] = "Korrekturbericht"
        m["Problems fixed in each version"] = "In jeder Version behobene Probleme"
        m["Bus, metro, tram and taxi"] = "Bus, U-Bahn, Tram und Taxi"
        m["Looking for nearby stops and taxi ranks…"] = "Haltestellen und Taxistände in der Nähe werden gesucht…"
        m["No bus, metro, tram or taxi stop mapped within 400 m."] = "Im Umkreis von 400 m ist keine Bus-, U-Bahn-, Tram- oder Taxihaltestelle erfasst."
        m["Metro"] = "U-Bahn"
        m["Tram"] = "Tram"
        m["Bus"] = "Bus"
        m["Taxi"] = "Taxi"
        m["Bike sharing"] = "Bikesharing"
        m["Stops in maps"] = "Haltestellen auf Karten"
        m["Find a taxi"] = "Taxi finden"
        m["bus stop"] = "Bushaltestelle"
        m["Lines and stops from OpenStreetMap data: for bus times and routes check the local transport company."] = "Linien und Haltestellen aus OpenStreetMap-Daten: Für Busfahrzeiten und -strecken beim örtlichen Verkehrsunternehmen nachsehen."
        m["Metro entrance"] = "U-Bahn-Eingang"
        m["Tram stop"] = "Tramhaltestelle"
        m["Bus stop"] = "Bushaltestelle"
        m["shelter"] = "Unterstand"
        m["Taxi rank"] = "Taxistand"
        m["spaces"] = "Plätze"
        m["Tobacconists"] = "Tabakläden"
        m["Newsagents"] = "Kioske"
        m["Ticket offices"] = "Fahrkartenschalter"
        m["Bus stops"] = "Bushaltestellen"
        m["Search on Google Maps:"] = "Auf Google Maps suchen:"
        m["Can't find it? Search on Google Maps:"] = "Nicht gefunden? Auf Google Maps suchen:"
        m["Looking for ticket sellers within"] = "Verkaufsstellen werden gesucht im Umkreis von"
        m["saved data"] = "gespeicherte Daten"
        m["OpenStreetMap servers are not responding (tried 3 Overpass servers and Postpass). Try again shortly or search on Google Maps."] = "Die OpenStreetMap-Server antworten nicht (3 Overpass-Server und Postpass versucht). Versuche es gleich noch einmal oder suche auf Google Maps."
        m["OpenStreetMap data unreachable right now (tried 3 Overpass servers and Postpass)."] = "OpenStreetMap-Daten zurzeit nicht erreichbar (3 Overpass-Server und Postpass versucht)."
        m["Pull down to retry"] = "Zum Wiederholen nach unten ziehen"
        m["Pull down to refresh."] = "Zum Aktualisieren nach unten ziehen."
        m["refreshes every 5 minutes or when you pull down"] = "aktualisiert alle 5 Minuten oder beim Herunterziehen"
        m["No ticket sellers within"] = "Keine Verkaufsstellen im Umkreis von"
        m["No ticket sellers found and the OpenStreetMap servers are not responding. Use the official Trenitalia map or try again."] = "Keine Verkaufsstellen gefunden und die OpenStreetMap-Server antworten nicht. Nutze die offizielle Trenitalia-Karte oder versuche es erneut."
        m["Mooney outlets"] = "Mooney-Verkaufsstellen"
        m["Official Trenitalia map (all of Italy)"] = "Offizielle Trenitalia-Karte (ganz Italien)"
        m["Sources"] = "Quellen"
        m["Trenord authorised resellers and ticket offices"] = "Autorisierte Trenord-Verkäufer und Fahrkartenschalter"
        m["list of"] = "Liste von"
        m["updated weekly; open/closed checked now"] = "wöchentlich aktualisiert; geöffnet/geschlossen jetzt geprüft"
        m["SBB ticket machines (open data data.sbb.ch)"] = "SBB-Billettautomaten (Open Data data.sbb.ch)"
        m["ticket offices, machines and validators from"] = "Schalter, Automaten und Entwerter von"
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney outlets: the official Trenitalia map shows them."] = "Im übrigen Italien werden Trenitalia-Regionalfahrkarten bei PuntoLIS- und Mooney-Verkaufsstellen verkauft: Die offizielle Trenitalia-Karte zeigt sie an."
        m["Nearest station"] = "Nächster Bahnhof"
        m["Authorised resellers"] = "Autorisierte Verkäufer"
        m["nearest"] = "nächster"
        m["see the official Trenitalia map in Resellers"] = "siehe die offizielle Trenitalia-Karte unter Verkäufer"
        m["Downloading Trenord sellers…"] = "Trenord-Verkäufer werden geladen…"
        m["Checking who is open now…"] = "Es wird geprüft, wer jetzt geöffnet hat…"
        m["Sells"] = "Verkauft"
        m["altoadigemobilità outlets (South Tyrol)"] = "altoadigemobilità-Verkaufsstellen (Südtirol)"
        m["Railway companies"] = "Bahnunternehmen"
        m["All companies in Italy and Switzerland: sites, tickets, data"] = "Alle Unternehmen in Italien und der Schweiz: Websites, Fahrkarten, Daten"
        m["Search company or region"] = "Unternehmen oder Region suchen"
        m["no public data"] = "keine öffentlichen Daten"
        m["Website"] = "Website"
        m["Where to buy"] = "Wo kaufen"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. Italian railways with their own network (EAV, FSE, Ferrotramviaria, FAL, Circumetnea, ARST and others) publish real-time data only on their own site and app."] = "Echtzeitdaten für Züge im RFI-Netz stammen von ViaggiaTreno, für alle Schweizer Unternehmen vom offiziellen Schweizer Fahrplan. Italienische Bahnen mit eigenem Netz (EAV, FSE, Ferrotramviaria, FAL, Circumetnea, ARST und andere) veröffentlichen Echtzeitdaten nur auf ihrer eigenen Website und App."
        m["Only departures are available for Swiss stations"] = "Für Schweizer Bahnhöfe sind nur Abfahrten verfügbar"
        m["not yet included (data only in daily files too heavy for a phone: see note in Punctuality)"] = "noch nicht enthalten (Daten nur in täglichen Dateien, die für ein Handy zu groß sind: siehe Hinweis unter Pünktlichkeit)"
        m["Real-time data for trains on the RFI network comes from ViaggiaTreno; for all Swiss companies from the official Swiss timetable. For EAV, ARST, Trentino Trasporti and Cotral the app shows scheduled times (Transitous). The other railways with their own network publish timetables and real-time data only on their site and app."] = "Echtzeitdaten für Züge im RFI-Netz stammen von ViaggiaTreno, für alle Schweizer Unternehmen vom offiziellen Schweizer Fahrplan. Für EAV, ARST, Trentino Trasporti und Cotral zeigt die App die planmäßigen Zeiten (Transitous). Die übrigen Bahnen mit eigenem Netz veröffentlichen Fahrpläne und Echtzeitdaten nur auf ihrer Website und App."
        m["Only departures are available for this station"] = "Für diesen Bahnhof sind nur Abfahrten verfügbar"
        m["Operator's scheduled times (Transitous): delays appear only if the operator publishes them."] = "Planmäßige Zeiten des Unternehmens (Transitous): Verspätungen erscheinen nur, wenn das Unternehmen sie veröffentlicht."
        m["Nearby toilets"] = "Toiletten in der Nähe"
        m["Free or paid, accessible, opening hours"] = "Kostenlos oder kostenpflichtig, barrierefrei, Öffnungszeiten"
        m["Free or paid, accessible, baby changing, opening hours"] = "Kostenlos oder kostenpflichtig, barrierefrei, Wickelraum, Öffnungszeiten"
        m["Authorised resellers, ticket offices, machines, contactless"] = "Autorisierte Verkäufer, Fahrkartenschalter, Automaten, kontaktlos"
    }

    private fun p2(m: HashMap<String, String>) {
        m["Looking for toilets within"] = "Toiletten werden gesucht im Umkreis von"
        m["OpenStreetMap servers are not responding. Try again shortly or search on Google Maps."] = "Die OpenStreetMap-Server antworten nicht. Versuche es gleich noch einmal oder suche auf Google Maps."
        m["Accessible ♿"] = "Barrierefrei ♿"
        m["Within 2 km"] = "Im Umkreis von 2 km"
        m["Public toilets"] = "Öffentliche Toiletten"
        m["No toilets mapped within"] = "Keine Toiletten erfasst im Umkreis von"
        m["Prices, hours and accessibility come from OpenStreetMap volunteers: check on site."] = "Preise, Öffnungszeiten und Barrierefreiheit stammen von OpenStreetMap-Freiwilligen: vor Ort prüfen."
        m["♿ partly accessible"] = "♿ teilweise barrierefrei"
        m["🚼 baby changing"] = "🚼 Wickelraum"
        m["customers only"] = "nur für Kunden"
        m["for customers"] = "für Kunden"
        m["min walk"] = "Min. Fußweg"
        m["Service status"] = "Dienststatus"
        m["Check that all data sources respond"] = "Prüfen, ob alle Datenquellen antworten"
        m["Check again"] = "Erneut prüfen"
        m["Checking all data sources…"] = "Alle Datenquellen werden geprüft…"
        m["All sources respond correctly."] = "Alle Quellen antworten korrekt."
        m["sources with problems: related features use fallbacks or the last saved data."] = "Quellen mit Problemen: Die zugehörigen Funktionen nutzen Ausweichlösungen oder die zuletzt gespeicherten Daten."
        m["Working"] = "Funktioniert"
        m["Checked at"] = "Geprüft um"
        m["Sources are external public services: if one is down the app tries alternatives (other servers, saved data, Google Maps)."] = "Die Quellen sind externe öffentliche Dienste: Fällt eine aus, versucht die App Alternativen (andere Server, gespeicherte Daten, Google Maps)."
        m["Trains and boards"] = "Züge und Tafeln"
        m["Journeys"] = "Reisen"
        m["News and strikes"] = "Nachrichten und Streiks"
        m["Maps and station services"] = "Karten und Bahnhofsservices"
        m["The app closed unexpectedly"] = "Die App wurde unerwartet beendet"
        m["Do you want to send the report to the developer? It contains only the technical error details, the phone model and the Android version: no personal data, location or trips."] = "Möchtest du den Bericht an den Entwickler senden? Er enthält nur die technischen Fehlerdetails, das Handymodell und die Android-Version: keine persönlichen Daten, keinen Standort und keine Reisen."
        m["Binario error report"] = "Binario-Fehlerbericht"
        m["Send report"] = "Bericht senden"
        m["Ignore"] = "Ignorieren"
        m["Your next train"] = "Dein nächster Zug"
        m["I won't suggest it again"] = "Nicht mehr vorschlagen"
        m["Not mine"] = "Nicht meiner"
        m["to"] = "nach"
        m["leaves at"] = "fährt ab um"
        m["changed!"] = "geändert!"
        m["Alternatives"] = "Alternativen"
        m["Leaving earlier"] = "Früher abfahren"
        m["Looking for alternatives…"] = "Alternativen werden gesucht…"
        m["No alternative soon."] = "Bald keine Alternative."
        m["Route ready in the Search tab"] = "Strecke bereit im Reiter Suche"
        m["Learn the trains I take often"] = "Züge lernen, die ich oft nehme"
        m["From the board, journeys, Follow and favourites. Stays on the phone only."] = "Aus Tafel, Reisen, Folgen und Favoriten. Bleibt nur auf dem Handy."
        m["Alert me automatically about my usual train"] = "Automatisch über meinen üblichen Zug benachrichtigen"
        m["In the 45 minutes before departure: delay, cancellation, platform change and ready alternatives"] = "In den 45 Minuten vor der Abfahrt: Verspätung, Ausfall, Gleisänderung und bereitgestellte Alternativen"
        m["Forget"] = "Vergessen"
        m["No usual train yet: it appears after you open it at least twice on the same weekday."] = "Noch kein üblicher Zug: Er erscheint, nachdem du ihn am selben Wochentag mindestens zweimal geöffnet hast."
        m["Download failed. Check your connection and try again."] = "Download fehlgeschlagen. Prüfe deine Verbindung und versuche es erneut."
        m["A new version is available"] = "Eine neue Version ist verfügbar"
        m["Downloading the update…"] = "Update wird heruntergeladen…"
        m["To install the update allow Binario to install apps (Android asks only once), then come back here."] = "Um das Update zu installieren, erlaube Binario, Apps zu installieren (Android fragt nur einmal), und komm dann hierher zurück."
        m["Update downloaded. Confirm the installation in the Android window: favourites and settings are kept."] = "Update heruntergeladen. Bestätige die Installation im Android-Fenster: Favoriten und Einstellungen bleiben erhalten."
        m["Do you want to update Binario? The app downloads the new version by itself; favourites and settings are kept."] = "Möchtest du Binario aktualisieren? Die App lädt die neue Version selbst herunter; Favoriten und Einstellungen bleiben erhalten."
        m["What's new"] = "Neuigkeiten"
        m["Allow"] = "Erlauben"
        m["Install"] = "Installieren"
        m["Later"] = "Später"
        m["Feedback and bug reports"] = "Feedback und Fehlerberichte"
        m["Write to the developer: ideas, suggestions, problems"] = "Schreib dem Entwickler: Ideen, Vorschläge, Probleme"
        m["Suggestions, ideas or something not working? Write it here: the message goes straight to the developer."] = "Vorschläge, Ideen oder etwas funktioniert nicht? Schreib es hier: Die Nachricht geht direkt an den Entwickler."
        m["Suggestion"] = "Vorschlag"
        m["Report a bug"] = "Fehler melden"
        m["Full name"] = "Vollständiger Name"
        m["Enter your full name"] = "Gib deinen vollständigen Namen ein"
        m["Invalid email"] = "Ungültige E-Mail-Adresse"
        m["Only used to reply to you"] = "Wird nur für die Antwort an dich verwendet"
        m["Describe the problem"] = "Beschreibe das Problem"
        m["Your feedback"] = "Dein Feedback"
        m["What you were doing, what happened and what you expected (e.g. station, train number, time)."] = "Was du gerade gemacht hast, was passiert ist und was du erwartet hast (z. B. Bahnhof, Zugnummer, Uhrzeit)."
        m["What you like, what you would improve, what is missing."] = "Was dir gefällt, was du verbessern würdest, was fehlt."
        m["Write at least a few words"] = "Schreib mindestens ein paar Worte"
        m["Attach technical details"] = "Technische Details anhängen"
        m["App version, phone model and Android version: they help find the problem."] = "App-Version, Handymodell und Android-Version: Sie helfen, das Problem zu finden."
        m["Thank you! Message sent."] = "Danke! Nachricht gesendet."
        m["No connection: the message is saved and will be sent automatically as soon as possible."] = "Keine Verbindung: Die Nachricht ist gespeichert und wird so bald wie möglich automatisch gesendet."
        m["Sending…"] = "Wird gesendet…"
        m["Send"] = "Senden"
        m["Name and email are only used to reply to you and nothing else. The message contains no location, trips or favourites."] = "Name und E-Mail werden nur verwendet, um dir zu antworten, sonst für nichts. Die Nachricht enthält keinen Standort, keine Reisen und keine Favoriten."
        m["Email"] = "E-Mail"
        m["I recommend Binario, the free train app for Italy and Switzerland: timetables, live delays, platforms, strikes, Trenord and FerrovieNord, alerts for your train. No ads."] = "Ich empfehle Binario, die kostenlose Zug-App für Italien und die Schweiz: Fahrpläne, Verspätungen in Echtzeit, Gleise, Streiks, Trenord und FerrovieNord, Benachrichtigungen für deinen Zug. Ohne Werbung."
        m["Download the latest version for Android:"] = "Lade die neueste Version für Android herunter:"
        m["After downloading, open the file and allow the installation: the app then updates itself."] = "Öffne die Datei nach dem Download und erlaube die Installation: Danach aktualisiert sich die App selbst."
        m["App not installed: choose another app"] = "App nicht installiert: Wähle eine andere App"
        m["Share Binario"] = "Binario teilen"
        m["Send your contacts the link to download the latest version of the app."] = "Sende deinen Kontakten den Link zum Herunterladen der neuesten App-Version."
        m["Other apps (SMS, email…)"] = "Andere Apps (SMS, E-Mail …)"
        m["Send the app to your contacts on WhatsApp, Telegram…"] = "Sende die App an deine Kontakte über WhatsApp, Telegram …"
        m["STIBM area"] = "STIBM-Gebiet"
        m["How much it costs"] = "Was es kostet"
        m["From"] = "Von"
        m["To"] = "Nach"
        m["The journey goes through Milan"] = "Die Fahrt führt durch Mailand"
        m["In that case zone Mi1 is also needed"] = "In diesem Fall wird auch die Zone Mi1 benötigt"
        m["zones"] = "Zonen"
        m["Same zone: the minimum 2-zone fare still applies (the one with the inner zone is fine too)."] = "Gleiche Zone: Es gilt trotzdem der Mindesttarif für 2 Zonen (der mit der inneren Zone ist ebenfalls in Ordnung)."
        m["Note: this station is outside the STIBM area. It is only valid for changing train or bus, not as start or end of a STIBM ticket."] = "Hinweis: Dieser Bahnhof liegt außerhalb des STIBM-Gebiets. Er gilt nur zum Umsteigen zwischen Zug oder Bus, nicht als Start oder Ziel eines STIBM-Tickets."
        m["Single ticket"] = "Einzelfahrkarte"
        m["min"] = "Min."
        m["Carnet of 10 (Trenord website and app)"] = "10er-Karte (Trenord-Website und -App)"
        m["Daily (24 hours)"] = "Tageskarte (24 Stunden)"
        m["3 days"] = "3 Tage"
        m["Weekly (Mon–Sun)"] = "Wochenkarte (Mo–So)"
        m["Monthly"] = "Monatskarte"
        m["Yearly"] = "Jahreskarte"
        m["Monthly under 26 / over 65"] = "Monatskarte unter 26 / über 65"
        m["Yearly under 26 / over 65"] = "Jahreskarte unter 26 / über 65"
        m["Yearly ISEE below €6,000"] = "Jahreskarte ISEE unter 6.000 €"
        m["Prices valid from"] = "Preise gültig ab"
        m["Valid on Trenord and Trenitalia regional trains in 2nd class, metro, trams and buses."] = "Gültig in Regionalzügen von Trenord und Trenitalia in der 2. Klasse, in U-Bahnen, Trams und Bussen."
        m["Main rules"] = "Wichtigste Regeln"
        m["Zone map"] = "Zonenplan"
        m["Fares"] = "Tarife"
        m["Rules"] = "Regeln"
        m["Stations in the STIBM area"] = "Bahnhöfe im STIBM-Gebiet"
        m["Search station or town"] = "Bahnhof oder Ort suchen"
        m["outside the area, interchange only"] = "außerhalb des Gebiets, nur Umstieg"
        m["service suspended"] = "Betrieb eingestellt"
        m["Use for the calculation"] = "Für die Berechnung verwenden"
        m["Source: Trenord, STIBM area – areas and fares"] = "Quelle: Trenord, STIBM-Gebiet – Gebiete und Tarife"
        m["Choose the station"] = "Bahnhof wählen"
        m["Station not found"] = "Bahnhof nicht gefunden"
        m["Outside the STIBM area (interchange only)"] = "Außerhalb des STIBM-Gebiets (nur Umstieg)"
        m["zone"] = "Zone"
        m["fares"] = "Tarife"
        m["STIBM area · Milan and Monza Brianza"] = "STIBM-Gebiet · Mailand und Monza-Brianza"
        m["Zones, prices and stations of the integrated ticket"] = "Zonen, Preise und Bahnhöfe des integrierten Tickets"
        m["One ticket for Trenord and Trenitalia regional trains, metro, trams and buses in the Metropolitan City of Milan, the province of Monza and Brianza and some nearby towns. The price depends on the number of zones (Mi1…Mi9) between start and end, not on the vehicle."] = "Ein Ticket für Regionalzüge von Trenord und Trenitalia, U-Bahn, Trams und Busse in der Metropolitanstadt Mailand, der Provinz Monza und Brianza und einigen nahen Orten. Der Preis hängt von der Zahl der Zonen (Mi1…Mi9) zwischen Start und Ziel ab, nicht vom Verkehrsmittel."
        m["How much your pass costs"] = "Was dein Abo kostet"
        m["My Conductor"] = "Mein Zugbegleiter"
        m["Follow your train: alerts before, during and after the trip"] = "Verfolge deinen Zug: Hinweise vor, während und nach der Fahrt"
        m["Tell me your train: I'll alert you about platform, delays and arrival. All trains, no sign-up."] = "Sag mir deinen Zug: Ich benachrichtige dich über Gleis, Verspätungen und Ankunft. Alle Züge, ohne Anmeldung."
        m["Trenord from A to B: weekly, monthly, yearly, Trenocittà, tickets"] = "Trenord von A nach B: Wochen-, Monats-, Jahreskarten, Trenocittà, Fahrkarten"
        m["Trenord regional fare (Lombardy) by distance band, valid from"] = "Regionaltarif Trenord (Lombardei) nach Entfernungsstufe, gültig ab"
        m["Cannot work out the distance between these stations. Check your connection or choose stations in Lombardy."] = "Die Entfernung zwischen diesen Bahnhöfen kann nicht berechnet werden. Prüfe deine Verbindung oder wähle Bahnhöfe in der Lombardei."
        m["Journey within the STIBM area"] = "Fahrt innerhalb des STIBM-Gebiets"
        m["Between these stations the integrated STIBM ticket applies (also valid on metro, trams and buses):"] = "Zwischen diesen Bahnhöfen gilt das integrierte STIBM-Ticket (auch gültig in U-Bahnen, Trams und Bussen):"
        m["Tap for prices and rules."] = "Tippe für Preise und Regeln."
        m["distance band"] = "Entfernungsstufe"
        m["Passes"] = "Abos"
        m["Weekly"] = "Wochenkarte"
        m["Trenocittà monthly"] = "Trenocittà Monatskarte"
        m["Trenocittà: train plus city transport in the town shown. "] = "Trenocittà: Zug plus Stadtverkehr im angezeigten Ort. "
        m["Passes on the Io Viaggio card (€10, valid 4 years). Families: 2nd minor child −20%, from the 3rd free (Io Viaggio in Famiglia)."] = "Abos auf der Io-Viaggio-Karte (10 €, 4 Jahre gültig). Familien: 2. minderjähriges Kind −20 %, ab dem 3. kostenlos (Io Viaggio in Famiglia)."
        m["Adult single"] = "Erwachsene, einfache Fahrt"
        m["Children 4–14"] = "Kinder 4–14"
        m["Senior"] = "Senioren"
        m["Carnet of 10"] = "10er-Karte"
        m["Children under 4 free; children 4–14 free with an adult family member holding a ticket."] = "Kinder unter 4 fahren kostenlos; Kinder von 4–14 fahren kostenlos mit einem Familienmitglied, das eine Fahrkarte hat."
        m["Io Viaggio Ovunque (all trains and public transport)"] = "Io Viaggio Ovunque (alle Züge und der öffentliche Verkehr)"
        m["All of Lombardy"] = "Ganze Lombardei"
        m["Province, monthly"] = "Provinz, monatlich"
        m["1 day"] = "1 Tag"
        m["2 days"] = "2 Tage"
        m["7 days"] = "7 Tage"
        m["Quarterly"] = "Quartalsweise"
        m["1st class supplement:"] = "Zuschlag 1. Klasse:"
        m["per trip"] = "pro Fahrt"
        m["per month"] = "pro Monat"
        m["per year (Io Viaggio Ovunque in Lombardia)"] = "pro Jahr (Io Viaggio Ovunque in Lombardia)"
        m["Bikes on lines leaving Lombardy: €3.50."] = "Fahrräder auf Linien, die die Lombardei verlassen: 3,50 €."
        m["Official fares"] = "Offizielle Tarife"
        m["Trenord passes"] = "Trenord-Abos"
        m["2nd cl."] = "2. Kl."
        m["1st cl."] = "1. Kl."
        m["Trains: 2nd class only. First class supplement: €2.80 per trip, €31 per month, €310 per year."] = "Züge: nur 2. Klasse. Zuschlag 1. Klasse: 2,80 € pro Fahrt, 31 € pro Monat, 310 € pro Jahr."
        m["Malpensa Express · fares"] = "Malpensa Express · Tarife"
        m["Prices from every station, lines, classes and restrictions"] = "Preise ab jedem Bahnhof, Linien, Klassen und Einschränkungen"
        m["The two lines"] = "Die zwei Linien"
        m["Prices from every station"] = "Preise ab jedem Bahnhof"
        m["Single adult / child"] = "Einfach Erwachsene / Kinder"
        m["Same-day return"] = "Rückfahrt am selben Tag"
        m["Weekly pass"] = "Wochenkarte"
        m["Monthly pass"] = "Monatskarte"
        m["Yearly pass"] = "Jahreskarte"
        m["Other tickets"] = "Weitere Fahrkarten"
        m["Return within 30 days (online only), adult / child"] = "Rückfahrt innerhalb von 30 Tagen (nur online), Erwachsene / Kinder"
        m["Malpensa Family (2 adults + 2 children 4–17)"] = "Malpensa Family (2 Erwachsene + 2 Kinder 4–17)"
        m["Terminal 1 ⇄ Terminal 2 transfer, adult / child"] = "Transfer Terminal 1 ⇄ Terminal 2, Erwachsene / Kinder"
        m["Rules and restrictions"] = "Regeln und Einschränkungen"
        m["Milan ⇄ Malpensa"] = "Mailand ⇄ Malpensa"
        m["To or from Malpensa airport (Terminal 1 and 2) the airport fare applies. Prices valid from"] = "Zum oder vom Flughafen Malpensa (Terminal 1 und 2) gilt der Flughafentarif. Preise gültig ab"
        m["Malpensa airport: Malpensa Express fare"] = "Flughafen Malpensa: Malpensa-Express-Tarif"
        m["single"] = "einfach"
        m["monthly 2nd cl."] = "Monatskarte 2. Kl."
        m["monthly 1st cl."] = "Monatskarte 1. Kl."
        m["There is no direct airport fare for this station. Tap for all fares and rules."] = "Für diesen Bahnhof gibt es keinen direkten Flughafentarif. Tippe für alle Tarife und Regeln."
        m["The prices below (regional fare) are not valid to or from the airport. Tap for all fares and restrictions."] = "Die folgenden Preise (Regionaltarif) gelten nicht zum oder vom Flughafen. Tippe für alle Tarife und Einschränkungen."
        m["2nd class, single ticket, CHF · valid from 14.12.2025 (source: Arcobaleno)"] = "2. Klasse, Einzelfahrkarte, CHF · gültig ab 14.12.2025 (Quelle: Arcobaleno)"
        m["Trenord passes and tickets"] = "Trenord-Abos und -Fahrkarten"
        m["Add to calendar"] = "Zum Kalender hinzufügen"
        m["Some features may have bugs or change. Tap here to report a problem."] = "Einige Funktionen können Fehler enthalten oder sich ändern. Tippe hier, um ein Problem zu melden."
        m["Alarms and saved timetables"] = "Alarme und gespeicherte Fahrpläne"
        m["More options (voice, vibration for deaf people) in Settings → Accessibility."] = "Weitere Optionen (Sprache, Vibration für Gehörlose) unter Einstellungen → Barrierefreiheit."
        m["Also just for your route and your times"] = "Auch nur für deine Strecke und deine Zeiten"
        m["Cancelled."] = "Ausgefallen."
        m["Travel assistance for disabled passengers"] = "Reisehilfe für Fahrgäste mit Behinderung"
        m["Remind me (scheduled notification)"] = "Erinnere mich (geplante Benachrichtigung)"
        m["Trenord notices"] = "Trenord-Mitteilungen"
        m["Biasca – Bellinzona – Lugano – Chiasso – Como"] = "Biasca – Bellinzona – Lugano – Chiasso – Como"
        m["Biasca – Bellinzona – Lugano – Varese – Malpensa"] = "Biasca – Bellinzona – Lugano – Varese – Malpensa"
        m["Tickets and prices"] = "Fahrkarten und Preise"
        m["Cadenazzo – Luino – Gallarate"] = "Cadenazzo – Luino – Gallarate"
        m["Arcobaleno fare calculator"] = "Arcobaleno-Tarifrechner"
        m["Dogs, cats and pet carriers: rules and prices by operator"] = "Hunde, Katzen und Transportboxen: Regeln und Preise je Unternehmen"
        m["Castione-Arbedo – Bellinzona – Locarno"] = "Castione-Arbedo – Bellinzona – Locarno"
        m["Find an Italo train by number"] = "Italo-Zug nach Nummer finden"
        m["Who to call and how to book: Sale Blu 800 90 60 60, Trenord, Italo, SBB"] = "Wen anrufen und wie buchen: Sale Blu 800 90 60 60, Trenord, Italo, SBB"
        m["Colour-blind colours. Do you want to turn this on? Tap yes red-green, yes blue-yellow, or no."] = "Farben für Farbenblinde. Möchtest du das einschalten? Tippe auf Ja Rot-Grün, Ja Blau-Gelb oder Nein."
        m["What's your name? Tell me your first and last name."] = "Wie heißt du? Nenne mir deinen Vor- und Nachnamen."
        m["Como – Mendrisio – Varese"] = "Como – Mendrisio – Varese"
        m["Conditions of carriage, delays, compensation"] = "Beförderungsbedingungen, Verspätungen, Entschädigung"
        m["Contacts and support"] = "Kontakte und Support"
        m["Validate before departure and at every change of vehicle (between two trains the first validation is enough)."] = "Vor der Abfahrt und bei jedem Fahrzeugwechsel entwerten (zwischen zwei Zügen genügt die erste Entwertung)."
        m["Single ticket valid 4 hours for the whole journey (in Italy from validation). Monthly cross-border passes: in Italy from the 1st of the month, only on an Io Viaggio card; in Ticino 30 days from purchase."] = "Einzelfahrkarte, 4 Stunden für die gesamte Fahrt gültig (in Italien ab Entwertung). Grenzüberschreitende Monatskarten: in Italien ab dem 1. des Monats, nur auf einer Io-Viaggio-Karte; im Tessin 30 Tage ab Kauf."
        m["What to do and who to contact: Trenord, Trenitalia, Italo, SBB"] = "Was zu tun ist und wen du kontaktieren kannst: Trenord, Trenitalia, Italo, SBB"
        m["From A to B: passes and tickets, also to Switzerland"] = "Von A nach B: Abos und Fahrkarten, auch in die Schweiz"
        m["From: "] = "Von: "
        m["Describe the problem."] = "Beschreibe das Problem."
        m["Describe the problem: what you were doing and what happened."] = "Beschreibe das Problem: was du gemacht hast und was passiert ist."
        m["Dictate the message"] = "Nachricht diktieren"
        m["Shall I send, correct or cancel? Say send, correct or cancel."] = "Soll ich senden, korrigieren oder abbrechen? Sage senden, korrigieren oder abbrechen."
        m["Tell me your suggestion."] = "Nenne mir deinen Vorschlag."
        m["Rights and refunds"] = "Rechte und Erstattungen"
        m["Where am I"] = "Wo bin ich"
        m["Where I am, platforms, lifts, stairs, nearby services; guidance to a place"] = "Wo ich bin, Gleise, Aufzüge, Treppen, Services in der Nähe; Wegführung zu einem Ort"
        m["Where I am, platforms, lifts, services; guidance to a place"] = "Wo ich bin, Gleise, Aufzüge, Services; Wegführung zu einem Ort"
        m["Duration"] = "Dauer"
        m["Sold out"] = "Ausverkauft"
        m["Explore by voice"] = "Per Sprache erkunden"
        m["Voice feedback"] = "Sprach-Feedback"
        m["Voice feedback. After the tone, tell me: is it a suggestion or do you want to report a problem? You can say cancel at any time."] = "Sprach-Feedback. Sage nach dem Ton: Ist es ein Vorschlag oder möchtest du ein Problem melden? Du kannst jederzeit „abbrechen“ sagen."
        m["Feedback and reports. Tap the \"Voice feedback\" button at the top to dictate your message."] = "Feedback und Meldungen. Tippe oben auf die Schaltfläche \"Sprach-Feedback\", um deine Nachricht zu diktieren."
        m["Intermediate stops only at stations in the STIBM area; outside the area only to change vehicle (e.g. Saronno, Busto Arsizio, Treviglio)."] = "Zwischenhalte nur an Bahnhöfen im STIBM-Gebiet; außerhalb des Gebiets nur zum Fahrzeugwechsel (z. B. Saronno, Busto Arsizio, Treviglio)."
        m["Giubiasco – Lugano – Mendrisio"] = "Giubiasco – Lugano – Mendrisio"
        m["Got it"] = "Verstanden"
        m["Tickets cannot be transferred after validation. Passes on an Io Viaggio or ATM card."] = "Fahrkarten sind nach der Entwertung nicht übertragbar. Abos auf einer Io-Viaggio- oder ATM-Karte."
        m["Your trains during the strike"] = "Deine Züge während des Streiks"
        m["The standard ticket is valid 75 minutes for 2 zones, +15 minutes per zone up to 4 zones, +30 minutes per zone from 5 zones up; in Milan (Mi1–Mi3) it is valid 90 minutes. Unlimited journeys within the validity time."] = "Das Standardticket gilt 75 Minuten für 2 Zonen, +15 Minuten pro Zone bis zu 4 Zonen, +30 Minuten pro Zone ab 5 Zonen; in Mailand (Mi1–Mi3) gilt es 90 Minuten. Unbegrenzte Fahrten innerhalb der Gültigkeitsdauer."
        m["The message is too short."] = "Die Nachricht ist zu kurz."
        m["Speech recognition is not available on this phone."] = "Spracherkennung ist auf diesem Handy nicht verfügbar."
        m["At the station and tools"] = "Am Bahnhof und Werkzeuge"
        m["Travel updates, guaranteed trains, tickets"] = "Reiseaktualisierungen, garantierte Züge, Fahrkarten"
        m["About the app"] = "Über die App"
        m["Full fare"] = "Voller Fahrpreis"
        m["Italy and Switzerland: websites, tickets, data"] = "Italien und Schweiz: Websites, Fahrkarten, Daten"
        m["The Lombardy regional fare is not valid across the border. The price adds the Lombardy section (Trenord distance bands) and the Ticino section (Arcobaleno zones): Trenord sells it in euros, Arcobaleno in francs."] = "Der Regionaltarif der Lombardei gilt nicht über die Grenze. Der Preis setzt sich aus dem lombardischen Abschnitt (Trenord-Entfernungsstufen) und dem Tessiner Abschnitt (Arcobaleno-Zonen) zusammen: Trenord verkauft ihn in Euro, Arcobaleno in Franken."
        m["Trenord and FerrovieNord lines"] = "Linien von Trenord und FerrovieNord"
        m["FerrovieNord network lines"] = "Linien des FerrovieNord-Netzes"
        m["Lines, Malpensa Express, STIBM area, notices"] = "Linien, Malpensa Express, STIBM-Gebiet, Mitteilungen"
        m["Locarno – Lugano – Chiasso – Milan"] = "Locarno – Lugano – Chiasso – Mailand"
        m["Malpensa Express: valid only within the city of Milan (not in the 21 towns of zone Mi3) and between Milan and Rescaldina (Mi1–Mi7), only on trains to/from Milano Centrale."] = "Malpensa Express: gültig nur innerhalb der Stadt Mailand (nicht in den 21 Gemeinden der Zone Mi3) und zwischen Mailand und Rescaldina (Mi1–Mi7), nur auf Zügen von/nach Milano Centrale."
        m["The name is missing."] = "Der Name fehlt."
        m["A valid email is missing."] = "Eine gültige E-Mail-Adresse fehlt."
        m["Half fare"] = "Halber Fahrpreis"
        m["Also show these options on the Home screen"] = "Diese Optionen auch auf dem Startbildschirm anzeigen"
        m["Hide"] = "Ausblenden"
        m["Hide fares"] = "Tarife ausblenden"
        m["During guaranteed hours (weekdays 6–9 and 18–21) regional trains run. Outside those hours check your operator's list of guaranteed trains."] = "In den garantierten Zeiten (werktags 6–9 und 18–21 Uhr) fahren Regionalzüge. Außerhalb dieser Zeiten prüfe die Liste der garantierten Züge deines Unternehmens."
        m["No strike announced in your region"] = "In deiner Region ist kein Streik angekündigt"
        m["No announced strike affects your route at your times"] = "Kein angekündigter Streik betrifft deine Strecke zu deinen Zeiten"
        m["No"] = "Nein"
        m["I didn't understand the email. Say it again slowly, saying at and dot."] = "Ich habe die E-Mail-Adresse nicht verstanden. Sag sie langsam noch einmal, mit „at“ und „Punkt“."
        m["I didn't hear you. Tap \"Voice feedback\" again to try again."] = "Ich habe dich nicht gehört. Tippe erneut auf \"Sprach-Feedback\", um es noch einmal zu versuchen."
        m["Note: the malpensaexpress.it passes page shows lower \"from\" prices (€25 weekly, €87 monthly, €840 yearly): here are the prices from the current Trenord fare table."] = "Hinweis: Die Seite malpensaexpress.it zu den Abos zeigt niedrigere „ab“-Preise (25 € Woche, 87 € Monat, 840 € Jahr): Hier stehen die Preise aus der aktuellen Trenord-Tariftabelle."
        m["Scheduled notifications, alarms, offline timetables"] = "Geplante Benachrichtigungen, Alarme, Offline-Fahrpläne"
        m["Travel update news"] = "Nachrichten zu Reiseaktualisierungen"
        m["What's new, fixes, service status, privacy"] = "Neuigkeiten, Korrekturen, Dienststatus, Datenschutz"
        m["Lost property"] = "Fundsachen"
        m["Spoken mode"] = "Sprachmodus"
        m["Spoken mode (blind users)"] = "Sprachmodus (für blinde Nutzer)"
        m["Spoken mode on."] = "Sprachmodus an."
        m["Time"] = "Zeit"
        m["Sort:"] = "Sortieren:"
        m["By operator"] = "Nach Unternehmen"
        m["For people who are blind or prefer to talk: the app asks the questions aloud and you answer by voice."] = "Für blinde Menschen oder alle, die lieber sprechen: Die App stellt die Fragen laut und du antwortest per Sprache."
        m["Trenord doesn't publish a price table for this route: the exact price in euros is in the Trenord online shop."] = "Trenord veröffentlicht für diese Strecke keine Preistabelle: Der genaue Preis in Euro steht im Trenord-Onlineshop."
        m["Ranks outside the station, radio taxis to call, apps"] = "Taxistände außerhalb des Bahnhofs, Funktaxis zum Anrufen, Apps"
        m["Taxi ranks, radio taxis to call, apps"] = "Taxistände, Funktaxis zum Anrufen, Apps"
        m["Best prices by day and time of day"] = "Beste Preise nach Tag und Tageszeit"
        m["Prices for 1 adult from LeFrecce (Trenitalia); they may change until purchase."] = "Preise für 1 Erwachsenen von LeFrecce (Trenitalia); sie können sich bis zum Kauf ändern."
        m["Price"] = "Preis"
        m["Arcobaleno price (2nd class, single ticket):"] = "Arcobaleno-Preis (2. Klasse, Einzelfahrkarte):"
        m["Trenord price (adult single ticket)"] = "Trenord-Preis (Einzelfahrkarte Erwachsene)"
        m["Price and booking on italotreno.com"] = "Preis und Buchung auf italotreno.com"
        m["Price on the Trenord website"] = "Preis auf der Trenord-Website"
        m["Sales points"] = "Verkaufsstellen"
        m["FerrovieNord punctuality"] = "Pünktlichkeit FerrovieNord"
        m["What's your email? For example: mario dot rossi at gmail dot com."] = "Wie lautet deine E-Mail-Adresse? Zum Beispiel: mario punkt rossi at gmail punkt com."
        m["RFI Sala Blu · 800 90 60 60"] = "RFI Sala Blu · 800 90 60 60"
        m["Children under 14 travel free with a paying adult; on their own they need the Under 14 card."] = "Kinder unter 14 fahren mit einem zahlenden Erwachsenen kostenlos; allein brauchen sie die Under-14-Karte."
        m["EU Regulation 2021/782"] = "EU-Verordnung 2021/782"
        m["Delays, cancellations, platforms, crowding and punctuality use distinguishable colours (orange and blue instead of red and green) and extra symbols. You can change it at any time from Home or Settings → Accessibility."] = "Verspätungen, Ausfälle, Gleise, Auslastung und Pünktlichkeit verwenden unterscheidbare Farben (Orange und Blau statt Rot und Grün) und zusätzliche Symbole. Du kannst das jederzeit auf dem Startbildschirm oder unter Einstellungen → Barrierefreiheit ändern."
        m["Problem report."] = "Problemmeldung."
        m["You are here"] = "Du bist hier"
        m["FerrovieNord website"] = "FerrovieNord-Website"
        m["Suggestion."] = "Vorschlag."
        m["Yes, blue-yellow"] = "Ja, Blau-Gelb"
        m["Yes, turn off"] = "Ja, ausschalten"
        m["Yes, red-green (the most common)"] = "Ja, Rot-Grün (am häufigsten)"
        m["TILO (Ticino–Lombardy)"] = "TILO (Tessin–Lombardei)"
    }

    private fun p3(m: HashMap<String, String>) {
        m["TILO and Switzerland"] = "TILO und die Schweiz"
        m["TILO · Services"] = "TILO · Services"
        m["Departures and arrivals board"] = "Abfahrts- und Ankunftstafel"
        m["Nearby taxis"] = "Taxis in der Nähe"
        m["Ticino–Lombardy, cross-border fares"] = "Tessin–Lombardei, grenzüberschreitende Tarife"
        m["Between two Swiss stations Arcobaleno (Ticino) or SBB fares apply: Trenord's distance bands don't apply."] = "Zwischen zwei Schweizer Bahnhöfen gelten die Tarife von Arcobaleno (Tessin) oder der SBB: Die Entfernungsstufen von Trenord gelten nicht."
        m["Between places outside Milan: the zones between them; if you cross Milan you always also need Mi1. Minimum 2 zones."] = "Zwischen Orten außerhalb von Mailand: die Zonen dazwischen; wenn du durch Mailand fährst, brauchst du immer auch Mi1. Mindestens 2 Zonen."
        m["Real-time trains, contacts"] = "Echtzeit-Züge, Kontakte"
        m["Trenord · 800 210 955"] = "Trenord · 800 210 955"
        m["All railway operators"] = "Alle Bahnunternehmen"
        m["All accessibility options"] = "Alle Barrierefreiheit-Optionen"
        m["All fares and classes"] = "Alle Tarife und Klassen"
        m["Checked on the Trenord website on"] = "Auf der Trenord-Website geprüft am"
        m["Travelling with pets"] = "Reisen mit Haustieren"
        m["Italy ⇄ Switzerland trip: cross-border ticket"] = "Reise Italien ⇄ Schweiz: grenzüberschreitende Fahrkarte"
        m["Trip within Switzerland"] = "Reise innerhalb der Schweiz"
        m["Do you want to turn on spoken mode? The phone's voice will tell you the platform, departure, delays and the stop where to get off."] = "Möchtest du den Sprachmodus einschalten? Die Stimme des Handys sagt dir Gleis, Abfahrt, Verspätungen und die Haltestelle zum Aussteigen."
        m["Do you want to turn off spoken mode?"] = "Möchtest du den Sprachmodus ausschalten?"
        m["application/json"] = "application/json"
        m["contactless"] = "kontaktlos"
        m["from"] = "ab"
        m["data saved on the phone"] = "auf dem Handy gespeicherte Daten"
        m["sold out"] = "ausverkauft"
        m["in testing"] = "in der Testphase"
        m["half price"] = "halber Preis"
        m["last"] = "letzter"
        m["Departures from Cadorna at minutes 27 and 57 (from 4.27 to 00.20), 37 minutes. Stops at Milano Bovisa, Saronno, Busto Arsizio Nord. FIRST class only."] = "Abfahrten ab Cadorna zu den Minuten 27 und 57 (von 4.27 bis 00.20 Uhr), 37 Minuten. Halte in Milano Bovisa, Saronno, Busto Arsizio Nord. Nur 1. Klasse."
        m["Departures from Centrale at minutes 25 and 55 (from 5.25 to 23.25), 51 minutes. Stops at Porta Garibaldi, Bovisa, Saronno, Busto Arsizio; the :25 trains also at Rescaldina, Castellanza and Ferno-Lonate Pozzolo. First and second class, but second class is only for trips that do NOT start or end at the airport."] = "Abfahrten ab Centrale zu den Minuten 25 und 55 (von 5.25 bis 23.25 Uhr), 51 Minuten. Halte in Porta Garibaldi, Bovisa, Saronno, Busto Arsizio; die Züge um :25 halten auch in Rescaldina, Castellanza und Ferno-Lonate Pozzolo. 1. und 2. Klasse, aber die 2. Klasse nur für Fahrten, die NICHT am Flughafen beginnen oder enden."
        m["To or from Malpensa Terminal 1 and 2 you always need an airport-fare ticket: regional passes, Io Viaggio Ovunque (Lombardy or Varese province) and STIBM are valid on Malpensa Express trains only between the other stations."] = "Von und zum Flughafen Malpensa Terminal 1 und 2 brauchst du immer eine Fahrkarte zum Flughafentarif: Regionalabos, Io Viaggio Ovunque (Lombardei oder Provinz Varese) und STIBM gelten in den Malpensa-Express-Zügen nur zwischen den übrigen Bahnhöfen."
        m["The Malpensa ticket is valid for both terminals."] = "Das Malpensa-Ticket gilt für beide Terminals."
        m["Single ticket: valid on the chosen day until the end of service, no validation needed; the date can be changed up to 3 times until the day before."] = "Einzelfahrkarte: gültig am gewählten Tag bis Betriebsschluss, keine Entwertung nötig; das Datum kann bis zum Vortag bis zu 3-mal geändert werden."
        m["Return ticket: same-day at ticket offices and machines; within 30 days only online and in the app (Milan ⇄ Malpensa, €25 instead of €30), only the return date can be changed."] = "Rückfahrkarte: am selben Tag an Schaltern und Automaten; innerhalb von 30 Tagen nur online und in der App (Mailand ⇄ Malpensa, 25 € statt 30 €), nur das Rückfahrdatum kann geändert werden."
        m["Malpensa Family €36: 2 adults and 2 young people aged 4 to 17, between a Milan station and the airport. Children under 4 travel free."] = "Malpensa Family 36 €: 2 Erwachsene und 2 Jugendliche von 4 bis 17 Jahren, zwischen einem Mailänder Bahnhof und dem Flughafen. Kinder unter 4 Jahren fahren kostenlos."
        m["Young people: reduced fare from 4 to 13 years."] = "Jugendliche: ermäßigter Tarif von 4 bis 13 Jahren."
        m["The Malpensa Express ticket to/from Milan is also valid on all trains between stations in the Milan area."] = "Das Malpensa-Express-Ticket von/nach Mailand gilt auch in allen Zügen zwischen Bahnhöfen im Mailänder Raum."
        m["On urban sections (Cadorna–Domodossola–Bovisa and Centrale–Porta Garibaldi–Bovisa) urban Trenord and STIBM tickets are also valid. STIBM is valid only in 2nd class, and on trains to/from Milano Centrale also as far as Rescaldina (Mi1–Mi7)."] = "Auf den städtischen Abschnitten (Cadorna–Domodossola–Bovisa und Centrale–Porta Garibaldi–Bovisa) gelten auch städtische Trenord- und STIBM-Tickets. STIBM gilt nur in der 2. Klasse und in Zügen von/nach Milano Centrale auch bis Rescaldina (Mi1–Mi7)."
        m["Malpensa Express passes: weekly (on sale from the Thursday before, activate within 5 days), monthly (from the 22nd of the previous month, within 15 days), yearly (within 30 days); on an Io Viaggio card or Phone Pass."] = "Malpensa-Express-Abos: wöchentlich (ab dem Donnerstag davor im Verkauf, innerhalb von 5 Tagen aktivieren), monatlich (ab dem 22. des Vormonats, innerhalb von 15 Tagen), jährlich (innerhalb von 30 Tagen); auf einer Io-Viaggio-Karte oder als Phone Pass."
        m["Bikes and dogs travel free as luggage with a boarding pass; without a boarding pass dogs pay the pet supplement."] = "Fahrräder und Hunde reisen mit einer Bordkarte kostenlos als Gepäck; ohne Bordkarte zahlen Hunde den Tierzuschlag."
        m["Transfer between Terminal 1 and Terminal 2: €2 adults, €1 young people."] = "Transfer zwischen Terminal 1 und Terminal 2: 2 € Erwachsene, 1 € Jugendliche."
        m["via Terminal 2"] = "über Terminal 2"
        m["via Busto Arsizio"] = "über Busto Arsizio"
        m["Share Binario: coming soon"] = "Binario teilen: demnächst"
        m["Network, lifts out of service, accessibility, defibrillators"] = "Netz, Aufzüge außer Betrieb, Barrierefreiheit, Defibrillatoren"
        m["FERROVIENORD network info"] = "FERROVIENORD-Netzinfos"
        m["Lifts and escalators out of service, accessibility, assistance, AEDs, documents"] = "Aufzüge und Rolltreppen außer Betrieb, Barrierefreiheit, Hilfe, AEDs, Dokumente"
        m["Replacement buses"] = "Ersatzbusse"
        m["Stops and times of buses replacing trains · Trenord, Trenitalia, TILO"] = "Haltestellen und Zeiten der Ersatzbusse · Trenord, Trenitalia, TILO"
        m["Defibrillators (AED)"] = "Defibrillatoren (AED)"
        m["Where they are, near you or the station · call 112"] = "Wo sie sind, in deiner Nähe oder am Bahnhof · Notruf 112"
        m["Share Binario, not available: coming soon"] = "Binario teilen, nicht verfügbar: demnächst"
        m["Coming soon"] = "Demnächst"
        m["solutions · saved on "] = "Verbindungen · gespeichert am "
        m["Reminder at "] = "Erinnerung um "
        m["arrival"] = "Ankunft"
        m["departure"] = "Abfahrt"
        m["Ticket offices, machines, resellers · nearby or by province"] = "Schalter, Automaten, Verkäufer · in der Nähe oder nach Provinz"
        m["Location not available: turn on GPS."] = "Standort nicht verfügbar: GPS einschalten."
        m["Looking for taxi ranks…"] = "Taxistände werden gesucht…"
        m["OpenStreetMap servers are not responding. Use the numbers below or Google Maps."] = "Die OpenStreetMap-Server antworten nicht. Nutze die Nummern unten oder Google Maps."
        m["Call a taxi"] = "Taxi rufen"
        m["I don't have a verified radio taxi number for this city: use an app or search for the number."] = "Für diese Stadt habe ich keine überprüfte Funktaxi-Nummer: Nutze eine App oder suche die Nummer."
        m["Search for the taxi number"] = "Taxi-Nummer suchen"
        m["Italian radio taxi app: book and pay in the app"] = "Italienische Funktaxi-App: in der App buchen und bezahlen"
        m["Taxis in many Italian cities"] = "Taxis in vielen italienischen Städten"
        m["Uber Taxi in cities where available"] = "Uber Taxi in Städten, in denen verfügbar"
        m["Where to get a taxi"] = "Wo du ein Taxi bekommst"
        m["No taxi rank mapped within 1.5 km. The rank is usually in front of the station's main exit."] = "Im Umkreis von 1,5 km ist kein Taxistand erfasst. Der Stand befindet sich meist vor dem Hauptausgang des Bahnhofs."
        m["Local taxi companies"] = "Örtliche Taxiunternehmen"
        m["Taxi ranks"] = "Taxistände"
        m["Ranks and phones from OpenStreetMap (volunteers), radio taxis from city services: check on site. 112 is for emergencies only."] = "Stände und Telefonnummern von OpenStreetMap (Freiwillige), Funktaxis aus städtischen Diensten: vor Ort prüfen. 112 ist nur für Notfälle."
        m["Tap to open the location"] = "Zum Öffnen des Standorts tippen"
        m["Tap to call"] = "Zum Anrufen tippen"
        m["Best prices"] = "Beste Preise"
        m["Choose origin and destination first."] = "Wähle zuerst Start und Ziel."
        m["All trains"] = "Alle Züge"
        m["Lowest price for 1 adult among trains in that time band (LeFrecce · Trenitalia). Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "Niedrigster Preis für 1 Erwachsenen unter den Zügen in diesem Zeitfenster (LeFrecce · Trenitalia). Tippe auf eine Zelle, um die Verbindungen zu sehen. Sparpreise ändern sich je nach Verfügbarkeit: Maßgeblich ist der Preis an der Kasse."
        m["In short"] = "Kurz gesagt"
        m["Small animals (cats, small dogs, rabbits, birds) in a carrier: almost always free."] = "Kleintiere (Katzen, kleine Hunde, Kaninchen, Vögel) in einer Transportbox: fast immer kostenlos."
        m["Larger dogs: leash and muzzle; a dog ticket is often needed."] = "Größere Hunde: Leine und Maulkorb; oft wird eine Hundefahrkarte benötigt."
        m["Guide and assistance dogs: always free, on all trains and classes, with no time limits."] = "Blinden- und Assistenzhunde: immer kostenlos, in allen Zügen und Klassen, ohne zeitliche Beschränkung."
        m["Always carry the dog-registry certificate and health booklet (from abroad: EU pet passport)."] = "Führe immer die Hunde-Registrierung und das Gesundheitsheft mit (aus dem Ausland: EU-Heimtierausweis)."
        m["The animal must not take up seats or disturb others: staff may ask you to leave if it causes danger or disturbance."] = "Das Tier darf keine Sitzplätze belegen oder andere stören: Das Personal kann dich zum Aussteigen auffordern, wenn es Gefahr oder Störung verursacht."
        m["Small animals in a carrier (max 70×30×50 cm): free within Lombardy."] = "Kleintiere in einer Transportbox (max. 70×30×50 cm): kostenlos innerhalb der Lombardei."
        m["Dogs of any size: muzzle, leash and dog-registry certificate; free within Lombardy."] = "Hunde jeder Größe: Maulkorb, Leine und Hunde-Registrierung; kostenlos innerhalb der Lombardei."
        m["Not allowed on weekdays (Monday–Friday) 7:00–9:30 and 17:30–19:30, small animals included. Guide dogs can always travel."] = "Nicht erlaubt werktags (Montag–Freitag) 7:00–9:30 und 17:30–19:30 Uhr, auch Kleintiere nicht. Blindenhunde dürfen immer mitfahren."
        m["Beyond Lombardy and to Switzerland an animal supplement is needed, under the rules of the operating company."] = "Außerhalb der Lombardei und in die Schweiz ist ein Tierzuschlag nötig, nach den Regeln des Betreibers."
        m["Malpensa Express: dogs travel free as luggage with a boarding pass; without one they pay the animal supplement."] = "Malpensa Express: Hunde reisen mit einer Bordkarte kostenlos als Gepäck; ohne Bordkarte zahlen sie den Tierzuschlag."
        m["Small animals in a carrier (max 70×30×50 cm): always free, on all trains."] = "Kleintiere in einer Transportbox (max. 70×30×50 cm): immer kostenlos, in allen Zügen."
        m["Regional trains: larger dogs travel with a 2nd-class ticket at 50% off, with leash and muzzle."] = "Regionalzüge: Größere Hunde reisen mit einer 2.-Klasse-Fahrkarte zum halben Preis, mit Leine und Maulkorb."
        m["Frecce and Intercity: a dog outside the carrier must be added when buying (\"Travel with your dog\"); the price is the one shown at checkout, with promotions in some periods (e.g. dogs free in summer)."] = "Frecce und Intercity: Ein Hund außerhalb der Transportbox muss beim Kauf hinzugefügt werden (\"Reise mit deinem Hund\"); der Preis ist der an der Kasse angezeigte, zeitweise mit Aktionen (z. B. Hunde im Sommer kostenlos)."
        m["Documents: dog-registry certificate and health booklet; staff may ask for them. Assistance dogs are also allowed in bar/restaurant cars and replacement buses."] = "Dokumente: Hunde-Registrierung und Gesundheitsheft; das Personal kann sie verlangen. Assistenzhunde sind auch in Bar-/Speisewagen und Ersatzbussen erlaubt."
        m["Small animals (up to about 5 kg) in a carrier: free."] = "Kleintiere (bis etwa 5 kg) in einer Transportbox: kostenlos."
        m["Larger dogs: allowed in Smart and Prima by booking the \"Dog\" service (online or Pronto Italo 06 07 08, up to 2 hours before); always on a leash, muzzle when boarding/leaving or on request. Price shown at checkout."] = "Größere Hunde: in Smart und Prima erlaubt, wenn der Service „Hund“ gebucht wird (online oder Pronto Italo 06 07 08, bis zu 2 Stunden vorher); immer an der Leine, Maulkorb beim Ein-/Aussteigen oder auf Verlangen. Preis an der Kasse angezeigt."
        m["Guide dogs: free, any size."] = "Blindenhunde: kostenlos, jede Größe."
        m["Switzerland · SBB and TILO"] = "Schweiz · SBB und TILO"
        m["Dogs up to 30 cm at the withers and other small animals in a bag or carrier: free, as hand luggage."] = "Hunde bis 30 cm Schulterhöhe und andere Kleintiere in einer Tasche oder Transportbox: kostenlos, als Handgepäck."
        m["Larger dogs (or outside a carrier): half the 2nd-class fare, or the dog day pass CHF 25 (also valid on buses, trams and boats); dog pass CHF 60 a month or CHF 350 a year."] = "Größere Hunde (oder außerhalb einer Transportbox): halber Preis der 2. Klasse oder die Hunde-Tageskarte CHF 25 (gilt auch in Bussen, Trams und Schiffen); Hundeabo CHF 60 pro Monat oder CHF 350 pro Jahr."
        m["The dog stays under your seat without blocking the aisle. Not allowed in restaurant cars (except guide and assistance dogs)."] = "Der Hund bleibt unter deinem Sitz, ohne den Gang zu blockieren. In Speisewagen nicht erlaubt (außer Blinden- und Assistenzhunde)."
        m["Rules from the operators' official pages (October 2026). Prices and promotions change: before travelling check the operator's page with the button above."] = "Regeln von den offiziellen Seiten der Unternehmen (Oktober 2026). Preise und Aktionen ändern sich: Prüfe vor der Reise die Seite des Unternehmens mit der Schaltfläche oben."
        m["Official page "] = "Offizielle Seite "
        m["Enter town or station"] = "Ort oder Bahnhof eingeben"
        m["Clear"] = "Löschen"
        m["Near me"] = "In meiner Nähe"
        m["Show map"] = "Karte anzeigen"
        m["Show list"] = "Liste anzeigen"
        m["towards "] = "Richtung "
        m["straight ahead"] = "geradeaus"
        m["to your right"] = "rechts von dir"
        m["behind you"] = "hinter dir"
        m["to your left"] = "links von dir"
        m["ahead on the right"] = "vorne rechts"
        m["ahead on the left"] = "vorne links"
        m["behind on the right"] = "hinten rechts"
        m["behind on the left"] = "hinten links"
        m["metres"] = "Meter"
        m["Travelling, near the station of "] = "Unterwegs, in der Nähe des Bahnhofs "
        m["You are at "] = "Du bist bei "
        m["Warning, out of service: "] = "Achtung, außer Betrieb: "
        m["You have arrived: "] = "Du bist angekommen: "
        m["Explore"] = "Erkunden"
        m["Categories"] = "Kategorien"
        m["Guiding you to: "] = "Ich führe dich zu: "
        m["Walking navigation"] = "Fußgängernavigation"
        m["Stop guiding"] = "Führung beenden"
        m["Location permission is needed to explore."] = "Zum Erkunden wird die Standortberechtigung benötigt."
        m["Finding your position… Turn on GPS."] = "Dein Standort wird ermittelt… Schalte das GPS ein."
        m["Guiding you to "] = "Ich führe dich zu "
        m["Exploring. I'll tell you about nearby stations, platforms, lifts, stairs and services."] = "Erkunden. Ich sage dir, was es an Bahnhöfen, Gleisen, Aufzügen, Treppen und Services in der Nähe gibt."
        m["Exploring stopped."] = "Erkunden beendet."
        m["Stop exploring"] = "Erkunden beenden"
        m["Start spoken exploration"] = "Gesprochene Erkundung starten"
        m["Nearest station: "] = "Nächster Bahnhof: "
        m["You are moving at "] = "Du bewegst dich mit "
        m["No useful places found nearby."] = "Keine nützlichen Orte in der Nähe gefunden."
        m["Where am I? Tell me"] = "Wo bin ich? Sag es mir"
        m["Last announcement"] = "Letzte Ansage"
        m["GPS accuracy: "] = "GPS-Genauigkeit: "
        m[" · no compass: directions by compass points"] = " · kein Kompass: Richtungen nach Himmelsrichtungen"
        m["Hold the phone in front of you: \"12 o'clock\" is ahead, \"3\" right, \"9\" left. In stations GPS can be off by a few metres: ask staff or the Sale Blu for help (More → Disability assistance)."] = "Halte das Handy vor dich: „12 Uhr“ ist vorne, „3“ rechts, „9“ links. In Bahnhöfen kann das GPS um einige Meter abweichen: Bitte das Personal oder die Sale Blu um Hilfe (Mehr → Hilfe für Menschen mit Behinderung)."
        m["None of these mapped nearby (300 m)."] = "Nichts davon in der Nähe erfasst (300 m)."
        m["Guide me"] = "Führe mich"
        m["Board"] = "Einsteigen"
        m["No results for "] = "Keine Ergebnisse für "
        m["Found "] = "Gefunden: "
        m[" results. First: "] = " Ergebnisse. Erstes: "
        m["Place, address, station…"] = "Ort, Adresse, Bahnhof…"
        m["Voice search"] = "Sprachsuche"
        m["Save this spot"] = "Diesen Ort speichern"
        m["E.g. \"Platform 3, front of the train\", \"Lift by the café\", \"Taxi exit\": then \"Guide me\" brings you back. Favourite stations and trains are in the Stations and Trains tabs."] = "Z. B. „Gleis 3, Zugspitze“, „Aufzug beim Café“, „Taxiausgang“: Mit „Führe mich“ findest du dann zurück. Lieblingsbahnhöfe und -züge findest du in den Reitern Bahnhöfe und Züge."
        m["No saved places."] = "Keine gespeicherten Orte."
        m["Name"] = "Name"
        m["Current position, accuracy ±"] = "Aktuelle Position, Genauigkeit ±"
        m["Saved spot"] = "Gespeicherter Ort"
        m["Saved: "] = "Gespeichert: "
        m["No solutions found for the chosen time."] = "Keine Verbindungen für die gewählte Zeit gefunden."
        m["Cannot reach the server. Check your connection."] = "Server nicht erreichbar. Prüfe deine Verbindung."
        m["Departing from "] = "Abfahrt von "
        m["FASTEST"] = "SCHNELLSTE"
        m[" · first train +"] = " · erster Zug +"
        m["Not reachable now: "] = "Zurzeit nicht erreichbar: "
        m["Train "] = "Zug "
        m["I'll remind you at "] = "Ich erinnere dich um "
        m["Where to catch the bus when trains don't run · Trenord, Trenitalia, TILO"] = "Wo du den Bus nimmst, wenn keine Züge fahren · Trenord, Trenitalia, TILO"
        m["The nearest to you · call 112"] = "Der nächste bei dir · Notruf 112"
        m["FERROVIENORD · source: ferrovienord.it (station accessibility notices). Assistance: 800 210 955"] = "FERROVIENORD · Quelle: ferrovienord.it (Meldungen zur Bahnhofsbarrierefreiheit). Hilfe: 800 210 955"
        m["Show later trains (+6 hours)"] = "Spätere Züge anzeigen (+6 Stunden)"
        m["Platform "] = "Gleis "
        m["What to do right away"] = "Was sofort zu tun ist"
        m["If you are still on the train or in the station, tell the conductor or staff straight away: it's the fastest way to find it."] = "Wenn du noch im Zug oder im Bahnhof bist, sag dem Zugbegleiter oder dem Personal sofort Bescheid: So geht es am schnellsten."
        m["Note the train number, day, time, coach and seat, and describe the item well (brand, colour, contents)."] = "Notiere Zugnummer, Tag, Uhrzeit, Wagen und Sitzplatz und beschreibe den Gegenstand genau (Marke, Farbe, Inhalt)."
        m["Contact the train's operator (below): each has its own lost property service."] = "Kontaktiere das Unternehmen, das den Zug betreibt (unten): Jedes hat einen eigenen Fundservice."
        m["Documents, cards or phone: block your cards and, for theft or documents, report it to the Railway Police (Polfer) or Carabinieri."] = "Dokumente, Karten oder Handy: Sperre deine Karten und melde Diebstahl oder Dokumente der Bahnpolizei (Polfer) oder den Carabinieri."
        m["After a few days unclaimed items go to the town's lost property office: ask there."] = "Nach einigen Tagen kommen nicht abgeholte Gegenstände zum Fundbüro der Stadt: Frag dort nach."
        m["The train you are following: "] = "Der Zug, dem du folgst: "
        m["Trenord, Malpensa Express and FerrovieNord stations"] = "Trenord, Malpensa Express und FerrovieNord-Bahnhöfe"
        m["Trenord Contact Center: items lost on trains or platforms"] = "Trenord Contact Center: in Zügen oder auf Bahnsteigen verlorene Gegenstände"
        m["Found items are kept at the My Link Points in Milano Cadorna and Milano Porta Garibaldi for a few days (up to 6), then go to the City of Milan lost property office."] = "Gefundene Gegenstände werden einige Tage (bis zu 6) in den My Link Points in Milano Cadorna und Milano Porta Garibaldi aufbewahrt und kommen dann zum Fundbüro der Stadt Mailand."
        m["City of Milan · Lost property"] = "Stadt Mailand · Fundbüro"
        m["Via Friuli 30, Milan · 02 884 53900"] = "Via Friuli 30, Mailand · 02 884 53900"
        m["Trenord lost property page"] = "Trenord-Fundseite"
        m["Frecce: go to the Frecciadesk or customer service in the station as soon as you notice, staff can have your seat checked. Regional and Intercity: found items are usually handed to the lost property office of the town where the train terminates."] = "Frecce: Wende dich sofort nach dem Bemerken an das Frecciadesk oder den Kundenservice im Bahnhof; das Personal kann deinen Platz überprüfen lassen. Regional und Intercity: Gefundene Gegenstände werden meist beim Fundbüro des Endbahnhofs abgegeben."
        m["Lost items search service"] = "Fundsachen-Suchdienst"
        m["Customer service offices"] = "Kundenservice-Büros"
        m["Pronto Italo, daily 7–23: report the item with train number, coach and seat"] = "Pronto Italo, täglich 7–23 Uhr: Verlust mit Zugnummer, Wagen und Sitzplatz melden"
        m["Report the loss online"] = "Verlust online melden"
        m["SBB Contact Center, 24 hours"] = "SBB Contact Center, 24 Stunden"
        m["On collection you pay CHF 20 (CHF 10 with a GA travelcard); electronics and bulky items CHF 25 (CHF 15). On TILO trains between Italy and Switzerland report to both SBB and Trenord."] = "Bei der Abholung zahlst du CHF 20 (CHF 10 mit GA); Elektronik und sperrige Gegenstände CHF 25 (CHF 15). In TILO-Zügen zwischen Italien und der Schweiz meldest du den Verlust sowohl bei der SBB als auch bei Trenord."
        m["Information from the official Trenord, Trenitalia and SBB pages (October 2026): times and procedures may change."] = "Informationen von den offiziellen Seiten von Trenord, Trenitalia und SBB (Oktober 2026): Zeiten und Abläufe können sich ändern."
        m["Location not available: search a town or station."] = "Standort nicht verfügbar: Suche einen Ort oder Bahnhof."
        m["Search a town or station above."] = "Suche oben einen Ort oder Bahnhof."
        m["Looking for defibrillators…"] = "Defibrillatoren werden gesucht…"
        m["Looking for defibrillators within "] = "Defibrillatoren werden gesucht im Umkreis von "
        m["Station "] = "Bahnhof "
        m["Station AED: usually on the outside wall, in a marked case"] = "Bahnhofs-AED: meist an der Außenwand, in einem gekennzeichneten Kasten"
        m["ferrovienord.it · AEDs in all FERROVIENORD stations"] = "ferrovienord.it · AEDs in allen FERROVIENORD-Bahnhöfen"
        m["Defibrillator"] = "Defibrillator"
        m["Emilia-Romagna regional AED register (open data)"] = "Regionales AED-Register der Emilia-Romagna (Open Data)"
        m["OpenStreetMap (volunteers): check on site"] = "OpenStreetMap (Freiwillige): vor Ort prüfen"
        m["OpenStreetMap servers are not responding: use the official map below or retry."] = "Die OpenStreetMap-Server antworten nicht: Nutze die offizielle Karte unten oder versuche es erneut."
        m["Defibrillators"] = "Defibrillatoren"
        m["Emergency: call "] = "Notfall: Ruf an "
        m["The operator guides you through CPR and tells you where the nearest AED is. AEDs can be used on children too and give voice instructions."] = "Die Leitstelle führt dich durch die Wiederbelebung und sagt dir, wo der nächste AED ist. AEDs können auch bei Kindern eingesetzt werden und geben Sprachanweisungen."
        m["Public access"] = "Öffentlich zugänglich"
        m["Always available"] = "Immer verfügbar"
        m["Outdoors"] = "Im Freien"
        m["Nearby defibrillators"] = "Defibrillatoren in der Nähe"
        m["No defibrillator in the open lists here. Call 112: the dispatch centre knows all registered AEDs and guides you."] = "Kein Defibrillator in den hier verwendeten offenen Listen. Ruf 112 an: Die Leitstelle kennt alle registrierten AEDs und leitet dich an."
        m["Where to get help nearby"] = "Wo du in der Nähe Hilfe bekommst"
        m["Emergency departments and pharmacies: many pharmacies have an AED, but it isn't guaranteed."] = "Notaufnahmen und Apotheken: Viele Apotheken haben einen AED, aber es ist nicht garantiert."
        m["Official maps and sources"] = "Offizielle Karten und Quellen"
        m["AREU Lombardy · AED map (official)"] = "AREU Lombardei · AED-Karte (offiziell)"
        m["Ticino Cuore · AEDs in Ticino"] = "Ticino Cuore · AEDs im Tessin"
        m["FERROVIENORD · station AEDs"] = "FERROVIENORD · Bahnhofs-AEDs"
        m["FERROVIENORD: 125 AEDs installed in 2022–2023 in all its stations, where possible on the outside wall so they can be reached at night, in alarmed cases linked to 112/118 dispatch. Other AEDs come from OpenStreetMap (volunteers): check on site. Trenitalia/RFI, Italo and SBB don't publish a list of station AEDs: ask staff or call 112 (144 in Switzerland)."] = "FERROVIENORD: 125 AEDs, 2022–2023 in allen Bahnhöfen installiert, wenn möglich an der Außenwand, damit sie nachts erreichbar sind, in alarmgesicherten Kästen mit Anbindung an die Leitstelle 112/118. Weitere AEDs stammen von OpenStreetMap (Freiwillige): vor Ort prüfen. Trenitalia/RFI, Italo und SBB veröffentlichen keine Liste der Bahnhofs-AEDs: Frag das Personal oder ruf 112 an (144 in der Schweiz)."
        m["Tap again for directions"] = "Erneut tippen für die Wegbeschreibung"
        m["Searched place"] = "Gesuchter Ort"
        m["Hospital · ask for help here"] = "Krankenhaus · hier um Hilfe bitten"
        m["Pharmacy · ask if they have an AED"] = "Apotheke · fragen, ob sie einen AED haben"
        m["Operator not stated"] = "Betreiber nicht angegeben"
        m["Available 24/7"] = "Rund um die Uhr verfügbar"
        m["Restricted access"] = "Eingeschränkter Zugang"
        m["At or next to a station"] = "Am oder neben einem Bahnhof"
        m["Source: "] = "Quelle: "
        m["Get directions"] = "Route anzeigen"
        m["View on MapComplete"] = "In MapComplete ansehen"
        m["Nearest defibrillator"] = "Nächster Defibrillator"
        m["List and map of AEDs · tap to see them"] = "Liste und Karte der AEDs · zum Ansehen tippen"
        m["Complete official list"] = "Vollständige offizielle Liste"
        m["⏳ Waiting for official AREU data: Binario has asked to use Lombardy's official defibrillator register. Until permission arrives the list below may be incomplete: open the official AREU map to see them all."] = "⏳ Warten auf offizielle AREU-Daten: Binario hat die Nutzung des offiziellen Defibrillatorenregisters der Lombardei beantragt. Bis die Erlaubnis eintrifft, kann die Liste unten unvollständig sein: Öffne die offizielle AREU-Karte, um alle zu sehen."
        m["Below are the AEDs from open lists (OpenStreetMap, FERROVIENORD, Emilia-Romagna register)."] = "Unten stehen die AEDs aus offenen Listen (OpenStreetMap, FERROVIENORD, Register der Emilia-Romagna)."
        m["Official AREU map"] = "Offizielle AREU-Karte"
        m["Ticino Cuore map"] = "Ticino-Cuore-Karte"
        m["Search Google Maps"] = "In Google Maps suchen"
        m["Station coordinates not available: search a town or station."] = "Bahnhofskoordinaten nicht verfügbar: Suche einen Ort oder Bahnhof."
        m["Location not available: turn on GPS or search a town or station."] = "Standort nicht verfügbar: GPS einschalten oder einen Ort oder Bahnhof suchen."
        m["Location permission needed, or search a town or station."] = "Standortberechtigung erforderlich, oder suche einen Ort oder Bahnhof."
        m["Looking for public toilets within"] = "Öffentliche Toiletten werden gesucht im Umkreis von"
        m["Place not found: try the town or station name."] = "Ort nicht gefunden: Versuche es mit dem Namen des Ortes oder Bahnhofs."
        m["Accessible"] = "Barrierefrei"
        m["Baby changing"] = "Wickelraum"
        m["Open to all"] = "Für alle geöffnet"
        m["near"] = "bei"
        m["No public toilets mapped here with these filters."] = "Mit diesen Filtern sind hier keine öffentlichen Toiletten erfasst."
        m["Data © OpenStreetMap, the same as the MapComplete \"Public toilets\" map ("] = "Daten © OpenStreetMap, dieselben wie auf der MapComplete-Karte „Öffentliche Toiletten“ ("
        m["Prices, hours and accessibility are entered by volunteers: check on site. If something is wrong you can fix it via \"View on MapComplete\"."] = "Preise, Öffnungszeiten und Barrierefreiheit werden von Freiwilligen eingetragen: vor Ort prüfen. Ist etwas falsch, kannst du es über „In MapComplete ansehen“ korrigieren."
        m["Public toilet"] = "Öffentliche Toilette"
        m["♿ Wheelchair accessible"] = "♿ Rollstuhlgerecht"
        m["♿ Partly accessible"] = "♿ Teilweise barrierefrei"
        m["Not wheelchair accessible"] = "Nicht rollstuhlgerecht"
        m["🚼 Baby changing table"] = "🚼 Wickeltisch"
        m["Unisex"] = "Unisex"
        m["Men and women"] = "Herren und Damen"
        m["Men only"] = "Nur Herren"
        m["Women only"] = "Nur Damen"
        m["Seated and urinals"] = "Sitztoiletten und Urinale"
        m["Urinals only"] = "Nur Urinale"
        m["Squat toilet"] = "Hocktoilette"
        m["Seated"] = "Sitztoilette"
        m["toilet paper"] = "Toilettenpapier"
        m["hand washing"] = "Händewaschen"
        m["With "] = "Mit "
        m["Customers only"] = "Nur für Kunden"
        m["Not open to the public"] = "Nicht öffentlich zugänglich"
        m["Level"] = "Ebene"
        m["Operated by"] = "Betrieben von"
        m["Calculation failed"] = "Berechnung fehlgeschlagen"
        m["Edit"] = "Bearbeiten"
        m["Every day (round trip)"] = "Jeden Tag (Hin- und Rückfahrt)"
        m["of CO₂ saved"] = "CO₂ eingespart"
        m["saved"] = "eingespart"
        m["extra cost"] = "Mehrkosten"
        m["Travel time (one way)"] = "Fahrzeit (einfach)"
        m["avg delay"] = "Ø Verspätung"
        m["Car"] = "Auto"
        m["free flow"] = "freier Verkehr"
        m["rush hour"] = "Hauptverkehrszeit"
        m["Daily breakdown (round trip)"] = "Tägliche Aufschlüsselung (Hin- und Rückfahrt)"
        m["yours"] = "deine"
        m["Road distance"] = "Straßenentfernung"
        m["of which tolled"] = "davon mautpflichtig"
        m["Consumption"] = "Verbrauch"
        m["Fuel"] = "Kraftstoff"
        m["Motorway tolls"] = "Autobahnmaut"
        m[" (estimate)"] = " (Schätzung)"
        m["Parking"] = "Parken"
        m["Car total"] = "Auto gesamt"
        m["Train (daily share of pass)"] = "Zug (Tagesanteil des Abos)"
        m["Tap an item with ✎ to enter your own value: everything is recalculated at once and saved."] = "Tippe auf einen Eintrag mit ✎, um einen eigenen Wert einzugeben: Alles wird sofort neu berechnet und gespeichert."
        m["Car CO₂"] = "Auto-CO₂"
        m["Train CO₂"] = "Zug-CO₂"
        m["CO₂ avoided"] = "Vermiedenes CO₂"
        m["Road distance (one way)"] = "Straßenentfernung (einfach)"
        m["Tolls per day (round trip)"] = "Maut pro Tag (Hin- und Rückfahrt)"
        m["Fuel price"] = "Kraftstoffpreis"
        m["Parking per day"] = "Parken pro Tag"
        m["Train pass per month"] = "Zugabo pro Monat"
        m["Car consumption"] = "Autoverbrauch"
        m["Back to the app's estimate"] = "Zurück zur Schätzung der App"
        m["Save and recalculate"] = "Speichern und neu berechnen"
        m["Trip and delay log"] = "Reise- und Verspätungsprotokoll"
    }

    private fun p4(m: HashMap<String, String>) {
        m[" · avg delay "] = " · Ø Verspätung "
        m[" · max "] = " · max. "
        m["Remove today"] = "Heute entfernen"
        m["out "] = "Hin "
        m["  back "] = "  zurück "
        m["On travel days after 9 pm the app automatically logs the delays of your usual trains."] = "An Reisetagen protokolliert die App nach 21 Uhr automatisch die Verspätungen deiner üblichen Züge."
        m["Your commute"] = "Dein Arbeitsweg"
        m["choose"] = "wählen"
        m["To: "] = "Nach: "
        m["Outbound train"] = "Hinfahrt-Zug"
        m["Return train"] = "Rückfahrt-Zug"
        m["Travel days"] = "Reisetage"
        m["M"] = "M"
        m["W"] = "M"
        m["T"] = "D"
        m["F"] = "F"
        m["S"] = "S"
        m["Car fuel"] = "Autokraftstoff"
        m["Consumption l/100 km"] = "Verbrauch l/100 km"
        m["Parking € per day"] = "Parken € pro Tag"
        m["Train pass € per month"] = "Zugabo € pro Monat"
        m["Calculate"] = "Berechnen"
        m["A network error occurred. Please try again."] = "Es ist ein Netzwerkfehler aufgetreten. Bitte versuche es erneut."
        m[". You can follow the train with voice alerts."] = ". Du kannst dem Zug mit Sprachhinweisen folgen."
        m["Ask about a train, station or route"] = "Frag nach einem Zug, Bahnhof oder einer Strecke"
        m["Speech recognition is not available on this phone. Install or enable the Google app."] = "Spracherkennung ist auf diesem Handy nicht verfügbar. Installiere oder aktiviere die Google-App."
        m["Read aloud on"] = "Vorlesen an"
        m["Read aloud off"] = "Vorlesen aus"
        m["Open train"] = "Zug öffnen"
        m["Following the train. I will give you voice alerts."] = "Ich folge dem Zug. Ich gebe dir Sprachhinweise."
        m["Follow with voice alerts"] = "Mit Sprachhinweisen folgen"
        m["Open station"] = "Bahnhof öffnen"
        m["Where is my train?"] = "Wo ist mein Zug?"
        m["Any strikes?"] = "Gibt es Streiks?"
        m["Can I bring my bike?"] = "Kann ich mein Fahrrad mitnehmen?"
        m["Disability assistance"] = "Hilfe für Menschen mit Behinderung"
        m["e.g. delay train 2070"] = "z. B. Verspätung Zug 2070"
        m["Speak: ask a question"] = "Sprechen: eine Frage stellen"
        m["Finding the station…"] = "Bahnhof wird gesucht…"
        m["Search a station or town above."] = "Suche oben einen Bahnhof oder Ort."
        m["Location not available: search a station."] = "Standort nicht verfügbar: Suche einen Bahnhof."
        m["No station found."] = "Kein Bahnhof gefunden."
        m["Place not found: try the station name."] = "Ort nicht gefunden: Versuche es mit dem Bahnhofsnamen."
        m["Looking for replacement buses at"] = "Ersatzbusse werden gesucht in"
        m["Other operators"] = "Weitere Unternehmen"
        m["Replacement bus stop"] = "Ersatzbus-Haltestelle"
        m["Replacement buses in the next 6 hours"] = "Ersatzbusse in den nächsten 6 Stunden"
        m["Timetable services are not responding: retry or check the official pages below."] = "Die Fahrplandienste antworten nicht: Versuche es erneut oder prüfe die offiziellen Seiten unten."
        m["No replacement buses scheduled here in the next hours according to official timetables. After sudden disruptions buses may not be in the timetables yet: check the official pages and station announcements."] = "Laut den offiziellen Fahrplänen sind hier in den nächsten Stunden keine Ersatzbusse geplant. Nach plötzlichen Störungen sind Busse möglicherweise noch nicht in den Fahrplänen: Prüfe die offiziellen Seiten und die Bahnhofsdurchsagen."
        m["Sources: official GTFS timetables of Trenord, Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements."] = "Quellen: offizielle GTFS-Fahrpläne von Trenord, Trenitalia und SBB über Transitous (transitous.org); Busse auf der Tafel von ViaggiaTreno (RFI). Jede Fahrt zeigt ihre Quelle. Die Zeiten sind planmäßig: Folge bei Störungen den Bahnhofsdurchsagen."
        m["Board at: "] = "Einsteigen: "
        m[" from the station"] = " vom Bahnhof"
        m["Bay / platform: "] = "Haltebucht / Bahnsteig: "
        m["Real time"] = "Echtzeit"
        m["Scheduled time"] = "Planmäßige Zeit"
        m["Directions to the stop"] = "Weg zur Haltestelle"
        m["My region"] = "Meine Region"
        m["My route and times"] = "Meine Strecke und Zeiten"
        m["National strikes and in: "] = "Nationale Streiks und in: "
        m["back "] = "zurück "
        m["Set your route and the time of your outbound and/or return train"] = "Lege deine Strecke und die Zeit deines Hin- und/oder Rückfahrtzuges fest"
        m["Mon"] = "Mo"
        m["Tue"] = "Di"
        m["Wed"] = "Mi"
        m["Thu"] = "Do"
        m["Fri"] = "Fr"
        m["Sat"] = "Sa"
        m["Sun"] = "So"
        m["Mon–Fri"] = "Mo–Fr"
        m["every day"] = "täglich"
        m["My route"] = "Meine Strecke"
        m["Out "] = "Hin "
        m["Back "] = "Zurück "
        m["No outbound"] = "Keine Hinfahrt"
        m["No return"] = "Keine Rückfahrt"
        m["Days"] = "Tage"
        m["Operators you use"] = "Von dir genutzte Unternehmen"
        m["Regions (also for the \"My region\" filter)"] = "Regionen (auch für den Filter „Meine Region“)"
        m["A strike shows in \"My route\" if it is national or in one of your regions, involves one of your operators (or all) and its hours cover your outbound or return train on one of your travel days."] = "Ein Streik erscheint unter „Meine Strecke“, wenn er landesweit oder in einer deiner Regionen stattfindet, eines deiner Unternehmen (oder alle) betrifft und seine Zeiten deinen Hin- oder Rückfahrtzug an einem deiner Reisetage abdecken."
        m["arrival at "] = "Ankunft um "
        m["Arrival "] = "Ankunft "
        m["Departure "] = "Abfahrt "
        m["On Xiaomi: Settings → Apps → Binario → Battery saver → No restrictions, and also enable \"Autostart\"."] = "Bei Xiaomi: Einstellungen → Apps → Binario → Energiesparmodus → Keine Einschränkungen, und aktiviere auch „Autostart“."
        m["On Oppo, Realme and OnePlus: Settings → Apps → Binario → Battery usage → allow background activity and auto launch."] = "Bei Oppo, Realme und OnePlus: Einstellungen → Apps → Binario → Akkunutzung → Hintergrundaktivität und automatischen Start erlauben."
        m["On Huawei and Honor: Settings → Battery → App launch → Binario → manage manually, with all three options on."] = "Bei Huawei und Honor: Einstellungen → Akku → App-Start → Binario → manuell verwalten, mit allen drei Optionen an."
        m["On Samsung: Settings → Apps → Binario → Battery → Unrestricted, and remove Binario from \"Sleeping apps\"."] = "Bei Samsung: Einstellungen → Apps → Binario → Akku → Unbeschränkt, und entferne Binario aus „Schlafende Apps“."
        m["On Vivo: Settings → Battery → Background power consumption → allow Binario."] = "Bei Vivo: Einstellungen → Akku → Hintergrund-Energieverbrauch → Binario erlauben."
        m["If the followed train stops by itself: Settings → Apps → Binario → Battery → Unrestricted."] = "Wenn der verfolgte Zug von selbst stoppt: Einstellungen → Apps → Binario → Akku → Unbeschränkt."
        m["Alerts even with the app closed"] = "Hinweise auch bei geschlossener App"
        m["The train is followed even with Binario closed. Some phones, however, stop the alerts after a while to save battery. To avoid missing platform, delays and the wake-up alarm, allow Binario to run without battery restrictions: consumption stays low and it stops by itself on arrival."] = "Der Zug wird auch bei geschlossenem Binario verfolgt. Einige Handys stoppen die Hinweise jedoch nach einer Weile, um Akku zu sparen. Damit dir Gleis, Verspätungen und der Wecker nicht entgehen, erlaube Binario, ohne Akkubeschränkungen zu laufen: Der Verbrauch bleibt gering und die App stoppt bei der Ankunft von selbst."
        m["Guide for your phone"] = "Anleitung für dein Handy"
        m["Not now"] = "Nicht jetzt"
        m["Infrastructure manager of the Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa and Brescia–Iseo–Edolo network. Trains are run by Trenord."] = "Infrastrukturbetreiber des Netzes Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa und Brescia–Iseo–Edolo. Die Züge fährt Trenord."
        m["Lifts and escalators out of service"] = "Aufzüge und Rolltreppen außer Betrieb"
        m["The FERROVIENORD site is not responding. Open the official page or retry."] = "Die FERROVIENORD-Website antwortet nicht. Öffne die offizielle Seite oder versuche es erneut."
        m["No equipment reported out of service."] = "Keine Anlagen als außer Betrieb gemeldet."
        m["No equipment out of service at this station."] = "An diesem Bahnhof ist keine Anlage außer Betrieb."
        m["Platform not accessible: "] = "Bahnsteig nicht barrierefrei: "
        m["Out of service since "] = "Außer Betrieb seit "
        m["Expected back: "] = "Voraussichtlich wieder verfügbar: "
        m["Source: ferrovienord.it · Station accessibility notices (read now, refreshed every 30 minutes)."] = "Quelle: ferrovienord.it · Meldungen zur Bahnhofsbarrierefreiheit (jetzt gelesen, alle 30 Minuten aktualisiert)."
        m["Accessibility and assistance"] = "Barrierefreiheit und Hilfe"
        m["Live lift and escalator status"] = "Live-Status von Aufzügen und Rolltreppen"
        m["Assistance for disabled passengers: 800 210 955"] = "Hilfe für Fahrgäste mit Behinderung: 800 210 955"
        m["Trenord/FERROVIENORD free number · book at least 48 hours ahead"] = "Kostenlose Nummer von Trenord/FERROVIENORD · mindestens 48 Stunden im Voraus buchen"
        m["Assistance request by email"] = "Hilfeanfrage per E-Mail"
        m["Book assistance online"] = "Hilfe online buchen"
        m["Station accessibility sheets · Milan branches"] = "Barrierefreiheitsblätter der Bahnhöfe · Mailänder Strecken"
        m["Station accessibility sheets · Brescia–Iseo–Edolo"] = "Barrierefreiheitsblätter der Bahnhöfe · Brescia–Iseo–Edolo"
        m["Station accessibility and reduced mobility"] = "Barrierefreiheit der Bahnhöfe und eingeschränkte Mobilität"
        m["Every FERROVIENORD station has a defibrillator (125 installed in 2022–2023): where possible on the outside wall so it can be reached at night, in an alarmed, marked case with a first-aid kit. It is remotely monitored and registered with the regional emergency centres. It can be used on children too. In an emergency call 112."] = "Jeder FERROVIENORD-Bahnhof hat einen Defibrillator (125 installiert 2022–2023): wenn möglich an der Außenwand, damit er nachts erreichbar ist, in einem alarmgesicherten, gekennzeichneten Kasten mit Erste-Hilfe-Set. Er wird ferngewartet und bei den regionalen Rettungsleitstellen registriert. Er kann auch bei Kindern eingesetzt werden. Im Notfall 112 anrufen."
        m["Map of nearby defibrillators"] = "Karte der Defibrillatoren in der Nähe"
        m["FERROVIENORD stations and other AEDs"] = "FERROVIENORD-Bahnhöfe und weitere AEDs"
        m["Defibrillators page"] = "Defibrillator-Seite"
        m["Network documents (PIR web)"] = "Netzdokumente (PIR web)"
        m["Service quality indicators 2026"] = "Servicequalitätsindikatoren 2026"
        m["Line and facility characteristics"] = "Merkmale von Linien und Anlagen"
        m["Station usage plan"] = "Bahnhofsnutzungsplan"
        m["Station upgrades for reduced mobility"] = "Bahnhofsumbauten für eingeschränkte Mobilität"
        m["Network statement"] = "Schienennetz-Nutzungsbedingungen"
        m["All documents"] = "Alle Dokumente"
        m["Sources: ferrovienord.it (PIR web, station accessibility notices, defibrillators) and trenord.it (assistance). Restore dates are the manager's estimates."] = "Quellen: ferrovienord.it (PIR web, Meldungen zur Bahnhofsbarrierefreiheit, Defibrillatoren) und trenord.it (Hilfe). Die Wiederinbetriebnahme-Termine sind Schätzungen des Betreibers."
        m["Customer service"] = "Kundenservice"
        m["Validators & more"] = "Entwerter & mehr"
        m[" (open/closed from Trenord)"] = " (geöffnet/geschlossen von Trenord)"
        m["trenitalia.com · Customer service offices (April 2025 hours)"] = "trenitalia.com · Kundenservice-Büros (Öffnungszeiten April 2025)"
        m["italotreno.com · Station ticket offices"] = "italotreno.com · Bahnhofsschalter"
        m["SBB open data (data.sbb.ch)"] = "SBB Open Data (data.sbb.ch)"
        m["Loading sales points…"] = "Verkaufsstellen werden geladen…"
        m["you"] = "du"
        m["nearest to"] = "nächster zu"
        m["Trenord sales points are in Lombardy. Nearby: SBB machines, altoadigemobilità and OpenStreetMap points; elsewhere in Italy use the official Trenitalia map (at the bottom)."] = "Trenord-Verkaufsstellen befinden sich in der Lombardei. In der Nähe: SBB-Automaten, altoadigemobilità und OpenStreetMap-Punkte; im übrigen Italien nutze die offizielle Trenitalia-Karte (ganz unten)."
        m["Open/closed updated now from Trenord for the province of"] = "Geöffnet/geschlossen jetzt von Trenord aktualisiert für die Provinz"
        m["No sales points found."] = "Keine Verkaufsstellen gefunden."
        m["Showing the nearest 300: search a town or station for the others."] = "Es werden die nächsten 300 angezeigt: Suche einen Ort oder Bahnhof für die übrigen."
        m["Distance: "] = "Entfernung: "
        m["Sells: "] = "Verkauft: "
        m["Weekly opening hours"] = "Wöchentliche Öffnungszeiten"
        m["Visit the page"] = "Seite besuchen"
        m["Card"] = "Karte"
        m["Coins"] = "Münzen"
        m[", limited operation"] = ", eingeschränkter Betrieb"
        m["*Limited operation"] = "*Eingeschränkter Betrieb"
        m["closed"] = "geschlossen"
        m["Trenord offices, machines and resellers"] = "Trenord-Schalter, Automaten und Verkäufer"
        m["open/closed read now"] = "geöffnet/geschlossen jetzt gelesen"
        m["SBB ticket machines (data.sbb.ch)"] = "SBB-Billettautomaten (data.sbb.ch)"
        m["other points from"] = "weitere Punkte von"
        m["1 machine"] = "1 Automat"
        m["machines"] = "Automaten"
        m["Overview"] = "Übersicht"
        m["Statistics not available right now."] = "Statistiken zurzeit nicht verfügbar."
        m["Search station"] = "Bahnhof suchen"
        m["Train number or destination"] = "Zugnummer oder Ziel"
        m["Least punctual"] = "Am unpünktlichsten"
        m["Most punctual"] = "Am pünktlichsten"
        m["FerrovieNord network"] = "FerrovieNord-Netz"
        m["Milan Passante"] = "Mailänder Passante"
        m["collected by the app · "] = "von der App erfasst · "
        m[" days"] = " Tage"
        m["No results"] = "Keine Ergebnisse"
        m["on time (within 5 min)"] = "pünktlich (innerhalb von 5 Min.)"
        m[" points vs "] = " Punkte gegenüber "
        m["arrivals observed"] = "beobachtete Ankünfte"
        m["cancelled runs"] = "ausgefallene Fahrten"
        m["Avg delay "] = "Ø Verspätung "
        m[" arrivals"] = " Ankünfte"
        m[" cancelled"] = " ausgefallen"
        m[" trains"] = " Züge"
        m["Your trains"] = "Deine Züge"
        m["Your stations"] = "Deine Bahnhöfe"
        m["Switzerland · SBB"] = "Schweiz · SBB"
        m["SBB data not reachable right now."] = "SBB-Daten zurzeit nicht erreichbar."
        m[" stop arrivals"] = " Haltestellenankünfte"
        m[" cancelled stops"] = " ausgefallene Halte"
        m["Data for "] = "Daten für "
        m["Average of "] = "Durchschnitt von "
        m[" days ("] = " Tagen ("
        m["Why BLS, SOB, Rhaetian Railway and the other Swiss companies are missing"] = "Warum BLS, SOB, Rhätische Bahn und die anderen Schweizer Unternehmen fehlen"
        m["FerrovieNord network · Trenord"] = "FerrovieNord-Netz · Trenord"
        m["Collection just started: first data after a few hours, reliable figures after a couple of weeks."] = "Erfassung gerade gestartet: erste Daten nach einigen Stunden, verlässliche Werte nach etwa zwei Wochen."
        m["Today's data"] = "Heutige Daten"
        m["Last "] = "Letzte "
        m[" days collected ("] = " Tage erfasst ("
        m["Stations are in the Stations tab (FerrovieNord filter)."] = "Die Bahnhöfe stehen im Reiter Bahnhöfe (Filter FerrovieNord)."
        m["Collection on"] = "Erfassung am"
        m[" runs"] = " Fahrten"
        m[" severe delays"] = " schwere Verspätungen"
        m["recent days (collected by the app)"] = "letzte Tage (von der App erfasst)"
        m[" runs observed"] = " beobachtete Fahrten"
        m["Recent punctuality (FN network): "] = "Aktuelle Pünktlichkeit (FN-Netz): "
        m["Last month punctuality: "] = "Pünktlichkeit im letzten Monat: "
        m["avg delay "] = "Ø Verspätung "
        m[". On time = arrival within 5 minutes."] = ". Pünktlich = Ankunft innerhalb von 5 Minuten."
        m["How shall I find your train? Type its number, or I find the station nearest to you, or pick a station and time."] = "Wie soll ich deinen Zug finden? Gib die Nummer ein, ich finde den Bahnhof in deiner Nähe oder du wählst einen Bahnhof und eine Zeit."
        m["No sign-up needed and your data stays on the phone. To send you alerts I need permission for notifications: tap Allow."] = "Keine Anmeldung nötig, deine Daten bleiben auf dem Handy. Um dir Hinweise zu senden, brauche ich die Berechtigung für Benachrichtigungen: Tippe auf Erlauben."
        m["Without notifications I can only update you here in the app. You can turn them on any time in the phone settings."] = "Ohne Benachrichtigungen kann ich dich nur hier in der App auf dem Laufenden halten. Du kannst sie jederzeit in den Handy-Einstellungen einschalten."
        m["I found this train: is it yours?"] = "Ich habe diesen Zug gefunden: Ist es deiner?"
        m["I can't connect. Check your connection and try again."] = "Ich kann keine Verbindung herstellen. Prüfe deine Verbindung und versuche es erneut."
        m["plat. "] = "Gl. "
        m["Without location I can't find the nearby station: pick the station yourself."] = "Ohne Standort finde ich den Bahnhof in der Nähe nicht: Wähle den Bahnhof selbst."
        m["I can't find your location. Turn on location or pick the station."] = "Ich finde deinen Standort nicht. Schalte den Standort ein oder wähle den Bahnhof."
        m["Station list unavailable, try again."] = "Bahnhofsliste nicht verfügbar, versuche es erneut."
        m["I can't answer right now: check your connection."] = "Ich kann gerade nicht antworten: Prüfe deine Verbindung."
        m["They said: "] = "Du hast gesagt: "
        m["Hold the phone close to the speaker"] = "Halte das Handy nah an den Lautsprecher"
        m["Say the train number or ask a question"] = "Sage die Zugnummer oder stelle eine Frage"
        m["Speech recognition isn't available on this phone: install or enable the Google app."] = "Spracherkennung ist auf diesem Handy nicht verfügbar: Installiere oder aktiviere die Google-App."
        m["I can't read this train's data right now. Try again shortly."] = "Ich kann die Daten dieses Zuges gerade nicht lesen. Versuche es gleich noch einmal."
        m["Where do you board?"] = "Wo steigst du ein?"
        m["I'll alert you when the platform is announced or changes, if the delay grows, if the train is cancelled"] = "Ich benachrichtige dich, wenn das Gleis angekündigt wird oder sich ändert, wenn die Verspätung wächst oder der Zug ausfällt"
        m[", and on arrival I'll send you a summary. Everything is in the ongoing notification too."] = ", und bei der Ankunft sende ich dir eine Zusammenfassung. Alles steht auch in der Dauerbenachrichtigung."
        m["Trip completed: I'm no longer following the train. Want to follow another one?"] = "Fahrt beendet: Ich folge dem Zug nicht mehr. Möchtest du einem anderen folgen?"
        m["OK, no more updates on this train."] = "OK, keine weiteren Meldungen zu diesem Zug."
        m["Where do you get off? I'll warn you before the stop."] = "Wo steigst du aus? Ich warne dich vor der Haltestelle."
        m["To the terminus"] = "Bis zur Endstation"
        m["No alarm needed: follow to the terminus"] = "Kein Alarm nötig: bis zur Endstation folgen"
        m["+1 hour"] = "+1 Stunde"
        m["+2 hours"] = "+2 Stunden"
        m["+3 hours"] = "+3 Stunden"
        m["Pick time"] = "Zeit wählen"
        m["Type or say the train number (it's on your ticket or the board)."] = "Gib die Zugnummer ein oder sprich sie aus (sie steht auf deiner Fahrkarte oder der Tafel)."
        m["Station and time"] = "Bahnhof und Zeit"
        m["Follow another train"] = "Einem anderen Zug folgen"
        m["Delayed? Your rights"] = "Verspätet? Deine Rechte"
        m["Transcribe speech"] = "Sprache transkribieren"
        m["Let the phone speak"] = "Das Handy sprechen lassen"
        m["Train number, e.g. 2070"] = "Zugnummer, z. B. 2070"
        m["Type a train number or a question"] = "Gib eine Zugnummer oder eine Frage ein"
        m["Speak"] = "Sprechen"
        m["Which station do you leave from?"] = "Von welchem Bahnhof fährst du ab?"
        m["platform "] = "Gleis "
        m["platform not yet announced"] = "Gleis noch nicht angekündigt"
        m["Next stop: "] = "Nächster Halt: "
        m["Last seen: "] = "Zuletzt gesehen: "
        m["They said"] = "Sie sagten"
        m["I am deaf: could you please write it down?"] = "Ich bin gehörlos: Könnten Sie es bitte aufschreiben?"
        m["Which platform does the train leave from?"] = "Von welchem Gleis fährt der Zug ab?"
        m["Could you tell me when we reach my stop?"] = "Könnten Sie mir sagen, wann wir meine Haltestelle erreichen?"
        m["How late is the train?"] = "Wie viel Verspätung hat der Zug?"
        m["Where can I buy a ticket?"] = "Wo kann ich eine Fahrkarte kaufen?"
        m["Show the screen to the person in front of you: the phone is also reading it aloud."] = "Zeige den Bildschirm der Person vor dir: Das Handy liest es auch laut vor."
        m["Type what you want to say"] = "Tippe, was du sagen möchtest"
        m["Ready phrases"] = "Fertige Sätze"
        m["Read aloud"] = "Vorlesen"
        m["Assistance is free, in the station and for getting on and off the train."] = "Die Hilfe ist kostenlos, im Bahnhof und beim Ein- und Aussteigen."
        m["It covers wheelchair users and people with walking difficulties (even temporary), blind or partially sighted, deaf or with communication difficulties, people with intellectual or mental disabilities, older people and pregnant women."] = "Sie gilt für Rollstuhlfahrer und Menschen mit Gehschwierigkeiten (auch vorübergehend), Blinde oder Sehbehinderte, Gehörlose oder Menschen mit Kommunikationsschwierigkeiten, Menschen mit geistiger oder psychischer Behinderung, ältere Menschen und Schwangere."
        m["Who to call depends on the station and train: at RFI stations (almost all Italian stations) the Sale Blu assist for every operator; at FerrovieNord stations Trenord does; in Switzerland, SBB."] = "Wen du anrufst, hängt von Bahnhof und Zug ab: An RFI-Bahnhöfen (fast alle italienischen Bahnhöfe) helfen die Sale Blu für alle Unternehmen; an FerrovieNord-Bahnhöfen Trenord; in der Schweiz die SBB."
        m["RFI Sale Blu · Trenitalia, Italo, Trenord at RFI stations"] = "RFI Sale Blu · Trenitalia, Italo, Trenord an RFI-Bahnhöfen"
        m["Toll-free from landlines · daily 6:45–21:30"] = "Kostenlos aus dem Festnetz · täglich 6:45–21:30"
        m["From mobiles and abroad (standard rate)"] = "Vom Handy und aus dem Ausland (normaler Tarif)"
        m["At least 6 hours before: stations, date, train, type of assistance, phone"] = "Mindestens 6 Stunden vorher: Bahnhöfe, Datum, Zug, Art der Hilfe, Telefon"
        m["SalaBlu Online and SalaBlu+ app"] = "SalaBlu Online und SalaBlu+-App"
        m["Booking up to 3 hours before; chat for deaf people"] = "Buchung bis zu 3 Stunden vorher; Chat für Gehörlose"
        m["How far ahead: at major stations (e.g. Milano Porta Garibaldi) up to 1 hour before for trains between 7:45 and 22:30; at other stations and at night at least 12 hours before. Groups of 3+: 24 hours. Trips abroad: 24–48 hours."] = "Wie früh: an großen Bahnhöfen (z. B. Milano Porta Garibaldi) bis zu 1 Stunde vorher für Züge zwischen 7:45 und 22:30 Uhr; an anderen Bahnhöfen und nachts mindestens 12 Stunden vorher. Gruppen ab 3 Personen: 24 Stunden. Reisen ins Ausland: 24–48 Stunden."
        m["Be at the meeting point at least 30 minutes before: staff wear orange vests. To cancel, give at least 4 hours' notice."] = "Sei mindestens 30 Minuten vorher am Treffpunkt: Das Personal trägt orange Westen. Zum Stornieren bitte mindestens 4 Stunden vorher Bescheid geben."
        m["Trenord and FerrovieNord stations"] = "Bahnhöfe von Trenord und FerrovieNord"
        m["Trenord assistance toll-free · book preferably 48 hours ahead"] = "Kostenlose Trenord-Hilfenummer · möglichst 48 Stunden vorher buchen"
        m["Trenord contact centre (also from mobiles)"] = "Trenord Contact Center (auch vom Handy)"
        m["Information and bookings"] = "Auskunft und Buchungen"
        m["Report barriers between train and station"] = "Hindernisse zwischen Zug und Bahnsteig melden"
        m["Pronto Italo · daily 7–23: suitable seat and assistance booking (provided in station by RFI)"] = "Pronto Italo · täglich 7–23 Uhr: Buchung von passendem Sitzplatz und Hilfe (am Bahnhof von RFI erbracht)"
        m["Italo assistance page"] = "Italo-Hilfeseite"
        m["SBB Contact Center Handicap from Italy · daily 5–24 (from Switzerland 0800 007 102, free)"] = "SBB Contact Center Handicap aus Italien · täglich 5–24 Uhr (aus der Schweiz 0800 007 102, kostenlos)"
        m["Book online"] = "Online buchen"
        m["swisspass.ch/handicap · at least 1 hour before (international trips 24 hours)"] = "swisspass.ch/handicap · mindestens 1 Stunde vorher (internationale Reisen 24 Stunden)"
        m["Tips by type of disability"] = "Tipps nach Art der Behinderung"
        m["Wheelchair: boarding with ramp or lift. Wheelchair at most 70 cm wide, 120 cm long and 250 kg including the person. The station screen shows lifts per platform and current faults."] = "Rollstuhl: Einstieg mit Rampe oder Lift. Rollstuhl höchstens 70 cm breit, 120 cm lang und 250 kg einschließlich Person. Der Bahnhofsbildschirm zeigt Aufzüge pro Gleis und aktuelle Störungen."
        m["Blind or partially sighted: guide dogs travel free; you can ask for a suitable seat when booking. Turn on the spoken option: the app tells you platform, departure and your stop."] = "Blinde oder Sehbehinderte: Blindenhunde reisen kostenlos; bei der Buchung kannst du einen passenden Sitzplatz anfragen. Schalte die Sprachoption ein: Die App sagt dir Gleis, Abfahrt und deine Haltestelle."
        m["Deaf people: the Sale Blu have a chat (after registering on SalaBlu Online). In My Conductor use \"Transcribe speech\" and \"Let the phone speak\"; turn on vibration and flash alerts."] = "Gehörlose: Die Sale Blu haben einen Chat (nach der Registrierung bei SalaBlu Online). Nutze in „Mein Zugbegleiter“ „Sprache transkribieren“ und „Das Handy sprechen lassen“; schalte Vibrations- und Blitzhinweise ein."
        m["Intellectual or mental disabilities, or people who are not self-sufficient: a companion may be needed; staff escort you from the meeting point to the train and connection."] = "Geistige oder psychische Behinderungen oder nicht selbstständige Personen: Eine Begleitperson kann nötig sein; das Personal begleitet dich vom Treffpunkt zum Zug und zum Anschluss."
        m["Older people, pregnant women, casts or temporary difficulties: assistance is for you too, with a wheelchair on request and help with one piece of hand luggage."] = "Ältere Menschen, Schwangere, Gipsverband oder vorübergehende Schwierigkeiten: Die Hilfe gilt auch für dich, mit Rollstuhl auf Wunsch und Hilfe bei einem Handgepäckstück."
        m["Connections: allow at least 30 minutes between trains when booking assistance."] = "Anschlüsse: Plane bei der Buchung von Hilfe mindestens 30 Minuten zwischen den Zügen ein."
        m["Open My Conductor"] = "Mein Zugbegleiter öffnen"
        m["Emergency"] = "Notfall"
        m["Single emergency number (Italy and Switzerland)"] = "Einheitliche Notrufnummer (Italien und Schweiz)"
        m["Numbers and rules from the official RFI, Trenord, Italo and SBB pages (October 2026): if in doubt, check the operator's site."] = "Nummern und Regeln von den offiziellen Seiten von RFI, Trenord, Italo und SBB (Oktober 2026): Im Zweifel prüfe die Website des Unternehmens."
        m["Page"] = "Seite"
        m["Changes"] = "Umstiege"
        m["direct"] = "direkt"
        m["Downloading outbound…"] = "Hinfahrt wird heruntergeladen…"
        m["Downloading return…"] = "Rückfahrt wird heruntergeladen…"
        m["No runs found for that day"] = "Für diesen Tag keine Fahrten gefunden"
        m["Timetable for"] = "Fahrplan für"
        m["runs"] = "Fahrten"
        m["No runs found."] = "Keine Fahrten gefunden."
        m["Real time from the operator · "] = "Echtzeit vom Unternehmen · "
        m["Scheduled times: delays not published by the operator · "] = "Planmäßige Zeiten: Verspätungen werden vom Unternehmen nicht veröffentlicht · "
        m["Departure station not found"] = "Abfahrtsbahnhof nicht gefunden"
        m["Arrival station not found"] = "Ankunftsbahnhof nicht gefunden"
        m["responds but the format changed"] = "antwortet, aber das Format hat sich geändert"
        m["OK (backup server: "] = "OK (Ersatzserver: "
        m["no response"] = "keine Antwort"
        m["Foreign operators (ÖBB, DB)"] = "Ausländische Unternehmen (ÖBB, DB)"
        m["Replacement bus"] = "Ersatzbus"
        m["SBB timetable (transport.opendata.ch)"] = "SBB-Fahrplan (transport.opendata.ch)"
        m["ViaggiaTreno (RFI) · station board"] = "ViaggiaTreno (RFI) · Bahnhofstafel"
        m["Trenord · replacement bus map"] = "Trenord · Ersatzbus-Karte"
        m["RFI · travel updates (works and replacement buses)"] = "RFI · Reiseaktualisierungen (Bauarbeiten und Ersatzbusse)"
        m["SBB · S-Bahn and regional"] = "SBB · S-Bahn und Regional"
    }

    private fun p5(m: HashMap<String, String>) {
        m["Wi-Fi and sockets: on Frecce and Italo on-board Wi-Fi is free and there are power sockets at the seats. Regional trains usually have no Wi-Fi and only some new trains have sockets. In Switzerland many SBB stations have free Wi-Fi."] = "WLAN und Steckdosen: In Frecce und Italo ist das WLAN an Bord kostenlos und es gibt Steckdosen an den Plätzen. Regionalzüge haben meist kein WLAN und nur einige neue Züge haben Steckdosen. In der Schweiz haben viele SBB-Bahnhöfe kostenloses WLAN."
        m["Seats: on Frecce, Intercity and Italo the seat is assigned with the ticket and you can choose it when buying (window, aisle…). Regional trains (Trenord, Trenitalia Regional, TILO) have no reservations: you sit wherever there is room."] = "Sitzplätze: In Frecce, Intercity und Italo ist der Sitzplatz mit der Fahrkarte reserviert und du kannst ihn beim Kauf wählen (Fenster, Gang…). In Regionalzügen (Trenord, Trenitalia Regionale, TILO) gibt es keine Reservierung: Man setzt sich, wo Platz ist."
        m["First class: Frecciarossa trains have Standard, Premium, Business and Executive levels; Italo has Smart, Comfort, Prima and Club Executive. Many Trenord regional trains have 1st class, with a supplement of €2.80 per trip (€31 a month, €310 a year with a pass). In the search results you can see 1st-class prices with the \"1st class\" selector."] = "Erste Klasse: Der Frecciarossa hat die Stufen Standard, Premium, Business und Executive; Italo hat Smart, Comfort, Prima und Club Executive. Viele Trenord-Regionalzüge haben eine 1. Klasse, mit einem Zuschlag von 2,80 € pro Fahrt (31 € im Monat, 310 € im Jahr mit Abo). In den Suchergebnissen siehst du die Preise der 1. Klasse mit dem Schalter \"1. Klasse\"."
        m["Ticket validity: it depends on the ticket. STIBM area (Milan and surroundings): 75 minutes for 2 zones, 90 minutes in the city, longer with more zones. Arcobaleno/Trenord cross-border tickets: 4 hours for the whole trip. Digital regional tickets are valid for the day or train shown; paper ones must be validated before boarding. Frecce and Italo: valid for the booked train."] = "Gültigkeit der Fahrkarte: Sie hängt von der Fahrkarte ab. STIBM-Gebiet (Mailand und Umgebung): 75 Minuten für 2 Zonen, 90 Minuten in der Stadt, länger mit mehr Zonen. Grenzüberschreitende Arcobaleno-/Trenord-Fahrkarten: 4 Stunden für die ganze Reise. Digitale Regionalfahrkarten gelten für den angegebenen Tag oder Zug; Papierfahrkarten müssen vor dem Einsteigen entwertet werden. Frecce und Italo: gültig für den gebuchten Zug."
        m["Parking: many stations have a car park (often paid) and bike racks or bike stations. The app does not list car parks yet: open the map from the station screen and search for \"parking\"."] = "Parken: Viele Bahnhöfe haben einen Parkplatz (oft kostenpflichtig) und Fahrradständer oder Velostationen. Die App listet Parkplätze noch nicht auf: Öffne die Karte in der Bahnhofsansicht und suche nach \"Parkplatz\"."
        m["Night trains: Trenitalia runs Intercity Notte trains (for example to southern Italy and Sicily); ÖBB Nightjets link Italy with Austria and Germany; in Ticino there is the TILO Pigiama night service on some nights. Search the route with an evening time."] = "Nachtzüge: Trenitalia fährt Intercity-Notte-Züge (zum Beispiel nach Süditalien und Sizilien); ÖBB-Nightjets verbinden Italien mit Österreich und Deutschland; im Tessin gibt es in manchen Nächten den Nachtdienst TILO Pigiama. Suche die Strecke mit einer Abendzeit."
        m["Italo (NTV) is the private high-speed operator, on the high-speed lines between Turin, Milan, Venice, Bologna, Florence, Rome and Naples. Tickets are sold on italotreno.com, in the app, at Italo ticket offices and machines in stations; levels are Smart, Comfort, Prima and Club Executive. Binario shows Italo trains in the solutions and in real time. Pronto Italo: 06 07 08."] = "Italo (NTV) ist das private Hochgeschwindigkeitsunternehmen auf den Schnellfahrstrecken zwischen Turin, Mailand, Venedig, Bologna, Florenz, Rom und Neapel. Fahrkarten gibt es auf italotreno.com, in der App, an den Italo-Schaltern und -Automaten in den Bahnhöfen; die Stufen sind Smart, Comfort, Prima und Club Executive. Binario zeigt Italo-Züge in den Verbindungen und in Echtzeit. Pronto Italo: 06 07 08."
        m["Food and drink: on every train you can eat and drink what you bring. Frecce have a bar/FRECCIABistrò, Italo offers snacks and drinks; regional trains have no catering."] = "Essen und Trinken: In jedem Zug darfst du Mitgebrachtes essen und trinken. Die Frecce haben eine Bar/FRECCIABistrò, Italo bietet Snacks und Getränke; Regionalzüge haben keine Verpflegung."
        m["Smoking is forbidden on all trains and in enclosed station areas, e-cigarettes on board included. Smokers risk a fine."] = "Rauchen ist in allen Zügen und in geschlossenen Bahnhofsbereichen verboten, auch E-Zigaretten an Bord. Wer raucht, riskiert ein Bußgeld."
        m["Discounts: Trenitalia has Economy and Super Economy fares (limited seats), discounts for young people and over-60s with CartaFRECCIA, and group offers. Italo has Low Cost and Economy fares and the Italo Più programme. In Lombardy Trenord has reduced passes for under-26s and over-65s and the Io Viaggio in Famiglia family discount. The app's \"Best prices\" calendar shows the lowest prices by time of day."] = "Ermäßigungen: Trenitalia hat die Tarife Economy und Super Economy (begrenzte Plätze), Rabatte für junge Leute und über 60-Jährige mit CartaFRECCIA sowie Gruppenangebote. Italo hat die Tarife Low Cost und Economy und das Programm Italo Più. In der Lombardei hat Trenord ermäßigte Abos für unter 26- und über 65-Jährige und den Familienrabatt Io Viaggio in Famiglia. Der Kalender \"Beste Preise\" der App zeigt die günstigsten Preise nach Tageszeit."
        m["Groups: Trenitalia and Italo have group offers (usually from 10 people, to be requested in advance); Trenord has tickets for groups and school classes. Conditions and forms are on the operators' websites."] = "Gruppen: Trenitalia und Italo haben Gruppenangebote (meist ab 10 Personen, im Voraus anzufragen); Trenord hat Fahrkarten für Gruppen und Schulklassen. Bedingungen und Formulare stehen auf den Websites der Unternehmen."
        m["Minors travelling alone: the rules differ between operators. In general older children can travel alone with a valid ticket, while young children must be accompanied by an adult. Before travelling check the conditions of carriage of Trenord, Trenitalia or Italo."] = "Minderjährige allein unterwegs: Die Regeln sind je nach Unternehmen verschieden. Im Allgemeinen dürfen ältere Kinder mit gültiger Fahrkarte allein reisen, kleine Kinder müssen von einem Erwachsenen begleitet werden. Prüfe vor der Reise die Beförderungsbedingungen von Trenord, Trenitalia oder Italo."
        m["Digital tickets: no need to print them, just show them on your phone (PDF, app or QR code) with enough battery. Some tickets require check-in or activation before boarding: it is stated on the ticket and in the operator's app."] = "Digitale Fahrkarten: Du musst sie nicht ausdrucken, es reicht, sie auf dem Handy zu zeigen (PDF, App oder QR-Code), mit genug Akku. Manche Fahrkarten verlangen vor dem Einsteigen einen Check-in oder eine Aktivierung: Das steht auf der Fahrkarte und in der App des Unternehmens."
        m["Emergency or safety: call 112, the single emergency number. On board use the intercom or emergency button and tell the conductor; in stations there is the Railway Police (Polfer). For a theft report it to the Polfer or Carabinieri and block your cards and phone. The nearest defibrillator is on the Home screen."] = "Notfall oder Sicherheit: Ruf die 112 an, die einheitliche Notrufnummer. Im Zug nutze die Sprechanlage oder den Notrufknopf und sag dem Schaffner Bescheid; in den Bahnhöfen gibt es die Bahnpolizei (Polfer). Einen Diebstahl zeigst du bei der Polfer oder den Carabinieri an und sperrst Karten und Handy. Der nächste Defibrillator ist auf dem Startbildschirm."
        m["Payments: ticket machines take cards (also contactless) and often cash; apps and websites take cards, PayPal and digital wallets depending on the operator; ticket offices also take cash. On some lines and metros you can tap a contactless card directly at the validators."] = "Bezahlen: Automaten nehmen Karten (auch kontaktlos) und oft Bargeld; Apps und Websites nehmen je nach Unternehmen Karten, PayPal und digitale Wallets; Schalter nehmen auch Bargeld. Auf manchen Linien und in U-Bahnen kannst du direkt am Entwerter mit einer kontaktlosen Karte bezahlen."
        m["Replacement buses: when trains are replaced by buses, Stations → Replacement buses shows stops, times and sources for your station; notices are in News. The bus stop is usually signposted in front of the station."] = "Ersatzbusse: Wenn Züge durch Busse ersetzt werden, zeigt Bahnhöfe → Ersatzbusse Haltestellen, Zeiten und Quellen für deinen Bahnhof; die Meldungen stehen unter Nachrichten. Die Bushaltestelle ist meist vor dem Bahnhof ausgeschildert."
        m["Language: tap the flag at the top of the Home screen or go to More → Settings → Language. Italian, English, Chinese, German, French, Spanish and Japanese are available; the voice changes language too."] = "Sprache: Tippe oben auf dem Startbildschirm auf die Flagge oder gehe zu Mehr → Einstellungen → Sprache. Es gibt Italienisch, Englisch, Chinesisch, Deutsch, Französisch, Spanisch und Japanisch; auch die Stimme wechselt die Sprache."
        m["Favourites: tap the star ★ on a train, a station board or a route. You find them in the Trains and Stations tabs, in Quick (recent and favourites) and in the Favourites widget; you can also add them to the Home shortcuts with +."] = "Favoriten: Tippe auf den Stern ★ bei einem Zug, einer Abfahrtstafel oder einer Strecke. Du findest sie in den Reitern Züge und Bahnhöfe, unter Schnell (zuletzt und Favoriten) und im Favoriten-Widget; mit + kannst du sie auch zu den Schnelltasten auf dem Startbildschirm hinzufügen."
        m["Searching a timetable: in the Search tab choose departure and arrival, date and time (and return if needed), then tap Search. The results show times, changes, prices and delays; tap a train for stops and platforms. You can also ask me \"trains from Varese to Milano\"."] = "Fahrplan suchen: Wähle im Reiter Suchen Abfahrt und Ankunft, Datum und Uhrzeit (und bei Bedarf die Rückfahrt), dann tippe auf Suchen. Die Ergebnisse zeigen Zeiten, Umstiege, Preise und Verspätungen; tippe auf einen Zug für Halte und Gleise. Du kannst mich auch fragen: \"Züge von Varese nach Milano\"."
        m["Ticket on board: on regional trains you buy the ticket before boarding. If the station has no way to buy one (office closed, machine broken), tell the conductor as soon as you board: usually you can pay with a surcharge, but rules differ between operators. The conditions of carriage say when this is possible and how much it costs."] = "Fahrkarte im Zug: In Regionalzügen kaufst du die Fahrkarte vor dem Einsteigen. Wenn man sie am Bahnhof nicht kaufen kann (Schalter geschlossen, Automat kaputt), sag es dem Schaffner sofort beim Einsteigen: Meist kannst du mit einem Zuschlag nachzahlen, aber die Regeln sind je nach Unternehmen verschieden. Die Beförderungsbedingungen sagen, wann das möglich ist und was es kostet."
        m["SBB · InterRegio, InterCity, EuroCity"] = "SBB · InterRegio, InterCity, EuroCity"
        m[" · guaranteed band 6–9 / 18–21"] = " · garantiertes Zeitfenster 6–9 / 18–21"
        m["Incomplete download"] = "Unvollständiger Download"
        m["accessible"] = "barrierefrei"
        m["tactile paving"] = "taktiles Leitsystem"
        m["steps"] = "Stufen"
        m["handrail"] = "Handlauf"
        m["level "] = "Ebene "
        m["Hospital"] = "Krankenhaus"
        m["Pharmacy"] = "Apotheke"
        m["emergency department"] = "Notaufnahme"
        m["hospital"] = "Krankenhaus"
        m["pharmacy"] = "Apotheke"
        m["You are not following any train. Ask for example \"train 2512\" and then tap \"Follow with voice alerts\"."] = "Du folgst keinem Zug. Frag zum Beispiel \"Zug 2512\" und tippe dann auf \"Mit Sprachhinweisen folgen\"."
        m["Which station? Ask for example \"bus and taxi at Varese\"."] = "Welcher Bahnhof? Frag zum Beispiel \"Bus und Taxi in Varese\"."
        m["Which station? Ask for example \"toilets at Saronno\"."] = "Welcher Bahnhof? Frag zum Beispiel \"Toiletten in Saronno\"."
        m["Tell me the train number, for example \"delay train 2512\" or \"platform of 9544\"."] = "Nenne mir die Zugnummer, zum Beispiel \"Verspätung Zug 2512\" oder \"Gleis von 9544\"."
        m["Sorry, I didn't understand. Try one of these topics: "] = "Entschuldigung, das habe ich nicht verstanden. Versuche eines dieser Themen: "
        m["lines "] = "Linien "
        m["Toilets: not mapped"] = "Toiletten: nicht erfasst"
        m["Toilets: "] = "Toiletten: "
        m[", accessible"] = ", barrierefrei"
        m[", hours "] = ", Öffnungszeiten "
        m["Platforms: "] = "Gleise: "
        m["Lifts: "] = "Aufzüge: "
        m["Ticket office: "] = "Schalter: "
        m["Ticket machines: "] = "Fahrkartenautomaten: "
        m["Validators: "] = "Entwerter: "
        m["Station data not reachable now."] = "Bahnhofsdaten zurzeit nicht erreichbar."
        m["Train cancelled."] = "Zug ausgefallen."
        m["Arrived"] = "Angekommen"
        m["Running on time."] = "Fährt pünktlich."
        m[" (scheduled)"] = " (planmäßig)"
        m[", platform not yet announced"] = ", Gleis noch nicht angekündigt"
        m[" · scheduled platform "] = " · planmäßiges Gleis "
        m[" · actual "] = " · tatsächlich "
        m[" · CANCELLED"] = " · AUSGEFALLEN"
        m[" · on time"] = " · pünktlich"
        m[" · plat. "] = " · Gl. "
        m["Timetable service unreachable."] = "Fahrplandienst nicht erreichbar."
        m[" plat."] = " Gl."
        m["No rail strikes announced (source: Italian Ministry strike observatory)."] = "Keine Bahnstreiks angekündigt (Quelle: Streik-Observatorium des italienischen Ministeriums)."
        m["Announced rail strikes:\n"] = "Angekündigte Bahnstreiks:\n"
        m["\n\nGuaranteed trains: More → Guaranteed trains."] = "\n\nGarantierte Züge: Mehr → Garantierte Züge."
        m["Strike observatory unreachable."] = "Streik-Observatorium nicht erreichbar."
        m["No traffic disruptions reported right now."] = "Zurzeit keine Verkehrsstörungen gemeldet."
        m["Take a few seconds to write the message."] = "Nimm dir ein paar Sekunden Zeit, um die Nachricht zu schreiben."
        m["You just sent a message: wait a few minutes before the next one."] = "Du hast gerade eine Nachricht gesendet: Warte einige Minuten bis zur nächsten."
        m["This message has already been sent."] = "Diese Nachricht wurde bereits gesendet."
        m["Too many links in the message: at most 2."] = "Zu viele Links in der Nachricht: höchstens 2."
        m["The message does not look like text: describe the problem or suggestion in words."] = "Die Nachricht sieht nicht wie Text aus: Beschreibe das Problem oder den Vorschlag in Worten."
        m["Information, help during disruption, reduced mobility, Carta Blu, complaints"] = "Informationen, Hilfe bei Störungen, eingeschränkte Mobilität, Carta Blu, Beschwerden"
        m["Italo tickets, changes, refunds and help"] = "Italo-Fahrkarten, Änderungen, Erstattungen und Hilfe"
        m["Italo ticket machines (unstaffed)"] = "Italo-Fahrkartenautomaten (unbesetzt)"
        m["TILO/SBB and Arcobaleno tickets, passes, information and help"] = "TILO/SBB- und Arcobaleno-Fahrkarten, Abos, Informationen und Hilfe"
        m["Live data not yet available"] = "Live-Daten noch nicht verfügbar"
        m["Departed"] = "Abgefahren"
        m[" changes"] = " Umstiege"
        m["Downloading South Tyrol ticket outlets…"] = "Südtiroler Verkaufsstellen werden geladen…"
        m["Locating outlets…"] = "Verkaufsstellen werden lokalisiert…"
        m["Downloading Trenord sales points…"] = "Trenord-Verkaufsstellen werden geladen…"
        m["Downloading ticket office hours…"] = "Öffnungszeiten der Schalter werden geladen…"
        m["Downloading the sales points list…"] = "Liste der Verkaufsstellen wird geladen…"
        m["Downloading the sellers list…"] = "Liste der Verkäufer wird geladen…"
        m["Ticket machine"] = "Fahrkartenautomat"
        m["Price you entered"] = "Von dir eingegebener Preis"
        m["platform not accessible: "] = "Bahnsteig nicht barrierefrei: "
        m["expected back on "] = "voraussichtlich wieder verfügbar am "
        m["Band from the official regional ticket price"] = "Stufe aus dem offiziellen Preis der Regionalfahrkarte"
        m["delay compensation"] = "Entschädigung bei Verspätung"
        m["bikes on trains"] = "Fahrräder im Zug"
        m["children"] = "Kinder"
        m["disability assistance"] = "Hilfe für Menschen mit Behinderung"
        m["lost property"] = "Fundsachen"
        m["ticket validation"] = "Entwertung von Fahrkarten"
        m["bus and taxi at Varese"] = "Bus und Taxi in Varese"
        m["toilets at Saronno"] = "Toiletten in Saronno"
        m["\nLast reported: "] = "\nZuletzt gemeldet: "
        m["\nNext: "] = "\nNächster: "
        m["on time"] = "pünktlich"
        m["FN network"] = "FN-Netz"
        m["Departure and arrival reminders"] = "Erinnerungen an Abfahrt und Ankunft"
        m["Disruptions on favourite routes and lines"] = "Störungen auf Lieblingsstrecken und -linien"
        m["Stop alarm"] = "Haltestellenalarm"
        m["Board at "] = "Einsteigen in "
        m[" at "] = " um "
        m[" · platform "] = " · Gleis "
        m["Alarm before "] = "Alarm vor "
        m["Data temporarily unavailable"] = "Daten vorübergehend nicht verfügbar"
        m[" on time."] = " pünktlich."
        m["\nWith a delay of 60 minutes or more you can claim compensation: see More › Conditions, rights and refunds."] = "\nBei einer Verspätung von 60 Minuten oder mehr kannst du eine Entschädigung verlangen: siehe Mehr › Beförderungsbedingungen, Rechte und Erstattungen."
        m["\nIf you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation."] = "\nMit einer Zeitkarte zählen Verspätungen für den Monatsbonus (Trenord) oder die Entschädigung."
        m["\nI've stopped following the train. Have a good day!"] = "\nIch folge dem Zug nicht mehr. Einen schönen Tag noch!"
        m["trip completed"] = "Fahrt beendet"
        m["Platform change"] = "Gleisänderung"
        m["Wake up! Next stop: "] = "Aufwachen! Nächster Halt: "
        m["Expected arrival at "] = "Voraussichtliche Ankunft um "
        m["Expected departure at "] = "Voraussichtliche Abfahrt um "
        m["Arrival at "] = "Ankunft um "
        m["Departure from "] = "Abfahrt ab "
        m["Warning: the train is cancelled"] = "Achtung: Der Zug fällt aus"
        m["Follow train"] = "Zug folgen"
        m["cancelled"] = "ausgefallen"
        m["It is cancelled."] = "Er fällt aus."
        m["Back on time."] = "Wieder pünktlich."
        m["Alternatives:"] = "Alternativen:"
        m["No alternative found soon: open the app for more options."] = "Bald keine Alternative gefunden: Öffne die App für weitere Optionen."
        m["Refreshing widget…"] = "Widget wird aktualisiert…"
        m["refreshing…"] = "wird aktualisiert…"
        m["Tap to set up"] = "Zum Einrichten tippen"
        m["Tap the title to choose what to show"] = "Tippe auf den Titel, um die Anzeige zu wählen"
        m["Tap ⟳ to refresh"] = "Tippe auf ⟳ zum Aktualisieren"
        m["Refreshes automatically · ⟳ to retry"] = "Aktualisiert sich automatisch · ⟳ zum Wiederholen"
        m["not updated"] = "nicht aktualisiert"
        m["Data service temporarily unreachable"] = "Datendienst vorübergehend nicht erreichbar"
        m["Tap ⟳ to retry"] = "Tippe auf ⟳ zum Wiederholen"
        m["No departures in the next hours"] = "Keine Abfahrten in den nächsten Stunden"
        m["The widget refreshes itself; tap ⟳ to retry"] = "Das Widget aktualisiert sich selbst; tippe auf ⟳ zum Wiederholen"
        m["First departures"] = "Erste Abfahrten"
        m["No trains now: here are the first scheduled"] = "Keine Züge jetzt: Hier die ersten planmäßigen"
        m[" · not updated"] = " · nicht aktualisiert"
        m["Status not available yet"] = "Status noch nicht verfügbar"
        m["Resume following "] = "Verfolgung fortsetzen: "
        m["The phone restarted: tap to keep receiving platform, delay and arrival alerts."] = "Das Handy wurde neu gestartet: Tippe, um weiter Hinweise zu Gleis, Verspätung und Ankunft zu erhalten."
        m["is cancelled."] = "fällt aus."
        m["Search by voice"] = "Per Sprache suchen"
        m["OpenStreetMap servers are not responding. Try again shortly or search Google Maps."] = "Die OpenStreetMap-Server antworten nicht. Versuche es gleich noch einmal oder suche auf Google Maps."
        m["Set up"] = "Einrichten"
        m["Share train status"] = "Zugstatus teilen"
        m["Other apps"] = "Andere Apps"
        m["Resellers"] = "Verkäufer"
        m["Mooney points"] = "Mooney-Verkaufsstellen"
        m["list from"] = "Liste von"
        m["Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney points: see the official Trenitalia map."] = "Im übrigen Italien werden Trenitalia-Regionalfahrkarten bei PuntoLIS- und Mooney-Verkaufsstellen verkauft: siehe die offizielle Trenitalia-Karte."
        m["Official Trenitalia map (all Italy)"] = "Offizielle Trenitalia-Karte (ganz Italien)"
        m["No data for this station. TrovaTreno does not publish the FerrovieNord network: for those stations the app collects arrivals from ViaggiaTreno by itself and data appears here after a few hours."] = "Keine Daten für diesen Bahnhof. TrovaTreno veröffentlicht das FerrovieNord-Netz nicht: Für diese Bahnhöfe sammelt die App die Ankünfte selbst von ViaggiaTreno, und die Daten erscheinen hier nach einigen Stunden."
        m["Average delay "] = "Durchschnittliche Verspätung "
        m["Each box compares only services of the same kind. Based on trains with at least 30 observed arrivals in the month; runs without a category are not included. Regional operators other than Trenord and Trenitalia (Tper, EAV, Ferrovie del Gargano, TUA, BLS…) are identified by route and train number; only those running on the RFI network tracked by ViaggiaTreno are included."] = "Jedes Feld vergleicht nur gleichartige Verbindungen. Basierend auf Zügen mit mindestens 30 beobachteten Ankünften im Monat; Fahrten ohne Kategorie sind nicht enthalten. Andere Regionalunternehmen als Trenord und Trenitalia (Tper, EAV, Ferrovie del Gargano, TUA, BLS…) werden anhand von Strecke und Zugnummer erkannt; nur die im von ViaggiaTreno erfassten RFI-Netz fahrenden sind enthalten."
        m["SBB counts a train as punctual under 3 minutes late (5 in Italy), so the comparison with Italy is conservative. SBB publishes only the previous day: the app collects one per day."] = "Die SBB zählt einen Zug als pünktlich bei unter 3 Minuten Verspätung (5 in Italien), daher ist der Vergleich mit Italien vorsichtig. Die SBB veröffentlicht nur den Vortag: Die App sammelt einen pro Tag."
        m["Their actual times exist as open data (opentransportdata.swiss, \"Ist-Daten\"), but only as a single daily file with all Swiss public transport: hundreds of MB, to be downloaded every day. On a phone that would use too much data and battery, and there is no service returning per-company totals as SBB does. They can be added in future if such a service appears, or with a small server that downloads the file and prepares the totals for the app."] = "Ihre tatsächlichen Zeiten gibt es als Open Data (opentransportdata.swiss, „Ist-Daten“), aber nur als einzelne Tagesdatei mit dem gesamten Schweizer öffentlichen Verkehr: Hunderte MB, täglich herunterzuladen. Auf einem Handy würde das zu viel Datenvolumen und Akku verbrauchen, und es gibt keinen Dienst, der Summen pro Unternehmen liefert wie die SBB. Sie können künftig ergänzt werden, falls ein solcher Dienst erscheint, oder mit einem kleinen Server, der die Datei herunterlädt und die Summen für die App aufbereitet."
        m["TrovaTreno does not publish the FerrovieNord network. The app reads arrivals from ViaggiaTreno by itself: every 80 minutes on Wi-Fi, every 3 hours on mobile data (about 0.3 MB). On time = within 5 minutes. Figures depend on when the phone is on and connected."] = "TrovaTreno veröffentlicht das FerrovieNord-Netz nicht. Die App liest die Ankünfte selbst von ViaggiaTreno: alle 80 Minuten im WLAN, alle 3 Stunden im Mobilfunknetz (etwa 0,3 MB). Pünktlich = innerhalb von 5 Minuten. Die Werte hängen davon ab, wann das Handy an und verbunden ist."
        m["Hi, I'm your Conductor! 🚆 I keep you posted about your train before, during and after the trip: platform, delays, platform changes, cancellations, next stops and arrival. It works with all trains: Trenord, Trenitalia, FerrovieNord, Italo, TILO and SBB."] = "Hallo, ich bin dein Zugbegleiter! 🚆 Ich halte dich vor, während und nach der Fahrt über deinen Zug auf dem Laufenden: Gleis, Verspätungen, Gleisänderungen, Ausfälle, nächste Halte und Ankunft. Es funktioniert mit allen Zügen: Trenord, Trenitalia, FerrovieNord, Italo, TILO und SBB."
        m["Departs"] = "Abfahrt"
        m["Arrives"] = "Ankunft"
        m["Italy"] = "Italien"
        m["International"] = "International"
        m["Long distance"] = "Fernverkehr"
        m["Regional and long distance"] = "Regional- und Fernverkehr"
        m["Real time: ViaggiaTreno (RFI network)"] = "Echtzeit: ViaggiaTreno (RFI-Netz)"
        m["Real time: official Swiss timetable"] = "Echtzeit: offizieller Schweizer Fahrplan"
        m["Real time only on the company's site/app"] = "Echtzeit nur auf der Website/App des Unternehmens"
        m["Scheduled times in the app (Transitous); real time only on the company's site/app"] = "Planmäßige Zeiten in der App (Transitous); Echtzeit nur auf der Website/App des Unternehmens"
        m["Regional and suburban"] = "Regional- und S-Bahn-Verkehr"
        m["Intercity and long distance"] = "Intercity und Fernverkehr"
        m["Plenty of seats"] = "Viele freie Plätze"
        m["Moderately busy: look for seats"] = "Mäßig ausgelastet: Platz suchen"
        m["Very crowded"] = "Sehr voll"
        m["Trenord (sensors or previous days' history)"] = "Trenord (Sensoren oder Verlauf der Vortage)"
        m["SBB forecast"] = "SBB-Prognose"
        m["Binario estimate by time of day"] = "Binario-Schätzung nach Tageszeit"
        m["I can help with:\n• \"delay train 2070\" or \"where is 9544\"\n• \"trains from Varese to Milano\"\n• \"departures from Varese\" / \"arrivals at Como\"\n• \"any strikes?\"\n• \"traffic on S5\" / \"problems at Saronno\"\n• \"elevators at Saronno\"\n• \"guaranteed trains\"\n• \"where is my train?\" (the train you follow)\n• \"next train to Milano\"\n• \"bus, metro and taxi at Milano Centrale\"\n• \"toilets at Saronno\" / \"services at Varese\"\n• \"delay compensation\", \"can I bring my bike?\", \"children\", \"disability assistance\", \"lost property\"\nTap the microphone to ask by voice."] = "Ich kann dir helfen bei:\n• \"Verspätung Zug 2070\" oder \"wo ist 9544\"\n• \"Züge von Varese nach Milano\"\n• \"Abfahrten von Varese\" / \"Ankünfte in Como\"\n• \"gibt es Streiks?\"\n• \"Verkehr auf S5\" / \"Probleme in Saronno\"\n• \"Aufzüge in Saronno\"\n• \"garantierte Züge\"\n• \"wo ist mein Zug?\" (der Zug, dem du folgst)\n• \"nächster Zug nach Milano\"\n• \"Bus, U-Bahn und Taxi in Milano Centrale\"\n• \"Toiletten in Saronno\" / \"Services in Varese\"\n• \"Entschädigung bei Verspätung\", \"kann ich mein Fahrrad mitnehmen?\", \"Kinder\", \"Hilfe für Menschen mit Behinderung\", \"Fundsachen\"\nTippe auf das Mikrofon, um per Sprache zu fragen."
        m["During regional rail strikes trains are normally guaranteed 6:00–9:00 and 18:00–21:00 on weekdays (7:00–10:00 and 18:00–21:00 on holidays). Updated official lists are in More → Guaranteed trains."] = "Bei Streiks im Regionalverkehr sind die Züge normalerweise werktags von 6:00–9:00 und 18:00–21:00 Uhr garantiert (an Feiertagen 7:00–10:00 und 18:00–21:00 Uhr). Aktuelle offizielle Listen findest du unter Mehr → Garantierte Züge."
        m["yes"] = "ja"
        m[", platform not yet shown"] = ", Gleis noch nicht angezeigt"
        m["Delay compensation (EU Regulation 2021/782):\n• 60–119 minutes late on arrival: 25% of the ticket\n• 120 minutes or more: 50%\n• Trenitalia Frecce: compensation also for 30–59 minutes, under Trenitalia's conditions\n• season tickets: own rules (Trenord gives season-ticket bonuses based on line punctuality)\nIf the expected delay exceeds 60 minutes you can also give up the trip with a full refund or be re-routed. The train screen shows whether you are entitled to compensation."] = "Entschädigung bei Verspätung (EU-Verordnung 2021/782):\n• 60–119 Minuten Verspätung bei Ankunft: 25 % der Fahrkarte\n• 120 Minuten oder mehr: 50 %\n• Trenitalia Frecce: Entschädigung auch bei 30–59 Minuten, nach den Bedingungen von Trenitalia\n• Zeitkarten: eigene Regeln (Trenord gewährt Zeitkarten-Boni nach der Pünktlichkeit der Linie)\nÜbersteigt die erwartete Verspätung 60 Minuten, kannst du auch auf die Reise verzichten und den vollen Preis erstattet bekommen oder umgeleitet werden. Der Zugbildschirm zeigt, ob du Anspruch auf Entschädigung hast."
        m["Ticket refund or change: it depends on the fare (cheap offers are often non-refundable). Trenitalia: request on the website or app with the ticket code (PNR). Trenord: from the refunds page. If the train is cancelled or expected more than 60 minutes late a refund is always due."] = "Erstattung oder Umtausch der Fahrkarte: hängt vom Tarif ab (Sparangebote sind oft nicht erstattbar). Trenitalia: Antrag auf der Website oder in der App mit dem Fahrkartencode (PNR). Trenord: über die Erstattungsseite. Fällt der Zug aus oder wird er voraussichtlich mehr als 60 Minuten verspätet sein, steht immer eine Erstattung zu."
        m["Validation: paper regional tickets without date and time must be validated before boarding (validating machine in the station). Digital tickets bought online or in the app already show the train or the day: check on the ticket whether check-in is needed. The nearest validators are in Stations → station → Overview, or More → Nearby resellers."] = "Entwertung: Papier-Regionalfahrkarten ohne Datum und Uhrzeit müssen vor dem Einsteigen entwertet werden (Entwerter im Bahnhof). Digitale Fahrkarten, die online oder in der App gekauft wurden, zeigen bereits den Zug oder den Tag: Prüfe auf der Fahrkarte, ob ein Check-in nötig ist. Die nächsten Entwerter findest du unter Bahnhöfe → Bahnhof → Übersicht oder Mehr → Verkäufer in der Nähe."
        m["Without a valid ticket you pay the fare plus a fine; amounts and how to pay (reduced if you pay at once or within a few days) are in the operator's conditions of carriage. If the ticket machine was broken, tell the conductor straight away."] = "Ohne gültige Fahrkarte zahlst du den Fahrpreis plus ein Bußgeld; Beträge und Zahlungsweise (ermäßigt bei sofortiger Zahlung oder innerhalb weniger Tage) stehen in den Beförderungsbedingungen des Unternehmens. War der Fahrkartenautomat defekt, sage es sofort dem Zugbegleiter."
        m["Bikes and scooters:\n• Trenord (Lombardy): regular, folding, electric bikes and scooters travel free on all trains, at any time, space permitting\n• Trenitalia Regional: usually on trains with the bike symbol, with a supplement\n• Frecce and Italo: normally only folded bikes in a bag\n• TILO: SBB rules in Ticino, Trenord rules in Lombardy"] = "Fahrräder und Roller:\n• Trenord (Lombardei): normale, Falt- und Elektrofahrräder sowie Roller reisen in allen Zügen kostenlos, jederzeit, bei Platzverfügbarkeit\n• Trenitalia Regional: meist in Zügen mit Fahrradsymbol, mit Zuschlag\n• Frecce und Italo: normalerweise nur zusammengeklappte Fahrräder in einer Tasche\n• TILO: SBB-Regeln im Tessin, Trenord-Regeln in der Lombardei"
        m["Pets on trains:\n• Trenord: free within Lombardy (carrier max 70×30×50 cm; dogs with muzzle, leash and registry certificate); not allowed on weekdays 7:00–9:30 and 17:30–19:30; beyond Lombardy an animal supplement is needed\n• Trenitalia: carrier free; on regional trains large dogs pay 50% of 2nd class; on Frecce and Intercity add \"Travel with your dog\" when buying\n• Italo: free up to about 5 kg in a carrier; larger dogs with the \"Dog\" service in Smart and Prima\n• SBB/TILO: free up to 30 cm in a bag; otherwise half fare or dog day pass CHF 25\n• Guide and assistance dogs: always free. Details in More → Travelling with pets."] = "Haustiere im Zug:\n• Trenord: kostenlos innerhalb der Lombardei (Transportbox max. 70×30×50 cm; Hunde mit Maulkorb, Leine und Hunde-Registrierung); werktags 7:00–9:30 und 17:30–19:30 Uhr nicht erlaubt; außerhalb der Lombardei ist ein Tierzuschlag nötig\n• Trenitalia: Transportbox kostenlos; in Regionalzügen zahlen große Hunde 50 % der 2. Klasse; bei Frecce und Intercity beim Kauf \"Reise mit deinem Hund\" hinzufügen\n• Italo: kostenlos bis etwa 5 kg in einer Transportbox; größere Hunde mit dem Service \"Hund\" in Smart und Prima\n• SBB/TILO: kostenlos bis 30 cm in einer Tasche; sonst halber Preis oder Hunde-Tageskarte CHF 25\n• Blinden- und Assistenzhunde: immer kostenlos. Details unter Mehr → Reisen mit Haustieren."
        m["Children:\n• Regional trains in Lombardy: free under 4 without a seat, 50% off from 4 to under 14\n• Trenitalia national trains: free under 4 without a seat, 50% off the Base fare from 4 to under 15\n• Other regions and Italo have their own rules"] = "Kinder:\n• Regionalzüge in der Lombardei: unter 4 Jahren kostenlos ohne Sitzplatz, 50 % Ermäßigung von 4 bis unter 14 Jahren\n• Nationale Trenitalia-Züge: unter 4 Jahren kostenlos ohne Sitzplatz, 50 % Ermäßigung auf den Base-Tarif von 4 bis unter 15 Jahren\n• Andere Regionen und Italo haben eigene Regeln"
        m["Assistance for people with disabilities or reduced mobility:\n• RFI Sala Blu (RFI stations): 800 90 60 60, from mobiles +39 02 32 32 32\n• Trenord: 800 210 955 (daily 8:15–19:45) or +39 02 72 49 49 49; book preferably 48 hours ahead\n• SBB (Ticino): 0800 007 102\nThe station screen shows lifts per platform and current faults."] = "Hilfe für Menschen mit Behinderung oder eingeschränkter Mobilität:\n• RFI Sala Blu (RFI-Bahnhöfe): 800 90 60 60, vom Handy +39 02 32 32 32\n• Trenord: 800 210 955 (täglich 8:15–19:45 Uhr) oder +39 02 72 49 49 49; möglichst 48 Stunden vorher buchen\n• SBB (Tessin): 0800 007 102\nDer Bahnhofsbildschirm zeigt Aufzüge pro Gleis und aktuelle Störungen."
        m["Lost property: tell the conductor straight away. Trenord: 02 72 49 49 49, items kept at the Cadorna and Garibaldi My Link Points for a few days, then at the City of Milan office (via Friuli 30). Trenitalia: lost items search service and Frecciadesk. Italo: Pronto Italo 06 07 08. SBB/TILO: report online at lostandfound.sbb.ch. Details in More → Lost property."] = "Fundsachen: Sage sofort dem Zugbegleiter Bescheid. Trenord: 02 72 49 49 49, Gegenstände werden einige Tage in den My Link Points Cadorna und Garibaldi aufbewahrt, dann im Büro der Stadt Mailand (Via Friuli 30). Trenitalia: Fundsachen-Suchdienst und Frecciadesk. Italo: Pronto Italo 06 07 08. SBB/TILO: online melden unter lostandfound.sbb.ch. Details unter Mehr → Fundsachen."
        m["Strikes and tickets: Trenord refunds on request within 30 days of the strike. Trenitalia refunds from the announcement: Frecce and Intercity up to departure time, regional trains until midnight of the day before. In the guaranteed time bands (weekdays 6–9 and 18–21) the trains on the official list run."] = "Streiks und Fahrkarten: Trenord erstattet auf Antrag innerhalb von 30 Tagen nach dem Streik. Trenitalia erstattet ab der Ankündigung: Frecce und Intercity bis zur Abfahrtszeit, Regionalzüge bis Mitternacht des Vortags. In den garantierten Zeitfenstern (werktags 6–9 und 18–21 Uhr) fahren die Züge der offiziellen Liste."
        m["Cancelled train: you are entitled to a full refund or to travel on the first available train to the same destination. A replacement bus is often provided: see the notices (More → Strikes, traffic and works). Tell me the train number to check it."] = "Ausgefallener Zug: Du hast Anspruch auf volle Erstattung oder auf Weiterfahrt mit dem ersten verfügbaren Zug zum selben Ziel. Oft wird ein Ersatzbus eingesetzt: siehe die Mitteilungen (Mehr → Streiks, Verkehr und Bauarbeiten). Nenne mir die Zugnummer, um es zu prüfen."
        m["Missed connection because of a delay: with a single ticket you can continue on the first available train at no extra cost. For journeys with a change the app shows the minutes to change and warns \"connection at risk\" if the first train is late."] = "Verpasster Anschluss wegen Verspätung: Mit einer durchgehenden Fahrkarte kannst du ohne Mehrkosten mit dem ersten verfügbaren Zug weiterfahren. Bei Reisen mit Umstieg zeigt die App die Umsteigezeit und warnt „Anschluss gefährdet“, wenn der erste Zug verspätet ist."
        m["Luggage: you travel with your own bags in the luggage spaces at no cost for normal use; they must stay under your control and not block aisles and doors. Large stations often have a paid left-luggage office."] = "Gepäck: Du reist mit deinem eigenen Gepäck in den Gepäckbereichen ohne Kosten bei normaler Nutzung; es muss unter deiner Kontrolle bleiben und darf Gänge und Türen nicht blockieren. Große Bahnhöfe haben oft eine kostenpflichtige Gepäckaufbewahrung."
        m["Tickets: on the official websites and apps (Trenitalia, Trenord, Italo), at ticket offices and machines in the station, and at authorised resellers (tobacconists, newsagents). More → Nearby resellers shows ticket offices, machines (also contactless) and resellers near you."] = "Fahrkarten: auf den offiziellen Websites und in den Apps (Trenitalia, Trenord, Italo), an Schaltern und Automaten im Bahnhof und bei autorisierten Verkäufern (Tabakläden, Kioske). Mehr → Verkäufer in der Nähe zeigt Schalter, Automaten (auch kontaktlos) und Verkäufer in deiner Nähe."
        m["Season tickets: Trenord offers monthly and annual tickets and the integrated Io Viaggio passes (train + public transport in Lombardy). Trenitalia has regional and Frecce passes. Season-ticket holders have their own refund and delay-bonus rules."] = "Abos: Trenord bietet Monats- und Jahreskarten und die integrierten Io-Viaggio-Abos (Zug + öffentlicher Verkehr in der Lombardei). Trenitalia hat Regional- und Frecce-Abos. Abo-Inhaber haben eigene Erstattungs- und Verspätungsbonusregeln."
        m["Airports:\n• Malpensa: Malpensa Express from Milano Cadorna and Milano Centrale, stops T1 and T2\n• Linate: metro line M4 (no train)\n• Orio al Serio (Bergamo): bus from Bergamo station\nAsk me for example \"trains from Milano Cadorna to Malpensa\"."] = "Flughäfen:\n• Malpensa: Malpensa Express ab Milano Cadorna und Milano Centrale, Halte T1 und T2\n• Linate: U-Bahn-Linie M4 (kein Zug)\n• Orio al Serio (Bergamo): Bus ab dem Bahnhof Bergamo\nFrag mich zum Beispiel \"Züge von Milano Cadorna nach Malpensa\"."
        m["Switzerland and TILO: trips between Lombardy and Ticino need cross-border tickets (Arcobaleno in CHF or Trenord in euros). TILO lines, fares and services are in More → TILO; for a route ask \"trains from Como to Lugano\"."] = "Schweiz und TILO: Für Reisen zwischen der Lombardei und dem Tessin brauchst du grenzüberschreitende Fahrkarten (Arcobaleno in CHF oder Trenord in Euro). TILO-Linien, Tarife und Services findest du unter Mehr → TILO; für eine Strecke frag \"Züge von Como nach Lugano\"."
        m["Contacts:\n• Trenitalia: 892021 (call centre)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (disability assistance): 800 90 60 60\nFor complaints use the forms on the official websites."] = "Kontakte:\n• Trenitalia: 892021 (Callcenter)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (Hilfe für Menschen mit Behinderung): 800 90 60 60\nFür Beschwerden nutze die Formulare auf den offiziellen Websites."
        m["Your rights (EU Regulation 2021/782): travel information, refund or re-routing if the expected delay exceeds 60 minutes, compensation of 25% (60–119 minutes) or 50% (120+), assistance (drinks, meals, accommodation if needed), free assistance for people with disabilities."] = "Deine Rechte (EU-Verordnung 2021/782): Reiseinformationen, Erstattung oder Umleitung bei erwarteter Verspätung von über 60 Minuten, Entschädigung von 25 % (60–119 Minuten) oder 50 % (ab 120), Betreuung (Getränke, Mahlzeiten, bei Bedarf Unterkunft), kostenlose Hilfe für Menschen mit Behinderung."
        m["Platforms in the app: the scheduled platform comes from the timetable; the actual one (blue) is confirmed by the station. A change is shown in red (e.g. 3 → 5) and, if you follow the train, you get a notification and a voice alert."] = "Gleise in der App: Das planmäßige Gleis stammt aus dem Fahrplan; das tatsächliche (blau) wird vom Bahnhof bestätigt. Eine Änderung wird rot angezeigt (z. B. 3 → 5) und, wenn du dem Zug folgst, erhältst du eine Benachrichtigung und einen Sprachhinweis."
        m["Stop alarm: open the train, tap the stop where you get off and choose \"Wake me before this stop\". It rings when the train leaves the previous stop (or 4 minutes before); with voice alerts you also hear the voice."] = "Haltestellenalarm: Öffne den Zug, tippe auf die Haltestelle zum Aussteigen und wähle \"Weck mich vor dieser Haltestelle\". Er klingelt, wenn der Zug die vorherige Haltestelle verlässt (oder 4 Minuten vorher); mit Sprachhinweisen hörst du auch die Stimme."
        m["Where I board: open the train, tap the stop where you get on and choose \"I board here\". Platform, time and alerts refer to that stop."] = "Wo ich einsteige: Öffne den Zug, tippe auf die Haltestelle zum Einsteigen und wähle \"Ich steige hier ein\". Gleis, Zeit und Hinweise beziehen sich auf diese Haltestelle."
        m["Timetables offline: search the route and tap the PDF icon in the results to download the day's timetable (outbound and return) to Download/Binario. The app also remembers the latest times of every route you searched."] = "Fahrpläne offline: Suche die Strecke und tippe in den Ergebnissen auf das PDF-Symbol, um den Tagesfahrplan (Hin- und Rückfahrt) in Download/Binario herunterzuladen. Die App merkt sich auch die neuesten Zeiten jeder gesuchten Strecke."
        m["Voice alerts: in Settings → Accessibility choose \"All\" or \"Only upcoming stop\". To ask by voice tap the microphone below, or long-press the Binario icon and choose \"Ask by voice\"."] = "Sprachhinweise: Wähle unter Einstellungen → Barrierefreiheit \"Alle\" oder \"Nur nächste Haltestelle\". Um per Sprache zu fragen, tippe unten auf das Mikrofon oder halte das Binario-Symbol gedrückt und wähle \"Per Sprache fragen\"."
        m["Alerts for deaf people: in Settings → Accessibility turn on strong vibration (one pattern per alert) and the flashlight."] = "Hinweise für Gehörlose: Schalte unter Einstellungen → Barrierefreiheit die starke Vibration (ein Muster pro Hinweis) und die Taschenlampe ein."
        m["Widgets: long-press an empty spot on the Home screen → Widgets → Binario. There are Route, Train, Station and Favourites; tap the title to change it."] = "Widgets: Halte eine leere Stelle auf dem Startbildschirm gedrückt → Widgets → Binario. Es gibt Strecke, Zug, Bahnhof und Favoriten; tippe auf den Titel, um ihn zu ändern."
        m["Following a train: open the train and tap \"Follow\": a pinned notification updates every minute and warns of platform changes and delays."] = "Einem Zug folgen: Öffne den Zug und tippe auf \"Folgen\": Eine angeheftete Benachrichtigung wird jede Minute aktualisiert und warnt vor Gleisänderungen und Verspätungen."
        m["Punctuality: More → Punctuality has monthly statistics, with regional trains compared with regional ones and high speed separately, plus every station and train (TrovaTreno.it data)."] = "Pünktlichkeit: Mehr → Pünktlichkeit enthält Monatsstatistiken, wobei Regionalzüge mit Regionalzügen und Hochgeschwindigkeit separat verglichen werden, sowie jeden Bahnhof und Zug (Daten von TrovaTreno.it)."
        m["Milan – Saronno – Varese – Laveno"] = "Mailand – Saronno – Varese – Laveno"
        m["Milan – Saronno – Como"] = "Mailand – Saronno – Como"
        m["Milan – Saronno – Novara"] = "Mailand – Saronno – Novara"
        m["Milan – Seveso – Asso"] = "Mailand – Seveso – Asso"
        m["Brescia – Iseo – Edolo"] = "Brescia – Iseo – Edolo"
        m["Other trains (S lines and Passante)"] = "Weitere Züge (S-Linien und Passante)"
        m["Check for updates"] = "Nach Updates suchen"
        m["Checking…"] = "Wird geprüft…"
        m["You already have the latest version"] = "Du hast bereits die neueste Version"
        m["Couldn't check for updates: check your connection and try again."] = "Die Suche nach Updates war nicht möglich: Prüfe deine Verbindung und versuche es erneut."
        m["Euro amounts are indicative (rate about €1.135 per CHF): the rate may differ at purchase."] = "Die Eurobeträge sind Richtwerte (Kurs etwa 1,135 € pro CHF): Der Kurs kann beim Kauf abweichen."
        m["More actions"] = "Weitere Aktionen"
        m["Not a railway station: opening it on the map"] = "Kein Bahnhof: Öffnung auf der Karte"
        m["Transport:"] = "Verkehrsmittel:"
        m["Trains only"] = "Nur Züge"
        m["Also metro and bus"] = "Auch U-Bahn und Bus"
        m["There are no train-only solutions at this time: solutions with metro or bus are shown too."] = "Zurzeit gibt es keine reinen Zugverbindungen: Es werden auch Verbindungen mit U-Bahn oder Bus angezeigt."
        m["Hidden"] = "Ausgeblendet"
        m["solutions with metro or bus"] = "Verbindungen mit U-Bahn oder Bus"
        m["Prices:"] = "Preise:"
        m["2nd class"] = "2. Klasse"
        m["1st class"] = "1. Klasse"
        m["1st class estimated: check sbb.ch"] = "1. Klasse geschätzt: auf sbb.ch prüfen"
        m["New version available"] = "Neue Version verfügbar"
        m["Tap to download and install"] = "Tippen zum Herunterladen und Installieren"
        m["Quick"] = "Schnell"
        m["Active filters"] = "Aktive Filter"
        m["Nearby stations, toilets, replacement buses, taxis, defibrillators"] = "Nahe Bahnhöfe, WC, Ersatzbusse, Taxis, Defibrillatoren"
        m["Show these options on the Quick page too"] = "Diese Optionen auch auf der Seite Schnell anzeigen"
        m["Send the link or the app file via WhatsApp, Telegram…"] = "Link oder App-Datei per WhatsApp, Telegram… senden"
        m["Or send the app file directly (installed version):"] = "Oder sende die App-Datei direkt (installierte Version):"
        m["App file (APK)"] = "App-Datei (APK)"
        m["The recipient must open it and allow installation. WhatsApp may refuse APK files: in that case use the link."] = "Der Empfänger muss sie öffnen und die Installation erlauben. WhatsApp kann APK-Dateien ablehnen: nutze dann den Link."
        m["Binario, the free app for trains in Italy and Switzerland. Open the file and allow installation."] = "Binario, die kostenlose App für Züge in Italien und der Schweiz. Öffne die Datei und erlaube die Installation."
        m["Could not prepare the app file"] = "App-Datei konnte nicht vorbereitet werden"
    }

    /** 0.1.23: Italo, prezzi migliori, cambi rischiosi, condivisione solo Android. */
    private fun p6(m: HashMap<String, String>) {
        m["Android smartphones and tablets only: it does not work on iPhone and iPad."] = "Nur für Android-Smartphones und -Tablets: funktioniert nicht auf iPhone und iPad."
        m["Risky change"] = "Riskanter Umstieg"
        m["Tight change"] = "Knapper Umstieg"
        m["For this change we recommend at least"] = "Für diesen Umstieg empfohlen: mindestens"
        m["a small delay could make you miss the connection."] = "schon eine kleine Verspätung kann den Anschluss kosten."
        m["Find an alternative with later trains"] = "Alternative mit späteren Zügen suchen"
        m["Two tickets: Italo on italotreno.com, the other train on trenitalia.com or trenord.it"] = "Zwei Fahrkarten: Italo auf italotreno.com, der andere Zug auf trenitalia.com oder trenord.it"
        m["Change station not found"] = "Umsteigebahnhof nicht gefunden"
        m["Arrival station not found"] = "Zielbahnhof nicht gefunden"
        m["Alternatives for the change at"] = "Alternativen zum Umstieg in"
        m["Arriving on"] = "Ankunft mit"
        m["Later trains with at least"] = "Spätere Züge mit mindestens"
        m["min to change"] = "Min. zum Umsteigen"
        m["No alternative found after this time."] = "Keine Alternative nach dieser Uhrzeit gefunden."
        m["Comfortable changes"] = "Entspannte Umstiege"
        m["With tickets for a fixed train and time (Frecce, Italo, Intercity) taking another train may require changing the ticket. Regional tickets are valid on any regional train on the route."] = "Bei Fahrkarten mit fester Zugbindung (Frecce, Italo, Intercity) kann ein anderer Zug einen Ticketumtausch erfordern. Regionaltickets gelten in jedem Regionalzug der Strecke."
        m["Cannot reach the server. Check your connection."] = "Server nicht erreichbar. Prüfe die Verbindung."
        m["Some time bands did not respond: tap to retry"] = "Einige Zeitfenster haben nicht geantwortet: tippen, um es erneut zu versuchen"
        m["Lowest price for 1 adult among trains in that time band (Trenitalia, Trenord and Italo). «—» = no price available, «?» = service not reachable. Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."] = "Niedrigster Preis für 1 Erwachsenen unter den Zügen dieses Zeitfensters (Trenitalia, Trenord und Italo). «—» = kein Preis verfügbar, «?» = Dienst nicht erreichbar. Tippe auf ein Feld, um die Verbindungen zu sehen. Spartarife ändern sich mit der Verfügbarkeit: Es gilt der Preis beim Kauf."
        m["next 7 days, morning, afternoon and evening"] = "nächste 7 Tage, morgens, nachmittags und abends"
        m["Choose origin and destination to see the lowest prices for the next 7 days."] = "Wähle Abfahrt und Ziel, um die niedrigsten Preise der nächsten 7 Tage zu sehen."
    }

    /** 0.1.24: silenzio degli avvisi di sciopero. */
    private fun p7(m: HashMap<String, String>) {
        m["Mute strike alerts"] = "Streikmeldungen stummschalten"
        m["Muted until"] = "Stumm bis"
        m["On · tap to mute them for a while"] = "Aktiv · tippen, um sie eine Weile stummzuschalten"
        m["Turn back on"] = "Wieder aktivieren"
        m["1 hour"] = "1 Stunde"
        m["3 hours"] = "3 Stunden"
        m["8 hours"] = "8 Stunden"
        m["1 week"] = "1 Woche"
        m["1 month"] = "1 Monat"
        m["For how long? Strikes stay visible in News."] = "Wie lange? Streiks bleiben unter Nachrichten sichtbar."
        m["Until a day and time…"] = "Bis zu einem Tag und einer Uhrzeit…"
    }

    /** 0.1.25: passeggeri, menù laterale, prossimo sciopero, notifica del treno seguito. */
    private fun p8(m: HashMap<String, String>) {
        m["Travel"] = "Reise"
        m["Best prices"] = "Bestpreise"
        m["At the station"] = "Im Bahnhof"
        m["Tickets and passes"] = "Fahrkarten und Abos"
        m["Fares"] = "Tarife"
        m["Send feedback"] = "Feedback senden"
        m["Next train strike"] = "Nächster Bahnstreik"
        m.putIfAbsent("Details", "Details")
        m.putIfAbsent("Menu", "Menü")
        m["1 adult"] = "1 Erwachsener"
        m["adults"] = "Erwachsene"
        m["1 child"] = "1 Kind"
        m["children"] = "Kinder"
        m["Passengers"] = "Reisende"
        m["Adults"] = "Erwachsene"
        m["Children"] = "Kinder"
        m["aged 4 to 14 (under 4 free without a seat)"] = "4 bis 14 Jahre (unter 4 kostenlos ohne Sitzplatz)"
        m["Prices shown are the total for all passengers. Discounts for children and families: check when buying."] = "Die angezeigten Preise gelten für alle Reisenden zusammen. Rabatte für Kinder und Familien: beim Kauf prüfen."
        m["Less"] = "Weniger"
        m["More"] = "Mehr"
        m.putIfAbsent("total price", "Gesamtpreis")
        m.putIfAbsent("min early", "Min. zu früh")
        m.putIfAbsent("late", "Verspätung")
        m.putIfAbsent("Refresh", "Aktualisieren")
        m.putIfAbsent("On time", "Pünktlich")
        m.putIfAbsent("Cancelled", "Ausgefallen")
    }

    /** 0.1.26: menù Accessibilità. */
    private fun p9(m: HashMap<String, String>) {
        m["Colour-blind, voice and vibration"] = "Farbenblind, Sprache und Vibration"
    }

    /** Germania: treni, aziende, stazioni e biglietti. */
    private fun p10(m: HashMap<String, String>) {
        m["Trains in Germany"] = "Züge in Deutschland"
        m["Times, delays and platforms in real time for all German operators"] = "Fahrpläne, Verspätungen und Gleise in Echtzeit für alle deutschen Bahnunternehmen"
        m["Search a German station like an Italian one, also by its Italian name: «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Journey search (also Italy ⇄ Germany), departure and arrival boards, train details and «Follow» all work."] = "Suche einen deutschen Bahnhof wie einen italienischen, auch mit dem italienischen Namen: «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Verbindungssuche (auch Italien ⇄ Deutschland), Abfahrts- und Ankunftstafel, Zugdetails und «Folgen» funktionieren."
        m["Data: official German DELFI timetables via Transitous. Prices are not public: buy on bahn.de or in the DB Navigator app."] = "Daten: offizielle deutsche DELFI-Fahrpläne über Transitous. Preise sind nicht öffentlich: Kauf auf bahn.de oder in der App DB Navigator."
        m["Train types"] = "Zugarten"
        m["DB high-speed trains between major cities; seat reservation recommended."] = "DB-Hochgeschwindigkeitszüge zwischen Großstädten; Sitzplatzreservierung empfohlen."
        m["Intercity and EuroCity: long distance, also to Austria, Switzerland and Italy."] = "Intercity und EuroCity: Fernverkehr, auch nach Österreich, in die Schweiz und nach Italien."
        m["Regional trains (DB Regio and many other companies): valid with the Deutschlandticket."] = "Regionalzüge (DB Regio und viele andere Unternehmen): gültig mit dem Deutschlandticket."
        m["City S-Bahn (Munich, Berlin, Hamburg, Stuttgart…): valid with the Deutschlandticket."] = "S-Bahnen der Städte (München, Berlin, Hamburg, Stuttgart…): gültig mit dem Deutschlandticket."
        m["FlixTrain: low-cost long distance, Flix tickets only."] = "FlixTrain: günstiger Fernverkehr, nur mit Flix-Ticket."
        m["Night trains: ÖBB Nightjet and European Sleeper."] = "Nachtzüge: ÖBB Nightjet und European Sleeper."
        m["Monthly pass for all regional trains (RE, RB, S-Bahn), buses, trams and metro in Germany. Not valid on ICE, IC, EC and FlixTrain. Cancel by the 10th of the month. It costs €63 until 31/12/2026 and €66.80 from 1 January 2027."] = "Monatsabo für alle Regionalzüge (RE, RB, S-Bahn), Busse, Straßenbahnen und U-Bahnen in Deutschland. Nicht gültig in ICE, IC, EC und FlixTrain. Kündbar bis zum 10. des Monats. Es kostet 63 € bis 31.12.2026 und 66,80 € ab 1. Januar 2027."
        m["Full fare: valid on any train on the chosen day."] = "Normalpreis: gültig in jedem Zug am gewählten Tag."
        m["Cheaper when bought early, but tied to the chosen train (Zugbindung)."] = "Günstiger bei frühem Kauf, aber an den gewählten Zug gebunden (Zugbindung)."
        m["DB annual discount cards (25% or 50%, or unlimited travel with the 100)."] = "Jährliche Rabattkarten der DB (25 % oder 50 %, oder unbegrenzt reisen mit der 100)."
        m["Buy on bahn.de"] = "Auf bahn.de kaufen"
        m["Deutschlandticket: information and purchase"] = "Deutschlandticket: Infos und Kauf"
        m["DB Navigator app (tickets on your phone)"] = "App DB Navigator (Tickets auf dem Handy)"
        m["Delays: your rights"] = "Verspätungen: deine Rechte"
        m["60 minutes or more late on arrival: 25% of the fare back; 120 minutes or more: 50% (minimum €4)."] = "Ab 60 Minuten Verspätung am Ziel: 25 % des Fahrpreises zurück; ab 120 Minuten: 50 % (mindestens 4 €)."
        m["Expected delay over 20 minutes: train binding is lifted and even with a Sparpreis you can take another train."] = "Erwartete Verspätung über 20 Minuten: die Zugbindung ist aufgehoben, auch mit Sparpreis darfst du einen anderen Zug nehmen."
        m["Expected arrival between midnight and 5 am with at least 60 minutes' delay: taxi refunded up to €120."] = "Ankunft zwischen Mitternacht und 5 Uhr mit mindestens 60 Minuten Verspätung: Taxi bis 120 € wird erstattet."
        m["Claim within 3 months on bahn.de, in DB Navigator or with the Fahrgastrechte form."] = "Antrag innerhalb von 3 Monaten auf bahn.de, im DB Navigator oder mit dem Fahrgastrechte-Formular."
        m["Passenger rights (Fahrgastrechte)"] = "Fahrgastrechte"
        m["Assistance for people with disabilities"] = "Hilfe für Menschen mit Behinderung"
        m["Mon–Fri 6–22, Sat–Sun and holidays 8–20"] = "Mo–Fr 6–22 Uhr, Sa–So und Feiertage 8–20 Uhr"
        m["Book assistance online (by 8 pm the day before)"] = "Hilfe online anmelden (bis 20 Uhr am Vortag)"
        m["Companies and stations"] = "Unternehmen und Bahnhöfe"
        m["All German railway companies"] = "Alle deutschen Bahnunternehmen"
        m["DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… («Germany» filter)"] = "DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… (Filter «Deutschland»)"
        m["Open a German station's board › «Station» tab: services, lifts and accessibility from bahnhof.de"] = "Öffne die Tafel eines deutschen Bahnhofs › Reiter «Bahnhof»: Services, Aufzüge und Barrierefreiheit von bahnhof.de"
        m["Germany: official DELFI timetables with delays and platforms in real time when published (Transitous)."] = "Deutschland: offizielle DELFI-Fahrpläne mit Verspätungen und Gleisen in Echtzeit, sofern veröffentlicht (Transitous)."
        m["Station services (Germany)"] = "Bahnhofsservices (Deutschland)"
        m["Services, shops, DB Lounge and map"] = "Services, Geschäfte, DB Lounge und Plan"
        m["Lifts with real-time status"] = "Aufzüge mit Status in Echtzeit"
        m["Station accessibility"] = "Barrierefreiheit des Bahnhofs"
        m["Assistance for people with disabilities (DB)"] = "Hilfe für Menschen mit Behinderung (DB)"
        m["Valid with the Deutschlandticket"] = "Gültig mit dem Deutschlandticket"
        m["/month"] = "/Monat"
        m["Price and tickets on bahn.de (Sparpreis tied to the train)"] = "Preis und Tickets auf bahn.de (Sparpreis mit Zugbindung)"
        m["ICE, regional trains, S-Bahn, Deutschlandticket, rights and companies"] = "ICE, Regionalzüge, S-Bahn, Deutschlandticket, Rechte und Unternehmen"
        m["Italy, Switzerland and Germany: websites, tickets, data"] = "Italien, Schweiz und Deutschland: Websites, Tickets, Daten"
        m.putIfAbsent("Germany", "Deutschland")
        m["Times and real time in the app: official German DELFI data (Transitous)"] = "Fahrpläne und Echtzeit in der App: offizielle deutsche DELFI-Daten (Transitous)"
        m["Trip not found"] = "Fahrt nicht gefunden"
        m.putIfAbsent("Real time · ", "Echtzeit · ")
        m["Scheduled times (no real time for this trip) · "] = "Planzeiten (für diese Fahrt keine Echtzeit) · "
    }

    /** Puntualità: confronto tra aziende e paesi. */
    private fun p11(m: HashMap<String, String>) {
        m["Companies and countries compared"] = "Unternehmen und Länder im Vergleich"
        m["Companies to compare"] = "Unternehmen zum Vergleich"
        m["Deutsche Bahn · official figures"] = "Deutsche Bahn · offizielle Werte"
        m["Each country measures differently: in Italy (TrovaTreno) and Austria a train is on time within 5 minutes, in Germany under 6 minutes, for SBB under 3 minutes (stricter). DB and ÖBB count stops along the route, TrovaTreno counts arrivals. The fairest comparison is between trains of the same type: use the Regional or Long distance filter."] = "Jedes Land misst anders: in Italien (TrovaTreno) und Österreich ist ein Zug bis 5 Minuten pünktlich, in Deutschland unter 6 Minuten, bei der SBB unter 3 Minuten (strenger). DB und ÖBB zählen die Halte unterwegs, TrovaTreno die Ankünfte. Am fairsten ist der Vergleich zwischen Zügen derselben Art: nutze den Filter Regional oder Fernverkehr."
        m["How to read the comparison"] = "So liest du den Vergleich"
        m["No companies to compare: tap «Add»."] = "Keine Unternehmen im Vergleich: tippe auf «Hinzufügen»."
        m["Remove from comparison"] = "Aus dem Vergleich entfernen"
        m["Some chosen companies have no data yet: they will appear when available."] = "Einige gewählte Unternehmen haben noch keine Daten: sie erscheinen, sobald verfügbar."
        m["Trenord · FerrovieNord network"] = "Trenord · FerrovieNord-Netz"
        m.putIfAbsent("last ", "letzte ")
        m["long distance (Railjet, IC, Nightjet)"] = "Fernverkehr (Railjet, IC, Nightjet)"
        m.putIfAbsent("regional", "Regionalverkehr")
        m["regional and S-Bahn"] = "Regional- und S-Bahn"
        m["ÖBB · official figures"] = "ÖBB · offizielle Werte"
    }

    /** Germania: scioperi e prezzi. */
    private fun p12(m: HashMap<String, String>) {
        m["Train strikes in Germany"] = "Bahnstreiks in Deutschland"
        m["News not reachable right now."] = "Nachrichten gerade nicht erreichbar."
        m["No train strike announced in Germany in the last 14 days."] = "In den letzten 14 Tagen wurde in Deutschland kein Bahnstreik angekündigt."
        m["News in German (Google News): in Germany strikes are announced by the GDL and EVG unions a few days in advance, with no official calendar."] = "Nachrichten auf Deutsch (Google News): In Deutschland kündigen die Gewerkschaften GDL und EVG Streiks wenige Tage vorher an, einen offiziellen Kalender gibt es nicht."
        m["Traffic in Germany: disruptions and engineering works (DB)"] = "Verkehrslage in Deutschland: Störungen und Baustellen (DB)"
        m["Open on bahn.de"] = "Auf bahn.de öffnen"
        m["For trains in Germany prices are not public: the lowest-price calendar is on bahn.de («Bestpreissuche»). With regional trains only, the Deutschlandticket is valid."] = "Für Züge in Deutschland sind die Preise nicht öffentlich: den Kalender mit den günstigsten Preisen gibt es auf bahn.de («Bestpreissuche»). Mit reinen Regionalzügen gilt das Deutschlandticket."
        m["Train strike in Germany"] = "Bahnstreik in Deutschland"
    }

    /** Emergenze per paese, affollamento e accessibilita' all'estero. */
    private fun p13(m: HashMap<String, String>) {
        m.putIfAbsent("Lombardy: Trenord and FerrovieNord trains from Trenord's official timetable (Regione Lombardia Open Data), with the delay from Trenord's live service.", "Lombardei: Trenord- und FerrovieNord-Züge aus dem offiziellen Trenord-Fahrplan (Open Data der Region Lombardei), mit der Verspätung aus dem Live-Dienst von Trenord.")
        m.putIfAbsent("Austria", "Österreich")
        m.putIfAbsent("France", "Frankreich")
        m.putIfAbsent("Germany, Austria, Switzerland and France: running trains placed on the line from the timetable and the realtime data the companies publish (Transitous); where there is no realtime the position follows the timetable.", "Deutschland, Österreich, Schweiz und Frankreich: fahrende Züge auf der Linie platziert nach Fahrplan und den von den Unternehmen veröffentlichten Echtzeitdaten (Transitous); wo es keine Echtzeit gibt, folgt die Position dem Fahrplan.")
        m.putIfAbsent("Finland (GPS)", "Finnland (GPS)")
        m.putIfAbsent("Norway (GPS)", "Norwegen (GPS)")
        m.putIfAbsent("GPS position", "GPS-Position")
        m.putIfAbsent("trains running or about to depart", "Züge unterwegs oder kurz vor der Abfahrt")
        m.putIfAbsent("Location unavailable", "Standort nicht verfügbar")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour. In Italy the position is estimated along the route from the timetable and the last stop (shortly after opening the dots move onto the line); elsewhere it stays around the hub: not GPS. It is a sample, not the whole network. Finland and Norway show the real GPS position (Digitraffic, Entur). Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "Jeder Punkt ist ein Zug, der in der nächsten Stunde von einem Knoten abfährt. In Italien wird die Position entlang der Strecke aus Fahrplan und letztem Halt geschätzt (kurz nach dem Öffnen springen die Punkte auf die Linie); sonst bleibt er rund um den Knoten: kein GPS. Es ist eine Stichprobe, nicht das ganze Netz. Finnland und Norwegen zeigen die echte GPS-Position (Digitraffic, Entur). Quellen: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Gleise: © OpenStreetMap-Mitwirkende, Stil CC-BY-SA 2.0 OpenRailwayMap.")
        m.putIfAbsent("Colored dots by delay, zoom and «Near me»", "Farbige Punkte nach Verspätung, Zoom und «In meiner Nähe»")
        m.putIfAbsent("Alerts for my trip", "Hinweise zu meiner Reise")
        m.putIfAbsent("Minutes from home to the departure station", "Minuten von zu Hause zum Abfahrtsbahnhof")
        m.putIfAbsent("«Leave home» before the outbound train, «Last useful train» in the evening on the return and «Connection at risk» when a delay endangers a change. The departure is the station near home.", "«Von zu Hause losgehen» vor dem Hinfahrtszug, «Letzter nutzbarer Zug» abends auf der Rückfahrt und «Anschluss gefährdet», wenn eine Verspätung einen Umstieg gefährdet. Die Abfahrt ist der Bahnhof in der Nähe von zu Hause.")
        m.putIfAbsent("Leave home", "Von zu Hause losgehen")
        m.putIfAbsent("Leave home by", "Geh spätestens um")
        m.putIfAbsent("for the train at", "für den Zug um")
        m.putIfAbsent("Last useful train", "Letzter nutzbarer Zug")
        m.putIfAbsent("Last useful train to", "Letzter nutzbarer Zug nach")
        m.putIfAbsent("departs at", "fährt um")
        m.putIfAbsent("Connection at risk at", "Anschluss gefährdet in")
        m.putIfAbsent("expected arrival", "voraussichtliche Ankunft")
        m.putIfAbsent("departure", "Weiterfahrt")
        m.putIfAbsent("Your history on this train", "Dein Verlauf auf diesem Zug")
        m.putIfAbsent("Average delay", "Durchschnittliche Verspätung")
        m.putIfAbsent("On time (within 5 min)", "Pünktlich (bis 5 Min.)")
        m.putIfAbsent("Worst", "Schlechtester Wert")
        m.putIfAbsent("Days recorded", "Aufgezeichnete Tage")
        m.putIfAbsent("Data stays on your phone only.", "Daten bleiben nur auf deinem Telefon.")
        m.putIfAbsent("Most punctual among the next trains", "Der pünktlichste unter den nächsten Zügen")
        m.putIfAbsent("runs observed", "beobachtete Fahrten")
        m.putIfAbsent("TrovaTreno data from last month; they do not guarantee today's delay.", "TrovaTreno-Daten des letzten Monats; sie garantieren nicht die heutige Verspätung.")
        m.putIfAbsent("RFI notice on your route", "RFI-Hinweis zu deiner Strecke")
        m.putIfAbsent("Notices on your routes", "Hinweise zu deinen Strecken")
        m.putIfAbsent("Until", "Bis")
        m.putIfAbsent("Timetable notice", "Fahrplanhinweis")
        m.putIfAbsent("From", "Vom")
        m.putIfAbsent("to", "bis")
        m.putIfAbsent("arrival at destination with", "Ankunft am Ziel mit")
        m.putIfAbsent("minutes", "Minuten")
        m.putIfAbsent("Tap for the source", "Tippen für die Quelle")
        m.putIfAbsent("Service interruption between Rho and Parabiago", "Betriebsunterbrechung zwischen Rho und Parabiago")
        m.putIfAbsent("Timetable remodulation 126.1: staff shifts remain unchanged.", "Fahrplananpassung 126.1: Die Dienstpläne des Personals bleiben unverändert.")
        m.putIfAbsent("From the departures of the next hours. High-speed, Intercity and Trenitalia regional trains have no line in the official timetables: they are shown by category and route.", "Aus den Abfahrten der nächsten Stunden. Hochgeschwindigkeits-, Intercity- und Regionalzüge von Trenitalia haben im offiziellen Fahrplan keine Linie: Sie werden nach Kategorie und Strecke angezeigt.")
        m.putIfAbsent("Trenord network / Lombardy", "Trenord-Netz / Lombardei")
        m.putIfAbsent("Other network or region", "Anderes Netz oder andere Region")
        m.putIfAbsent("Over 60 with CartaFreccia: FrecciaSENIOR offer on Frecce trains (from €29). Discounts and conditions detailed on the official page.", "Über 60 mit CartaFreccia: Angebot FrecciaSENIOR auf Frecce-Zügen (ab 29 €). Ermäßigungen und Bedingungen auf der offiziellen Seite.")
        m.putIfAbsent("From age 65, single tickets are 20% off the Lombardy Regional Single Fare; in the STIBM area 25% off ordinary monthly and annual passes (to be loaded on the Io Viaggio card, €10).", "Ab 65 Jahren 20 % Ermäßigung auf Einzelfahrten zum Regionaltarif Lombardei; im STIBM-Gebiet 25 % Ermäßigung auf normale Monats- und Jahresabos (auf die Io-Viaggio-Karte zu laden, 10 €).")
        m.putIfAbsent("Over 60: Italo Senior, 40% to 60% off the Flex fare, in Smart and Prima Business; non-refundable, changeable up to 72 hours before departure.", "Über 60: Italo Senior, 40 bis 60 % Ermäßigung auf den Flex-Tarif, in Smart und Prima Business; nicht erstattbar, bis 72 Stunden vor Abfahrt änderbar.")
        m.putIfAbsent("Reduced General Abonnement (GA) for women from their 64th birthday (from 65 starting in 2028) and for men from 65.", "Ermäßigtes Generalabonnement (GA) für Frauen ab dem 64. Geburtstag (ab 2028 ab dem 65.) und für Männer ab 65.")
        m.putIfAbsent("Senior BahnCard from age 65; the BahnCard 50 (ages 27 to 64) gives 50% off the Flexpreis and 25% off long-distance Sparpreis fares.", "Senioren-BahnCard ab 65 Jahren; die BahnCard 50 (27 bis 64 Jahre) gibt 50 % auf den Flexpreis und 25 % auf die Sparpreise im Fernverkehr.")
        m.putIfAbsent("From age 65, men and women: Vorteilscard Senior at €31 (valid 1 year).", "Ab 65 Jahren, Männer und Frauen: Vorteilscard Senior für 31 € (1 Jahr gültig).")
        m.putIfAbsent("From age 60: Carte Avantage Senior at €49 (confirm the price when buying): 30% off trips in 2nd and 1st class, 60% for up to 3 accompanying children aged 4-11; TER discounts vary by region.", "Ab 60 Jahren: Carte Avantage Senior für 49 € (Preis beim Kauf bestätigen): 30 % auf Fahrten in der 2. und 1. Klasse, 60 % für bis zu 3 begleitende Kinder von 4 bis 11 Jahren; TER-Ermäßigungen je nach Region unterschiedlich.")
        m.putIfAbsent("The prices shown are the total for all passengers.", "Die angezeigten Preise gelten für alle Reisenden zusammen.")
        m.putIfAbsent("Age discounts vary by country and company: here kids are 4 to 14, but other companies use other ages. Family discounts: check when buying.", "Altersermäßigungen unterscheiden sich je nach Land und Unternehmen: hier sind Kinder 4 bis 14 Jahre alt, andere Unternehmen nutzen andere Altersgrenzen. Familienermäßigungen: beim Kauf prüfen.")
        m.putIfAbsent("Age rules for each company", "Altersregeln der einzelnen Unternehmen")
        m.putIfAbsent("Age rules: companies and countries", "Altersregeln: Unternehmen und Länder")
        m.putIfAbsent("Age reductions depend on the country, company, train type and fare. Summary from the official sites (3/11/2026): they may change, always check the source before buying.", "Altersermäßigungen hängen von Land, Unternehmen, Zugart und Tarif ab. Zusammenfassung von den offiziellen Seiten (3.11.2026): Änderungen möglich, prüfe vor dem Kauf immer die Quelle.")
        m.putIfAbsent("National trains: under 4 free without a seat; ages 4 to 14 (until the 15th birthday) 50% off the Base fare.", "Inlandszüge: unter 4 Jahren kostenlos ohne Sitzplatz; 4 bis 14 Jahre (bis zum 15. Geburtstag) 50 % Ermäßigung auf den Base-Tarif.")
        m.putIfAbsent("Regional trains: under 4 free (with an adult, without a seat); ages 4 to under 12 get 50% off. Some regions have their own rules (Lombardy, Campania, Abruzzo, Sardinia, Apulia, Trento, Bolzano).", "Regionalzüge: unter 4 Jahren kostenlos (mit Erwachsenem, ohne Sitzplatz); 4 bis unter 12 Jahre 50 % Ermäßigung. Einige Regionen haben eigene Regeln (Lombardei, Kampanien, Abruzzen, Sardinien, Apulien, Trient, Bozen).")
        m.putIfAbsent("International trains (EuroCity, EuroNight): free up to age 5 without a seat; ages 6 to 14 get the «CHILD» offer (about 50%), varies by service.", "Internationale Züge (EuroCity, EuroNight): bis 5 Jahre kostenlos ohne Sitzplatz; 6 bis 14 Jahre Angebot «CHILD» (etwa 50 %), je nach Verbindung unterschiedlich.")
        m.putIfAbsent("Up to age 3 free on the whole fleet, without taking a seat; ages 4 to under 14 get 50% off the Regional Single Fare; in the STIBM area under-14s travel free (with a document proving their age).", "Bis 3 Jahre kostenlos in der gesamten Flotte, ohne Sitzplatz; 4 bis unter 14 Jahre 50 % Ermäßigung auf den Regionaltarif; im STIBM-Gebiet fahren unter 14-Jährige kostenlos (mit Altersnachweis).")
        m.putIfAbsent("Under 3 free, without an assigned seat and held by an adult (with more than one child per adult a paid seat is required). Italo Family offer for 2–4 people: details on the site.", "Unter 3 Jahren kostenlos, ohne zugewiesenen Sitzplatz und auf dem Arm eines Erwachsenen (bei mehr als einem Kind pro Erwachsenem ist ein kostenpflichtiger Platz nötig). Italo-Familienangebot für 2–4 Personen: Details auf der Website.")
        m.putIfAbsent("Under 6 free; ages 6 to under 16 pay half price (or the minimum fare), or travel free with a parent holding a valid ticket if you have the Junior Card. Under 25: Youth Half-Fare.", "Unter 6 Jahren kostenlos; 6 bis unter 16 Jahre halber Preis (oder Mindestpreis), oder kostenlos mit einem Elternteil mit gültigem Ticket, wenn du die Junior-Karte hast. Unter 25: Halbtax für Junge.")
        m.putIfAbsent("Under 6 free; ages 6 to 14 travel free on long-distance trains when accompanied by an adult or a sibling aged 15 or over. Regional trains and discounted tickets may have different rules.", "Unter 6 Jahren kostenlos; 6 bis 14 Jahre fahren im Fernverkehr kostenlos in Begleitung eines Erwachsenen oder eines Geschwisterkindes ab 15 Jahren. Nahverkehr und Sparangebote können andere Regeln haben.")
        m.putIfAbsent("Under 6 free without a ticket, with an adult; ages 6 to 14 (until the day before the 15th birthday) free with the Vorteilscard Family (€21, up to 4 children), only on ÖBB trains in Austria; from 15 adult fare.", "Unter 6 Jahren kostenlos ohne Ticket, mit einem Erwachsenen; 6 bis 14 Jahre (bis einen Tag vor dem 15. Geburtstag) kostenlos mit der Vorteilscard Family (21 €, bis zu 4 Kinder), nur in ÖBB-Zügen in Österreich; ab 15 Erwachsenentarif.")
        m.putIfAbsent("Under 4 free on the lap (TGV INOUI, TER, Intercités), one child per traveller; own seat with the Forfait Bambin at €9. Ages 4 to 11: 60% off for those accompanying a Carte Avantage Adulte holder. OUIGO has its own fares.", "Unter 4 Jahren kostenlos auf dem Schoß (TGV INOUI, TER, Intercités), ein Kind pro Reisendem; eigener Sitzplatz mit dem Forfait Bambin für 9 €. 4 bis 11 Jahre: 60 % Ermäßigung für Kinder, die einen Inhaber der Carte Avantage Adulte begleiten. OUIGO hat eigene Tarife.")
        m.putIfAbsent("Plan B", "Plan B")
        m.putIfAbsent("Missed the train or the connection? Find alternatives from where you are now.", "Zug oder Anschluss verpasst? Finde Alternativen von deinem aktuellen Standort.")
        m.putIfAbsent("Where you are now", "Wo du jetzt bist")
        m.putIfAbsent("Another station…", "Anderer Bahnhof…")
        m.putIfAbsent("Alternatives to", "Alternativen nach")
        m.putIfAbsent("Looking for alternatives…", "Suche Alternativen…")
        m.putIfAbsent("How Binario works", "So funktioniert Binario")
        m.putIfAbsent("Basic or Full", "Basis oder Vollständig")
        m.putIfAbsent("On the Search screen choose how many features to see. You can change it any time: your choice is saved.", "Wähle auf dem Suchbildschirm, wie viele Funktionen du sehen willst. Du kannst es jederzeit ändern: Die Wahl wird gespeichert.")
        m.putIfAbsent("Offline timetables", "Offline-Fahrpläne")
        m.putIfAbsent("In the results tap «Save these times to use them offline»: you will find them in Offline timetables even without a network.", "Tippe in den Ergebnissen auf «Diese Zeiten für die Offline-Nutzung speichern»: Du findest sie auch ohne Netz unter Offline-Fahrpläne.")
        m.putIfAbsent("Widgets", "Widgets")
        m.putIfAbsent("Long-press the home screen, choose Widgets and add Binario: departures and delays always in sight.", "Halte den Startbildschirm gedrückt, wähle Widgets und füge Binario hinzu: Abfahrten und Verspätungen immer im Blick.")
        m.putIfAbsent("Punctuality", "Pünktlichkeit")
        m.putIfAbsent("Under each icon is the tab name: search a station or a train and see how many arrive on time.", "Unter jedem Symbol steht der Name des Tabs: Suche einen Bahnhof oder Zug und sieh, wie viele pünktlich ankommen.")
        m.putIfAbsent("Got it", "Verstanden")
        m.putIfAbsent("less than a minute ago", "vor weniger als einer Minute")
        m.putIfAbsent("%d min ago", "vor %d Min.")
        m.putIfAbsent("%d h ago", "vor %d Std.")
        m.putIfAbsent("%d days ago", "vor %d Tagen")
        m.putIfAbsent("Timetables saved %s. They may have changed: connect to refresh them.", "Fahrpläne gespeichert %s. Sie können sich geändert haben: Verbinde dich, um sie zu aktualisieren.")
        m.putIfAbsent("Last saved message: the Trenord page is not responding right now.", "Zuletzt gespeicherte Meldung: Die Trenord-Seite antwortet gerade nicht.")
        m.putIfAbsent("The downloaded file is not a valid APK. Try downloading it again.", "Die heruntergeladene Datei ist keine gültige APK. Lade sie erneut herunter.")
        m.putIfAbsent("The downloaded file is not Binario.", "Die heruntergeladene Datei ist nicht Binario.")
        m.putIfAbsent("This version is already installed or is older.", "Diese Version ist bereits installiert oder älter.")
        m.putIfAbsent("Your Binario was installed with a different signature from the updates (for example a test build or another source): Android cannot update it and would show “App not installed”. Uninstall Binario and install the latest version from the download page: you will lose favourites and settings.", "Dein Binario wurde mit einer anderen Signatur als die Updates installiert (z. B. Testversion oder andere Quelle): Android kann es nicht aktualisieren und würde „App nicht installiert“ anzeigen. Deinstalliere Binario und installiere die neueste Version von der Download-Seite: Favoriten und Einstellungen gehen verloren.")
        m.putIfAbsent("Open the download page", "Download-Seite öffnen")
        m.putIfAbsent("Show the message", "Meldung anzeigen")
        m.putIfAbsent("1 source has problems: related features use backups or the latest saved data.", "1 Quelle hat Probleme: Die verknüpften Funktionen nutzen Ersatzquellen oder die zuletzt gespeicherten Daten.")
        m.putIfAbsent("%d sources have problems: related features use backups or the latest saved data.", "%d Quellen haben Probleme: Die verknüpften Funktionen nutzen Ersatzquellen oder die zuletzt gespeicherten Daten.")
        m.putIfAbsent("All sources respond, but some are busy (too many requests): the app uses backups.", "Alle Quellen antworten, einige sind aber ausgelastet (zu viele Anfragen): Die App nutzt Ersatzquellen.")
        m.putIfAbsent("Latest message from Trenord", "Letzte Meldung von Trenord")
        m.putIfAbsent("Reading the message from the Trenord site…", "Meldung wird von der Trenord-Website gelesen…")
        m.putIfAbsent("Message not available right now.", "Meldung gerade nicht verfügbar.")
        m.putIfAbsent("Line status", "Linienstatus")
        m.putIfAbsent("Latest notice", "Letzte Meldung")
        m.putIfAbsent("Show all", "Alles anzeigen")
        m.putIfAbsent("Show less", "Weniger anzeigen")
        m.putIfAbsent("Open the line page", "Linienseite öffnen")
        m.putIfAbsent("Save these times to use them offline", "Diese Zeiten für die Offline-Nutzung speichern")
        m.putIfAbsent("Saved: find it in Offline timetables", "Gespeichert: zu finden unter Offline-Fahrpläne")
        m.putIfAbsent("No saved timetables", "Keine gespeicherten Fahrpläne")
        m.putIfAbsent("To have timetables without a network: search for a trip, then in the results tap «Save these times to use them offline». You will find it here.", "Fahrpläne ohne Netz: Suche eine Fahrt und tippe in den Ergebnissen auf «Diese Zeiten für die Offline-Nutzung speichern». Du findest sie dann hier.")
        m.putIfAbsent("Tap a search to reopen it, even without a network.", "Tippe auf eine Suche, um sie erneut zu öffnen, auch ohne Netz.")
        m.putIfAbsent("Search for a trip", "Fahrt suchen")
        m.putIfAbsent("Busy: too many requests from your address (429). The app tries the other servers and then Postpass; retry in 15 seconds.", "Ausgelastet: zu viele Anfragen von deiner Adresse (429). Die App probiert die anderen Server und dann Postpass; versuche es in 15 Sekunden erneut.")
        m.putIfAbsent("Share of trains on time for each station in the chosen month. Type a name to search, then tap it to open.", "Anteil pünktlicher Züge pro Bahnhof im gewählten Monat. Namen eingeben, dann zum Öffnen antippen.")
        m.putIfAbsent("Share of runs on time for each train in the chosen month. Search by number or destination, then tap it to open.", "Anteil pünktlicher Fahrten pro Zug im gewählten Monat. Nach Nummer oder Ziel suchen, dann zum Öffnen antippen.")
        m.putIfAbsent("Search station", "Bahnhof suchen")
        m.putIfAbsent("Train number or destination", "Zugnummer oder Ziel")
        m.putIfAbsent("Clear", "Löschen")
        m.putIfAbsent("Least punctual", "Am wenigsten pünktlich")
        m.putIfAbsent("Most punctual", "Am pünktlichsten")
        m.putIfAbsent("Milan Passante", "Mailänder Passante")
        m.putIfAbsent("RFI network", "RFI-Netz")
        m.putIfAbsent("FerrovieNord network", "FerrovieNord-Netz")
        m.putIfAbsent("%d results", "%d Ergebnisse")
        m.putIfAbsent("%d results for «%s»", "%d Ergebnisse für «%s»")
        m.putIfAbsent("No results", "Keine Ergebnisse")
        m.putIfAbsent("No alternatives found in the next hours.", "Keine Alternativen in den nächsten Stunden gefunden.")
        m.putIfAbsent("direct", "direkt")
        m.putIfAbsent("changes", "Umstiege")
        m.putIfAbsent("Tap a train to open it. Times are scheduled: check delays and platforms on its page.", "Tippe auf einen Zug, um ihn zu öffnen. Es sind Fahrplanzeiten: Verspätungen und Gleise siehst du auf der Zugseite.")
        m.putIfAbsent("Trains in Austria", "Züge in Österreich")
        m.putIfAbsent("Trains in France", "Züge in Frankreich")
        m.putIfAbsent("Trains in Italy", "Züge in Italien")
        m.putIfAbsent("Features", "Funktionen")
        m.putIfAbsent("Basic", "Einfach")
        m.putIfAbsent("Full", "Vollständig")
        m.putIfAbsent("Estimate: scheduled time plus the known delay.", "Schätzung: Fahrplanzeit plus bekannte Verspätung.")
        m.putIfAbsent("This train usually arrives with", "Dieser Zug kommt meist mit")
        m.putIfAbsent("Updated just now", "Gerade aktualisiert")
        m.putIfAbsent("Data from %d min ago", "Daten von vor %d Min.")
        m.putIfAbsent("tap ↻ to refresh", "↻ zum Aktualisieren tippen")
        m.putIfAbsent("Cancelled today", "Heute ausgefallen")
        m.putIfAbsent("Extra train today", "Zusatzzug heute")
        m.putIfAbsent("Replaced by train", "Ersetzt durch Zug")
        m.putIfAbsent("Runs in place of train", "Fährt anstelle von Zug")
        m.putIfAbsent("Other times", "Andere Tage")
        m.putIfAbsent("replaced by", "ersetzt durch")
        m.putIfAbsent("in place of", "anstelle von")
        m.putIfAbsent("network", "Netz")
        m.putIfAbsent("Trenord · TILO", "Trenord · TILO")
        m.putIfAbsent("All networks", "Alle Netze")
        m.putIfAbsent("Switzerland · SBB", "Schweiz · SBB")
        m.putIfAbsent("All", "Alle")
        m.putIfAbsent("FerrovieNord", "FerrovieNord")
        m.putIfAbsent("RFI", "RFI")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Sources: ViaggiaTreno (Italy, Trenord, FerrovieNord) and transport.opendata.ch (TILO, Switzerland). Trenord and TILO are a single service.", "Stichprobe aus den Abfahrtstafeln der wichtigsten Knoten (nächste Stunden): nicht das ganze Netz. Quellen: ViaggiaTreno (Italien, Trenord, FerrovieNord) und transport.opendata.ch (TILO, Schweiz). Trenord und TILO sind ein gemeinsamer Betrieb.")
        m.putIfAbsent("Italia · RFI", "Italien · RFI")
        m.putIfAbsent("Trenord · rete RFI", "Trenord · RFI-Netz")
        m.putIfAbsent("Trenord · rete FerrovieNord", "Trenord · FerrovieNord-Netz")
        m.putIfAbsent("TILO", "TILO")
        m.putIfAbsent("Svizzera · FFS/SBB", "Schweiz · SBB")
        m.putIfAbsent("Nessun ritardo di 5 minuti o più nei nodi controllati.", "Keine Verspätungen ab 5 Minuten an den geprüften Knoten.")
        m.putIfAbsent("Campione dai tabelloni dei principali nodi (partenze delle prossime ore): non è l'elenco di tutta la rete. Fonti: ViaggiaTreno (Italia, Trenord, FerrovieNord) e transport.opendata.ch (TILO, Svizzera).", "Stichprobe aus den Abfahrtstafeln der wichtigsten Knoten (nächste Stunden): nicht das ganze Netz. Quellen: ViaggiaTreno (Italien, Trenord, FerrovieNord) und transport.opendata.ch (TILO, Schweiz).")
        m.putIfAbsent("Trains in Switzerland", "Züge in der Schweiz")
        m.putIfAbsent("Timetables, delays and platforms of Italian trains (Trenitalia, Italo, Trenord, FerrovieNord and regional railways).", "Fahrpläne, Verspätungen und Gleise italienischer Züge (Trenitalia, Italo, Trenord, FerrovieNord und Regionalbahnen).")
        m.putIfAbsent("Timetables, delays and platforms of Swiss trains (SBB, TILO and regional railways), with crowding and station services where SBB publishes them.", "Fahrpläne, Verspätungen und Gleise Schweizer Züge (SBB, TILO und Regionalbahnen), mit Auslastung und Bahnhofsservices, wo die SBB sie veröffentlichen.")
        m.putIfAbsent("Search a station by name, a train by number, or a route. Journey search, departure board, train page and “Follow” work.", "Suche einen Bahnhof nach Namen, einen Zug nach Nummer oder eine Strecke. Verbindungssuche, Abfahrtstafel, Zugseite und „Folgen“ funktionieren.")
        m.putIfAbsent("Data: ViaggiaTreno, Trenord and Italo. Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "Daten: ViaggiaTreno, Trenord und Italo. Die Echtzeitdaten hängen davon ab, was die Unternehmen veröffentlichen, und können bei einigen Zügen fehlen. Maßgeblich sind immer Anzeigetafeln und Durchsagen.")
        m.putIfAbsent("Data: SBB (open data). Real-time depends on what the operators publish and may be missing for some trains. Boards and announcements always prevail.", "Daten: SBB (offene Daten). Die Echtzeitdaten hängen davon ab, was die Unternehmen veröffentlichen, und können bei einigen Zügen fehlen. Maßgeblich sind immer Anzeigetafeln und Durchsagen.")
        m.putIfAbsent("Timetables, delays and platforms of Austrian trains (ÖBB, Westbahn and regional operators), when real-time data is published.", "Fahrpläne, Verspätungen und Gleise österreichischer Züge (ÖBB, Westbahn und Regionalbahnen), wenn Echtzeitdaten veröffentlicht sind.")
        m.putIfAbsent("Timetables, delays and platforms of French trains (TGV, TER, Intercités, RER), when real-time data is published.", "Fahrpläne, Verspätungen und Gleise französischer Züge (TGV, TER, Intercités, RER), wenn Echtzeitdaten veröffentlicht sind.")
        m.putIfAbsent("Search the station with its Italian name too: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Trip search (also with Italy), station board, train page and «Follow» all work.", "Suche den Bahnhof auch mit dem italienischen Namen: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Reisesuche (auch mit Italien), Tafel, Zugseite und «Folgen» funktionieren.")
        m.putIfAbsent("Data: official timetables via Transitous; real time depends on what operators publish and may be missing for some trips. Prices are not public: tickets on the official sites. Station boards and announcements always prevail.", "Daten: offizielle Fahrpläne über Transitous; Echtzeit hängt von den Veröffentlichungen der Bahnen ab und kann bei manchen Fahrten fehlen. Preise sind nicht öffentlich: Tickets auf den offiziellen Seiten. Maßgeblich sind immer Anzeigetafeln und Durchsagen.")
        m.putIfAbsent("Tickets and official information", "Tickets und offizielle Informationen")
        m.putIfAbsent("Prices for these trains are not public: the lowest-price calendar is on the operators' sites (ÖBB, SNCF) or on bahn.de.", "Die Preise für diese Züge sind nicht öffentlich: den Kalender mit den günstigsten Preisen findest du auf den Seiten der Bahnen (ÖBB, SNCF) oder auf bahn.de.")
        m.putIfAbsent("Austria and France: official timetables with real-time delays and platforms when published (Transitous).", "Österreich und Frankreich: offizielle Fahrpläne mit Echtzeit-Verspätungen und Gleisen, wenn veröffentlicht (Transitous).")
        m.putIfAbsent("Prices and tickets on the operators' sites (ÖBB, SNCF) or on bahn.de", "Preise und Tickets auf den Seiten der Bahnen (ÖBB, SNCF) oder auf bahn.de")
        m.putIfAbsent("Sharing? When the time is right…", "Teilen? Wenn die Zeit gekommen ist…")
        m.putIfAbsent("Unofficial app: not affiliated with, sponsored or endorsed by Trenitalia, RFI, Italo, Trenord or any other transport company. Data comes from public sources.", "Inoffizielle App: nicht verbunden mit, gesponsert oder unterstützt von Trenitalia, RFI, Italo, Trenord oder anderen Verkehrsunternehmen. Die Daten stammen aus öffentlichen Quellen.")
        m.putIfAbsent("Tap again for the board and services", "Noch einmal tippen für Tafel und Services")
        m.putIfAbsent("Services near this station", "Services in der Nähe dieses Bahnhofs")
        m.putIfAbsent("Board", "Tafel")
        m.putIfAbsent("Platform ", "Gleis ")
        m.putIfAbsent("Delay now: ", "Verspätung jetzt: ")
        m.putIfAbsent("Scheduled times: the delay may change. Created with Binario.", "Planmäßige Zeiten: Die Verspätung kann sich ändern. Erstellt mit Binario.")
        m.putIfAbsent("Tracks", "Gleise")
        m.putIfAbsent("Ahead", "Vorne")
        m.putIfAbsent("Behind", "Hinten")
        m.putIfAbsent("Trains ahead and behind yours", "Züge vor und hinter deinem")
        m.putIfAbsent("Compared at the next stop: ", "Vergleich am nächsten Halt: ")
        m.putIfAbsent("Your train", "Dein Zug")
        m.putIfAbsent("The train ahead is running late and could slow yours down.", "Der Zug vor dir hat Verspätung und könnte deinen ausbremsen.")
        m.putIfAbsent("Trains in the same direction passing that stop in the 45 minutes before and after yours. Source: ViaggiaTreno.", "Züge in gleicher Richtung, die in den 45 Minuten vor und nach deinem an diesem Halt vorbeikommen. Quelle: ViaggiaTreno.")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.", "Jeder Punkt ist ein Zug, der in der nächsten Stunde von einem Knoten abfährt, rund um den Knoten angeordnet: nicht seine GPS-Position. Es ist eine Stichprobe, nicht das ganze Netz. Quellen: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Gleise: © OpenStreetMap-Mitwirkende, Stil CC-BY-SA 2.0 OpenRailwayMap.")
        m.putIfAbsent("Watch and smartwatch", "Uhr und Smartwatch")
        m.putIfAbsent("Followed train status on the watch too", "Status des verfolgten Zuges auch auf der Uhr")
        m.putIfAbsent("Sends a normal (not pinned) notification when the delay, platform or next stop changes, so Mi Band, Wear OS and other watches show it.", "Sendet eine normale (nicht angeheftete) Benachrichtigung, wenn sich Verspätung, Gleis oder nächster Halt ändern, damit Mi Band, Wear OS und andere Uhren sie anzeigen.")
        m.putIfAbsent("Send a test notification", "Testbenachrichtigung senden")
        m.putIfAbsent("Test: if you see this on your watch, all is well.", "Test: Wenn du das auf deiner Uhr siehst, ist alles in Ordnung.")
        m.putIfAbsent("Watch status", "Status auf der Uhr")
        m.putIfAbsent("Binario does not talk to the watch directly: notifications (alerts, strikes, platform changes, delays, reminders) reach your wrist through the watch's own app. Mi Band: in Mi Fitness or Zepp Life open your device › Notifications and reminders › App alerts and turn on Binario. Wear OS: they arrive on their own (check in the Wear OS app › Notifications). In both cases set Binario to «no restrictions» in battery settings. The pinned train notification (with «Stop following») is usually not forwarded: that is why the separate alerts above exist.", "Binario spricht nicht direkt mit der Uhr: Benachrichtigungen (Warnungen, Streiks, Gleiswechsel, Verspätungen, Erinnerungen) erreichen dein Handgelenk über die App der Uhr. Mi Band: In Mi Fitness oder Zepp Life dein Gerät öffnen › Benachrichtigungen und Erinnerungen › App-Benachrichtigungen und Binario aktivieren. Wear OS: Sie kommen von selbst (in der Wear-OS-App unter Benachrichtigungen prüfen). Stelle Binario in beiden Fällen in den Akkueinstellungen auf «keine Einschränkungen». Die angeheftete Zugbenachrichtigung (mit «Nicht mehr folgen») wird meist nicht weitergeleitet: Deshalb gibt es die separaten Meldungen oben.")
        m.putIfAbsent("Cancelled", "Ausgefallen")
        m.putIfAbsent("Next: ", "Nächster: ")
        m.putIfAbsent("Pl. ", "Gl. ")
        m.putIfAbsent("Delays right now: Italy, Switzerland, Germany", "Verspätungen jetzt: Italien, Schweiz, Deutschland")
        m.putIfAbsent("Not enough data right now", "Im Moment nicht genug Daten")
        m.putIfAbsent("Trains by delay band", "Züge nach Verspätungsstufe")
        m.putIfAbsent("Average delay", "Durchschnittliche Verspätung")
        m.putIfAbsent("On time (up to 5 min)", "Pünktlich (bis 5 Min.)")
        m.putIfAbsent("Trains with a delay reading", "Züge mit gemessener Verspätung")
        m.putIfAbsent("Hubs with the highest average delay", "Knoten mit der höchsten durchschnittlichen Verspätung")
        m.putIfAbsent("Sample of trains departing from the big hubs in the next hour, not the whole network. For Italian trains the delay is known only after departure from the origin (ViaggiaTreno): so only trains with a delay reading are counted, and the comparison with Switzerland and Germany, which also give the predicted delay, is only indicative. For monthly statistics and the comparison between companies see below.", "Stichprobe der Züge, die in der nächsten Stunde von den großen Knoten abfahren, nicht das ganze Netz. Bei italienischen Zügen ist die Verspätung erst nach der Abfahrt am Startbahnhof bekannt (ViaggiaTreno): deshalb werden nur Züge mit gemessener Verspätung gezählt, und der Vergleich mit der Schweiz und Deutschland, die auch die prognostizierte Verspätung liefern, ist nur ein Anhaltspunkt. Monatsstatistiken und Unternehmensvergleich siehe unten.")
        m.putIfAbsent("Train map", "Zugkarte")
        m.putIfAbsent("Delay", "Verspätung")
        m.putIfAbsent("Send by email", "Per E-Mail senden")
        m.putIfAbsent("Info and sources", "Infos und Quellen")
        m.putIfAbsent("Rainbow theme", "Regenbogen-Design")
        m.putIfAbsent("Each tile has a rainbow colour", "Jede Kachel hat eine Regenbogenfarbe")
        m.putIfAbsent("Custom colours", "Eigene Farben")
        m.putIfAbsent("Choose your own main colour", "Wähle selbst die Hauptfarbe")
        m.putIfAbsent("Main colour", "Hauptfarbe")
        m.putIfAbsent("Colour code (hex)", "Farbcode (Hex)")
        m.putIfAbsent("Dark background", "Dunkler Hintergrund")
        m.putIfAbsent("Apply", "Anwenden")
        m.putIfAbsent("Text size", "Textgröße")
        m.putIfAbsent("Large", "Groß")
        m.putIfAbsent("Very large", "Sehr groß")
        m.putIfAbsent("Huge", "Riesig")
        m.putIfAbsent("Enlarges the text across the app; lines wrap instead of being cut off.", "Vergrößert die Schrift in der ganzen App; Zeilen werden umgebrochen statt abgeschnitten.")
        m.putIfAbsent("Weather at", "Wetter in")
        m.putIfAbsent("Feels like", "Gefühlt")
        m.putIfAbsent("Wind", "Wind")
        m.putIfAbsent("Arriving", "Einfahrt")
        m.putIfAbsent("Departs in", "Abfahrt in")
        m.putIfAbsent("Last 30 days history", "Verlauf der letzten 30 Tage")
        m.putIfAbsent("Cancelled", "Ausgefallen")
        m.putIfAbsent("Measured on arrival at", "Gemessen bei Ankunft in")
        m.putIfAbsent("runs operated", "durchgeführte Fahrten")
        m.putIfAbsent("Data collected by Binario, unofficial.", "Von Binario gesammelte Daten, inoffiziell.")
        m.putIfAbsent("Delay ranking", "Verspätungsrangliste")
        m.putIfAbsent("By day", "Nach Tag")
        m.putIfAbsent("30 days", "30 Tage")
        m.putIfAbsent("Sample from the main hubs: not the list of the whole network.", "Stichprobe der wichtigsten Knoten, nicht das ganze Netz.")
        m.putIfAbsent("Most delayed", "Am verspätetsten")
        m.putIfAbsent("Most punctual", "Am pünktlichsten")
        m.putIfAbsent("runs", "Fahrten")
        m.putIfAbsent("The history is still filling up.", "Der Verlauf füllt sich noch.")
        m.putIfAbsent("Binario collects delays every day: in a few days the ranking will be here.", "Binario sammelt täglich Verspätungen: in einigen Tagen erscheint hier die Rangliste.")
        m.putIfAbsent("Last 30 days, trains observed by Binario", "Letzte 30 Tage, von Binario beobachtete Züge")
        m.putIfAbsent("Choose the style", "Stil wählen")
        m.putIfAbsent("The style changes colours, shapes and the layout of the Home, widgets included. You can change it whenever you like.", "Der Stil ändert Farben, Formen und Aufbau der Startseite, auch in den Widgets. Du kannst ihn jederzeit ändern.")
        m.putIfAbsent("The usual look, green", "Das gewohnte Aussehen, grün")
        m.putIfAbsent("Dark amber Solari board", "Dunkle Solari-Tafel in Bernstein")
        m.putIfAbsent("Find a train", "Zug suchen")
        m.putIfAbsent("By number or line", "Nach Nummer oder Linie")
        m.putIfAbsent("Arrivals and departures", "Ankünfte und Abfahrten")
        m.putIfAbsent("Around you", "In deiner Nähe")
        m.putIfAbsent("Train map", "Zugkarte")
        m.putIfAbsent("Where they are now", "Wo sie jetzt sind")
        m.putIfAbsent("Who is most delayed", "Wer am meisten Verspätung hat")
        m.putIfAbsent("What changes", "Was sich ändert")
        m.putIfAbsent("Alarms and reminders", "Wecker und Erinnerungen")
        m.putIfAbsent("Saved on the phone", "Auf dem Handy gespeichert")
        m.putIfAbsent("Statistics", "Statistiken")
        m.putIfAbsent("Refunds", "Erstattungen")
        m.putIfAbsent("Passenger rights", "Fahrgastrechte")
        m.putIfAbsent("Help", "Hilfe")
        m.putIfAbsent("Frequently asked questions", "Häufige Fragen")
        m.putIfAbsent("Clear", "Klar")
        m.putIfAbsent("Partly cloudy", "Leicht bewölkt")
        m.putIfAbsent("Overcast", "Bedeckt")
        m.putIfAbsent("Fog", "Nebel")
        m.putIfAbsent("Drizzle", "Nieselregen")
        m.putIfAbsent("Rain", "Regen")
        m.putIfAbsent("Snow", "Schnee")
        m.putIfAbsent("Showers", "Schauer")
        m.putIfAbsent("Thunderstorm", "Gewitter")
        m.putIfAbsent("Variable", "Wechselhaft")
        m.putIfAbsent("Light tiles", "Helle Kacheln")
        m.putIfAbsent("White tiles on a light blue background, blue header", "Weiße Kacheln auf hellblauem Grund, blaue Kopfzeile")
        m.putIfAbsent("Coloured tiles", "Bunte Kacheln")
        m.putIfAbsent("Each function has its own pastel colour", "Jede Funktion hat ihre eigene Pastellfarbe")
        m.putIfAbsent("Dark board", "Dunkle Tafel")
        m.putIfAbsent("Black and gold, fixed-width numbers", "Schwarz und Gold, Zahlen in Festbreite")
        m.putIfAbsent("Wide-tile list", "Liste mit breiten Kacheln")
        m.putIfAbsent("Wide rows split into sections", "Breite Zeilen nach Abschnitten")
        m.putIfAbsent("My train up front", "Mein Zug im Vordergrund")
        m.putIfAbsent("Your next train on top, with a countdown", "Oben dein nächster Zug mit Countdown")
        m.putIfAbsent("Four big tiles and a list", "Vier große Kacheln und eine Liste")
        m.putIfAbsent("Four big tiles, then rows for the rest", "Vier große Kacheln, der Rest als Zeilen")
        m.putIfAbsent("Lines and codes", "Linien und Kürzel")
        m.putIfAbsent("Rows with a coloured code on the left, like on the lines", "Zeilen mit farbigem Kürzel links, wie bei den Linien")
        m.putIfAbsent("High contrast", "Hoher Kontrast")
        m.putIfAbsent("Black and yellow, big tiles and thick borders", "Schwarz und Gelb, große Kacheln und dicke Ränder")
        m.putIfAbsent("Three columns by section", "Drei Spalten nach Abschnitten")
        m.putIfAbsent("Compact icons in three columns, with sections", "Kompakte Symbole in drei Spalten, mit Abschnitten")
        m.putIfAbsent("Today's dashboard", "Dashboard von heute")
        m.putIfAbsent("Last 30 days, current delays and shortcuts", "Letzte 30 Tage, aktuelle Verspätungen und Kurzbefehle")
        m.putIfAbsent("Fixes, service status, privacy", "Korrekturen, Dienststatus, Datenschutz")
        m.putIfAbsent("Weather at the station (Open-Meteo)", "Wetter am Bahnhof (Open-Meteo)")
        m.putIfAbsent("Real time", "Echtzeit")
        m.putIfAbsent("Mine", "Meine")
        m.putIfAbsent("Prefer to write by email?", "Lieber per E-Mail schreiben?")
        m.putIfAbsent("Conditions and fares by company", "Bedingungen und Tarife nach Unternehmen")
        m.putIfAbsent("Fares and tickets", "Tarife und Tickets")
        m.putIfAbsent("Rights and refunds", "Rechte und Erstattungen")
        m.putIfAbsent("Source: official website of", "Quelle: offizielle Website von")
        m.putIfAbsent("links checked on", "Links geprüft am")
        m.putIfAbsent("Conditions and fares change: the app opens each company's official pages without copying their prices. The company's own text prevails.", "Bedingungen und Tarife ändern sich: Die App öffnet die offiziellen Seiten jedes Unternehmens und kopiert keine Preise. Maßgeblich ist der Text des Unternehmens.")
        m.putIfAbsent("Trains departing soon from the main hubs of Italy, Switzerland and Germany, coloured by delay", "Züge, die bald von den wichtigsten Knoten in Italien, der Schweiz und Deutschland abfahren, nach Verspätung gefärbt")
        m.putIfAbsent("On time", "Pünktlich")
        m.putIfAbsent("1–5 min late", "1–5 Min. Verspätung")
        m.putIfAbsent("6–14 min late", "6–14 Min. Verspätung")
        m.putIfAbsent("15+ min late", "15+ Min. Verspätung")
        m.putIfAbsent("Delay n.a.", "Verspätung n. v.")
        m.putIfAbsent("Trains shown", "Angezeigte Züge")
        m.putIfAbsent("Open train", "Zug öffnen")
        m.putIfAbsent("Refresh", "Aktualisieren")
        m.putIfAbsent("Italy", "Italien")
        m.putIfAbsent("Switzerland", "Schweiz")
        m.putIfAbsent("Germany", "Deutschland")
        m.putIfAbsent("Each dot is a train departing from a hub in the next hour, placed around the hub: not its GPS position. It is a sample, not the whole network. Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous.", "Jeder Punkt ist ein Zug, der in der nächsten Stunde von einem Knoten abfährt, rund um den Knoten angeordnet: nicht seine GPS-Position. Es ist eine Stichprobe, nicht das ganze Netz. Quellen: ViaggiaTreno, SBB (transport.opendata.ch), Transitous.")
        m.putIfAbsent("App style", "App-Stil")
        m.putIfAbsent("Traditional", "Traditionell")
        m.putIfAbsent("Vintage (split-flap board)", "Vintage (Klappanzeige)")
        m.putIfAbsent("Refreshing the board…", "Tafel wird aktualisiert…")
        m.putIfAbsent("TAP THE TITLE TO CHOOSE", "TITEL ANTIPPEN ZUM WÄHLEN")
        m.putIfAbsent("NO DATA", "KEINE DATEN")
        m.putIfAbsent("Departure board style", "Stil der Abfahrtstafeln")
        m.putIfAbsent("Classic", "Klassisch")
        m.putIfAbsent("Vintage (split-flap)", "Vintage (Klappanzeige)")
        m.putIfAbsent(". After the timetable change buses may be missing until Trenord publishes the new file.", ". Nach dem Fahrplanwechsel können Busse fehlen, bis Trenord die neue Datei veröffentlicht.")
        m.putIfAbsent(": Transitous timetables are used for Trenord instead.", ": Für Trenord werden stattdessen die Fahrpläne von Transitous verwendet.")
        m.putIfAbsent("Sources: official Trenord GTFS timetable from Lombardy Region open data (Transitous as a fallback); Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements.", "Quellen: offizieller Trenord-GTFS-Fahrplan aus den Open Data der Region Lombardei (Transitous als Ersatz); Trenitalia und SBB über Transitous (transitous.org); Busse auf der Tafel von ViaggiaTreno (RFI). Jede Fahrt nennt ihre Quelle. Die Zeiten sind planmäßig: bei Störungen folge den Durchsagen im Bahnhof.")
        m.putIfAbsent("The Trenord replacement-bus timetable is valid until", "Der Fahrplan der Trenord-Ersatzbusse gilt bis")
        m.putIfAbsent("The Trenord timetable file (Lombardy Region) expired on", "Die Trenord-Fahrplandatei (Region Lombardei) ist abgelaufen am")
        m.putIfAbsent("Lombardy Region open data · official Trenord timetable (GTFS)", "Open Data der Region Lombardei · offizieller Trenord-Fahrplan (GTFS)")
        m.putIfAbsent("Which time is most punctual", "Welche Abfahrt ist am pünktlichsten")
        m.putIfAbsent("on time", "pünktlich")
        m.putIfAbsent("Each option counts as its least punctual train. Statistics of the latest month, not a forecast: strikes and works can change everything.", "Jede Verbindung zählt mit ihrem unpünktlichsten Zug. Statistik des letzten Monats, keine Prognose: Streiks und Bauarbeiten können alles ändern.")
        m.putIfAbsent("Text copied", "Text kopiert")
        m.putIfAbsent("Copy the request text", "Text des Antrags kopieren")
        m.putIfAbsent("Most delayed trains right now", "Züge mit der größten Verspätung jetzt")
        m.putIfAbsent("No significant delays at the main hubs, or the service is not responding.", "Keine nennenswerten Verspätungen an den wichtigsten Knoten, oder der Dienst antwortet nicht.")
        m.putIfAbsent("Sample from the departure boards of the main hubs (next few hours): not a list of the whole network. Source: ViaggiaTreno.", "Stichprobe aus den Abfahrtstafeln der wichtigsten Knoten (nächste Stunden): keine Liste des gesamten Netzes. Quelle: ViaggiaTreno.")
        m.putIfAbsent("Dual numbering", "Doppelte Nummerierung")
        m.putIfAbsent("This service changes number when it passes from one network to another (RFI, FerrovieNord, SBB).", "Diese Fahrt wechselt die Nummer, wenn sie von einem Netz ins andere übergeht (RFI, FerrovieNord, SBB).")
        m.putIfAbsent("From the official Trenord timetables in force: the numbers can change with every timetable change.", "Aus den geltenden offiziellen Trenord-Fahrplänen: Die Nummern können sich bei jedem Fahrplanwechsel ändern.")
        m.putIfAbsent("After", "Nach")
        m.putIfAbsent("the train becomes", "wird der Zug zur Nummer")
        m.putIfAbsent("Reported by ViaggiaTreno.", "Von ViaggiaTreno gemeldet.")
        m.putIfAbsent("Strike tomorrow", "Streik morgen")
        m.putIfAbsent("Line", "Linie")
        m.putIfAbsent("Line page", "Seite der Linie")
        m.putIfAbsent("Tap for the official line page: stops, timetables and notices.", "Tippe für die offizielle Seite der Linie: Halte, Fahrpläne und Hinweise.")
        m.putIfAbsent("Lines through this station", "Linien über diesen Bahnhof")
        m.putIfAbsent("From the departures of the next few hours. Frecce, Intercity and Trenitalia regional trains have no line in the official timetables.", "Aus den Abfahrten der nächsten Stunden. Frecce, Intercity und Regionalzüge von Trenitalia haben in den amtlichen Fahrplänen keine Linie.")
        m.putIfAbsent("Official website", "Offizielle Website")
        m["Automatic (mobile network)"] = "Automatisch (Mobilfunknetz)"
        m.putIfAbsent("Germany", "Deutschland")
        m.putIfAbsent("Italy", "Italien")
        m["Country for emergencies and defibrillators"] = "Land für Notfälle und Defibrillatoren"
        m["Expected occupancy in DB Navigator"] = "Erwartete Auslastung im DB Navigator"
        m["Expected occupancy on sbb.ch"] = "Erwartete Auslastung auf sbb.ch"
        m["SBB assistance for people with disabilities (Contact Center Handicap)"] = "SBB-Hilfe für Menschen mit Behinderung (Contact Center Handicap)"
        m["No official data: DB publishes expected occupancy only in DB Navigator and on bahn.de. This is an estimate by time of day."] = "Keine offiziellen Daten: Die DB veröffentlicht die erwartete Auslastung nur im DB Navigator und auf bahn.de. Hier eine Schätzung nach Tageszeit."
        m["German companies do not publish per-train services (wheelchair spaces, bikes) in open data: you can find them in DB Navigator or on bahn.de. "] = "Deutsche Bahnunternehmen veröffentlichen die Services einzelner Züge (Rollstuhlplätze, Fahrräder) nicht als offene Daten: du findest sie im DB Navigator oder auf bahn.de. "
        m.putIfAbsent("Switzerland", "Schweiz")
        m["The Rega (air rescue) app sends your location to the operations centre. Ambulance: 144."] = "Die App der Rega (Luftrettung) sendet deinen Standort an die Einsatzzentrale. Ambulanz: 144."
        m["The official emergency app of the German federal states: reach 112 and 110 also in writing, with your location."] = "Die offizielle Notruf-App der Bundesländer: 112 und 110 auch schriftlich erreichen, mit deinem Standort."
        m.putIfAbsent("Train cancelled", "Zug fällt aus")
        m.putIfAbsent("Train heavily delayed", "Zug mit starker Verspätung")
        m.putIfAbsent("No connection", "Keine Verbindung")
        m.putIfAbsent("Last reading: %d min ago", "Letzte Messung: vor %d Min.")
        m.putIfAbsent("It updates as soon as the network is back.", "Wird aktualisiert, sobald das Netz zurück ist.")
    }

    private fun p14(m: HashMap<String, String>) {
        m.putIfAbsent("No connection. Check your Wi-Fi or mobile data.", "Keine Verbindung. Prüfe WLAN oder mobile Daten.")
        m.putIfAbsent("The service is not responding. Try again shortly.", "Der Dienst antwortet nicht. Versuche es gleich noch einmal.")
        m.putIfAbsent("Too many requests. Wait a minute and try again.", "Zu viele Anfragen. Warte eine Minute und versuche es erneut.")
        m.putIfAbsent("Not found: the service does not have this data.", "Nicht gefunden: Der Dienst hat diese Daten nicht.")
        m.putIfAbsent("The service has a problem. Try again later.", "Der Dienst hat ein Problem. Versuche es später noch einmal.")
        m.putIfAbsent("Something went wrong. Try again.", "Etwas ist schiefgelaufen. Versuche es erneut.")
        m.putIfAbsent("You are offline. Showing the latest available data.", "Du bist offline. Es werden die letzten verfügbaren Daten angezeigt.")
        m.putIfAbsent("The service is not responding: some data is %d min old.", "Der Dienst antwortet nicht: Einige Daten sind %d Min. alt.")
        m.putIfAbsent("With the app's latest network errors (service addresses only, no personal data).", "Mit den letzten Netzwerkfehlern der App (nur Dienstadressen, keine persönlichen Daten).")
        m.putIfAbsent("Try changing the time or the station.", "Ändere die Uhrzeit oder den Bahnhof.")
        m.putIfAbsent("Looking for alternatives…", "Suche nach Alternativen…")
        m.putIfAbsent("Advanced", "Erweitert")
        m.putIfAbsent("Just the essentials: timetable search, strikes and your shortcuts.", "Nur das Wichtigste: Fahrplansuche, Streiks und deine Schnelltasten.")
        m.putIfAbsent("Also: passengers, train type, prices, My trips, offline timetables, lines and fares.", "Dazu: Reisende, Zugart, Preise, Meine Reisen, Offline-Fahrpläne, Linien und Tarife.")
        m.putIfAbsent("All features: also maps, other countries, emergency, assistant and style tiles.", "Alle Funktionen: auch Karten, Ausland, Notfall, Assistent und Stil-Kacheln.")
        m.putIfAbsent("Show all features", "Alle Funktionen anzeigen")
        m.putIfAbsent("Accessible", "Barrierefrei")
        m.putIfAbsent("Accessible stations", "Barrierefreie")
        m.putIfAbsent("Other services", "Weitere Dienste")
        m.putIfAbsent("Open the notice document (PDF)", "Dokument der Meldung öffnen (PDF)")
        m.putIfAbsent("Open the station page", "Bahnhofsseite öffnen")
        m.putIfAbsent("Trenord notice", "Trenord-Meldung")
        m.putIfAbsent("Bars and restaurants", "Bars und Restaurants")
        m.putIfAbsent("Bike sharing", "Bike-Sharing")
        m.putIfAbsent("Get directions", "Route berechnen")
        m.putIfAbsent("Car sharing", "Carsharing")
        m.putIfAbsent("With ticket office", "Mit Schalter")
        m.putIfAbsent("With ticket machines", "Mit Billettautomaten")
        m.putIfAbsent("From the Trenord website. Tap a station for its address and other services.", "Von der Trenord-Website. Tippe auf einen Bahnhof für Adresse und weitere Dienste.")
        m.putIfAbsent("Defibrillator", "Defibrillator")
        m.putIfAbsent("Left luggage", "Gepäckaufbewahrung")
        m.putIfAbsent("Machines", "Automaten")
        m.putIfAbsent("Ticket machines", "Billettautomaten")
        m.putIfAbsent("Newsstand", "Kiosk")
        m.putIfAbsent("Address", "Adresse")
        m.putIfAbsent("Reading the station page from the Trenord website…", "Bahnhofsseite wird von der Trenord-Website gelesen…")
        m.putIfAbsent("Show all", "Alle anzeigen")
        m.putIfAbsent("No services listed", "Keine Dienste angegeben")
        m.putIfAbsent("No stations with these services.", "Keine Bahnhöfe mit diesen Diensten.")
        m.putIfAbsent("Parking", "Parkplatz")
        m.putIfAbsent("Car park", "Autoparkplatz")
        m.putIfAbsent("Bike parking", "Veloparkplatz")
        m.putIfAbsent("Waiting room", "Wartesaal")
        m.putIfAbsent("Escalators", "Rolltreppen")
        m.putIfAbsent("Station page not available right now.", "Bahnhofsseite gerade nicht verfügbar.")
        m.putIfAbsent("Accessibility services", "Dienste für Barrierefreiheit")
        m.putIfAbsent("Stations on the line", "Bahnhöfe der Linie")
        m.putIfAbsent("Wi-Fi", "WLAN")
        m.putIfAbsent("TILO trains that left in the last 3 hours, in both directions, from the Swiss timetable: it counts delays over 15 minutes, not cancelled trains. For cancellations see the SBB notices below.", "TILO-Züge der letzten 3 Stunden in beiden Richtungen, aus dem Schweizer Fahrplan: gezählt werden Verspätungen über 15 Minuten, nicht ausgefallene Züge. Für Ausfälle siehe die SBB-Meldungen unten.")
        m.putIfAbsent("SBB notices on the line", "SBB-Meldungen zur Linie")
        m.putIfAbsent("Checking SBB notices…", "SBB-Meldungen werden geprüft…")
        m.putIfAbsent("No current SBB notices: according to SBB, service is running normally.", "Keine aktuellen SBB-Meldungen: laut SBB verkehren die Züge normal.")
        m.putIfAbsent("SBB open data (texts in English).", "Offene Daten der SBB (Texte auf Englisch).")
        m.putIfAbsent("SBB service status", "Betriebslage SBB")
        m.putIfAbsent("Delete this trip?", "Diese Fahrt löschen?")
        m.putIfAbsent("Across all trips on the chosen route", "Über alle Fahrten der gewählten Strecke")
        m.putIfAbsent("Morning (5–10)", "Morgen (5–10)")
        m.putIfAbsent("Daytime (10–16)", "Tag (10–16)")
        m.putIfAbsent("Evening (16–21)", "Abend (16–21)")
        m.putIfAbsent("Night (21–5)", "Nacht (21–5)")
        m.putIfAbsent("When your trains are most late", "Wann deine Züge am meisten Verspätung haben")
        m.putIfAbsent("Across all trips in the log", "Über alle Fahrten im Fahrtenbuch")
        m.putIfAbsent("{0} trips · average delay {1} min · {2} with 15 min or more", "{0} Fahrten · Ø Verspätung {1} Min. · {2} mit 15 Min. oder mehr")
        m.putIfAbsent("most delays", "meiste Verspätung")
        m.putIfAbsent("today", "heute")
        m.putIfAbsent("yesterday", "gestern")
        m.putIfAbsent("Last few days (worst moment)", "Letzte Tage (schlechtester Moment)")
        m.putIfAbsent("All routes", "Alle Strecken")
        m.putIfAbsent("Compensation claim", "Antrag auf Entschädigung")
        m.putIfAbsent("Not today", "Heute nicht melden")
        m.putIfAbsent("Year", "Jahr")
        m.putIfAbsent("Arrival delay, day by day", "Verspätung bei Ankunft, Tag für Tag")
        m.putIfAbsent("Filled bar: minutes late (top = 60 or more). Empty bar: train cancelled.", "Gefüllter Balken: Minuten Verspätung (oben = 60 oder mehr). Leerer Balken: Zug ausgefallen.")
        m.putIfAbsent("Days with trips: {0}. No delays. Cancelled: {1}.", "Tage mit Fahrten: {0}. Keine Verspätungen. Ausgefallen: {1}.")
        m.putIfAbsent("Days with trips: {0}. Highest delay: {1} minutes on day {2}. Cancelled: {3}.", "Tage mit Fahrten: {0}. Größte Verspätung: {1} Minuten am Tag {2}. Ausgefallen: {3}.")
        m.putIfAbsent("{0} minutes late", "{0} Minuten Verspätung")
        m.putIfAbsent("Date", "Datum")
        m.putIfAbsent("Scheduled arrival", "Planmäßige Ankunft")
        m.putIfAbsent("Delay (min)", "Verspätung (Min.)")
        m.putIfAbsent("Yes", "Ja")
        m.putIfAbsent("Delays this month", "Verspätungen des Monats")
        m.putIfAbsent("Search the guide", "In der Hilfe suchen")
        m.putIfAbsent("No topic found", "Kein Thema gefunden")
        m.putIfAbsent("Tap to open «My trips» and share the month.", "Tippe, um «Meine Fahrten» zu öffnen und den Monat zu teilen.")
        m.putIfAbsent("added by hand", "manuell eingetragen")
        m.putIfAbsent("Add a trip", "Fahrt hinzufügen")
        m.putIfAbsent("Train (e.g. R 2727)", "Zug (z. B. R 2727)")
        m.putIfAbsent("Date (dd/mm/yyyy)", "Datum (TT/MM/JJJJ)")
        m.putIfAbsent("Scheduled arrival (hh:mm)", "Planmäßige Ankunft (hh:mm)")
        m.putIfAbsent("Minutes late on arrival", "Minuten Verspätung bei Ankunft")
        m.putIfAbsent("Write the train with its number, for example R 2727.", "Gib den Zug mit seiner Nummer ein, zum Beispiel R 2727.")
        m.putIfAbsent("Write the departure and arrival stations.", "Gib Abfahrts- und Ankunftsbahnhof ein.")
        m.putIfAbsent("Check date and time: for example 09/11/2026 and 08:15.", "Prüfe Datum und Uhrzeit: zum Beispiel 09/11/2026 und 08:15.")
        m.putIfAbsent("The trip cannot be in the future.", "Die Fahrt darf nicht in der Zukunft liegen.")
        m.putIfAbsent("The delay must be from 0 to 999 minutes.", "Die Verspätung muss zwischen 0 und 999 Minuten liegen.")
        m.putIfAbsent("Low disruption", "Geringe Störung")
        m.putIfAbsent("Moderate disruption", "Mittlere Störung")
        m.putIfAbsent("High disruption", "Starke Störung")
        m.putIfAbsent("1 strike hidden by the filter", "1 Streik vom Filter ausgeblendet")
        m.putIfAbsent("{0} strikes hidden by the filter", "{0} Streiks vom Filter ausgeblendet")
        m.putIfAbsent("1 notice hidden by the filter", "1 Meldung vom Filter ausgeblendet")
        m.putIfAbsent("{0} notices hidden by the filter", "{0} Meldungen vom Filter ausgeblendet")
        m.putIfAbsent("Share the month", "Monat teilen")
        m.putIfAbsent("Times recorded by the Binario app: they do not replace the operator's official certificates.", "Von der App Binario erfasste Zeiten: Sie ersetzen keine offiziellen Bescheinigungen des Unternehmens.")
        m.putIfAbsent("{0}: scheduled {1}, actual {2}", "{0}: planmäßig {1}, tatsächlich {2}")
        m.putIfAbsent("{0}: scheduled {1}, expected {2}", "{0}: planmäßig {1}, erwartet {2}")
        m.putIfAbsent("{0}: scheduled {1}", "{0}: planmäßig {1}")
        m.putIfAbsent("How to read the times", "So liest du die Zeiten")
        m.putIfAbsent("Actual time: the train passed on time", "Tatsächliche Zeit: der Zug war pünktlich")
        m.putIfAbsent("Actual time: the train passed late", "Tatsächliche Zeit: der Zug war verspätet")
        m.putIfAbsent("Expected time: scheduled plus the current delay reported by the operator", "Erwartete Zeit: Fahrplan plus die aktuelle, vom Unternehmen gemeldete Verspätung")
        m.putIfAbsent("When data comes from several operators, the source is shown under the stop name (e.g. Trenord, SBB).", "Kommen die Daten von mehreren Unternehmen, steht die Quelle unter dem Haltestellennamen (z. B. Trenord, SBB).")
        m.putIfAbsent("Disruption on the line (last 3 hours)", "Störungen auf der Linie (letzte 3 Stunden)")
        m.putIfAbsent("Checking the trains of the last few hours…", "Ich prüfe die Züge der letzten Stunden…")
        m.putIfAbsent("No trains departed in the last 3 hours.", "Keine Züge in den letzten 3 Stunden abgefahren.")
        m.putIfAbsent("{0} critical trains out of {1}", "{0} kritische Züge von {1}")
        m.putIfAbsent("Short-run", "Verkürzt")
        m.putIfAbsent("Over 15 min", "Über 15 Min.")
        m.putIfAbsent("Trains that departed in the last 3 hours, in both directions. Critical: cancelled, short-run or more than 15 minutes late.", "Züge, die in den letzten 3 Stunden abgefahren sind, in beide Richtungen. Kritisch: ausgefallen, verkürzt oder mehr als 15 Minuten verspätet.")
        m.putIfAbsent("My trips", "Meine Fahrten")
        m.putIfAbsent("Trains followed to arrival, delays this month", "Bis zur Ankunft verfolgte Züge, Verspätungen des Monats")
        m.putIfAbsent("Previous month", "Vorheriger Monat")
        m.putIfAbsent("Next month", "Nächster Monat")
        m.putIfAbsent("No trips yet", "Noch keine Fahrten")
        m.putIfAbsent("When you follow a train (the «Follow» button on the train page) until it arrives, the trip appears here with its delay. It stays on this phone only.", "Wenn du einen Zug (Taste «Folgen» auf der Zugseite) bis zur Ankunft verfolgst, erscheint die Fahrt hier mit ihrer Verspätung. Sie bleibt nur auf diesem Telefon.")
        m.putIfAbsent("No trips this month.", "Keine Fahrten in diesem Monat.")
        m.putIfAbsent("The trip log stays on this phone only.", "Das Fahrtenbuch bleibt nur auf diesem Telefon.")
        m.putIfAbsent("Clear the trip log", "Fahrtenbuch löschen")
        m.putIfAbsent("Delete all saved trips?", "Alle gespeicherten Fahrten löschen?")
        m.putIfAbsent("Trips", "Fahrten")
        m.putIfAbsent("Delay of 15 min or more", "Verspätung ab 15 Min.")
        m.putIfAbsent("Delay of 60 min or more", "Verspätung ab 60 Min.")
        m.putIfAbsent("Total minutes of delay", "Verspätungsminuten insgesamt")
        m.putIfAbsent("With a delay of 60 minutes or more you can claim compensation.", "Ab 60 Minuten Verspätung kannst du eine Entschädigung verlangen.")
        m.putIfAbsent("If you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation.", "Mit einem Abo zählen Verspätungen für den Monatsbonus (Trenord) oder die Entschädigung.")
    }
}
