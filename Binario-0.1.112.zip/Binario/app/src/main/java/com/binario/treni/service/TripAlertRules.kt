package com.binario.treni.service

/** Regole pure (senza rete né Android) degli avvisi sulla tratta salvata, così si possono provare con i test. */
object TripAlertRules {
    const val STRONG_DELAY_MIN = 10

    enum class Kind { NONE, CANCELLED, DELAYED }

    fun disruption(cancelled: Boolean, delayMin: Int): Kind = when {
        cancelled -> Kind.CANCELLED
        delayMin >= STRONG_DELAY_MIN -> Kind.DELAYED
        else -> Kind.NONE
    }
}
