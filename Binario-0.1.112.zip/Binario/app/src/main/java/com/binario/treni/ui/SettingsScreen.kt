package com.binario.treni.ui

import androidx.compose.runtime.saveable.rememberSaveable
import com.binario.treni.data.tx
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.text.style.TextDecoration
import com.binario.treni.data.ALL_CATEGORIES
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.NewsItem
import com.binario.treni.data.Notice
import com.binario.treni.data.Sources
import com.binario.treni.data.Strike
import com.binario.treni.data.SavedSearch
import com.binario.treni.service.Reminders
import com.binario.treni.service.TrackingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Impostazioni generali, notifiche, mappe, accessibilità, backup. */
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onThemeChange: (String) -> Unit, onLegal: () -> Unit = {}, onDev: () -> Unit = {}) {
    val ctx = LocalContext.current
    val store = vm.store
    var start by remember { mutableStateOf(store.startScreen) }
    var theme by remember { mutableStateOf(store.theme) }
    var kbd by remember { mutableStateOf(store.openKeyboard) }
    var buy by remember { mutableStateOf(store.showBuy) }
    var maps by remember { mutableStateOf(store.mapsEnabled) }
    var strikes by remember { mutableStateOf(store.strikeAlerts) }
    var strikesRoute by remember { mutableStateOf(store.strikeRouteOnly) }
    var routes by remember { mutableStateOf(store.routeAlerts) }
    var deaf by remember { mutableStateOf(store.deafMode) }
    var flash by remember { mutableStateOf(store.flashAlerts) }
    var blindLevel by remember { mutableStateOf(store.blindLevel) }
    val blind = blindLevel != "off"
    var stopsVoice by remember { mutableStateOf(store.announceStops) }
    var rate by remember { mutableStateOf(store.speechRate) }
    var changes by remember { mutableStateOf(store.changeAlerts) }
    var habitLearn by remember { mutableStateOf(store.habitLearning) }
    var habitAlerts by remember { mutableStateOf(store.habitAlerts) }
    var habitList by remember { mutableStateOf(store.habits()) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(tx("application/json"))) { uri ->
        if (uri != null) exportTo(ctx, uri, store)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFrom(ctx, uri, store)
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Impostazioni"), onBack)
        WhiteCard {
            CardTitle(tx("Generale"))
            ChoiceSetting(tx("Schermata all'avvio"), start, listOf("search" to tx("Cerca Orario"), "trains" to tx("Treni"), "stations" to tx("Stazioni"), "quick" to tx("Rapido"),
                "voice" to tx("Assistente vocale (microfono subito attivo)"))) {
                start = it; store.startScreen = it
            }
            ChoiceSetting(tx("Lingua"), com.binario.treni.data.I18n.lang, listOf("it" to "🇮🇹 Italiano", "en" to "🇬🇧 English", "zh" to "🇨🇳 中文", "de" to "🇩🇪 Deutsch", "fr" to "🇫🇷 Français", "es" to "🇪🇸 Español", "ja" to "🇯🇵 日本語")) {
                com.binario.treni.data.I18n.lang = it; store.lang = it
            }
            // Paese per emergenze: numero da chiamare, app di emergenza (AREU, Rega, nora) e mappe dei defibrillatori
            var emCountry by remember { mutableStateOf(com.binario.treni.data.Emergency.setting(ctx)) }
            ChoiceSetting(tx("Paese per emergenze e defibrillatori"), emCountry, listOf(
                "auto" to tx("Automatico (rete mobile)") + " · " + com.binario.treni.data.Emergency.fromNetwork(ctx).let { it.flag + " " + it.label },
                "it" to "🇮🇹 " + tx("Italia") + " · 112",
                "ch" to "🇨🇭 " + tx("Svizzera") + " · 144",
                "de" to "🇩🇪 " + tx("Germania") + " · 112",
            )) { emCountry = it; com.binario.treni.data.Emergency.setSetting(ctx, it) }
            ChoiceSetting(tx("Tema"), theme, listOf("system" to tx("Come il sistema"), "light" to tx("Verde chiaro"), "dark" to tx("Scuro"))) {
                theme = it; store.theme = it; onThemeChange(it)
            }
            StylePickerSetting(onChanged = { })
        }
        WhiteCard {
            CardTitle(tx("Cerca e Acquista"))
            SwitchSetting(tx("Apri tastiera in scelta stazione"), kbd) { kbd = it; store.openKeyboard = it }
            SwitchSetting(tx("Mostra pulsante Acquisto"), buy) { buy = it; store.showBuy = it }
            var weather by remember { mutableStateOf(store.showWeather) }
            SwitchSetting(tx("Meteo alla stazione (Open-Meteo)"), weather) { weather = it; store.showWeather = it }
        }
        WhiteCard {
            CardTitle(tx("Notifiche"))
            SwitchSetting(tx("Notifica scioperi"), strikes) { strikes = it; store.strikeAlerts = it }
            if (strikes) {
                val r = remember { com.binario.treni.data.RouteNews.defaultRoute(store, ctx) }
                SwitchSetting(tx("Solo scioperi della mia tratta"), strikesRoute,
                    if (r.from != null && r.to != null) r.label + (if (r.complete) " · " + tx("nei miei orari") else "") + " · " + tx("si cambia in Notizie › La mia tratta e orari")
                    else tx("Nessuna tratta scelta: imposta la tua tratta in Notizie › La mia tratta e orari. Intanto ricevi gli scioperi nazionali e della tua regione.")) {
                    strikesRoute = it; store.strikeRouteOnly = it
                }
                StrikeMuteSetting(store)
            }
            SwitchSetting(tx("Avvisi interruzioni su tratte, linee e treni preferiti"), routes) { routes = it; store.routeAlerts = it }
            SwitchSetting(tx("Treno seguito: avvisa se cambia binario o aumenta il ritardo"), changes) { changes = it; store.changeAlerts = it }
        }
        WhiteCard {
            CardTitle(tx("Il tuo prossimo treno"))
            SwitchSetting(tx("Impara i treni che prendo spesso"), habitLearn,
                tx("Dal tabellone, dalle soluzioni, da Segui e dai preferiti. Resta solo sul telefono.")) {
                habitLearn = it; store.habitLearning = it
            }
            SwitchSetting(tx("Avvisami da solo sul treno abituale"), habitAlerts,
                tx("Nei 45 minuti prima della partenza: ritardo, soppressione, cambio binario e alternative pronte")) {
                habitAlerts = it; store.habitAlerts = it
            }
            habitList.forEach { h ->
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(h.title + " · " + h.timeText, fontSize = 15.sp)
                        Text(h.board.name + (h.alight?.let { " → " + it.name } ?: "") + " · " + h.total + "×", color = Muted, fontSize = 12.sp)
                    }
                    IconButton({ store.removeHabit(h.key); habitList = store.habits() }) { Icon(Icons.Filled.Close, tx("Dimentica")) }
                }
            }
            if (habitList.isEmpty()) Text(tx("Ancora nessun treno abituale: compare dopo averlo aperto almeno due volte lo stesso giorno della settimana."),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        WhiteCard {
            CardTitle(tx("Accessibilità"))
            SwitchSetting(tx("Avvisi per persone sorde o ipoudenti"), deaf,
                tx("Vibrazione forte con schema diverso per ogni avviso: sveglia fermata (3 lunghe ripetute), promemoria (3 brevi ×2), interruzioni (2 lunghe)")) {
                deaf = it; store.deafMode = it
                if (it) com.binario.treni.service.Haptic.alert(ctx, com.binario.treni.service.Haptic.Kind.REMINDER)
            }
            if (deaf) SwitchSetting(tx("Lampeggio del flash negli avvisi"), flash) { flash = it; store.flashAlerts = it }
            ChoiceSetting(tx("Avvisi vocali per persone non vedenti o ipovedenti"), blindLevel, listOf(
                "off" to tx("Disattivati"),
                "stop" to tx("Solo fermata imminente"),
                "all" to tx("Tutti: binario, partenza, cambi, ritardi, fermate"),
            )) {
                blindLevel = it; store.blindLevel = it
                when (it) {
                    "all" -> com.binario.treni.service.Speech.say(ctx,
                        tx("Avvisi vocali attivi. Ti dirò il binario, la partenza e la fermata dove scendere."),
                        com.binario.treni.service.Speech.Sound.PLATFORM, force = true)
                    "stop" -> com.binario.treni.service.Speech.say(ctx,
                        tx("Ti avviserò con la voce solo quando la tua fermata è imminente."),
                        com.binario.treni.service.Speech.Sound.IMMINENT, force = true)
                }
            }
            Text(tx("La voce del telefono dice dove prendere il treno (binario), quando parte, i cambi di binario e i ritardi, e avvisa con un suono insistente quando la tua fermata è imminente."),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
            if (blindLevel == "all") SwitchSetting(tx("Annuncia ogni fermata del treno seguito"), stopsVoice) { stopsVoice = it; store.announceStops = it }
            if (blind) {
                ChoiceSetting(tx("Velocità della voce"), rate.toString(), listOf("0.8" to tx("Lenta"), "1.0" to tx("Normale"), "1.2" to tx("Veloce"))) {
                    rate = it.toFloat(); store.speechRate = rate
                    com.binario.treni.service.Speech.say(ctx, tx("Prova della voce."), null, force = true)
                }
                Text(tx("Prova i suoni: ognuno ha un significato diverso."), color = Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
                    listOf(
                        com.binario.treni.service.Speech.Sound.PLATFORM to tx("Binario"),
                        com.binario.treni.service.Speech.Sound.DEPART to tx("Partenza"),
                        com.binario.treni.service.Speech.Sound.IMMINENT to tx("Fermata imminente"),
                        com.binario.treni.service.Speech.Sound.ALERT to tx("Problema"),
                    ).forEach { (snd, label) ->
                        OutlinedButton({ com.binario.treni.service.Speech.say(ctx, label, snd, force = true) }, Modifier.padding(end = 6.dp)) { Text(label) }
                    }
                }
                Text(
                    tx("Per chiedere a voce: tieni premuta l'icona di Binario e scegli «Chiedi a voce» (puoi trascinarla sulla Home), " +
                        "oppure aggiungi il riquadro «Binario · Chiedi a voce» nelle Impostazioni rapide. Con l'assistente del telefono di' «Apri Binario». " +
                        "Funziona anche con TalkBack."),
                    color = Muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp),
                )
            }
            // Interruttori rapidi sì/no (gli stessi della Home)
            A11yQuickCard(store, inSettings = true, voiceKey = blindLevel) { blindLevel = it }
            var homeCard by remember { mutableStateOf(store.homeA11y) }
            SwitchSetting(tx("Mostra queste opzioni anche nella pagina Rapido"), homeCard) { homeCard = it; store.homeA11y = it }
            // Dimensione del testo per chi vede poco: vale in tutta l'app, le righe vanno a capo senza tagli
            ChoiceSetting(tx("Dimensione del testo"), com.binario.treni.data.TextScale.value.toString(), listOf(
                "1.0" to tx("Normale"), "1.15" to tx("Grande"), "1.3" to tx("Molto grande"), "1.5" to tx("Enorme"),
            )) { com.binario.treni.data.TextScale.set(ctx, it.toFloat()) }
            Text(tx("Ingrandisce i caratteri in tutta l'app; i testi vanno a capo senza essere tagliati."), color = Muted, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
            ChoiceSetting(tx("Colori per daltonici"), com.binario.treni.data.ColorBlind.mode, listOf(
                "off" to tx("Disattivato"),
                "redgreen" to tx("Rosso-verde (protanopia, deuteranopia)"),
                "tritan" to tx("Blu-giallo (tritanopia)"),
            )) {
                com.binario.treni.data.ColorBlind.mode = it; store.colorBlind = it
                com.binario.treni.widget.Widgets.refreshAll(ctx)
            }
            if (com.binario.treni.data.ColorBlind.on) Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("✓ " + tx("In orario"), color = OnTime, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(12.dp))
                Text("▲ +7'", color = LateRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(12.dp))
                listOf(com.binario.treni.data.Crowd.Level.LOW, com.binario.treni.data.Crowd.Level.MEDIUM, com.binario.treni.data.Crowd.Level.HIGH).forEach {
                    Text(it.symbol + " ", color = Color(it.color), fontSize = 16.sp)
                }
            }
        }
        WhiteCard {
            CardTitle(com.binario.treni.data.I18n.tr("Orologio e smartwatch", "Watch and smartwatch"))
            var watchOn by remember { mutableStateOf(store.watchStatus) }
            SwitchSetting(
                com.binario.treni.data.I18n.tr("Stato del treno seguito anche sull'orologio", "Followed train status on the watch too"), watchOn,
                com.binario.treni.data.I18n.tr(
                    "Invia una notifica normale (non fissa) quando cambiano ritardo, binario o prossima fermata, così Mi Band, Wear OS e gli altri orologi la mostrano.",
                    "Sends a normal (not pinned) notification when the delay, platform or next stop changes, so Mi Band, Wear OS and other watches show it.",
                ),
            ) { watchOn = it; store.watchStatus = it }
            OutlinedButton(
                {
                    com.binario.treni.service.Notif.createChannels(ctx)
                    com.binario.treni.service.Notif.post(
                        ctx, 9001, com.binario.treni.service.Notif.CH_ALERT, "🚆 Binario",
                        com.binario.treni.data.I18n.tr("Prova: se la vedi sull'orologio, è tutto a posto.", "Test: if you see this on your watch, all is well."),
                        com.binario.treni.service.Notif.openApp(ctx),
                    )
                },
                Modifier.padding(horizontal = 16.dp),
            ) { Text(com.binario.treni.data.I18n.tr("Invia notifica di prova", "Send a test notification")) }
            Text(
                com.binario.treni.data.I18n.tr(
                    "Binario non parla direttamente con l'orologio: le notifiche (avvisi, scioperi, cambi binario, ritardi, promemoria) arrivano al polso tramite l'app dell'orologio. " +
                        "Mi Band: in Mi Fitness o Zepp Life apri il dispositivo › Notifiche e promemoria › Avvisi delle app e attiva Binario. " +
                        "Wear OS: arrivano da sole (controlla nell'app Wear OS › Notifiche). In entrambi i casi imposta Binario su «nessuna restrizione» nella batteria. " +
                        "La notifica fissa del treno (con «Smetti di seguire») di solito non viene inoltrata: per questo ci sono gli avvisi separati qui sopra.",
                    "Binario does not talk to the watch directly: notifications (alerts, strikes, platform changes, delays, reminders) reach your wrist through the watch's own app. " +
                        "Mi Band: in Mi Fitness or Zepp Life open your device › Notifications and reminders › App alerts and turn on Binario. " +
                        "Wear OS: they arrive on their own (check in the Wear OS app › Notifications). In both cases set Binario to «no restrictions» in battery settings. " +
                        "The pinned train notification (with «Stop following») is usually not forwarded: that is why the separate alerts above exist.",
                ),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp),
            )
        }
        WhiteCard {
            CardTitle(tx("Posizione e Mappe"))
            SwitchSetting(tx("Disattiva Mappe"), !maps) { maps = !it; store.mapsEnabled = !it }
        }
        WhiteCard {
            CardTitle("Backup")
            MenuRow(null, tx("Esporta dati")) { exportLauncher.launch("binario-backup.json") }
            MenuRow(null, tx("Importa dati")) { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }
        }
        WhiteCard {
            CardTitle(tx("Legale"))
            MenuRow(Icons.Filled.Gavel, tx("Note legali"), tx("Versione") + " " + APP_VERSION) { onLegal() }
            Text(com.binario.treni.data.I18n.tr5(PRIVACY_TEXT, PRIVACY_TEXT_EN, PRIVACY_TEXT_ZH, PRIVACY_TEXT_DE, PRIVACY_TEXT_FR, PRIVACY_TEXT_ES, PRIVACY_TEXT_JA), fontSize = 13.sp, color = Muted, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        // Modalità sviluppatore: 7 tocchi su "Versione App", poi la password
        var taps by rememberSaveable { mutableStateOf(0) }
        var askPassword by remember { mutableStateOf(false) }
        var devOn by remember { mutableStateOf(com.binario.treni.data.DevLayout.unlocked(ctx)) }
        if (askPassword) DevPasswordDialog(onDismiss = { askPassword = false }) {
            askPassword = false; devOn = true
            toast(ctx, "Modalità sviluppatore attiva")
            onDev()
        }
        WhiteCard(onClick = {
            if (!devOn) {
                taps++
                when {
                    taps >= 7 -> { taps = 0; askPassword = true }
                    taps >= 4 -> toast(ctx, "Ancora ${7 - taps} tocchi…")
                }
            }
        }) {
            CardTitle(tx("Versione App"))
            Text(APP_VERSION, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp))
            Text(tx(CREDIT), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
            if (devOn) MenuRow(Icons.Filled.DeveloperMode, "Modalità sviluppatore", "Disposizione dell'app: trascina e riordina") { onDev() }
        }
        Spacer(Modifier.height(16.dp))
    }
}

private fun exportTo(ctx: android.content.Context, uri: android.net.Uri, store: com.binario.treni.data.Store) {
    try {
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(store.exportJson().toByteArray()) }
        toast(ctx, tx("Backup salvato"))
    } catch (e: Exception) {
        toast(ctx, tx("Errore nel salvataggio"))
    }
}

private fun importFrom(ctx: android.content.Context, uri: android.net.Uri, store: com.binario.treni.data.Store) {
    try {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() } ?: ""
        toast(ctx, if (store.importJson(text)) tx("Dati importati") else tx("File non valido"))
    } catch (e: Exception) {
        toast(ctx, tx("File non valido"))
    }
}

@Composable
private fun SwitchSetting(title: String, value: Boolean, sub: String = "", onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 12.sp)
        }
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Green))
    }
}

/**
 * Silenzia le notifiche di sciopero per un tempo scelto dall'utente (1 ora … 1 mese, oppure fino a un giorno e un'ora).
 * Gli scioperi arrivati nel frattempo restano visibili in Notizie, ma non arrivano come notifica.
 */
@Composable
fun StrikeMuteSetting(store: com.binario.treni.data.Store) {
    val ctx = LocalContext.current
    var until by remember { mutableLongStateOf(store.strikeMuteUntil) }
    var open by remember { mutableStateOf(false) }
    val now = System.currentTimeMillis()
    val muted = until > now
    fun set(v: Long) { until = v; store.strikeMuteUntil = v }
    Row(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (muted) Icons.Filled.NotificationsOff else Icons.Filled.NotificationsActive, null, tint = if (muted) Color(0xFFEF6C00) else Green)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(tx("Silenzia gli avvisi di sciopero"), fontSize = 16.sp)
            Text(if (muted) tx("Silenziati fino al") + " " + Fmt.dayTime(until) else tx("Attivi · tocca per silenziarli per un po'"),
                color = if (muted) Color(0xFFEF6C00) else Muted, fontSize = 12.sp)
        }
        if (muted) TextButton({ set(0L) }) { Text(tx("Riattiva"), color = Green) }
    }
    if (open) {
        val h = 3_600_000L
        val options = listOf(
            tx("1 ora") to h, tx("3 ore") to 3 * h, tx("8 ore") to 8 * h, tx("1 giorno") to 24 * h,
            tx("3 giorni") to 72 * h, tx("1 settimana") to 7 * 24 * h, tx("1 mese") to 30 * 24 * h,
        )
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(tx("Silenzia gli avvisi di sciopero")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(tx("Per quanto tempo? Gli scioperi restano visibili in Notizie."), color = Muted, fontSize = 13.sp)
                    options.forEach { (label, d) ->
                        Text(label, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { set(System.currentTimeMillis() + d); open = false }.padding(vertical = 12.dp))
                    }
                    Text(tx("Fino a un giorno e un'ora…"), fontSize = 16.sp, color = Green, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth().clickable {
                            open = false
                            val c = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, 1) }
                            android.app.DatePickerDialog(ctx, { _, y, m, d ->
                                android.app.TimePickerDialog(ctx, { _, hh, mm ->
                                    val t = java.util.Calendar.getInstance().apply { set(y, m, d, hh, mm, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
                                    if (t > System.currentTimeMillis()) set(t) else toast(ctx, tx("Orario già passato"))
                                }, 8, 0, true).show()
                            }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).apply {
                                datePicker.minDate = System.currentTimeMillis() - 1000
                            }.show()
                        }.padding(vertical = 12.dp))
                }
            },
            confirmButton = { TextButton({ open = false }) { Text(tx("Chiudi"), color = Green) } },
        )
    }
}

@Composable
private fun ChoiceSetting(title: String, value: String, options: List<Pair<String, String>>, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Muted, fontSize = 13.sp)
                Text(options.firstOrNull { it.first == value }?.second ?: value, fontSize = 17.sp)
            }
            Icon(Icons.Filled.ArrowDropDown, null, tint = Muted)
        }
        DropdownMenu(open, { open = false }) {
            options.forEach { (k, v) -> DropdownMenuItem({ Text(v) }, { onChange(k); open = false }) }
        }
    }
}
