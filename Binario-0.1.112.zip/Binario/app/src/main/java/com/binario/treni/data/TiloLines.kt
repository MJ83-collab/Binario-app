package com.binario.treni.data

import org.json.JSONObject
import java.net.URLEncoder

/**
 * Linee TILO (S10, S40, S50, RE80…) e svizzere. L'orario italiano non ha i treni TILO diretti che passano dalla Svizzera
 * (es. S40 Como – Mendrisio – Varese): la linea mostrava «Nessun treno diretto trovato» e «Nessun treno partito nelle
 * ultime 3 ore» anche con la circolazione regolare (9/11/2026). Qui treni e ritardi vengono dall'orario ufficiale svizzero.
 */
object TiloLines {
    /** Una corsa diretta della linea con il ritardo alla partenza (minuti, dall'orario svizzero). */
    data class Run(val sol: Solution, val delay: Int)

    fun isTilo(line: Linea): Boolean =
        line.operator.equals("TILO", true) || SwissLive.isSwiss(line.a.id) || SwissLive.isSwiss(line.b.id)

    /** Chiave per ritrovare il ritardo di una corsa nella lista (partenza + treno). */
    fun key(s: Solution): String = s.dep.toString() + "|" + s.legs.joinToString("-") { it.number }

    /** Solo le corse dirette (un treno, senza cambi), una volta sola ciascuna, in ordine di partenza (logica pura). */
    fun directRuns(conns: List<Connection>, from: String, to: String): List<Run> =
        conns.filter { it.rides.size == 1 }
            .distinctBy { it.dep.toString() + "|" + it.rides[0].train }
            .sortedBy { it.dep }
            .map { c ->
                val r = c.rides[0]
                Run(
                    Solution(
                        from = from, to = to, dep = c.dep, arr = c.arr,
                        duration = "${c.minutes / 60}h${(c.minutes % 60).toString().padStart(2, '0')}",
                        price = null,
                        legs = listOf(Leg(number = r.train, category = "", from = r.from, to = r.to, dep = r.dep, arr = r.arr, operator = r.operator)),
                        source = "sbb.ch",
                    ),
                    r.delay,
                )
            }

    /** Treni diretti da [from] a [to] a partire da [time]. */
    fun runs(from: Station, to: Station, time: Long, limit: Int = 12): List<Run> =
        directRuns(Swiss.connections(Swiss.placeOf(from), Swiss.placeOf(to), time, limit = limit), from.name, to.name)

    /**
     * Disagio dai dati svizzeri (logica pura): corse partite nelle ultime 3 ore con più di 15 minuti di ritardo.
     * L'orario svizzero non dice quali treni sono soppressi o limitati: si contano solo i ritardi.
     */
    fun summarize(runs: List<Run>, now: Long): DisruptionSummary {
        val gone = runs.filter { it.sol.dep in (now - LineDisruption.WINDOW_MS)..now }.distinctBy { key(it.sol) }
        return DisruptionSummary(checked = gone.size, cancelled = 0, limited = 0, late = gone.count { it.delay > LineDisruption.LATE_MIN })
    }

    /** Disagio della linea nelle due direzioni; null se l'orario svizzero non ha risposto in nessuna delle due. */
    fun disruption(line: Linea, now: Long = System.currentTimeMillis()): DisruptionSummary? {
        var errors = 0
        val all = listOf(line.a to line.b, line.b to line.a).flatMap { (f, t) ->
            try {
                runs(f, t, now - LineDisruption.WINDOW_MS, limit = 16)
            } catch (e: Exception) {
                errors++
                Diag.record("disagio-tilo", e)
                emptyList()
            }
        }
        if (errors == 2) return null
        return summarize(all, now)
    }

    /** Capolinea delle linee TILO con il nome che l'orario conosce («Como» da solo diventava Como Borghi, dove la S40 non passa). */
    val ENDS: Map<String, Pair<String, String>> = mapOf(
        "RE80" to ("Locarno" to "Milano Centrale"),
        "S10" to ("Biasca" to "Como S. Giovanni"),
        "S20" to ("Castione-Arbedo" to "Locarno"),
        "S30" to ("Cadenazzo" to "Gallarate"),
        "S40" to ("Como S. Giovanni" to "Varese"),
        "S50" to ("Biasca" to "Malpensa Aeroporto T1"),
        "S90" to ("Giubiasco" to "Mendrisio"),
    )

    /** Stazione di un capolinea TILO: prima tra quelle svizzere (id CH…), poi tra quelle italiane. */
    fun resolveEnd(name: String): Station? {
        val n = norm(name)
        val ch = try { SwissLive.searchStations(name) } catch (e: Exception) { emptyList() }
        ch.firstOrNull { norm(it.name.removeSuffix(SwissLive.SUFFIX)) == n }?.let { return it }
        return Api.resolveStation(name) ?: ch.firstOrNull { norm(it.name).startsWith(n) }
    }

    internal fun norm(s: String) = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace(Regex("[^a-z0-9]+"), "")
}

/**
 * Avvisi del traffico ferroviario svizzero (FFS): lo stesso contenuto del feed RSS «Informazioni sul traffico
 * ferroviario in Svizzera», dai dati aperti FFS (data.sbb.ch, senza registrazione). I testi sono in inglese.
 */
object SwissTraffic {
    private const val API = "https://data.sbb.ch/api/explore/v2.1/catalog/datasets/rail-traffic-information/records"
    const val PAGE = "https://www.sbb.ch/it/pianificare/informazioni-traffico-ferroviario"

    data class Notice(val title: String, val text: String, val link: String, val published: Long, val start: Long, val end: Long)

    private val cache = TtlCacheLite<List<Notice>>(5 * 60_000L)

    private fun time(s: String): Long {
        if (s.isBlank() || s == "null") return 0L
        for (p in listOf("yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ssZ")) {
            try {
                return java.text.SimpleDateFormat(p, java.util.Locale.US).parse(s)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    private fun JSONObject.str(k: String): String = if (!has(k) || isNull(k)) "" else optString(k)

    /** Legge la risposta dei dati aperti; lo stesso avviso aggiornato più volte resta una volta sola, nella versione più recente. */
    fun parse(json: String): List<Notice> {
        val arr = JSONObject(json).optJSONArray("results") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val title = o.str("title").trim()
            if (title.isBlank()) return@mapNotNull null
            Notice(
                title = title,
                text = o.str("description_html").ifBlank { o.str("description") }.trim(),
                link = o.str("link"),
                published = time(o.str("published")),
                start = time(o.str("startdatetime")),
                end = time(o.str("enddatetime")),
            )
        }.sortedByDescending { it.published }.distinctBy { it.link.ifBlank { it.title } }
    }

    private fun word(text: String, w: String) =
        w.isNotBlank() && Regex("(?<![\\p{L}\\p{N}])" + Regex.escape(w) + "(?![\\p{L}\\p{N}])", RegexOption.IGNORE_CASE).containsMatchIn(text)

    /**
     * Avvisi in corso per una linea (logica pura). Valgono quelli che nominano una delle sue stazioni svizzere (Chiasso
     * compresa) oppure il codice della linea insieme a TILO o Ticino: «S40» da solo non basta, la S-Bahn di Zurigo ha
     * anche lei una S40. I capolinea italiani da soli non contano (un avviso su «Como» può essere di un'altra linea).
     */
    fun forLine(list: List<Notice>, code: String, places: List<String>, now: Long): List<Notice> {
        val swissPlaces = places.map { it.removeSuffix(SwissLive.SUFFIX).trim() }
            .filter { p -> p.length >= 3 && (SwissNews.mentionsSwiss(p) || p.equals("Chiasso", true)) }
            .distinct()
        return list.filter { n ->
            val t = n.title + " " + n.text
            val active = n.end == 0L || n.end >= now
            val byCode = word(t, code) && (word(t, "TILO") || word(t, "Ticino") || word(t, "Tessin"))
            active && (byCode || swissPlaces.any { word(t, it) })
        }
    }

    /** Avvisi in corso o futuri, i più recenti (al massimo 100). */
    fun load(): List<Notice> = cache.get {
        val where = URLEncoder.encode("enddatetime >= now() OR enddatetime IS NULL", "UTF-8")
        parse(Http.getText("$API?where=$where&order_by=" + URLEncoder.encode("published desc", "UTF-8") + "&limit=100"))
    }
}

/** Piccola cache a tempo per un solo valore (thread-safe). */
class TtlCacheLite<T>(private val ttlMs: Long) {
    private var value: T? = null
    private var at = 0L

    @Synchronized
    fun get(load: () -> T): T {
        val now = System.currentTimeMillis()
        value?.let { if (now - at < ttlMs) return it }
        return load().also { value = it; at = now }
    }
}
