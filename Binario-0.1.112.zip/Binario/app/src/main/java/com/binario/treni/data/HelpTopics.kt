package com.binario.treni.data

/** Un argomento della guida: la domanda e la sua risposta. */
data class HelpTopic(val title: String, val body: String)

/**
 * Guida divisa per argomenti (idea presa da inAgenda: una voce per funzione). I testi della guida, in tutte le lingue,
 * sono fatti di blocchi separati da una riga vuota: la prima riga è la domanda, le altre la risposta.
 */
object HelpTopics {
    fun parse(text: String): List<HelpTopic> =
        text.trim().split(Regex("""\n[ \t]*\n""")).mapNotNull { block ->
            val lines = block.trim().lines()
            val title = lines.firstOrNull()?.trim().orEmpty()
            if (title.isBlank()) null else HelpTopic(title, lines.drop(1).joinToString("\n").trim())
        }
}
