package com.binario.treni.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.TrainRef
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/**
 * «Treni con più ritardo adesso»: campione dai tabelloni dei principali nodi (partenze delle prossime ore), diviso per rete:
 * Italia (ViaggiaTreno), Trenord e TILO insieme (sono un unico servizio: reti RFI, FerrovieNord e svizzera) e FFS/SBB (transport.opendata.ch).
 * Non è l'elenco di tutta la rete: i treni che non partono da questi nodi non compaiono.
 */
internal object DelayedNow {
    enum class Group(val title: String, val top: Int) {
        IT("Italia · RFI", 5), TRENORD("Trenord · TILO", 8), CH("Svizzera · FFS/SBB", 4),
    }
    data class Item(val ref: TrainRef, val title: String, val dest: String, val delay: Int, val from: String, val group: Group, val net: String = "")

    private val HUBS = listOf(
        "S08409" to "Roma Termini", "S01700" to "Milano Centrale", "S09218" to "Napoli Centrale", "S06421" to "Firenze S.M.N.",
        "S05043" to "Bologna Centrale", "S00219" to "Torino Porta Nuova", "S02593" to "Venezia S. Lucia", "S02430" to "Verona Porta Nuova",
        "S04700" to "Genova Piazza Principe", "S11119" to "Bari Centrale", "S08217" to "Roma Tiburtina", "S01820" to "Milano Rogoredo",
        "S02581" to "Padova", "S09818" to "Salerno",
    )
    /** Nodi lombardi sulla rete RFI dove passano i treni Trenord. */
    private val TRENORD_RFI_HUBS = listOf(
        "S01700" to "Milano Centrale", "S01820" to "Milano Rogoredo", "S01322" to "Monza", "S01520" to "Lecco", "S01529" to "Bergamo",
        "S01717" to "Brescia", "S01307" to "Como S. Giovanni", "S01205" to "Varese", "S01860" to "Pavia",
    )
    /** Stazioni della rete FerrovieNord. */
    private val FN_HUBS = listOf(
        "S01066" to "Milano Cadorna", "S01738" to "Varese Nord", "S01933" to "Saronno", "S01765" to "Como Lago", "S00023" to "Novara Nord",
        "S01925" to "Seveso", "S01747" to "Laveno Lago", "S01101" to "Asso", "S01139" to "Malpensa T1", "S01137" to "Busto Arsizio Nord",
    )
    private val SWISS_HUBS = listOf("Lugano", "Chiasso", "Mendrisio", "Bellinzona", "Locarno", "Zürich HB", "Bern", "Basel SBB", "Genève", "Luzern")
    /** Categorie che NON sono Trenord (alta velocità, Intercity, notte, Italo). */
    private val NOT_TRENORD = setOf("FR", "FA", "FB", "IC", "ICN", "EC", "EN", "ITA", "EXP", "ES", "EC")

    @Volatile private var cache: Pair<Long, List<Item>>? = null
    private val swissStations = java.util.concurrent.ConcurrentHashMap<String, com.binario.treni.data.Station?>()

    /** Elenco finale: per ogni rete i treni più in ritardo, nell'ordine delle reti. */
    suspend fun load(): List<Item> {
        cache?.let { (at, l) -> if (System.currentTimeMillis() - at < 3 * 60_000L) return l }
        val now = System.currentTimeMillis()
        val all = coroutineScope {
            val itl = HUBS.map { (id, name) -> async(Dispatchers.IO) { vt(id, name, now) { Group.IT } } }
            val tr = TRENORD_RFI_HUBS.map { (id, name) -> async(Dispatchers.IO) { vt(id, name, now, "RFI") { cat -> if (cat.uppercase() in NOT_TRENORD) null else Group.TRENORD } } }
            val fn = FN_HUBS.map { (id, name) -> async(Dispatchers.IO) { vt(id, name, now, "FerrovieNord") { _ -> Group.TRENORD } } }
            val ch = SWISS_HUBS.map { name -> async(Dispatchers.IO) { swiss(name, now) } }
            (itl + tr + fn + ch).awaitAll().flatten()
        }
        val out = Group.entries.flatMap { g ->
            all.filter { it.group == g }.distinctBy { it.ref.number + "/" + it.ref.originCode }.sortedByDescending { it.delay }.take(g.top)
        }
        cache = now to out
        return out
    }

    private fun vt(id: String, name: String, now: Long, net: String = "", group: (String) -> Group?): List<Item> = try {
        val a = Api.rawBoard("partenze", id, now)
        (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val delay = o.optInt("ritardo", 0)
            val n = o.opt("numeroTreno")?.toString().orEmpty()
            val org = o.optString("codOrigine")
            if (delay < 5 || n.isBlank() || org.isBlank()) return@mapNotNull null
            val title = o.optString("compNumeroTreno").trim().ifBlank { n }
            val g = group(title.substringBefore(' ')) ?: return@mapNotNull null
            val dest = o.optString("destinazione").lowercase().split(" ").joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
            val ref = TrainRef(n, org, o.optLong("dataPartenzaTreno"), "$n - $dest")
            Item(ref, title, dest, delay, name, g, net)
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun swiss(name: String, now: Long): List<Item> = try {
        val st = swissStations.getOrPut(name) { com.binario.treni.data.SwissLive.searchStations(name).firstOrNull() }
        if (st == null) emptyList() else com.binario.treni.data.SwissLive.departures(st, now).mapNotNull { b ->
            if (b.delay < 5) return@mapNotNull null
            val tilo = b.operator.uppercase().contains("TILO")
            val g = if (tilo) Group.TRENORD else Group.CH
            val dest = b.otherEnd
            Item(TrainRef(b.number, b.originCode, b.departureDate, b.number + " - " + dest), (b.category + " " + b.number).trim(), dest, b.delay, name, g, if (tilo) "Svizzera" else "")
        }
    } catch (_: Exception) {
        emptyList()
    }
}

@Composable
fun DelayedNowCard(onTrain: (TrainRef) -> Unit) {
    var rows by remember { mutableStateOf<List<DelayedNow.Item>?>(null) }
    LaunchedEffect(Unit) { rows = withContext(Dispatchers.IO) { runCatching { DelayedNow.load() }.getOrDefault(emptyList()) } }
    WhiteCard {
        CardTitle(tx("Treni con più ritardo adesso"))
        val r = rows
        if (r == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), color = Green)
        } else if (r.isEmpty()) {
            Text(tx("Nessun ritardo rilevante nei principali nodi, oppure il servizio non risponde."), color = Muted, fontSize = 13.sp,
                modifier = Modifier.padding(16.dp))
        } else {
            DelayedNow.Group.entries.forEach { g ->
                val items = r.filter { it.group == g }
                Text(tx(g.title), color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp))
                if (items.isEmpty()) {
                    Text(tx("Nessun ritardo di 5 minuti o più nei nodi controllati."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                }
                items.forEach { x ->
                    Row(Modifier.fillMaxWidth().clickable { onTrain(x.ref) }.padding(horizontal = 16.dp, vertical = 7.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(x.title + " → " + x.dest, fontSize = 15.sp, maxLines = com.binario.treni.data.TextScale.lines(1), overflow = TextOverflow.Ellipsis)
                            Text(tx("Da") + " " + x.from + if (x.net.isNotBlank()) " · " + tx("rete") + " " + x.net else "", color = Muted, fontSize = 12.sp)
                        }
                        Text("+" + x.delay + " min", color = if (x.delay >= 30) androidx.compose.ui.graphics.Color(0xFFC62828) else androidx.compose.ui.graphics.Color(0xFFEF6C00), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
            Text(
                tx("Campione dai tabelloni dei principali nodi (partenze delle prossime ore): non è l'elenco di tutta la rete. Fonti: ViaggiaTreno (Italia, Trenord, FerrovieNord) e transport.opendata.ch (TILO, Svizzera). Trenord e TILO sono un unico servizio."),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 10.dp),
            )
        }
    }
}
