package com.binario.treni.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.AppStyle
import com.binario.treni.data.BinarioHistory
import com.binario.treni.data.HomeLayout
import com.binario.treni.data.StyleSpec
import com.binario.treni.data.StyleSpecs
import com.binario.treni.data.TrainRef
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Una funzione della Home mostrata come riquadro, riga o icona a seconda dello stile. */
private data class Tile(
    val id: String, val label: String, val sub: String, val icon: ImageVector, val route: String,
    val group: String, val pastel: Color, val badge: String, val badgeColor: Color,
)

private val TILES = listOf(
    Tile("trains", "Cerca treno", "Per numero o linea", Icons.Filled.Train, "trains", "Cerca", Color(0xFFCFE3FF), "TRN", Color(0xFF0B5CAD)),
    Tile("board", "Arrivi e partenze", "Tabellone stazione", Icons.Filled.DepartureBoard, "stations", "Cerca", Color(0xFFCFF3DD), "STZ", Color(0xFF1F8A4C)),
    Tile("nearby", "Stazioni vicine", "Intorno a te", Icons.Filled.NearMe, "nearby", "Cerca", Color(0xFFD5F0F0), "VIC", Color(0xFF00838F)),
    Tile("map", "Mappa dei treni", "Dove sono adesso", Icons.Filled.Map, "trainsmap", "In tempo reale", Color(0xFFFFE3B8), "MAP", Color(0xFFD4501E)),
    Tile("late", "Classifica ritardi", "Chi è più in ritardo", Icons.Filled.Timer, "ranking", "In tempo reale", Color(0xFFFFD0CC), "RIT", Color(0xFFC62828)),
    Tile("strikes", "Scioperi e notizie", "Cosa cambia", Icons.Filled.Campaign, "news", "In tempo reale", Color(0xFFFFF1A8), "SCI", Color(0xFFB8860B)),
    Tile("reminders", "Allarmi", "Sveglie e promemoria", Icons.Filled.Alarm, "reminders", "I miei", Color(0xFFE6D5FF), "ALL", Color(0xFF6B3FB5)),
    Tile("saved", "Orari offline", "Salvati sul telefono", Icons.Filled.DownloadForOffline, "saved", "I miei", Color(0xFFD9E8FF), "OFF", Color(0xFF3F51B5)),
    Tile("trips", "I miei viaggi", "Ritardi del mese", Icons.Filled.History, "trips", "I miei", Color(0xFFE3F2E1), "VIA", Color(0xFF2E7D32)),
    Tile("stats", "Puntualità", "Statistiche", Icons.Filled.BarChart, "stats", "Informazioni", Color(0xFFD5F0F0), "PUN", Color(0xFF2E7D32)),
    Tile("refunds", "Rimborsi", "Diritti del viaggiatore", Icons.Filled.Gavel, "conditions", "Informazioni", Color(0xFFFFD9EA), "RIM", Color(0xFFAD1457)),
    Tile("help", "Aiuto", "Domande frequenti", Icons.Filled.HelpOutline, "help", "Informazioni", Color(0xFFE3E6ED), "AIU", Color(0xFF546E7A)),
)

private val GROUPS = listOf("Cerca", "In tempo reale", "I miei", "Informazioni")

/**
 * Parte della Home per gli stili con riquadri. Gli stili «tradizionale» e «vintage» non la usano.
 * [hero] è il riquadro «il tuo prossimo treno» (usato dagli stili che lo mettono in primo piano).
 */
@Composable
fun StyleHome(go: (String) -> Unit, onTrain: (TrainRef) -> Unit, hero: @Composable () -> Unit = {}) {
    val sp = AppStyle.spec ?: return
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        when (sp.layout) {
            HomeLayout.GRID2 -> Grid(sp, TILES.take(8), 2, go)
            HomeLayout.MIX -> { Grid(sp, TILES.take(4), 2, go); Spacer(Modifier.height(8.dp)); Rows(sp, TILES.drop(4), go) }
            HomeLayout.LIST -> Sections(sp, go) { items -> Rows(sp, items, go) }
            HomeLayout.GRID3 -> Sections(sp, go) { items -> Grid(sp, items, 3, go) }
            HomeLayout.HERO -> {
                hero()
                Spacer(Modifier.height(8.dp))
                Grid(sp, TILES.take(4), 4, go)
                Spacer(Modifier.height(8.dp))
                Rows(sp, TILES.drop(4), go)
            }
            HomeLayout.DASH -> Dashboard(sp, go, onTrain)
        }
    }
}

@Composable
private fun Sections(sp: StyleSpec, go: (String) -> Unit, content: @Composable (List<Tile>) -> Unit) {
    GROUPS.forEach { g ->
        val items = TILES.filter { it.group == g }
        if (items.isEmpty()) return@forEach
        Text(tx(g).uppercase(), color = sp.muted, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 6.dp))
        content(items)
    }
}

@Composable
private fun Grid(sp: StyleSpec, items: List<Tile>, cols: Int, go: (String) -> Unit) {
    val h = when { cols >= 4 -> 84.dp; cols == 3 -> 92.dp; sp.big -> 132.dp; else -> 108.dp }
    items.chunked(cols).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { t -> TileBox(sp, t, cols, Modifier.weight(1f).height(h)) { go(t.route) } }
            repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

/** Con i colori per daltonici i riquadri pastello e le sigle usano solo tinte distinguibili (azzurro, arancio, grigio). */
private fun cbPastel(sp: StyleSpec, t: Tile): Color =
    if (!com.binario.treni.data.ColorBlind.on) { if (sp.rainbow) StyleSpecs.RAINBOW[TILES.indexOf(t).coerceAtLeast(0) % 7].first else t.pastel } else listOf(Color(0xFFD6EAF8), Color(0xFFFDEBD0), Color(0xFFE3E6ED))[TILES.indexOf(t).coerceAtLeast(0) % 3]

private fun cbBadge(t: Tile): Color =
    if (!com.binario.treni.data.ColorBlind.on) t.badgeColor
    else listOf(Color(com.binario.treni.data.ColorBlind.brand), Color(0xFFB35900), Color(0xFF546E7A))[TILES.indexOf(t).coerceAtLeast(0) % 3]

@Composable
private fun TileBox(sp: StyleSpec, t: Tile, cols: Int, modifier: Modifier, onClick: () -> Unit) {
    val bg = if (sp.colorful) cbPastel(sp, t) else MaterialTheme.colorScheme.surface
    val fg = MaterialTheme.colorScheme.onSurface
    val icon = if (sp.rainbow && !com.binario.treni.data.ColorBlind.on) StyleSpecs.RAINBOW[TILES.indexOf(t).coerceAtLeast(0) % 7].second else if (sp.colorful) fg else sp.primary
    val compact = cols >= 3
    Surface(
        onClick = onClick, modifier = modifier, shape = RoundedCornerShape(sp.radius.dp), color = bg,
        border = if (sp.border > 0) BorderStroke(sp.border.dp, sp.borderColor) else null,
        shadowElevation = if (sp.border == 0 && !sp.colorful) 1.dp else 0.dp,
    ) {
        if (compact) Column(Modifier.fillMaxSize().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(t.icon, null, tint = icon, modifier = Modifier.size(if (cols >= 4) 24.dp else 26.dp))
            Spacer(Modifier.height(4.dp))
            Text(tx(t.label), color = fg, fontSize = if (cols >= 4) 11.sp else 12.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = com.binario.treni.data.TextScale.lines(2), lineHeight = 14.sp)
        } else Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(t.icon, null, tint = icon, modifier = Modifier.size(if (sp.big) 36.dp else 28.dp))
            Column {
                Text(tx(t.label), color = fg, fontSize = if (sp.big) 20.sp else 16.sp, fontWeight = if (sp.big) FontWeight.ExtraBold else FontWeight.SemiBold, lineHeight = if (sp.big) 22.sp else 18.sp)
                if (!sp.big) Text(tx(t.sub), color = sp.muted, fontSize = 12.sp, maxLines = com.binario.treni.data.TextScale.lines(1))
            }
        }
    }
}

@Composable
private fun Rows(sp: StyleSpec, items: List<Tile>, go: (String) -> Unit) {
    items.forEach { t ->
        Surface(
            onClick = { go(t.route) }, shape = RoundedCornerShape(sp.radius.dp), color = MaterialTheme.colorScheme.surface,
            border = if (sp.border > 0) BorderStroke(sp.border.dp, sp.borderColor) else null,
            shadowElevation = if (sp.border == 0) 1.dp else 0.dp,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        ) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                if (sp.badges) Box(
                    Modifier.defaultMinSize(minWidth = 46.dp).height(30.dp).clip(RoundedCornerShape(8.dp)).background(cbBadge(t)).padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(t.badge, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp) }
                else Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(sp.primary.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                    Icon(t.icon, null, tint = sp.primary)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(tx(t.label), fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(tx(t.sub), color = sp.muted, fontSize = 13.sp, maxLines = com.binario.treni.data.TextScale.lines(1))
                }
                Icon(Icons.Filled.ChevronRight, null, tint = sp.muted)
            }
        }
    }
}

/** Cruscotto: ultimi 30 giorni dai dati raccolti da Binario (se già disponibili), ritardi del momento, sciopero e scorciatoie. */
@Composable
private fun Dashboard(sp: StyleSpec, go: (String) -> Unit, onTrain: (TrainRef) -> Unit) {
    val ctx = LocalContext.current
    var sum by remember { mutableStateOf<BinarioHistory.Summary?>(null) }
    LaunchedEffect(Unit) { sum = withContext(Dispatchers.IO) { runCatching { BinarioHistory.summary(ctx) }.getOrNull() } }
    sum?.let { s ->
        Text(tx("Ultimi 30 giorni, treni osservati da Binario").uppercase(), color = sp.muted, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Kpi(sp, tx("In orario"), "%.0f%%".format(s.punctuality), OnTime, Modifier.weight(1f))
            Kpi(sp, tx("Ritardo medio"), "%.1f min".format(s.avgDelay), if (s.avgDelay > 5) LateRed else sp.primary, Modifier.weight(1f))
            Kpi(sp, tx("Soppressi"), s.cancelled.toString(), if (s.cancelled > 0) LateRed else sp.primary, Modifier.weight(1f))
        }
    }
    DelayedNowCard(onTrain)
    Spacer(Modifier.height(4.dp))
    Grid(sp, TILES.filter { it.id in setOf("trains", "board", "map", "late", "stats") }, 3, go)
}

@Composable
private fun Kpi(sp: StyleSpec, label: String, value: String, color: Color, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(sp.radius.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 1.dp) {
        Column(Modifier.padding(12.dp)) {
            Text(label, color = sp.muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = com.binario.treni.data.TextScale.lines(1))
            Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, fontFamily = if (sp.mono) FontFamily.Monospace else FontFamily.Default, maxLines = com.binario.treni.data.TextScale.lines(1))
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Scelta dello stile (Impostazioni)
// ---------------------------------------------------------------------------------------------------------------------

/** Riga delle impostazioni che apre l'elenco degli stili, ognuno con la sua anteprima a colori. */
@Composable
fun StylePickerSetting(onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf(false) }
    val id = AppStyle.id
    val current = when (id) {
        "classic" -> tx("Tradizionale")
        "vintage" -> tx("Vintage (tabellone a palette)")
        else -> StyleSpecs.byId(id)?.let { tx(it.name) } ?: id
    }
    Surface(onClick = { open = true }, color = Color.Transparent, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tx("Stile dell'app"), color = Muted, fontSize = 13.sp)
                Text(current, fontSize = 17.sp)
            }
            Icon(Icons.Filled.ArrowDropDown, null, tint = Muted)
        }
    }
    if (open) AlertDialog(
        onDismissRequest = { open = false },
        title = { Text(tx("Scegli lo stile")) },
        text = {
            androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 480.dp)) {
                item { Text(tx("Lo stile cambia colori, forme e disposizione della Home, anche nei widget. Puoi cambiarlo quando vuoi."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp)) }
                item { StyleOption("classic", tx("Tradizionale"), tx("L'aspetto di sempre, verde"), listOf(Color(0xFF4F9447), Color.White, Color(0xFFEDEDED)), id) { pick(ctx, it, { open = false }, onChanged) } }
                item { StyleOption("vintage", tx("Vintage (tabellone a palette)"), tx("Tabellone Solari scuro e ambra"), listOf(Color(0xFFF5C84C), Color(0xFF18181A), Color(0xFF0B0B0C)), id) { pick(ctx, it, { open = false }, onChanged) } }
                keyedItems(StyleSpecs.ALL.indices.toList()) { i ->
                    val s = StyleSpecs.ALL[i]
                    val sw = if (s.rainbow) StyleSpecs.RAINBOW.take(3).map { it.second } else listOf(s.primary, s.surface, s.background)
                    StyleOption(s.id, tx(s.name), tx(s.desc), sw, id) { pick(ctx, it, { open = false }, onChanged) }
                }
                item {
                    val cs = StyleSpecs.custom(Color(AppStyle.customPrimary), AppStyle.customDark)
                    StyleOption("custom", tx("Colori personalizzati"), tx("Scegli tu il colore principale"), listOf(cs.primary, cs.surface, cs.background), id) { open = false; custom = true }
                }
            }
        },
        confirmButton = { TextButton({ open = false }) { Text(tx("Chiudi")) } },
    )
    if (custom) CustomColorsDialog(onDismiss = { custom = false }) { color, dark ->
        AppStyle.setCustom(ctx, color, dark)
        com.binario.treni.widget.Widgets.restyle(ctx)
        custom = false; onChanged()
    }
}

/** Scelta dei colori personalizzati: tavolozza o codice esadecimale, fondo chiaro o scuro, con anteprima. */
@Composable
private fun CustomColorsDialog(onDismiss: () -> Unit, onApply: (Int, Boolean) -> Unit) {
    var color by remember { mutableStateOf(AppStyle.customPrimary) }
    var dark by remember { mutableStateOf(AppStyle.customDark) }
    var hex by remember { mutableStateOf("%06X".format(AppStyle.customPrimary and 0xFFFFFF)) }
    fun setColor(c: Int) { color = c; hex = "%06X".format(c and 0xFFFFFF) }
    val spec = StyleSpecs.custom(Color(color), dark)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Colori personalizzati")) },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                // Anteprima
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(spec.background).padding(10.dp)) {
                    Column {
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(spec.topBar).padding(12.dp)) {
                            Text("Binario", color = spec.onTopBar, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(spec.radius.dp)).background(spec.surface).padding(12.dp)) {
                            Text(tx("Cerca treno"), color = spec.onSurface)
                        }
                        Spacer(Modifier.height(8.dp))
                        Box(Modifier.clip(RoundedCornerShape(8.dp)).background(spec.primary).padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text(tx("Cerca"), color = spec.onPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(tx("Colore principale"), color = Muted, fontSize = 13.sp)
                StyleSpecs.PALETTE.chunked(6).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { c ->
                            Box(
                                Modifier.size(40.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(c))
                                    .then(if (c == color) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, androidx.compose.foundation.shape.CircleShape) else Modifier)
                                    .clickable { setColor(c) },
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = hex, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    label = { Text(tx("Codice colore (esadecimale)")) }, prefix = { Text("#") },
                    onValueChange = { v ->
                        val t = v.filter { it.isLetterOrDigit() }.take(6).uppercase()
                        hex = t
                        if (t.length == 6) t.toIntOrNull(16)?.let { color = it or 0xFF000000.toInt() }
                    },
                )
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tx("Sfondo scuro"), Modifier.weight(1f))
                    Switch(dark, { dark = it })
                }
            }
        },
        confirmButton = { TextButton({ onApply(color or 0xFF000000.toInt(), dark) }) { Text(tx("Applica")) } },
        dismissButton = { TextButton(onDismiss) { Text(tx("Annulla")) } },
    )
}

private fun pick(ctx: android.content.Context, id: String, close: () -> Unit, changed: () -> Unit) {
    AppStyle.set(ctx, id)
    // I widget prendono subito i colori del nuovo stile
    com.binario.treni.widget.Widgets.restyle(ctx)
    close(); changed()
}

@Composable
private fun StyleOption(id: String, name: String, desc: String, swatch: List<Color>, selected: String, onPick: (String) -> Unit) {
    Surface(onClick = { onPick(id) }, color = Color.Transparent, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.clip(RoundedCornerShape(8.dp))) { swatch.forEach { Box(Modifier.size(width = 18.dp, height = 40.dp).background(it)) } }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(desc, color = Muted, fontSize = 12.sp)
            }
            RadioButton(selected == id, { onPick(id) })
        }
    }
}
