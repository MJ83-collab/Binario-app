package com.binario.treni.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Nessuna rete: l'app rinuncia subito invece di aspettare i tempi di attesa. */
class OfflineException : java.io.IOException("Offline")

/**
 * Stato della rete. Serve a due cose: mostrare la striscia «Sei offline» e far fallire subito le richieste quando
 * il telefono non ha nessuna rete con Internet (prima ogni richiesta aspettava fino a 15 + 20 secondi).
 * Se il controllo non è disponibile (test, servizio non pronto) non blocca mai nulla.
 */
object Net {
    /** Per la striscia «Sei offline» nella schermata. */
    var online by mutableStateOf(true)

    /** Solo per i test: simula l'assenza di rete. */
    @Volatile var forceOffline: Boolean = false

    @Volatile private var cm: ConnectivityManager? = null

    fun init(ctx: Context) {
        try {
            val m = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm = m
            online = hasInternet(m)
            m.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { online = true }
                override fun onLost(network: Network) { online = hasInternet(m) }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    online = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                }
            })
        } catch (_: Exception) {
            cm = null
        }
    }

    private fun hasInternet(m: ConnectivityManager): Boolean {
        val n = m.activeNetwork ?: return false
        val c = m.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Lancia [OfflineException] se il telefono non ha nessuna rete con Internet. */
    fun requireOnline() {
        if (forceOffline) throw OfflineException()
        val m = cm ?: return
        val ok = try { hasInternet(m) } catch (_: Exception) { true }
        if (!ok) throw OfflineException()
    }
}

/** Ricorda se di recente l'app ha mostrato dati non aggiornati (perché il servizio non rispondeva). */
object Freshness {
    @Volatile private var ageMs = 0L
    @Volatile private var at = 0L

    fun note(age: Long, now: Long = System.currentTimeMillis()) { ageMs = age; at = now }

    /** Età dei dati mostrati, se negli ultimi [window] ms ne è stato servito qualcuno di scaduto; altrimenti null. */
    fun ageIfRecent(now: Long, window: Long = 60_000L): Long? = if (at != 0L && now - at < window) ageMs else null

    fun reset() { ageMs = 0L; at = 0L }
}
