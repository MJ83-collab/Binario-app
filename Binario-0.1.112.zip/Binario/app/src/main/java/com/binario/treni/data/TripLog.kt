package com.binario.treni.data

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import org.json.JSONArray
import org.json.JSONObject

/**
 * Un viaggio seguito con «Segui questo treno» fino all'arrivo, oppure soppresso mentre lo si seguiva.
 * Resta solo sul telefono: serve a ricordare i ritardi del mese (bonus degli abbonati, indennizzi).
 */
data class TripEntry(
    /** Treno + origine + giorno: lo stesso viaggio non si conta due volte. */
    val key: String,
    /** Giorno del viaggio, "aaaa-mm-gg" (ora italiana). */
    val day: String,
    val train: String,
    val from: String,
    val to: String,
    val schedArr: Long,
    val realArr: Long,
    /** Minuti di ritardo all'arrivo (0 se in anticipo). */
    val delay: Int,
    val cancelled: Boolean = false,
    /** Inserito a mano (non seguito con «Segui»): lo si dice nell'elenco e nel testo esportato. */
    val manual: Boolean = false,
) {
    /** Momento usato per ordinare l'elenco. */
    val time: Long get() = if (realArr > 0) realArr else schedArr
}

/** Riepilogo di un mese di viaggi. */
data class TripSummary(
    val trips: Int,
    val onTime: Int,
    val late15: Int,
    val late60: Int,
    val cancelled: Int,
    val delayMinutes: Int,
) {
    /** Viaggi fatti davvero (senza i soppressi). */
    val ran: Int get() = trips - cancelled

    /** Puntualità: viaggi in orario (fino a 5 minuti) sui viaggi fatti, in percentuale; null se non ce n'è nessuno. */
    val punctuality: Int? get() = if (ran <= 0) null else Math.round(onTime * 100f / ran)
}

object TripLog {
    /** Circa tre anni di andata e ritorno nei giorni feriali (500 bastavano appena per un anno e tagliavano il riepilogo annuale). */
    const val MAX = 1500

    /** Come nelle statistiche di puntualità: «in orario» fino a 5 minuti di ritardo. */
    const val ON_TIME_MIN = 5
    private const val KEY = "trip_log"
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")

    fun dayOf(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date(ms))

    /** Mese "aaaa-mm" di un istante. */
    fun monthOf(ms: Long): String = dayOf(ms).substring(0, 7)

    fun keyOf(number: String, originCode: String, day: String): String = "$number/$originCode@$day"

    /** Mese spostato di [delta] mesi: "2026-01" con -1 dà "2025-12". */
    fun shift(month: String, delta: Int): String {
        val y = month.substring(0, 4).toInt()
        val m = month.substring(5, 7).toInt()
        val t = y * 12 + (m - 1) + delta
        return String.format(Locale.US, "%04d-%02d", t / 12, t % 12 + 1)
    }

    /** Aggiunge o sostituisce (stessa chiave); il più recente in cima; al massimo [max] viaggi. */
    fun upsert(list: List<TripEntry>, e: TripEntry, max: Int = MAX): List<TripEntry> =
        (listOf(e) + list.filter { it.key != e.key }).sortedByDescending { it.time }.take(max)

    fun inMonth(list: List<TripEntry>, month: String): List<TripEntry> = list.filter { it.day.startsWith("$month-") }

    /** Tratta di un viaggio senza verso (andata e ritorno insieme), senza maiuscole: «milano⇄varese». */
    fun routeKey(e: TripEntry): String = listOf(e.from.trim().lowercase(), e.to.trim().lowercase()).sorted().joinToString("⇄")

    /** Una tratta del diario da scegliere nel filtro, con quanti viaggi ha. */
    data class RouteOption(val key: String, val label: String, val trips: Int)

    /** Tratte del diario, dalla più frequente; il nome è quello del viaggio più recente («Varese ⇄ Milano»). */
    fun routeOptions(list: List<TripEntry>): List<RouteOption> =
        list.groupBy { routeKey(it) }.map { (k, l) -> l.maxBy { it.time }.let { RouteOption(k, "${it.from.trim()} ⇄ ${it.to.trim()}", l.size) } }
            .sortedWith(compareByDescending<RouteOption> { it.trips }.thenBy { it.label })

    /** Solo i viaggi della tratta [key] (tutti se null). */
    fun byRoute(list: List<TripEntry>, key: String?): List<TripEntry> = if (key.isNullOrBlank()) list else list.filter { routeKey(it) == key }

    /** Fasce orarie dell'arrivo previsto: 0 mattina (5–10), 1 giorno (10–16), 2 sera (16–21), 3 notte (21–5). */
    fun slotOf(ms: Long): Int {
        val h = java.util.Calendar.getInstance(rome).apply { timeInMillis = ms }.get(java.util.Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..9 -> 0
            in 10..15 -> 1
            in 16..20 -> 2
            else -> 3
        }
    }

    /** Una fascia oraria: viaggi, ritardo medio (senza i soppressi), quanti con 15 minuti o più, quanti soppressi. */
    data class SlotStat(val slot: Int, val trips: Int, val avgDelay: Int, val late15: Int, val cancelled: Int)

    /** Le quattro fasce (anche vuote), per i viaggi con l'orario previsto. */
    fun bySlot(list: List<TripEntry>): List<SlotStat> {
        val g = list.filter { it.schedArr > 0 }.groupBy { slotOf(it.schedArr) }
        return (0..3).map { k ->
            val l = g[k].orEmpty()
            val ran = l.filter { !it.cancelled }
            SlotStat(k, l.size, if (ran.isEmpty()) 0 else Math.round(ran.sumOf { it.delay.coerceAtLeast(0) }.toFloat() / ran.size),
                ran.count { it.delay >= 15 }, l.count { it.cancelled })
        }
    }

    /** La fascia con il ritardo medio più alto, solo se ha almeno 3 viaggi e un ritardo medio di almeno 1 minuto (null altrimenti). */
    fun worstSlot(stats: List<SlotStat>): Int? = stats.filter { it.trips >= 3 && it.avgDelay >= 1 }.maxByOrNull { it.avgDelay }?.slot

    /** Viaggi di un anno («aaaa»). */
    fun inYear(list: List<TripEntry>, year: String): List<TripEntry> = list.filter { it.day.startsWith("$year-") }

    /** Un giorno del grafico del mese: ritardo più alto dei viaggi fatti, se c'è stato un soppresso, quanti viaggi. */
    data class DayBar(val day: Int, val delay: Int, val cancelled: Boolean, val trips: Int)

    /** Tutti i giorni del mese (anche quelli senza viaggi), per il grafico. */
    fun dailyBars(list: List<TripEntry>, month: String): List<DayBar> {
        val c = java.util.Calendar.getInstance(rome).apply {
            clear(); set(month.substring(0, 4).toInt(), month.substring(5, 7).toInt() - 1, 1)
        }
        val days = c.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
        val byDay = inMonth(list, month).groupBy { it.day.substring(8, 10).toInt() }
        return (1..days).map { d ->
            val l = byDay[d].orEmpty()
            DayBar(d, l.filter { !it.cancelled }.maxOfOrNull { it.delay.coerceAtLeast(0) } ?: 0, l.any { it.cancelled }, l.size)
        }
    }

    /** Il grafico detto a parole (lettore vocale): giorni con viaggi, ritardo più alto e quando, soppressi. */
    fun chartDescription(bars: List<DayBar>): String {
        val withTrips = bars.count { it.trips > 0 }
        val worst = bars.filter { it.trips > 0 }.maxByOrNull { it.delay }
        val cancelled = bars.count { it.cancelled }
        return if (worst == null || worst.delay <= 0) {
            tx("Giorni con viaggi: {0}. Nessun ritardo. Soppressi: {1}.").replace("{0}", "$withTrips").replace("{1}", "$cancelled")
        } else {
            tx("Giorni con viaggi: {0}. Ritardo più alto: {1} minuti il giorno {2}. Soppressi: {3}.")
                .replace("{0}", "$withTrips").replace("{1}", "${worst.delay}").replace("{2}", "${worst.day}").replace("{3}", "$cancelled")
        }
    }

    /** Si può chiedere un indennizzo: almeno 60 minuti di ritardo all'arrivo (Regolamento UE 2021/782) oppure treno soppresso. */
    fun claimable(e: TripEntry): Boolean = e.cancelled || e.delay >= 60

    /**
     * Testo della richiesta all'azienda, in italiano come quello della scheda del treno (va alle aziende italiane).
     * 25% dai 60 minuti, 50% dai 120; per un soppresso si chiede rimborso o indennizzo. Un viaggio inserito a mano lo dice.
     */
    fun claimText(e: TripEntry): String {
        val day = SimpleDateFormat("dd/MM/yyyy", Locale.ITALY).apply { timeZone = rome }
        val hm = SimpleDateFormat("HH:mm", Locale.ITALY).apply { timeZone = rome }
        val date = if (e.schedArr > 0) day.format(Date(e.schedArr)) else e.day.split("-").reversed().joinToString("/")
        val pct = if (e.delay >= 120) "50%" else if (e.delay >= 60) "25%" else ""
        return buildString {
            append(if (e.cancelled) "Oggetto: richiesta di rimborso per la soppressione del treno ${e.train}\n\n"
            else "Oggetto: richiesta di indennizzo per ritardo del treno ${e.train}\n\n")
            append("Data del viaggio: $date\n")
            append("Treno: ${e.train}, ${e.from} → ${e.to}\n")
            if (e.schedArr > 0) append("Arrivo previsto a ${e.to}: ${hm.format(Date(e.schedArr))}\n")
            if (e.cancelled) append("Il treno è stato soppresso.\n\n")
            else {
                if (e.realArr > 0) append("Arrivo effettivo: ${hm.format(Date(e.realArr))}\n")
                append("Ritardo all'arrivo: ${e.delay} minuti\n\n")
            }
            // Dati che l'azienda chiede sempre: restano da completare a mano (l'app non li conosce)
            append("Nome e cognome: \n")
            append("Numero del biglietto o dell'abbonamento: \n\n")
            append("Ai sensi del Regolamento (UE) 2021/782 sui diritti dei passeggeri, chiedo ")
            append(if (e.cancelled) "il rimborso o l'indennizzo previsto per la soppressione del treno.\n"
            else "l'indennizzo previsto" + (if (pct.isNotEmpty()) " ($pct del prezzo del biglietto)" else "") + " per il ritardo subito.\n")
            append("Allego il titolo di viaggio. ")
            append(if (e.manual) "Orari annotati dal passeggero.\n\n" else "Dati di marcia da ViaggiaTreno, verificabili con il vettore.\n\n")
            append("Cordiali saluti")
        }
    }

    /** Una riga del diario letta per intero dal lettore vocale. */
    fun spoken(e: TripEntry, date: String): String {
        val state = when {
            e.cancelled -> tx("Soppresso")
            e.delay > 0 -> tx("{0} minuti di ritardo").replace("{0}", "${e.delay}")
            else -> tx("in orario")
        }
        return "${e.train}, ${e.from} → ${e.to}, $date, $state" + if (e.manual) ", " + tx("inserito a mano") else ""
    }

    fun summary(list: List<TripEntry>): TripSummary {
        val ran = list.filter { !it.cancelled }
        return TripSummary(
            trips = list.size,
            onTime = ran.count { it.delay <= ON_TIME_MIN },
            late15 = ran.count { it.delay >= 15 },
            late60 = ran.count { it.delay >= 60 },
            cancelled = list.count { it.cancelled },
            delayMinutes = ran.sumOf { it.delay.coerceAtLeast(0) },
        )
    }

    /**
     * Testo da condividere per un mese (da allegare a una richiesta di bonus o indennizzo):
     * un viaggio per riga, dal più vecchio, poi il riepilogo e l'avvertenza che non è un'attestazione ufficiale.
     */
    fun exportText(title: String, list: List<TripEntry>, time: (TripEntry) -> String = { if (it.time > 0) Fmt.dayTime(it.time) else it.day }): String =
        buildString {
            appendLine(title)
            appendLine()
            list.sortedBy { it.time }.forEach { e ->
                val d = when {
                    e.cancelled -> tx("Soppresso")
                    e.delay > 0 -> "+${e.delay} min"
                    else -> tx("in orario")
                }
                appendLine("${time(e)} · ${e.train} · ${e.from} → ${e.to} · $d" + if (e.manual) " · " + tx("inserito a mano") else "")
            }
            val s = summary(list)
            appendLine()
            appendLine(tx("Viaggi") + ": " + s.trips)
            appendLine(tx("In orario (fino a 5 min)") + ": " + s.onTime)
            s.punctuality?.let { appendLine(tx("Puntualità") + ": " + it + "%") }
            appendLine(tx("Ritardo di 15 min o più") + ": " + s.late15)
            appendLine(tx("Ritardo di 60 min o più") + ": " + s.late60)
            appendLine(tx("Soppressi") + ": " + s.cancelled)
            appendLine(tx("Minuti di ritardo in tutto") + ": " + s.delayMinutes)
            appendLine()
            append(tx("Orari rilevati dall'app Binario: non sostituiscono le attestazioni ufficiali dell'azienda."))
        }

    /**
     * Riepilogo mensile: dal giorno 1 al 3 (se il telefono era spento il primo) il mese prima da riassumere,
     * solo se ha avuto ritardi di 15 minuti o più o soppressioni e se non è già stato avvisato ([lastSent] = mese «aaaa-mm»).
     */
    fun monthlyDue(list: List<TripEntry>, now: Long, lastSent: String): String? {
        val c = java.util.Calendar.getInstance(rome).apply { timeInMillis = now }
        if (c.get(java.util.Calendar.DAY_OF_MONTH) > 3) return null
        val prev = shift(monthOf(now), -1)
        if (prev == lastSent) return null
        val s = summary(inMonth(list, prev))
        return prev.takeIf { s.trips > 0 && (s.late15 > 0 || s.cancelled > 0) }
    }

    /**
     * Diario come CSV per un foglio di calcolo: separatore «;» (Excel in italiano usa la virgola per i decimali),
     * BOM iniziale per gli accenti, una riga per viaggio dal più vecchio. Le intestazioni seguono la lingua dell'app.
     */
    fun toCsv(list: List<TripEntry>): String {
        fun cell(raw: String): String {
            // Un testo scritto a mano che inizia con = + - @ verrebbe preso per una formula da Excel: lo si apre con l'apostrofo
            val v = if (raw.isNotEmpty() && raw[0] in "=+-@\t") "'$raw" else raw
            return if (v.any { it == ';' || it == '"' || it == '\n' || it == '\r' }) "\"" + v.replace("\"", "\"\"") + "\"" else v
        }
        val day = SimpleDateFormat("dd/MM/yyyy", Locale.ITALY).apply { timeZone = rome }
        val hm = SimpleDateFormat("HH:mm", Locale.ITALY).apply { timeZone = rome }
        val head = listOf(tx("Data"), tx("Arrivo previsto"), tx("Treno"), tx("Da"), tx("A"), tx("Ritardo (min)"), tx("Soppresso"), tx("inserito a mano"))
        val rows = list.sortedBy { it.time }.map { e ->
            val d = if (e.schedArr > 0) day.format(Date(e.schedArr)) else e.day.split("-").reversed().joinToString("/")
            listOf(
                d, if (e.schedArr > 0) hm.format(Date(e.schedArr)) else "", e.train, e.from, e.to,
                if (e.cancelled) "" else e.delay.toString(), if (e.cancelled) tx("Sì") else tx("No"), if (e.manual) tx("Sì") else tx("No"),
            )
        }
        return "\uFEFF" + (listOf(head) + rows).joinToString("\r\n") { r -> r.joinToString(";") { cell(it) } } + "\r\n"
    }

    /** Perché un viaggio inserito a mano non va bene (null = va bene). */
    enum class ManualError { TRAIN, PLACES, DATE, FUTURE, DELAY }

    /**
     * Viaggio inserito a mano: treno (con il numero), da, a, data «gg/mm/aaaa», ora di arrivo prevista «hh:mm»,
     * ritardo in minuti (0–999; vuoto = 0) oppure soppresso. Non nel futuro (oltre [now]).
     */
    fun manualEntry(
        train: String, from: String, to: String, date: String, time: String, delay: String, cancelled: Boolean,
        now: Long = System.currentTimeMillis(),
    ): Pair<TripEntry?, ManualError?> {
        val t = train.trim().replace(Regex("\\s+"), " ")
        if (t.none { it.isDigit() }) return null to ManualError.TRAIN
        if (from.isBlank() || to.isBlank()) return null to ManualError.PLACES
        val at = try {
            SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALY).apply { timeZone = rome; isLenient = false }
                .parse(date.trim() + " " + time.trim())?.time
        } catch (_: Exception) {
            null
        } ?: return null to ManualError.DATE
        if (at > now + 60 * 60_000L) return null to ManualError.FUTURE
        val d = if (cancelled) 0 else (delay.trim().ifBlank { "0" }.toIntOrNull()?.takeIf { it in 0..999 } ?: return null to ManualError.DELAY)
        val day = dayOf(at)
        val e = TripEntry(
            key = "manuale/" + t.filter { it.isDigit() } + "@" + day + "@" + at,
            day = day, train = t, from = from.trim(), to = to.trim(), schedArr = at,
            realArr = if (cancelled) 0L else at + d * 60_000L, delay = d, cancelled = cancelled, manual = true,
        )
        return e to null
    }

    fun encode(list: List<TripEntry>): String = JSONArray().apply {
        list.forEach { e ->
            put(
                JSONObject().put("k", e.key).put("d", e.day).put("t", e.train).put("f", e.from).put("a", e.to)
                    .put("s", e.schedArr).put("r", e.realArr).put("ri", e.delay).put("c", e.cancelled).put("m", e.manual),
            )
        }
    }.toString()

    fun decode(s: String?): List<TripEntry> {
        if (s.isNullOrBlank()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).mapNotNull { i ->
                val o = a.optJSONObject(i) ?: return@mapNotNull null
                TripEntry(
                    key = o.optString("k"), day = o.optString("d"), train = o.optString("t"),
                    from = o.optString("f"), to = o.optString("a"), schedArr = o.optLong("s"), realArr = o.optLong("r"),
                    delay = o.optInt("ri"), cancelled = o.optBoolean("c"), manual = o.optBoolean("m"),
                ).takeIf { it.key.isNotBlank() && it.day.length == 10 }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    // ---- Memoria sul telefono ----

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("binario", Context.MODE_PRIVATE)

    fun all(ctx: Context): List<TripEntry> = decode(prefs(ctx).getString(KEY, null))

    /** Salva il viaggio; se è già salvato uguale non riscrive nulla (il servizio lo può chiamare più volte). */
    @Synchronized
    fun record(ctx: Context, e: TripEntry) {
        val list = all(ctx)
        if (list.firstOrNull { it.key == e.key } == e) return
        prefs(ctx).edit().putString(KEY, encode(upsert(list, e))).apply()
    }

    fun monthlySent(ctx: Context): String = prefs(ctx).getString("trip_month_sent", "") ?: ""

    fun markMonthlySent(ctx: Context, month: String) {
        prefs(ctx).edit().putString("trip_month_sent", month).apply()
    }

    @Synchronized
    fun delete(ctx: Context, key: String) {
        prefs(ctx).edit().putString(KEY, encode(all(ctx).filter { it.key != key })).apply()
    }

    @Synchronized
    fun clear(ctx: Context) {
        prefs(ctx).edit().remove(KEY).apply()
    }
}
