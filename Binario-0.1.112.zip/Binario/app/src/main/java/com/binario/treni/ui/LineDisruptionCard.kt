package com.binario.treni.ui

import androidx.compose.foundation.layout.Column
import java.util.TimeZone
import java.util.Locale
import java.text.SimpleDateFormat
import com.binario.treni.data.I18n
import com.binario.treni.data.TripLog
import com.binario.treni.data.DisruptionHistory
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.DisruptionSummary
import com.binario.treni.data.LineDisruption
import com.binario.treni.data.LineDisruptionLoader
import com.binario.treni.data.Linea
import com.binario.treni.data.TiloLines
import com.binario.treni.data.tx

/**
 * «Disagio sulla linea»: quanti treni partiti nelle ultime 3 ore (in entrambe le direzioni) sono soppressi,
 * limitati o con più di 15 minuti di ritardo. Si calcola quando si apre la linea; [refresh] lo ricalcola.
 * Non per le linee svizzere: l'orario svizzero ha un limite di richieste giornaliero.
 */
@Composable
fun LineDisruptionCard(line: Linea, refresh: Int) {
    val tilo = TiloLines.isTilo(line)
    var summary by remember(line.key) { mutableStateOf<DisruptionSummary?>(null) }
    var loading by remember(line.key) { mutableStateOf(true) }
    var failed by remember(line.key) { mutableStateOf(false) }
    val ctx = LocalContext.current
    var history by remember(line.key) { mutableStateOf(DisruptionHistory.get(ctx, line)) }
    LaunchedEffect(line.key, refresh) {
        loading = true
        val r = LineDisruptionLoader.load(line)
        if (r != null) {
            DisruptionHistory.record(ctx, line, r)
            history = DisruptionHistory.get(ctx, line)
        }
        summary = r
        failed = r == null
        loading = false
    }
    if (failed) return
    WhiteCard {
        CardTitle(tx("Disagio sulla linea (ultime 3 ore)"))
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            val s = summary
            when {
                loading -> Text(tx("Controllo i treni delle ultime ore…"), color = Muted, fontSize = 13.sp)
                s == null || s.checked == 0 -> Text(tx("Nessun treno partito nelle ultime 3 ore."), color = Muted, fontSize = 13.sp)
                else -> {
                    // Il livello è scritto a parole, non solo con il colore (daltonici, TalkBack)
                    val word = levelWord(s.percent)
                    val critical = tx("{0} treni critici su {1}").replace("{0}", s.critical.toString()).replace("{1}", s.checked.toString())
                    Row(
                        Modifier.semantics(mergeDescendants = true) { contentDescription = "${s.percent}% · $word · $critical" },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${s.percent}%", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = levelColor(s.percent))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(word, fontWeight = FontWeight.Bold, color = levelColor(s.percent))
                            Text(critical, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    if (tilo) {
                        // Orario svizzero: i ritardi ci sono, le soppressioni no (lo si dice, per non far credere «tutto regolare»)
                        Text(tx("Oltre 15 min") + " ${s.late}", fontSize = 13.sp)
                        Text(
                            tx("Treni TILO partiti nelle ultime 3 ore, in entrambe le direzioni, dall'orario svizzero: conta i ritardi oltre 15 minuti, non i treni soppressi. Per le soppressioni guarda gli avvisi FFS qui sotto."),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    } else {
                        Text(
                            tx("Soppressi") + " ${s.cancelled} · " + tx("Limitati") + " ${s.limited} · " + tx("Oltre 15 min") + " ${s.late}",
                            fontSize = 13.sp,
                        )
                        Text(
                            tx("Treni partiti nelle ultime 3 ore, in entrambe le direzioni. Critico: soppresso, limitato o con più di 15 minuti di ritardo."),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                    if (history.size >= 2) HistoryRow(history)
                }
            }
        }
    }
}

/** Verde (o blu per i daltonici) sotto il 10%, ambra fino al 25%, rosso sopra. */
private fun levelColor(percent: Int): Color = when (LineDisruption.level(percent)) {
    0 -> OnTime
    1 -> Color(0xFFE08A00)
    else -> LateRed
}

/** Lo stesso livello a parole. */
private fun levelWord(percent: Int): String = when (LineDisruption.level(percent)) {
    0 -> tx("Disagio basso")
    1 -> tx("Disagio medio")
    else -> tx("Disagio alto")
}

/** Andamento degli ultimi giorni (il momento peggiore di ciascun giorno), dal più vecchio a oggi: giorno e percentuale scritti. */
@Composable
private fun HistoryRow(history: List<Pair<String, Int>>) {
    val now = System.currentTimeMillis()
    val today = TripLog.dayOf(now)
    val yesterday = TripLog.dayOf(now - 86_400_000L)
    val days = history.reversed()
    Text(tx("Ultimi giorni (momento peggiore)"), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
    Row(
        Modifier.fillMaxWidth().padding(top = 4.dp).clearAndSetSemantics {
            contentDescription = days.joinToString(", ") { (d, p) -> dayShort(d, today, yesterday) + " " + p + "% " + levelWord(p) }
        },
    ) {
        days.forEach { (d, p) ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$p%", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = levelColor(p))
                Text(dayShort(d, today, yesterday), fontSize = 11.sp, color = Muted, maxLines = 1)
            }
        }
    }
}

/** «oggi», «ieri», altrimenti il giorno della settimana con il numero («lun 9»). */
private fun dayShort(day: String, today: String, yesterday: String): String = when (day) {
    today -> tx("oggi")
    yesterday -> tx("ieri")
    else -> try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("Europe/Rome") }.parse(day)!!
        SimpleDateFormat(if (I18n.cjk) "M/d" else "EEE d", I18n.locale).apply { timeZone = TimeZone.getTimeZone("Europe/Rome") }.format(d)
    } catch (_: Exception) {
        day.takeLast(2)
    }
}
