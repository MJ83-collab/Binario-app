package com.binario.treni.service

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import com.binario.treni.data.Diag
import com.binario.treni.data.LineDisruption
import com.binario.treni.data.LineDisruptionLoader
import com.binario.treni.data.LineNotice
import com.binario.treni.data.Store
import com.binario.treni.data.tx
import com.binario.treni.ui.LineInfo
import com.binario.treni.ui.TRENORD_LINES_JS
import com.binario.treni.ui.TRENORD_LINES_URL
import com.binario.treni.ui.loadSavedTrenordLines
import com.binario.treni.ui.parseTrenordLinesJs
import com.binario.treni.ui.sortTrenordLines
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray

/**
 * Linee preferite controllate in sfondo (dal controllo ogni 15 minuti, al massimo ogni [MIN_GAP_MS]):
 * 1. stato Trenord: si legge l'elenco ufficiale delle linee con un WebView invisibile (la pagina è fatta in JavaScript)
 *    e si avvisa se lo stato di una linea preferita è cambiato dall'ultima lettura (anche quella fatta aprendo «Linee»);
 * 2. disagio: per le linee preferite italiane, dalle 6 alle 22 e al massimo una volta l'ora per linea, la percentuale di treni
 *    soppressi, limitati o oltre 15 minuti; avviso sopra il 25% (vedi [LineDisruption.shouldAlert]).
 * Tutto solo se «Avvisi interruzioni su tratte, linee e treni preferiti» è attivo.
 */
object LineWatch {
    const val MIN_GAP_MS = 30 * 60_000L
    const val DISRUPTION_GAP_MS = 60 * 60_000L
    private const val READ_TIMEOUT_MS = 60_000L

    /** Al massimo tante linee e tratte preferite per giro (ognuna costa fino a 18 richieste). */
    private const val MAX_LINES = 3

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("line_watch", Context.MODE_PRIVATE)

    suspend fun run(ctx: Context, now: Long = System.currentTimeMillis()) {
        val store = Store(ctx)
        if (!store.routeAlerts || (store.favLines().isEmpty() && store.favRoutes().isEmpty())) return
        val p = prefs(ctx)
        if (now - p.getLong("at", 0L) < MIN_GAP_MS) return
        p.edit().putLong("at", now).apply()
        try {
            checkTrenordStatus(ctx, store)
        } catch (e: Exception) {
            Diag.record("linewatch/stato", e)
        }
        try {
            checkDisruption(ctx, store, now)
        } catch (e: Exception) {
            Diag.record("linewatch/disagio", e)
        }
    }

    /** Silenzia fino a mezzanotte la linea o tratta [k] (chiamato dal tasto «Non avvisare oggi»). */
    fun muteToday(ctx: Context, k: String, now: Long = System.currentTimeMillis()) {
        prefs(ctx).edit().putLong(k + "_mute", LineDisruption.endOfDay(now)).apply()
    }

    /** Elenco Trenord salvato (lo stesso che mostra la schermata «Linee»). */
    fun saveTrenordLines(prefs: SharedPreferences, list: List<LineInfo>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        prefs.edit().putString("trenord_lines", a.toString()).apply()
    }

    /**
     * Notifica le linee preferite ([favKeys] = url + percorso) il cui stato è cambiato tra [old] e [new].
     * Restituisce le linee cambiate con il nuovo stato (la schermata ci mostra anche un messaggio breve).
     */
    fun alertChanges(ctx: Context, old: List<LineInfo>, new: List<LineInfo>, favKeys: Set<String>): List<Pair<LineInfo, String>> {
        val changed = LineNotice.changes(
            old.associate { (it.url + it.route) to it.status }, new.associate { (it.url + it.route) to it.status }, favKeys,
        )
        val out = changed.mapNotNull { (key, status) -> new.firstOrNull { it.url + it.route == key }?.let { it to status } }
        if (Store(ctx).routeAlerts) out.forEach { (li, status) ->
            Notif.post(
                ctx, ("lc" + li.url + li.route).hashCode(), Notif.CH_ALERT, "⚠️ " + tx("Linea") + " " + li.code,
                status + "\n" + li.route, Notif.openApp(ctx, null, 5010, "lines"),
            )
        }
        return out
    }

    private suspend fun checkTrenordStatus(ctx: Context, store: Store) {
        val favs = store.favLines().filter { it.url.contains("trenord.it") }
        if (favs.isEmpty()) return // senza linee Trenord preferite non serve aprire la pagina
        val list = readTrenordLines(ctx)
        if (list.size < 5) return // pagina non letta bene: meglio non confrontare
        val app = ctx.applicationContext.getSharedPreferences("binario", Context.MODE_PRIVATE)
        val old = loadSavedTrenordLines(app)
        val sorted = sortTrenordLines(list)
        alertChanges(ctx, old, sorted, favs.map { it.url + it.route }.toSet())
        saveTrenordLines(app, sorted)
    }

    /** Legge l'elenco Trenord con un WebView invisibile sul thread principale; vuoto dopo [READ_TIMEOUT_MS] o se qualcosa va storto. */
    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun readTrenordLines(ctx: Context): List<LineInfo> = withTimeoutOrNull(READ_TIMEOUT_MS) {
        suspendCancellableCoroutine<List<LineInfo>> { cont ->
            val main = Handler(Looper.getMainLooper())
            main.post {
                var web: WebView? = null
                var done = false
                fun finish(l: List<LineInfo>) {
                    if (done) return
                    done = true
                    try { web?.destroy() } catch (e: Exception) { Diag.record("linewatch/webview", e) }
                    if (cont.isActive) cont.resume(l)
                }
                cont.invokeOnCancellation { main.post { finish(emptyList()) } }
                try {
                    val w = WebView(ctx.applicationContext)
                    web = w
                    w.settings.javaScriptEnabled = true
                    w.settings.domStorageEnabled = true
                    var tries = 0
                    fun read() {
                        if (done) return
                        w.evaluateJavascript(TRENORD_LINES_JS) { res ->
                            val l = parseTrenordLinesJs(res)
                            if (l.size < 5 && tries++ < 4) w.postDelayed({ read() }, 3000) else finish(l)
                        }
                    }
                    w.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String?) {
                            view.postDelayed({ read() }, 2500)
                        }
                    }
                    w.loadUrl(TRENORD_LINES_URL)
                } catch (e: Exception) {
                    Diag.record("linewatch/webview", e)
                    finish(emptyList())
                }
            }
        }
    } ?: emptyList()

    private suspend fun checkDisruption(ctx: Context, store: Store, now: Long) {
        val hour = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Rome")).apply { timeInMillis = now }
            .get(java.util.Calendar.HOUR_OF_DAY)
        if (hour !in 6..21) return
        val p = prefs(ctx)
        // Linee preferite e poi tratte preferite, senza doppioni (al massimo MAX_LINES in tutto per giro)
        val targets = LineDisruption.targets(store.favLines(), store.favRoutes(), MAX_LINES)
        for (target in targets) {
            val line = target.line
            val k = "d_" + line.key.hashCode()
            // «Non avvisare oggi»: fino a mezzanotte questa linea (o tratta) non si controlla nemmeno
            if (now < p.getLong(k + "_mute", 0L)) continue
            if (now - p.getLong(k + "_at", 0L) < DISRUPTION_GAP_MS) continue
            val s = LineDisruptionLoader.load(line, now) ?: continue
            com.binario.treni.data.DisruptionHistory.record(ctx, line, s, now)
            val lastPct = p.getInt(k + "_pct", 0)
            val lastAlert = p.getLong(k + "_alert", 0L)
            val e = p.edit().putLong(k + "_at", now).putInt(k + "_pct", LineDisruption.percentToKeep(s, lastPct))
            if (LineDisruption.shouldAlert(s, lastPct, lastAlert, now)) {
                val title = if (target.isRoute) tx("Tratta") + " " + line.a.name + " ⇄ " + line.b.name
                else tx("Linea") + " " + line.name.ifBlank { line.label }
                val nid = ("ld" + line.key).hashCode()
                val mute = PendingIntent.getBroadcast(
                    ctx, ("lm" + line.key).hashCode(),
                    Intent(ctx, DisruptionMuteReceiver::class.java).putExtra(DisruptionMuteReceiver.KEY, k).putExtra(DisruptionMuteReceiver.NID, nid),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
                Notif.post(
                    ctx, nid, Notif.CH_ALERT,
                    "⚠️ " + title + " · " + s.percent + "%",
                    tx("{0} treni critici su {1}").replace("{0}", s.critical.toString()).replace("{1}", s.checked.toString()) + "\n" +
                        tx("Soppressi") + " ${s.cancelled} · " + tx("Limitati") + " ${s.limited} · " + tx("Oltre 15 min") + " ${s.late}\n" +
                        tx("Disagio sulla linea (ultime 3 ore)"),
                    Notif.openApp(ctx, null, 5011, if (target.isRoute) "trains" else "lines"),
                    NotificationCompat.Action(0, tx("Non avvisare oggi"), mute),
                )
                e.putLong(k + "_alert", now)
            }
            e.apply()
        }
    }
}

/** Tasto «Non avvisare oggi» della notifica di disagio: silenzia quella linea o tratta fino a mezzanotte e chiude la notifica. */
class DisruptionMuteReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val k = intent.getStringExtra(KEY) ?: return
        LineWatch.muteToday(ctx, k)
        val nid = intent.getIntExtra(NID, 0)
        if (nid != 0) ctx.getSystemService(NotificationManager::class.java)?.cancel(nid)
    }

    companion object {
        const val KEY = "k"
        const val NID = "nid"
    }
}
