package com.binario.treni.ui

import androidx.compose.runtime.saveable.rememberSaveable
import com.binario.treni.data.tx
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.text.style.TextDecoration
import com.binario.treni.data.ALL_CATEGORIES
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.NewsItem
import com.binario.treni.data.Notice
import com.binario.treni.data.Sources
import com.binario.treni.data.Strike
import com.binario.treni.data.SavedSearch
import com.binario.treni.service.Reminders
import com.binario.treni.service.TrackingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Scheda "Biglietti": acquisto e gestione sui siti ufficiali delle compagnie. */
@Composable
fun TicketsScreen(onBack: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Biglietti"), onBack)
        SectionHeader(tx("Acquista"))
        SimpleRow(Icons.Filled.ShoppingCart, "Trenitalia", tx("Frecce, Intercity e Regionali")) { openUrl(ctx, "https://www.lefrecce.it") }
        SimpleRow(Icons.Filled.ShoppingCart, "Italo", tx("Alta velocità NTV")) { openUrl(ctx, "https://www.italotreno.com") }
        SimpleRow(Icons.Filled.ShoppingCart, "Trenord", tx("Regionali Lombardia e Malpensa Express")) { openUrl(ctx, "https://www.trenord.it") }
        SectionHeader(tx("I miei biglietti"))
        SimpleRow(Icons.Filled.ConfirmationNumber, tx("Area personale Trenitalia"), tx("Biglietti, abbonamenti e QR code")) {
            openUrl(ctx, "https://www.lefrecce.it/Channels.Website.WEB/#/user-area/")
        }
        SimpleRow(Icons.Filled.EditCalendar, tx("Cambio prenotazione Trenitalia"), tx("Modifica data, ora o classe")) {
            openUrl(ctx, "https://www.lefrecce.it")
        }
        SimpleRow(Icons.Filled.ConfirmationNumber, tx("I miei viaggi Italo"), "") { openUrl(ctx, "https://www.italotreno.com") }
        Text(
            tx("L'acquisto avviene sul sito ufficiale della compagnia: l'acquisto diretto nell'app e la sincronizzazione ") +
                tx("dei biglietti richiedono un accordo commerciale con Trenitalia, Italo e Trenord."),
            style = MaterialTheme.typography.bodySmall, color = Color.Gray, modifier = Modifier.padding(16.dp),
        )
    }
}

/** Scheda "Altro": menu con notizie espandibili, come nell'app di riferimento. */
@Composable
fun MoreScreen(vm: MainViewModel, go: (String) -> Unit) {
    val ctx = LocalContext.current
    var tracked by remember { mutableStateOf(vm.store.tracked()) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Altro"))
        // Menu semplice: poche sezioni per argomento, e una sezione "Per azienda" che raccoglie tutto ciò che riguarda
        // una sola impresa (Trenord, FerrovieNord, Trenitalia, Italo, TILO). I sottomenu si aprono toccando la freccia.
        var open by remember { mutableStateOf<String?>(null) }
        fun toggle(k: String) { open = if (open == k) null else k }
        MenuRow(Icons.Filled.Map, com.binario.treni.data.I18n.tr("Mappa dei treni", "Train map"), tx("Pallini colorati per ritardo, zoom e «Vicino a me»")) { go("trainsmap") }

        // Schede nell'ordine scelto (modalità sviluppatore → Disposizione dell'app)
        val moreCards = remember { com.binario.treni.data.DevLayout.visible(ctx, com.binario.treni.data.DevLayout.MORE) }
        moreCards.forEach { card ->
            when (card) {
                "alpha" -> {
                Text(tx("App non ufficiale: non affiliata, sponsorizzata né approvata da Trenitalia, RFI, Italo, Trenord o altre aziende di trasporto. I dati provengono da fonti pubbliche."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                if (IS_ALPHA) WhiteCard(onClick = { go("feedback?bug=true") }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("ALPHA", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            modifier = Modifier.background(Color(0xFFEF6C00), androidx.compose.foundation.shape.RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tx("Versione") + " " + APP_VERSION + " · " + tx("in prova"), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(tx("Alcune funzioni possono avere errori o cambiare. Tocca qui per segnalare un problema."), color = Muted, fontSize = 13.sp)
                        }
                    }
                }
                }
                "companies" -> {
                WhiteCard {
                    CardTitle(tx("Per azienda"))
                    MenuGroup(open == "trenord", { toggle("trenord") }, Icons.Filled.Train, "Trenord", tx("Linee, Malpensa Express, area STIBM, avvisi")) {
                        MenuRow(null, tx("Linee Trenord e FerrovieNord")) { go("lines") }
                        MenuRow(null, tx("Malpensa Express · tariffe"), tx("Prezzi da ogni stazione, linee, classi e limitazioni")) { go("malpensa?from=") }
                        MenuRow(null, tx("Area STIBM · Milano e Monza Brianza"), tx("Zone, prezzi e stazioni del biglietto integrato")) { go("stibm?name=") }
                        MenuRow(null, tx("Abbonamenti e biglietti Trenord")) { go("fares") }
                        MenuRow(null, tx("Avvisi Trenord"), "trenord.it") { openUrl(ctx, "https://www.trenord.it/news/trenord-informa/avvisi/") }
                        MenuRow(null, tx("Circolazione in tempo reale"), "trenord.it") { openUrl(ctx, "https://www.trenord.it/linee-e-orari/circolazione/tempo-reale/") }
                    }
                    MenuGroup(open == "fn", { toggle("fn") }, Icons.Filled.Train, "FerrovieNord", com.binario.treni.data.I18n.tr("Rete, ascensori fuori servizio, accessibilità, defibrillatori", "Network, lifts out of service, accessibility, defibrillators")) {
                        MenuRow(null, com.binario.treni.data.I18n.tr("Info rete FERROVIENORD", "FERROVIENORD network info"),
                            com.binario.treni.data.I18n.tr("Ascensori e scale mobili fuori servizio, accessibilità, assistenza, DAE, documenti", "Lifts and escalators out of service, accessibility, assistance, AEDs, documents")) { go("fn") }
                        MenuRow(null, tx("Linee della rete FerrovieNord")) { go("lines") }
                        MenuRow(null, tx("Puntualità FerrovieNord")) { go("stats") }
                        MenuRow(null, tx("Sito FerrovieNord"), "ferrovienord.it") { openUrl(ctx, "https://www.ferrovienord.it") }
                    }
                    MenuGroup(open == "trenitalia", { toggle("trenitalia") }, Icons.Filled.Train, "Trenitalia", tx("Infomobilità, treni garantiti, biglietti")) {
                        MenuRow(null, tx("Notizie infomobilità"), "trenitalia.com") { openUrl(ctx, Sources.TRENITALIA_INFO_URL) }
                        MenuRow(null, tx("Treni garantiti in caso di sciopero")) { go("guaranteed") }
                        MenuRow(null, tx("Biglietti"), "trenitalia.com") { go("tickets") }
                    }
                    MenuGroup(open == "italo", { toggle("italo") }, Icons.Filled.Train, "Italo", tx("Treni in tempo reale, contatti")) {
                        MenuRow(null, tx("Cerca un treno Italo per numero")) { go("capotreno") }
                        MenuRow(null, tx("Contatti e assistenza"), "italotreno.com") { openUrl(ctx, "https://www.italotreno.com/it/contatti-supporto") }
                    }
                    MenuGroup(open == "tilo", { toggle("tilo") }, Icons.Filled.Public, tx("TILO e Svizzera"), tx("Ticino–Lombardia, tariffe transfrontaliere")) {
                        MenuRow(null, tx("TILO · Ticino e Lombardia"), tx("Linee, tariffe transfrontaliere, servizi")) { go("tilo") }
                        MenuRow(null, tx("Confronta itinerari"), tx("Es. Varese → Como via Mendrisio o via Milano")) { go("compare") }
                        MenuRow(null, tx("Avvisi TILO"), "tilo.ch") { openUrl(ctx, "https://www.tilo.ch/avvisi.html") }
                    }
                    MenuRow(Icons.Filled.Public, tx("Treni in Italia"), "Trenitalia, Italo, Trenord…") { go("italy") }
                    MenuRow(Icons.Filled.Public, tx("Treni in Germania"), tx("ICE, regionali, S-Bahn, Deutschlandticket, diritti e aziende")) { go("germany") }
                    MenuRow(Icons.Filled.Public, tx("Treni in Svizzera"), "FFS, TILO…") { go("switzerland") }
                    MenuRow(Icons.Filled.Public, tx("Treni in Austria"), "ÖBB, Westbahn…") { go("austria") }
                    MenuRow(Icons.Filled.Public, tx("Treni in Francia"), "TGV, TER, Intercités…") { go("france") }
                    MenuRow(Icons.Filled.Apartment, tx("Tutte le imprese ferroviarie"), tx("Italia, Svizzera e Germania: siti, biglietti, dati")) { go("railways") }
                }
                }
                "station" -> {
                WhiteCard {
                    CardTitle(tx("In stazione e strumenti"))
                    // «Servizi in stazione» (WC, rivendite, bus sostitutivi, taxi, defibrillatori) è ora nella schermata Stazioni vicine
                    MenuRow(Icons.Filled.Route, tx("Tutte le linee"), tx("Trenord, TILO, FerrovieNord, Svizzera")) { go("lines") }
                    MenuRow(Icons.Filled.CompareArrows, tx("Confronta itinerari")) { go("compare") }
                    MenuRow(Icons.Filled.Eco, tx("Quanto sei green"), tx("Quanto risparmi in CO₂, carburante, pedaggi e tempo")) { go("green") }
                }
                }
                "a11y" -> {
                WhiteCard {
                    CardTitle(tx("Accessibilità"))
                    A11yQuickCard(vm.store, inSettings = true, onAssistance = { go("assistance") }, onExplore = { go("explore") })
                    MenuRow(Icons.Filled.Vibration, tx("Avvisi per persone sorde"),
                        if (vm.store.deafMode) tx("Attivi: vibrazione e flash") else tx("Disattivati")) { go("settings") }
                    MenuRow(Icons.Filled.Tune, tx("Tutte le opzioni di accessibilità")) { go("settings") }
                }
                }
                "app" -> {
                WhiteCard {
                    CardTitle(tx("App"))
                    MenuRow(Icons.Filled.Settings, tx("Impostazioni")) { go("settings") }
                    MenuRow(Icons.Filled.Widgets, "Widget") { go("widgets") }
                    MenuRow(Icons.Filled.Share, tx("Condividi Binario"), tx("Condivisione? Quando sarà il momento…")) { toast(ctx, tx("Condivisione? Quando sarà il momento…")) }
                    MenuRow(Icons.Filled.Feedback, tx("Feedback e segnala un bug"), tx("Scrivi allo sviluppatore: idee, suggerimenti, problemi")) { go("feedback?bug=false") }
                    MenuRow(Icons.Filled.QuestionMark, tx("Aiuto e FAQ")) { go("help") }
                    MenuGroup(open == "info", { toggle("info") }, Icons.Filled.Info, tx("Informazioni sull'app"), tx("Correzioni, stato dei servizi, privacy")) {
                        MenuRow(
                            null, tx("Cerca aggiornamenti"),
                            if (ManualUpdate.checking) tx("Controllo in corso…") else tx("Versione") + " " + APP_VERSION,
                        ) { if (!ManualUpdate.checking) ManualUpdate.request++ }
                        MenuRow(null, tx("Report correzioni"), tx("Problemi risolti in ogni versione")) { go("fixes") }
                        MenuRow(null, tx("Stato dei servizi"), tx("Controlla che tutte le fonti di dati rispondano")) { go("health") }
                        MenuRow(null, tx("Privacy e permessi")) { go("privacy") }
                        MenuRow(null, tx("Note legali"), tx("Versione") + " " + APP_VERSION) { go("legal") }
                    }
                }
                }
            }
        }
        Text(
            "Binario $APP_VERSION · " + tx(CREDIT), color = Muted, fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth().padding(20.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

/** Opzioni avanzate di ricerca: massimo cambi e categorie escluse. */
@Composable
fun AdvancedScreen(vm: MainViewModel, onBack: () -> Unit) {
    var max by remember { mutableIntStateOf(vm.maxChanges) }
    var ex by remember { mutableStateOf(vm.excluded) }
    var menu by remember { mutableStateOf(false) }
    fun label(m: Int) = when (m) {
        -1 -> tx("non definito")
        0 -> tx("nessun cambio (solo diretti)")
        else -> "$m"
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Opzioni avanzate"), onBack) {
            IconButton({ vm.saveAdvanced(max, ex); onBack() }) { Icon(Icons.Filled.Check, tx("Salva")) }
        }
        WhiteCard {
            CardTitle(tx("Max Cambi"))
            Box {
                Row(Modifier.fillMaxWidth().clickable { menu = true }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx("Max Cambi"), color = Muted, fontSize = 13.sp)
                        Text(label(max), fontSize = 17.sp)
                    }
                    Icon(Icons.Filled.ArrowDropDown, null, tint = Muted)
                }
                DropdownMenu(menu, { menu = false }) {
                    listOf(-1, 0, 1, 2, 3).forEach { m -> DropdownMenuItem({ Text(label(m)) }, { max = m; menu = false }) }
                }
            }
        }
        WhiteCard {
            CardTitle(tx("Escludi categorie"))
            Column(Modifier.padding(vertical = 8.dp)) {
                ALL_CATEGORIES.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { c ->
                            val off = c in ex
                            Box(
                                Modifier.weight(1f).clickable { ex = if (off) ex - c else ex + c }.padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    c, fontSize = 17.sp,
                                    color = if (off) Color(0xFFBDBDBD) else categoryColor(c),
                                    textDecoration = if (off) TextDecoration.LineThrough else null,
                                )
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Text(tx("Tocca una categoria per escluderla (barrata) o includerla."), color = Muted, fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            }
        }
    }
}

const val APP_VERSION = "0.1.112-alpha"

/** Build in fase alpha: funzioni in prova, possono esserci errori. */
const val IS_ALPHA = true
const val CREDIT = "App creata da Marco Jannino"

// Note che il workflow «Crea APK» mette nella release su GitHub (le legge l'app sotto «Novità»): a ogni versione
// serve un blocco che inizia con il versionName esatto, altrimenti la release esce senza note (successo con la 0.1.108).
const val CHANGELOG_TEXT = """0.1.112-alpha
• Funzioni della Home su tre livelli: Base (solo l'essenziale, predefinito), Avanzate (per chi viaggia spesso), Complete (tutto)
• Sotto la scelta, una riga dice cosa c'è a quel livello
• Avanzate: passeggeri, tipo di treni, prezzi migliori, I miei viaggi, orari offline, linee, treni garantiti, Svizzera, tariffe, bagni, rivendite e assistenza disabili
• In fondo al menu laterale: «Mostra tutte le funzioni» per passare a Complete in un tocco
• Chi aveva già scelto «Complete» resta in Complete

0.1.111-alpha
• Linee Trenord e TILO: dalla pagina ufficiale Trenord ora ci sono lo stato della linea, tutti gli avvisi e i documenti PDF allegati
• Stazioni sulla linea con biglietteria, distributori automatici e accessibilità, con i filtri come sul sito
• Tocca una stazione: indirizzo, «Calcola percorso» e gli altri servizi (bar, deposito bagagli, ascensori, sala d'attesa…)
• La schermata della linea ora scorre tutta: la lista dei treni non resta più schiacciata in fondo

0.1.110-alpha
• Linee TILO (S10, S40, S50, RE80…): treni e ritardi dall'orario svizzero, capolinea giusti (la S40 parte da Como S. Giovanni, non da Como Borghi)
• Nelle linee TILO: avvisi FFS in corso (dati aperti FFS, in inglese) e disagio calcolato sui ritardi
• Anche dalla scheda «Svizzera» le linee TILO si aprono con i treni
• Testo grande: i pulsanti vanno a capo invece di schiacciarsi, le schede scorrono e il nome resta intero

0.1.109-alpha
• Aggiornamento dell'app: se il download si interrompe riprova da solo, dice il motivo vero dell'errore e offre «Apri la pagina di download»
• Niente più «null» sotto «Novità» quando una versione non ha note
• Dalla 0.1.108: «I miei viaggi» con puntualità in %, conferma prima di eliminare, treno soppresso fino alla tua fermata, fino a 1500 viaggi, richiesta di indennizzo con nome e biglietto, CSV più sicuro
• Dalla 0.1.108: disagio della linea più preciso (treni limitati, errori di rete, niente avvisi ripetuti)

0.1.68-alpha
• Tragitto del treno: una fermata futura non risulta più «già raggiunta e in orario» quando la fonte manda solo una previsione uguale all'orario programmato (esempio: Rho segnata in orario mentre il treno era ancora a Pregnana con 7 minuti di ritardo). Ora i rilevamenti incoerenti con la fermata precedente vengono scartati e si usa il ritardo reale.

0.1.67-alpha
• Corretto il link «pagina ufficiale della linea» di Trenord (dava «Access Denied»); verificati i link delle pagine linee TILO e delle direttrici Trenord. Registro novità e Report correzioni ripartiti da zero.

0.1.66-alpha
• Se l'invio del feedback non riesce, compare il pulsante «Invia via email» (indirizzo letto dal file di configurazione, non scritto nell'app).
"""

@Composable
fun SavedScreen(vm: MainViewModel, onBack: () -> Unit, onOpen: () -> Unit) {
    var list by remember { mutableStateOf(vm.store.savedSearches()) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Orari salvati offline"), onBack)
        if (list.isEmpty()) StateView(
            ViewState.EMPTY, tx("Nessun orario salvato"),
            tx("Per avere gli orari anche senza rete: cerca un viaggio, poi nei risultati tocca «Salva questi orari per usarli offline». Lo ritrovi qui."),
            onRetry = null,
        ) else Text(
            tx("Tocca una ricerca per riaprirla, anche senza rete."), color = Color.Gray, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        if (list.isEmpty()) OutlinedButton(onBack, Modifier.padding(horizontal = 16.dp)) { Text(tx("Cerca un viaggio"), color = Green) }
        LazyColumn {
            items(list, key = { it.key }) { s: SavedSearch ->
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.openSaved(s); onOpen() }.padding(start = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                            Text(s.title, fontWeight = FontWeight.Medium)
                            Text("${s.solutions.size} " + com.binario.treni.data.I18n.tr("soluzioni · salvato il ", "solutions · saved on ") + Fmt.dayTime(s.savedAt), color = Color.Gray, fontSize = 13.sp)
                            val nowMs = System.currentTimeMillis()
                            Text(com.binario.treni.data.SavedAge.label(nowMs, s.savedAt), fontSize = 13.sp,
                                color = if (com.binario.treni.data.SavedAge.isStale(nowMs, s.savedAt)) Color(0xFFE08A00) else Color.Gray)
                        }
                        IconButton({ vm.store.deleteSaved(s.key); list = vm.store.savedSearches() }) {
                            Icon(Icons.Filled.Delete, tx("Elimina"), tint = Color.Gray)
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun RemindersScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(vm.store.reminders().sortedBy { it.at }) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Notifiche programmate"), onBack)
        if (list.isEmpty()) MessageBox(tx("Nessuna notifica. Usa \"Avvisami\" su un treno o una soluzione."))
        LazyColumn {
            items(list, key = { it.id }) { r ->
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Alarm, null, tint = Green)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                            Text(r.label, fontWeight = FontWeight.Medium)
                            Text(
                                com.binario.treni.data.I18n.tr("Avviso alle ", "Reminder at ") + Fmt.dayTime(r.at) + " · " + (if (r.arrival) com.binario.treni.data.I18n.tr("arrivo", "arrival") else com.binario.treni.data.I18n.tr("partenza", "departure")) + " " + Fmt.time(r.eventTime),
                                color = Color.Gray, fontSize = 13.sp,
                            )
                        }
                        IconButton({ Reminders.cancel(ctx, r.id); list = vm.store.reminders().sortedBy { it.at } }) {
                            Icon(Icons.Filled.Delete, tx("Elimina"), tint = Color.Gray)
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun InfoScreen(title: String, body: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        GreenTopBar(title, onBack)
        Text(body, modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp), lineHeight = 22.sp)
    }
}

/** Report delle correzioni: per ogni versione, i problemi trovati e come sono stati risolti. */
const val CHANGELOG_TEXT_EN = """0.1.68-alpha
• Train route: a future stop no longer shows as “already reached and on time” when a source only sends a forecast equal to the scheduled time (example: Rho shown on time while the train was still at Pregnana, 7 minutes late). Readings that contradict the previous stop are now discarded and the real delay is used.

0.1.67-alpha
• Fixed the Trenord “official line page” link (it showed “Access Denied”); checked the TILO line pages and Trenord route links. Changelog and Fixes report restarted from scratch.

0.1.66-alpha
• If sending feedback fails, an “Send by email” button appears (address read from the configuration file, not written in the app).
"""

/** Pagina "Note legali": versione e autore in alto, poi il testo. */
@Composable
fun LegalScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        GreenTopBar(tx("Note legali"), onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("Binario · " + tx("versione") + " " + APP_VERSION, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(tx(CREDIT), color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Text(com.binario.treni.data.I18n.tr5(LEGAL_TEXT, LEGAL_TEXT_EN, LEGAL_TEXT_ZH, LEGAL_TEXT_DE, LEGAL_TEXT_FR, LEGAL_TEXT_ES, LEGAL_TEXT_JA), lineHeight = 21.sp, fontSize = 14.sp)
        }
    }
}

/** Avviso al primo avvio (e dopo aggiornamenti delle note): va accettato per usare l'app. */
@Composable
fun LegalConsent(store: com.binario.treni.data.Store, onOpenLegal: () -> Unit, onAccepted: () -> Unit = {}) {
    var accepted by remember { mutableStateOf(store.legalAccepted == LEGAL_VERSION) }
    if (accepted) return
    AlertDialog(
        onDismissRequest = {},
        title = { Text(tx("Prima di iniziare")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Binario " + APP_VERSION + " · " + tx(CREDIT), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(tx("Binario è un'app indipendente, non affiliata a Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO o SBB. I dati provengono da fonti pubbliche e possono contenere errori: fanno sempre fede tabelloni, annunci e canali ufficiali. Affollamento, costi e tempi stimati sono indicativi. Tutte le fonti sono pubbliche, gratuite e citate nelle note legali. L'app è gratuita, senza pubblicità, non vende biglietti e non raccoglie dati personali."))
                TextButton(onOpenLegal) { Text(tx("Leggi le note legali complete"), color = Green) }
            }
        },
        confirmButton = {
            Button({ store.legalAccepted = LEGAL_VERSION; accepted = true; onAccepted() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Text(tx("Ho capito e accetto"))
            }
        },
    )
}

const val LEGAL_VERSION = 3

/** Voce di menu che apre un sottomenu (freccia giù/su), con le voci rientrate. */
/**
 * Voci del Capotreno nella scheda Treni (sotto "Il mio Capotreno"): il tuo viaggio, notizie e scioperi, biglietti e prezzi.
 * Prima erano in "Altro".
 */
@Composable
fun CapotrenoMenuCard(vm: MainViewModel, go: (String) -> Unit) {
    val ctx = LocalContext.current
    var tracked by remember { mutableStateOf(vm.store.tracked()) }
    var open by remember { mutableStateOf<String?>(null) }
    fun toggle(k: String) { open = if (open == k) null else k }
    WhiteCard {
        tracked?.let { t ->
            MenuRow(Icons.Filled.Train, tx("Treno seguito") + ": " + t.label, tx("Apri lo stato in tempo reale")) {
                go("train?num=${android.net.Uri.encode(t.number)}&orig=${android.net.Uri.encode(t.originCode)}&date=${t.date}")
            }
            MenuRow(Icons.Filled.NotificationsOff, tx("Smetti di seguire") + " ${t.label}") { TrackingService.stop(ctx); tracked = null }
        }
        SubHeading(tx("Il tuo viaggio"))
        MenuRow(Icons.Filled.Mic, tx("Chiedi a voce"), tx("Assistente: treni, ritardi, binari, scioperi")) { go("bot?voice=true") }
        MenuRow(Icons.Filled.History, tx("I miei viaggi"), tx("Treni seguiti fino all'arrivo, ritardi del mese")) { go("trips") }
        MenuRow(Icons.Filled.Luggage, tx("Oggetti smarriti"), tx("Cosa fare e chi contattare: Trenord, Trenitalia, Italo, FFS")) { go("lost") }
        MenuRow(Icons.Filled.Notifications, tx("Allarmi e orari salvati"), tx("Notifiche programmate, sveglie, orari offline")) { toggle("trip") }
        if (open == "trip") Column(Modifier.padding(start = 24.dp)) {
            MenuRow(Icons.Filled.Alarm, tx("Allarmi")) { go("reminders") }
            MenuRow(Icons.Filled.DownloadForOffline, tx("Orari salvati offline"), tx("Anche i PDF scaricati sono in Download/Binario")) { go("saved") }
        }
        SubHeading(tx("Notizie e scioperi"))
        MenuRow(Icons.Filled.Campaign, tx("Scioperi, circolazione e lavori"), tx("Anche solo per la tua tratta e i tuoi orari")) { go("news") }
        MenuRow(Icons.Filled.EventBusy, tx("Treni garantiti in caso di sciopero")) { go("guaranteed") }
        MenuRow(Icons.Filled.Map, com.binario.treni.data.I18n.tr("Mappa dei treni", "Train map"), tx("Pallini colorati per ritardo, zoom e «Vicino a me»")) { go("trainsmap") }
        MenuRow(Icons.Filled.Insights, tx("Puntualità"), tx("Regionali con regionali, alta velocità con alta velocità")) { go("stats") }
        SubHeading(tx("Biglietti e prezzi"))
        MenuRow(Icons.Filled.ConfirmationNumber, tx("Biglietti"), tx("Siti ufficiali di acquisto e area personale")) { go("tickets") }
        MenuRow(Icons.Filled.Euro, tx("Quanto costa il tuo abbonamento"), tx("Da A a B: abbonamenti e biglietti, anche verso la Svizzera")) { go("fares") }
        MenuRow(Icons.Filled.Storefront, tx("Punti vendita"), com.binario.treni.data.I18n.tr("Biglietterie, emettitrici, rivenditori · vicino o per provincia", "Ticket offices, machines, resellers · nearby or by province")) { go("sellers?id=&name=") }
        MenuRow(Icons.Filled.Gavel, tx("Diritti e rimborsi"), tx("Condizioni di trasporto, ritardi, indennizzi")) { go("conditions") }
        MenuRow(Icons.Filled.Pets, tx("Viaggiare con animali"), tx("Cani, gatti e trasportini: regole e prezzi per impresa")) { go("animals") }
    }

}

/** Sottotitolo dentro una scheda del menu (es. "Notizie e scioperi" dentro "Il mio Capotreno"). */
@Composable
private fun SubHeading(text: String) {
    Text(text, color = Green, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 2.dp))
}

@Composable
private fun MenuGroup(
    expanded: Boolean, onToggle: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String,
    content: @Composable () -> Unit,
) {
    MenuRow(icon, title, sub, trailing = {
        Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, if (expanded) tx("Chiudi") else tx("Apri"), tint = Muted)
    }, onClick = onToggle)
    if (expanded) Column(Modifier.padding(start = 24.dp)) { content() }
}

const val CHANGELOG_TEXT_ZH = """0.1.68-alpha
• 列车行程：当数据源只给出与计划时间相同的预测时，后面的车站不再显示为“已到达且准点”（例如列车仍在晚点7分钟的 Pregnana 时，Rho 却显示准点）。现在会舍弃与上一站矛盾的读数，并使用实际晚点时间。

0.1.67-alpha
• 修复了 Trenord“线路官方页面”链接（之前显示“Access Denied”）；已检查 TILO 线路页面和 Trenord 干线链接。更新日志和修复报告已从头开始。

0.1.66-alpha
• 如果反馈发送失败，会出现“通过电子邮件发送”按钮（地址从配置文件读取，不写在应用中）。
"""
