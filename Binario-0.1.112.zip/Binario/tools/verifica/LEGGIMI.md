# Come si evitano gli errori

Prima di ogni zip (qui, senza Android):
    python3 tools/verifica/controlla.py . --base <zip dell'ultima versione compilata bene>
    (cd tools/raccolta && python3 -m unittest -v test_raccogli)
Controlla: parentesi cambiate rispetto allo zip di base, testi tx("…") senza traduzione, risorse R.* inesistenti, versioni coerenti.

Su GitHub (ad ogni "Crea APK", prima dell'APK firmato): i test in app/src/test.
- LineMatchTest: «stessa linea» dei treni davanti/dietro (la destinazione uguale non basta)
- StyleSpecsTest: testi leggibili in ogni stile, daltonici che cambiano TUTTI gli stili, traduzioni dei nomi degli stili
- TextScaleTest: con il testo ingrandito le righe non si tagliano
- TranslationCoverageTest: ogni tx("…") ha la traduzione inglese
Se un test fallisce la build si ferma e il log dice quale.

Regola: quando si corregge un errore segnalato, si aggiunge un test che lo avrebbe preso.
- ArrivedDelayTest, PropagateDelayTest: ritardo del treno coerente (arrivato «in orario» a +12; fermate Transitous senza il ritardo del treno)

Test aggiunti il 9/11/2026 (girano su GitHub con gli altri):
- SwissHttpTest: orario svizzero (TILO) con cache, pausa dopo il 429 e un solo nuovo tentativo
- TripLogTest: diario «I miei viaggi» (mese, doppioni, riepilogo, esportazione, salvataggio)
- LineDisruptionTest: grado di disagio della linea e regola della notifica per le linee preferite (LineWatch)
- VtInfomobilityTest: avvisi ViaggiaTreno completi e brevi, senza doppioni né «circolazione regolare»
- SwissNewsTest: avvisi solo svizzeri mai con la regione Lombardia, per la tratta solo se va in Svizzera
- FmtDistanceTest, ImprovementsSourceTest: distanze, torcia, errori registrati, versione, legenda orari, contatore filtro, schede

controlla.py (9/11/2026): accetta codice spostato in file nuovi (la somma delle parentesi resta uguale) e controlla
anche i file nuovi; il «//» degli indirizzi web dentro le stringhe non è più scambiato per un commento.
- HelpTopicsTest: la guida in tutte le 7 lingue è fatta di domande con risposta e ha gli stessi argomenti (13)
- TripLogTest ora prova anche il viaggio inserito a mano e il riepilogo di inizio mese; SwissHttpTest la pausa mostrata in «Stato dei servizi»
- Quarto e quinto giro: TripLogTest (CSV, anno, grafico, lettura vocale), LineDisruptionTest (tratte preferite, «Non avvisare oggi» fino a mezzanotte, anche col cambio d'ora)
