#!/usr/bin/env python3
"""Controlli rapidi sul codice, da lanciare PRIMA di creare lo zip (non serve Android):
parentesi bilanciate, testi tx("…") senza traduzione, risorse R.drawable/R.layout/R.id inesistenti, versioni coerenti,
traduzioni delle altre lingue che chiamano chiavi inglesi inesistenti. Esce con codice 1 se trova problemi.
Uso:  python3 tools/verifica/controlla.py [cartella-Binario] --base Binario-0.1.70.zip   (zip dell'ultima versione compilata bene)"""
import glob, os, re, sys

root = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith('--') else os.path.join(os.path.dirname(__file__), '..', '..')
root = os.path.abspath(root)
kt = [f for f in glob.glob(root + '/app/src/main/**/*.kt', recursive=True)]
errors = []

def read(p): return open(p, encoding='utf-8').read()

def strip_code(t):
    """Toglie stringhe e commenti, per contare parentesi senza falsi allarmi."""
    t = re.sub(r'"""[\s\S]*?"""', '""', t)
    t = re.sub(r'/\*[\s\S]*?\*/', '', t)
    t = re.sub(r'(?<!:)//[^\n]*', '', t)  # non gli indirizzi web dentro le stringhe ("https://…")
    t = re.sub(r"'(?:\\.|[^'\\])'", "''", t)
    return re.sub(r'"(?:\\.|[^"\\\n])*"', '""', t)

# 1. parentesi: il conteggio è approssimato (stringhe con ${…}), quindi si confronta con l'ultimo zip compilato con successo:
#    un file è sospetto solo se lo squilibrio è diverso da quello che aveva allora.
def balance(t):
    t = strip_code(t)
    return tuple(t.count(a) - t.count(b) for a, b in ('{}', '()', '[]'))

base = {}
if '--base' in sys.argv:
    import zipfile
    zf = zipfile.ZipFile(sys.argv[sys.argv.index('--base') + 1])
    for n in zf.namelist():
        if n.endswith('.kt'): base[n.split('app/src/main/', 1)[-1]] = balance(zf.read(n).decode('utf-8'))
changed, added = [], []
for f in kt:
    rel = f.split('app/src/main/', 1)[-1]
    now = balance(read(f))
    if rel in base:
        if now != base[rel]: changed.append((rel, base[rel], now))
    elif '--base' in sys.argv:
        added.append((rel, now))
    elif now != (0, 0, 0) and not os.path.basename(f).startswith(('Osm', 'Knowledge')):
        pass  # senza zip di base il conteggio non è affidabile: usa --base
# Codice spostato in file nuovi (es. una schermata tolta da un file grande): il file vecchio cambia, ma la somma
# delle parentesi di file cambiati + file nuovi resta quella di prima. Altrimenti si segnalano i singoli file.
def _sum(rows): return tuple(sum(r[i] for r in rows) for i in range(3))
moved = bool(changed) and _sum([b for _, b, _ in changed]) == _sum([n for _, _, n in changed] + [n for _, n in added])
if moved:
    print(f'Codice spostato tra file: parentesi in equilibrio ({len(changed)} file cambiati, {len(added)} file nuovi)')
else:
    for rel, b, n in changed: errors.append(f'Parentesi cambiate rispetto allo zip di base: {rel} {b} -> {n}')
    for rel, n in added:
        if n != (0, 0, 0): errors.append(f'Parentesi da controllare nel file nuovo: {rel} {n}')

# 2. traduzioni
en_src = read(root + '/app/src/main/java/com/binario/treni/data/En.kt')
en_keys = set(re.findall(r'^\s*"((?:[^"\\]|\\.)*)" to ', en_src, re.M))
skip = {'En.kt', 'De.kt', 'Fr.kt', 'Es.kt', 'Zh.kt', 'Ja.kt'}
for f in kt:
    if os.path.basename(f) in skip: continue
    for m in re.finditer(r'\btx\("((?:[^"\\$]|\\.)*)"\)', read(f)):
        k = m.group(1)
        if k not in en_keys:
            errors.append(f'Senza traduzione (aggiungi a En.kt): «{k[:70]}» in {os.path.basename(f)}')

# 3. risorse
res = root + '/app/src/main/res'
have = {'drawable': set(), 'layout': set(), 'id': set(), 'string': set(), 'color': set(), 'mipmap': set(), 'xml': set(), 'raw': set()}
for d in os.listdir(res):
    base = d.split('-')[0]
    if base in have and os.path.isdir(res + '/' + d):
        for fn in os.listdir(res + '/' + d): have[base].add(fn.rsplit('.', 1)[0])
for f in glob.glob(res + '/**/*.xml', recursive=True):
    t = read(f)
    have['id'].update(re.findall(r'@\+id/(\w+)', t))
    have['string'].update(re.findall(r'<string name="(\w+)"', t))
    have['color'].update(re.findall(r'<color name="(\w+)"', t))
    have['id'].update(re.findall(r'<item[^>]*type="id"[^>]*name="(\w+)"', t))
for f in kt:
    for kind, name in re.findall(r'\bR\.(drawable|layout|id|string|color|mipmap|xml|raw)\.(\w+)', read(f)):
        if name not in have[kind]:
            errors.append(f'Risorsa inesistente R.{kind}.{name} in {os.path.basename(f)}')

# 4. versioni
gr = read(root + '/app/build.gradle.kts')
vn = re.search(r'versionName = "([^"]+)"', gr).group(1)
vc = re.search(r'versionCode = (\d+)', gr).group(1)
other = read(root + '/app/src/main/java/com/binario/treni/ui/OtherScreens.kt')
av = re.search(r'APP_VERSION = "([^"]+)"', other).group(1)
if vn != av: errors.append(f'Versione diversa: build.gradle {vn} e APP_VERSION {av}')
print(f'Versione {vn} (codice {vc}) · {len(kt)} file Kotlin · {len(en_keys)} testi tradotti')

# 4b. import dei modelli (caso 0.1.92: TrainRef usato senza import in NewFeatures.kt)
def code_lines(t):
    out, raw = [], False
    for line in t.split('\n'):
        tr = line.count('"""'); was = raw
        if tr % 2 == 1: raw = not raw
        if was or raw or tr > 0 or line.lstrip().startswith(('import ', '//', '*', '/*')): continue
        out.append(re.sub(r'"(?:[^"\\\n]|\\.)*"', '""', line))
    return out
for f in kt:
    if '/ui/' not in f.replace('\\', '/') and '/service/' not in f.replace('\\', '/'): continue
    t = read(f); body = [l.replace('com.binario.treni.data.', '') if False else re.sub(r'com\.binario\.treni\.data\.\w+', '', l) for l in code_lines(t)]
    for n in ('TrainRef', 'TrainStatus', 'TrainStop', 'Station'):
        imported = re.search(r'^import com\.binario\.treni\.data\.(%s|\*)\s*$' % n, t, re.M)
        if not imported and any(re.search(r'\b%s\b' % n, l) for l in body):
            errors.append(f'Import mancante di {n} in {os.path.basename(f)}')

# 5. test presenti
tests = glob.glob(root + '/app/src/test/**/*.kt', recursive=True)
print(f'{len(tests)} file di test (girano su GitHub prima di ogni APK firmato)')

if errors:
    print('\nPROBLEMI TROVATI:')
    for e in errors: print(' -', e)
    sys.exit(1)
print('Tutto a posto.')
