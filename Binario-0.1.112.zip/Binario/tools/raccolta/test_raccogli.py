#!/usr/bin/env python3
"""Prove del raccoglitore di ritardi, senza rete: usa risposte di esempio in prove/.  Uso: python3 -m unittest -v test_raccogli"""
import csv, json, os, subprocess, sys, tempfile, unittest

QUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, QUI)
import raccogli  # noqa: E402


def carica(nome):
    with open(os.path.join(QUI, "prove", nome), encoding="utf-8") as f:
        return json.load(f)


def righe(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f, delimiter=";"))


class Raccolta(unittest.TestCase):
    def test_lettura_rfi(self):
        r = raccogli.parse(carica("demo_arrivi.json"), "S00000", "Prova", "10:00")
        self.assertTrue(r, "nessun arrivo letto")
        for rec in r.values():
            self.assertEqual(rec["fonte"], "RFI")
            self.assertTrue(rec["numero"].isdigit())

    def test_ritardi_non_negativi_ma_soppressi_a_parte(self):
        r = raccogli.parse(carica("demo_arrivi.json"), "S00000", "Prova", "10:00")
        for rec in r.values():
            if not rec["soppresso"]:
                self.assertIsInstance(rec["ritardo"], int)

    def test_cicli_completi_creano_i_file(self):
        with tempfile.TemporaryDirectory() as d:
            for opz in ("--demo", "--demo-italo", "--demo-trenord"):
                nome = {"--demo": "demo_arrivi.json", "--demo-italo": "demo_italo.json", "--demo-trenord": "demo_mia.json"}[opz]
                p = subprocess.run([sys.executable, os.path.join(QUI, "raccogli.py"), "--out", d, opz, os.path.join(QUI, "prove", nome)],
                                   capture_output=True, text=True)
                self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            for f in ("treni-30g.csv", "classifica-giorno.csv", "leggimi.txt"):
                self.assertTrue(os.path.exists(os.path.join(d, f)), f)
            t = righe(os.path.join(d, "treni-30g.csv"))
            self.assertTrue(t)
            # colonne lette dall'app (BinarioHistory.kt): se cambiano qui, va cambiata anche l'app
            for col in ("numero", "categoria", "origine", "stazione", "nome", "n_osservazioni", "n_soppressi",
                        "ritardo_medio_minuti", "puntualita_percento", "giorni", "fonte"):
                self.assertIn(col, t[0], col)
            for r in t:
                self.assertTrue(0 <= float(r["puntualita_percento"]) <= 100)
                self.assertGreaterEqual(int(r["n_osservazioni"]), int(r["n_soppressi"]))
            fonti = {r["fonte"] for r in t}
            self.assertTrue(fonti <= {"RFI", "Italo", "Trenord"}, fonti)
            c = righe(os.path.join(d, "classifica-giorno.csv"))
            for col in ("giorno", "posizione", "numero", "categoria", "origine", "nome", "orario", "ritardo_minuti"):
                self.assertIn(col, c[0], col)

    def test_user_agent_senza_email(self):
        self.assertNotIn("@", raccogli.UA)


if __name__ == "__main__":
    unittest.main()


class Svizzera(unittest.TestCase):
    NOW = None

    def setUp(self):
        from datetime import datetime
        self.now = datetime(2026, 11, 6, 15, 0, tzinfo=raccogli.ROME)
        ts = lambda h, m: int(datetime(2026, 11, 6, h, m, tzinfo=raccogli.ROME).timestamp())
        self.ts = ts

    def test_arrivi_tilo_e_ffs(self):
        board = {"stationboard": [
            {"name": "S10", "number": "S10", "category": "S", "operator": "TILO", "to": "Chiasso", "stop": {"arrivalTimestamp": self.ts(14, 40), "delay": 6, "prognosis": {"arrival": "x"}}},
            {"name": "IC 21", "category": "IC", "operator": "SBB", "to": "Lugano", "stop": {"arrivalTimestamp": self.ts(14, 50), "delay": 2, "prognosis": {"arrival": "x"}}}]}
        rows = raccogli.parse_swiss(board, "Lugano", self.now, "15:00", "arrival")
        fonti = sorted(r["fonte"] for r in rows.values())
        self.assertEqual(fonti, ["FFS", "TILO-CH"])
        self.assertTrue(all(r["arrivato"] == 1 for r in rows.values()))

    def test_tilo_verso_italia_rete_rfi_e_fn(self):
        def j(name, dest_id, dest):
            return {"name": name, "number": "S40", "category": "S", "operator": "TILO", "to": dest,
                    "passList": [{"station": {"name": "Mendrisio", "id": "8505304"}}, {"station": {"name": dest, "id": dest_id}, "arrivalTimestamp": self.ts(14, 30), "delay": 9, "prognosis": {"arrival": "x"}}]}
        board = {"stationboard": [j("S40", "8300110", "Como San Giovanni"), j("S50", "8300500", "Malpensa Aeroporto T1"), j("S99", "8505300", "Lugano"),
                                  {"name": "IC 5", "operator": "SBB", "passList": []}]}
        rows = raccogli.parse_swiss(board, "Mendrisio", self.now, "15:00", "departure")
        by = {r["nome"]: r for r in rows.values()}
        self.assertEqual(by["Como San Giovanni"]["fonte"], "TILO-RFI")
        self.assertEqual(by["Malpensa Aeroporto T1"]["fonte"], "TILO-FN")
        self.assertEqual(by["Lugano"]["fonte"], "TILO-CH")
        self.assertEqual(len(rows), 3)   # l'SBB non viene registrato dalle partenze
        self.assertEqual(by["Como San Giovanni"]["ritardo"], 9)

    def test_senza_previsione_non_e_arrivato(self):
        board = {"stationboard": [{"name": "S10", "category": "S", "operator": "TILO", "stop": {"arrivalTimestamp": self.ts(14, 40), "delay": 0}}]}
        r = list(raccogli.parse_swiss(board, "Lugano", self.now, "15:00", "arrival").values())[0]
        self.assertEqual(r["arrivato"], 0)

    def test_linea_senza_numero_distingue_per_orario(self):
        board = {"stationboard": [{"name": "S10", "category": "S", "operator": "TILO", "stop": {"arrivalTimestamp": self.ts(14, 40), "delay": 1, "prognosis": {"arrival": "x"}}},
                                  {"name": "S10", "category": "S", "operator": "TILO", "stop": {"arrivalTimestamp": self.ts(15, 10), "delay": 1, "prognosis": {"arrival": "x"}}}]}
        self.assertEqual(len(raccogli.parse_swiss(board, "Lugano", self.now, "15:00", "arrival")), 2)
