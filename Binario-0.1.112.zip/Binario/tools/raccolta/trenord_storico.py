#!/usr/bin/env python3
"""
Storico Trenord e FerrovieNord di Binario.

Parte dall'ORARIO UFFICIALE (feed GTFS di Trenord, Open Data Regione Lombardia, dataset 3z4k-mxz9, CC BY 4.0): tutte le corse del giorno,
sia sulla rete RFI sia sulla rete FerrovieNord (FN). Per ogni numero chiede lo stato al servizio pubblico di Trenord (MIA) e sceglie la
corsa giusta dalle fermate: più corse possono avere lo stesso numero (10060 = Mortara RFI e Varese Nord FN) e prendere la prima è sbagliato.
Salva, per ogni corsa: soppressione totale o parziale, ritardo finale e massimo, e i treni «aggiunti» che non sono nell'orario
(es. il 4747 straordinario che ha preso il posto del 2727 soppresso). I treni aggiunti si collegano al soppresso quando partono dalla stessa
stazione, vanno alla stessa destinazione e l'orario differisce al più di 15 minuti.

Nessuna dipendenza oltre alla libreria standard. Tutte le funzioni di rete si possono sostituire nei test.
"""
import csv, io, json, os, re, time, unicodedata, urllib.parse, urllib.request, zipfile
from datetime import datetime

META = "https://www.dati.lombardia.it/api/views/3z4k-mxz9.json"
FILES = "https://www.dati.lombardia.it/api/views/3z4k-mxz9/files/"
LEGACY = "https://www.dati.lombardia.it/download/3z4k-mxz9/application%2Fzip"
MIA = "https://admin.trenord.it/store-management-api/mia/train/"
UA = "Binario/0.1.112 (Android app com.binario.treni)"

TR_FIELDS = ["giorno", "numero", "categoria", "linea", "rete", "origine_id", "origine", "destinazione_id", "destinazione",
             "partenza", "arrivo", "stato", "ritardo_finale", "ritardo_max", "fermate_totali", "fermate_soppresse",
             "programmato", "sostituito_da", "sostituisce", "visto"]
LINK_FIELDS = ["giorno", "soppresso", "aggiunto", "origine", "destinazione", "partenza_soppresso", "partenza_aggiunto", "differenza_minuti"]
MAX_DIFF_MIN = 15       # un treno aggiunto sostituisce un soppresso se parte entro questo scarto
MIN_OVERLAP = 0.5       # quota minima di fermate in comune per dire «è la stessa corsa»
RANK = {"soppresso": 3, "arrivato": 3, "in_corso": 2, "senza_dati": 1}

# Capolinea della rete FerrovieNord (nomi normalizzati): una corsa che li tocca è FN anche se molte fermate sono condivise con RFI
FN_TERMINI = {"milanocadorna", "varesenord", "comolago", "lavenomombellolago", "novaranord", "asso", "malpensaaeroportot1",
              "malpensaaeroportot2", "seveso", "iseo", "edolo", "brescia"}


def norm(name):
    """Nome di fermata confrontabile: minuscolo, senza accenti, senza parentesi e sigla FN, solo lettere e cifre."""
    s = unicodedata.normalize("NFD", str(name or "").lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = re.sub(r"\([^)]*\)", " ", s)
    s = re.sub(r"\bf\.?\s?n\.?(?=\s|$)", " ", s)
    s = re.sub(r"\b(ferrovienord|fn)\b", " ", s)
    return re.sub(r"[^a-z0-9]", "", s)


def hm(seconds):
    s = int(seconds) % 86400
    return "%02d:%02d" % (s // 3600, (s % 3600) // 60)


def hm_minutes(text):
    try:
        h, m = str(text).split(":")[:2]
        return int(h) * 60 + int(m)
    except Exception:  # noqa
        return None


def seconds(text):
    try:
        p = [int(x) for x in str(text).strip().split(":")]
        return p[0] * 3600 + p[1] * 60 + (p[2] if len(p) > 2 else 0)
    except Exception:  # noqa
        return -1


# ---------------------------------------------------------------- orario ufficiale (GTFS)

def gtfs_download(dest, get_bytes=None):
    """Scarica il feed GTFS in [dest]. L'identificativo del file cambia quando Trenord lo aggiorna: si legge dalla scheda del dataset."""
    get_bytes = get_bytes or _http_bytes
    urls = []
    try:
        blob = json.loads(get_bytes(META, 30).decode("utf-8", "replace")).get("blobId")
        if blob:
            urls.append(FILES + blob + "?download=true&filename=trenord_gtfs.zip")
    except Exception:  # noqa
        pass
    urls.append(LEGACY)
    last = None
    for u in urls:
        try:
            data = get_bytes(u, 180)
            if len(data) < 20_000 or data[:2] != b"PK":
                raise ValueError("file non valido")
            with open(dest, "wb") as f:
                f.write(data)
            return dest
        except Exception as e:  # noqa
            last = e
    raise RuntimeError(f"orario Trenord non scaricabile: {last}")


def _http_bytes(url, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _table(z, name):
    with z.open(name) as raw:
        for row in csv.DictReader(io.TextIOWrapper(raw, encoding="utf-8-sig", newline="")):
            yield row


def _active(service, day_key, weekday, weekly, added, removed):
    if (service, day_key) in removed:
        return False
    if (service, day_key) in added:
        return True
    w = weekly.get(service)
    if not w:
        return False
    days, start, end = w
    return days[weekday] and start <= day_key <= end


def gtfs_trips(zip_path, day, fn_ids=frozenset()):
    """Corse ferroviarie (route_type 2 o 1xx) attive nel giorno [day] «AAAA-MM-GG»: numero, linea, rete, fermate con orari."""
    key = day.replace("-", "")
    weekday = datetime.strptime(day, "%Y-%m-%d").weekday()
    with zipfile.ZipFile(zip_path) as z:
        names = {}
        for r in _table(z, "stops.txt"):
            names[r.get("stop_id", "")] = r.get("stop_name", "")
        rail = {}
        for r in _table(z, "routes.txt"):
            try:
                t = int(r.get("route_type", ""))
            except ValueError:
                continue
            if t == 2 or 100 <= t <= 199:
                rail[r["route_id"]] = r.get("route_short_name", "")
        trips = {}
        for r in _table(z, "trips.txt"):
            if r.get("route_id") in rail:
                num = (r.get("trip_short_name") or "").split(" - ")[-1].strip() or r["trip_id"]
                trips[r["trip_id"]] = (r["route_id"], r.get("service_id", ""), num)
        services = {t[1] for t in trips.values()}
        weekly = {}
        if "calendar.txt" in z.namelist():
            for r in _table(z, "calendar.txt"):
                sv = r.get("service_id", "")
                if sv in services:
                    d = [r.get(k) == "1" for k in ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")]
                    weekly[sv] = (d, int(r.get("start_date") or 0), int(r.get("end_date") or 99999999))
        added, removed = set(), set()
        if "calendar_dates.txt" in z.namelist():
            for r in _table(z, "calendar_dates.txt"):
                if r.get("date") != key or r.get("service_id") not in services:
                    continue
                (added if r.get("exception_type") == "1" else removed if r.get("exception_type") == "2" else set()).add((r["service_id"], int(key)))
        k = int(key)
        wanted = {tid for tid, (_, sv, _) in trips.items() if _active(sv, k, weekday, weekly, added, removed)}
        rows = {}
        for r in _table(z, "stop_times.txt"):
            tid = r.get("trip_id")
            if tid not in wanted:
                continue
            a = seconds(r.get("arrival_time") or r.get("departure_time"))
            d = seconds(r.get("departure_time") or r.get("arrival_time"))
            if a < 0 or d < 0:
                continue
            rows.setdefault(tid, []).append((int(r.get("stop_sequence") or 0), r.get("stop_id", ""), a, d))
    out = []
    for tid, lst in rows.items():
        lst.sort()
        stops = [(sid, names.get(sid, sid), a, d) for _, sid, a, d in lst]
        if len(stops) < 2:
            continue
        route, _, num = trips[tid]
        out.append({"numero": num, "linea": rail.get(route, ""), "stops": stops,
                    "origine_id": stops[0][0], "origine": stops[0][1], "destinazione_id": stops[-1][0], "destinazione": stops[-1][1],
                    "partenza": hm(stops[0][3]), "arrivo": hm(stops[-1][2]), "rete": network_of(stops, fn_ids)})
    out.sort(key=lambda t: (int(t["numero"]) if t["numero"].isdigit() else 0, t["partenza"]))
    return out


def network_of(stops, fn_ids=frozenset()):
    """«FN» se la corsa è sulla rete FerrovieNord (metà delle fermate sono FN o tocca un capolinea FN), altrimenti «RFI»."""
    if not stops:
        return "RFI"
    names = [norm(s[1]) for s in stops]
    fn = sum(1 for s in stops if s[0] in fn_ids)
    if fn * 2 >= len(stops) or names[0] in FN_TERMINI or names[-1] in FN_TERMINI:
        return "FN"
    return "RFI"


# ---------------------------------------------------------------- servizio live di Trenord (MIA)

def journeys_of(root, day):
    """Tutte le corse del giorno [day] «AAAA-MM-GG» nella risposta MIA: lo stesso numero può avere più corse."""
    key = day.replace("-", "")
    out = []
    items = root if isinstance(root, list) else ([root] if isinstance(root, dict) else [])
    for entry in items:
        for j in (entry.get("journey_list") or []):
            t = j.get("train") or {}
            d = str(t.get("date") or entry.get("date") or "").strip()
            if (d and d != key) or len(j.get("pass_list") or []) < 2:
                continue
            out.append((entry, j))
    return out


def _stops_of(journey):
    out = []
    for p in journey.get("pass_list") or []:
        st = p.get("station") or {}
        out.append((str(st.get("station_id") or ""), norm(st.get("station_ori_name"))))
    return out


def overlap(a, b):
    """Quota di fermate in comune (per codice o per nome) rispetto alla corsa più corta; 0 se una è vuota."""
    if not a or not b:
        return 0.0
    ids_a = {i for i, _ in a if i}; ids_b = {i for i, _ in b if i}
    names_a = {n for _, n in a if n}; names_b = {n for _, n in b if n}
    short = min(len(a), len(b))
    return max(len(ids_a & ids_b), len(names_a & names_b)) / short


def pick_journey(root, day, trip_stops):
    """La corsa del servizio MIA che coincide con le fermate [trip_stops] [(id, nome)]; None se nessuna coincide abbastanza."""
    best, score = None, 0.0
    for entry, j in journeys_of(root, day):
        s = overlap(trip_stops, _stops_of(j))
        if s > score:
            best, score = (entry, j), s
    return best if score >= MIN_OVERLAP else None


def record_of(entry, journey, day, seen, trip=None, fn_ids=frozenset()):
    """Registro di una corsa dal servizio MIA. [trip] = corsa dell'orario ufficiale; senza, è un treno «aggiunto» (non in orario)."""
    passes = journey.get("pass_list") or []
    train = journey.get("train") or {}
    n = len(passes)
    cancelled = [bool(p.get("cancelled")) for p in passes]
    total = bool(entry.get("cancelled")) or all(cancelled)
    delays, last_arr = [], None
    for i, p in enumerate(passes):
        a = p.get("actual_data") or {}
        for key in ("arr_delay_actual", "dep_delay_actual"):
            v = a.get(key)
            if isinstance(v, (int, float)):
                delays.append(int(v))
        if i == n - 1 and isinstance(a.get("arr_delay_actual"), (int, float)):
            last_arr = int(a["arr_delay_actual"])
    st0 = passes[0].get("station") or {}
    st1 = passes[-1].get("station") or {}

    def hh(p, k):
        return str(p.get(k) or "")[:5]

    if total:
        stato = "soppresso"
    elif last_arr is not None and not cancelled[-1]:
        stato = "arrivato"
    elif delays:
        stato = "in_corso"
    else:
        stato = "senza_dati"
    try:
        current = int(train.get("delay") if train.get("delay") is not None else entry.get("delay") or 0)
    except (TypeError, ValueError):
        current = 0
    final = last_arr if last_arr is not None else (current if stato == "in_corso" else 0)
    stops_basic = [(s[0], s[1]) for s in _stops_of(journey)]
    if trip is not None:
        origin_id, origin = trip["origine_id"], trip["origine"].title()
        dest_id, dest = trip["destinazione_id"], trip["destinazione"].title()
        dep, arr, line, net = trip["partenza"], trip["arrivo"], trip["linea"], trip["rete"]
    else:
        origin_id, origin = str(st0.get("station_id") or ""), str(st0.get("station_ori_name") or "").title()
        dest_id, dest = str(st1.get("station_id") or ""), str(st1.get("station_ori_name") or "").title()
        dep, arr, line = hh(passes[0], "dep_time"), hh(passes[-1], "arr_time"), str(train.get("train_category") or "")
        net = network_of([(i, nm) for i, nm in stops_basic], fn_ids)
    return {
        "giorno": day, "numero": str(train.get("train_id") or train.get("train_name") or (trip or {}).get("numero") or "").strip(),
        "categoria": str(train.get("train_category") or line or "").strip(), "linea": line, "rete": net,
        "origine_id": origin_id, "origine": origin, "destinazione_id": dest_id, "destinazione": dest, "partenza": dep, "arrivo": arr,
        "stato": stato, "ritardo_finale": final, "ritardo_max": max(delays + [final]) if (delays or final) else 0,
        "fermate_totali": n, "fermate_soppresse": sum(cancelled), "programmato": 1 if trip is not None else 0,
        "sostituito_da": "", "sostituisce": "", "visto": seen,
    }


# ---------------------------------------------------------------- sostituzioni

def link_replacements(records):
    """Collega ogni treno soppresso al treno aggiunto che parte dalla stessa stazione e va alla stessa destinazione, entro 15 minuti.
    Ogni aggiunto sostituisce al più un soppresso (il più vicino): nei casi ambigui non si collega a caso. Restituisce le coppie."""
    cancelled = [r for r in records if r["stato"] == "soppresso" and str(r["programmato"]) == "1"]
    added = [r for r in records if str(r["programmato"]) == "0" and r["stato"] != "soppresso"]
    cands = []
    for c in cancelled:
        for a in added:
            if norm(c["origine"]) != norm(a["origine"]) or norm(c["destinazione"]) != norm(a["destinazione"]):
                continue
            t1, t2 = hm_minutes(c["partenza"]), hm_minutes(a["partenza"])
            if t1 is None or t2 is None:
                continue
            d = abs(t1 - t2)
            if d <= MAX_DIFF_MIN:
                cands.append((d, c, a))
    cands.sort(key=lambda x: x[0])
    used_c, used_a, pairs = set(), set(), []
    for d, c, a in cands:
        if id(c) in used_c or id(a) in used_a:
            continue
        # ambiguo: un altro candidato alla stessa distanza per la stessa coppia → non si collega
        rivals = [x for x in cands if x[0] == d and (x[1] is c) != (x[2] is a) and (x[1] is c or x[2] is a)]
        if rivals:
            continue
        used_c.add(id(c)); used_a.add(id(a))
        c["sostituito_da"] = a["numero"]
        a["sostituisce"] = c["numero"]
        pairs.append({"giorno": c["giorno"], "soppresso": c["numero"], "aggiunto": a["numero"], "origine": c["origine"],
                      "destinazione": c["destinazione"], "partenza_soppresso": c["partenza"], "partenza_aggiunto": a["partenza"],
                      "differenza_minuti": d})
    return pairs


# ---------------------------------------------------------------- file

def rec_key(r):
    return (r["giorno"], str(r["numero"]), r["origine_id"], r["partenza"])


def merge_records(old, new):
    """Una corsa già conclusa (arrivata o soppressa) non cambia più; altrimenti vale il rilevamento più avanzato, a parità l'ultimo."""
    for k, r in new.items():
        o = old.get(k)
        if o:
            ro, rn = RANK.get(o.get("stato"), 0), RANK.get(r["stato"], 0)
            if o.get("stato") in ("arrivato", "soppresso") and o.get("stato") != r["stato"]:
                continue
            if rn < ro:
                continue
            # i collegamenti già trovati non si perdono
            r = dict(r)
            for f in ("sostituito_da", "sostituisce"):
                if not r.get(f) and o.get(f):
                    r[f] = o[f]
        old[k] = {f: str(v) if v is not None else "" for f, v in r.items()}
    return old


def load_records(folder, day):
    p = os.path.join(folder, "trenord", day + ".csv")
    data = {}
    if os.path.exists(p):
        with open(p, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f, delimiter=";"):
                data[rec_key(r)] = r
    return data


def save_records(folder, day, data):
    os.makedirs(os.path.join(folder, "trenord"), exist_ok=True)
    with open(os.path.join(folder, "trenord", day + ".csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=TR_FIELDS, delimiter=";")
        w.writeheader()
        for k in sorted(data, key=lambda k: (k[0], int(k[1]) if k[1].isdigit() else 0, k[3])):
            w.writerow({x: data[k].get(x, "") for x in TR_FIELDS})


def save_links(folder, pairs):
    """Elenco delle sostituzioni (file unico, senza doppioni; si ripulisce con i giorni conservati)."""
    p = os.path.join(folder, "trenord", "sostituzioni.csv")
    cur = {}
    if os.path.exists(p):
        with open(p, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f, delimiter=";"):
                cur[(r["giorno"], r["soppresso"], r["aggiunto"])] = r
    for q in pairs:
        cur[(q["giorno"], str(q["soppresso"]), str(q["aggiunto"]))] = {k: str(v) for k, v in q.items()}
    os.makedirs(os.path.join(folder, "trenord"), exist_ok=True)
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=LINK_FIELDS, delimiter=";")
        w.writeheader()
        for k in sorted(cur):
            w.writerow({x: cur[k].get(x, "") for x in LINK_FIELDS})


def to_legacy(rec):
    """Riga nel formato storico di prima (giorni/AAAA-MM-GG.csv) per le corse concluse: serve a treni-30g.csv e alla classifica."""
    if rec["stato"] not in ("arrivato", "soppresso"):
        return None
    return {"giorno": rec["giorno"], "numero": rec["numero"], "categoria": rec["categoria"], "origine": rec["origine"],
            "stazione": rec["destinazione_id"], "nome": rec["destinazione"], "orario": rec["arrivo"],
            "ritardo": int(rec["ritardo_finale"]) if rec["stato"] == "arrivato" else 0,
            "soppresso": 1 if rec["stato"] == "soppresso" else 0, "arrivato": 1 if rec["stato"] == "arrivato" else 0,
            "visto": rec["visto"], "fonte": "Trenord-" + rec["rete"]}


# ---------------------------------------------------------------- passaggio

def run(folder, day, seen, trips, fetch, extra_numbers=(), only_fn=False, fn_ids=frozenset(), pause=0.35, max_calls=3200,
        sleep=time.sleep, log=print):
    """Legge lo stato di ogni corsa dell'orario ufficiale (e dei numeri «extra» visti ai tabelloni ma non in orario).
    [fetch(numero)] restituisce la risposta MIA (lista/dizionario) o solleva un'eccezione. Salva i file e restituisce
    (registri nuovi, coppie di sostituzione, righe nel vecchio formato)."""
    by_number = {}
    for t in trips:
        if only_fn and t["rete"] != "FN":
            continue
        by_number.setdefault(t["numero"], []).append(t)
    numbers = sorted(by_number, key=lambda x: int(x) if x.isdigit() else 0)
    extras = [n for n in sorted(set(extra_numbers), key=lambda x: int(x) if x.isdigit() else 0) if n not in {t["numero"] for t in trips}]
    new, errors, calls, empty_extra = {}, 0, 0, []
    for n in numbers + extras:
        if calls >= max_calls:
            log(f"Trenord: limite di {max_calls} richieste raggiunto")
            break
        calls += 1
        try:
            root = fetch(n)
        except Exception:  # noqa
            errors += 1
            if errors >= 25 and not new:
                log("Trenord: servizio non raggiungibile da questo indirizzo")
                break
            sleep(pause * 2)
            continue
        if n in by_number:
            for t in by_number[n]:
                hit = pick_journey(root, day, [(s[0], norm(s[1])) for s in t["stops"]])
                if hit:
                    r = record_of(hit[0], hit[1], day, seen, trip=t, fn_ids=fn_ids)
                    new[rec_key(r)] = r
        else:
            js = journeys_of(root, day)
            if not js:
                empty_extra.append(n)
            for entry, j in js:
                r = record_of(entry, j, day, seen, trip=None, fn_ids=fn_ids)
                if r["numero"]:
                    new[rec_key(r)] = r
        sleep(pause)
    cur = merge_records(load_records(folder, day), new)
    pairs = link_replacements(list(cur.values()))
    save_records(folder, day, cur)
    save_links(folder, pairs)
    legacy = [x for x in (to_legacy(r) for r in cur.values()) if x]
    log(f"Trenord: {len(new)} corse lette · {len(pairs)} sostituzioni · errori {errors} · extra senza risposta {len(empty_extra)}")
    return new, pairs, legacy, empty_extra
