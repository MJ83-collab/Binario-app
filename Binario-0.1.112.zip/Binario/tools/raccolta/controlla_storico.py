#!/usr/bin/env python3
"""Controlla i CSV del collettore Trenord/FN/TILO (storico/trenord/AAAA-MM-GG.csv e sostituzioni.csv).

Uso:  python3 tools/raccolta/controlla_storico.py [cartella]      (predefinita: storico/trenord)
Esce con codice 0 se tutto torna, 1 se trova problemi; stampa un riepilogo leggibile.
"""
import csv, os, re, sys, glob
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from trenord_storico import TR_FIELDS, LINK_FIELDS

STATI = {"arrivato", "in_corso", "soppresso", "senza_dati"}
RETI = {"RFI", "FN", "CH", "TILO", "Trenord", "Trenord-RFI/FN", ""}


def check_day(path):
    errs, n, stati = [], 0, {}
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f, delimiter=";")
        if r.fieldnames != TR_FIELDS:
            return [f"{path}: colonne diverse dal previsto"], 0, {}
        seen = set()
        giorno = os.path.basename(path)[:-4]
        for i, row in enumerate(r, 2):
            n += 1
            k = (row["numero"], row["origine_id"], row["partenza"])
            if k in seen:
                errs.append(f"{path}:{i}: corsa doppia {k}")
            seen.add(k)
            if row["giorno"] != giorno:
                errs.append(f"{path}:{i}: giorno {row['giorno']} diverso dal file")
            if row["stato"] not in STATI:
                errs.append(f"{path}:{i}: stato sconosciuto «{row['stato']}»")
            stati[row["stato"]] = stati.get(row["stato"], 0) + 1
            for c in ("ritardo_finale", "ritardo_max"):
                if row[c] and not re.fullmatch(r"-?\d{1,3}", row[c]):
                    errs.append(f"{path}:{i}: {c} non numerico «{row[c]}»")
                elif row[c] and abs(int(row[c])) > 600:
                    errs.append(f"{path}:{i}: {c} implausibile ({row[c]} min)")
            if row["stato"] == "soppresso" and row["ritardo_finale"] not in ("", "0"):
                errs.append(f"{path}:{i}: soppresso ma con ritardo {row['ritardo_finale']}")
    return errs, n, stati


def check_links(path):
    errs, n = [], 0
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f, delimiter=";")
        if r.fieldnames != LINK_FIELDS:
            return [f"{path}: colonne diverse dal previsto"], 0
        for i, row in enumerate(r, 2):
            n += 1
            if row["soppresso"] == row["aggiunto"]:
                errs.append(f"{path}:{i}: un treno non può sostituire se stesso")
            d = row["differenza_minuti"]
            if not re.fullmatch(r"\d{1,2}", d or "x") or int(d) > 15:
                errs.append(f"{path}:{i}: differenza fuori dai 15 minuti ({d})")
    return errs, n


def main(folder):
    days = sorted(glob.glob(os.path.join(folder, "????-??-??.csv")))
    if not days:
        print(f"Nessun file in {folder}: il collettore non ha ancora girato (o ha scritto altrove).")
        return 1
    errs, tot, stati = [], 0, {}
    for p in days:
        e, n, s = check_day(p)
        errs += e
        tot += n
        for k, v in s.items():
            stati[k] = stati.get(k, 0) + v
    links = os.path.join(folder, "sostituzioni.csv")
    nl = 0
    if os.path.exists(links):
        e, nl = check_links(links)
        errs += e
    print(f"{len(days)} giorni, {tot} corse, stati {stati}, {nl} sostituzioni collegate")
    if tot and stati.get("senza_dati", 0) / tot > 0.5:
        errs.append("Più della metà delle corse è «senza_dati»: probabile fonte in tempo reale non raggiunta")
    for e in errs[:40]:
        print("PROBLEMA:", e)
    print("Tutto a posto." if not errs else f"{len(errs)} problemi.")
    return 0 if not errs else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "storico/trenord"))
