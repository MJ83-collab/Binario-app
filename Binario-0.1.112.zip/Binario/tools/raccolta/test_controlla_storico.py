import csv, os, tempfile, unittest
import controlla_storico as c
from trenord_storico import TR_FIELDS, LINK_FIELDS


def write(path, fields, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter=";")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


class T(unittest.TestCase):
    def test_ok_and_problems(self):
        d = tempfile.mkdtemp()
        good = dict(giorno="2026-11-05", numero="2727", origine_id="S1", partenza="19:00", stato="soppresso", ritardo_finale="0")
        write(os.path.join(d, "2026-11-05.csv"), TR_FIELDS, [good, dict(good, numero="2728", stato="arrivato", ritardo_finale="3")])
        write(os.path.join(d, "sostituzioni.csv"), LINK_FIELDS, [dict(giorno="2026-11-05", soppresso="2727", aggiunto="4747", differenza_minuti="8")])
        self.assertEqual(c.main(d), 0)
        write(os.path.join(d, "2026-11-05.csv"), TR_FIELDS, [good, good, dict(good, numero="9", stato="boh", ritardo_finale="900")])
        self.assertEqual(c.main(d), 1)

    def test_empty_folder(self):
        self.assertEqual(c.main(tempfile.mkdtemp()), 1)


if __name__ == "__main__":
    unittest.main()
