#!/usr/bin/env python3
"""
Raccolta dei ritardi di Binario: ogni esecuzione legge i tabelloni «arrivi» di ViaggiaTreno per alcune stazioni principali,
aggiorna i file del giorno e ricalcola lo storico (ultimi 30 giorni) e la classifica giornaliera.
Dati propri di Binario, ricavati da ViaggiaTreno (non ufficiali). Nessuna dipendenza oltre alla libreria standard.

Uso:  python3 raccogli.py --out CARTELLA            (raccolta reale; il passaggio Trenord scatta da solo dopo le 23)
      python3 raccogli.py --out CARTELLA --trenord  (forza il passaggio Trenord)
      python3 raccogli.py --out CARTELLA --demo F   (prova offline: F = file JSON di un tabellone arrivi)
"""
import argparse, csv, glob, json, os, sys, tempfile, time, urllib.parse, urllib.request
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

ROME = ZoneInfo("Europe/Rome")
VT = "http://www.viaggiatreno.it/infomobilita/resteasy/viaggiatreno/arrivi/"
UA = "Binario/0.1.112 (Android app com.binario.treni)"

# Stazioni (codici ViaggiaTreno già usati dall'app in «Ritardi ora»). Si allarga più avanti.
HUBS_NAZIONALI = [
    ("S08409", "Roma Termini"), ("S01700", "Milano Centrale"), ("S09218", "Napoli Centrale"), ("S06421", "Firenze S.M.N."),
    ("S05043", "Bologna Centrale"), ("S00219", "Torino Porta Nuova"), ("S02593", "Venezia S. Lucia"), ("S02430", "Verona Porta Nuova"),
    ("S04700", "Genova Piazza Principe"), ("S11119", "Bari Centrale"), ("S08217", "Roma Tiburtina"), ("S01820", "Milano Rogoredo"),
    ("S02581", "Padova"), ("S09818", "Salerno"),
]
# Stazioni FerrovieNord (codici ViaggiaTreno), non lette dai tabelloni: la rete FN è coperta dall'orario Trenord (trenord_storico.py)
FN_HUBS = [("S01066", "Milano Cadorna"), ("S01738", "Varese Nord"), ("S01933", "Saronno"), ("S01765", "Como Lago"), ("S00023", "Novara Nord"),
           ("S01139", "Malpensa T1"), ("S01925", "Seveso"), ("S01747", "Laveno Lago"), ("S01101", "Asso"), ("S01137", "Busto Arsizio Nord")]
SWISS = "https://transport.opendata.ch/v1/stationboard"
# Nodi svizzeri (nome per transport.opendata.ch): arrivi di TILO e FFS. Dalle partenze dei nodi ticinesi si ricava anche l'arrivo dei TILO in Italia.
SWISS_HUBS = ["Lugano", "Chiasso", "Mendrisio", "Bellinzona", "Locarno", "Zürich HB", "Bern", "Basel SBB", "Genève", "Luzern"]
TILO_HUBS = ["Lugano", "Chiasso", "Mendrisio", "Bellinzona", "Locarno"]
FN_NAMES = {"milanocadorna", "varesenord", "saronno", "comolago", "novaranord", "malpensaaeroportot1", "malpensaaeroportot2", "malpensat1",
            "malpensat2", "seveso", "lavenomombellolago", "lavenolago", "asso", "bustoarsizionord", "milanobovisapolitecnico"}
KEEP_DAYS = 45      # giorni di file grezzi conservati
WINDOW_DAYS = 30    # giorni dello storico per treno e della classifica
PAUSE = 1.0         # secondi tra una richiesta e l'altra (poche richieste, gentili con il servizio)
FIELDS = ["giorno", "numero", "categoria", "origine", "stazione", "nome", "orario", "ritardo", "soppresso", "arrivato", "visto", "fonte"]

ITALO = "https://italoinviaggio.italotreno.com/api/RicercaStazioneService?CodiceStazione="
MIA = "https://admin.trenord.it/store-management-api/mia/train/"
TRENORD_MAX = 1200  # treni Trenord letti per passaggio
# Nodi lombardi (codici ViaggiaTreno): servono anche a conoscere i numeri dei treni Trenord del giorno
LOMBARDIA = [
    ("S01933", "Saronno"), ("S01322", "Monza"), ("S01520", "Lecco"), ("S01529", "Bergamo"), ("S01717", "Brescia"),
    ("S01307", "Como S. Giovanni"), ("S01205", "Varese"), ("S01860", "Pavia"),
]
# Stazioni Italo (codici del servizio «Italo in viaggio»)
ITALO_HUBS = [
    ("MC_", "Milano Centrale"), ("RG_", "Milano Rogoredo"), ("BC_", "Bologna Centrale"), ("SMN", "Firenze S.M.N."),
    ("RMT", "Roma Termini"), ("RTB", "Roma Tiburtina"), ("NAC", "Napoli Centrale"), ("SAL", "Salerno"),
    ("TOP", "Torino Porta Nuova"), ("OUE", "Torino Porta Susa"), ("VSL", "Venezia S. Lucia"), ("VEM", "Venezia Mestre"),
    ("PD_", "Padova"), ("VPN", "Verona Porta Nuova"), ("BAC", "Bari Centrale"), ("AAV", "Reggio Emilia AV"),
]
NOT_TRENORD = {"FR", "FA", "FB", "IC", "ICN", "EC", "EN", "ITA", "EXP"}
HUBS = HUBS_NAZIONALI + LOMBARDIA


def vt_date(t):
    d = t.astimezone(ROME)
    return d.strftime("%a %b %d %Y %H:%M:%S") + " GMT" + d.strftime("%z")


def fetch(code, now, retries=2):
    url = VT + code + "/" + urllib.parse.quote(vt_date(now))
    last = None
    for k in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:  # noqa
            last = e
            time.sleep(2 + 3 * k)
    raise RuntimeError(f"{code}: {last}")


def day_of(ms):
    return datetime.fromtimestamp(ms / 1000, ROME).strftime("%Y-%m-%d")


def parse(board, code, name, seen, fonte="RFI"):
    """Righe (chiave → record) dal tabellone arrivi di una stazione."""
    out = {}
    for o in board or []:
        ms = o.get("orarioArrivo")
        num = str(o.get("numeroTreno") or "").strip()
        if not ms or not num:
            continue
        comp = (o.get("compNumeroTreno") or "").strip()
        cat = comp.split(" ")[0] if " " in comp else (o.get("categoria") or "").strip()
        rec = {
            "giorno": day_of(ms), "numero": num, "categoria": cat, "origine": (o.get("origine") or "").title(),
            "stazione": code, "nome": name, "orario": datetime.fromtimestamp(ms / 1000, ROME).strftime("%H:%M"),
            "ritardo": int(o.get("ritardo") or 0), "soppresso": 1 if o.get("provvedimento") == 1 else 0,
            "arrivato": 1 if o.get("arrivato") else 0, "visto": seen, "fonte": fonte,
        }
        out[(rec["giorno"], num, code)] = rec
    return out


def _norm(x):
    import unicodedata
    x = unicodedata.normalize("NFD", str(x or "").lower())
    return "".join(c for c in x if c.isalnum() and unicodedata.category(c) != "Mn")


def swiss_network(station_name, country_hint=None):
    """Rete di una stazione di arrivo di un treno TILO: «CH» (Svizzera), «FN» o «RFI» (Italia)."""
    n = _norm(station_name)
    if n in FN_NAMES:
        return "FN"
    if country_hint == "IT":
        return "RFI"
    return "CH"


def parse_swiss(board, hub, now, seen, mode="arrival"):
    """Righe dal tabellone svizzero (transport.opendata.ch). «arrival»: arrivi alla stazione [hub] di TILO e FFS.
    «departure»: solo i TILO, registrati alla loro destinazione (anche in Italia, su rete RFI o FN) con il ritardo dell'ultima fermata."""
    out = {}
    for j in (board or {}).get("stationboard") or []:
        op = str(j.get("operator") or "").upper()
        tilo = "TILO" in op
        if mode == "departure" and not tilo:
            continue
        num = str(j.get("name") or j.get("number") or "").strip().lstrip("0").replace(" ", "")
        cat = str(j.get("category") or "").strip()
        line = str(j.get("number") or "").strip()
        if not num:
            continue
        stop = j.get("stop") or {}
        if mode == "arrival":
            ts, delay, name, origin = stop.get("arrivalTimestamp"), stop.get("delay"), hub, (j.get("to") or "")
            prog = (stop.get("prognosis") or {}).get("arrival")
            station_key = "CH" + hub
            net = "CH"
        else:
            pl = j.get("passList") or []
            if len(pl) < 2:
                continue
            last = pl[-1]
            ts, delay = last.get("arrivalTimestamp"), last.get("delay")
            prog = (last.get("prognosis") or {}).get("arrival")
            name = (last.get("station") or {}).get("name") or ""
            origin = hub
            net = swiss_network(name, "IT" if str((last.get("station") or {}).get("id") or "").startswith("83") else "CH")
            station_key = "CH" + _norm(name)
        if not ts:
            continue
        arr = datetime.fromtimestamp(int(ts), ROME)
        import re as _re
        if not _re.search(r"\d{4,}", num):   # nome di linea (es. «S10»), non numero di treno: si distingue per orario
            num = num + "-" + arr.strftime("%H%M")
        d = int(delay or 0)
        arrived = 1 if arr <= now and prog is not None else 0
        if mode == "arrival" and not tilo:
            fonte = "FFS"
        else:
            fonte = "TILO-" + net
        rec = {
            "giorno": arr.strftime("%Y-%m-%d"), "numero": num, "categoria": (cat + line if cat and line and cat in ("S", "RE") else cat), "origine": str(origin).title(),
            "stazione": station_key, "nome": str(name), "orario": arr.strftime("%H:%M"), "ritardo": max(d, 0), "soppresso": 0,
            "arrivato": arrived, "visto": seen, "fonte": fonte,
        }
        out[(rec["giorno"], num, station_key)] = rec
    return out


def get_json(url, retries=1):
    last = None
    for k in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:  # noqa
            last = e
            time.sleep(2 + 3 * k)
    raise RuntimeError(f"{url[-40:]}: {last}")


def hhmm_ms(hhmm, now):
    """«HH:MM» di oggi (ora italiana) in millisecondi; None se il formato non è valido."""
    try:
        h, m = hhmm.strip().split(":")[:2]
        d = now.replace(hour=int(h), minute=int(m), second=0, microsecond=0)
        return d
    except Exception:  # noqa
        return None


def parse_italo(board, code, name, now, seen):
    """Arrivi Italo di una stazione. Il servizio dà il ritardo attuale: vale come finale quando l'arrivo previsto è passato."""
    out = {}
    day = now.strftime("%Y-%m-%d")
    for o in (board or {}).get("ListaTreniArrivo") or []:
        num = str(o.get("Numero") or "").strip()
        sched = hhmm_ms(str(o.get("OraPassaggio") or ""), now)
        if not num or sched is None:
            continue
        delay = int(o.get("Ritardo") or 0)
        info = (str(o.get("Informazioni") or "") + " " + str(o.get("Descrizione") or "")).upper()
        canc = 1 if "SOPPRESS" in info or "CANCELL" in info else 0
        expected = sched + timedelta(minutes=delay)
        rec = {
            "giorno": day, "numero": num, "categoria": "ITA", "origine": str(o.get("DescrizioneLocalita") or "").title(),
            "stazione": "IT" + code, "nome": name, "orario": sched.strftime("%H:%M"), "ritardo": delay, "soppresso": canc,
            "arrivato": 1 if expected <= now else 0, "visto": seen, "fonte": "Italo",
        }
        out[(day, num, "IT" + code)] = rec
    return out


def parse_mia(root, day, seen):
    """Un treno Trenord dal servizio MIA: ritardo finale all'ultima fermata. None se non è un treno Trenord di quel giorno."""
    first = root[0] if isinstance(root, list) and root else (root if isinstance(root, dict) else None)
    if not first:
        return None
    jl = (first.get("journey_list") or [{}])[0]
    t = jl.get("train") or {}
    if not t or str(t.get("date") or first.get("date") or "").strip() != day.replace("-", ""):
        return None
    passes = jl.get("pass_list") or []
    if len(passes) < 2:
        return None
    last = passes[-1]
    ad = last.get("actual_data") or {}
    real = ad.get("arr_delay_actual")
    arrived = real is not None
    delay = int(real) if arrived else int(t.get("delay") or first.get("delay") or 0)
    canc = 1 if first.get("cancelled") or all(p.get("cancelled") for p in passes) else 0
    dep = (passes[0].get("station") or {}).get("station_ori_name", "")
    arr = last.get("station") or {}
    num = str(t.get("train_id") or t.get("train_name") or "").strip()
    return {
        "giorno": day, "numero": num, "categoria": str(t.get("train_category") or "").strip(), "origine": dep.title(),
        "stazione": str(arr.get("station_id") or ""), "nome": str(arr.get("station_ori_name") or "").title(),
        "orario": str(last.get("arr_time") or "")[:5], "ritardo": delay, "soppresso": canc,
        "arrivato": 1 if arrived else 0, "visto": seen, "fonte": "Trenord",
    }


def trenord_candidates(folder, day):
    """Numeri dei treni regionali visti oggi ai nodi lombardi, esclusi quelli già noti come non Trenord."""
    hubs = {c for c, _ in LOMBARDIA} | {"S01700", "S01820"}
    nums = []
    for r in load_day(folder, day).values():
        if r.get("fonte", "") in ("", "RFI") and r["stazione"] in hubs and r["categoria"].upper() not in NOT_TRENORD:
            nums.append(r["numero"])
    nums = sorted(set(nums), key=lambda x: int(x) if x.isdigit() else 0)
    skip_p = os.path.join(folder, "trenord-esclusi.txt")
    skip = set(open(skip_p).read().split()) if os.path.exists(skip_p) else set()
    return [n for n in nums if n not in skip], skip, skip_p


def run_trenord(folder, now, seen):
    """Passaggio serale: ritardo finale dei treni Trenord di oggi (il servizio non conserva i giorni passati)."""
    day = now.strftime("%Y-%m-%d")
    marker = os.path.join(folder, "trenord-fatto.txt")
    if os.path.exists(marker) and open(marker).read().strip() == day:
        print("Trenord: già fatto oggi")
        return {}
    nums, skip, skip_p = trenord_candidates(folder, day)
    print(f"Trenord: {len(nums)} treni da leggere")
    found, errors, empty = {}, 0, []
    for n in nums[:TRENORD_MAX]:
        try:
            root = get_json(MIA + urllib.parse.quote(n) + "?journey_date=" + day.replace("-", ""), retries=0)
        except Exception:  # noqa
            errors += 1
            if errors >= 25 and not found:
                print("Trenord: servizio non raggiungibile da questo indirizzo")
                break
            time.sleep(PAUSE)
            continue
        rec = parse_mia(root, day, seen)
        if rec and rec["numero"]:
            found[(day, rec["numero"], rec["stazione"])] = rec
        elif root == [] or root == {}:
            empty.append(n)
        time.sleep(0.6)
    if empty:
        with open(skip_p, "w", encoding="utf-8") as f:
            f.write("\n".join(sorted(skip | set(empty), key=lambda x: int(x) if x.isdigit() else 0)) + "\n")
    if found:
        with open(marker, "w", encoding="utf-8") as f:
            f.write(day)
    print(f"Trenord: {len(found)} treni registrati · errori {errors} · non Trenord {len(empty)}")
    return found


def load_day(folder, day):
    p = os.path.join(folder, "giorni", day + ".csv")
    data = {}
    if os.path.exists(p):
        with open(p, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f, delimiter=";"):
                data[(r["giorno"], r["numero"], r["stazione"])] = r
    return data


def save_day(folder, day, data):
    os.makedirs(os.path.join(folder, "giorni"), exist_ok=True)
    p = os.path.join(folder, "giorni", day + ".csv")
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, delimiter=";")
        w.writeheader()
        for k in sorted(data):
            w.writerow({x: data[k].get(x, "") for x in FIELDS})


def merge(old, new):
    """Un arrivo già concluso non cambia più; altrimenti vale l'ultimo rilevamento."""
    for k, r in new.items():
        o = old.get(k)
        if o and str(o.get("arrivato")) == "1":
            continue
        old[k] = {x: str(v) for x, v in r.items()}
    return old


def aggregate(folder, today):
    first = (today - timedelta(days=WINDOW_DAYS - 1)).strftime("%Y-%m-%d")
    rows = []
    for p in sorted(glob.glob(os.path.join(folder, "giorni", "*.csv"))):
        day = os.path.basename(p)[:-4]
        if day < first or day > today.strftime("%Y-%m-%d"):
            continue
        with open(p, newline="", encoding="utf-8") as f:
            rows += [r for r in csv.DictReader(f, delimiter=";") if r["arrivato"] == "1" or r["soppresso"] == "1"]
    # Per treno e stazione: media, percentuale in orario (≤ 5 min, sui non soppressi) e ritardo di ogni giorno
    groups = {}
    for r in rows:
        groups.setdefault((r["numero"], r["stazione"]), []).append(r)
    with open(os.path.join(folder, "treni-30g.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["numero", "categoria", "origine", "stazione", "nome", "n_osservazioni", "n_soppressi", "ritardo_medio_minuti", "puntualita_percento", "giorni", "fonte"])
        for (num, st), L in sorted(groups.items(), key=lambda x: (int(x[0][0]) if x[0][0].isdigit() else 0, x[0][1])):
            ran = [r for r in L if r["soppresso"] != "1"]
            canc = len(L) - len(ran)
            avg = sum(int(r["ritardo"]) for r in ran) / len(ran) if ran else 0.0
            ok = sum(1 for r in ran if int(r["ritardo"]) <= 5)
            pct = 100.0 * ok / len(ran) if ran else 0.0
            days = "|".join(f'{r["giorno"]}:{"S" if r["soppresso"] == "1" else r["ritardo"]}' for r in sorted(L, key=lambda r: r["giorno"]))
            last = L[-1]
            w.writerow([num, last["categoria"], last["origine"], st, last["nome"], len(L), canc, f"{avg:.1f}", f"{pct:.1f}", days, last.get("fonte", "RFI")])
    # Classifica giornaliera: i 30 arrivi con più ritardo di ogni giorno
    with open(os.path.join(folder, "classifica-giorno.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["giorno", "posizione", "numero", "categoria", "origine", "stazione", "nome", "orario", "ritardo_minuti", "fonte"])
        by_day = {}
        for r in rows:
            if r["soppresso"] != "1":
                by_day.setdefault(r["giorno"], []).append(r)
        for day in sorted(by_day, reverse=True):
            best = {}
            for r in by_day[day]:  # lo stesso treno può comparire a più stazioni: vale il ritardo maggiore
                if r["numero"] not in best or int(r["ritardo"]) > int(best[r["numero"]]["ritardo"]):
                    best[r["numero"]] = r
            top = sorted(best.values(), key=lambda r: -int(r["ritardo"]))[:30]
            for i, r in enumerate(top, 1):
                w.writerow([day, i, r["numero"], r["categoria"], r["origine"], r["stazione"], r["nome"], r["orario"], r["ritardo"], r.get("fonte", "RFI")])
    return len(rows)


def cleanup(folder, today):
    limit = (today - timedelta(days=KEEP_DAYS)).strftime("%Y-%m-%d")
    for p in glob.glob(os.path.join(folder, "giorni", "*.csv")):
        if os.path.basename(p)[:-4] < limit:
            os.remove(p)


def run_trenord_storico(folder, now, seen, only_fn=False, trips=None):
    """Storico Trenord/FN dall'orario ufficiale (trenord_storico.py). Restituisce le righe nel vecchio formato; None se l'orario non c'è."""
    import trenord_storico as ts
    day = now.strftime("%Y-%m-%d")
    fn_ids = set()
    here = os.path.dirname(os.path.abspath(__file__))
    for p in (os.path.join(here, "fn_stations.json"), os.path.join(here, "..", "..", "app", "src", "main", "assets", "fn_stations.json")):
        if os.path.exists(p):
            try:
                fn_ids = {x["id"] for x in json.load(open(p, encoding="utf-8"))}
                break
            except Exception:  # noqa
                pass
    if trips is None:
        try:
            with tempfile.TemporaryDirectory() as tmp:
                z = ts.gtfs_download(os.path.join(tmp, "gtfs.zip"))
                trips = ts.gtfs_trips(z, day, fn_ids)
        except Exception as e:  # noqa
            print("Trenord storico:", e)
            return None
    known = {t["numero"] for t in trips}
    extra = sorted({r["numero"] for r in load_day(folder, day).values()
                    if r.get("fonte", "") in ("", "RFI") and r["categoria"].upper() not in NOT_TRENORD
                    and r["numero"] not in known and r["numero"].isdigit()})
    fetch_n = lambda n: get_json(MIA + urllib.parse.quote(n) + "?journey_date=" + day.replace("-", ""), retries=0)
    _, _, legacy, _ = ts.run(folder, day, seen, trips, fetch_n, extra_numbers=extra, only_fn=only_fn, fn_ids=fn_ids)
    return legacy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--demo")
    ap.add_argument("--demo-italo")
    ap.add_argument("--demo-trenord")
    ap.add_argument("--trenord", action="store_true", help="forza il passaggio Trenord")
    a = ap.parse_args()
    now = datetime.now(ROME)
    seen = now.strftime("%H:%M")
    found, errors = {}, []
    if a.demo:
        with open(a.demo, encoding="utf-8") as f:
            found.update(parse(json.load(f), "S00000", "Prova", seen))
    if a.demo_italo:
        with open(a.demo_italo, encoding="utf-8") as f:
            found.update(parse_italo(json.load(f), "MC_", "Milano Centrale", now, seen))
    if a.demo_trenord:
        with open(a.demo_trenord, encoding="utf-8") as f:
            rec = parse_mia(json.load(f), now.strftime("%Y-%m-%d"), seen)
        if rec:
            found[(rec["giorno"], rec["numero"], rec["stazione"])] = rec
    demo = a.demo or a.demo_italo or a.demo_trenord
    if not demo:
        # 1) Tabelloni RFI (ViaggiaTreno)
        vt_err = 0
        for code, name in HUBS:
            try:
                found.update(parse(fetch(code, now), code, name, seen))
            except Exception as e:  # noqa
                errors.append(str(e)); vt_err += 1
            time.sleep(PAUSE)
        # 2) Italo
        it_err = 0
        for code, name in ITALO_HUBS:
            try:
                found.update(parse_italo(get_json(ITALO + urllib.parse.quote(code), retries=1), code, name, now, seen))
            except Exception as e:  # noqa
                errors.append(str(e)); it_err += 1
            time.sleep(0.5)
        print(f"RFI: {len(HUBS) - vt_err}/{len(HUBS)} stazioni · Italo: {len(ITALO_HUBS) - it_err}/{len(ITALO_HUBS)} stazioni")
        # 3) Svizzera: TILO e FFS (transport.opendata.ch)
        ch_err = 0
        for hub in SWISS_HUBS:
            for mode in (["arrival", "departure"] if hub in TILO_HUBS else ["arrival"]):
                try:
                    url = SWISS + "?station=" + urllib.parse.quote(hub) + "&limit=40&type=" + mode + "&datetime=" + urllib.parse.quote(now.strftime("%Y-%m-%d %H:%M"))
                    found.update(parse_swiss(get_json(url, retries=1), hub, now, seen, mode))
                except Exception as e:  # noqa
                    errors.append(str(e)); ch_err += 1
                time.sleep(0.6)
        print(f"Svizzera: {len(SWISS_HUBS)} nodi · errori {ch_err}")
    print(f"Arrivi letti: {len(found)} · errori: {len(errors)}")
    for e in errors[:6]:
        print("  ", e)
    total = len(HUBS) + len(ITALO_HUBS) + len(SWISS_HUBS)
    if not demo and len(errors) == total:
        print("Nessuna fonte raggiungibile: probabile blocco dei servizi verso questo indirizzo.")
        sys.exit(2)
    by_day = {}
    for k, r in found.items():
        by_day.setdefault(k[0], {})[k] = r
    for day, new in by_day.items():
        save_day(a.out, day, merge(load_day(a.out, day), new))
    # 4) Trenord: una volta al giorno, in serata (dopo le 23), oppure se richiesto
    if not demo and (a.trenord or (now.hour == 23 and now.minute >= 15)):
        legacy = run_trenord_storico(a.out, now, seen)
        if legacy is None:
            tr = run_trenord(a.out, now, seen)
        else:
            tr = {(r["giorno"], r["numero"], r["stazione"]): r for r in legacy}
        for day, new in {d: {k: v for k, v in tr.items() if k[0] == d} for d in {k[0] for k in tr}}.items():
            save_day(a.out, day, merge(load_day(a.out, day), new))
    # 4b) FerrovieNord: letture di metà giornata, per cogliere subito soppressioni e treni sostitutivi
    if not demo and not a.trenord and now.hour in (9, 14, 19) and now.minute < 30:
        run_trenord_storico(a.out, now, seen, only_fn=True)
    n = aggregate(a.out, now)
    cleanup(a.out, now)
    with open(os.path.join(a.out, "leggimi.txt"), "w", encoding="utf-8") as f:
        f.write("Storico ritardi raccolto da Binario da servizi pubblici: tabelloni RFI (ViaggiaTreno), arrivi Italo (Italo in viaggio)\n"
                "e, per i treni Trenord, il ritardo reale all'ultima fermata (servizio pubblico Trenord). Trenord e TILO sono un unico servizio: nello storico\n"
                "sono uniti, con la rete (RFI, FerrovieNord, Svizzera) nella colonna fonte. TILO e FFS: transport.opendata.ch.\n"
                "Non sono dati ufficiali e non coprono tutta la rete. Ritardo = minuti all'arrivo; «in orario» = al più 5 minuti.\n"
                "Per Italo il ritardo è quello dell'ultima rilevazione dopo l'arrivo previsto.\n"
                f"Ultimo aggiornamento: {now.strftime('%d/%m/%Y %H:%M')}. Arrivi nell'ultima finestra di {WINDOW_DAYS} giorni: {n}.\n")
    print(f"Storico aggiornato: {n} arrivi negli ultimi {WINDOW_DAYS} giorni")


if __name__ == "__main__":
    main()
