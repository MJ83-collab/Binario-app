#!/usr/bin/env python3
"""Prove dello storico Trenord/FN, senza rete: orario GTFS e risposte MIA inventati.  Uso: python3 -m unittest -v test_trenord_storico"""
import csv, io, os, sys, tempfile, unittest, zipfile

QUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, QUI)
import trenord_storico as ts  # noqa: E402

DAY = "2026-11-05"


def mk_zip(path):
    files = {
        "stops.txt": "stop_id,stop_name\nS1,Milano Cadorna\nS2,Saronno\nS3,Varese Nord\nS4,Mortara\nS5,Milano Centrale\nS6,Pavia\n",
        "routes.txt": "route_id,route_short_name,route_type\nR1,S3,2\nR2,S13,2\nR3,Bus,3\n",
        "trips.txt": "route_id,service_id,trip_id,trip_short_name\nR1,SV,T1,10060\nR2,SV,T2,10060\nR1,SV,T3,2727\nR3,SV,T4,999\nR1,OFF,T5,1111\n",
        "calendar.txt": "service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,start_date,end_date\n"
                        "SV,1,1,1,1,1,1,1,20261101,20261231\nOFF,0,0,0,0,0,0,0,20261101,20261231\n",
        "calendar_dates.txt": "service_id,date,exception_type\n",
        "stop_times.txt": "trip_id,arrival_time,departure_time,stop_id,stop_sequence\n"
                          "T1,18:00:00,18:00:00,S1,1\nT1,18:20:00,18:20:00,S2,2\nT1,18:50:00,18:50:00,S3,3\n"
                          "T2,18:05:00,18:05:00,S5,1\nT2,18:50:00,18:50:00,S4,2\n"
                          "T3,19:00:00,19:00:00,S1,1\nT3,19:50:00,19:50:00,S3,2\n"
                          "T4,10:00:00,10:00:00,S1,1\nT4,10:30:00,10:30:00,S3,2\n"
                          "T5,11:00:00,11:00:00,S1,1\nT5,11:30:00,11:30:00,S3,2\n",
    }
    with zipfile.ZipFile(path, "w") as z:
        for n, c in files.items():
            z.writestr(n, c)


def p(sid, name, dep=None, arr=None, canc=False, adel=None, ddel=None):
    d = {"station": {"station_id": sid, "station_ori_name": name}, "cancelled": canc, "actual_data": {}}
    if dep: d["dep_time"] = dep + ":00"
    if arr: d["arr_time"] = arr + ":00"
    if adel is not None: d["actual_data"]["arr_delay_actual"] = adel
    if ddel is not None: d["actual_data"]["dep_delay_actual"] = ddel
    return d


def mia(num, cat, passes, canc=False, delay=0):
    return [{"date": "20261105", "cancelled": canc, "delay": delay,
             "journey_list": [{"train": {"train_id": num, "train_category": cat, "date": "20261105", "delay": delay}, "pass_list": passes}]}]


FN_IDS = {"S1", "S2", "S3"}


class Orario(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.z = os.path.join(self.tmp.name, "g.zip")
        mk_zip(self.z)
        self.trips = ts.gtfs_trips(self.z, DAY, FN_IDS)

    def tearDown(self):
        self.tmp.cleanup()

    def test_solo_ferrovia_e_servizio_attivo(self):
        nums = sorted(t["numero"] for t in self.trips)
        self.assertEqual(nums, ["10060", "10060", "2727"])   # niente bus (999) e niente servizio spento (1111)

    def test_stesso_numero_due_reti(self):
        reti = {t["origine"]: t["rete"] for t in self.trips if t["numero"] == "10060"}
        self.assertEqual(reti, {"Milano Cadorna": "FN", "Milano Centrale": "RFI"})

    def test_sceglie_la_corsa_giusta_per_fermate(self):
        # il servizio risponde con le due corse 10060: deve prendere quella FN per la corsa FN e quella RFI per la RFI
        root = [{"date": "20261105", "journey_list": [
            {"train": {"train_id": "10060", "date": "20261105"}, "pass_list": [p("S5", "MILANO CENTRALE", dep="18:05"), p("S4", "MORTARA", arr="18:50", adel=1)]},
            {"train": {"train_id": "10060", "date": "20261105"}, "pass_list": [p("S1", "MILANO CADORNA", dep="18:00"), p("S3", "VARESE NORD", arr="18:50", adel=12)]}]}]
        fn = [t for t in self.trips if t["rete"] == "FN" and t["numero"] == "10060"][0]
        rfi = [t for t in self.trips if t["rete"] == "RFI"][0]
        a = ts.pick_journey(root, DAY, [(s[0], ts.norm(s[1])) for s in fn["stops"]])
        b = ts.pick_journey(root, DAY, [(s[0], ts.norm(s[1])) for s in rfi["stops"]])
        self.assertEqual(ts.record_of(a[0], a[1], DAY, "20:00", trip=fn)["ritardo_finale"], 12)
        self.assertEqual(ts.record_of(b[0], b[1], DAY, "20:00", trip=rfi)["ritardo_finale"], 1)

    def test_nessuna_corsa_simile_non_inventa(self):
        root = mia("2727", "S", [p("X1", "ALTROVE", dep="19:00"), p("X2", "LONTANO", arr="19:50", adel=0)])
        self.assertIsNone(ts.pick_journey(root, DAY, [("S1", "milanocadorna"), ("S3", "varesenord")]))


class Sostituzioni(unittest.TestCase):
    def test_2727_soppresso_sostituito_da_4747(self):
        with tempfile.TemporaryDirectory() as out:
            trips = [t for t in ts.gtfs_trips(self._zip(out), DAY, FN_IDS) if t["numero"] == "2727"]
            answers = {
                "2727": mia("2727", "S", [p("S1", "MILANO CADORNA", dep="19:00", canc=True), p("S3", "VARESE NORD", arr="19:50", canc=True)], canc=True),
                "4747": mia("4747", "S", [p("S1", "MILANO CADORNA", dep="19:08", ddel=0), p("S3", "VARESE NORD", arr="19:58", adel=3)]),
            }
            new, pairs, legacy, _ = ts.run(out, DAY, "23:20", trips, lambda n: answers[n], extra_numbers=["4747"], fn_ids=FN_IDS, sleep=lambda s: None, log=lambda *a: None)
            self.assertEqual([(q["soppresso"], q["aggiunto"], q["differenza_minuti"]) for q in pairs], [("2727", "4747", 8)])
            rec = ts.load_records(out, DAY)
            self.assertEqual(rec[(DAY, "2727", "S1", "19:00")]["sostituito_da"], "4747")
            self.assertEqual(rec[(DAY, "4747", "S1", "19:08")]["sostituisce"], "2727")
            self.assertEqual(rec[(DAY, "4747", "S1", "19:08")]["programmato"], "0")
            self.assertEqual(rec[(DAY, "4747", "S1", "19:08")]["rete"], "FN")
            self.assertEqual(sorted(r["soppresso"] for r in legacy), [0, 1])
            with open(os.path.join(out, "trenord", "sostituzioni.csv"), encoding="utf-8") as f:
                self.assertEqual(len(list(csv.DictReader(f, delimiter=";"))), 1)

    def test_aggiunto_lontano_non_si_collega(self):
        c = {"giorno": DAY, "numero": "1", "origine": "A", "destinazione": "B", "partenza": "10:00", "stato": "soppresso", "programmato": "1"}
        a = {"giorno": DAY, "numero": "2", "origine": "A", "destinazione": "B", "partenza": "11:00", "stato": "arrivato", "programmato": "0"}
        self.assertEqual(ts.link_replacements([c, a]), [])

    def test_caso_ambiguo_non_si_collega(self):
        mk = lambda n, h, prog, st: {"giorno": DAY, "numero": n, "origine": "A", "destinazione": "B", "partenza": h, "stato": st, "programmato": prog}
        c = mk("1", "10:00", "1", "soppresso")
        a1, a2 = mk("8", "10:05", "0", "arrivato"), mk("9", "09:55", "0", "arrivato")
        self.assertEqual(ts.link_replacements([c, a1, a2]), [])

    def _zip(self, out):
        z = os.path.join(out, "g.zip"); mk_zip(z); return z


class Salvataggio(unittest.TestCase):
    def rec(self, stato, fin=0, num="1"):
        return {"giorno": DAY, "numero": num, "origine_id": "S1", "partenza": "10:00", "stato": stato, "ritardo_finale": fin, "sostituito_da": "", "sostituisce": ""}

    def test_corsa_conclusa_non_cambia(self):
        old = {ts.rec_key(self.rec("arrivato", 4)): self.rec("arrivato", 4)}
        ts.merge_records(old, {ts.rec_key(self.rec("in_corso", 9)): self.rec("in_corso", 9)})
        self.assertEqual(old[(DAY, "1", "S1", "10:00")]["ritardo_finale"], 4)

    def test_soppresso_di_meta_giornata_resta(self):
        old = {ts.rec_key(self.rec("soppresso")): self.rec("soppresso")}
        ts.merge_records(old, {ts.rec_key(self.rec("senza_dati")): self.rec("senza_dati")})
        self.assertEqual(old[(DAY, "1", "S1", "10:00")]["stato"], "soppresso")

    def test_corsa_in_corso_si_aggiorna(self):
        old = {ts.rec_key(self.rec("in_corso", 2)): self.rec("in_corso", 2)}
        ts.merge_records(old, {ts.rec_key(self.rec("arrivato", 7)): self.rec("arrivato", 7)})
        self.assertEqual(old[(DAY, "1", "S1", "10:00")]["stato"], "arrivato")

    def test_senza_email_nello_user_agent(self):
        self.assertNotIn("@", ts.UA)


if __name__ == "__main__":
    unittest.main()
