import os
"""Legge e modifica i trigger di Knowledge.kt (fonte unica per app e simulatore)."""
import re
KFILE=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','app','src','main','java','com','binario','treni','data','Knowledge.kt')
ENTRY=re.compile(r'Entry\("(\w+)",\s*listOf\((.*?)\),\s*\n\s*"', re.S)
def parse(src=None):
    s=src or open(KFILE).read()
    out=[]
    for m in ENTRY.finditer(s):
        groups=[re.findall(r'"([^"]*)"',g) for g in re.findall(r'listOf\(([^()]*)\)',m.group(2))]
        out.append((m.group(1),groups))
    return out
def add(id_, groups):
    s=open(KFILE).read()
    m=[x for x in ENTRY.finditer(s) if x.group(1)==id_]
    assert m, id_
    m=m[0]
    existing=[re.findall(r'"([^"]*)"',g) for g in re.findall(r'listOf\(([^()]*)\)',m.group(2))]
    extra=[g for g in groups if g not in existing]
    if not extra: return
    ins=', '+', '.join('listOf('+', '.join('"%s"'%w for w in g)+')' for g in extra)
    end=m.end(2)
    s=s[:end]+ins+s[end:]
    open(KFILE,'w').write(s)
if __name__=='__main__':
    for i,g in parse(): print(i,len(g))
