import os
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import langdata as L
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','..','app','src','main','java','com','binario','treni','data','BotLang.kt')
def k(s):  # stringa Kotlin
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('$', '\\$') + '"'
def pairs(name, lst, doc):
    out = ['    /** %s */\n    val %s: List<Pair<String, String>> = listOf(\n' % (doc, name)]
    line = '       '
    for a, b in lst:
        item = ' %s to %s,' % (k(a), k(b))
        if len(line) + len(item) > 150: out.append(line + '\n'); line = '       '
        line += item
    out.append(line + '\n    )\n\n')
    return ''.join(out)
def pats(name, lst):
    out = ['    private val %s: List<Pair<Regex, String>> = listOf(\n' % name]
    for a, b in lst:
        out.append('        Regex(%s) to %s,\n' % (k(a), k(b.replace('\\1', '$1').replace('\\2', '$2'))))
    out.append('    )\n\n')
    return ''.join(out)
kw = set()
for _, v in L.JA + L.ZH: kw.update(v.split())
kw.update(['from', 'to', 'at'])
src = []
src.append('''package com.binario.treni.data

import java.text.Normalizer

/**
 * Dizionari per capire le domande all'assistente in tedesco, francese, spagnolo, giapponese e cinese:
 * parole e frasi vengono trasformate nelle parole inglesi che le regole e la base di conoscenza riconoscono.
 * GENERATO dal simulatore di prova (langdata.py): modificare lì e rigenerare, così app e test restano uguali.
 */
object BotLang {
''')
src.append(pairs('DE', L.DE, 'Tedesco → inglese (parole intere).'))
src.append(pairs('FR', L.FR, 'Francese → inglese (parole intere).'))
src.append(pairs('ES', L.ES, 'Spagnolo → inglese (parole intere).'))
src.append(pairs('JA', L.JA, 'Giapponese → inglese (sottostringhe).'))
src.append(pairs('ZH', L.ZH, 'Cinese → inglese (sottostringhe).'))
src.append(pats('JA_PAT', L.JA_PAT))
src.append(pats('ZH_PAT', L.ZH_PAT))
src.append('    private val STRIP = Regex(%s)\n' % k(L.CJK_STRIP.replace('\u3000','\\u3000').replace('\u303f','\\u303F').replace('\u3040','\\u3040').replace('\u30ff','\\u30FF').replace('\u3400','\\u3400').replace('\u4dbf','\\u4DBF').replace('\u4e00','\\u4E00').replace('\u9fff','\\u9FFF').replace('\uf900','\\uF900').replace('\ufaff','\\uFAFF').replace('\uff01','\\uFF01').replace('\uff65','\\uFF65')).replace('\\\\u','\\u'))
src.append('''
    /** Parole inglesi prodotte dai dizionari CJK: servono a riconoscere dove finisce il nome della stazione. */
    private val KEYWORDS: Set<String> = setOf(
''')
kl = sorted(kw); line = '       '
for x in kl:
    item = ' %s,' % k(x)
    if len(line) + len(item) > 150: src.append(line + '\\n'.replace('\\n', '\n')); line = '       '
    line += item
src.append(line + '\n    )\n\n')
src.append('''    private val jaSorted by lazy { JA.sortedByDescending { it.first.length } }
    private val zhSorted by lazy { ZH.sortedByDescending { it.first.length } }

    /**
     * Giapponese e cinese: schemi di frase ("VareseからMilano" → "from varese to milano"), parole, poi si tolgono gli ideogrammi
     * rimasti. "Saronno toilets" diventa "toilets at saronno", come le domande in italiano e inglese.
     */
    fun cjk(text: String, ja: Boolean): String {
        var t = Normalizer.normalize(text, Normalizer.Form.NFKC).lowercase()
        for ((re, rep) in if (ja) JA_PAT else ZH_PAT) t = re.replace(t, rep)
        for ((a, b) in if (ja) jaSorted else zhSorted) t = t.replace(a, " $b ")
        t = STRIP.replace(t, " ").replace(Regex("\\\\s+"), " ").trim()
        val tok = if (t.isEmpty()) emptyList() else t.split(" ")
        val i = tok.indexOfFirst { it in KEYWORDS }
        if (i > 0 && tok[0] !in KEYWORDS && tok[0].none { it.isDigit() }) t = (tok.drop(i) + "at" + tok.take(i)).joinToString(" ")
        return t
    }
}
''')
open(OUT, 'w', encoding='utf-8').write(''.join(src))
print('written', OUT)
