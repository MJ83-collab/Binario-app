# Test del Capotreno

Simulatore Python della logica di `data/Bot.kt` + `data/Knowledge.kt` + `data/BotLang.kt`.
Non serve compilare l'app.

- `python3 sim.py`               → 400 domande per lingua (domande/q_*.txt), 7 lingue
- `python3 sim.py --set=h`       → esempi del testo di aiuto (h), b, c, d = set di verifica mai visti durante lo sviluppo
- `python3 sim.py it en`         → solo alcune lingue
- `langdata.py`  dizionari stranieri → inglese (fonte unica)
- `genkt.py`     rigenera data/BotLang.kt da langdata.py
- `ktrig.py`     legge/modifica i trigger di Knowledge.kt

Formato domande: `risposta_attesa<TAB>domanda`.
Se si cambia Bot.kt bisogna allineare a mano `answer()` in sim.py.
