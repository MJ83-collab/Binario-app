# -*- coding: utf-8 -*-
"""Simulatore dell'assistente di Binario (Bot.answer + Knowledge + BotLang) per verificare il riconoscimento delle domande.
Riproduce la logica Kotlin: stesse regole, stesso ordine. Le parole chiave della base di conoscenza sono lette da Knowledge.kt."""
import re, sys, unicodedata, collections, os
sys.path.insert(0, os.path.dirname(__file__))
import langdata as L
from ktrig import parse

ENTRIES = parse()  # [(id, groups)]

STATIONS = ["VARESE", "VARESE NORD", "MILANO CENTRALE", "MILANO CADORNA", "MILANO PORTA GARIBALDI", "MILANO LAMBRATE", "MILANO BOVISA",
            "MILANO ROGOREDO", "COMO SAN GIOVANNI", "COMO LAGO", "COMO NORD BORGHI", "SARONNO", "LUGANO", "GALLARATE", "MALPENSA AEROPORTO T1",
            "MALPENSA AEROPORTO T2", "BERGAMO", "BRESCIA", "LECCO", "INDUNO OLONA", "MONZA", "TREVIGLIO", "CHIASSO", "BELLINZONA", "ROMA TERMINI",
            "NAPOLI CENTRALE", "TORINO PORTA NUOVA", "VENEZIA SANTA LUCIA", "BOLOGNA CENTRALE", "FIRENZE SANTA MARIA NOVELLA", "LAVENO MOMBELLO",
            "LUINO", "NOVARA", "PAVIA", "RHO FIERA MILANO", "BUSTO ARSIZIO", "LOCARNO", "MENDRISIO", "SESTO SAN GIOVANNI"]

def deacc(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')

def normalize(s):
    s = unicodedata.normalize('NFD', s.lower())
    s = re.sub(r'[̀-ͯ]+', '', ''.join(c for c in s if unicodedata.category(c) != 'Mn'))
    s = re.sub(r'[^a-z0-9 ]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()

def lev(a, b):
    d = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        prev = d[0]; d[0] = i
        for j in range(1, len(b) + 1):
            tmp = d[j]
            d[j] = min(d[j] + 1, d[j - 1] + 1, prev + (0 if a[i - 1] == b[j - 1] else 1))
            prev = tmp
    return d[len(b)]

def has_stem(words, stem):
    if stem.startswith('='): return stem[1:] in words
    return any(w.startswith(stem) or (len(stem) >= 6 and len(w) >= len(stem) - 1 and lev(w[:len(stem)], stem) <= 1) for w in words)

def score(groups, words):
    best = 0
    for g in groups:
        if all(has_stem(words, s) for s in g):
            v = sum(len(s) + 1 if s.startswith('=') else len(s) for s in g) + (len(g) - 1) * 3
            best = max(best, v)
    return best

def kfind(q, minscore=4):
    words = [w for w in normalize(q).split(' ') if w]
    best = None; bs = -1
    for id_, g in ENTRIES:
        sc = score(g, words)
        if sc >= minscore and sc > bs: best, bs = id_, sc
    return best, max(bs, 0)

def w(x):  # parola intera (lettere/cifre Unicode)
    return re.compile(r'(?<![^\W_])' + re.escape(x) + r'(?![^\W_])')

def latin_map(pairs):
    return [(w(a), b) for a, b in sorted(pairs, key=lambda p: -len(p[0]))]

DEMAP, FRMAP, ESMAP = latin_map(L.DE), latin_map(L.FR), latin_map(L.ES)
JAMAP = sorted(L.JA, key=lambda p: -len(p[0])); ZHMAP = sorted(L.ZH, key=lambda p: -len(p[0]))
JAPAT = [(re.compile(a), b) for a, b in L.JA_PAT]; ZHPAT = [(re.compile(a), b) for a, b in L.ZH_PAT]
STRIP = re.compile(L.CJK_STRIP)
KEYWORDS = set()
for _, v in L.JA + L.ZH: KEYWORDS.update(v.split())
KEYWORDS.update(['from', 'to', 'at'])

def cjk(text, ja):
    t = unicodedata.normalize('NFKC', text).lower()
    for r, rep in (JAPAT if ja else ZHPAT): t = r.sub(rep, t)
    for a, b in (JAMAP if ja else ZHMAP): t = t.replace(a, ' ' + b + ' ')
    t = STRIP.sub(' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    tok = t.split(' ') if t else []
    i = next((k for k, x in enumerate(tok) if x in KEYWORDS), -1)
    if i > 0 and tok[0] not in KEYWORDS and not any(c.isdigit() for c in tok[0]):
        t = ' '.join(tok[i:] + ['at'] + tok[:i])
    return t

def foreign(question, lang):
    t = question.lower()
    if lang == 'de':
        for r, e in DEMAP: t = r.sub(e, t)
    elif lang == 'fr':
        # prima le frasi ("bus de remplacement", "à bord"), poi le preposizioni rimaste
        for r, e in FRMAP: t = r.sub(e, t)
        a = w('à')
        if re.search(r'(?<![^\W\d_])de(?![^\W\d_]).*(?<![^\W\d_])à(?![^\W\d_])', t): t = a.sub('to', w('de').sub('from', t))
        else: t = a.sub('at', t)
        t = w('de').sub('from', t)
    elif lang == 'es':
        for r, e in ESMAP: t = r.sub(e, t)
        if re.search(r'(?<![^\W\d_])de(?![^\W\d_]).*(?<![^\W\d_])a(?![^\W\d_])', t):
            t = w('de').sub('from', t); t = w('a').sub('to', t)
    elif lang in ('ja', 'zh'):
        t = cjk(t, lang == 'ja')
    return t

FILLER = re.compile(r'\b(per favore|grazie|please|thanks|mi sai dire|sai dirmi|vorrei sapere|dimmi|ciao|buongiorno|buonasera|scusa)\b')

def has(q, *ws): return any(x in q for x in ws)
def has_word(q, *ws): return any(re.search(r'\b' + re.escape(x) + r'\b', q) for x in ws)

def search1(clean):
    up = deacc(clean).upper()
    l = [s for s in STATIONS if s.startswith(up)]
    ex = [s for s in l if s == up]
    return (ex or l or [None])[0]

def station(text, lead=False):
    clean = text.strip().strip('?.!,').strip()
    if len(clean) < 2: return None
    r = search1(clean)
    if r: return r
    # "milano cadorna funziona", "lecco station": si tolgono fino a 3 parole in fondo, poi fino a 2 all'inizio
    words = clean.split(' ')
    for k in range(1, min(3, len(words) - 1) + 1):
        c = ' '.join(words[:-k])
        if len(c) >= 3:
            r = search1(c)
            if r: return r
    for k in range(1, (min(2, len(words) - 1) if lead else 0) + 1):
        c = ' '.join(words[k:])
        if len(c) >= 3:
            r = search1(c)
            if r: return r
    return None

def station_after(q, *keys):
    k = '|'.join(keys)
    m = re.search(r'.*\b(?:' + k + r')\b\s*(?:(?:alla|nella|della|vicino alla|vicino a|presso|in the|in|ad|a|di|da|de|near|at|to|from|of)\s+)?(?:stazione\s+(?:di\s+)?|station\s+)?(.+)$', q)
    if not m: return None
    raw = re.sub(r'\?|\.', '', m.group(1)).strip()
    # il testo dopo l'ULTIMA preposizione ("services from la station from induno olona" → "induno olona")
    tail = re.search(r'.*(?:^|\s)(?:a|ad|di|da|de|in|alla|della|nella|near|at|from|of)\s+(.+)$', raw)
    st = station(tail.group(1), True) if tail else None
    return st or station(raw, True)

TRANSPORT = ["autobus", "bus", "buses", "taxis", "trams", "pullman", "metropolitana", "metro", "tram", "taxi", "mezzi", "coincidenze con", "bike sharing",
             "bici in condivisione", "public transport", "trasporti pubblici", "mezzi pubblici"]
WC = ["wc", "bagno", "bagni", "toilette", "toilet", "toilets", "servizi igienici", "gabinetto", "restroom"]
SVC = ["biglietteria", "biglietterie", "emettitrice", "emettitrici", "obliteratrice", "obliteratrici", "servizi", "ticket office", "ticket offices", "services",
       "quanti binari", "binari ha", "how many platforms"]
NUM_SKIP = {"112", "118", "144", "911", "782"}
EARLY_EXCLUDE = {"malpensa", "svizzera"}
MYTRAIN_BEATS = {"binario_spiegazione", "puntualita", "app_sveglia"}

def answer(question, lang):
    raw = question if lang in ('it', 'en') else foreign(question, lang)
    q = FILLER.sub(' ', raw.lower())
    q = re.sub(r'\s+', ' ', q).strip().strip('?!.')
    n = normalize(q)
    # Numero del treno (non "Regolamento 2021/782", non 112)
    num = None
    if not has(n, "regolament", "regulation", "verordnung", "reglement", "reglamento"):
        for m in re.finditer(r'\b(\d{3,5})\b', q):
            if m.group(1) not in NUM_SKIP: num = m.group(1); break
    if num is not None and not re.search(r'(?:da|from)\s+.+?\s+(?:a|ad|to|per|fino a)\s+', q): return 'train'
    k, ks = kfind(q)
    strong = k is not None and ks >= 7
    if strong and k in MYTRAIN_BEATS and has(n, "mio treno", "my train"): return 'mytrain'
    if strong and k not in EARLY_EXCLUDE:
        # "obliteratrice a Como", "WC a Saronno": con una stazione nominata vince la domanda sulla stazione
        if k != 'bus_sostitutivi':
            if has_word(n, *SVC) and station_after(q, *SVC): return 'services'
            if has_word(n, *WC) and station_after(q, *WC): return 'wc'
            if has_word(n, *TRANSPORT) and station_after(q, *TRANSPORT): return 'transport'
        return k
    if not q or has(n, "aiut", "help", "cosa sai", "cosa puoi", "what can") or (has(n, "come funzion", "how does", "how do") and has(n, "assist")):
        return 'help'
    if has(n, "mio treno", "my train", "treno seguito", "followed train"): return 'mytrain'
    if has_word(n, *TRANSPORT): return 'transport'
    if has_word(n, *WC): return 'wc'
    if has_word(n, *SVC) and not has(n, "rimbors"):
        if station_after(q, *SVC): return 'services'
    m = re.search(r'(?:da|from)\s+(.+?)\s+(?:a|ad|to|per|fino a)\s+(.+)', q)
    if m and station(m.group(1)) and station(m.group(2)): return 'route'
    m = re.search(r'(?:prossimo treno|prossimi treni|primo treno|ultimo treno|next train|next trains|treni|treno|train|trains)\s+(?:per|a|verso|to|for)\s+(.+)', q)
    if m and not has(q, " da ", " from ") and station(m.group(1)): return 'nexttrain'
    m = re.search(r'(?:partenze|departures|departure board|parte|leaving|tabellone)\s+(?:(?:da|from|di|at|in|a)\s+)?(.+)', q)
    if m and station(m.group(1)): return 'departures'
    m = re.search(r'(?:arrivi|arrivals|arriva)\s+(?:(?:a|at|in|di|to)\s+)?(.+)', q)
    if m and station(m.group(1)): return 'arrivals'
    if has(n, "ascensor", "elevator", "lift", "scale mobili", "escalator"):
        if station_after(q, "ascensori", "ascensore", "elevators", "elevator", "lift", "lifts", "scale mobili", "escalators", "escalator"): return 'elevators'
    if strong: return k
    if has(n, "garantit", "guaranteed", "fasce"): return 'guaranteed'
    if has(n, "sciopero", "scioperi", "strike"): return 'strike'
    if k is not None: return k
    if has(n, "circolazione", "traffico", "traffic", "problem", "ritardi", "delays", "interrott", "sospes", "guasto", "disruption", "linea", "line", "lavori", "works", "blocked", "bloccat", "succede", "going on"):
        return 'traffic'
    if has(n, "ritardo", "delay", "binario", "platform", "dove e il treno", "where is", "che ora", "what time", "wie viel uhr", "quelle heure", "que hora") or has_word(n, "late", "delayed"): return 'asknum'
    if station(q): return 'departures'
    return 'unknown'

def run(langs=None, show=40, detail=None, prefix='q'):
    langs = langs or ['it', 'en', 'de', 'fr', 'es', 'zh', 'ja']
    tot = ok = 0; res = {}
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'domande')
    for lg in langs:
        rows = [l.split('\t') for l in open(os.path.join(base, '%s_%s.txt' % (prefix, lg)), encoding='utf-8').read().split('\n') if l.strip()]
        bad = []
        for exp, qq in rows:
            got = answer(qq, lg)
            if got != exp: bad.append((exp, got, qq))
        res[lg] = (len(rows) - len(bad), len(rows), bad)
        tot += len(rows); ok += len(rows) - len(bad)
    for lg in langs:
        g, n, bad = res[lg]
        print('%s: %d/%d = %.1f%%' % (lg, g, n, 100.0 * g / n))
    print('TOTAL: %d/%d = %.1f%%' % (ok, tot, 100.0 * ok / tot))
    if detail:
        for lg in langs:
            for exp, got, qq in res[lg][2][:show]:
                print('  [%s] expected %-20s got %-20s | %s' % (lg, exp, got, qq))
    return res

if __name__ == '__main__':
    args = sys.argv[1:]
    prefix = 'q'
    if args and args[0].startswith('--set='):
        prefix = args.pop(0)[6:]
    run(args or None, detail=True, prefix=prefix)
