package com.binario.treni

import com.binario.treni.data.ItaloLive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ItaloLiveTest {
    @Test fun stationCodes() {
        assertEquals("MC_", ItaloLive.codeFor("MILANO CENTRALE"))
        assertEquals("SMN", ItaloLive.codeFor("FIRENZE S.M.N."))
        assertEquals("BC_", ItaloLive.codeFor("BOLOGNA C.LE"))
        assertEquals("AAV", ItaloLive.codeFor("REGGIO EMILIA AV MEDIOPADANA"))
        assertEquals("OUE", ItaloLive.codeFor("TORINO PORTA SUSA"))
        assertEquals("TOP", ItaloLive.codeFor("TORINO P.NUOVA"))
        assertEquals("VSL", ItaloLive.codeFor("VENEZIA S.LUCIA"))
        assertEquals("RRO", ItaloLive.codeFor("RHO FIERA MILANO"))
        assertEquals("RMT", ItaloLive.codeFor("ROMA TERMINI"))
        assertNull(ItaloLive.codeFor("REGGIO EMILIA"))
        assertNull(ItaloLive.codeFor("VARESE"))
        assertNull(ItaloLive.codeFor("MILANO PORTA GARIBALDI"))
    }

    @Test fun italoNumbers() {
        assertTrue(ItaloLive.looksItalo("9920"))
        assertTrue(ItaloLive.looksItalo("ITA 8983"))
        assertFalse(ItaloLive.looksItalo("2070"))
        assertFalse(ItaloLive.looksItalo("25592"))
    }
}

class CrossBorderTest {
    private fun st(n: String) = com.binario.treni.data.Station(n, "S01234")

    @Test fun swissStations() {
        val cb = com.binario.treni.data.CrossBorderFares
        assertTrue(cb.isSwissStation(st("LUGANO")))
        assertTrue(cb.isSwissStation(st("Mendrisio")))
        assertTrue(cb.isSwissStation(com.binario.treni.data.Station("Bellinzona", "CH8505213")))
        assertFalse(cb.isSwissStation(st("VARESE")))
        assertFalse(cb.isSwissStation(st("BODIO LOMNAGO")))
        assertFalse(cb.isSwissStation(st("CASTIONE ANDEVENNO")))
        assertFalse(cb.isSwissStation(st("BERNATE TICINO")))
    }

    @Test fun verifiedEuro() {
        val cb = com.binario.treni.data.CrossBorderFares
        assertEquals(12.50, cb.findEur("VARESE", "LUGANO")!!.second, 0.001)
        assertEquals(21.00, cb.findEur("Lugano", "Varese")!!.first, 0.001)
        assertNull(cb.findEur("VARESE NORD", "LUGANO"))
        assertNull(cb.findEur("COMO SAN GIOVANNI", "LUGANO"))
    }
}
