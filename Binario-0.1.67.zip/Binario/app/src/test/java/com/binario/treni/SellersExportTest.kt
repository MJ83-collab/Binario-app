package com.binario.treni

import com.binario.treni.data.TicketSellers
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

/**
 * Prepara l'elenco completo delle rivendite e biglietterie Trenord per l'app (sellers.json).
 * Gira solo nel lavoro settimanale su GitHub (variabile BINARIO_EXPORT con il percorso del file da scrivere):
 * così l'app scarica un solo file invece di leggere decine di pagine del sito Trenord dal telefono.
 */
class SellersExportTest {
    @Test
    fun exportTrenordSellers() {
        val path = System.getenv("BINARIO_EXPORT")
        assumeTrue(!path.isNullOrBlank())
        val items = TicketSellers.downloadTrenord { println(it) }
        val offices = items.count { it.kind.name == "TICKET_OFFICE" }
        val machines = items.count { it.kind.name == "TICKET_MACHINE" }
        println("Punti vendita: ${items.size} (biglietterie: $offices, stazioni con emettitrici: $machines)")
        // Se il sito è cambiato o non risponde non pubblichiamo un elenco vuoto o a metà
        // Ottobre 2026: circa 280 rivendite e 50 biglietterie, più le stazioni con emettitrici. Sotto 150 o senza biglietterie qualcosa non va.
        assertTrue("Troppi pochi punti vendita: ${items.size}", items.size >= 150)
        assertTrue("Troppe poche biglietterie: $offices", offices >= 20)
        val a = JSONArray()
        items.forEach { a.put(it.toJson()) }
        File(path!!).writeText(JSONObject().put("at", System.currentTimeMillis()).put("source", TicketSellers.TRENORD_SITE).put("items", a).toString())
    }
}
