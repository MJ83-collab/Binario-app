package com.binario.treni

import com.binario.treni.data.MyRoute
import com.binario.treni.data.RouteNews
import com.binario.treni.data.Station
import com.binario.treni.data.Strike
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class RouteNewsTest {
    private val rome = TimeZone.getTimeZone("Europe/Rome")
    private fun at(d: Int, m: Int, h: Int, min: Int = 0) = Calendar.getInstance(rome).apply {
        clear(); set(2026, m - 1, d, h, min)
    }.timeInMillis

    private fun strike(start: String, end: String, modality: String, company: String, relevance: String, region: String) =
        Strike(start, end, "OSR", "Ferroviario", company, modality, relevance, region, "Tutte", "")

    private val route = MyRoute(Station("VARESE", "S01700"), Station("MILANO CENTRALE", "S01700"), "07:12", "18:40",
        setOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY), setOf("Trenord"), setOf("Lombardia"))

    @Test fun windowWithDates() {
        val s = strike("28/10/2026", "29/10/2026", "24 ORE: DALLE 21.00 DEL 28/10 ALLE 21.00 DEL 29/10", "TRENITALIA", "Regionale", "Emilia-Romagna")
        assertEquals(at(28, 10, 21) to at(29, 10, 21), RouteNews.window(s))
    }

    @Test fun windowSameDay() {
        val s = strike("30/10/2026", "30/10/2026", "DALLE 9.00 ALLE 17.00", "TRENORD", "Regionale", "Lombardia")
        assertEquals(at(30, 10, 9) to at(30, 10, 17), RouteNews.window(s))
    }

    @Test fun wholeDay() {
        val s = strike("30/10/2026", "30/10/2026", "INTERA GIORNATA", "", "Nazionale", "")
        assertEquals(at(30, 10, 0) to at(31, 10, 0), RouteNews.window(s))
    }

    @Test fun routeMatching() {
        // Venerdì 30/10: sciopero Trenord 9–17 in Lombardia non tocca andata 7:12 né ritorno 18:40
        val day = strike("30/10/2026", "30/10/2026", "DALLE 9.00 ALLE 17.00", "TRENORD", "Regionale", "Lombardia")
        assertFalse(RouteNews.affectsRoute(day, route))
        // 21:00 del 28 → 21:00 del 29 (giovedì) in Lombardia, Trenord: tocca andata e ritorno del 29
        val night = strike("28/10/2026", "29/10/2026", "DALLE 21.00 DEL 28/10 ALLE 21.00 DEL 29/10", "PERSONALE TRENORD", "Regionale", "Lombardia")
        val trips = RouteNews.affectedTrips(night, route)
        assertEquals(2, trips.size)
        assertTrue(trips.all { it.guaranteed.not() || it.outbound || !it.outbound })
        assertTrue(RouteNews.affectsRoute(night, route))
        // Stesso orario ma in Emilia-Romagna e solo Trenitalia: non riguarda la tratta
        val emilia = strike("28/10/2026", "29/10/2026", "DALLE 21.00 DEL 28/10 ALLE 21.00 DEL 29/10", "TRENITALIA", "Regionale", "Emilia-Romagna")
        assertFalse(RouteNews.affectsRoute(emilia, route))
        // Nazionale RFI: riguarda tutti
        val rfi = strike("29/10/2026", "29/10/2026", "INTERA GIORNATA", "PERSONALE RFI", "Nazionale", "")
        assertTrue(RouteNews.affectsRoute(rfi, route))
    }

    @Test fun guaranteedBands() {
        assertTrue(RouteNews.guaranteedSlot(at(29, 10, 7, 12)))
        assertFalse(RouteNews.guaranteedSlot(at(29, 10, 12, 0)))
        assertFalse(RouteNews.guaranteedSlot(at(31, 10, 7, 12))) // sabato
    }
}
