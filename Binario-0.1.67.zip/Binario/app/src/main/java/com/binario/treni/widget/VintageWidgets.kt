package com.binario.treni.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.widget.RemoteViews
import com.binario.treni.MainActivity
import com.binario.treni.R
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.Store

/** Widget «tabellone a palette»: stesse informazioni dei widget classici, disegnate come il vecchio tabellone Solari. */
abstract class VintageWidget : AppWidgetProvider() {
    abstract val type: WidgetType

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        VintageRender.renderAll(ctx, ids, type, fetch = true) { pending.finish() }
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle?) {
        // Ridisegna con le nuove dimensioni usando gli ultimi dati, senza rete
        VintageRender.renderAll(ctx, intArrayOf(id), type, fetch = false) {}
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == Widgets.ACTION_REFRESH) {
            val ids = AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, javaClass))
            try {
                android.widget.Toast.makeText(ctx, I18n.tr("Aggiorno il tabellone…", "Refreshing the board…"), android.widget.Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
            }
            val pending = goAsync()
            VintageRender.renderAll(ctx, ids, type, fetch = true) { pending.finish() }
        }
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        val s = Store(ctx)
        ids.forEach { s.removeWidgetConfig(it); WidgetCache.clear(ctx, it) }
    }
}

class VintageStationWidget : VintageWidget() { override val type = WidgetType.STATION }
class VintageRouteWidget : VintageWidget() { override val type = WidgetType.ROUTE }
class VintageTrainWidget : VintageWidget() { override val type = WidgetType.TRAIN }
class VintageFavoritesWidget : VintageWidget() { override val type = WidgetType.FAV }

object VintageRender {
    private const val BOARD = 0xFF0B0B0C.toInt()
    private const val FRAME = 0xFF4A3A22.toInt()
    private const val FLAP_TOP = 0xFF242427.toInt()
    private const val FLAP_BOTTOM = 0xFF18181A.toInt()
    private const val SPLIT = 0xFF050505.toInt()
    private const val WHITE = 0xFFF2EFE6.toInt()
    private const val AMBER = 0xFFF5C84C.toInt()
    private const val LATE = 0xFFFF7043.toInt()
    private const val DIM = 0xFF8C887C.toInt()

    /** Carica i dati (se richiesto) e aggiorna i widget indicati, fuori dal thread principale. */
    fun renderAll(ctx: Context, ids: IntArray, type: WidgetType, fetch: Boolean, done: () -> Unit) {
        val app = ctx.applicationContext
        Thread {
            try {
                ids.forEach { id ->
                    try { render(app, id, type, fetch) } catch (_: Exception) { }
                }
            } finally {
                done()
            }
        }.start()
    }

    private fun render(ctx: Context, id: Int, type: WidgetType, fetch: Boolean) {
        var rows: List<WRow>? = null
        var at = 0L
        var offline = false
        if (fetch) {
            for (attempt in 0 until 2) {
                rows = try { WidgetService.Factory(ctx, id, type).loadRows() } catch (e: Exception) { null }
                if (rows != null) break
                try { Thread.sleep(1500L) } catch (_: InterruptedException) { break }
            }
            if (rows != null) {
                if (rows.any { it.time.isNotBlank() }) WidgetCache.save(ctx, id, rows)
                at = System.currentTimeMillis()
            }
        }
        if (rows == null) {
            val (cached, cachedAt) = WidgetCache.load(ctx, id)
            rows = cached; at = cachedAt; offline = fetch
        }
        val mgr = AppWidgetManager.getInstance(ctx)
        val cfg = Store(ctx).widgetConfig(id)
        val title = if (type == WidgetType.FAV) tx("Preferiti") else cfg?.title?.ifBlank { null } ?: I18n.tr("Tocca per configurare", "Tap to set up")
        val opts = mgr.getAppWidgetOptions(id)
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250).coerceAtLeast(120)
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 140).coerceAtLeast(80)
        val bmp = draw(ctx, wDp, hDp, title.uppercase(), if (at > 0) (if (offline) "!" else "") + Fmt.time(at) else "", rows ?: emptyList(), type, cfg == null && type != WidgetType.FAV)

        val rv = RemoteViews(ctx.packageName, R.layout.widget_vintage)
        rv.setImageViewBitmap(R.id.v_board, bmp)
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val cls = Widgets.vintageClassOf(type)
        rv.setOnClickPendingIntent(R.id.v_ref, PendingIntent.getBroadcast(ctx, cls.name.hashCode(), Intent(ctx, cls).setAction(Widgets.ACTION_REFRESH), flags))
        val conf = Intent(ctx, WidgetConfigActivity::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).setAction("reconfigure_$id")
        rv.setOnClickPendingIntent(R.id.v_cfg, PendingIntent.getActivity(ctx, 7000 + id, if (type == WidgetType.FAV) Intent(ctx, MainActivity::class.java) else conf, flags))
        val open = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (type == WidgetType.STATION && cfg?.station != null) open.putExtra(MainActivity.EXTRA_STATION, cfg.station.toJson().toString())
        rv.setOnClickPendingIntent(R.id.v_board, PendingIntent.getActivity(ctx, 9000 + id, open, flags))
        mgr.updateAppWidget(id, rv)
    }

    private fun tx(s: String) = com.binario.treni.data.tx(s)

    private fun cleanDest(r: WRow, type: WidgetType): String {
        var m = r.main
        if (type == WidgetType.ROUTE) m = m.replace(Regex("^→\\s*\\d{1,2}:\\d{2}\\s*"), "")
        return m
    }

    private fun delayCol(r: WRow, type: WidgetType): String = when (type) {
        WidgetType.TRAIN -> if (r.delay.isBlank()) "" else if (r.delayRed) "RIT" else "OK"
        else -> r.delay.replace("'", "")
    }

    private fun platCol(r: WRow): String = r.platform.substringAfter("→").trim().take(2)

    private fun draw(ctx: Context, wDp: Int, hDp: Int, title: String, stamp: String, rows: List<WRow>, type: WidgetType, needsSetup: Boolean): Bitmap {
        val density = ctx.resources.displayMetrics.density
        var w = wDp * density
        var h = hDp * density
        // La bitmap viaggia dentro RemoteViews: teniamola entro ~3 MB
        val maxPx = 750_000f
        val k = if (w * h > maxPx) Math.sqrt((maxPx / (w * h)).toDouble()).toFloat() else 1f
        w *= k; h *= k
        val bmp = Bitmap.createBitmap(w.toInt(), h.toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val unit = density * k // px per dp

        // Cornice e fondo
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = FRAME
        c.drawRoundRect(RectF(0f, 0f, w, h), 10 * unit, 10 * unit, p)
        p.color = BOARD
        c.drawRoundRect(RectF(3 * unit, 3 * unit, w - 3 * unit, h - 3 * unit), 8 * unit, 8 * unit, p)

        // Griglia di palette
        val m = 8 * unit
        val cellsTotal = ((wDp - 16) / 15.5f)
        val dest = (cellsTotal - 5 - 4 - 2 - 1.5f).toInt().coerceIn(5, 22)
        val cw = (w - 2 * m) / (5 + dest + 4 + 2 + 1.5f)
        val gap = cw * 0.5f
        // Poche righe, ma grandi e leggibili: al massimo 8; se c'è altezza avanzata le righe si allungano
        var ch = cw * 1.7f
        var titleH = ch * 0.62f
        var labelH = ch * 0.42f
        val fit = ((h - 2 * m - titleH - labelH) / (ch * 1.1f)).toInt().coerceAtLeast(1)
        val maxRows = minOf(fit, 7)
        val rowH = minOf((h - 2 * m - titleH - labelH) / maxRows, cw * 2.6f)
        ch = minOf(rowH / 1.1f, cw * 2.2f)

        // Titolo e ora dei dati
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); color = AMBER; textSize = ch * 0.42f }
        // Pulsante di aggiornamento ben visibile (freccia circolare in un riquadro) a destra del titolo
        val bs = titleH * 0.95f
        val bx = w - m - bs
        val by = m * 0.6f
        val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = AMBER; strokeWidth = bs * 0.07f }
        c.drawRoundRect(RectF(bx, by, bx + bs, by + bs), bs * 0.2f, bs * 0.2f, bp)
        bp.strokeWidth = bs * 0.09f
        bp.strokeCap = Paint.Cap.ROUND
        val ar = RectF(bx + bs * 0.27f, by + bs * 0.27f, bx + bs * 0.73f, by + bs * 0.73f)
        c.drawArc(ar, -60f, 290f, false, bp)
        // punta della freccia all'inizio dell'arco
        val cx = ar.centerX(); val cy = ar.centerY(); val rr = ar.width() / 2f
        val ex = cx + rr * Math.cos(Math.toRadians(-60.0)).toFloat()
        val ey = cy + rr * Math.sin(Math.toRadians(-60.0)).toFloat()
        val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = AMBER }
        val head = Path().apply { moveTo(ex + bs * 0.16f, ey - bs * 0.02f); lineTo(ex - bs * 0.06f, ey - bs * 0.13f); lineTo(ex - bs * 0.02f, ey + bs * 0.11f); close() }
        c.drawPath(head, hp)
        val titleW = w - 2 * m - bs - tp.measureText(stamp) - 12 * unit
        var t = title
        while (t.length > 3 && tp.measureText(t) > titleW) t = t.dropLast(1)
        c.drawText(t, m, m + titleH * 0.75f, tp)
        tp.color = DIM
        tp.textAlign = Paint.Align.RIGHT
        c.drawText(stamp, bx - 6 * unit, m + titleH * 0.75f, tp)

        // Intestazioni di colonna
        val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); color = AMBER; textSize = ch * 0.3f }
        val x1 = m
        val x2 = x1 + 5 * cw + gap
        val x3 = x2 + dest * cw + gap
        val x4 = x3 + 4 * cw + gap
        val ly = m + titleH + labelH * 0.8f
        c.drawText("ORARI", x1, ly, lp)
        c.drawText("DESTINAZIONE", x2, ly, lp)
        c.drawText("RIT", x3, ly, lp)
        c.drawText("BIN", x4, ly, lp)

        val shown = rows.take(maxRows)
        var y = m + titleH + labelH
        if (needsSetup || shown.isEmpty()) {
            val msg = if (needsSetup) I18n.tr("TOCCA IL TITOLO PER SCEGLIERE", "TAP THE TITLE TO CHOOSE") else I18n.tr("NESSUN DATO", "NO DATA")
            drawText(c, msg, 0, dest + 11, x1, y, cw, ch, AMBER, false)
            return bmp
        }
        for (r in shown) {
            if (r.time.isBlank()) {
                // Riga informativa (messaggio o stato): una sola scritta a tutta larghezza
                drawText(c, (r.main + (if (r.sub.isNotBlank()) " " + r.sub else "")).uppercase(), 0, dest + 10, x1, y, cw, ch, AMBER, false)
            } else {
                drawText(c, r.time.replace(':', '.'), 5, 5, x1, y, cw, ch, WHITE, false)
                drawText(c, cleanDest(r, type).uppercase(), dest, dest, x2, y, cw, ch, AMBER, false)
                drawText(c, delayCol(r, type), 4, 4, x3, y, cw, ch, if (r.delayRed) LATE else DIM, true)
                drawText(c, platCol(r), 2, 2, x4, y, cw, ch, if (r.platformConfirmed) WHITE else DIM, true)
            }
            y += rowH
        }
        return bmp
    }

    /** Una scritta a palette: ogni carattere in una cella con la fessura a metà. */
    private fun drawText(c: Canvas, text: String, len: Int, cells: Int, x: Float, y: Float, cw: Float, ch: Float, color: Int, right: Boolean) {
        val chars = text.take(len.coerceAtLeast(1).let { if (len == 0) cells else len })
        val padded = if (len == 0) chars else if (right) chars.padStart(len) else chars.padEnd(len)
        val cell = Paint(Paint.ANTI_ALIAS_FLAG)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); this.color = color; textSize = ch * 0.62f; textAlign = Paint.Align.CENTER
        }
        val fm = tp.fontMetrics
        val r = cw * 0.12f
        val inner = cw * 0.92f
        padded.forEachIndexed { i, chr ->
            val left = x + i * cw
            val rect = RectF(left, y, left + inner, y + ch)
            cell.color = FLAP_TOP
            c.drawRoundRect(rect, r, r, cell)
            cell.color = FLAP_BOTTOM
            c.drawRect(rect.left, y + ch / 2f, rect.right, rect.bottom - r, cell)
            c.drawRoundRect(RectF(rect.left, y + ch / 2f, rect.right, rect.bottom), r, r, cell)
            c.drawRect(rect.left, y + ch / 2f, rect.right, y + ch / 2f + r, cell)
            if (chr != ' ') c.drawText(chr.toString(), rect.centerX(), y + ch / 2f - (fm.ascent + fm.descent) / 2f, tp)
            cell.color = SPLIT
            c.drawRect(rect.left, y + ch / 2f - 0.8f, rect.right, y + ch / 2f + 0.8f, cell)
        }
    }
}
