package com.binario.treni.ui

// Note legali tradotte (stesso contenuto di LEGAL_TEXT / LEGAL_TEXT_EN).

const val LEGAL_TEXT_ZH = """1. 关于我们
Binario 是由 Marco Jannino 创建的独立免费应用。它与 Trenitalia、RFI、FS 集团、Italo-NTV、Trenord、FerrovieNord/FNM、TILO、SBB 及其他提到的运输公司或机构均无关联，也未获得它们的赞助或认可。

2. 商标
所提及公司的名称和商标归各自所有者所有，仅用于标明信息来源或所指服务。本应用不使用公司的官方标志。

3. 数据与可靠性
时刻表、晚点、站台、取消、票价、罢工、通告、无障碍、客流和统计数据均来自第三方公开来源，按“现状”提供，不保证准确、完整或及时。
始终以官方信息为准：车站显示屏和广播、工作人员、官方网站和应用。

4. 估算
标有“≈”的客流、“你有多环保”的数值（二氧化碳、燃油、过路费、行车时间）、路线比较和跨境参考票价均为估算，仅供参考，不构成价格或行程时间的报价或保证。

5. 车票与购买
本应用不出售车票，也不处理支付。购买按钮会打开各公司的官方网站，其销售和运输条件完全适用。各公司的条件、票价和乘客权利以其官方页面链接的形式收录在“运输条件”中。

6. 责任限制
在法律允许的范围内，作者不对因使用本应用或依赖其信息而产生的任何直接或间接损失负责，包括误车或误接、费用、罚款或不便。通知、提醒和到站闹钟可能收不到（省电模式、无网络、手机设置）：请勿将其作为唯一提醒。
乘客权利（退款、赔偿、协助）须依据欧盟条例 2021/782 及其条件向运输公司主张。

7. 隐私（GDPR）
本应用无需注册，不显示广告，没有统计或跟踪工具，也没有自己的服务器：作者既不接收也不出售个人数据。收藏、设置、提醒和环保记录保存在你的手机上，卸载应用时即被删除。
为了运行，应用会直接访问所列来源：与任何网站一样，它们会按各自的隐私政策收到你的 IP 地址和请求数据（如车站或车次）。
仅在你允许时、且仅在需要位置的页面（附近车站、售票点、服务）使用位置。为查找附近地点，坐标会发送到 OpenStreetMap 服务器（Overpass）；应用不会保存坐标，也不会在后台使用。
应用内发送的反馈经开发者的 Google 表单传递，应用更新来自 GitHub。详情、法律依据和权利：“隐私与权限”。

8. 数据来源（已注明）
所有信息均来自任何人都可免费查阅的公开来源，无需注册、订阅或商业协议。应用不购买数据，不使用付费服务，也不转售任何内容：它只是注明来源，展示公司和公共机构发布的内容。
• 时刻表、晚点、计划与实际站台：ViaggiaTreno – RFI / Trenitalia（viaggiatreno.it）
• 行程方案与票价：LeFrecce – Trenitalia（lefrecce.it）
• 罢工：交通罢工观测站 – 意大利基础设施和交通部（scioperi.mit.gov.it）
• 通告、线路、客流、运输条件：Trenord（trenord.it）
• 设施状态与新闻：FerrovieNord（ferrovienord.it）
• 电梯与车站无障碍、Sala Blu：RFI（rfi.it）
• Trenord 替代巴士时刻：伦巴第大区开放数据，Trenord 官方 GTFS 数据源，CC BY 4.0 许可（dati.lombardia.it）；无法使用时用 Transitous 代替
• 其他公司的区域和地方时刻表及替代巴士：Transitous（transitous.org），汇集各公司发布的 GTFS 数据源
• Italo 列车：italotreno.com
• 德国列车与服务：德国铁路 Deutsche Bahn（bahn.de）
• 跨境列车与服务：TILO（tilo.ch）
• 瑞士时刻表与预计客流：transport.opendata.ch / opentransportdata.swiss（SBB）
• Arcobaleno 票价：提契诺和莫埃萨诺票价联盟（arcobaleno.ch）
• 运输条件、票价和乘客权利：各公司的官方页面（见“运输条件”）
• 乘客权利：欧盟条例 2021/782（eur-lex.europa.eu）
• 准点率统计：TrovaTreno.it – 开放数据，CC BY 4.0 许可
• 燃油价格：意大利企业和意大利制造部开放数据（mimit.gov.it），IODL 2.0 许可
• 地图、售票点、检票机、电梯：© OpenStreetMap 贡献者（openstreetmap.org），ODbL 许可
• 道路路线：基于 OpenStreetMap 数据的 OSRM（project-osrm.org）
• 软件：osmdroid 以及 Android/Jetpack 组件，Apache 2.0 许可

9. 免费与来源的使用
Binario 免费、无广告、无应用内购买，且非营利。来源的查询方式与普通用户在自己手机上访问相同，请求有限，由用户操作触发或间隔适度；内容仍归其所有者所有。官方页面在内置阅读器中原样显示，或打开原网站。
如果公司或数据所有者要求更改或停止显示某些内容，相关功能将被移除。

10. 联系方式
如需反馈、要求删除或更正：请联系作者 Marco Jannino。
如对铁路服务有投诉，请联系相关运输公司。

11. 变更
这些说明可能随应用新版本更新。使用中的版本显示在顶部。最后更新：2026 年 11 月。"""

const val LEGAL_TEXT_DE = """1. Wer wir sind
Binario ist eine unabhängige, kostenlose App von Marco Jannino. Sie ist nicht mit Trenitalia, RFI, Gruppo FS, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB oder anderen genannten Verkehrsunternehmen oder Stellen verbunden und wird von ihnen weder gesponsert noch gebilligt.

2. Marken
Namen und Marken der genannten Unternehmen gehören ihren jeweiligen Inhabern und dienen nur dazu, die Quelle der Information oder den betreffenden Dienst zu benennen. Die App verwendet keine offiziellen Firmenlogos.

3. Daten und Zuverlässigkeit
Fahrpläne, Verspätungen, Gleise, Ausfälle, Preise, Streiks, Meldungen, Barrierefreiheit, Auslastung und Statistiken stammen aus öffentlichen Quellen Dritter und werden „wie besehen“ ohne Gewähr für Richtigkeit, Vollständigkeit oder Aktualität bereitgestellt.
Maßgeblich sind stets die offiziellen Informationen: Anzeigetafeln und Durchsagen im Bahnhof, Personal, offizielle Websites und Apps.

4. Schätzungen
Mit „≈“ gekennzeichnete Auslastung, die Werte von „Wie grün bist du“ (CO₂, Kraftstoff, Maut, Fahrzeiten), Routenvergleiche und Richtpreise für grenzüberschreitende Fahrten sind Schätzungen zur Information und kein Angebot und keine Garantie für Preis oder Reisezeit.

5. Tickets und Käufe
Die App verkauft keine Tickets und wickelt keine Zahlungen ab. Die Kaufschaltflächen öffnen die offiziellen Websites der Unternehmen, deren Verkaufs- und Beförderungsbedingungen uneingeschränkt gelten. Bedingungen, Tarife und Fahrgastrechte jedes Unternehmens sind als Links zu dessen offiziellen Seiten unter „Beförderungsbedingungen“ gesammelt.

6. Haftungsbeschränkung
Soweit gesetzlich zulässig, haftet der Autor nicht für direkte oder indirekte Schäden aus der Nutzung der App oder dem Vertrauen auf ihre Informationen, darunter verpasste Züge oder Anschlüsse, Kosten, Bußgelder oder Unannehmlichkeiten. Benachrichtigungen, Erinnerungen und Haltestellenwecker kommen eventuell nicht an (Energiesparmodus, kein Netz, Handyeinstellungen): Verlasse dich nicht allein darauf.
Fahrgastrechte (Erstattung, Entschädigung, Betreuung) sind nach der Verordnung (EU) 2021/782 und den Bedingungen des Unternehmens beim Verkehrsunternehmen geltend zu machen.

7. Datenschutz (DSGVO)
Die App erfordert keine Registrierung, zeigt keine Werbung, hat keine Analyse- oder Tracking-Werkzeuge und keinen eigenen Server: Der Autor erhält und verkauft keine personenbezogenen Daten. Favoriten, Einstellungen, Erinnerungen und das Grün-Protokoll bleiben auf deinem Telefon und werden bei der Deinstallation gelöscht.
Zum Funktionieren ruft die App die aufgeführten Quellen direkt ab: Wie jede Website erhalten sie deine IP-Adresse und die Anfragedaten (z. B. Bahnhof oder Zugnummer) nach ihren eigenen Datenschutzbestimmungen.
Der Standort wird nur mit deiner Erlaubnis und nur auf den Bildschirmen genutzt, die ihn brauchen (Bahnhöfe in der Nähe, Verkaufsstellen, Services). Um Orte in der Nähe zu finden, werden die Koordinaten an OpenStreetMap-Server (Overpass) gesendet; die App speichert sie nicht und nutzt sie nicht im Hintergrund.
Aus der App gesendetes Feedback läuft über ein Google-Formular des Entwicklers, App-Updates kommen von GitHub. Einzelheiten, Rechtsgrundlage und Rechte: „Datenschutz & Berechtigungen“.

8. Datenquellen (angegeben)
Alle Informationen stammen aus öffentlich zugänglichen Quellen, die jeder kostenlos, ohne Registrierung, Abonnement oder Handelsvereinbarung einsehen kann. Die App kauft keine Daten, nutzt keine kostenpflichtigen Dienste und verkauft nichts weiter: Sie zeigt nur, unter Nennung der Quelle, was Unternehmen und öffentliche Stellen veröffentlichen.
• Fahrpläne, Verspätungen, planmäßige und tatsächliche Gleise: ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Reiseverbindungen und Preise: LeFrecce – Trenitalia (lefrecce.it)
• Streiks: Beobachtungsstelle für Verkehrsstreiks – Italienisches Ministerium für Infrastruktur und Verkehr (scioperi.mit.gov.it)
• Meldungen, Linien, Auslastung, Beförderungsbedingungen: Trenord (trenord.it)
• Status von Anlagen und Nachrichten: FerrovieNord (ferrovienord.it)
• Aufzüge und Barrierefreiheit der Bahnhöfe, Sala Blu: RFI (rfi.it)
• Fahrpläne der Trenord-Ersatzbusse: Open Data der Region Lombardei, offizieller Trenord-GTFS-Feed, Lizenz CC BY 4.0 (dati.lombardia.it); ersatzweise Transitous
• Regional- und Lokalfahrpläne sowie Ersatzbusse anderer Unternehmen: Transitous (transitous.org), das die von den Unternehmen veröffentlichten GTFS-Feeds sammelt
• Italo-Züge: italotreno.com
• Züge und Services in Deutschland: Deutsche Bahn (bahn.de)
• Grenzüberschreitende Züge und Services: TILO (tilo.ch)
• Schweizer Fahrplan und erwartete Auslastung: transport.opendata.ch / opentransportdata.swiss (SBB)
• Arcobaleno-Tarife: Tarifverbund Tessin und Moesano (arcobaleno.ch)
• Beförderungsbedingungen, Tarife und Fahrgastrechte: offizielle Seiten jedes Unternehmens (siehe „Beförderungsbedingungen“)
• Fahrgastrechte: Verordnung (EU) 2021/782 (eur-lex.europa.eu)
• Pünktlichkeitsstatistiken: TrovaTreno.it – Open Data, Lizenz CC BY 4.0
• Kraftstoffpreise: Open Data des italienischen Ministeriums für Unternehmen und Made in Italy (mimit.gov.it), Lizenz IODL 2.0
• Karten, Verkaufsstellen, Entwerter, Aufzüge: © OpenStreetMap-Mitwirkende (openstreetmap.org), Lizenz ODbL
• Straßenrouten: OSRM (project-osrm.org) auf OpenStreetMap-Daten
• Software: osmdroid und Android/Jetpack-Komponenten, Lizenz Apache 2.0

9. Kostenlos und Nutzung der Quellen
Binario ist kostenlos, werbefrei, ohne In-App-Käufe und gemeinnützig. Die Quellen werden wie von einem normalen Nutzer von seinem Telefon abgefragt, mit begrenzten Anfragen, auf Nutzeraktion oder in mäßigen Abständen; die Inhalte bleiben Eigentum ihrer Inhaber. Offizielle Seiten werden unverändert im integrierten Leser angezeigt oder über die Originalseite geöffnet.
Bittet ein Unternehmen oder Dateninhaber darum, Inhalte zu ändern oder nicht mehr anzuzeigen, wird die betreffende Funktion entfernt.

10. Kontakt
Für Hinweise, Entfernungswünsche oder Korrekturen: Kontakt zum Autor Marco Jannino.
Für Beschwerden über den Bahnverkehr wende dich an das betreffende Verkehrsunternehmen.

11. Änderungen
Diese Hinweise können mit neuen App-Versionen aktualisiert werden. Die verwendete Version steht oben. Letzte Aktualisierung: November 2026."""

const val LEGAL_TEXT_FR = """1. Qui sommes-nous
Binario est une application indépendante et gratuite, créée par Marco Jannino. Elle n'est ni affiliée, ni sponsorisée, ni approuvée par Trenitalia, RFI, Gruppo FS, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB ou toute autre entreprise ou organisme de transport cité.

2. Marques
Les noms et marques des entreprises citées appartiennent à leurs titulaires et ne servent qu'à indiquer la source de l'information ou le service concerné. L'application n'utilise pas les logos officiels des entreprises.

3. Données et fiabilité
Horaires, retards, voies, suppressions, tarifs, grèves, avis, accessibilité, affluence et statistiques proviennent de sources publiques tierces et sont fournis « en l'état », sans garantie d'exactitude, d'exhaustivité ou d'actualité.
Les informations officielles prévalent toujours : tableaux et annonces en gare, personnel, sites et applications officiels.

4. Estimations
L'affluence marquée « ≈ », les valeurs de « Quel est ton niveau de vert » (CO₂, carburant, péages, temps de trajet), les comparaisons d'itinéraires et les tarifs transfrontaliers indicatifs sont des estimations à titre d'information, et ne constituent ni une offre ni une garantie de prix ou de durée.

5. Billets et achats
L'application ne vend pas de billets et ne gère aucun paiement. Les boutons d'achat ouvrent les sites officiels des entreprises, dont les conditions de vente et de transport s'appliquent pleinement. Les conditions, tarifs et droits des voyageurs de chaque entreprise sont réunis sous forme de liens vers ses pages officielles dans « Conditions de transport ».

6. Limitation de responsabilité
Dans la mesure permise par la loi, l'auteur n'est pas responsable des dommages directs ou indirects résultant de l'utilisation de l'application ou de la confiance accordée à ses informations, y compris trains ou correspondances manqués, frais, amendes ou désagréments. Les notifications, rappels et alarmes d'arrêt peuvent ne pas arriver (économie de batterie, absence de réseau, réglages du téléphone) : ne vous y fiez pas comme seule alerte.
Les droits des voyageurs (remboursement, indemnisation, assistance) se font valoir auprès du transporteur, selon le règlement (UE) 2021/782 et ses conditions.

7. Confidentialité (RGPD)
L'application ne demande aucune inscription, n'affiche aucune publicité, n'a ni outils d'analyse ni de suivi et n'a pas de serveur propre : l'auteur ne reçoit ni ne vend de données personnelles. Favoris, réglages, rappels et journal vert restent sur votre téléphone et sont supprimés à la désinstallation.
Pour fonctionner, l'application contacte directement les sources indiquées : comme tout site web, elles reçoivent votre adresse IP et les données de la requête (p. ex. gare ou numéro de train), selon leur propre politique de confidentialité.
La position n'est utilisée qu'avec votre autorisation et seulement sur les écrans qui en ont besoin (gares proches, points de vente, services). Pour trouver les lieux proches, les coordonnées sont envoyées aux serveurs d'OpenStreetMap (Overpass) ; l'application ne les conserve pas et ne les utilise pas en arrière-plan.
Les retours envoyés depuis l'application passent par un formulaire Google du développeur, et les mises à jour viennent de GitHub. Détails, base juridique et droits : « Confidentialité et autorisations ».

8. Sources des données (citées)
Toutes les informations proviennent de sources accessibles au public que chacun peut consulter gratuitement, sans inscription, abonnement ni accord commercial. L'application n'achète pas de données, n'utilise aucun service payant et ne revend rien : elle montre seulement, en citant la source, ce que publient les entreprises et les organismes publics.
• Horaires, retards, voies prévues et réelles : ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Solutions de voyage et tarifs : LeFrecce – Trenitalia (lefrecce.it)
• Grèves : Observatoire des grèves des transports – ministère italien des Infrastructures et des Transports (scioperi.mit.gov.it)
• Avis, lignes, affluence, conditions de transport : Trenord (trenord.it)
• État des installations et actualités : FerrovieNord (ferrovienord.it)
• Ascenseurs et accessibilité des gares, Sala Blu : RFI (rfi.it)
• Horaires des bus de remplacement Trenord : données ouvertes de la Région Lombardie, flux GTFS officiel de Trenord, licence CC BY 4.0 (dati.lombardia.it) ; à défaut, Transitous
• Horaires régionaux et locaux et bus de remplacement d'autres entreprises : Transitous (transitous.org), qui rassemble les flux GTFS publiés par les entreprises
• Trains Italo : italotreno.com
• Trains et services en Allemagne : Deutsche Bahn (bahn.de)
• Trains et services transfrontaliers : TILO (tilo.ch)
• Horaires suisses et affluence prévue : transport.opendata.ch / opentransportdata.swiss (SBB)
• Tarifs Arcobaleno : communauté tarifaire du Tessin et du Moesano (arcobaleno.ch)
• Conditions de transport, tarifs et droits des voyageurs : pages officielles de chaque entreprise (voir « Conditions de transport »)
• Droits des voyageurs : règlement (UE) 2021/782 (eur-lex.europa.eu)
• Statistiques de ponctualité : TrovaTreno.it – données ouvertes, licence CC BY 4.0
• Prix des carburants : données ouvertes du ministère italien des Entreprises et du Made in Italy (mimit.gov.it), licence IODL 2.0
• Cartes, points de vente, valideurs, ascenseurs : © contributeurs OpenStreetMap (openstreetmap.org), licence ODbL
• Itinéraires routiers : OSRM (project-osrm.org) sur données OpenStreetMap
• Logiciels : osmdroid et composants Android/Jetpack, licence Apache 2.0

9. Gratuité et usage des sources
Binario est gratuit, sans publicité, sans achats intégrés et sans but lucratif. Les sources sont consultées comme le ferait un utilisateur normal depuis son téléphone, avec des requêtes limitées, sur action de l'utilisateur ou à intervalles modérés ; les contenus restent la propriété de leurs titulaires. Les pages officielles sont affichées sans modification dans le lecteur intégré ou en ouvrant le site d'origine.
Si une entreprise ou un titulaire de données demande de modifier ou de ne plus afficher certains contenus, la fonction concernée sera retirée.

10. Contact
Pour signalements, demandes de retrait ou corrections : contactez l'auteur, Marco Jannino.
Pour les réclamations sur le service ferroviaire, adressez-vous à l'entreprise de transport concernée.

11. Modifications
Ces mentions peuvent être mises à jour avec les nouvelles versions de l'application. La version utilisée est indiquée en haut. Dernière mise à jour : novembre 2026."""

const val LEGAL_TEXT_ES = """1. Quiénes somos
Binario es una aplicación independiente y gratuita creada por Marco Jannino. No está afiliada, patrocinada ni aprobada por Trenitalia, RFI, Gruppo FS, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB ni por ninguna otra empresa u organismo de transporte mencionado.

2. Marcas
Los nombres y marcas de las empresas citadas pertenecen a sus titulares y se usan solo para indicar la fuente de la información o el servicio al que se refieren. La aplicación no usa logotipos oficiales de las empresas.

3. Datos y fiabilidad
Horarios, retrasos, vías, cancelaciones, tarifas, huelgas, avisos, accesibilidad, afluencia y estadísticas proceden de fuentes públicas de terceros y se ofrecen «tal cual», sin garantía de exactitud, integridad ni actualidad.
Prevalece siempre la información oficial: paneles y avisos en la estación, personal, sitios web y aplicaciones oficiales.

4. Estimaciones
La afluencia marcada con «≈», las cifras de «Cuán verde eres» (CO₂, combustible, peajes, tiempos de trayecto), las comparaciones de rutas y las tarifas transfronterizas indicativas son estimaciones informativas y no constituyen una oferta ni una garantía de precio o duración.

5. Billetes y compras
La aplicación no vende billetes ni gestiona pagos. Los botones de compra abren los sitios oficiales de las empresas, cuyas condiciones de venta y de transporte se aplican íntegramente. Las condiciones, tarifas y derechos de los viajeros de cada empresa se recogen como enlaces a sus páginas oficiales en «Condiciones de transporte».

6. Limitación de responsabilidad
En la medida permitida por la ley, el autor no responde de daños directos o indirectos derivados del uso de la aplicación o de la confianza en su información, incluidos trenes o enlaces perdidos, costes, multas o molestias. Las notificaciones, recordatorios y alarmas de parada pueden no llegar (ahorro de batería, sin red, ajustes del teléfono): no confíes en ellas como único aviso.
Los derechos de los viajeros (reembolso, compensación, asistencia) se reclaman al transportista según el Reglamento (UE) 2021/782 y sus condiciones.

7. Privacidad (RGPD)
La aplicación no requiere registro, no muestra anuncios, no tiene herramientas de análisis ni seguimiento y no tiene servidor propio: el autor no recibe ni vende datos personales. Favoritos, ajustes, recordatorios y el registro verde permanecen en tu teléfono y se borran al desinstalar la aplicación.
Para funcionar, la aplicación contacta directamente con las fuentes indicadas: como cualquier sitio web, reciben tu dirección IP y los datos de la consulta (p. ej. estación o número de tren), según sus propias políticas de privacidad.
La ubicación se usa solo con tu permiso y solo en las pantallas que la necesitan (estaciones cercanas, puntos de venta, servicios). Para encontrar lugares cercanos, las coordenadas se envían a los servidores de OpenStreetMap (Overpass); la aplicación no las guarda ni las usa en segundo plano.
Los comentarios enviados desde la aplicación pasan por un formulario de Google del desarrollador, y las actualizaciones vienen de GitHub. Detalles, base jurídica y derechos: «Privacidad y permisos».

8. Fuentes de los datos (citadas)
Toda la información procede de fuentes de acceso público que cualquiera puede consultar gratis, sin registro, suscripción ni acuerdo comercial. La aplicación no compra datos, no usa servicios de pago y no revende nada: solo muestra, citando la fuente, lo que publican empresas y organismos públicos.
• Horarios, retrasos, vías previstas y reales: ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Soluciones de viaje y tarifas: LeFrecce – Trenitalia (lefrecce.it)
• Huelgas: Observatorio de huelgas del transporte – Ministerio italiano de Infraestructuras y Transportes (scioperi.mit.gov.it)
• Avisos, líneas, afluencia, condiciones de transporte: Trenord (trenord.it)
• Estado de las instalaciones y noticias: FerrovieNord (ferrovienord.it)
• Ascensores y accesibilidad de las estaciones, Sala Blu: RFI (rfi.it)
• Horarios de los autobuses sustitutivos de Trenord: datos abiertos de la Región de Lombardía, feed GTFS oficial de Trenord, licencia CC BY 4.0 (dati.lombardia.it); si no está disponible, Transitous
• Horarios regionales y locales y autobuses sustitutivos de otras empresas: Transitous (transitous.org), que recoge los feeds GTFS publicados por las empresas
• Trenes Italo: italotreno.com
• Trenes y servicios en Alemania: Deutsche Bahn (bahn.de)
• Trenes y servicios transfronterizos: TILO (tilo.ch)
• Horario suizo y afluencia prevista: transport.opendata.ch / opentransportdata.swiss (SBB)
• Tarifas Arcobaleno: comunidad tarifaria del Tesino y Moesano (arcobaleno.ch)
• Condiciones de transporte, tarifas y derechos de los viajeros: páginas oficiales de cada empresa (véase «Condiciones de transporte»)
• Derechos de los viajeros: Reglamento (UE) 2021/782 (eur-lex.europa.eu)
• Estadísticas de puntualidad: TrovaTreno.it – datos abiertos, licencia CC BY 4.0
• Precios de combustible: datos abiertos del Ministerio italiano de Empresas y Made in Italy (mimit.gov.it), licencia IODL 2.0
• Mapas, puntos de venta, canceladoras, ascensores: © colaboradores de OpenStreetMap (openstreetmap.org), licencia ODbL
• Rutas por carretera: OSRM (project-osrm.org) sobre datos de OpenStreetMap
• Software: osmdroid y componentes de Android/Jetpack, licencia Apache 2.0

9. Gratuidad y uso de las fuentes
Binario es gratuita, sin anuncios, sin compras dentro de la aplicación y sin ánimo de lucro. Las fuentes se consultan como lo haría un usuario normal desde su teléfono, con solicitudes limitadas, por acción del usuario o a intervalos moderados; los contenidos siguen siendo propiedad de sus titulares. Las páginas oficiales se muestran sin alterar en el lector integrado o abriendo el sitio original.
Si una empresa o titular de datos pide cambiar o dejar de mostrar algún contenido, se retirará la función correspondiente.

10. Contacto
Para avisos, solicitudes de retirada o correcciones: contacta con el autor, Marco Jannino.
Para reclamaciones sobre el servicio ferroviario, dirígete a la empresa de transporte correspondiente.

11. Cambios
Estas notas pueden actualizarse con las nuevas versiones de la aplicación. La versión en uso se indica arriba. Última actualización: noviembre de 2026."""

const val LEGAL_TEXT_JA = """1. 運営者について
Binario は Marco Jannino が作成した独立の無料アプリです。Trenitalia、RFI、FS グループ、Italo-NTV、Trenord、FerrovieNord/FNM、TILO、SBB など、記載されたいずれの交通事業者・機関とも提携・後援・承認の関係はありません。

2. 商標
記載された各社の名称や商標は、それぞれの権利者に帰属し、情報の出典や該当サービスを示すためにのみ使用します。アプリは各社の公式ロゴを使用しません。

3. データと信頼性
時刻表、遅延、番線、運休、運賃、ストライキ、お知らせ、バリアフリー、混雑状況、統計は、第三者の公開情報に基づき「現状のまま」提供され、正確性・完全性・最新性を保証しません。
常に公式情報が優先されます：駅の案内表示・放送、係員、公式サイトとアプリ。

4. 推定値
「≈」で示す混雑状況、「どれだけエコか」の数値（CO₂、燃料、通行料、所要時間）、経路の比較、国境をまたぐ運賃の目安は、参考情報としての推定であり、価格や所要時間の提示・保証ではありません。

5. 切符と購入
アプリは切符を販売せず、決済も扱いません。購入ボタンは各社の公式サイトを開き、その販売条件・運送条件が全面的に適用されます。各社の運送条件・運賃・旅客の権利は、公式ページへのリンクとして「運送条件」にまとめています。

6. 責任の制限
法律で認められる範囲で、作者はアプリの利用や情報への依存から生じる直接的・間接的な損害（列車や乗り継ぎの乗り遅れ、費用、罰金、不便など）について責任を負いません。通知、リマインダー、停車駅アラームは届かないことがあります（省電力、圏外、端末の設定）。唯一の警告として頼らないでください。
旅客の権利（払い戻し、補償、支援）は、EU 規則 2021/782 と各社の条件に基づき、運送事業者に請求してください。

7. プライバシー（GDPR）
アプリは登録不要で、広告表示、分析・追跡ツール、独自サーバーはありません。作者は個人データを受け取らず、販売もしません。お気に入り、設定、リマインダー、グリーン記録は端末内に保存され、アンインストールで削除されます。
動作のため、アプリは記載の情報源に直接アクセスします。一般的なウェブサイトと同様、各情報源は各自のプライバシーポリシーに従い、IP アドレスとリクエストデータ（駅名・列車番号など）を受け取ります。
位置情報は、許可した場合のみ、必要な画面（近くの駅、販売所、サービス）でのみ使用します。近くの場所を探すため、座標は OpenStreetMap のサーバー（Overpass）に送信されます。アプリは座標を保存せず、バックグラウンドでも使用しません。
アプリから送信したフィードバックは開発者の Google フォームを経由し、アプリの更新は GitHub から取得します。詳細、法的根拠、権利：「プライバシーと権限」。

8. データの出典（明記）
すべての情報は、登録・購読・商業契約なしに誰でも無料で閲覧できる公開情報源に基づきます。アプリはデータを購入せず、有料サービスを使わず、何も転売しません。企業や公的機関が公開している内容を、出典を明記して表示するだけです。
• 時刻表、遅延、予定・実際の番線：ViaggiaTreno – RFI / Trenitalia（viaggiatreno.it）
• 経路案と運賃：LeFrecce – Trenitalia（lefrecce.it）
• ストライキ：交通ストライキ観測所 – イタリア・インフラ交通省（scioperi.mit.gov.it）
• お知らせ、路線、混雑、運送条件：Trenord（trenord.it）
• 設備の状況とニュース：FerrovieNord（ferrovienord.it）
• エレベーターと駅のバリアフリー、Sala Blu：RFI（rfi.it）
• Trenord 代行バスの時刻：ロンバルディア州オープンデータ、Trenord 公式 GTFS フィード、CC BY 4.0 ライセンス（dati.lombardia.it）。利用できない場合は Transitous
• 他社の地域・ローカル時刻表と代行バス：Transitous（transitous.org）（各社が公開する GTFS フィードを収集）
• Italo の列車：italotreno.com
• ドイツの列車とサービス：ドイツ鉄道 Deutsche Bahn（bahn.de）
• 国境を越える列車とサービス：TILO（tilo.ch）
• スイスの時刻表と予想混雑：transport.opendata.ch / opentransportdata.swiss（SBB）
• Arcobaleno の運賃：ティチーノ州とモエザーノの運賃連合（arcobaleno.ch）
• 運送条件・運賃・旅客の権利：各社の公式ページ（「運送条件」参照）
• 旅客の権利：EU 規則 2021/782（eur-lex.europa.eu）
• 定時性統計：TrovaTreno.it – オープンデータ、CC BY 4.0 ライセンス
• 燃料価格：イタリア企業・メイド・イン・イタリア省のオープンデータ（mimit.gov.it）、IODL 2.0 ライセンス
• 地図、販売所、改札機、エレベーター：© OpenStreetMap contributors（openstreetmap.org）、ODbL ライセンス
• 道路経路：OpenStreetMap データに基づく OSRM（project-osrm.org）
• ソフトウェア：osmdroid と Android/Jetpack コンポーネント、Apache 2.0 ライセンス

9. 無料であることと情報源の利用
Binario は無料で、広告なし、アプリ内課金なし、非営利です。情報源へは、通常の利用者が自分の端末から行うのと同様に、限られたリクエストで、利用者の操作時または適度な間隔でアクセスします。コンテンツは各権利者に帰属します。公式ページは内蔵リーダーで無加工のまま表示するか、元のサイトを開きます。
企業やデータの権利者から内容の変更や表示の停止を求められた場合は、該当する機能を削除します。

10. 連絡先
報告、削除の依頼、訂正は、作者 Marco Jannino（アプリ内のフィードバック機能）までご連絡ください。
鉄道サービスへの苦情は、該当する交通事業者にお問い合わせください。

11. 変更
この通知は、アプリの新バージョンで更新されることがあります。使用中のバージョンは上部に表示されます。最終更新：2026年11月。"""

