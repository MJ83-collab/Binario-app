package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.BoardItem
import com.binario.treni.data.Fmt

/** Colori del tabellone a palette (stile Solari delle vecchie stazioni). */
object VintageColors {
    val board = Color(0xFF0B0B0C)
    val flap = Color(0xFF1C1C1E)
    val split = Color(0xFF050505)
    val white = Color(0xFFF2EFE6)
    val amber = Color(0xFFF5C84C)
    val late = Color(0xFFFF7043)
    val dim = Color(0xFF8C887C)
}

private val GAP = 1.5.dp
private val COL_GAP = 8.dp
private val SIDE = 12.dp

private const val FLAP_SET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.+-'"

/** Misure del tabellone: le palette si adattano per occupare tutta la larghezza disponibile. */
private class Dims(val dest: Int, val cw: Dp) {
    val ch: Dp get() = cw * 1.6f
    val font get() = (cw.value * 1.08f).sp
    val smallFont get() = (cw.value * 0.72f).sp
}

private fun dims(widthDp: Float): Dims {
    val avail = widthDp - 2 * SIDE.value - 3 * COL_GAP.value
    val fixed = 5 + 4 + 2
    val total = (avail / (14f + GAP.value)).toInt().coerceAtLeast(fixed + 6)
    val dest = (total - fixed).coerceIn(6, 30)
    val cw = (avail / (fixed + dest) - GAP.value).coerceIn(8f, 19f)
    return Dims(dest, cw.dp)
}

/** Una palette: il carattere scorre tra lettere e numeri (flip) fino a fermarsi su quello giusto, con la fessura a metà. */
@Composable
private fun Flap(ch: Char, color: Color, d: Dims, index: Int = 0) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // Rispetta "Rimuovi animazioni" di Android: in quel caso il carattere compare subito
    val animate = remember {
        try { android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f } catch (e: Exception) { true }
    }
    var shown by remember { mutableStateOf(if (animate) ' ' else ch) }
    val flip = remember { androidx.compose.animation.core.Animatable(1f) }
    LaunchedEffect(ch) {
        if (!animate || shown == ch) { shown = ch; flip.snapTo(1f); return@LaunchedEffect }
        val target = FLAP_SET.indexOf(ch)
        if (target < 0) { shown = ch; flip.snapTo(1f); return@LaunchedEffect }
        kotlinx.coroutines.delay(index * 14L)
        var cur = FLAP_SET.indexOf(shown).coerceAtLeast(0)
        val dist = (target - cur + FLAP_SET.length) % FLAP_SET.length
        val stride = maxOf(1, dist / 7)
        while (cur != target) {
            cur = (cur + stride) % FLAP_SET.length
            if ((target - cur + FLAP_SET.length) % FLAP_SET.length < stride) cur = target
            flip.animateTo(0f, androidx.compose.animation.core.tween(20))
            shown = FLAP_SET[cur]
            flip.animateTo(1f, androidx.compose.animation.core.tween(20))
        }
        shown = ch
        flip.snapTo(1f)
    }
    Box(
        Modifier.padding(end = GAP).size(d.cw, d.ch).clip(RoundedCornerShape(2.dp)).background(VintageColors.flap)
            .drawWithContent {
                drawContent()
                drawLine(VintageColors.split, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), strokeWidth = 2f)
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            shown.toString(), color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = d.font,
            textAlign = TextAlign.Center, modifier = Modifier.graphicsLayer { scaleY = flip.value },
        )
    }
}

/** Testo a palette di lunghezza fissa (tagliato o completato con palette vuote). */
@Composable
private fun FlapText(text: String, len: Int, color: Color, d: Dims, rightAlign: Boolean = false) {
    val t = text.uppercase().take(len)
    val padded = if (rightAlign) t.padStart(len) else t.padEnd(len)
    Row { padded.forEachIndexed { i, c -> Flap(c, color, d, i) } }
}

/**
 * Nome lungo: se non entra nelle palette scorre in loop, un carattere alla volta, con una pausa all'inizio
 * per poterlo leggere. Se entra, resta fermo.
 */
@Composable
private fun FlapMarquee(text: String, len: Int, color: Color, d: Dims) {
    val t = text.uppercase()
    if (t.length <= len) { FlapText(t, len, color, d); return }
    val loop = "$t   "
    var offset by remember(t) { mutableStateOf(0) }
    LaunchedEffect(t) {
        while (true) {
            offset = 0
            kotlinx.coroutines.delay(2800)
            for (i in 1..loop.length) {
                offset = i % loop.length
                kotlinx.coroutines.delay(if (i == loop.length) 600 else 650)
            }
        }
    }
    val window = (loop + loop).drop(offset).take(len)
    FlapText(window, len, color, d)
}

@Composable
fun VintageHeader() {
    BoxWithConstraints(Modifier.fillMaxWidth().padding(start = SIDE, end = SIDE, top = 8.dp, bottom = 4.dp)) {
        val d = dims(maxWidth.value + 2 * SIDE.value)
        Row {
            HeaderLabel("ORARI", 5, d)
            Spacer(Modifier.width(COL_GAP))
            HeaderLabel("DESTINAZIONE", d.dest, d)
            Spacer(Modifier.width(COL_GAP))
            HeaderLabel("RIT", 4, d)
            Spacer(Modifier.width(COL_GAP))
            HeaderLabel("BIN", 2, d)
        }
    }
}

@Composable
private fun HeaderLabel(text: String, chars: Int, d: Dims) {
    Text(text, color = VintageColors.amber, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = d.smallFont,
        modifier = Modifier.width((d.cw + GAP) * chars), maxLines = 1)
}

@Composable
fun VintageBoardRow(b: BoardItem, departures: Boolean, onClick: () -> Unit) {
    val known = b.inStation || b.delay != 0
    val delayText = when {
        !known -> "N.D"
        b.delay > 0 -> "+${b.delay}"
        b.delay < 0 -> "${b.delay}"
        else -> ""
    }
    val plat = b.realPlatform.ifBlank { b.schedPlatform }
    BoxWithConstraints(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = SIDE, vertical = 3.dp)) {
        val d = dims(maxWidth.value + 2 * SIDE.value)
        Column {
            Row {
                FlapText(Fmt.time(b.time).replace(':', '.'), 5, VintageColors.white, d)
                Spacer(Modifier.width(COL_GAP))
                FlapMarquee((if (departures) "" else "da ") + b.otherEnd, d.dest, VintageColors.amber, d)
                Spacer(Modifier.width(COL_GAP))
                FlapText(delayText, 4, if (b.delay > 0) VintageColors.late else VintageColors.dim, d, rightAlign = true)
                Spacer(Modifier.width(COL_GAP))
                FlapText(plat, 2, if (b.realPlatform.isNotBlank()) VintageColors.white else VintageColors.dim, d, rightAlign = true)
            }
            Text(
                "${b.operator} ${b.category} ${b.number}".trim().uppercase(),
                color = VintageColors.dim, fontFamily = FontFamily.Monospace, fontSize = d.smallFont,
                modifier = Modifier.padding(start = (d.cw + GAP) * 5 + COL_GAP, top = 1.dp),
            )
        }
    }
}
