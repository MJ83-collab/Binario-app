package com.binario.treni.data

import java.text.Normalizer

/**
 * Base di conoscenza dell'assistente: risposte alle domande più comuni dei viaggiatori, sempre con la fonte ufficiale.
 * Il riconoscimento è tollerante: ignora accenti e maiuscole, accetta plurali e coniugazioni (radici delle parole)
 * e piccoli errori di battitura nelle parole lunghe.
 */
object Knowledge {
    data class Entry(
        val id: String,
        /** Ogni gruppo di radici deve comparire tutto nella domanda. "=parola" = parola esatta. */
        val triggers: List<List<String>>,
        val itText: String,
        val enText: String,
        val source: String = "",
        val url: String = "",
    ) {
        val text: String get() = I18n.tr(itText, enText)
    }

    /** Minuscole, senza accenti né punteggiatura. */
    fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** La radice compare tra le parole? Prefisso esatto, oppure un errore di battitura per radici di almeno 6 lettere. */
    fun hasStem(words: List<String>, stem: String): Boolean {
        if (stem.startsWith("=")) return words.contains(stem.substring(1))
        return words.any { w ->
            w.startsWith(stem) || (stem.length >= 6 && w.length >= stem.length - 1 && lev(w.take(stem.length), stem) <= 1)
        }
    }

    /** Punteggio di una voce: la lunghezza delle radici del gruppo più specifico trovato (0 = nessun gruppo completo). */
    fun score(e: Entry, words: List<String>): Int =
        e.triggers.filter { g -> g.all { hasStem(words, it) } }
            .maxOfOrNull { g -> g.sumOf { if (it.startsWith("=")) it.length + 1 else it.length } + (g.size - 1) * 3 } ?: 0

    /** La voce più pertinente, se il punteggio è sufficiente. */
    fun find(question: String, minScore: Int = 4): Entry? {
        val words = normalize(question).split(" ").filter { it.isNotBlank() }
        return entries.map { it to score(it, words) }.filter { it.second >= minScore }.maxByOrNull { it.second }?.first
    }

    /** Argomenti suggeriti quando la domanda non è chiara. */
    val topics: List<String> get() = listOf(
        I18n.tr("rimborso per ritardo", "delay compensation"), I18n.tr("bici sul treno", "bikes on trains"),
        I18n.tr("bambini", "children"), I18n.tr("assistenza disabili", "disability assistance"),
        I18n.tr("oggetti smarriti", "lost property"), I18n.tr("convalida biglietto", "ticket validation"),
        I18n.tr("bus e taxi a Varese", "bus and taxi at Varese"), I18n.tr("WC a Saronno", "toilets at Saronno"),
    )

    private const val TI_INDENNIZZO = "https://www.trenitalia.com/it/informazioni/indennizzo-per-ritardodeltreno.html"
    private const val TI_RIMBORSO = "https://www.trenitalia.com/it/informazioni/richiesta-di-rimborso.html"
    private const val TN_RIMBORSI = "https://www.trenord.it/assistenza/servizi/rimborsi-e-indennizzi/"
    private const val TI_DIRITTI = "https://www.trenitalia.com/it/informazioni/la-guida-del-viaggiatore/regolamento-ue-782-2021-diritti-e-obblighi-dei-passeggeri.html"

    val entries: List<Entry> = listOf(
        Entry("ritardo_rimborso",
            listOf(listOf("rimbors", "ritard"), listOf("indenn"), listOf("risarc"), listOf("compens"), listOf("refund", "delay"),
                listOf("compensation"), listOf("bonus", "ritard"), listOf("soldi", "ritard"), listOf("money", "late"), listOf("late", "refund"), listOf("refund", "late"), listOf("compensat"), listOf("money", "delay"), listOf("delay", "=back"), listOf("spett", "ritard"), listOf("owed", "late"), listOf("entitled", "late"), listOf("entitled", "delay"), listOf("=right", "delay")),
            "Rimborso per ritardo (Regolamento UE 2021/782):\n• da 60 a 119 minuti di ritardo all'arrivo: indennizzo del 25% del biglietto\n• da 120 minuti: 50%\n" +
                "• Frecce Trenitalia: indennizzo anche tra 30 e 59 minuti, secondo le condizioni Trenitalia\n" +
                "• abbonati: regole proprie (Trenord riconosce bonus sugli abbonamenti in base alla puntualità della linea)\n" +
                "Se il ritardo previsto supera i 60 minuti puoi anche rinunciare al viaggio con rimborso completo o farti riprogrammare il viaggio. " +
                "Nella scheda del treno l'app ti mostra se hai diritto all'indennizzo.",
            "Delay compensation (EU Regulation 2021/782):\n• 60–119 minutes late on arrival: 25% of the ticket\n• 120 minutes or more: 50%\n" +
                "• Trenitalia Frecce: compensation also for 30–59 minutes, under Trenitalia's conditions\n" +
                "• season tickets: own rules (Trenord gives season-ticket bonuses based on line punctuality)\n" +
                "If the expected delay exceeds 60 minutes you can also give up the trip with a full refund or be re-routed. " +
                "The train screen shows whether you are entitled to compensation.",
            "Trenitalia · indennità per ritardo", TI_INDENNIZZO),
        Entry("rimborso_biglietto",
            listOf(listOf("rimbors", "bigliett"), listOf("rinunci"), listOf("annull", "bigliett"), listOf("cambi", "bigliett"),
                listOf("modific", "bigliett"), listOf("refund", "ticket"), listOf("cancel", "ticket"), listOf("change", "ticket")),
            "Rimborso o cambio del biglietto: dipende dall'offerta acquistata (le offerte economiche spesso non sono rimborsabili). " +
                "Trenitalia: richiesta dal sito o dall'app con codice del biglietto (PNR). Trenord: dalla pagina rimborsi. " +
                "Se il treno è soppresso o ha più di 60 minuti di ritardo previsto il rimborso è sempre dovuto.",
            "Ticket refund or change: it depends on the fare (cheap offers are often non-refundable). " +
                "Trenitalia: request on the website or app with the ticket code (PNR). Trenord: from the refunds page. " +
                "If the train is cancelled or expected more than 60 minutes late a refund is always due.",
            "Trenitalia · richiesta di rimborso", TI_RIMBORSO),
        Entry("convalida",
            listOf(listOf("convalid"), listOf("obliter"), listOf("timbr"), listOf("validat"), listOf("stamp", "ticket"), listOf("valid", "bigliett"), listOf("validat", "ticket"), listOf("obliter", "bigliett"), listOf("dimentic", "obliter"), listOf("obliter", "bigliett", "elettronic"), listOf("validat", "ticket", "electronic")),
            "Convalida: i biglietti regionali cartacei senza data e ora vanno convalidati prima di salire (obliteratrice in stazione). " +
                "I biglietti digitali acquistati online o in app riportano già il treno o il giorno: controlla sul biglietto se serve il check-in. " +
                "Le obliteratrici più vicine sono in Stazioni → scheda della stazione → Riepilogo, o in Altro → Rivendite vicine.",
            "Validation: paper regional tickets without date and time must be validated before boarding (validating machine in the station). " +
                "Digital tickets bought online or in the app already show the train or the day: check on the ticket whether check-in is needed. " +
                "The nearest validators are in Stations → station → Overview, or More → Nearby resellers.",
            "Trenord · condizioni di trasporto", "https://www.trenord.it/assistenza/informazioni-utili/condizioni-di-trasporto/"),
        Entry("multa",
            listOf(listOf("mult"), listOf("sanzion"), listOf("senza", "bigliett"), listOf("controllor"), listOf("without", "ticket"), listOf("=fined"), listOf("=fine"), listOf("fined"), listOf("penalt"), listOf("sanzion", "bigliett"), listOf("mult", "convalid"), listOf("mult", "bigliett"), listOf("=fine", "validat", "ticket"), listOf("fined", "validat")),
            "Senza un biglietto valido si paga il biglietto più una sanzione; importi e modalità di pagamento (ridotti se paghi subito o entro pochi giorni) " +
                "sono nelle condizioni di trasporto dell'azienda. Se l'emettitrice era guasta segnalalo subito al capotreno.",
            "Without a valid ticket you pay the fare plus a fine; amounts and how to pay (reduced if you pay at once or within a few days) " +
                "are in the operator's conditions of carriage. If the ticket machine was broken, tell the conductor straight away.",
            "Trenord · sanzioni", "https://www.trenord.it/assistenza/servizi/sanzioni/"),
        Entry("bici",
            listOf(listOf("bici"), listOf("biciclett"), listOf("monopattin"), listOf("bike"), listOf("bicycle"), listOf("scooter"), listOf("bycicl")),
            "Bici e monopattini:\n• Trenord (Lombardia): bici tradizionali, pieghevoli, elettriche e monopattini viaggiano gratis su tutti i treni, senza limiti di orario, se c'è spazio\n" +
                "• Trenitalia Regionale: in genere sui treni con il simbolo della bici, con supplemento\n• Frecce e Italo: di norma solo bici pieghevoli chiuse in sacca\n" +
                "• TILO: in Ticino valgono le regole FFS, in Lombardia quelle Trenord",
            "Bikes and scooters:\n• Trenord (Lombardy): regular, folding, electric bikes and scooters travel free on all trains, at any time, space permitting\n" +
                "• Trenitalia Regional: usually on trains with the bike symbol, with a supplement\n• Frecce and Italo: normally only folded bikes in a bag\n" +
                "• TILO: SBB rules in Ticino, Trenord rules in Lombardy",
            "Trenord · trasporto biciclette", "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/trasporto-biciclette/"),
        Entry("animali",
            listOf(listOf("animal"), listOf("=cane"), listOf("=cani"), listOf("=gatto"), listOf("=gatti"), listOf("=dog"), listOf("=dogs"), listOf("=cat"), listOf("=pet"), listOf("=pets"), listOf("=cats"), listOf("=cat", "ticket"), listOf("=dog", "ticket"), listOf("=pet", "ticket"), listOf("conigl"), listOf("rabbit"), listOf("criceto"), listOf("hamster"), listOf("uccell"), listOf("=bird")),
            "Animali in treno:\n• Trenord: gratis in Lombardia (trasportino max 70×30×50 cm; cani con museruola, guinzaglio e certificato anagrafe canina); " +
                "vietati nei feriali 7:00–9:30 e 17:30–19:30; fuori regione serve il supplemento animali\n" +
                "• Trenitalia: trasportino gratis; sui regionali i cani grandi pagano il 50% della 2ª classe; su Frecce e Intercity si aggiunge \"Viaggia con il tuo cane\" all'acquisto\n" +
                "• Italo: gratis fino a circa 5 kg nel trasportino; cani più grandi con il servizio \"Cane\" in Smart e Prima\n" +
                "• FFS/TILO: gratis fino a 30 cm in borsa; altrimenti metà prezzo o carta giornaliera cani CHF 25\n" +
                "• Cani guida e d'assistenza: sempre gratis. Tutto in Altro → Viaggiare con animali.",
            "Pets on trains:\n• Trenord: free within Lombardy (carrier max 70×30×50 cm; dogs with muzzle, leash and registry certificate); " +
                "not allowed on weekdays 7:00–9:30 and 17:30–19:30; beyond Lombardy an animal supplement is needed\n" +
                "• Trenitalia: carrier free; on regional trains large dogs pay 50% of 2nd class; on Frecce and Intercity add \"Travel with your dog\" when buying\n" +
                "• Italo: free up to about 5 kg in a carrier; larger dogs with the \"Dog\" service in Smart and Prima\n" +
                "• SBB/TILO: free up to 30 cm in a bag; otherwise half fare or dog day pass CHF 25\n" +
                "• Guide and assistance dogs: always free. Details in More → Travelling with pets.",
            "Trenord · trasporto animali", "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/trasporto-animali/"),
        Entry("bambini",
            listOf(listOf("bambin"), listOf("ragazz"), listOf("figli"), listOf("neonat"), listOf("child"), listOf("=kids"), listOf("infant"), listOf("=baby"), listOf("child", "discount"), listOf("=son"), listOf("=daughter"), listOf("child", "ticket"), listOf("babies"), listOf("=baby", "ticket"), listOf("=kid")),
            "Bambini e ragazzi:\n• Regionali in Lombardia: gratis sotto i 4 anni senza posto a sedere, sconto 50% da 4 a 14 anni non compiuti\n" +
                "• Treni nazionali Trenitalia: gratis sotto i 4 anni senza posto, 50% sull'offerta Base da 4 a 15 anni non compiuti\n" +
                "• Altre regioni e Italo hanno regole proprie",
            "Children:\n• Regional trains in Lombardy: free under 4 without a seat, 50% off from 4 to under 14\n" +
                "• Trenitalia national trains: free under 4 without a seat, 50% off the Base fare from 4 to under 15\n" +
                "• Other regions and Italo have their own rules",
            "Trenord · ragazzi e bambini", "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/ragazzi-e-bambini-in-treno/"),
        Entry("disabili",
            listOf(listOf("disabil"), listOf("carrozzin"), listOf("sedia", "rotell"), listOf("sala", "blu"), listOf("mobilita", "ridott"),
                listOf("wheelchair"), listOf("disab"), listOf("=prm"), listOf("accompagn", "assist"), listOf("reduced", "mobilit"), listOf("disab", "help"), listOf("assist", "anzian"), listOf("assist", "elderly"), listOf("help", "elderly"), listOf("assist", "senior"), listOf("stampell"), listOf("crutch"), listOf("crutch", "help"), listOf("stampell", "aiut"), listOf("crutch", "assist")),
            "Assistenza per persone con disabilità o mobilità ridotta:\n• RFI Sala Blu (stazioni RFI): 800 90 60 60, da cellulare +39 02 32 32 32\n" +
                "• Trenord: 800 210 955 (tutti i giorni 8:15–19:45) o +39 02 72 49 49 49; prenota preferibilmente 48 ore prima\n" +
                "• FFS (Ticino): 0800 007 102\nNella scheda della stazione trovi ascensori per binario e guasti in corso.",
            "Assistance for people with disabilities or reduced mobility:\n• RFI Sala Blu (RFI stations): 800 90 60 60, from mobiles +39 02 32 32 32\n" +
                "• Trenord: 800 210 955 (daily 8:15–19:45) or +39 02 72 49 49 49; book preferably 48 hours ahead\n" +
                "• SBB (Ticino): 0800 007 102\nThe station screen shows lifts per platform and current faults.",
            "RFI · Sale Blu", "https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/le-informazioni-sull-assistenza-delle-sale-blu-in-un-click.html"),
        Entry("smarriti",
            listOf(listOf("smarrit"), listOf("=perso"), listOf("=persa"), listOf("dimentic"), listOf("=lost"), listOf("oggett", "trov"), listOf("=left", "=my", "=on"), listOf("lasciat"), listOf("forgot"), listOf("scordat")),
            "Oggetti smarriti: avvisa subito il capotreno. Trenord: 02 72 49 49 49, oggetti ai My Link Point di Cadorna e Garibaldi per pochi giorni, poi al Comune di Milano (via Friuli 30, 02 884 53900). " +
                "Trenitalia: servizio ricerca oggetti smarriti e Frecciadesk. Italo: Pronto Italo 06 07 08. FFS/TILO: segnalazione online su lostandfound.sbb.ch. Tutto in Altro → Oggetti smarriti.",
            "Lost property: tell the conductor straight away. Trenord: 02 72 49 49 49, items kept at the Cadorna and Garibaldi My Link Points for a few days, then at the City of Milan office (via Friuli 30). " +
                "Trenitalia: lost items search service and Frecciadesk. Italo: Pronto Italo 06 07 08. SBB/TILO: report online at lostandfound.sbb.ch. Details in More → Lost property.",
            "Trenord · oggetti smarriti", "https://www.trenord.it/assistenza/servizi/oggetti-smarriti/"),
        Entry("sciopero_rimborso",
            listOf(listOf("sciopero", "rimbors"), listOf("scioper", "bigliett"), listOf("strike", "refund"), listOf("strike", "ticket"), listOf("scioper", "rimbors", "bigliett"), listOf("strike", "refund", "ticket")),
            "Sciopero e biglietti: Trenord rimborsa su richiesta entro 30 giorni dallo sciopero. Trenitalia rimborsa dalla proclamazione: " +
                "per Frecce e Intercity fino all'ora di partenza, per i regionali fino alle 24 del giorno prima. " +
                "Nelle fasce garantite (feriali 6–9 e 18–21) circolano i treni dell'elenco ufficiale.",
            "Strikes and tickets: Trenord refunds on request within 30 days of the strike. Trenitalia refunds from the announcement: " +
                "Frecce and Intercity up to departure time, regional trains until midnight of the day before. " +
                "In the guaranteed time bands (weekdays 6–9 and 18–21) the trains on the official list run.",
            "Trenord · in caso di sciopero", "https://www.trenord.it/assistenza/informazioni-utili/in-caso-di-sciopero/"),
        Entry("soppresso",
            listOf(listOf("soppress"), listOf("cancellat"), listOf("cancelled"), listOf("treno", "salt"), listOf("=cancel", "train"), listOf("sopprim")),
            "Treno soppresso: hai diritto al rimborso completo oppure a viaggiare con il primo treno utile per la stessa destinazione. " +
                "Spesso viene attivato un bus sostitutivo: lo trovi nei comunicati (Altro → Scioperi, circolazione e lavori). " +
                "Per sapere se un treno è soppresso dimmi il suo numero.",
            "Cancelled train: you are entitled to a full refund or to travel on the first available train to the same destination. " +
                "A replacement bus is often provided: see the notices (More → Strikes, traffic and works). Tell me the train number to check it.",
            "Trenitalia · diritti dei passeggeri", TI_DIRITTI),
        Entry("coincidenza",
            listOf(listOf("coinciden", "pers"), listOf("=perso", "coinciden"), listOf("missed", "connection"), listOf("cambio", "pers"), listOf("miss", "connection"), listOf("lost", "connection"), listOf("miss", "=change"), listOf("perd", "coinciden"), listOf("miss", "connect")),
            "Coincidenza persa per ritardo: con un unico biglietto hai diritto a proseguire con il primo treno utile senza pagare di più. " +
                "Nelle soluzioni con cambio l'app mostra i minuti per il cambio e avvisa \"coincidenza a rischio\" se il primo treno è in ritardo.",
            "Missed connection because of a delay: with a single ticket you can continue on the first available train at no extra cost. " +
                "For journeys with a change the app shows the minutes to change and warns \"connection at risk\" if the first train is late.",
            "Trenitalia · diritti dei passeggeri", TI_DIRITTI),
        Entry("bagagli",
            listOf(listOf("bagagl"), listOf("valig"), listOf("luggage"), listOf("baggage"), listOf("suitcase"), listOf("left", "luggage")),
            "Bagagli: sui treni si viaggia con i propri bagagli negli appositi spazi, senza costi per l'uso normale; " +
                "devono restare sotto il tuo controllo e non bloccare corridoi e porte. Le grandi stazioni hanno spesso un deposito bagagli a pagamento.",
            "Luggage: you travel with your own bags in the luggage spaces at no cost for normal use; " +
                "they must stay under your control and not block aisles and doors. Large stations often have a paid left-luggage office.",
            "Trenitalia · condizioni di trasporto", "https://www.trenitalia.com/it/informazioni/condizioni-generali-di-trasporto.html"),
        Entry("acquisto",
            listOf(listOf("dove", "compr"), listOf("acquist", "bigliett"), listOf("compr", "bigliett"), listOf("buy", "ticket"), listOf("where", "ticket"), listOf("=pago", "bigliett"), listOf("tobacconist"), listOf("=sold", "ticket"), listOf("online", "ticket"), listOf("tabacc"), listOf("vend", "bigliett")),
            "Biglietti: sui siti e nelle app ufficiali (Trenitalia, Trenord, Italo), alle biglietterie e alle emettitrici in stazione, " +
                "nelle rivendite autorizzate (tabaccherie, edicole). In Altro → Rivendite vicine trovi biglietterie, emettitrici (anche contactless) e rivendite intorno a te.",
            "Tickets: on the official websites and apps (Trenitalia, Trenord, Italo), at ticket offices and machines in the station, " +
                "and at authorised resellers (tobacconists, newsagents). More → Nearby resellers shows ticket offices, machines (also contactless) and resellers near you.",
            "Trenord · dove acquistare", "https://www.trenord.it/biglietti/dove-acquistare/acquista-online/"),
        Entry("abbonamenti",
            listOf(listOf("abbonament"), listOf("season", "ticket"), listOf("=io", "viaggio"), listOf("mensil"), listOf("annual"), listOf("monthly"), listOf("season"), listOf("=pass")),
            "Abbonamenti: Trenord offre mensili e annuali e gli abbonamenti integrati Io Viaggio (treno + mezzi pubblici in Lombardia). " +
                "Trenitalia ha abbonamenti regionali e per le Frecce. Gli abbonati hanno regole di rimborso e bonus per i ritardi proprie.",
            "Season tickets: Trenord offers monthly and annual tickets and the integrated Io Viaggio passes (train + public transport in Lombardy). " +
                "Trenitalia has regional and Frecce passes. Season-ticket holders have their own refund and delay-bonus rules.",
            "Trenord · abbonamenti", "https://www.trenord.it/biglietti/titoli-di-viaggio/abbonamenti/"),
        Entry("malpensa",
            listOf(listOf("malpensa"), listOf("aeroport"), listOf("airport"), listOf("linate"), listOf("orio")),
            "Aeroporti:\n• Malpensa: Malpensa Express da Milano Cadorna e da Milano Centrale, fermate T1 e T2\n" +
                "• Linate: metropolitana M4 (non c'è il treno)\n• Orio al Serio (Bergamo): bus dalla stazione di Bergamo\n" +
                "Chiedimi per esempio \"treni da Milano Cadorna a Malpensa\".",
            "Airports:\n• Malpensa: Malpensa Express from Milano Cadorna and Milano Centrale, stops T1 and T2\n" +
                "• Linate: metro line M4 (no train)\n• Orio al Serio (Bergamo): bus from Bergamo station\n" +
                "Ask me for example \"trains from Milano Cadorna to Malpensa\".",
            "Trenord · Malpensa Express", "https://www.trenord.it/biglietti/titoli-di-viaggio/malpensa-express/"),
        Entry("svizzera",
            listOf(listOf("svizzer"), listOf("ticino"), listOf("lugano"), listOf("transfrontalier"), listOf("arcobaleno"), listOf("switzerland"), listOf("=chf"), listOf("=tilo"), listOf("cross", "border"), listOf("=swiss"), listOf("abbonament", "svizzer"), listOf("=pass", "switzerland"), listOf("season", "switzerland")),
            "Svizzera e TILO: per i viaggi tra Lombardia e Ticino servono biglietti transfrontalieri (Arcobaleno in CHF o Trenord in euro). " +
                "Linee TILO, tariffe e servizi sono in Altro → TILO; per un tragitto chiedimi \"treni da Como a Lugano\".",
            "Switzerland and TILO: trips between Lombardy and Ticino need cross-border tickets (Arcobaleno in CHF or Trenord in euros). " +
                "TILO lines, fares and services are in More → TILO; for a route ask \"trains from Como to Lugano\".",
            "TILO · titoli di trasporto", "https://www.tilo.ch/servizi/titoli-di-trasporto.html"),
        Entry("contatti",
            listOf(listOf("numero", "telefon"), listOf("call", "center"), listOf("contatt"), listOf("phone", "number"), listOf("customer", "service"),
                listOf("assistenza", "client"), listOf("reclam"), listOf("complaint"), listOf("call", "cent"), listOf("contact"), listOf("complain"), listOf("numero", "verde"), listOf("numer", "=italo"), listOf("numer", "trenitalia"), listOf("numer", "trenord")),
            "Contatti:\n• Trenitalia: 892021 (call center)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (assistenza disabili): 800 90 60 60\n" +
                "Per i reclami usa i moduli sui siti ufficiali.",
            "Contacts:\n• Trenitalia: 892021 (call centre)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (disability assistance): 800 90 60 60\n" +
                "For complaints use the forms on the official websites.",
            "Trenitalia · call center", "https://www.trenitalia.com/it/informazioni/i-nostri-call-center.html"),
        Entry("diritti",
            listOf(listOf("diritt"), listOf("=rights"), listOf("regolament"), listOf("=782"), listOf("regulation"), listOf("=right", "assist"), listOf("=rights", "cancel"), listOf("diritt", "soppress"), listOf("diritt", "cancell")),
            "I tuoi diritti (Regolamento UE 2021/782): informazioni sul viaggio, rimborso o riprogrammazione se il ritardo previsto supera 60 minuti, " +
                "indennizzo del 25% (60–119 minuti) o 50% (da 120), assistenza (bevande, pasti, alloggio se necessario), assistenza gratuita per persone con disabilità.",
            "Your rights (EU Regulation 2021/782): travel information, refund or re-routing if the expected delay exceeds 60 minutes, " +
                "compensation of 25% (60–119 minutes) or 50% (120+), assistance (drinks, meals, accommodation if needed), free assistance for people with disabilities.",
            "Trenitalia · Regolamento UE 2021/782", TI_DIRITTI),
        Entry("binario_spiegazione",
            listOf(listOf("binario", "previst"), listOf("binario", "real"), listOf("binario", "blu"), listOf("binario", "ross"), listOf("platform", "change"), listOf("platform", "scheduled"), listOf("platform", "actual"), listOf("platform", "blue"), listOf("platform", "=red"), listOf("cambi", "binario")),
            "Binari nell'app: il binario previsto è quello dell'orario; quello reale (in blu) è confermato dalla stazione. " +
                "Se cambia lo vedi evidenziato in rosso (es. 3 → 5) e, se segui il treno, ricevi una notifica e l'avviso vocale.",
            "Platforms in the app: the scheduled platform comes from the timetable; the actual one (blue) is confirmed by the station. " +
                "A change is shown in red (e.g. 3 → 5) and, if you follow the train, you get a notification and a voice alert.",
        ),
        // ---- Uso dell'app ----
        Entry("app_sveglia",
            listOf(listOf("svegli"), listOf("=alarm"), listOf("wake"), listOf("avvis", "scend"), listOf("dove", "scend"), listOf("=get", "=off"), listOf("allarm", "fermat"), listOf("avvis", "arriv"), listOf("alert", "=when"), listOf("alert", "arriv")),
            "Sveglia per la fermata: apri il treno, tocca la fermata dove scendi e scegli \"Svegliami prima di questa fermata\". " +
                "Suona quando il treno lascia la fermata precedente (o 4 minuti prima); con gli avvisi vocali senti anche la voce.",
            "Stop alarm: open the train, tap the stop where you get off and choose \"Wake me before this stop\". " +
                "It rings when the train leaves the previous stop (or 4 minutes before); with voice alerts you also hear the voice."),
        Entry("app_salgo",
            listOf(listOf("salgo"), listOf("dove", "sal"), listOf("=board", "=where"), listOf("boarding"), listOf("=board", "halfway"), listOf("=board", "stop"), listOf("=board", "station"), listOf("fermat", "salit")),
            "Dove salgo: apri il treno, tocca la fermata dove sali e scegli \"Salgo qui\". Binario, orario e avvisi si riferiscono a quella fermata.",
            "Where I board: open the train, tap the stop where you get on and choose \"I board here\". Platform, time and alerts refer to that stop."),
        Entry("app_offline",
            listOf(listOf("=pdf"), listOf("offline"), listOf("senza", "rete"), listOf("senza", "internet"), listOf("scaric", "orari"), listOf("download"), listOf("stamp"), listOf("without", "internet"), listOf("senza", "connession"), listOf("without", "connection")),
            "Orari senza rete: cerca la tratta e nei risultati tocca l'icona PDF per scaricare l'orario del giorno (andata e ritorno) in Download/Binario. " +
                "L'app ricorda anche da sola gli ultimi orari di ogni tratta cercata.",
            "Timetables offline: search the route and tap the PDF icon in the results to download the day's timetable (outbound and return) to Download/Binario. " +
                "The app also remembers the latest times of every route you searched."),
        Entry("app_voce",
            listOf(listOf("=voce"), listOf("vocal"), listOf("vedent"), listOf("ciec"), listOf("=blind"), listOf("talkback"), listOf("ipovedent"), listOf("visually", "impaired"), listOf("=voice")),
            "Avvisi vocali: in Impostazioni → Accessibilità scegli \"Tutti\" o \"Solo fermata imminente\". " +
                "Per chiedere a voce tocca il microfono qui sotto, oppure tieni premuta l'icona di Binario e scegli \"Chiedi a voce\".",
            "Voice alerts: in Settings → Accessibility choose \"All\" or \"Only upcoming stop\". " +
                "To ask by voice tap the microphone below, or long-press the Binario icon and choose \"Ask by voice\"."),
        Entry("app_sordi",
            listOf(listOf("=sordo"), listOf("=sorda"), listOf("=sordi"), listOf("ipoudent"), listOf("=deaf"), listOf("vibraz"), listOf("=flash"), listOf("hearing"), listOf("vibrat")),
            "Avvisi per persone sorde: in Impostazioni → Accessibilità attiva vibrazione forte (uno schema per ogni avviso) e lampeggio del flash.",
            "Alerts for deaf people: in Settings → Accessibility turn on strong vibration (one pattern per alert) and the flashlight."),
        Entry("app_widget",
            listOf(listOf("widget"), listOf("widget", "preferit"), listOf("widget", "favourit"), listOf("widget", "favorit")),
            "Widget: tieni premuto su uno spazio vuoto della Home → Widget → Binario. Ci sono Tragitto, Treno, Stazione e Preferiti; tocca il titolo per cambiarlo.",
            "Widgets: long-press an empty spot on the Home screen → Widgets → Binario. There are Route, Train, Station and Favourites; tap the title to change it."),
        Entry("app_segui",
            listOf(listOf("segui"), listOf("=follow"), listOf("notifica", "fiss"), listOf("tracking"), listOf("follow"), listOf("pinned"), listOf("persistent"), listOf("=seguo"), listOf("come", "=seguo"), listOf("segui", "notific"), listOf("follow", "notific")),
            "Seguire un treno: apri il treno e tocca \"Segui\": una notifica fissa si aggiorna ogni minuto e avvisa di cambi di binario e ritardi.",
            "Following a train: open the train and tap \"Follow\": a pinned notification updates every minute and warns of platform changes and delays."),
        Entry("puntualita",
            listOf(listOf("puntualit"), listOf("punctual"), listOf("statistic"), listOf("puntual"), listOf("=how", "punctual")),
            "Puntualità: in Altro → Puntualità trovi le statistiche mensili, con regionali confrontati con regionali e alta velocità a parte, " +
                "e la puntualità di ogni stazione e treno (dati TrovaTreno.it).",
            "Punctuality: More → Punctuality has monthly statistics, with regional trains compared with regional ones and high speed separately, " +
                "plus every station and train (TrovaTreno.it data)."),
        // ---- Domande frequenti aggiunte nella 0.1.22 ----
        Entry("wifi",
            listOf(listOf("wifi"), listOf("=wi", "=fi"), listOf("internet", "bordo"), listOf("internet", "board"), listOf("=prese"), listOf("=presa"),
                listOf("ricaric"), listOf("socket"), listOf("charg"), listOf("internet")),
            "Wi-Fi e prese: su Frecce e Italo il Wi-Fi a bordo è gratuito e ci sono prese elettriche ai posti. Sui regionali di norma il Wi-Fi non c'è " +
                "e le prese ci sono solo su alcuni treni nuovi. In Svizzera molte stazioni FFS hanno Wi-Fi gratuito.",
            "Wi-Fi and sockets: on Frecce and Italo on-board Wi-Fi is free and there are power sockets at the seats. Regional trains usually have no Wi-Fi " +
                "and only some new trains have sockets. In Switzerland many SBB stations have free Wi-Fi.",
            "Trenitalia · Frecciarossa", "https://www.trenitalia.com/it/frecciarossa.html"),
        Entry("posto",
            listOf(listOf("prenot", "posto"), listOf("posto", "assegn"), listOf("posto", "finestr"), listOf("posto", "seder"), listOf("scegl", "posto"),
                listOf("posto", "garant"), listOf("=seat"), listOf("seats"), listOf("reserv", "seat"), listOf("=seat", "guarant")),
            "Posto a sedere: su Frecce, Intercity e Italo il posto è assegnato con il biglietto e lo puoi scegliere all'acquisto (finestrino, corridoio…). " +
                "Sui regionali (Trenord, Trenitalia Regionale, TILO) non si prenota: ci si siede dove c'è posto.",
            "Seats: on Frecce, Intercity and Italo the seat is assigned with the ticket and you can choose it when buying (window, aisle…). " +
                "Regional trains (Trenord, Trenitalia Regional, TILO) have no reservations: you sit wherever there is room.",
            "Trenitalia · condizioni di trasporto", "https://www.trenitalia.com/it/informazioni/condizioni-generali-di-trasporto.html"),
        Entry("prima_classe",
            listOf(listOf("prima", "classe"), listOf("first", "class"), listOf("=1st", "class"), listOf("business"), listOf("executive"), listOf("=premium")),
            "Prima classe: sui Frecciarossa ci sono i livelli Standard, Premium, Business ed Executive; su Italo Smart, Comfort, Prima e Club Executive. " +
                "Sui regionali Trenord la 1ª classe c'è su molti treni, con un supplemento di 2,80 € a corsa (31 € al mese, 310 € all'anno con l'abbonamento). " +
                "Nei risultati della ricerca vedi i prezzi in 1ª classe con il selettore «1ª classe».",
            "First class: Frecciarossa trains have Standard, Premium, Business and Executive levels; Italo has Smart, Comfort, Prima and Club Executive. " +
                "Many Trenord regional trains have 1st class, with a supplement of €2.80 per trip (€31 a month, €310 a year with a pass). " +
                "In the search results you can see 1st-class prices with the \"1st class\" selector.",
            "Trenitalia · Frecciarossa", "https://www.trenitalia.com/it/frecciarossa.html"),
        Entry("validita",
            listOf(listOf("validit"), listOf("=validity"), listOf("=validity", "ticket"), listOf("validit", "bigliett"), listOf("quanto", "dur", "bigliett"), listOf("scadenz"), listOf("vale", "bigliett"), listOf("dur", "bigliett"),
                listOf("how", "long", "valid"), listOf("valid", "long"), listOf("expir"), listOf("valid", "=day"), listOf("valid", "=all"), listOf("durat", "ticket"), listOf("durat", "bigliett")),
            "Validità del biglietto: dipende dal tipo. Area STIBM (Milano e dintorni): 75 minuti per 2 zone, 90 minuti in città, di più con più zone. " +
                "Biglietti transfrontalieri Arcobaleno/Trenord: 4 ore per tutto il viaggio. I regionali digitali valgono per il giorno o il treno indicato, " +
                "quelli cartacei si convalidano prima di salire. Frecce e Italo: valgono per il treno prenotato.",
            "Ticket validity: it depends on the ticket. STIBM area (Milan and surroundings): 75 minutes for 2 zones, 90 minutes in the city, longer with more zones. " +
                "Arcobaleno/Trenord cross-border tickets: 4 hours for the whole trip. Digital regional tickets are valid for the day or train shown; " +
                "paper ones must be validated before boarding. Frecce and Italo: valid for the booked train.",
            "Trenord · condizioni di trasporto", "https://www.trenord.it/assistenza/informazioni-utili/condizioni-di-trasporto/"),
        Entry("parcheggio",
            listOf(listOf("parchegg"), listOf("posteggi"), listOf("parking"), listOf("=park")),
            "Parcheggi: molte stazioni hanno un parcheggio auto (spesso a pagamento) e rastrelliere o velostazioni per le bici. " +
                "L'app non ha ancora l'elenco dei parcheggi: dalla scheda della stazione apri la mappa e cerca «parcheggio».",
            "Parking: many stations have a car park (often paid) and bike racks or bike stations. " +
                "The app does not list car parks yet: open the map from the station screen and search for \"parking\".",
        ),
        Entry("notte",
            listOf(listOf("nott"), listOf("night"), listOf("cuccett"), listOf("vagon", "letto"), listOf("sleeper"), listOf("couchette"), listOf("nightjet"), listOf("night", "train")),
            "Treni notte: Trenitalia ha gli Intercity Notte (per esempio verso il Sud Italia e la Sicilia); i Nightjet ÖBB collegano l'Italia con Austria e Germania; " +
                "in Ticino c'è il servizio notturno TILO Pigiama in alcune notti. Cerca la tratta con l'orario serale nella ricerca soluzioni.",
            "Night trains: Trenitalia runs Intercity Notte trains (for example to southern Italy and Sicily); ÖBB Nightjets link Italy with Austria and Germany; " +
                "in Ticino there is the TILO Pigiama night service on some nights. Search the route with an evening time.",
            "Trenitalia · Intercity", "https://www.trenitalia.com/it/intercity.html"),
        Entry("italo",
            listOf(listOf("=italo", "cos"), listOf("=italo", "chi"), listOf("=italo", "offert"), listOf("=italo", "bigliett"), listOf("=italo", "funzion"),
                listOf("=italo", "=what"), listOf("=italo", "train"), listOf("=italo", "treni"), listOf("=italo", "frecciaross"), listOf("=italo", "ticket"),
                listOf("=italo", "offer"), listOf("=italo", "work"), listOf("=ntv"), listOf("=italo", "discount")),
            "Italo (NTV) è l'impresa privata dell'alta velocità, sulle linee AV tra Torino, Milano, Venezia, Bologna, Firenze, Roma e Napoli. " +
                "I biglietti si comprano su italotreno.com, in app, alle biglietterie Italo e alle emettitrici in stazione; i livelli sono Smart, Comfort, Prima e Club Executive. " +
                "In Binario trovi i treni Italo nelle soluzioni e in tempo reale. Pronto Italo: 06 07 08.",
            "Italo (NTV) is the private high-speed operator, on the high-speed lines between Turin, Milan, Venice, Bologna, Florence, Rome and Naples. " +
                "Tickets are sold on italotreno.com, in the app, at Italo ticket offices and machines in stations; levels are Smart, Comfort, Prima and Club Executive. " +
                "Binario shows Italo trains in the solutions and in real time. Pronto Italo: 06 07 08.",
            "Italo", "https://www.italotreno.com/it"),
        Entry("cibo",
            listOf(listOf("mangi"), listOf("=bar"), listOf("ristor"), listOf("cibo"), listOf("bevand"), listOf("food"), listOf("=eat"), listOf("restaurant"),
                listOf("bistro"), listOf("snack"), listOf("drink"), listOf("trolley"), listOf("carrell")),
            "Cibo e bevande: su tutti i treni puoi mangiare e bere quello che porti. Sulle Frecce c'è il bar/FRECCIABistrò, su Italo snack e bevande; " +
                "sui regionali non c'è servizio di ristorazione.",
            "Food and drink: on every train you can eat and drink what you bring. Frecce have a bar/FRECCIABistrò, Italo offers snacks and drinks; " +
                "regional trains have no catering.",
            "Trenitalia · Frecciarossa", "https://www.trenitalia.com/it/frecciarossa.html"),
        Entry("fumo",
            listOf(listOf("=fumo"), listOf("fumar"), listOf("sigarett"), listOf("svap"), listOf("smok"), listOf("=vape"), listOf("vaping"), listOf("cigarett"), listOf("=fuma"), listOf("fumat")),
            "È vietato fumare su tutti i treni e nelle aree chiuse delle stazioni, anche con la sigaretta elettronica a bordo. Chi fuma rischia una sanzione.",
            "Smoking is forbidden on all trains and in enclosed station areas, e-cigarettes on board included. Smokers risk a fine.",
            "Trenitalia · condizioni di trasporto", "https://www.trenitalia.com/it/informazioni/condizioni-generali-di-trasporto.html"),
        Entry("sconti",
            listOf(listOf("scont"), listOf("offert", "econom"), listOf("carta", "freccia"), listOf("cartafreccia"), listOf("riduz"), listOf("discount"),
                listOf("=young"), listOf("senior"), listOf("anzian"), listOf("over", "=60"), listOf("cheap"), listOf("reduct"), listOf("=piu", "=60"), listOf("=60", "anni"), listOf("=60", "=years")),
            "Sconti: Trenitalia ha le offerte Economy e Super Economy (posti limitati), sconti per giovani e over 60 con CartaFRECCIA e offerte per gruppi. " +
                "Italo ha le tariffe Low Cost ed Economy e il programma Italo Più. In Lombardia Trenord ha abbonamenti ridotti under 26 e over 65 e lo sconto famiglia " +
                "Io Viaggio in Famiglia. Il calendario «Prezzi migliori» dell'app mostra i prezzi più bassi per fascia oraria.",
            "Discounts: Trenitalia has Economy and Super Economy fares (limited seats), discounts for young people and over-60s with CartaFRECCIA, and group offers. " +
                "Italo has Low Cost and Economy fares and the Italo Più programme. In Lombardy Trenord has reduced passes for under-26s and over-65s and the " +
                "Io Viaggio in Famiglia family discount. The app's \"Best prices\" calendar shows the lowest prices by time of day.",
            "Trenitalia · offerte", "https://www.trenitalia.com/it/offerte.html"),
        Entry("gruppi",
            listOf(listOf("grupp"), listOf("comitiv"), listOf("scolast"), listOf("=gita"), listOf("group"), listOf("school", "trip"), listOf("siamo", "person"), listOf("group", "discount"), listOf("grupp", "scont")),
            "Gruppi: Trenitalia e Italo hanno offerte per gruppi (di solito da 10 persone in su, da chiedere in anticipo); Trenord ha biglietti per gruppi e scolaresche. " +
                "Condizioni e moduli sono sui siti delle aziende.",
            "Groups: Trenitalia and Italo have group offers (usually from 10 people, to be requested in advance); Trenord has tickets for groups and school classes. " +
                "Conditions and forms are on the operators' websites.",
            "Trenitalia · offerte", "https://www.trenitalia.com/it/offerte.html"),
        Entry("minori",
            listOf(listOf("minor"), listOf("=da", "=solo"), listOf("non", "accompagn"), listOf("=solo", "bambin"), listOf("alone"), listOf("unaccompan"), listOf("child", "alone"), listOf("alone", "=son"), listOf("alone", "=daughter")),
            "Minori che viaggiano da soli: le regole cambiano da un'azienda all'altra. In generale i ragazzi più grandi possono viaggiare da soli con un biglietto valido, " +
                "mentre i bambini piccoli devono essere accompagnati da un adulto. Prima di partire controlla le condizioni di trasporto di Trenord, Trenitalia o Italo.",
            "Minors travelling alone: the rules differ between operators. In general older children can travel alone with a valid ticket, " +
                "while young children must be accompanied by an adult. Before travelling check the conditions of carriage of Trenord, Trenitalia or Italo.",
            "Trenitalia · condizioni di trasporto", "https://www.trenitalia.com/it/informazioni/condizioni-generali-di-trasporto.html"),
        Entry("digitale",
            listOf(listOf("digital"), listOf("stamp", "bigliett"), listOf("telefon", "bigliett"), listOf("cellular", "bigliett"), listOf("check", "=in"),
                listOf("elettronic", "bigliett"), listOf("=e", "ticket"), listOf("=print"), listOf("phone", "ticket"), listOf("mobile", "ticket"), listOf("electronic", "ticket"), listOf("checkin"), listOf("=qr", "telefon"), listOf("=qr", "phone"), listOf("=qr", "code"), listOf("=qr", "bigliett"), listOf("=qr", "ticket")),
            "Biglietti digitali: non serve stamparli, basta mostrarli sul telefono (PDF, app o codice QR) con la batteria carica. " +
                "Alcuni biglietti richiedono il check-in o l'attivazione prima di salire: è scritto sul biglietto e nell'app dell'azienda.",
            "Digital tickets: no need to print them, just show them on your phone (PDF, app or QR code) with enough battery. " +
                "Some tickets require check-in or activation before boarding: it is stated on the ticket and in the operator's app.",
            "Trenitalia · condizioni di trasporto", "https://www.trenitalia.com/it/informazioni/condizioni-generali-di-trasporto.html"),
        Entry("sicurezza",
            listOf(listOf("emergenz"), listOf("rubat"), listOf("=furto"), listOf("borsegg"), listOf("polizi"), listOf("polfer"), listOf("sento", "male"),
                listOf("malore"), listOf("emergenc"), listOf("stolen"), listOf("theft"), listOf("pickpocket"), listOf("police"), listOf("=sick"), listOf("molest"), listOf("harass"), listOf("medic"), listOf("doctor")),
            "Emergenza o sicurezza: chiama il 112, il numero unico di emergenza. A bordo usa il citofono o il pulsante di emergenza e avvisa il capotreno; " +
                "in stazione c'è la Polizia Ferroviaria (Polfer). Per un furto fai denuncia alla Polfer o ai Carabinieri e blocca carte e telefono. " +
                "Il defibrillatore più vicino è nella Home.",
            "Emergency or safety: call 112, the single emergency number. On board use the intercom or emergency button and tell the conductor; " +
                "in stations there is the Railway Police (Polfer). For a theft report it to the Polfer or Carabinieri and block your cards and phone. " +
                "The nearest defibrillator is on the Home screen.",
        ),
        Entry("pagamento",
            listOf(listOf("pagar", "cart"), listOf("contactless"), listOf("contant"), listOf("pagament"), listOf("satispay"), listOf("bancomat"), listOf("=card"),
                listOf("=cash"), listOf("apple", "pay"), listOf("google", "pay"), listOf("payment"), listOf("=pay"), listOf("accett", "contant"), listOf("=card", "ticket")),
            "Pagamenti: alle emettitrici si paga con carta (anche contactless) e spesso in contanti; nelle app e sui siti con carta, PayPal e portafogli digitali " +
                "secondo l'azienda; alle biglietterie anche in contanti. Su alcune linee e nelle metropolitane si può pagare in contactless direttamente ai validatori.",
            "Payments: ticket machines take cards (also contactless) and often cash; apps and websites take cards, PayPal and digital wallets depending on the operator; " +
                "ticket offices also take cash. On some lines and metros you can tap a contactless card directly at the validators.",
        ),
        Entry("bus_sostitutivi",
            listOf(listOf("sostitutiv"), listOf("replacement"), listOf("instead"), listOf("=bus", "posto", "=treno"), listOf("replacement", "=bus")),
            "Bus sostitutivi: quando i treni sono sostituiti da autobus, in Stazioni → Bus sostitutivi trovi fermate, orari e fonti per la tua stazione; " +
                "i comunicati sono in Notizie. Di solito la fermata del bus è segnalata davanti alla stazione.",
            "Replacement buses: when trains are replaced by buses, Stations → Replacement buses shows stops, times and sources for your station; " +
                "notices are in News. The bus stop is usually signposted in front of the station.",
        ),
        Entry("lingua",
            listOf(listOf("lingua"), listOf("language"), listOf("ingles"), listOf("spagnol"), listOf("giappones"), listOf("=italian"), listOf("=spanish"), listOf("japanese")),
            "Lingua: tocca la bandierina in alto nella Home oppure Altro → Impostazioni → Lingua. Ci sono italiano, inglese, cinese, tedesco, francese, spagnolo e giapponese; " +
                "anche la voce cambia lingua.",
            "Language: tap the flag at the top of the Home screen or go to More → Settings → Language. Italian, English, Chinese, German, French, Spanish and Japanese " +
                "are available; the voice changes language too.",
        ),
        Entry("preferiti",
            listOf(listOf("preferit"), listOf("favourit"), listOf("favorit"), listOf("salv", "stazion"), listOf("salv", "tratt"), listOf("=save", "station"), listOf("=save", "route")),
            "Preferiti: tocca la stellina ★ su un treno, sul tabellone di una stazione o su una tratta. Li ritrovi nelle schede Treni e Stazioni, in Rapido " +
                "(recenti e preferite) e nel widget Preferiti; puoi anche metterli tra i Tasti rapidi della Home con +.",
            "Favourites: tap the star ★ on a train, a station board or a route. You find them in the Trains and Stations tabs, in Quick (recent and favourites) " +
                "and in the Favourites widget; you can also add them to the Home shortcuts with +.",
        ),
        Entry("cercare_orari",
            listOf(listOf("cerc", "orari"), listOf("trov", "orari"), listOf("cerc", "treno"), listOf("cerc", "soluz"), listOf("search", "timetabl"),
                listOf("=find", "train"), listOf("search", "journey"), listOf("=use", "search"), listOf("=ricerca"), listOf("=find", "timetabl")),
            "Cercare un orario: nella scheda Cerca scegli partenza e arrivo, data e ora (e andata e ritorno se serve), poi tocca Cerca. " +
                "Nei risultati vedi orari, cambi, prezzi e ritardi; tocca un treno per fermate e binari. Puoi anche chiedermi \"treni da Varese a Milano\".",
            "Searching a timetable: in the Search tab choose departure and arrival, date and time (and return if needed), then tap Search. " +
                "The results show times, changes, prices and delays; tap a train for stops and platforms. You can also ask me \"trains from Varese to Milano\".",
        ),
        Entry("biglietto_bordo",
            listOf(listOf("bordo", "bigliett"), listOf("bigliett", "capotren"), listOf("bigliett", "controllor"), listOf("compr", "bigliett", "=treno"),
                listOf("=on", "board", "ticket"), listOf("onboard"), listOf("surcharge"), listOf("sovrapprezz"), listOf("conductor", "ticket"), listOf("=buy", "ticket", "train"), listOf("onboard", "ticket"), listOf("=buy", "=on", "board"), listOf("bigliett", "=sul", "=treno"), listOf("fare", "bigliett", "=treno")),
            "Biglietto a bordo: sui regionali il biglietto si compra prima di salire. Se in stazione non c'è modo di acquistarlo (biglietteria chiusa, emettitrice guasta), " +
                "avvisa subito il capotreno appena sali: di norma puoi regolarizzare con un sovrapprezzo, ma le regole cambiano da un'azienda all'altra. " +
                "Le condizioni di trasporto indicano quando è possibile e quanto costa.",
            "Ticket on board: on regional trains you buy the ticket before boarding. If the station has no way to buy one (office closed, machine broken), " +
                "tell the conductor as soon as you board: usually you can pay with a surcharge, but rules differ between operators. " +
                "The conditions of carriage say when this is possible and how much it costs.",
            "Trenord · sanzioni", "https://www.trenord.it/assistenza/servizi/sanzioni/"),
    )

    /** Voce per id (es. "bus_sostitutivi"). */
    fun byId(id: String): Entry? = entries.firstOrNull { it.id == id }
}
