package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.CrossBorderFares
import com.binario.treni.data.Station
import com.binario.treni.data.Stibm
import com.binario.treni.data.TrenordFares
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** "Quanto costa il tuo abbonamento Trenord": da A a B, tutte le tipologie di biglietto e abbonamento. */
@Composable
fun FaresScreen(vm: MainViewModel, onBack: () -> Unit, onStibm: (String) -> Unit, onMalpensa: (String) -> Unit = {}) {
    val ctx = LocalContext.current
    var from by remember { mutableStateOf(vm.from) }
    var to by remember { mutableStateOf(vm.to) }
    var picking by remember { mutableStateOf<Int?>(null) }
    var result by remember { mutableStateOf<TrenordFares.Lookup?>(null) }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }

    // Da o per la Svizzera non vale la tariffa regionale lombarda: niente fascia chilometrica
    val swissA = from?.let { com.binario.treni.data.CrossBorderFares.isSwissStation(it) } ?: false
    val swissB = to?.let { com.binario.treni.data.CrossBorderFares.isSwissStation(it) } ?: false
    val abroad = swissA || swissB

    LaunchedEffect(from?.id, to?.id) {
        val a = from; val b = to
        result = null; failed = false
        if (a == null || b == null || a.id == b.id || abroad) return@LaunchedEffect
        loading = true
        result = withContext(Dispatchers.IO) { runCatching { TrenordFares.lookup(vm.store, a, b) }.getOrNull() }
        failed = result == null
        loading = false
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Quanto costa il tuo abbonamento"), onBack)
        LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
            item {
                WhiteCard {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                StationField(from?.name, tx("Partenza")) { picking = 0 }
                                Spacer(Modifier.height(6.dp))
                                StationField(to?.name, tx("Arrivo")) { picking = 1 }
                            }
                            IconButton({ val f = from; from = to; to = f }) { Icon(Icons.Filled.SwapVert, tx("Inverti"), tint = Green) }
                        }
                        Text(tx("Tariffa regionale Trenord (Lombardia) per fascia chilometrica, in vigore dal") + " " + TrenordFares.VALID_FROM + ".",
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            if (abroad && from != null && to != null) item { CrossBorderCard(from!!.name, to!!.name, swissA && swissB) }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 12.dp), color = Green) }
            if (failed && !abroad) item { MessageBox(tx("Non riesco a calcolare la distanza tra queste stazioni. Controlla la connessione o scegli stazioni lombarde.")) }
            // Da o per l'aeroporto di Malpensa: serve la tariffa aeroportuale Malpensa Express
            val fa = from; val fb = to
            if (fa != null && fb != null && (com.binario.treni.data.MalpensaFares.isMalpensa(fa.name) || com.binario.treni.data.MalpensaFares.isMalpensa(fb.name))) {
                val other = if (com.binario.treni.data.MalpensaFares.isMalpensa(fa.name)) fb.name else fa.name
                val mxp = com.binario.treni.data.MalpensaFares.forStation(other)
                item {
                    WhiteCard(onClick = { onMalpensa(other) }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(tx("Aeroporto di Malpensa: tariffa Malpensa Express"), fontWeight = FontWeight.Bold, color = Green)
                            if (mxp.isEmpty()) {
                                Text(tx("Per questa stazione non c'è una tariffa aeroportuale diretta. Tocca per tutte le tariffe e le regole."), fontSize = 13.sp)
                            } else mxp.forEach { o ->
                                Text(
                                    o.name + (if (o.via.isNotBlank()) " (" + tx(o.via) + ")" else "") + ": " + Stibm.eur(o.single) + " " + tx("corsa semplice") + " · " +
                                        Stibm.eur(o.month2) + " " + tx("mensile 2ª cl.") + " · " + Stibm.eur(o.month1) + " " + tx("mensile 1ª cl."),
                                    fontSize = 13.sp,
                                )
                            }
                            Text(tx("I prezzi qui sotto (tariffa regionale) non valgono da o per l'aeroporto. Tocca per tutte le tariffe e le limitazioni."),
                                color = LateRed, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
            // Viaggio tutto dentro l'area STIBM: vale la tariffa integrata
            val sa = from?.let { Stibm.find(it.name) }
            val sb = to?.let { Stibm.find(it.name) }
            if (sa != null && sb != null && !sa.interchangeOnly && !sb.interchangeOnly) {
                item {
                    WhiteCard(onClick = { onStibm(from?.name ?: "") }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(tx("Viaggio dentro l'area STIBM"), fontWeight = FontWeight.Bold, color = Green)
                            Text(tx("Tra queste due stazioni si usa il biglietto integrato STIBM (vale anche su metro, tram e bus):") + " " +
                                Stibm.fare(sa.zone, sb.zone, false).label + ". " + tx("Tocca per prezzi e regole."), fontSize = 13.sp)
                        }
                    }
                }
            }
            val r = result
            if (r != null) {
                val b = r.band
                item {
                    WhiteCard {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(b.label, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green)
                                Spacer(Modifier.width(8.dp))
                                Text(tx("fascia chilometrica"), modifier = Modifier.padding(bottom = 4.dp))
                            }
                            Text(r.note, color = if (r.exact) Muted else LateRed, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    WhiteCard {
                        CardTitle(tx("Abbonamenti"))
                        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                            FareHeader()
                            FareLine(tx("Settimanale"), b.week2, b.week1)
                            FareLine(tx("Mensile"), b.month2, b.month1)
                            FareLine(tx("Annuale"), b.year2, b.year1)
                            val cities = listOfNotNull(from?.name?.let { TrenordFares.trenocittaCity(it) }, to?.name?.let { TrenordFares.trenocittaCity(it) }).distinct()
                            cities.forEach { c ->
                                TrenordFares.trenocitta(b, c)?.let { (first, second) ->
                                    FareLine(tx("Trenocittà mensile") + " · " + c, second, first)
                                }
                            }
                            Text(
                                (if (cities.isNotEmpty()) tx("Trenocittà: treno più mezzi urbani della città indicata. ") else "") +
                                    tx("Abbonamenti sulla tessera Io Viaggio (10 €, valida 4 anni). In famiglia: 2° figlio minorenne −20%, dal 3° gratis (Io Viaggio in Famiglia)."),
                                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                            )
                        }
                    }
                }
                item {
                    WhiteCard {
                        CardTitle(tx("Biglietti"))
                        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                            FareHeader()
                            FareLine(tx("Ordinario adulti"), b.ord2, b.ord1)
                            FareLine(tx("Ragazzi 4–14 anni"), b.kid2, b.kid1)
                            FareLine(tx("Senior"), b.senior2, b.senior1)
                            FareLine(tx("Carnet 10 viaggi"), b.carnet2, b.carnet1)
                            Text(tx("Bambini sotto i 4 anni gratis; ragazzi 4–14 gratis se accompagnati da un familiare adulto con biglietto."),
                                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                }
            }
            item {
                WhiteCard {
                    CardTitle(tx("Io Viaggio Ovunque (tutti i treni e mezzi pubblici)"))
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                        Text(tx("In tutta la Lombardia"), fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        TrenordFares.IVOL.forEach { (k, v) -> SimpleFare(tx(k), v) }
                        Text(tx("In provincia, mensile"), fontWeight = FontWeight.Medium, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                        TrenordFares.IVOP.forEach { (k, v) -> SimpleFare(k, v) }
                        Text(tx("Supplemento 1ª classe:") + " " + Stibm.eur(TrenordFares.FIRST_CLASS_TRIP) + " " + tx("a viaggio") + " · " +
                            Stibm.eur(TrenordFares.FIRST_CLASS_MONTH_IVOL) + " " + tx("al mese") + " · " + Stibm.eur(TrenordFares.FIRST_CLASS_YEAR_IVOL) + " " +
                            tx("all'anno (Io Viaggio Ovunque in Lombardia)") + ". " + tx("Bici sulle linee che escono dalla Lombardia: 3,50 €."),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
            item {
                Row(Modifier.padding(horizontal = 8.dp)) {
                    TextButton({ openUrl(ctx, TrenordFares.SOURCE_PDF) }) { Text(tx("Tariffario ufficiale"), color = Green) }
                    TextButton({ openUrl(ctx, TrenordFares.SOURCE_PAGE) }) { Text(tx("Abbonamenti Trenord"), color = Green) }
                }
            }
        }
    }

    picking?.let { which ->
        StationPickerDialog(if (which == 0) tx("Stazione di partenza") else tx("Stazione di arrivo"), { picking = null }) { s: Station ->
            if (which == 0) from = s else to = s
            picking = null
        }
    }
}

@Composable
private fun FareHeader() {
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Spacer(Modifier.weight(1f))
        Text(tx("2ª cl."), color = Muted, fontSize = 12.sp, modifier = Modifier.width(78.dp))
        Text(tx("1ª cl."), color = Muted, fontSize = 12.sp, modifier = Modifier.width(78.dp))
    }
}

@Composable
private fun FareLine(label: String, second: Double, first: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(Stibm.eur(second), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.width(78.dp))
        Text(Stibm.eur(first), color = Muted, fontSize = 14.sp, modifier = Modifier.width(78.dp))
    }
}

@Composable
private fun SimpleFare(label: String, value: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(Stibm.eur(value), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

/** Viaggio da o per la Svizzera: biglietto transfrontaliero (Trenord in euro, Arcobaleno in franchi), non la tariffa lombarda. */
@Composable
private fun CrossBorderCard(a: String, b: String, bothSwiss: Boolean) {
    val ctx = LocalContext.current
    val cb = com.binario.treni.data.CrossBorderFares
    WhiteCard {
        Column(Modifier.padding(16.dp)) {
            Text(if (bothSwiss) tx("Viaggio in Svizzera") else tx("Viaggio Italia ⇄ Svizzera: biglietto transfrontaliero"),
                fontWeight = FontWeight.Bold, color = Green, fontSize = 16.sp)
            Text(
                if (bothSwiss) tx("Tra due stazioni svizzere valgono le tariffe Arcobaleno (Ticino) o FFS: le fasce chilometriche Trenord non si applicano.")
                else tx("La tariffa regionale lombarda non vale oltre confine. Il prezzo somma la tratta lombarda (fasce chilometriche Trenord) e la tratta ticinese (zone Arcobaleno): Trenord lo vende in euro, Arcobaleno in franchi."),
                fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
            )
            if (!bothSwiss) {
                val eur = cb.findEur(a, b)
                if (eur != null) {
                    Text(tx("Prezzo Trenord (corsa semplice adulti)"), fontWeight = FontWeight.Medium, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
                    FareHeader()
                    FareLine(eur.a + " ⇄ " + eur.b, eur.second, eur.first)
                    Text(tx("Verificato sul sito Trenord il") + " " + eur.checked + ".", color = Muted, fontSize = 12.sp)
                } else {
                    Text(tx("Per questa tratta Trenord non pubblica una tabella di prezzi: il prezzo esatto in euro è sul negozio online Trenord."),
                        color = LateRed, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
                val sbb = cb.findSbb(a, b)
                if (sbb != null) {
                    Text(tx("Prezzo FFS/SBB (corsa semplice adulti)"), fontWeight = FontWeight.Medium, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
                    Text(tx("2ª classe") + " CHF " + String.format(java.util.Locale.ITALY, "%.2f", sbb.second) + " (" + CrossBorderFares.eur(sbb.second) + ")" +
                        " · " + tx("1ª classe") + " CHF " + String.format(java.util.Locale.ITALY, "%.2f", sbb.first) + " (" + CrossBorderFares.eur(sbb.first) + ")",
                        fontSize = 13.sp)
                    Text(tx("Letto su sbb.ch il") + " " + sbb.checked + ".", color = Muted, fontSize = 12.sp)
                }
                val chf = cb.find(a, b)
                if (chf != null) {
                    Text(tx("Prezzo Arcobaleno (2ª classe, corsa semplice):") + " CHF " + String.format(java.util.Locale.ITALY, "%.2f", chf.chf) + " (" + CrossBorderFares.eur(chf.chf) + ")" +
                        " · " + tx("metà prezzo") + " CHF " + String.format(java.util.Locale.ITALY, "%.2f", chf.halfChf) + " (via " + chf.via + ")",
                        fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
                Text(tx("Corsa semplice valida 4 ore per l'intero percorso (in Italia dalla convalida). Abbonamenti transfrontalieri mensili: in Italia dal 1° del mese, solo su tessera Io Viaggio; in Ticino 30 giorni dall'acquisto."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
            Row(Modifier.padding(top = 6.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
                if (!bothSwiss) TextButton({ openUrl(ctx, cb.TRENORD_STORE) }) { Text(tx("Prezzo sul sito Trenord"), color = Green) }
                TextButton({ openUrl(ctx, cb.ARCOBALENO_CALC) }) { Text(tx("Calcolatore Arcobaleno"), color = Green) }
                if (!bothSwiss) TextButton({ openUrl(ctx, cb.ARCOBALENO_PASSES) }) { Text(tx("Abbonamenti transfrontalieri"), color = Green) }
            }
        }
    }
}
