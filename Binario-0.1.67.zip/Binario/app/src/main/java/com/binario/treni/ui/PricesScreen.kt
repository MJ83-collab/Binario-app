package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.SearchFilter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.TimeZone

private fun tr(a: String, b: String) = I18n.tr(a, b)

/** Fasce orarie del calendario prezzi. */
private val SLOTS = listOf(Triple(6, 12, "Mattina" to "Morning"), Triple(12, 18, "Pomeriggio" to "Afternoon"), Triple(18, 24, "Sera" to "Evening"))

/**
 * Prezzi migliori per giorno e fascia oraria (come i calendari prezzi delle app di viaggio): per i prossimi 7 giorni,
 * il prezzo più basso del mattino, del pomeriggio e della sera. Toccando una casella si cercano le soluzioni di quella fascia.
 */
@Composable
fun PricesScreen(vm: MainViewModel, onBack: () -> Unit, onResults: () -> Unit = onBack) {
    val from = vm.from
    val to = vm.to
    val rome = remember { TimeZone.getTimeZone("Europe/Rome") }
    var filter by remember { mutableStateOf(if (vm.filter == SearchFilter.REGIONAL) SearchFilter.REGIONAL else SearchFilter.FRECCE) }
    val start = remember { Fmt.midnight(maxOf(vm.date, System.currentTimeMillis())) }
    val days = remember(start) { (0 until 7).map { Fmt.midnight(start + it * 86_400_000L + 3 * 3_600_000L) } }
    // prezzo minimo per (giorno, fascia): assente = in caricamento; -1 = nessuna soluzione con prezzo; -2 = errore di rete
    val cells = remember(filter) { mutableStateMapOf<Pair<Int, Int>, Double>() }
    var done by remember(filter) { mutableIntStateOf(0) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(filter, from?.id, to?.id, reload, vm.pax) {
        if (from == null || to == null) return@LaunchedEffect
        if (com.binario.treni.data.GermanyLive.isTransitous(from.id) || com.binario.treni.data.GermanyLive.isTransitous(to.id)) return@LaunchedEffect
        cells.clear(); done = 0
        // Poche richieste alla volta: troppe insieme e LeFrecce risponde con errori (prima tutte le caselle restavano "—")
        val sem = Semaphore(2)
        coroutineScope {
            days.flatMapIndexed { d, day ->
                SLOTS.mapIndexed { k, (h0, h1, _) ->
                    async {
                        sem.withPermit {
                            val t0 = Calendar.getInstance(rome).apply { timeInMillis = day; set(Calendar.HOUR_OF_DAY, h0) }.timeInMillis
                            val t1 = t0 + (h1 - h0) * 3_600_000L
                            val now = System.currentTimeMillis()
                            val min = if (t1 < now) -1.0 else withContext(Dispatchers.IO) { slotPrice(from, to, maxOf(t0, now), t1, filter, vm.pax) }
                            cells[d to k] = min
                            done++
                        }
                    }
                }
            }.awaitAll()
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tr("Prezzi migliori", "Best prices"), onBack)
        if (from == null || to == null) { MessageBox(tr("Scegli prima partenza e arrivo.", "Choose origin and destination first.")); return@Column }
        // Germania: DB non pubblica i prezzi, quindi niente calendario; si apre bahn.de con la tratta già compilata
        if (com.binario.treni.data.GermanyLive.isTransitous(from.id) || com.binario.treni.data.GermanyLive.isTransitous(to.id)) {
            val ctx = androidx.compose.ui.platform.LocalContext.current
            MessageBox(if (com.binario.treni.data.GermanyLive.isGerman(from.id) || com.binario.treni.data.GermanyLive.isGerman(to.id)) com.binario.treni.data.tx("Per i treni in Germania i prezzi non sono pubblici: il calendario dei prezzi più bassi è su bahn.de («Bestpreissuche»). Con soli treni regionali vale il Deutschlandticket.") else com.binario.treni.data.tx("Per questi treni i prezzi non sono pubblici: il calendario dei prezzi più bassi è sui siti delle compagnie (ÖBB, SNCF) o su bahn.de."))
            Button({ openUrl(ctx, com.binario.treni.data.GermanyLive.bahnUrl(from.name, to.name, vm.date)) }, colors = ButtonDefaults.buttonColors(containerColor = Green),
                modifier = Modifier.padding(horizontal = 16.dp)) { Text(com.binario.treni.data.tx("Apri su bahn.de")) }
            return@Column
        }
        Text(from.name + " → " + to.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp))
        if (!vm.pax.isSingle) Text("👤 " + paxLabel(vm.pax) + " · " + tr("prezzo totale", "total price"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp))
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
            listOf(SearchFilter.FRECCE to tr("Alta velocità", "High speed"), SearchFilter.ALL to tr("Tutti i treni", "All trains"), SearchFilter.REGIONAL to tr("Regionali", "Regional"))
                .forEach { (f, l) -> FilterChip(filter == f, { filter = f }, label = { Text(l, fontSize = 13.sp) }, modifier = Modifier.padding(end = 6.dp)) }
        }
        if (done < days.size * SLOTS.size) LinearProgressIndicator(
            progress = { done / (days.size * SLOTS.size).toFloat() }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), color = Green,
        )
        val best = cells.values.filter { it > 0 }.minOrNull()
        if (done >= days.size * SLOTS.size && cells.values.any { it == -2.0 }) TextButton({ reload++ }, Modifier.padding(horizontal = 8.dp)) {
            Text(tr("Alcune fasce non hanno risposto: tocca per riprovare", "Some time bands did not respond: tap to retry"), color = Green, fontSize = 13.sp)
        }
        WhiteCard {
            Column(Modifier.padding(10.dp)) {
                Row {
                    Spacer(Modifier.width(92.dp))
                    SLOTS.forEach { (h0, h1, label) ->
                        Text(tr(label.first, label.second) + "\n$h0–$h1", Modifier.weight(1f), color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
                days.forEachIndexed { d, day ->
                    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(Fmt.dayLong(day).replaceFirstChar { it.uppercase() }.substringBefore(" ").take(3) + " " + Fmt.day(day),
                            Modifier.width(92.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        SLOTS.forEachIndexed { k, (h0, _, _) ->
                            val v = cells[d to k]
                            val isBest = v != null && best != null && v == best
                            Box(
                                Modifier.weight(1f).padding(2.dp).height(40.dp).clip(RoundedCornerShape(6.dp))
                                    .background(if (isBest) Green else MaterialTheme.colorScheme.surfaceVariant)
                                    .border(1.dp, if (isBest) Green else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(6.dp))
                                    // Si può toccare ogni fascia non ancora passata: con il prezzo, senza prezzo o in caricamento
                                    .clickable(enabled = !slotPast(day, k, rome)) {
                                        vm.date = Calendar.getInstance(rome).apply { timeInMillis = day; set(Calendar.HOUR_OF_DAY, h0) }.timeInMillis
                                            .coerceAtLeast(MainViewModel.roundToQuarter(System.currentTimeMillis()))
                                        vm.filter = filter
                                        vm.search()
                                        onResults()
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                when {
                                    v == null -> Text("…", color = Muted)
                                    v == -2.0 -> Text("?", color = Muted)
                                    v < 0 -> Text("—", color = Muted)
                                    else -> Text(Fmt.price(v), fontSize = 13.sp, fontWeight = if (isBest) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isBest) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }
            }
        }
        Text(tr("Prezzo più basso per 1 adulto tra i treni di quella fascia (Trenitalia, Trenord e Italo). «—» = nessun prezzo disponibile, «?» = servizio non raggiungibile. Tocca una casella per vedere le soluzioni. Le tariffe economiche cambiano con la disponibilità: il prezzo finale è quello all'acquisto.",
            "Lowest price for 1 adult among trains in that time band (Trenitalia, Trenord and Italo). «—» = no price available, «?» = service not reachable. Tap a cell to see the solutions. Economy fares change with availability: the final price is the one at checkout."),
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
    }
}

/** Vero se la fascia k del giorno è già finita. */
private fun slotPast(day: Long, k: Int, rome: TimeZone): Boolean {
    val (h0, h1, _) = SLOTS[k]
    val t0 = Calendar.getInstance(rome).apply { timeInMillis = day; set(Calendar.HOUR_OF_DAY, h0) }.timeInMillis
    return t0 + (h1 - h0) * 3_600_000L < System.currentTimeMillis()
}

/**
 * Prezzo più basso tra le soluzioni che partono nella fascia [t0, t1). Per "Alta velocità" si cercano tutte le soluzioni
 * e si tengono quelle con almeno un treno veloce (da stazioni come Induno Olona "solo Frecce" non dava nulla).
 * Fino a due pagine di risultati per coprire tutta la fascia; un tentativo in più se il servizio non risponde.
 * Restituisce -1 se non c'è nessun prezzo, -2 se il servizio non ha risposto.
 */
private fun slotPrice(from: com.binario.treni.data.Station, to: com.binario.treni.data.Station, t0: Long, t1: Long, filter: SearchFilter, pax: com.binario.treni.data.Pax): Double {
    val search = if (filter == SearchFilter.FRECCE) SearchFilter.ALL else filter
    var failed = false
    val found = ArrayList<com.binario.treni.data.Solution>()
    var start = t0
    for (page in 0 until 2) {
        val list = (0 until 2).firstNotNullOfOrNull { attempt ->
            try { Api.solutions(from, to, start, search, pax = pax) } catch (_: Exception) { if (attempt == 0) Thread.sleep(800); null }
        }
        if (list == null) { failed = true; break }
        found += list
        val last = list.maxOfOrNull { it.dep } ?: break
        if (last >= t1 || last <= start) break
        start = last + 60_000L
    }
    val ok = found.filter { s ->
        s.dep in t0 until t1 && !s.status.equals("INHIBITED", true) &&
            (filter != SearchFilter.FRECCE || s.legs.any { Api.isHighSpeed(it) })
    }
    val min = ok.mapNotNull { it.price }.minOrNull()
    return when {
        min != null -> min
        failed && found.isEmpty() -> -2.0
        else -> -1.0
    }
}

/** Scheda in Home: apre il calendario dei prezzi migliori per la tratta scelta (o invita a sceglierla). */
@Composable
fun PricesHomeCard(vm: MainViewModel, onOpen: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val f = vm.from
    val t = vm.to
    WhiteCard(onClick = {
        if (f == null || t == null || f.id == t.id) toast(ctx, tr("Scegli prima partenza e arrivo.", "Choose origin and destination first."))
        else onOpen()
    }) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CalendarMonth, null, tint = Green, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tr("Prezzi migliori", "Best prices"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    if (f != null && t != null) f.name + " → " + t.name + " · " + tr("prossimi 7 giorni, mattina, pomeriggio e sera", "next 7 days, morning, afternoon and evening")
                    else tr("Scegli partenza e arrivo per vedere i prezzi più bassi dei prossimi 7 giorni.", "Choose origin and destination to see the lowest prices for the next 7 days."),
                    color = Muted, fontSize = 13.sp,
                )
            }
            Text("›", color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}
