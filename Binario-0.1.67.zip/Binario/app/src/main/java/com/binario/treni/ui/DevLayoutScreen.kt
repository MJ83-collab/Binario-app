package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.binario.treni.data.DevLayout

private val ROW_HEIGHT = 58.dp

/**
 * Strumento dello sviluppatore "Disposizione dell'app": tieni premuto su un elemento e trascinalo per cambiarne la
 * posizione; l'interruttore lo mostra o lo nasconde. Le modifiche valgono subito su questo telefono; con "Esporta" si
 * copia la disposizione da mandare allo sviluppatore per renderla quella di serie per tutti.
 */
@Composable
fun DevLayoutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val lists = DevLayout.ITEMS.keys.toList()
    val list = lists[tab]
    var importing by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar("Disposizione dell'app", onBack) {
            IconButton({ DevLayout.lock(ctx); toast(ctx, "Modalità sviluppatore bloccata"); onBack() }) { Icon(Icons.Filled.Lock, "Blocca") }
        }
        GreenTabs(lists.map { DevLayout.TITLES[it] ?: it }, tab) { tab = it }
        key(list) { ReorderList(list) }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({
                val text = DevLayout.export(ctx)
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Disposizione Binario", text))
                shareText(ctx, text)
            }, modifier = Modifier.weight(1f)) { Text("Esporta", color = Green) }
            OutlinedButton({ importing = true }, modifier = Modifier.weight(1f)) { Text("Importa", color = Green) }
        }
    }
    if (importing) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { importing = false },
            title = { Text("Importa disposizione") },
            text = {
                OutlinedTextField(text, { text = it }, label = { Text("Incolla qui il testo esportato") }, modifier = Modifier.fillMaxWidth().height(180.dp))
            },
            confirmButton = {
                TextButton({
                    if (DevLayout.importLayout(ctx, text)) { toast(ctx, "Disposizione applicata"); importing = false }
                    else toast(ctx, "Testo non valido")
                }) { Text("Applica", color = Green) }
            },
            dismissButton = { TextButton({ importing = false }) { Text("Annulla") } },
        )
    }
}

/** Elenco riordinabile trascinando (pressione lunga), con frecce su/giù come alternativa accessibile. */
@Composable
private fun ColumnScope.ReorderList(list: String) {
    val ctx = LocalContext.current
    val names = remember(list) { DevLayout.ITEMS[list].orEmpty().toMap() }
    val order = remember(list) { mutableStateListOf<String>().apply { addAll(DevLayout.order(ctx, list)) } }
    val hidden = remember(list) { mutableStateListOf<String>().apply { addAll(DevLayout.hidden(ctx, list)) } }
    var dragging by remember { mutableStateOf<String?>(null) }
    var offset by remember { mutableFloatStateOf(0f) }
    val rowPx = with(LocalDensity.current) { ROW_HEIGHT.toPx() }
    fun persist() = DevLayout.save(ctx, list, order.toList(), hidden.toSet())
    fun move(from: Int, to: Int) {
        if (from == to || from !in order.indices) return
        val item = order.removeAt(from)
        order.add(to.coerceIn(0, order.size), item)
        persist()
    }

    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
        Text("Tieni premuto su un elemento e trascinalo. L'interruttore lo mostra o lo nasconde. Le modifiche valgono subito.",
            color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        order.forEachIndexed { i, k ->
            val isDragged = dragging == k
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isDragged) Green.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 3.dp)
                    .fillMaxWidth()
                    .height(ROW_HEIGHT - 6.dp)
                    .zIndex(if (isDragged) 1f else 0f)
                    .graphicsLayer { translationY = if (isDragged) offset else 0f }
                    .shadow(if (isDragged) 6.dp else 0.dp, RoundedCornerShape(10.dp))
                    .pointerInput(k, order.size) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { dragging = k; offset = 0f },
                            onDrag = { change, amount -> change.consume(); offset += amount.y },
                            onDragEnd = {
                                val from = order.indexOf(k)
                                val to = (from + Math.round(offset / rowPx)).coerceIn(0, order.size - 1)
                                dragging = null; offset = 0f
                                move(from, to)
                            },
                            onDragCancel = { dragging = null; offset = 0f },
                        )
                    },
            ) {
                Row(Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.DragIndicator, "Trascina", tint = Muted)
                    Spacer(Modifier.width(8.dp))
                    Text(names[k] ?: k, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f),
                        color = if (k in hidden) Muted else MaterialTheme.colorScheme.onSurface)
                    IconButton({ move(i, i - 1) }, enabled = i > 0) { Icon(Icons.Filled.KeyboardArrowUp, "Su") }
                    IconButton({ move(i, i + 1) }, enabled = i < order.size - 1) { Icon(Icons.Filled.KeyboardArrowDown, "Giù") }
                    Switch(
                        checked = k !in hidden,
                        onCheckedChange = { on -> if (on) hidden.remove(k) else hidden.add(k); persist() },
                        colors = SwitchDefaults.colors(checkedTrackColor = Green),
                    )
                }
            }
        }
        TextButton({
            DevLayout.reset(ctx, list)
            order.clear(); order.addAll(DevLayout.order(ctx, list))
            hidden.clear()
            toast(ctx, "Ripristinata la disposizione di serie")
        }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("Ripristina com'era", color = LateRed) }
    }
}

/** Finestra della password per la modalità sviluppatore. */
@Composable
fun DevPasswordDialog(onDismiss: () -> Unit, onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modalità sviluppatore") },
        text = {
            Column {
                OutlinedTextField(
                    pw, { pw = it; wrong = false }, singleLine = true, label = { Text("Password") },
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Password),
                    isError = wrong,
                )
                if (wrong) Text("Password errata", color = LateRed, fontSize = 13.sp)
            }
        },
        confirmButton = {
            TextButton({ if (DevLayout.unlock(ctx, pw)) onUnlocked() else wrong = true }) { Text("Sblocca", color = Green) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Annulla") } },
    )
}
