package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.FerrovieNord
import com.binario.treni.data.I18n
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun tr(a: String, b: String) = I18n.tr(a, b)

/**
 * Info rete FERROVIENORD (dal sito ferrovienord.it e dal suo PIR web): ascensori e scale mobili fuori servizio,
 * stato impianti in tempo reale, accessibilità delle stazioni, assistenza alle persone con disabilità, defibrillatori
 * e documenti della rete. Ogni sezione indica la fonte.
 */
@Composable
fun FerrovieNordScreen(onBack: () -> Unit, onDae: () -> Unit) {
    val ctx = LocalContext.current
    var outages by remember { mutableStateOf<List<FerrovieNord.Outage>?>(null) }
    var failed by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(retry) {
        failed = false
        outages = withContext(Dispatchers.IO) { runCatching { FerrovieNord.outages(force = retry > 0) }.getOrNull() }
        if (outages == null) { failed = true; outages = emptyList() }
    }
    val q = query.trim().lowercase()
    val shown = outages.orEmpty().filter { q.isEmpty() || it.station.lowercase().contains(q) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar("FERROVIENORD", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Text(tr("Gestore della rete di Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa e Brescia–Iseo–Edolo. I treni sono di Trenord.",
                    "Infrastructure manager of the Milano Cadorna–Saronno–Varese, Como, Novara, Laveno, Asso, Seregno, Malpensa and Brescia–Iseo–Edolo network. Trains are run by Trenord."),
                    fontSize = 14.sp, modifier = Modifier.padding(16.dp))
                SectionHeader(tr("Ascensori e scale mobili fuori servizio", "Lifts and escalators out of service"))
                TrenordSearchField(query, { query = it }, {}, placeholder = tr("Cerca una stazione", "Search a station"))
            }
            when {
                outages == null -> item { LoadingBox() }
                failed -> item {
                    MessageBox(tr("Il sito FERROVIENORD non risponde. Apri la pagina ufficiale o riprova.", "The FERROVIENORD site is not responding. Open the official page or retry."))
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { OutlinedButton({ retry++ }) { Text(tr("Riprova", "Retry"), color = Green) } }
                }
                shown.isEmpty() -> item {
                    MessageBox(if (q.isEmpty()) tr("Nessun impianto segnalato fuori servizio.", "No equipment reported out of service.")
                    else tr("Nessun impianto fuori servizio in questa stazione.", "No equipment out of service at this station."))
                }
                else -> items(shown) { o ->
                    WhiteCard {
                        Column(Modifier.padding(start = 12.dp, end = 14.dp, top = 12.dp, bottom = 10.dp)) {
                            TrenordName(o.station)
                            Column(Modifier.padding(start = 24.dp, top = 4.dp)) {
                                if (o.item.isNotBlank()) Text("♿ " + o.item, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFFB34700))
                                if (o.platform.isNotBlank()) Text(tr("Banchina non accessibile: ", "Platform not accessible: ") + o.platform, fontSize = 14.sp, color = LateRed)
                                if (o.since.isNotBlank()) Text(tr("Fuori servizio dal ", "Out of service since ") + o.since, fontSize = 13.sp)
                                if (o.until.isNotBlank()) Text(tr("Ripristino previsto: ", "Expected back: ") + o.until, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
            item {
                Text(tr("Fonte: ferrovienord.it · Comunicazioni accessibilità stazioni (letta adesso, si aggiorna ogni 30 minuti).",
                    "Source: ferrovienord.it · Station accessibility notices (read now, refreshed every 30 minutes)."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                WhiteCard {
                    CardTitle(tr("Accessibilità e assistenza", "Accessibility and assistance"))
                    MenuRow(Icons.Filled.Elevator, tr("Stato ascensori e scale mobili in tempo reale", "Live lift and escalator status"), "maps.manutenzionefn.it") { openUrl(ctx, FerrovieNord.LIVE_STATUS) }
                    MenuRow(Icons.Filled.Call, tr("Assistenza persone con disabilità: 800 210 955", "Assistance for disabled passengers: 800 210 955"),
                        tr("Numero verde Trenord/FERROVIENORD · prenota almeno 48 ore prima", "Trenord/FERROVIENORD free number · book at least 48 hours ahead")) { dial(ctx, FerrovieNord.ASSIST_PHONE) }
                    MenuRow(Icons.Filled.Email, FerrovieNord.ASSIST_EMAIL, tr("Richiesta di assistenza via email", "Assistance request by email")) {
                        openUrl(ctx, "mailto:" + FerrovieNord.ASSIST_EMAIL)
                    }
                    MenuRow(Icons.Filled.Accessible, tr("Prenota l'assistenza online", "Book assistance online"), "trenord.it") { openUrl(ctx, FerrovieNord.ASSIST_PAGE) }
                    MenuRow(Icons.Filled.Description, tr("Schede accessibilità stazioni · rami di Milano", "Station accessibility sheets · Milan branches"), "PDF · ferrovienord.it") { openUrl(ctx, FerrovieNord.SHEETS_MILANO) }
                    MenuRow(Icons.Filled.Description, tr("Schede accessibilità stazioni · Brescia–Iseo–Edolo", "Station accessibility sheets · Brescia–Iseo–Edolo"), "PDF · ferrovienord.it") { openUrl(ctx, FerrovieNord.SHEETS_ISEO) }
                    MenuRow(Icons.Filled.Info, tr("Accessibilità stazioni e PMR", "Station accessibility and reduced mobility"), "ferrovienord.it") { openUrl(ctx, FerrovieNord.ACCESSIBILITY) }
                }
                WhiteCard {
                    CardTitle(tr("Defibrillatori (DAE)", "Defibrillators (AED)"))
                    Text(tr("In tutte le stazioni FERROVIENORD c'è un defibrillatore (125 installati tra il 2022 e il 2023): dove possibile sulla facciata esterna, così è raggiungibile anche di notte, in una teca allarmata e segnalata, con il kit di primo soccorso. È monitorato a distanza e registrato presso le centrali regionali dell'emergenza. Si può usare anche sui bambini. In emergenza chiama il 112.",
                        "Every FERROVIENORD station has a defibrillator (125 installed in 2022–2023): where possible on the outside wall so it can be reached at night, in an alarmed, marked case with a first-aid kit. It is remotely monitored and registered with the regional emergency centres. It can be used on children too. In an emergency call 112."),
                        fontSize = 14.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                    MenuRow(Icons.Filled.MonitorHeart, tr("Mappa dei defibrillatori vicini", "Map of nearby defibrillators"), tr("Stazioni FERROVIENORD e altri DAE", "FERROVIENORD stations and other AEDs")) { onDae() }
                    MenuRow(Icons.Filled.Language, tr("Pagina defibrillatori", "Defibrillators page"), "ferrovienord.it") { openUrl(ctx, FerrovieNord.DEFIBRILLATORS) }
                }
                WhiteCard {
                    CardTitle(tr("Documenti della rete (PIR web)", "Network documents (PIR web)"))
                    MenuRow(Icons.Filled.Insights, tr("Indicatori di qualità dei servizi 2026", "Service quality indicators 2026"), "ferrovienord.it") { openUrl(ctx, FerrovieNord.QUALITY_2026) }
                    MenuRow(Icons.Filled.Train, tr("Caratteristiche delle linee e degli impianti", "Line and facility characteristics"), "ferrovienord.it") { openUrl(ctx, FerrovieNord.LINES) }
                    MenuRow(Icons.Filled.Apartment, tr("Piano di utilizzo delle stazioni", "Station usage plan"), "ferrovienord.it") { openUrl(ctx, FerrovieNord.STATION_PLAN) }
                    MenuRow(Icons.Filled.Accessible, tr("Adeguamento stazioni per persone a mobilità ridotta", "Station upgrades for reduced mobility"), "ferrovienord.it") { openUrl(ctx, FerrovieNord.PMR_WORKS) }
                    MenuRow(Icons.Filled.Description, tr("Prospetto informativo della rete", "Network statement"), "ferrovienord.it") { openUrl(ctx, FerrovieNord.NETWORK_STATEMENT) }
                    MenuRow(Icons.Filled.Folder, "PIR web", tr("Tutti i documenti", "All documents")) { openUrl(ctx, FerrovieNord.PIR) }
                }
                Text(tr("Fonti: ferrovienord.it (PIR web, comunicazioni accessibilità stazioni, defibrillatori) e trenord.it (assistenza). Le date di ripristino sono previsioni del gestore.",
                    "Sources: ferrovienord.it (PIR web, station accessibility notices, defibrillators) and trenord.it (assistance). Restore dates are the manager's estimates."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
            }
        }
    }
}
