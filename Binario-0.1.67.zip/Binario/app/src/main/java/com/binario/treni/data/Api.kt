package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object Fmt {
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")
    fun time(ms: Long): String = if (ms <= 0) "--:--" else SimpleDateFormat("HH:mm", Locale.ITALY).apply { timeZone = rome }.format(Date(ms))
    fun day(ms: Long): String = SimpleDateFormat(if (I18n.cjk) "M月d日" else "dd MMM", I18n.locale).apply { timeZone = rome }.format(Date(ms))
    fun dayLong(ms: Long): String = SimpleDateFormat(if (I18n.cjk) "M月d日 EEEE" else "EEEE d MMMM", I18n.locale).apply { timeZone = rome }.format(Date(ms))
        .replaceFirstChar { it.uppercase() }
    fun dayTime(ms: Long): String = SimpleDateFormat(if (I18n.cjk) "M月d日 HH:mm" else "dd MMM HH:mm", I18n.locale).apply { timeZone = rome }.format(Date(ms))
    fun price(p: Double?): String = if (p == null) "" else String.format(Locale.ITALY, "%.2f €", p)
    fun duration(dep: Long, arr: Long): String {
        if (dep <= 0 || arr <= dep) return ""
        val m = ((arr - dep) / 60000).toInt()
        return "${m / 60}h ${"%02d".format(m % 60)}m"
    }

    /**
     * Momento in cui lo stato di una corsa (partito/arrivato/ritardo) torna a «non ancora partito» con i dati del giorno dopo:
     * a mezzanotte, oppure alle 5 del mattino se il treno arriva dopo mezzanotte.
     */
    fun resetAt(runDay: Long, lastArr: Long): Long {
        val nextMidnight = midnight(runDay + 27 * 3_600_000L)
        return if (lastArr > nextMidnight) nextMidnight + 5 * 3_600_000L else nextMidnight
    }

    fun midnight(ms: Long = System.currentTimeMillis()): Long = Calendar.getInstance(rome).apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

/**
 * Client per i dati pubblici:
 *  - ViaggiaTreno (RFI/Trenitalia): stazioni, tabelloni, andamento treni in tempo reale.
 *  - LeFrecce (Trenitalia): soluzioni di viaggio con prezzi.
 * Sono API non ufficiali: possono cambiare senza preavviso, per questo il parsing è difensivo.
 */
object Api {
    private const val VT = "http://www.viaggiatreno.it/infomobilita/resteasy/viaggiatreno/"
    private const val LF = "https://www.lefrecce.it/Channels.Website.BFF.WEB/website/"
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")

    // ---------------- HTTP ----------------

    private fun open(url: String): HttpURLConnection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Binario/1.0")
        setRequestProperty("Accept-Language", "it-IT")
    }

    /**
     * Piccola cache in memoria delle risposte: lo stesso treno o tabellone viene chiesto da più parti dell'app
     * (soluzioni, preferiti, Capotreno, treno seguito, widget) a pochi secondi di distanza. I dati in tempo reale
     * restano validi 15 secondi, quelli che non cambiano (regione, coordinate, nomi delle stazioni) 6 ore.
     */
    private val cache = object : LinkedHashMap<String, Pair<Long, String>>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, String>>?): Boolean = size > 200
    }

    private fun ttl(url: String): Long = when {
        "/andamentoTreno/" in url || "/partenze/" in url || "/arrivi/" in url -> 15_000L
        "/cercaNumeroTrenoTrenoAutocomplete/" in url -> 60_000L
        "/regione/" in url || "/dettaglioStazione/" in url || "/autocompletaStazione/" in url || "/elencoStazioni/" in url -> 6 * 3_600_000L
        else -> 0L
    }

    /** Svuota la cache (es. tasto "Aggiorna"): la prossima richiesta va in rete. */
    fun clearCache() = synchronized(cache) { cache.clear() }

    private fun get(url: String): String {
        val life = ttl(url)
        if (life > 0) synchronized(cache) {
            cache[url]?.let { (t, body) -> if (System.currentTimeMillis() - t < life) return body }
        }
        // Stessa richiesta già in corso (es. tabellone, scheda treno e widget insieme): aspetto quella invece di ripeterla
        val mine = java.util.concurrent.CompletableFuture<String>()
        val running = inflight.putIfAbsent(url, mine)
        if (running != null) {
            return try {
                running.get(40, java.util.concurrent.TimeUnit.SECONDS)
            } catch (e: java.util.concurrent.ExecutionException) {
                throw (e.cause as? IOException) ?: IOException(e.cause)
            } catch (e: java.util.concurrent.TimeoutException) {
                throw IOException("Timeout")
            }
        }
        try {
            val body = getFresh(url)
            if (life > 0) synchronized(cache) { cache[url] = System.currentTimeMillis() to body }
            mine.complete(body)
            return body
        } catch (e: Exception) {
            mine.completeExceptionally(e)
            throw e
        } finally {
            inflight.remove(url, mine)
        }
    }

    private val inflight = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.CompletableFuture<String>>()

    /** GET con un secondo tentativo in caso di errore di rete o del server (5xx): ViaggiaTreno a volte "singhiozza". */
    private fun getFresh(url: String): String {
        var last: IOException? = null
        for (attempt in 0 until 2) {
            try {
                return getOnce(url)
            } catch (e: IOException) {
                last = e
                if (e.message?.startsWith("HTTP 4") == true) break
                try { Thread.sleep(700) } catch (_: InterruptedException) { break }
            }
        }
        throw last ?: IOException("Errore di rete")
    }

    private fun getOnce(url: String): String {
        val c = open(url)
        try {
            // Se un sito rifiuta l'app (403), riprova presentandosi come il browser del telefono
            if (c.responseCode == 403) {
                c.disconnect()
                val b = open(url).apply { setRequestProperty("User-Agent", BROWSER_UA) }
                try {
                    if (b.responseCode !in 200..299) throw IOException("HTTP ${b.responseCode}")
                    return b.inputStream.bufferedReader().use { it.readText() }
                } finally {
                    b.disconnect()
                }
            }
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun post(url: String, body: String): String {
        val c = open(url)
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    // ---------------- LeFrecce: sessione (token CSRF + cookie) ----------------

    private const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36"
    private var lfToken: String? = null
    private var lfCookie: String? = null
    private var lfAuthAt = 0L

    /** LeFrecce richiede prima POST whitelist/enabled: restituisce un token CSRF e i cookie di sessione. */
    @Synchronized
    private fun lfAuth(force: Boolean = false) {
        if (!force && lfAuthAt > 0 && System.currentTimeMillis() - lfAuthAt < 10 * 60_000) return
        val c = (URL(LF + "whitelist/enabled").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 20000
            requestMethod = "POST"; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", BROWSER_UA)
            setRequestProperty("Accept-Language", "it-IT")
        }
        try {
            c.outputStream.use { it.write("{}".toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IOException("LeFrecce whitelist HTTP $code")
            val token = try {
                val o = JSONObject(text)
                o.optString("token").ifBlank { o.optString("csrfToken") }
            } catch (_: Exception) {
                text.trim().takeIf { it.isNotEmpty() && it.length < 500 }.orEmpty()
            }
            val cookies = c.headerFields.entries
                .filter { it.key != null && it.key.equals("Set-Cookie", true) }
                .flatMap { it.value }
                .map { it.substringBefore(';').trim() }
                .filter { it.isNotEmpty() }
            lfToken = token.ifBlank { null }
            lfCookie = cookies.joinToString("; ").ifBlank { null }
            lfAuthAt = System.currentTimeMillis()
        } finally {
            c.disconnect()
        }
    }

    /** POST a LeFrecce con token e cookie; se la sessione è scaduta (401/403) la rinnova una volta. 400 = nessuna soluzione. */
    private fun lfPost(path: String, body: String, retry: Boolean = true): String? {
        lfAuth()
        val c = (URL(LF + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 25000
            requestMethod = "POST"; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", BROWSER_UA)
            setRequestProperty("Accept-Language", "it-IT")
            lfToken?.let { setRequestProperty("x-csrf-token", it) }
            lfCookie?.let { setRequestProperty("Cookie", it) }
        }
        try {
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            if ((code == 401 || code == 403 || code == 419) && retry) {
                c.disconnect()
                lfAuth(force = true)
                return lfPost(path, body, retry = false)
            }
            if (code == 400) return null
            if (code !in 200..299) throw IOException("LeFrecce HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun vtDate(ms: Long): String =
        SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT'Z", Locale.US).apply { timeZone = rome }.format(Date(ms))

    private fun JSONObject.s(k: String): String = if (!has(k) || isNull(k)) "" else optString(k).trim()
    private fun JSONObject.l(k: String): Long = if (!has(k) || isNull(k)) 0L else optLong(k)
    private fun JSONObject.i(k: String): Int = if (!has(k) || isNull(k)) 0 else optInt(k)

    private fun parseIso(s: String): Long {
        if (s.isBlank()) return 0L
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSS", "yyyy-MM-dd'T'HH:mm:ss",
        )
        for (p in patterns) {
            try {
                val f = SimpleDateFormat(p, Locale.US)
                if (!p.contains("XXX")) f.timeZone = rome
                return f.parse(s)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    // ---------------- Stazioni ----------------

    /** Stazioni italiane (ViaggiaTreno) e, in coda, stazioni svizzere dall'orario ufficiale svizzero. */
    fun searchStations(q: String): List<Station> {
        var vtError: Exception? = null
        val ita = try {
            get(VT + "autocompletaStazione/" + enc(q.trim())).lines().mapNotNull { line ->
                val p = line.split("|")
                if (p.size >= 2 && p[1].isNotBlank()) Station(p[0].trim(), p[1].trim()) else null
            }
        } catch (e: Exception) {
            vtError = e; emptyList()
        }
        // Svizzera e ferrovie a rete propria in parallelo, per non rallentare la ricerca
        var ch: List<Station> = emptyList()
        var local: List<Station> = emptyList()
        var de: List<Station> = emptyList()
        var at: List<Station> = emptyList()
        var fr: List<Station> = emptyList()
        if (q.trim().length >= 3) {
            val t1 = Thread { ch = SwissLive.searchStations(q) }.apply { start() }
            val t2 = Thread { local = LocalRail.searchStations(q) }.apply { start() }
            // Germania: stazioni dagli orari ufficiali DELFI (anche "Monaco di Baviera", "Colonia"…)
            val t3 = Thread { de = GermanyLive.searchStations(q) }.apply { start() }
            // Austria e Francia: stesso motore (Transitous)
            val t4 = Thread { at = GermanyLive.searchCountry(q, GermanyLive.AT) }.apply { start() }
            val t5 = Thread { fr = GermanyLive.searchCountry(q, GermanyLive.FR) }.apply { start() }
            t1.join(8000); t2.join(8000); t3.join(8000); t4.join(8000); t5.join(8000)
        }
        // Fermate della rete FerrovieNord che ViaggiaTreno a volte non trova per nome (stessi codici)
        val fn = FnNetwork.search(q).filter { f -> ita.none { it.id == f.id } }
        if (ita.isEmpty() && ch.isEmpty() && local.isEmpty() && fn.isEmpty() && de.isEmpty() && at.isEmpty() && fr.isEmpty()) vtError?.let { throw it }
        return ita + fn + local + ch + de + at + fr
    }

    private val resolved = java.util.concurrent.ConcurrentHashMap<String, Station>()

    /** Nomi delle fermate della metropolitana/bus nelle soluzioni che corrispondono a una stazione ferroviaria di Milano. */
    private val ALIASES = mapOf(
        "CENTRALE" to "MILANO CENTRALE", "GARIBALDI" to "MILANO PORTA GARIBALDI", "PORTA GARIBALDI" to "MILANO PORTA GARIBALDI",
        "CADORNA" to "MILANO CADORNA", "CADORNA FN" to "MILANO CADORNA", "REPUBBLICA" to "MILANO REPUBBLICA",
        "PORTA VENEZIA" to "MILANO PORTA VENEZIA", "LAMBRATE" to "MILANO LAMBRATE", "ROGOREDO" to "MILANO ROGOREDO",
        "PORTA GENOVA" to "MILANO PORTA GENOVA", "BOVISA" to "MILANO BOVISA POLITECNICO", "DATEO" to "MILANO DATEO",
        "VILLAPIZZONE" to "MILANO VILLAPIZZONE", "LANCETTI" to "MILANO LANCETTI", "PORTA VITTORIA" to "MILANO PORTA VITTORIA",
        "SAN CRISTOFORO" to "MILANO SAN CRISTOFORO", "DOMODOSSOLA" to "MILANO DOMODOSSOLA", "AFFORI" to "MILANO AFFORI",
        "GRECO PIRELLI" to "MILANO GRECO PIRELLI", "CERTOSA" to "MILANO CERTOSA", "FORLANINI" to "MILANO FORLANINI",
        "RHO FIERA MILANO" to "RHO FIERA", "FIERA" to "RHO FIERA", "MALPENSA T1" to "MALPENSA AEROPORTO T1",
        "MALPENSA T2" to "MALPENSA AEROPORTO T2",
    )

    private fun stNorm(s: String) = java.text.Normalizer.normalize(s.uppercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").replace(Regex("[^A-Z0-9]+"), " ").trim()

    /**
     * Trova la stazione con il nome scritto nelle soluzioni di viaggio, che spesso è diverso da quello di ViaggiaTreno
     * ("Rho Fiera Milano" = RHO FIERA, "REPUBBLICA" della metro = MILANO REPUBBLICA, "CENTRALE FS" = MILANO CENTRALE).
     * Prova il nome intero, poi senza le sigle (FS, FN, M1…), gli alias di Milano e il nome accorciato una parola alla volta.
     */
    fun resolveStation(name: String, city: String = ""): Station? {
        val key = stNorm(name)
        if (key.isEmpty()) return null
        resolved[key]?.let { return it }
        val core = key.replace(Regex("\\b(FS|FN|FNM|FFS|SBB|RFI|M[1-5]|STAZIONE|STAZ|FERMATA|METRO|MM)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        val tries = LinkedHashSet<String>()
        ALIASES[key]?.let { tries += it }
        ALIASES[core]?.let { tries += it }
        tries += name.trim().uppercase()
        tries += key
        if (core.isNotEmpty()) tries += core
        val cityN = stNorm(city).split(' ').firstOrNull().orEmpty()
        if (cityN.length >= 3 && !core.startsWith(cityN)) tries += "$cityN $core"
        if (!core.startsWith("MILANO")) tries += "MILANO $core"
        var words = core.split(' ')
        while (words.size > 1) { words = words.dropLast(1); if (words.joinToString(" ").length >= 3) tries += words.joinToString(" ") }
        val coreWords = (if (ALIASES[core] != null) stNorm(ALIASES[core]!!) else core).split(' ').filter { it.isNotEmpty() }
        fun score(st: Station): Int { val n = stNorm(st.name).split(' '); return coreWords.count { w -> n.any { it.startsWith(w) || w.startsWith(it) && it.length >= 3 } } }
        for (q in tries) {
            val list = try { searchStations(q) } catch (_: Exception) { emptyList() }
            if (list.isEmpty()) continue
            val qn = stNorm(q)
            val exact = list.firstOrNull { stNorm(it.name) == qn } ?: list.firstOrNull { stNorm(it.name) == core }
            val best = exact ?: list.maxByOrNull { score(it) }?.takeIf { st ->
                val sc = score(st)
                sc >= 1 && sc >= coreWords.size - 1 && (coreWords.size >= 2 || sc == coreWords.size)
            } ?: continue
            resolved[key] = best
            return best
        }
        return null
    }

    fun departures(st: Station, time: Long = System.currentTimeMillis()): List<BoardItem> =
        when {
            SwissLive.isSwiss(st.id) -> SwissLive.departures(st, time)
            GermanyLive.isTransitous(st.id) -> GermanyLive.board(st, time)
            LocalRail.isLocal(st.id) -> LocalRail.departures(st, time)
            else -> withItalo(st, time, board("partenze", st, time, departures = true))
        }

    /** Aggiunge le partenze Italo (che ViaggiaTreno non mostra) se la stazione è servita da Italo e si guarda "adesso". */
    private fun withItalo(st: Station, time: Long, vt: List<BoardItem>): List<BoardItem> {
        if (Math.abs(time - System.currentTimeMillis()) > 30 * 60_000L || ItaloLive.codeFor(st.name) == null) return vt
        val have = vt.mapTo(HashSet()) { trainDigits(it.number) }
        val until = (vt.maxOfOrNull { it.time } ?: (time + 90 * 60_000L)).coerceAtLeast(time + 60 * 60_000L)
        val extra = ItaloLive.departures(st).filter { b -> b.number !in have && b.time + b.delay * 60_000L >= time - 5 * 60_000L && b.time <= until }
        return if (extra.isEmpty()) vt else (vt + extra).sortedBy { b -> b.time }
    }

    /**
     * Tutti i prossimi treni: ViaggiaTreno restituisce circa 90 minuti per richiesta,
     * quindi uniamo più finestre consecutive (default 12 ore) togliendo i doppioni.
     */
    fun boardAhead(st: Station, departures: Boolean, from: Long = System.currentTimeMillis(), hours: Int = 12): List<BoardItem> {
        val out = LinkedHashMap<String, BoardItem>()
        var t = from
        val end = from + hours * 3600_000L
        var failures = 0
        while (t < end && failures < 2) {
            val part = try {
                if (departures) departures(st, t) else arrivals(st, t)
            } catch (e: Exception) {
                failures++; emptyList()
            }
            part.forEach { b -> out.putIfAbsent(b.number + "|" + b.originCode + "|" + b.time, b) }
            // la finestra successiva parte dall'ultimo treno trovato (o +80 minuti se vuota)
            val last = part.maxOfOrNull { it.time } ?: 0L
            t = if (last > t + 20 * 60_000L) last else t + 80 * 60_000L
        }
        return out.values.filter { it.time >= from - 10 * 60_000L }.sortedBy { it.time }
    }

    fun arrivals(st: Station, time: Long = System.currentTimeMillis()): List<BoardItem> =
        if (GermanyLive.isTransitous(st.id)) GermanyLive.board(st, time, arrivals = true)
        else if (SwissLive.isSwiss(st.id) || LocalRail.isLocal(st.id)) throw IOException(I18n.tr("Per questa stazione sono disponibili solo le partenze", "Only departures are available for this station"))
        else board("arrivi", st, time, departures = false)

    /** Tabellone grezzo di ViaggiaTreno ("partenze" o "arrivi"), per le statistiche raccolte dall'app. */
    fun rawBoard(kind: String, stationId: String, time: Long): JSONArray = JSONArray(get(VT + kind + "/" + stationId + "/" + enc(vtDate(time))))

    private fun board(kind: String, st: Station, time: Long, departures: Boolean): List<BoardItem> {
        val a = JSONArray(get(VT + kind + "/" + st.id + "/" + enc(vtDate(time))))
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val comp = o.s("compNumeroTreno")
            val cat = comp.split(" ").firstOrNull()?.takeIf { comp.contains(" ") } ?: o.s("categoria")
            val suffix = if (departures) "Partenza" else "Arrivo"
            val eff = o.s("binarioEffettivo${suffix}Descrizione")
            val prog = o.s("binarioProgrammato${suffix}Descrizione")
            BoardItem(
                number = o.s("numeroTreno"),
                category = cat,
                otherEnd = if (departures) o.s("destinazione") else o.s("origine"),
                time = if (departures) o.l("orarioPartenza") else o.l("orarioArrivo"),
                delay = o.i("ritardo"),
                platform = eff.ifBlank { prog },
                platformConfirmed = eff.isNotBlank(),
                originCode = o.s("codOrigine"),
                departureDate = o.l("dataPartenzaTreno"),
                inStation = o.optBoolean("inStazione"),
                schedPlatform = prog,
                realPlatform = eff,
                operator = Operators.fromClientCode(o.i("codiceCliente"), cat, comp),
            )
        }
    }

    // ---------------- Treni ----------------

    /** Cerca un treno per numero. Può restituire più corse con lo stesso numero (origini diverse). */
    /**
     * Solo il numero del treno: LeFrecce per i regionali dà "S50 TRENORD 25592" o "RE SBB 25591",
     * mentre ViaggiaTreno vuole "25592". Prende l'ultimo gruppo di cifre (da 2 a 6).
     */
    fun trainDigits(n: String): String =
        Regex("\\d{2,6}").findAll(n).lastOrNull()?.value ?: n.trim()

    /** Cerca un treno per numero su ViaggiaTreno e, per i numeri tipo Italo (8xxx, 9xxx), anche su Italo. */
    fun trainLookup(number: String): List<TrainRef> {
        val vt = try {
            vtLookup(number)
        } catch (e: IOException) {
            if (!ItaloLive.looksItalo(number)) throw e
            emptyList()
        }
        return if (ItaloLive.looksItalo(number)) vt + ItaloLive.lookup(number) else vt
    }

    private fun vtLookup(number: String): List<TrainRef> {
        val first = vtLookupOne(number)
        if (first.isNotEmpty()) return withAliases(first)
        // Doppia numerazione (RFI / FerrovieNord): se ViaggiaTreno non conosce questo numero si prova l'altro della stessa corsa
        for (al in TrainAliases.others(number)) {
            val r = try { vtLookupOne(al.other) } catch (_: Exception) { emptyList() }
            if (r.isNotEmpty() && r.any { TrainAliases.othersFor(it.number, it.originCode).isNotEmpty() }) return withAliases(r)
        }
        return first
    }

    /** Nella lista dei risultati il numero diventa «24114/11813» e si indica la linea («S1 · S3 · S12 · S13»). */
    private fun withAliases(list: List<TrainRef>): List<TrainRef> = list.map { r ->
        val al = TrainAliases.othersFor(r.number, r.originCode).firstOrNull() ?: return@map r
        val parts = r.label.split(" - ")
        val head = (parts.firstOrNull() ?: r.number).trim()
        val rest = parts.drop(1).joinToString(" - ")
        val label = head + "/" + al.other + (if (rest.isNotBlank()) " - $rest" else "") + (if (al.line.isNotBlank()) " · " + al.line else "")
        r.copy(label = label)
    }

    private fun vtLookupOne(number: String): List<TrainRef> {
        val list = get(VT + "cercaNumeroTrenoTrenoAutocomplete/" + enc(trainDigits(number))).lines().mapNotNull { line ->
            val p = line.split("|")
            if (p.size < 2) return@mapNotNull null
            val parts = p[1].split("-")
            if (parts.size < 2) return@mapNotNull null
            val date = parts.getOrNull(2)?.toLongOrNull() ?: Fmt.midnight()
            TrainRef(parts[0].trim(), parts[1].trim(), date, p[0].trim())
        }
        // Doppia numerazione: Trenord usa lo stesso numero sulla rete RFI e sulla rete FerrovieNord (es. 10610 Cremona – Milano
        // Porta Garibaldi e 10610 Seveso – Milano Cadorna). Se i risultati sono di reti diverse, si indica quale è quale.
        val fn = list.map { r -> try { FnNetwork.isFn(r.originCode) } catch (_: Exception) { false } }
        if (list.size < 2 || fn.distinct().size < 2) return list
        return list.mapIndexed { i, r ->
            val tag = if (fn[i]) "FerrovieNord" else "RFI"
            val parts = r.label.split(" - ")
            val label = if (parts.size >= 3) parts[0] + " - " + parts[1] + " (" + tag + ") - " + parts.drop(2).joinToString(" - ") else r.label + " (" + tag + ")"
            r.copy(label = label)
        }
    }

    /** Completa un riferimento senza data/origine (es. preferiti) con la corsa di oggi. */
    fun resolve(ref: TrainRef): TrainRef {
        if (ref.originCode.isNotBlank() && ref.date > 0) return ref.copy(number = trainDigits(ref.number))
        val list = trainLookup(ref.number)
        val match = list.firstOrNull { it.originCode == ref.originCode } ?: list.firstOrNull()
            ?: throw IOException("Treno ${ref.number} non trovato")
        return match.copy(label = ref.label.ifBlank { match.label })
    }

    /**
     * Lo stato di una corsa resta quello del suo giorno fino al reset: mezzanotte, o le 5 se il treno arriva dopo mezzanotte.
     * Dopo il reset si mostra la corsa di oggi («non ancora partito»); se non è ancora disponibile, la stessa corsa senza rilevamenti.
     */
    fun status(ref: TrainRef): TrainStatus = TrainMerge.merge(statusBasic(ref))

    /** Stato da una sola fonte (la base), senza unire le altre: per chi legge molti treni di seguito (mappa, statistiche, avvisi). */
    fun statusBasic(ref: TrainRef): TrainStatus {
        val st = statusRaw(ref)
        val now = System.currentTimeMillis()
        val today = Fmt.midnight(now)
        if (st.date <= 0 || st.date >= today || st.stops.isEmpty() || now < Fmt.resetAt(st.date, st.arrTime)) return st
        val fresh = try { statusRaw(ref.copy(date = today)) } catch (_: Exception) { null }
        if (fresh != null && fresh.date >= today) return fresh
        val shift = { ms: Long -> if (ms > 0) ms + (today - st.date) else 0L }
        return st.copy(
            date = today, delay = 0, lastStation = "", lastTime = 0L,
            stops = st.stops.map { s ->
                s.copy(schedArr = shift(s.schedArr), schedDep = shift(s.schedDep), realArr = 0L, realDep = 0L, delay = 0,
                    platform = s.schedPlatform, platformChanged = false, platformConfirmed = false, realPlatform = "")
            },
        )
    }

    private fun statusRaw(ref: TrainRef): TrainStatus {
        if (ref.originCode.startsWith(SwissLive.PREFIX + "|")) return SwissLive.status(ref)
        if (GermanyLive.isTransitousRef(ref.originCode)) return GermanyLive.status(ref)
        if (ref.originCode.startsWith(LocalRail.PREFIX + "|")) return LocalRail.status(ref)
        if (ItaloLive.isItalo(ref)) return ItaloLive.status(ref)
        val r0 = try { resolve(ref) } catch (e: Exception) { return trenordFallback(ref) ?: throw e }
        return try {
            vtStatus(r0)
        } catch (e: Exception) {
            // Il riferimento viene da un'altra fonte (es. mappa: stazione di origine dell'orario Trenord, spesso non nota a ViaggiaTreno):
            // 1) si riprova con l'origine che ViaggiaTreno conosce per quel numero; 2) altrimenti si usa l'orario Trenord con il live.
            val alt = try { trainLookup(ref.number).firstOrNull { it.originCode != r0.originCode } } catch (_: Exception) { null }
            if (alt != null) {
                try { return vtStatus(alt.copy(label = ref.label.ifBlank { alt.label })) } catch (_: Exception) { }
            }
            trenordFallback(r0) ?: throw e
        }
    }

    /** Stato di un treno Trenord/FerrovieNord/TILO costruito dall'orario ufficiale (feed GTFS) e dal servizio live di Trenord. */
    private fun trenordFallback(ref: TrainRef): TrainStatus? {
        val run = TrenordGtfs.tripFor(trainDigits(ref.number), ref.date) ?: return null
        val n = run.stops.size
        val stops = run.stops.mapIndexed { i, s ->
            TrainStop(
                name = s.name, id = s.id,
                schedArr = if (i > 0) s.arr else 0L, schedDep = if (i < n - 1) s.dep else 0L,
                realArr = 0L, realDep = 0L, delay = 0, platform = "", platformChanged = false, platformConfirmed = false,
            )
        }
        val st = TrainStatus(
            number = run.number, category = run.line, origin = stops.first().name, destination = stops.last().name,
            originCode = run.stops.first().id, date = run.midnight, delay = 0, lastStation = "", lastTime = 0L,
            cancelled = false, stops = stops, operator = "Trenord",
        )
        val live = try { trenordLiveFor(st) } catch (_: Exception) { TrenordLive.EMPTY }
        val base = (try { rebuildFromTrenord(st, live) } catch (_: Exception) { null }) ?: st
        val withInfo = if (live.alerts.isEmpty()) base else base.copy(
            info = (listOf(base.info) + live.alerts).filter { it.isNotBlank() }.distinct().joinToString("\n"),
        )
        return try { enrichFuture(withInfo, live) } catch (_: Exception) { withInfo }
    }

    private fun vtStatus(r: TrainRef): TrainStatus {
        val o = JSONObject(get(VT + "andamentoTreno/" + r.originCode + "/" + r.number + "/" + r.date))
        val f = o.optJSONArray("fermate") ?: JSONArray()
        val stops = (0 until f.length()).map { i ->
            val s = f.getJSONObject(i)
            val effP = s.s("binarioEffettivoPartenzaDescrizione")
            val effA = s.s("binarioEffettivoArrivoDescrizione")
            val progP = s.s("binarioProgrammatoPartenzaDescrizione")
            val progA = s.s("binarioProgrammatoArrivoDescrizione")
            val eff = effP.ifBlank { effA }
            val prog = progP.ifBlank { progA }
            TrainStop(
                name = s.s("stazione"),
                id = s.s("id"),
                schedArr = s.l("arrivo_teorico"),
                schedDep = s.l("partenza_teorica"),
                realArr = s.l("arrivoReale"),
                realDep = s.l("partenzaReale"),
                delay = s.i("ritardo"),
                platform = eff.ifBlank { prog },
                platformChanged = eff.isNotBlank() && prog.isNotBlank() && eff != prog,
                platformConfirmed = eff.isNotBlank(),
                schedPlatform = prog,
                realPlatform = eff,
            )
        }
        val comp = o.s("compNumeroTreno")
        return enrichStops(TrainStatus(
            number = o.s("numeroTreno").ifBlank { r.number },
            category = o.s("categoria").ifBlank { comp.split(" ").firstOrNull() ?: "" },
            origin = o.s("origine"),
            destination = o.s("destinazione"),
            originCode = r.originCode,
            date = r.date,
            delay = o.i("ritardo"),
            lastStation = o.s("stazioneUltimoRilevamento").takeIf { it != "--" } ?: "",
            lastTime = o.l("oraUltimoRilevamento"),
            cancelled = o.optBoolean("trenoSoppresso") || o.i("provvedimento") == 1,
            stops = stops,
            info = listOf(o.s("subTitle"), o.s("compProvvedimento"))
                .filter { it.isNotBlank() && it != "null" }.joinToString("\n"),
            operator = Operators.fromClientCode(o.i("codiceCliente"), o.s("categoria"), comp),
            numberChanges = numberChanges(o.optJSONArray("cambiNumero")),
        ))
    }

    /**
     * Fermate senza dati (tipico sulla rete FerrovieNord, dove ViaggiaTreno rileva solo alcune stazioni), solo per i treni Trenord/FN:
     * 1) dal servizio live di Trenord (lo stesso della pagina «Circolazione in tempo reale» di trenord.it): orari e ritardi effettivi
     *    delle fermate già fatte, stima per le prossime, binario per fermata e avvisi di soppressione;
     * 2) altrimenti il ritardo attuale del treno (mai negativo) per le fermate non ancora transitate;
     * 3) le fermate il cui orario stimato è già passato risultano transitate (pallino blu, orario stimato).
     * Le fermate già rilevate da ViaggiaTreno non si toccano. Le fermate future mostrano la stima in arancione.
     */
    private fun enrichStops(st: TrainStatus): TrainStatus {
        if (st.cancelled || st.stops.isEmpty()) return st
        if (!TrainAliases.isTrenordRun(st)) return if (st.departed) enrichFuture(st, TrenordLive.EMPTY) else st
        val live = trenordLiveFor(st)
        // ViaggiaTreno vede spesso solo una parte della corsa FerrovieNord (es. Busto Arsizio → Malpensa): con tutte le fermate di Trenord
        // si parte dalla corsa completa, tenendo i rilevamenti di ViaggiaTreno per le fermate che ha già registrato.
        val base = rebuildFromTrenord(st, live) ?: st
        val withInfo = if (live.alerts.isEmpty()) base else base.copy(
            info = (listOf(base.info) + live.alerts).filter { it.isNotBlank() }.distinct().joinToString("\n"),
        )
        val res = if (withInfo.departed) enrichFuture(withInfo, live) else withInfo
        // Rete FerrovieNord: il ritardo del treno è quello dichiarato da Trenord (prima fonte)
        val fnRun = res.stops.any { FnNetwork.isFn(it.id) }
        return if (fnRun && live.trainDelay != null) res.copy(delay = live.trainDelay) else res
    }

    private fun rebuildFromTrenord(st: TrainStatus, live: TrenordLive): TrainStatus? {
        val ls = live.stops
        if (ls.size < 2) return null
        val vtIds = st.stops.map { it.id }
        val more = ls.size > st.stops.size || ls.first().id != st.stops.first().id || ls.last().id != st.stops.last().id
        val anyActual = ls.any { it.arrActual || it.depActual }
        if (!more && !(anyActual && !st.departed)) return null
        val vt = st.stops.associateBy { it.id }
        val n = ls.size
        val stops = ls.mapIndexed { i, l ->
            val v = vt[l.id]
            val ra = if (i > 0 && l.arrActual && l.schedArr > 0) l.schedArr + (l.arrDelay ?: 0) * 60_000L else 0L
            val rd = if (i < n - 1 && l.depActual && l.schedDep > 0) l.schedDep + (l.depDelay ?: l.arrDelay ?: 0) * 60_000L else 0L
            // Rete FerrovieNord: la prima fonte è il servizio live di Trenord; ViaggiaTreno solo dove Trenord non ha il rilevamento
            if (v != null && v.passed && !(FnNetwork.isFn(l.id) && (ra > 0 || rd > 0))) return@mapIndexed v
            TrainStop(
                name = v?.name ?: l.name, id = l.id,
                schedArr = if (i > 0) l.schedArr else 0L, schedDep = if (i < n - 1) l.schedDep else 0L,
                realArr = ra, realDep = rd,
                delay = if (ra > 0 || rd > 0) (l.depDelay ?: l.arrDelay ?: 0) else (v?.delay ?: 0),
                platform = if (l.platformActual) l.platform else (v?.platform?.takeIf { it.isNotBlank() } ?: l.platform),
                platformChanged = false, platformConfirmed = l.platformActual || (v?.platformConfirmed == true),
                schedPlatform = if (l.platformActual) "" else (v?.schedPlatform?.takeIf { it.isNotBlank() } ?: l.platform),
                realPlatform = if (l.platformActual) l.platform else (v?.realPlatform ?: ""),
            )
        }
        return st.copy(
            stops = stops,
            origin = stops.first().name, destination = stops.last().name,
            delay = live.trainDelay ?: st.delay,
            lastStation = live.actualStation.ifBlank { st.lastStation },
            lastTime = if (live.actualTime > 0) live.actualTime else st.lastTime,
        )
    }

    /** Dati live Trenord della corsa: si provano il numero mostrato e gli altri numeri della doppia numerazione. */
    private fun trenordLiveFor(st: TrainStatus): TrenordLive {
        val nums = (listOf(st.number) + TrainAliases.othersFor(st).map { it.other }).map { trainDigits(it) }.distinct()
        for (n in nums) {
            val l = trenordLiveCached(n, if (st.date > 0) st.date + 3_600_000L else System.currentTimeMillis())
            if (!l.isEmpty) return l
        }
        return TrenordLive.EMPTY
    }

    private fun hmsToMillis(base: Long, hms: String?): Long {
        if (hms.isNullOrBlank() || base <= 0) return 0L
        val p = hms.split(":")
        val h = p.getOrNull(0)?.toIntOrNull() ?: return 0L
        val m = p.getOrNull(1)?.toIntOrNull() ?: return 0L
        val c = Calendar.getInstance(rome).apply {
            timeInMillis = base
            set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, p.getOrNull(2)?.toIntOrNull() ?: 0); set(Calendar.MILLISECOND, 0)
        }
        var t = c.timeInMillis
        if (t - base > 12 * 3_600_000L) t -= 24 * 3_600_000L else if (base - t > 12 * 3_600_000L) t += 24 * 3_600_000L
        return t
    }

    private fun enrichFuture(st: TrainStatus, live: TrenordLive): TrainStatus {
        val now = System.currentTimeMillis()
        val cur = st.delay.coerceAtLeast(0)
        val trenord = !live.isEmpty || TrainAliases.isTrenordRun(st)
        val n = st.stops.size
        val out = st.stops.mapIndexed { i, s ->
            val l = live.byId[s.id] ?: live.byName[normStop(s.name)]
            // Rete FerrovieNord: Trenord live ha la precedenza anche sulle fermate già rilevate da ViaggiaTreno
            val fnLive = s.passed && l != null && (l.arrActual != null || l.depActual != null) && FnNetwork.isFn(s.id)
            if (s.passed && !fnLive) return@mapIndexed s
            var x = s
            // Orari effettivi di Trenord: la fermata è stata fatta
            if (l != null && (l.arrActual != null || l.depActual != null)) {
                // Meglio programmato + ritardo dichiarato (minuti) che l'ora grezza: in alcune risposte l'ora effettiva è incoerente col ritardo
                val ra = if (i > 0 && s.schedArr > 0 && l.arrActual != null) (l.arrDelay?.let { s.schedArr + it * 60_000L } ?: hmsToMillis(s.schedArr, l.arrActual)) else 0L
                val rd = if (i < n - 1 && s.schedDep > 0 && l.depActual != null) (l.depDelay?.let { s.schedDep + it * 60_000L } ?: hmsToMillis(s.schedDep, l.depActual)) else 0L
                if (ra > 0 || rd > 0) {
                    return@mapIndexed x.copy(realArr = ra, realDep = rd, delay = l.depDelay ?: l.arrDelay ?: s.delay).withLivePlatform(l)
                }
            }
            // Stima: orario stimato di Trenord se il treno ha dati live, altrimenti ritardo attuale
            var d = s.delay
            if (d == 0) {
                val est = if (live.hasLive && l != null) {
                    val e = if (l.depEst != null && s.schedDep > 0) hmsToMillis(s.schedDep, l.depEst) - s.schedDep
                    else if (l.arrEst != null && s.schedArr > 0) hmsToMillis(s.schedArr, l.arrEst) - s.schedArr else null
                    e?.let { Math.round(it / 60_000.0).toInt() }
                } else null
                d = (est ?: cur).coerceAtLeast(0)
            }
            if (d != s.delay) x = x.copy(delay = d)
            if (l != null) x = x.withLivePlatform(l)
            if (trenord) {
                val estArr = if (x.schedArr > 0 && i > 0) x.schedArr + d * 60_000L else 0L
                val estDep = if (x.schedDep > 0 && i < n - 1) x.schedDep + d * 60_000L else 0L
                val ref = if (estDep > 0) estDep else estArr
                if (ref in 1 until now - 60_000L) {
                    x = x.copy(realArr = estArr.takeIf { it > 0 && it < now } ?: 0L, realDep = estDep.takeIf { it > 0 && it < now } ?: 0L)
                }
            }
            x
        }
        return st.copy(stops = out)
    }

    /** Binario di Trenord solo se ViaggiaTreno non ne ha uno: effettivo se Trenord lo dichiara tale, altrimenti previsto. */
    private fun TrainStop.withLivePlatform(l: StopLive): TrainStop {
        if (l.platform.isBlank() || platform.isNotBlank()) return this
        return if (l.platformActual) copy(platform = l.platform, realPlatform = l.platform, platformConfirmed = true)
        else copy(platform = l.platform, schedPlatform = l.platform)
    }

    private val NON_ALNUM = Regex("[^a-z0-9]")
    /** Nome di fermata confrontabile: senza sigla della rete FerrovieNord («Milano Cadorna FN» = «Milano Cadorna»). */
    private fun normStop(n: String) = n.lowercase().replace(Regex("\\bf\\.\\s?n\\.?(?=\\s|$)"), " fn ")
        .replace(Regex("\\b(fn|ferrovienord)\\b"), " ").replace(NON_ALNUM, "")

    private class StopLive(
        val arrDelay: Int?, val depDelay: Int?, val arrActual: String?, val depActual: String?,
        val arrEst: String?, val depEst: String?, val platform: String, val platformActual: Boolean,
    )

    private class LiveStop(
        val id: String, val name: String, val schedArr: Long, val schedDep: Long,
        val arrActual: Boolean, val depActual: Boolean, val arrDelay: Int?, val depDelay: Int?,
        val platform: String, val platformActual: Boolean,
    )

    private class TrenordLive(
        val byId: Map<String, StopLive>, val byName: Map<String, StopLive>, val alerts: List<String>, val hasLive: Boolean,
        val stops: List<LiveStop> = emptyList(), val trainDelay: Int? = null, val actualStation: String = "", val actualTime: Long = 0L,
    ) {
        val isEmpty: Boolean get() = byId.isEmpty() && byName.isEmpty()
        companion object { val EMPTY = TrenordLive(emptyMap(), emptyMap(), emptyList(), false) }
    }

    /** Dati per fermata di Trenord tenuti 2 minuti, anche se vuoti o in errore: niente richieste ripetute a ogni aggiornamento. */
    private val liveCache = java.util.concurrent.ConcurrentHashMap<String, TrenordLive>()

    private fun trenordLiveCached(number: String, dayMs: Long): TrenordLive {
        val k = number + "|" + (dayMs / 86_400_000L) + "|" + (System.currentTimeMillis() / 120_000L)
        liveCache[k]?.let { return it }
        if (liveCache.size > 50) liveCache.clear()
        val v = try { trenordLive(number, dayMs) } catch (_: Exception) { TrenordLive.EMPTY }
        liveCache[k] = v
        return v
    }

    /** Ritardo (minuti) e presenza di dati live di un treno Trenord dal servizio del sito; null se non si legge. */
    fun trenordDelay(number: String): Pair<Int, Boolean>? = try {
        val root = trenordMia(number)
        val first = (root as? JSONArray)?.optJSONObject(0) ?: (root as? JSONObject)
        val digits = trainDigits(number)
        val list = first?.optJSONArray("journey_list")
        val tr = (0 until (list?.length() ?: 0)).mapNotNull { list?.optJSONObject(it)?.optJSONObject("train") }
            .firstOrNull { trainDigits(it.optString("train_id")) == digits } ?: list?.optJSONObject(0)?.optJSONObject("train")
        if (tr == null) null else (tr.optInt("delay", 0) to tr.optBoolean("has_live_info"))
    } catch (_: Exception) { null }

    /**
     * Ritardo di un treno Trenord/FerrovieNord per la mappa: prima il servizio live di Trenord (anche con l'altro numero della doppia
     * numerazione), poi ViaggiaTreno se il treno è già partito. [ref] = corsa dell'orario Trenord (origine e data) per non confondere
     * lo stesso numero su reti diverse.
     */
    fun trenordDelayBest(number: String, ref: TrainRef? = null): Pair<Int, Boolean>? {
        val nums = (listOf(number) + TrainAliases.others(number).map { it.other }).distinct()
        var any: Pair<Int, Boolean>? = null
        for (n in nums) {
            val d = trenordDelay(n) ?: continue
            if (d.second) return d
            if (any == null) any = d
        }
        val vt = try { statusBasic(ref ?: TrainRef(number)) } catch (_: Exception) { null }
        if (vt != null && vt.departed) return vt.delay to true
        return any
    }

    private fun isoMillis(s: String?): Long = if (s.isNullOrBlank()) 0L else try {
        java.time.Instant.parse(s).toEpochMilli()
    } catch (_: Exception) { try { java.time.OffsetDateTime.parse(s).toInstant().toEpochMilli() } catch (_: Exception) { 0L } }

    private fun JSONObject.strOrNull(k: String): String? = if (!has(k) || isNull(k)) null else optString(k).takeIf { it.isNotBlank() && it != "null" }
    private fun JSONObject.intOrNull(k: String): Int? = if (!has(k) || isNull(k)) null else (opt(k) as? Number)?.toInt()

    /**
     * Servizio live di Trenord (mia/train/<numero>): [ { journey_list: [ { train: { delay, has_live_info, alerts… },
     * pass_list: [ { station{station_id}, arr_time, dep_time, platform, is_actual_platform,
     * actual_data{arr/dep_actual_time, arr/dep_delay_actual, arr/dep_estimated_time} } ] } ] } ]
     */
    private fun trenordLive(number: String, dayMs: Long): TrenordLive {
        val root = trenordMia(number, dayMs) ?: return TrenordLive.EMPTY
        val first = (root as? JSONArray)?.optJSONObject(0) ?: (root as? JSONObject) ?: return TrenordLive.EMPTY
        val list = first.optJSONArray("journey_list") ?: return TrenordLive.EMPTY
        val digits = trainDigits(number)
        val journey = (0 until list.length()).mapNotNull { list.optJSONObject(it) }
            .firstOrNull { trainDigits(it.optJSONObject("train")?.optString("train_id").orEmpty()) == digits }
            ?: list.optJSONObject(0) ?: return TrenordLive.EMPTY
        val train = journey.optJSONObject("train")
        val alerts = ArrayList<String>()
        train?.optJSONArray("alerts")?.let { a ->
            for (i in 0 until a.length()) a.optJSONObject(i)?.strOrNull("message")?.let { alerts += it }
        }
        val byId = HashMap<String, StopLive>(); val byName = HashMap<String, StopLive>()
        val pl = journey.optJSONArray("pass_list") ?: return TrenordLive(byId, byName, alerts, false)
        val live = ArrayList<LiveStop>()
        for (i in 0 until pl.length()) {
            val p = pl.optJSONObject(i) ?: continue
            val a = p.optJSONObject("actual_data")
            val sl = StopLive(
                arrDelay = a?.intOrNull("arr_delay_actual"), depDelay = a?.intOrNull("dep_delay_actual"),
                arrActual = a?.strOrNull("arr_actual_time"), depActual = a?.strOrNull("dep_actual_time"),
                arrEst = a?.strOrNull("arr_estimated_time"), depEst = a?.strOrNull("dep_estimated_time"),
                platform = p.strOrNull("platform").orEmpty(), platformActual = p.optBoolean("is_actual_platform"),
            )
            val stn = p.optJSONObject("station") ?: continue
            stn.strOrNull("station_id")?.let { byId[it] = sl }
            stn.strOrNull("station_ori_name")?.let { byName[normStop(it)] = sl }
            val sid = stn.strOrNull("station_id")
            if (sid != null && p.optBoolean("cancelled") != true) {
                live += LiveStop(
                    sid, stn.strOrNull("station_ori_name").orEmpty(), isoMillis(p.strOrNull("arr_date_time")), isoMillis(p.strOrNull("dep_date_time")),
                    sl.arrActual != null, sl.depActual != null, sl.arrDelay, sl.depDelay, sl.platform, sl.platformActual,
                )
            }
        }
        return TrenordLive(
            byId, byName, alerts, train?.optBoolean("has_live_info") == true,
            live, train?.intOrNull("delay"), train?.strOrNull("actual_station").orEmpty(), isoMillis(train?.strOrNull("actual_time")),
        )
    }

    /** "cambiNumero" di ViaggiaTreno: il formato esatto non è documentato, si leggono le chiavi più probabili. */
    private fun numberChanges(a: JSONArray?): List<Pair<String, String>> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val c = a.optJSONObject(i) ?: return@mapNotNull null
            val n = listOf("nuovoNumeroTreno", "numeroTreno", "nuovoNumero", "numero").map { c.s(it) }.firstOrNull { it.isNotBlank() && it != "null" }
                ?: return@mapNotNull null
            val st = listOf("stazione", "nomeStazione", "nome").map { c.s(it) }.firstOrNull { it.isNotBlank() && it != "null" }.orEmpty()
            trainDigits(n) to st
        }
    }

    // ---------------- Soluzioni di viaggio ----------------

    /**
     * Soluzioni di viaggio. maxChanges = -1 → nessun limite. excluded = categorie da escludere (es. "FR", "BUS").
     */
    fun solutions(
        from: Station, to: Station, time: Long, filter: SearchFilter,
        maxChanges: Int = -1, excluded: Set<String> = emptySet(), pax: Pax = Pax.ONE,
    ): List<Solution> {
        val base = solutionsBase(from, to, time, filter, maxChanges, excluded, pax)
        // Treni Italo (Trenitalia non li vende): diretti tra stazioni Italo, oppure regionale/Trenitalia + Italo con cambio
        if (filter == SearchFilter.REGIONAL || "ITA" in excluded || GermanyLive.isTransitous(from.id) || GermanyLive.isTransitous(to.id)) return base
        val italo = try { italoSolutions(from, to, time, base, maxChanges, pax) } catch (_: Exception) { emptyList() }
        if (italo.isEmpty()) return base
        val have = base.flatMap { it.legs }.mapTo(HashSet()) { trainDigits(it.number) }
        val extra = italo.filter { sol -> sol.legs.none { it.category == "ITA" && trainDigits(it.number) in have } }
            .filter { maxChanges < 0 || it.changes <= maxChanges }
        // Le soluzioni Italo restano nella stessa finestra oraria delle altre
        val until = base.maxOfOrNull { it.dep }?.let { maxOf(it, time + 3 * 3_600_000L) } ?: (time + 6 * 3_600_000L)
        return (base + extra.filter { it.dep <= until }).sortedBy { it.dep }
    }

    /**
     * Soluzioni Italo. Se partenza e arrivo sono stazioni Italo: treni diretti con orari e prezzi (servizio di vendita
     * Italo, qualsiasi data; in riserva il servizio "Italo in viaggio" per le prossime ore). Se una sola delle due è
     * servita da Italo (es. Induno Olona → Roma): si prende la stazione di cambio delle soluzioni Trenitalia
     * (es. Milano Centrale) e si uniscono un treno Trenitalia/Trenord e un Italo con tempo di cambio sufficiente.
     */
    private fun italoSolutions(from: Station, to: Station, time: Long, base: List<Solution>, maxChanges: Int, pax: Pax): List<Solution> {
        val a = ItaloLive.codeFor(from.name)
        val b = ItaloLive.codeFor(to.name)
        val end = time + 6 * 3_600_000L
        if (a != null && b != null) {
            if (a == b) return emptyList()
            val list = try { ItaloBooking.search(a, b, time - 5 * 60_000L, end, pax) } catch (_: Exception) { emptyList() }
            return list.ifEmpty { try { ItaloLive.directSolutions(from, to, time) } catch (_: Exception) { emptyList() } }
        }
        if (maxChanges == 0 || (a == null && b == null)) return emptyList()
        val legs = base.flatMap { it.legs }
        if (a == null && b != null) {
            // Stazione di cambio verso l'Italo: la prima stazione Italo dove arriva un treno delle soluzioni Trenitalia
            val hubName = legs.map { it.to }.firstOrNull { n -> n.isNotBlank() && ItaloLive.codeFor(n).let { it != null && it != b } }
                ?: defaultHub(from) ?: return emptyList()
            val hubCode = ItaloLive.codeFor(hubName) ?: return emptyList()
            val hub = resolveStation(hubName) ?: return emptyList()
            val feeders = try { lefrecce(from, hub, time, SearchFilter.ALL, false, pax) } catch (_: Exception) { emptyList() }
                .filter { it.arr > 0 && it.dep >= time - 60_000L }
            if (feeders.isEmpty()) return emptyList()
            val trains = ItaloBooking.search(hubCode, b, feeders.minOf { it.arr }, end + 2 * 3_600_000L, pax)
            return feeders.mapNotNull { f ->
                val last = f.legs.lastOrNull() ?: return@mapNotNull null
                val it0 = trains.firstOrNull { t ->
                    val need = ChangeRisk.needed(last.copy(to = last.to.ifBlank { hubName }), t.legs.first())
                    t.dep >= f.arr + need * 60_000L && t.dep <= f.arr + 100 * 60_000L
                } ?: return@mapNotNull null
                join(f, it0, hubName)
            }.distinctBy { it.legs.last().number }
        }
        // a != null && b == null: Italo fino alla stazione di cambio, poi Trenitalia/Trenord
        val hubName = legs.map { it.from }.lastOrNull { n -> n.isNotBlank() && ItaloLive.codeFor(n).let { it != null && it != a } }
            ?: defaultHub(to) ?: return emptyList()
        val hubCode = ItaloLive.codeFor(hubName) ?: return emptyList()
        val hub = resolveStation(hubName) ?: return emptyList()
        val trains = ItaloBooking.search(a!!, hubCode, time - 5 * 60_000L, end, pax)
        if (trains.isEmpty()) return emptyList()
        val tails = try { lefrecce(hub, to, trains.minOf { it.arr }, SearchFilter.ALL, false, pax) } catch (_: Exception) { emptyList() }
            .let { first ->
                // Le corse successive, se i treni Italo arrivano più tardi
                val lastArr = trains.maxOf { it.arr }
                if (first.isNotEmpty() && first.maxOf { it.dep } < lastArr) first + (try { lefrecce(hub, to, first.maxOf { it.dep } + 60_000L, SearchFilter.ALL, false, pax) } catch (_: Exception) { emptyList() })
                else first
            }
        return trains.mapNotNull { t ->
            val il = t.legs.last()
            val tail = tails.firstOrNull { x ->
                val need = ChangeRisk.needed(il, x.legs.firstOrNull() ?: return@firstOrNull false)
                x.dep >= t.arr + need * 60_000L && x.dep <= t.arr + 120 * 60_000L
            } ?: return@mapNotNull null
            join(t, tail, hubName)
        }.distinctBy { it.legs.first().number }
    }

    /** Stazione Italo milanese usata quando le soluzioni Trenitalia non indicano un cambio utile. */
    @Suppress("UNUSED_PARAMETER")
    private fun defaultHub(st: Station): String? = null

    /** Unisce due soluzioni consecutive (es. Trenord fino a Milano Centrale + Italo per Roma). */
    private fun join(x: Solution, y: Solution, hubName: String): Solution {
        val xl = x.legs.mapIndexed { i, l ->
            if (l.from.isNotBlank()) l else l.copy(
                from = if (i == 0) x.from else "", to = if (i == x.legs.lastIndex) hubName else "",
                dep = if (i == 0) x.dep else 0L, arr = if (i == x.legs.lastIndex) x.arr else 0L,
            )
        }
        val yl = y.legs.mapIndexed { i, l ->
            if (l.from.isNotBlank()) l else l.copy(
                from = if (i == 0) hubName else "", to = if (i == y.legs.lastIndex) y.to else "",
                dep = if (i == 0) y.dep else 0L, arr = if (i == y.legs.lastIndex) y.arr else 0L,
            )
        }
        val price = if (x.price != null && y.price != null) Math.round((x.price + y.price) * 100) / 100.0 else null
        val first = if (price != null) Math.round(((x.priceFirst ?: x.price!!) + (y.priceFirst ?: y.price!!)) * 100) / 100.0 else null
        return Solution(
            from = x.from, to = y.to, dep = x.dep, arr = y.arr, duration = Fmt.duration(x.dep, y.arr),
            price = price, legs = xl + yl, source = "italotreno.com", fares = x.fares + y.fares,
            status = if (x.status.equals("INHIBITED", true) || y.status.equals("INHIBITED", true)) "INHIBITED" else "",
            priceFirst = first?.takeIf { x.priceFirst != null || y.priceFirst != null },
        )
    }

    private fun solutionsBase(
        from: Station, to: Station, time: Long, filter: SearchFilter,
        maxChanges: Int, excluded: Set<String>, pax: Pax = Pax.ONE,
    ): List<Solution> {
        // Da o per la Svizzera: orario ufficiale svizzero (comprende FFS, TILO, BLS, SOB e i treni lombardi)
        // Germania (anche Italia ⇄ Germania): orari ufficiali DELFI tramite Transitous; prezzi su bahn.de
        if (GermanyLive.isTransitous(from.id) || GermanyLive.isTransitous(to.id)) return GermanyLive.solutions(from, to, time, maxChanges == 0)
            .filter { s -> (maxChanges < 0 || s.changes <= maxChanges) && s.legs.none { l -> excluded.any { ex -> l.category.equals(ex, true) } } }
        // Svizzera: il prezzo è per 1 adulto; i ragazzi pagano metà prezzo (Metà-prezzo/Junior)
        if (SwissLive.isSwiss(from.id) || SwissLive.isSwiss(to.id)) return SwissLive.solutions(from, to, time).let { l ->
            if (pax.isSingle) l else {
                val k = pax.adults + 0.5 * pax.children
                l.map { s -> s.copy(price = s.price?.let { Math.round(it * k * 100) / 100.0 }, priceFirst = s.priceFirst?.let { Math.round(it * k * 100) / 100.0 }) }
            }
        }
        // Con una ferrovia a rete propria (EAV, ARST, Ferrotramviaria…): orari ufficiali raccolti da Transitous
        if (LocalRail.isLocal(from.id) || LocalRail.isLocal(to.id)) return LocalRail.solutions(from, to, time)
        val directOnly = maxChanges == 0
        var lfError: Exception? = null
        val primary = try {
            lefrecce(from, to, time, filter, directOnly, pax).ifEmpty {
                // "Alta velocità" da una stazione senza Frecce (es. Induno Olona): LeFrecce non dà nulla con "solo Frecce";
                // si cercano tutte le soluzioni e si tengono quelle con almeno un treno veloce
                if (filter == SearchFilter.FRECCE) lefrecce(from, to, time, SearchFilter.ALL, directOnly, pax).filter { s -> s.legs.any { isHighSpeed(it) } }
                else emptyList()
            }
        } catch (e: Exception) {
            lfError = e
            emptyList()
        }
        // Riserva 1: orari ufficiali GTFS (Trenord, anche rete FerrovieNord) tramite Transitous
        val gtfs = if (primary.isEmpty()) {
            try {
                LocalRail.solutions(from, to, time)
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()
        // Riserva 2: il vecchio servizio ViaggiaTreno (oggi spesso non disponibile).
        val list = primary.ifEmpty { gtfs }.ifEmpty {
            try {
                viaggiaTrenoSolutions(from, to, time, filter, directOnly)
            } catch (e: Exception) {
                lfError?.let { throw IOException(it.message ?: "LeFrecce non raggiungibile", it) }
                emptyList()
            }
        }
        return list.filter { sol ->
            (maxChanges < 0 || sol.changes <= maxChanges) &&
                sol.legs.none { l -> excluded.any { ex -> l.category.equals(ex, true) } }
        }
    }

    /** Treno ad alta velocità o a lunga percorrenza veloce (Frecce, Italo, Intercity, EC). */
    fun isHighSpeed(l: Leg): Boolean {
        val c = (l.category + " " + l.number).uppercase()
        return listOf("FR", "FA", "FB", "ITA", "IC", "EC", "FRECCIA", "ITALO").any { k -> c == k || c.startsWith("$k ") || c.contains(" $k ") || c.contains("FRECCIA") }
    }

    private val lfIds = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun norm(n: String) = n.lowercase(Locale.ITALY).replace(Regex("[^a-z0-9àèéìòù]+"), " ").trim()

    /**
     * Id LeFrecce della stazione. Per le stazioni RFI è 830000000 + codice ViaggiaTreno, ma per la rete FerrovieNord
     * (Milano Cadorna, Saronno, Varese Nord, Como Lago, Novara Nord, Malpensa…) è diverso (es. Varese Nord 830025251):
     * lo cerchiamo per nome e lo teniamo in memoria.
     */
    fun lfId(st: Station): Long {
        lfIds[st.id]?.let { return it }
        val guess = st.lefrecceId
        val found = try {
            val a = JSONArray(get(LF + "locations/search?name=" + enc(st.name) + "&limit=10"))
            val list = (0 until a.length()).map { a.getJSONObject(it) }
            list.firstOrNull { it.optLong("id") == guess }?.optLong("id")
                ?: list.firstOrNull { norm(it.optString("name")) == norm(st.name) }?.optLong("id")
                ?: list.firstOrNull { !it.optBoolean("multistation") }?.optLong("id")
        } catch (e: Exception) {
            null
        }
        val id = found?.takeIf { it > 0 } ?: guess
        if (found != null) lfIds[st.id] = id
        return id
    }

    private fun lefrecce(from: Station, to: Station, time: Long, filter: SearchFilter, directOnly: Boolean, pax: Pax = Pax.ONE): List<Solution> {
        val t = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).apply { timeZone = rome }.format(Date(time))
        val body = JSONObject()
            .put("departureLocationId", lfId(from))
            .put("arrivalLocationId", lfId(to))
            .put("departureTime", t)
            .put("adults", pax.adults.coerceIn(1, 9))
            .put("children", pax.children.coerceIn(0, 9))
            .put(
                "criteria", JSONObject()
                    .put("frecceOnly", filter == SearchFilter.FRECCE)
                    .put("regionalOnly", filter == SearchFilter.REGIONAL)
                    .put("intercityOnly", false)
                    .put("noChanges", directOnly)
                    .put("order", "DEPARTURE_DATE")
                    .put("limit", if (filter == SearchFilter.ALL) 30 else 10)
                    .put("offset", 0),
            )
            .put("advancedSearchRequest", JSONObject().put("bestFare", false).put("bikeFilter", false))
        val text = lfPost("ticket/solutions", body.toString()) ?: return emptyList()
        val root = JSONObject(text)
        val arr = root.optJSONArray("solutions") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val wrap = arr.optJSONObject(i) ?: return@mapNotNull null
            val s = wrap.optJSONObject("solution") ?: wrap
            val dep = parseIso(s.s("departureTime"))
            val arrT = parseIso(s.s("arrivalTime"))
            val nodes = s.optJSONArray("nodes") ?: wrap.optJSONArray("nodes")
            val trains = s.optJSONArray("trains") ?: JSONArray()
            val legs = if (nodes != null && nodes.length() > 0) {
                (0 until nodes.length()).map { k ->
                    val n = nodes.getJSONObject(k)
                    val tr = n.optJSONObject("train") ?: JSONObject()
                    Leg(
                        number = tr.s("description").ifBlank { tr.s("name") },
                        category = tr.s("acronym").ifBlank { tr.s("trainCategory") },
                        from = n.s("origin"), to = n.s("destination"),
                        dep = parseIso(n.s("departureTime")), arr = parseIso(n.s("arrivalTime")),
                    )
                }
            } else {
                (0 until trains.length()).map { k ->
                    val tr = trains.getJSONObject(k)
                    Leg(
                        number = tr.s("description").ifBlank { tr.s("name") },
                        category = tr.s("acronym").ifBlank { tr.s("trainCategory") },
                    )
                }
            }.map { l ->
                // Un treno senza tratte intermedie copre l'intero viaggio
                if (l.from.isBlank() && trains.length() == 1) l.copy(from = s.s("origin"), to = s.s("destination"), dep = dep, arr = arrT) else l
            }
            val priceObj = s.optJSONObject("price")
            val price = priceObj?.optDouble("amount")?.takeIf { !it.isNaN() }
            val grids = parseGrids(wrap.optJSONArray("grids") ?: s.optJSONArray("grids"), legs)
            Solution(
                from = s.s("origin").ifBlank { from.name },
                to = s.s("destination").ifBlank { to.name },
                dep = dep, arr = arrT,
                duration = s.s("duration").ifBlank { Fmt.duration(dep, arrT) },
                price = price,
                legs = legs,
                fares = grids,
                status = s.s("status").ifBlank { wrap.s("status") },
                priceFirst = firstClassPrice(price, grids, pax.count),
            )
        }
            // Lo stesso treno a volte arriva due volte (es. TILO: "RE SBB 25591" e "S50 TRENORD 25591"):
            // diventa una sola riga con entrambe le sigle e il numero una volta: "RE SBB / SU S50 TRENORD 25591"
            .groupBy { sol -> "${sol.dep}|${sol.arr}|" + sol.legs.joinToString(",") { trainDigits(it.number) } }
            .values.map { same -> if (same.size == 1) same[0] else mergeSame(same) }
    }

    /**
     * Classe di un livello di servizio LeFrecce: 1 = prima (1ª Classe, Business), 2 = seconda (2ª Classe, Standard),
     * 0 = altro (Premium, Executive, Salottino…), che non si usa per il confronto.
     */
    fun serviceClass(name: String): Int {
        val n = name.lowercase(Locale.ITALY)
        return when {
            n.contains("executive") || n.contains("premium") || n.contains("salottino") -> 0
            n.contains("business") || Regex("(^|\\D)1\\s*[ªa°^o]?\\s*(classe|cl\\b|class)").containsMatchIn(n) || n.contains("prima") || n.contains("first") || n.contains("1st") -> 1
            n.contains("standard") || Regex("(^|\\D)2\\s*[ªa°^o]?\\s*(classe|cl\\b|class)").containsMatchIn(n) || n.contains("seconda") || n.contains("second") || n.contains("2nd") -> 2
            else -> 0
        }
    }

    /**
     * Prezzo in 1ª classe: prezzo della soluzione (2ª) più, per ogni treno, la differenza tra la tariffa di 1ª e quella
     * di 2ª più economiche ancora in vendita. Null se nessun treno ha la 1ª classe (es. molti regionali).
     */
    private fun firstClassPrice(price: Double?, grids: List<FareGrid>, people: Int = 1): Double? {
        if (price == null || grids.isEmpty()) return null
        var extra = 0.0
        var found = false
        grids.forEach { g ->
            val ok = g.offers.filter { !it.soldOut && it.price != null }
            val second = ok.filter { serviceClass(it.service) == 2 }.mapNotNull { it.price }.minOrNull()
            val first = ok.filter { serviceClass(it.service) == 1 }.mapNotNull { it.price }.minOrNull()
            if (second != null && first != null) {
                found = true
                if (first > second) extra += (first - second) * people.coerceAtLeast(1)
            }
        }
        return if (found) Math.round((price + extra) * 100) / 100.0 else null
    }

    /** Tariffe per treno: grids[].services[].offers[] (nome, prezzo, posti disponibili, esaurita). */
    private fun parseGrids(grids: JSONArray?, legs: List<Leg>): List<FareGrid> {
        if (grids == null) return emptyList()
        return (0 until grids.length()).mapNotNull { g ->
            val grid = grids.optJSONObject(g) ?: return@mapNotNull null
            val services = grid.optJSONArray("services") ?: return@mapNotNull null
            val offers = (0 until services.length()).flatMap { k ->
                val sv = services.optJSONObject(k) ?: return@flatMap emptyList<FareOffer>()
                val svName = sv.s("name").ifBlank { sv.s("description") }
                val list = sv.optJSONArray("offers") ?: JSONArray()
                (0 until list.length()).mapNotNull { j ->
                    val o = list.optJSONObject(j) ?: return@mapNotNull null
                    val p = o.optJSONObject("price")?.optDouble("amount")?.takeIf { !it.isNaN() }
                    FareOffer(o.s("serviceName").ifBlank { svName }, o.s("name").ifBlank { o.s("description") }, p,
                        o.optInt("availableAmount", 0), o.s("status").equals("SOLD_OUT", true) || p == null)
                }
            }.distinctBy { it.service + "|" + it.name }
            if (offers.isEmpty()) null else FareGrid(legs.getOrNull(g)?.title ?: "", offers)
        }
    }

    /** Unisce soluzioni identiche che differiscono solo per la sigla del treno. */
    private fun mergeSame(same: List<Solution>): Solution {
        val first = same[0]
        val legs = first.legs.mapIndexed { i, leg ->
            val titles = same.mapNotNull { it.legs.getOrNull(i)?.title }.distinct()
            if (titles.size < 2) return@mapIndexed leg
            val digits = trainDigits(leg.number)
            val names = titles.map { it.removeSuffix(digits).trim() }.filter { it.isNotBlank() }.distinct()
            val merged = names.joinToString(" / ") + " " + digits
            leg.copy(number = merged.removePrefix(leg.category).trim())
        }
        return first.copy(legs = legs, price = same.mapNotNull { it.price }.minOrNull() ?: first.price)
    }

    private fun viaggiaTrenoSolutions(from: Station, to: Station, time: Long, filter: SearchFilter, directOnly: Boolean): List<Solution> {
        val t = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = rome }.format(Date(time))
        val root = JSONObject(get(VT + "soluzioniViaggioNew/${from.num}/${to.num}/$t"))
        val arr = root.optJSONArray("soluzioni") ?: return emptyList()
        val high = setOf("FR", "FA", "FB", "ITA", "EC", "IC")
        val reg = setOf("REG", "RV", "R", "S", "MET")
        return (0 until arr.length()).mapNotNull { i ->
            val s = arr.getJSONObject(i)
            val v = s.optJSONArray("vehicles") ?: return@mapNotNull null
            val legs = (0 until v.length()).map { k ->
                val x = v.getJSONObject(k)
                Leg(
                    number = x.s("numeroTreno"),
                    category = x.s("categoriaDescrizione").ifBlank { x.s("categoria") },
                    from = x.s("origine"), to = x.s("destinazione"),
                    dep = parseIso(x.s("orarioPartenza")), arr = parseIso(x.s("orarioArrivo")),
                )
            }
            if (legs.isEmpty()) return@mapNotNull null
            Solution(from.name, to.name, legs.first().dep, legs.last().arr,
                s.s("durata").ifBlank { Fmt.duration(legs.first().dep, legs.last().arr) }, null, legs)
        }.filter { sol ->
            val cats = sol.legs.map { it.category.uppercase() }
            when (filter) {
                SearchFilter.FRECCE -> cats.all { c -> high.any { c.startsWith(it) } }
                SearchFilter.REGIONAL -> cats.all { c -> reg.any { c.startsWith(it) } }
                else -> true
            } && (!directOnly || sol.legs.size == 1)
        }
    }

    // ---------------- Trenord: affollamento ----------------

    /**
     * Percentuale di affollamento stimata da Trenord (0–100), se disponibile.
     * Servizio non documentato: in caso di errore restituisce null e l'app mostra il link al sito Trenord.
     */
    fun trenordCrowding(number: String): Int? = try {
        trenordMia(number)?.let { findCrowding(it) }
    } catch (e: Exception) {
        null
    }

    /** Risposta del servizio Trenord per il treno di oggi, tenuta 2 minuti (la usano affollamento e servizi a bordo). */
    private val miaCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, Any>>()

    private fun trenordMia(number: String, dayMs: Long = System.currentTimeMillis()): Any? {
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = rome }.format(Date(dayMs))
        val k = "$number|$day"
        miaCache[k]?.let { (t, v) -> if (System.currentTimeMillis() - t < 120_000L) return v }
        val body = get("https://admin.trenord.it/store-management-api/mia/train/" + enc(number) + "?journey_date=" + day).trim()
        val v: Any = if (body.startsWith("[")) JSONArray(body) else JSONObject(body)
        miaCache[k] = System.currentTimeMillis() to v
        return v
    }

    /**
     * Servizi a bordo pubblicati da Trenord (come sul sito trenord.it): bici, accessibilità per persone con
     * disabilità o ridotta mobilità, classi, Malpensa Express. Null se il treno non è Trenord o il dato manca.
     */
    fun trenordServices(number: String): TrainServices? = try {
        val root = trenordMia(number)
        val first = when (root) {
            is JSONArray -> root.optJSONObject(0)
            is JSONObject -> root
            else -> null
        }
        val train = first?.optJSONArray("journey_list")?.optJSONObject(0)?.optJSONObject("train") ?: first
        if (train == null || !(train.has("bicycle") || train.has("handicap"))) null
        else TrainServices(
            bike = train.optBoolean("bicycle"),
            accessible = train.optBoolean("handicap"),
            firstClass = train.optBoolean("class_1") || train.optBoolean("class_1_and_2"),
            secondClass = train.optBoolean("class_2") || train.optBoolean("class_1_and_2"),
            malpensa = train.optBoolean("mxp") || train.optBoolean("mxp_special"),
        )
    } catch (e: Exception) {
        null
    }

    private fun findCrowding(x: Any?): Int? {
        when (x) {
            is JSONObject -> {
                x.optJSONObject("crowding")?.let { c ->
                    val p = c.optDouble("percentage")
                    if (!p.isNaN()) return p.toInt().coerceIn(0, 100)
                }
                for (k in x.keys()) findCrowding(x.opt(k))?.let { return it }
            }
            is JSONArray -> for (i in 0 until x.length()) findCrowding(x.opt(i))?.let { return it }
        }
        return null
    }

    // ---------------- Coordinate stazioni / mappa ----------------

    fun stationCoord(store: Store, id: String): Pair<Double, Double>? {
        store.coord(id)?.let { return it }
        if (SwissLive.isSwiss(id)) return SwissLive.coord(id)?.also { store.setCoord(id, it) }
        if (GermanyLive.isTransitous(id)) return GermanyLive.coord(id)?.also { store.setCoord(id, it) }
        if (LocalRail.isLocal(id)) return LocalRail.coord(id)?.also { store.setCoord(id, it) }
        // Rete FerrovieNord: ViaggiaTreno non ha le coordinate di Varese Nord, Como Lago, Novara Nord…
        FnNetwork.coord(id)?.let { return it }
        return try {
            val reg = get(VT + "regione/$id").trim()
            val o = JSONObject(get(VT + "dettaglioStazione/$id/$reg"))
            val lat = o.optDouble("lat"); val lon = o.optDouble("lon")
            if (lat.isNaN() || lon.isNaN() || lat == 0.0) null else (lat to lon).also { store.setCoord(id, it) }
        } catch (e: Exception) {
            null
        }
    }

    data class GeoStation(val station: Station, val lat: Double, val lon: Double)

    /** Elenco completo stazioni con coordinate (scaricato una volta e salvato in memoria). */
    @Volatile private var allStationsMemo: List<GeoStation>? = null

    fun allStations(ctx: Context): List<GeoStation> {
        // L'elenco (circa 3000 stazioni) si legge e si analizza una volta sola per sessione
        allStationsMemo?.let { return it }
        return allStationsLoad(ctx).also { if (it.isNotEmpty()) allStationsMemo = it }
    }

    private fun allStationsLoad(ctx: Context): List<GeoStation> {
        val f = File(ctx.filesDir, "stations.json")
        val text = if (f.exists() && f.length() > 1000) f.readText() else {
            val out = JSONArray()
            val seen = HashSet<String>()
            for (reg in 0..22) {
                try {
                    val a = JSONArray(get(VT + "elencoStazioni/$reg"))
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        val id = o.s("codiceStazione")
                        if (id.isBlank() || !seen.add(id)) continue
                        val name = o.optJSONObject("localita")?.s("nomeLungo")?.ifBlank { null } ?: o.s("nomeCitta")
                        out.put(JSONObject().put("id", id).put("name", name).put("lat", o.optDouble("lat")).put("lon", o.optDouble("lon")))
                    }
                } catch (_: Exception) {
                }
            }
            if (out.length() == 0) throw IOException("Elenco stazioni non disponibile")
            out.toString().also { f.writeText(it) }
        }
        val a = JSONArray(text)
        val base = (0 until a.length()).mapNotNull { i ->
            val o = a.getJSONObject(i)
            val lat = o.optDouble("lat"); val lon = o.optDouble("lon")
            if (lat.isNaN() || lon.isNaN() || lat == 0.0) null
            else GeoStation(Station(o.optString("name"), o.optString("id")), lat, lon)
        }
        // Più le stazioni della rete FerrovieNord che l'elenco di ViaggiaTreno non contiene
        FnNetwork.ensure(ctx)
        val have = base.mapTo(HashSet()) { it.station.id }
        return base + FnNetwork.stations.filter { it.station.id !in have }
    }

    // ---------------- Accessibilità (RFI) ----------------

    data class AccessIssue(val station: String, val change: String, val endDate: String)

    /**
     * Variazioni di accessibilità (ascensori/rampe fuori servizio > 24h) pubblicate da RFI.
     * La pagina è una tabella HTML: la leggiamo e filtriamo per stazione.
     */
    fun rfiAccessIssues(stationName: String): List<AccessIssue> {
        val html = get("https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/stato-ascensori-e-rampe-di-accesso-ai-binari.html")
        val row = Regex("<tr[^>]*>(.*?)</tr>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val cell = Regex("<t[dh][^>]*>(.*?)</t[dh]>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val tag = Regex("<[^>]+>")
        val key = stationName.lowercase().replace(Regex("[^a-z0-9 ]"), " ").split(" ").filter { it.length > 2 }
        return row.findAll(html).mapNotNull { m ->
            val cells = cell.findAll(m.groupValues[1]).map {
                tag.replace(it.groupValues[1], " ").replace("&nbsp;", " ").replace(Regex("\\s+"), " ").trim()
            }.toList()
            if (cells.size < 2 || cells[0].equals("NOME STAZIONE", true)) null
            else AccessIssue(cells[0], cells[1], cells.getOrElse(2) { "" })
        }.filter { a -> key.isNotEmpty() && key.all { a.station.lowercase().contains(it) } }.toList()
    }

    // ---------------- News / infomobilità ----------------

    fun news(): List<NewsItem> {
        val a = JSONArray(get(VT + "news/0/it"))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            NewsItem(o.s("titolo"), o.s("testo"), o.l("data"))
        }
    }
}
