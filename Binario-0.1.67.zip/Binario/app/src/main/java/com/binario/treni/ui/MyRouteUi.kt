package com.binario.treni.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n
import com.binario.treni.data.MyRoute
import com.binario.treni.data.RouteNews
import java.util.Calendar

private fun tr(a: String, b: String) = I18n.tr(a, b)

/** Filtro delle notizie: tutte, solo la mia regione, solo la mia tratta nei miei orari. */
@Composable
fun NewsFilterBar(filter: String, route: MyRoute, onFilter: (String) -> Unit, onEdit: () -> Unit, onRegions: (Set<String>) -> Unit = {}) {
    var pickRegions by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            listOf("all" to tr("Tutte", "All"), "region" to tr("La mia regione", "My region"), "route" to tr("La mia tratta e orari", "My route and times"))
                .forEach { (k, label) ->
                    FilterChip(filter == k, {
                        onFilter(k)
                        if (k == "region" && route.regions.isEmpty()) pickRegions = true
                    }, label = { Text(label, fontSize = 13.sp) }, modifier = Modifier.padding(end = 6.dp))
                }
        }
        if (filter != "all") {
            // Riga di riepilogo con il tasto per cambiare: sempre visibile (prima il tasto "Imposta" finiva fuori schermo)
            Row(verticalAlignment = Alignment.CenterVertically) {
                val txt = when (filter) {
                    "region" -> if (route.regions.isEmpty()) tr("Nessuna regione scelta", "No region chosen")
                        else tr("Avvisi e scioperi di: ", "Notices and strikes in: ") + route.regions.sorted().joinToString() + tr(" (e senza regione indicata)", " (and with no region given)")
                    else -> if (route.complete) route.label + " · " + listOf(
                        route.out.takeIf { it.isNotBlank() }?.let { tr("andata ", "out ") + it },
                        route.back.takeIf { it.isNotBlank() }?.let { tr("ritorno ", "back ") + it },
                    ).filterNotNull().joinToString(", ") + " · " + daysLabel(route.days) + " · " + route.operators.joinToString()
                    else tr("Imposta la tua tratta e l'orario del treno di andata e/o ritorno", "Set your route and the time of your outbound and/or return train")
                }
                Text(txt, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton({ if (filter == "region") pickRegions = true else onEdit() }) {
                    Text(tr("Cambia", "Change"), color = Green)
                }
            }
        }
    }
    if (pickRegions) RegionDialog(route.regions, onDismiss = { pickRegions = false }) { g -> onRegions(g); pickRegions = false }
}

/** Scelta delle regioni per il filtro "La mia regione", con ripristino a Lombardia. */
@Composable
fun RegionDialog(initial: Set<String>, onDismiss: () -> Unit, onSave: (Set<String>) -> Unit) {
    var sel by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("La mia regione", "My region")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(tr("Mostra solo avvisi e scioperi che toccano queste regioni (più quelli nazionali). Puoi sceglierne più di una.",
                    "Show only notices and strikes that affect these regions (plus national ones). You can pick more than one."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
                RouteNews.REGIONS.forEach { g ->
                    Row(
                        Modifier.fillMaxWidth().clickable { sel = if (g in sel) sel - g else sel + g }.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(g in sel, { sel = if (g in sel) sel - g else sel + g }, colors = CheckboxDefaults.colors(checkedColor = Green))
                        Text(g)
                    }
                }
            }
        },
        confirmButton = {
            Button({ onSave(sel) }, enabled = sel.isNotEmpty(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr("Salva", "Save")) }
        },
        dismissButton = {
            Row {
                TextButton({ sel = setOf("Lombardia") }) { Text(tr("Reimposta", "Reset")) }
                TextButton(onDismiss) { Text(tr("Annulla", "Cancel")) }
            }
        },
    )
}

private val DAY_ORDER = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)
private fun dayShort(d: Int) = when (d) {
    Calendar.MONDAY -> tr("Lun", "Mon"); Calendar.TUESDAY -> tr("Mar", "Tue"); Calendar.WEDNESDAY -> tr("Mer", "Wed")
    Calendar.THURSDAY -> tr("Gio", "Thu"); Calendar.FRIDAY -> tr("Ven", "Fri"); Calendar.SATURDAY -> tr("Sab", "Sat"); else -> tr("Dom", "Sun")
}
private fun daysLabel(days: Set<Int>): String = when (days) {
    setOf(2, 3, 4, 5, 6) -> tr("lun–ven", "Mon–Fri")
    DAY_ORDER.toSet() -> tr("tutti i giorni", "every day")
    else -> DAY_ORDER.filter { it in days }.joinToString(" ") { dayShort(it) }
}

/** Imposta la tratta abituale: stazioni, orari di andata e ritorno, giorni, imprese e regioni. */
@Composable
fun MyRouteDialog(initial: MyRoute, onDismiss: () -> Unit, onSave: (MyRoute) -> Unit) {
    val ctx = LocalContext.current
    var r by remember { mutableStateOf(initial) }
    var picking by remember { mutableStateOf<Int?>(null) }
    fun pickTime(current: String, set: (String) -> Unit) {
        val m = Regex("^(\\d{1,2})[:.](\\d{2})").find(current)
        android.app.TimePickerDialog(ctx, { _, h, min -> set("%02d:%02d".format(h, min)) },
            m?.groupValues?.get(1)?.toInt() ?: 7, m?.groupValues?.get(2)?.toInt() ?: 30, true).show()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("La mia tratta", "My route")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                StationField(r.from?.name, tr("Partenza", "From")) { picking = 0 }
                Spacer(Modifier.height(6.dp))
                StationField(r.to?.name, tr("Arrivo", "To")) { picking = 1 }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton({ pickTime(r.out) { r = r.copy(out = it) } }, Modifier.weight(1f)) {
                        Text(tr("Andata ", "Out ") + r.out.ifBlank { "—" })
                    }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton({ pickTime(r.back) { r = r.copy(back = it) } }, Modifier.weight(1f)) {
                        Text(tr("Ritorno ", "Back ") + r.back.ifBlank { "—" })
                    }
                }
                Row {
                    if (r.out.isNotBlank()) TextButton({ r = r.copy(out = "") }) { Text(tr("Senza andata", "No outbound"), fontSize = 12.sp) }
                    if (r.back.isNotBlank()) TextButton({ r = r.copy(back = "") }) { Text(tr("Senza ritorno", "No return"), fontSize = 12.sp) }
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("Minuti da casa alla stazione di partenza", "Minutes from home to the departure station"), fontSize = 13.sp, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        r.walk.toString(), { v -> v.filter { it.isDigit() }.take(3).toIntOrNull()?.let { n -> r = r.copy(walk = n) } },
                        modifier = Modifier.width(80.dp), singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                    )
                }
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("Avvisi sul mio viaggio", "Alerts for my trip"), fontWeight = FontWeight.Medium)
                        Text(tr("«Esci di casa» prima del treno di andata, «Ultimo treno utile» la sera sul ritorno e «Coincidenza a rischio» quando un ritardo mette in pericolo un cambio. La partenza è la stazione vicino a casa.",
                            "«Leave home» before the outbound train, «Last useful train» in the evening on the return and «Connection at risk» when a delay endangers a change. The departure is the station near home."),
                            color = Muted, fontSize = 12.sp)
                    }
                    Switch(r.alerts, { r = r.copy(alerts = it) })
                }
                Text(tr("Giorni", "Days"), fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    DAY_ORDER.forEach { d ->
                        FilterChip(d in r.days, { r = r.copy(days = if (d in r.days) r.days - d else r.days + d) },
                            label = { Text(dayShort(d), fontSize = 12.sp) }, modifier = Modifier.padding(end = 4.dp))
                    }
                }
                Text(tr("Imprese che usi", "Operators you use"), fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    RouteNews.OPERATORS.forEach { o ->
                        FilterChip(o in r.operators, { r = r.copy(operators = if (o in r.operators) r.operators - o else r.operators + o) },
                            label = { Text(o, fontSize = 12.sp) }, modifier = Modifier.padding(end = 4.dp))
                    }
                }
                Text(tr("Regioni (anche per il filtro \"La mia regione\")", "Regions (also for the \"My region\" filter)"),
                    fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
                RouteNews.REGIONS.chunked(4).forEach { row ->
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        row.forEach { g ->
                            FilterChip(g in r.regions, { r = r.copy(regions = if (g in r.regions) r.regions - g else r.regions + g) },
                                label = { Text(g, fontSize = 12.sp) }, modifier = Modifier.padding(end = 4.dp))
                        }
                    }
                }
                Text(tr("Uno sciopero compare in \"La mia tratta\" se è nazionale o in una tua regione, riguarda una tua impresa (o tutte) e il suo orario copre il tuo treno di andata o di ritorno in un tuo giorno di viaggio.",
                    "A strike shows in \"My route\" if it is national or in one of your regions, involves one of your operators (or all) and its hours cover your outbound or return train on one of your travel days."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = {
            Button({ onSave(r) }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr("Salva", "Save")) }
        },
        dismissButton = { TextButton(onDismiss) { Text(tr("Annulla", "Cancel")) } },
    )
    picking?.let { w ->
        StationPickerDialog(if (w == 0) tr("Partenza", "From") else tr("Arrivo", "To"), { picking = null }) { s ->
            r = if (w == 0) r.copy(from = s) else r.copy(to = s)
            picking = null
        }
    }
}
