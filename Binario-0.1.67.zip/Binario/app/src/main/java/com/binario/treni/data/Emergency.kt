package com.binario.treni.data

import android.content.Context

/**
 * Emergenze per paese (Italia, Svizzera, Germania): numero da chiamare, app ufficiale che invia la posizione
 * e mappe ufficiali o complete dei defibrillatori. Il paese si sceglie in Impostazioni (predefinito: automatico,
 * dalla rete mobile a cui è collegato il telefono). Verificato il 30/10/2026.
 */
object Emergency {
    enum class Country(
        val code: String,
        val flag: String,
        val itName: String,
        val enName: String,
        /** Numero per ambulanza / emergenza sanitaria. */
        val number: String,
        /** App ufficiale di emergenza: nome, package Android, sito. */
        val appName: String,
        val appPackage: String,
        val appSite: String,
        val appItText: String,
        val appEnText: String,
        /** Mappa completa dei defibrillatori del paese. */
        val aedMapName: String,
        val aedMapUrl: String,
    ) {
        IT("it", "🇮🇹", "Italia", "Italy", "112", "AREU · 112 Where ARE U", "it.Beta80Group.whereareu", "https://www.areu.lombardia.it",
            "L'app ufficiale per chiamare il 112 inviando la tua posizione esatta.", "The official app to call 112 sending your exact location.",
            "AREU Lombardia · mappa DAE", DaeSources.AREU_MAP),
        CH("ch", "🇨🇭", "Svizzera", "Switzerland", "144", "Rega · 1414", "ch.rega.Rega", "https://www.rega.ch/en/rega-app",
            "L'app della Rega (soccorso aereo) invia la tua posizione alla centrale. Ambulanza: 144.",
            "The Rega (air rescue) app sends your location to the operations centre. Ambulance: 144.",
            "defikarte.ch · defibrillatori in Svizzera", "https://www.defikarte.ch"),
        DE("de", "🇩🇪", "Germania", "Germany", "112", "nora · Notruf-App", "de.noranotruf", "https://www.nora-notruf.de/en-en",
            "L'app di emergenza ufficiale dei Länder tedeschi: chiama 112 e 110 anche scrivendo, con la tua posizione.",
            "The official emergency app of the German federal states: reach 112 and 110 also in writing, with your location.",
            "OpenAEDMap · defibrillatori (OpenStreetMap)", "https://openaedmap.org"),
        ;

        val label: String get() = I18n.tr(itName, enName)
        val appText: String get() = I18n.tr(appItText, appEnText)
    }

    private const val PREF = "set_emergency_country"

    /** "auto" (dalla rete mobile), "it", "ch" o "de". */
    fun setting(ctx: Context): String = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).getString(PREF, "auto") ?: "auto"

    fun setSetting(ctx: Context, v: String) = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).edit().putString(PREF, v).apply()

    /** Paese dalla rete mobile: Svizzera (anche Liechtenstein), Germania, altrimenti Italia. */
    fun fromNetwork(ctx: Context): Country = try {
        val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
        when (tm.networkCountryIso.lowercase()) {
            "ch", "li" -> Country.CH
            "de" -> Country.DE
            else -> Country.IT
        }
    } catch (_: Exception) {
        Country.IT
    }

    fun current(ctx: Context): Country = when (setting(ctx)) {
        "it" -> Country.IT
        "ch" -> Country.CH
        "de" -> Country.DE
        else -> fromNetwork(ctx)
    }
}
