package com.binario.treni.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.Icon
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

/**
 * Un punto sulla mappa. [glyph] sceglie il segnalino in stile Trenord (goccia grigio scuro con cerchio bianco e simbolo):
 * "link" (My Link Point), "office" (biglietteria), "machine" (emettitrice), "reseller" (rivendita), "wc", "other".
 */
data class MapPoint(
    val lat: Double,
    val lon: Double,
    val title: String,
    val snippet: String = "",
    val glyph: String? = null,
    /** Colore del segnalino (es. in base al ritardo); null = colore predefinito della mappa. */
    val color: Int? = null,
    /** Ultimo parametro: le chiamate con lambda finale `MapPoint(...) { … }` la assegnano qui. */
    val onClick: (() -> Unit)? = null,
)

/**
 * Tessere della mappa. CARTO dal 2026 chiede una chiave a pagamento (mostrava "API KEY REQUIRED"),
 * quindi usiamo le tessere ufficiali di OpenStreetMap; se non rispondono passiamo a OpenStreetMap France.
 * Nessuna chiave necessaria; l'app si identifica con il proprio nome come chiede la policy OSM.
 */
internal val OsmStandard: OnlineTileSourceBase = XYTileSource(
    "OsmStandard", 0, 19, 256, ".png",
    arrayOf("https://tile.openstreetmap.org/"),
    "© OpenStreetMap contributors",
)
private val OsmFrance: OnlineTileSourceBase = XYTileSource(
    "OsmFrance", 0, 19, 256, ".png",
    arrayOf(
        "https://a.tile.openstreetmap.fr/osmfr/",
        "https://b.tile.openstreetmap.fr/osmfr/",
        "https://c.tile.openstreetmap.fr/osmfr/",
    ),
    "© OpenStreetMap contributors · OSM France",
)

/** Sorgente scelta dopo la prova (null = non ancora provata). */
@Volatile internal var chosenSource: OnlineTileSourceBase? = null

/** Prova una tessera: risponde con un'immagine PNG? */
private fun tileWorks(url: String): Boolean = try {
    val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
        connectTimeout = 6000; readTimeout = 8000
        setRequestProperty("User-Agent", org.osmdroid.config.Configuration.getInstance().userAgentValue)
    }
    try {
        c.responseCode == 200 && (c.contentType ?: "").startsWith("image")
    } finally {
        c.disconnect()
    }
} catch (e: Exception) {
    false
}

internal fun pickSource(map: MapView) {
    chosenSource?.let { if (map.tileProvider.tileSource.name() != it.name()) map.setTileSource(it); return }
    Thread {
        val src = when {
            tileWorks("https://tile.openstreetmap.org/6/33/23.png") -> OsmStandard
            tileWorks("https://a.tile.openstreetmap.fr/osmfr/6/33/23.png") -> OsmFrance
            else -> OsmStandard
        }
        chosenSource = src
        map.post { if (map.repository != null && map.tileProvider.tileSource.name() != src.name()) map.setTileSource(src) }
    }.start()
}

/** Apre Google Maps sul punto (o sul centro dei punti), con una ricerca facoltativa. */
fun openGoogleMapsAt(ctx: android.content.Context, lat: Double, lon: Double, query: String?) {
    if (!query.isNullOrBlank()) {
        googleMaps(ctx, lat, lon, query)
        return
    }
    val url = "https://www.google.com/maps/search/?api=1&query=$lat,$lon"
    try {
        ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            .setPackage("com.google.android.apps.maps"))
    } catch (e: Exception) {
        openUrl(ctx, url)
    }
}

/** Colori dei segnalini: la mia posizione in rosso, il punto scelto/cercato in blu, gli altri con il colore dell'app. */
private const val PIN_ME = 0xFFD32F2F.toInt()
private const val PIN_SELECTED = 0xFF1565C0.toInt()

/** Segnalino a goccia disegnato al volo (niente icone di sistema poco leggibili). */
private fun pinDrawable(ctx: android.content.Context, color: Int, big: Boolean = false): android.graphics.drawable.BitmapDrawable {
    val d = ctx.resources.displayMetrics.density
    val w = ((if (big) 34 else 28) * d).toInt()
    val h = (w * 1.35f).toInt()
    val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val r = w / 2f - 2 * d
    val cx = w / 2f
    val cy = r + 2 * d
    val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    val stroke = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        this.color = android.graphics.Color.WHITE; style = android.graphics.Paint.Style.STROKE; strokeWidth = 2.5f * d
    }
    val path = android.graphics.Path().apply {
        moveTo(cx - r * 0.62f, cy + r * 0.78f); lineTo(cx, h - 1.5f * d); lineTo(cx + r * 0.62f, cy + r * 0.78f); close()
    }
    c.drawPath(path, fill)
    c.drawCircle(cx, cy, r, fill)
    c.drawCircle(cx, cy, r, stroke)
    c.drawCircle(cx, cy, r * 0.38f, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { this.color = android.graphics.Color.WHITE })
    return android.graphics.drawable.BitmapDrawable(ctx.resources, bmp)
}

/** Grigio scuro dei segnalini in stile Trenord. */
private const val PIN_DARK = 0xFF3D3D3D.toInt()

/**
 * Segnalino in stile sito Trenord: goccia grigio scuro (blu se scelto) con un grande cerchio bianco e il simbolo
 * della categoria disegnato in grigio.
 */
private fun glyphPin(ctx: android.content.Context, glyph: String, selected: Boolean): android.graphics.drawable.BitmapDrawable {
    val d = ctx.resources.displayMetrics.density
    val w = ((if (selected) 44 else 38) * d).toInt()
    val h = (w * 1.32f).toInt()
    val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val r = w / 2f - 1.5f * d
    val cx = w / 2f
    val cy = r + 1.5f * d
    val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = if (selected) PIN_SELECTED else PIN_DARK
        setShadowLayer(2f * d, 0f, 1f * d, 0x66000000)
    }
    val path = android.graphics.Path().apply {
        addCircle(cx, cy, r, android.graphics.Path.Direction.CW)
        moveTo(cx - r * 0.62f, cy + r * 0.72f)
        lineTo(cx, h - 2f * d)
        lineTo(cx + r * 0.62f, cy + r * 0.72f)
        close()
    }
    c.drawPath(path, fill)
    val g = r * 0.74f
    c.drawCircle(cx, cy, g, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE })
    drawGlyph(c, glyph, cx, cy, g * 0.62f, d, if (selected) PIN_SELECTED else PIN_DARK)
    return android.graphics.drawable.BitmapDrawable(ctx.resources, bmp)
}

/** Simboli semplici disegnati a mano (niente icone di sistema): leggibili anche piccoli. */
private fun drawGlyph(c: android.graphics.Canvas, glyph: String, cx: Float, cy: Float, g: Float, d: Float, color: Int) {
    val st = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = android.graphics.Paint.Style.STROKE; strokeWidth = 1.6f * d
        strokeJoin = android.graphics.Paint.Join.ROUND; strokeCap = android.graphics.Paint.Cap.ROUND
    }
    val fl = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    val tx = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; textAlign = android.graphics.Paint.Align.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    fun text(s: String, size: Float) { tx.textSize = size; c.drawText(s, cx, cy - (tx.descent() + tx.ascent()) / 2, tx) }
    when (glyph) {
        "link" -> { c.drawCircle(cx, cy, g, st); text("i", g * 1.25f) }
        "office" -> {
            // Sportello: insegna, persona, banco
            c.drawRect(cx - g * 0.75f, cy - g * 0.95f, cx + g * 0.75f, cy - g * 0.55f, st)
            c.drawCircle(cx, cy - g * 0.12f, g * 0.22f, st)
            c.drawRect(cx - g * 0.85f, cy + g * 0.25f, cx + g * 0.85f, cy + g * 0.55f, st)
            c.drawRect(cx - g * 0.6f, cy + g * 0.55f, cx + g * 0.6f, cy + g * 0.95f, st)
        }
        "machine" -> {
            // Emettitrice: cassa con schermo, tastierino e fessura
            c.drawRoundRect(cx - g * 0.8f, cy - g * 0.9f, cx + g * 0.8f, cy + g * 0.9f, g * 0.12f, g * 0.12f, st)
            c.drawRect(cx - g * 0.55f, cy - g * 0.25f, cx - g * 0.05f, cy + g * 0.15f, st)
            for (i in 0..2) for (j in 0..2) c.drawCircle(cx + g * (0.22f + 0.17f * i), cy - g * (0.28f - 0.17f * j), 0.9f * d, fl)
            c.drawLine(cx - g * 0.8f, cy - g * 0.6f, cx + g * 0.8f, cy - g * 0.6f, st)
            c.drawLine(cx + g * 0.1f, cy + g * 0.55f, cx + g * 0.5f, cy + g * 0.55f, st)
        }
        "reseller" -> {
            // Negozio: tenda a spicchi, vetrina e porta
            val top = cy - g * 0.85f
            c.drawLine(cx - g * 0.85f, top, cx + g * 0.85f, top, st)
            for (k in 0..3) {
                val x0 = cx - g * 0.85f + k * g * 0.425f
                c.drawArc(x0, top - g * 0.05f, x0 + g * 0.425f, top + g * 0.5f, 0f, 180f, false, st)
            }
            c.drawRect(cx - g * 0.75f, top + g * 0.25f, cx + g * 0.75f, cy + g * 0.9f, st)
            c.drawRect(cx - g * 0.5f, cy + g * 0.05f, cx - g * 0.05f, cy + g * 0.9f, st)
            c.drawRect(cx + g * 0.12f, cy + g * 0.05f, cx + g * 0.55f, cy + g * 0.45f, st)
        }
        "wc" -> text("WC", g * 0.95f)
        "help" -> {
            // Croce verde: ospedale o farmacia
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFF2E7D32.toInt() }
            c.drawRect(cx - g * 0.25f, cy - g * 0.8f, cx + g * 0.25f, cy + g * 0.8f, p)
            c.drawRect(cx - g * 0.8f, cy - g * 0.25f, cx + g * 0.8f, cy + g * 0.25f, p)
        }
        "dae" -> {
            // Defibrillatore: cuore rosso con fulmine bianco (simbolo internazionale DAE)
            val heart = android.graphics.Path().apply {
                moveTo(cx, cy + g * 0.85f)
                cubicTo(cx - g * 1.25f, cy - g * 0.05f, cx - g * 0.75f, cy - g * 1.0f, cx, cy - g * 0.45f)
                cubicTo(cx + g * 0.75f, cy - g * 1.0f, cx + g * 1.25f, cy - g * 0.05f, cx, cy + g * 0.85f)
                close()
            }
            c.drawPath(heart, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFFD32F2F.toInt() })
            val bolt = android.graphics.Path().apply {
                moveTo(cx + g * 0.1f, cy - g * 0.55f); lineTo(cx - g * 0.3f, cy + g * 0.08f); lineTo(cx - g * 0.02f, cy + g * 0.08f)
                lineTo(cx - g * 0.12f, cy + g * 0.6f); lineTo(cx + g * 0.3f, cy - g * 0.08f); lineTo(cx + g * 0.02f, cy - g * 0.08f); close()
            }
            c.drawPath(bolt, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { this.color = android.graphics.Color.WHITE })
        }
        "bus" -> {
            // Bus: sagoma con finestrino e ruote
            c.drawRoundRect(cx - g * 0.75f, cy - g * 0.85f, cx + g * 0.75f, cy + g * 0.6f, g * 0.2f, g * 0.2f, st)
            c.drawRect(cx - g * 0.55f, cy - g * 0.6f, cx + g * 0.55f, cy - g * 0.05f, st)
            c.drawCircle(cx - g * 0.45f, cy + g * 0.8f, g * 0.14f, fl)
            c.drawCircle(cx + g * 0.45f, cy + g * 0.8f, g * 0.14f, fl)
        }
        else -> c.drawCircle(cx, cy, g * 0.35f, fl)
    }
}

/** Pallino rosso "sei qui" con alone. */
private fun meDrawable(ctx: android.content.Context): android.graphics.drawable.BitmapDrawable {
    val d = ctx.resources.displayMetrics.density
    val s = (30 * d).toInt()
    val bmp = android.graphics.Bitmap.createBitmap(s, s, android.graphics.Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    p.color = 0x55D32F2F; c.drawCircle(s / 2f, s / 2f, s / 2f, p)
    p.color = android.graphics.Color.WHITE; c.drawCircle(s / 2f, s / 2f, s * 0.30f, p)
    p.color = PIN_ME; c.drawCircle(s / 2f, s / 2f, s * 0.22f, p)
    return android.graphics.drawable.BitmapDrawable(ctx.resources, bmp)
}

/** Cerchio verde con il numero di punti raggruppati (come le mappe Trenord). */
private fun clusterDrawable(ctx: android.content.Context, color: Int, count: Int): android.graphics.drawable.BitmapDrawable {
    val d = ctx.resources.displayMetrics.density
    val s = ((when { count < 10 -> 36; count < 100 -> 42; else -> 50 }) * d).toInt()
    val bmp = android.graphics.Bitmap.createBitmap(s, s, android.graphics.Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    p.color = (color and 0x00FFFFFF) or 0x55000000; c.drawCircle(s / 2f, s / 2f, s / 2f, p)
    p.color = android.graphics.Color.WHITE; c.drawCircle(s / 2f, s / 2f, s * 0.40f, p)
    p.color = color; c.drawCircle(s / 2f, s / 2f, s * 0.36f, p)
    p.color = android.graphics.Color.WHITE
    p.textAlign = android.graphics.Paint.Align.CENTER
    p.typeface = android.graphics.Typeface.DEFAULT_BOLD
    p.textSize = (if (count < 100) 14 else 12) * d
    val label = if (count > 999) "999+" else count.toString()
    c.drawText(label, s / 2f, s / 2f - (p.descent() + p.ascent()) / 2, p)
    return android.graphics.drawable.BitmapDrawable(ctx.resources, bmp)
}

/** Raggruppa i segnalini vicini sullo schermo (celle di circa 56 dp) in base allo zoom attuale. */
private class Clusters {
    val extra = ArrayList<Marker>()
    var apply: (() -> Unit)? = null
    @Volatile var released = false
}

private fun distKm(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
    val r = FloatArray(1)
    android.location.Location.distanceBetween(a.first, a.second, b.first, b.second, r)
    return r[0] / 1000.0
}

/**
 * Mappa OpenStreetMap (nessuna chiave API necessaria).
 * - La mia posizione compare da sola in rosso (se il permesso di posizione è già concesso, altrimenti con il tasto "Dove sono").
 * - Il punto cercato ([target], es. la stazione) o quello toccato diventa blu; [selected] sceglie quello blu all'apertura
 *   (null = il più vicino a me, -1 = nessuno).
 */
@Composable
fun OsmMap(
    points: List<MapPoint>,
    drawLine: Boolean,
    modifier: Modifier = Modifier,
    me: Pair<Double, Double>? = null,
    googleQuery: String? = null,
    target: MapPoint? = null,
    selected: Int? = null,
    /** Raggruppa i punti vicini in cerchi numerati che si aprono ingrandendo (di serie con molti punti). */
    cluster: Boolean = !drawLine && points.size > 25,
    /** Se indicato, all'apertura inquadra solo i [fitNearest] punti più vicini al punto cercato (o a me), non tutti. */
    fitNearest: Int? = null,
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var autoMe by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Pair<Double, Double>?>(null) }
    var granted by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(hasLocation(ctx)) }
    val perm = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions(),
    ) { r -> granted = r.values.any { it } }
    androidx.compose.runtime.LaunchedEffect(granted, me) {
        if (me == null && granted) currentLocation(ctx)?.let { autoMe = it.latitude to it.longitude }
    }
    val here = me ?: autoMe
    // Punto blu: quello scelto, altrimenti il più vicino a me (servizi vicini), altrimenti nessuno
    val initialSel = when {
        selected != null -> selected
        target != null -> -1
        here != null && points.isNotEmpty() && !drawLine -> points.indices.minByOrNull { distKm(here, points[it].lat to points[it].lon) } ?: -1
        else -> -1
    }
    var sel by androidx.compose.runtime.remember(points.size, initialSel) { androidx.compose.runtime.mutableIntStateOf(initialSel) }
    val markers = androidx.compose.runtime.remember { ArrayList<Marker>() }
    val clusters = androidx.compose.runtime.remember { Clusters() }
    val brand = com.binario.treni.data.ColorBlind.brand.toInt()
    Box(modifier.clipToBounds()) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            clusters.released = false
            MapView(c).apply {
                setTileSource(chosenSource ?: OsmStandard)
                pickSource(this)
                setTilesScaledToDpi(true)
                setMultiTouchControls(true)
                setMinZoomLevel(4.0)
                setMaxZoomLevel(19.0)
                controller.setZoom(6.0)
                controller.setCenter(GeoPoint(42.5, 12.5))
                addMapListener(org.osmdroid.events.DelayedMapListener(object : org.osmdroid.events.MapListener {
                    override fun onScroll(event: org.osmdroid.events.ScrollEvent?) = false
                    override fun onZoom(event: org.osmdroid.events.ZoomEvent?): Boolean {
                        try { clusters.apply?.invoke() } catch (_: Exception) { }
                        return false
                    }
                }, 120))
            }
        },
        update = update@{ map ->
            val normalPin = pinDrawable(map.context, brand)
            val bluePin = pinDrawable(map.context, PIN_SELECTED, big = true)
            val glyphCache = HashMap<String, android.graphics.drawable.BitmapDrawable>()
            fun iconOf(i: Int, chosen: Boolean): android.graphics.drawable.Drawable {
                points.getOrNull(i)?.color?.let { col -> return glyphCache.getOrPut("c$col|$chosen") { pinDrawable(map.context, col, big = chosen) } }
                val gl = points.getOrNull(i)?.glyph ?: return if (chosen) bluePin else normalPin
                return glyphCache.getOrPut("$gl|$chosen") { glyphPin(map.context, gl, chosen) }
            }
            // Solo il colore del punto scelto è cambiato: aggiorna le icone senza ricentrare la mappa
            val sig = points.joinToString("|") { "${it.lat},${it.lon},${it.title},${it.color}" } + "|" + here + "|" + drawLine + "|" + target?.title + "|" + target?.lat + "|" + brand
            if (map.tag == sig) {
                markers.forEachIndexed { i, m -> m.icon = iconOf(i, i == sel) }
                clusters.apply?.invoke()
                map.invalidate()
                return@update
            }
            map.tag = sig
            map.overlays.clear()
            markers.clear()
            clusters.extra.clear()
            clusters.apply = null
            val gps = points.map { GeoPoint(it.lat, it.lon) }
            if (drawLine && gps.size > 1) {
                map.overlays.add(Polyline(map).apply {
                    setPoints(gps)
                    outlinePaint.color = brand
                    outlinePaint.strokeWidth = 10f
                })
            }
            points.forEachIndexed { i, p ->
                val m = Marker(map).apply {
                    position = gps[i]
                    title = p.title
                    snippet = p.snippet
                    icon = iconOf(i, i == sel)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    setOnMarkerClickListener { m, _ ->
                        if (sel == i && m.isInfoWindowShown) {
                            if (p.onClick != null) p.onClick.invoke() else m.closeInfoWindow()
                        } else {
                            sel = i
                            markers.forEachIndexed { k, o -> o.icon = iconOf(k, k == i) }
                            m.showInfoWindow()
                            map.invalidate()
                        }
                        true
                    }
                }
                markers += m
                map.overlays.add(m)
            }
            if (cluster && points.size > 1) {
                val green = brand
                clusters.apply = recluster@{
                    // La mappa può essere già stata chiusa (si esce dalla schermata mentre un aggiornamento è in coda):
                    // in quel caso non si crea nulla, altrimenti osmdroid va in crash
                    if (clusters.released || map.repository == null) return@recluster
                    val z = map.zoomLevelDouble
                    clusters.extra.forEach { map.overlays.remove(it) }
                    clusters.extra.clear()
                    // Molto vicino: tutti i segnalini singoli
                    if (z >= 17.5) { markers.forEach { it.setEnabled(true) }; map.invalidate(); return@recluster }
                    val world = 256.0 * Math.pow(2.0, z)
                    val cellX = 56.0 * 360.0 / world
                    val cellY = 56.0 * 2 * Math.PI / world
                    val groups = points.indices.filter { it != sel }.groupBy { i ->
                        val la = Math.toRadians(points[i].lat)
                        val y = Math.log(Math.tan(Math.PI / 4 + la / 2))
                        Math.floor(points[i].lon / cellX).toLong() * 1_000_003L + Math.floor(y / cellY).toLong()
                    }
                    markers.forEachIndexed { i, m -> m.setEnabled(i == sel) }
                    groups.values.forEach { g ->
                        if (g.size == 1) { markers[g[0]].setEnabled(true); return@forEach }
                        val la = g.map { points[it].lat }.average()
                        val lo = g.map { points[it].lon }.average()
                        val cm = Marker(map).apply {
                            position = GeoPoint(la, lo)
                            icon = clusterDrawable(map.context, green, g.size)
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                            setOnMarkerClickListener { _, mv ->
                                // Tocco sul cerchio: ingrandisce sui punti del gruppo
                                val box = BoundingBox.fromGeoPoints(g.map { GeoPoint(points[it].lat, points[it].lon) })
                                if (box.latitudeSpan < 0.0003 && box.longitudeSpan < 0.0003) {
                                    mv.controller.animateTo(GeoPoint(la, lo), 18.0, 400L)
                                } else mv.zoomToBoundingBox(box.increaseByScale(1.6f), true)
                                true
                            }
                        }
                        clusters.extra += cm
                        // Sotto i segnalini singoli, sopra il resto
                        map.overlays.add(cm)
                    }
                    map.invalidate()
                }
            }
            // Stazione o servizio cercato: sempre blu
            target?.let { t ->
                map.overlays.add(Marker(map).apply {
                    position = GeoPoint(t.lat, t.lon)
                    title = t.title
                    snippet = t.snippet
                    icon = bluePin
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                })
            }
            // Io: pallino rosso
            if (here != null) {
                map.overlays.add(Marker(map).apply {
                    position = GeoPoint(here.first, here.second)
                    title = com.binario.treni.data.tx("Sei qui")
                    icon = meDrawable(map.context)
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                })
            }
            map.overlays.add(org.osmdroid.views.overlay.CopyrightOverlay(map.context))
            // Inquadra tutti i punti; la mia posizione solo se è vicina (non rimpicciolire la mappa di un treno lontano)
            val ref = target?.let { it.lat to it.lon } ?: here
            val framed = if (fitNearest != null && ref != null && gps.size > fitNearest) {
                gps.sortedBy { distKm(ref, it.latitude to it.longitude) }.take(fitNearest)
            } else gps
            val pts = framed + listOfNotNull(target?.let { GeoPoint(it.lat, it.lon) })
            val meNear = here != null && (pts.isEmpty() || pts.any { distKm(here, it.latitude to it.longitude) < 30.0 })
            val all = pts + listOfNotNull(if (meNear && here != null) GeoPoint(here.first, here.second) else null)
            if (all.size > 1) {
                map.post { if (map.repository != null) map.zoomToBoundingBox(BoundingBox.fromGeoPoints(all).increaseByScale(1.25f), false) }
            } else if (all.size == 1) {
                map.controller.setZoom(14.0); map.controller.setCenter(all[0])
            }
            if (sel in points.indices) map.post { if (map.repository != null) try { markers.getOrNull(sel)?.showInfoWindow() } catch (_: Exception) { } }
            map.post { try { clusters.apply?.invoke() } catch (_: Exception) { } }
            map.invalidate()
        },
        onRelease = {
            clusters.released = true
            clusters.apply = null
            it.onDetach()
        },
    )
    // Posizione non ancora consentita: tasto per mostrarla
    if (me == null && !granted) {
        SmallFloatingActionButton(
            onClick = { perm.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp),
            containerColor = Color.White, contentColor = Color(PIN_ME),
        ) {
            Row(Modifier.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.MyLocation, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(com.binario.treni.data.tx("Dove sono"), fontSize = 13.sp)
            }
        }
    }
    // Google Maps sempre a portata di tasto, anche se le tessere non si caricano
    val gTarget = when {
        here != null -> here
        points.size == 1 -> points[0].lat to points[0].lon
        points.isNotEmpty() -> points.map { it.lat }.average() to points.map { it.lon }.average()
        else -> null
    }
    if (gTarget != null) {
        SmallFloatingActionButton(
            onClick = { openGoogleMapsAt(ctx, gTarget.first, gTarget.second, googleQuery) },
            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
            containerColor = Color.White, contentColor = Green,
        ) {
            Row(Modifier.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Map, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Google Maps", fontSize = 13.sp)
            }
        }
    }
    }
}

/** Tessere di OpenRailwayMap (stile «standard»): servono 512 px per tessera da 256, osmdroid le riduce. © OpenStreetMap contributors · Style CC-BY-SA 2.0 OpenRailwayMap. */
internal val OrmStandard: OnlineTileSourceBase = XYTileSource(
    "OpenRailwayMap", 2, 19, 256, ".png",
    arrayOf("https://tiles.openrailwaymap.org/standard/"),
    "© OpenStreetMap contributors · Style: CC-BY-SA 2.0 OpenRailwayMap",
)

/** Un pallino colorato (treno) sulla mappa dei treni. */
data class MapDot(val lat: Double, val lon: Double, val color: Int)

/** Comando alla mappa dei treni (centra su un punto o zoom): [id] cambia a ogni pressione così il comando si esegue una volta sola. */
data class MapCmd(val id: Int, val kind: String, val lat: Double = 0.0, val lon: Double = 0.0)

private fun dotDrawable(ctx: android.content.Context, color: Int): android.graphics.drawable.BitmapDrawable {
    val d = ctx.resources.displayMetrics.density
    val size = (22 * d).toInt()
    val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    p.color = android.graphics.Color.WHITE
    c.drawCircle(size / 2f, size / 2f, size / 2f - d, p)
    p.color = color
    c.drawCircle(size / 2f, size / 2f, size / 2f - 3.5f * d, p)
    return android.graphics.drawable.BitmapDrawable(ctx.resources, bmp)
}

/** Mappa con un pallino per treno; toccando un pallino si chiama [onTap] con la sua posizione nell'elenco. */
@Composable
fun TrainDotsMap(dots: List<MapDot>, modifier: Modifier = Modifier, rails: Boolean = false, cmd: MapCmd? = null, onTap: (Int) -> Unit) {
    val tap = androidx.compose.runtime.rememberUpdatedState(onTap)
    val lastCmd = androidx.compose.runtime.remember { intArrayOf(0) }
    AndroidView(
        modifier = modifier.clipToBounds(),
        factory = { c ->
            MapView(c).apply {
                setTileSource(chosenSource ?: OsmStandard)
                pickSource(this)
                setTilesScaledToDpi(true)
                setMultiTouchControls(true)
                setMinZoomLevel(4.0)
                setMaxZoomLevel(17.0)
                zoomController.setVisibility(org.osmdroid.views.CustomZoomButtonsController.Visibility.NEVER)
                controller.setZoom(5.4)
                controller.setCenter(GeoPoint(46.6, 10.5))
            }
        },
        update = update@{ map ->
            if (cmd != null && cmd.id != lastCmd[0]) {
                lastCmd[0] = cmd.id
                when (cmd.kind) {
                    "in" -> map.controller.zoomIn()
                    "out" -> map.controller.zoomOut()
                    "me" -> { map.controller.setZoom(11.0); map.controller.animateTo(GeoPoint(cmd.lat, cmd.lon)) }
                }
            }
            val sig = dots.size.toString() + "|" + dots.sumOf { it.lat + it.lon } + "|" + dots.sumOf { it.color.toLong() } + "|" + rails
            if (map.tag == sig) return@update
            map.tag = sig
            map.overlays.clear()
            // Binari e infrastrutture da OpenRailwayMap (solo se l'utente li accende; tessere richieste solo quando servono)
            if (rails) {
                val prov = org.osmdroid.tileprovider.MapTileProviderBasic(map.context, OrmStandard)
                map.overlays.add(org.osmdroid.views.overlay.TilesOverlay(prov, map.context).apply {
                    loadingBackgroundColor = android.graphics.Color.TRANSPARENT
                    loadingLineColor = android.graphics.Color.TRANSPARENT
                })
            }
            val cache = HashMap<Int, android.graphics.drawable.BitmapDrawable>()
            dots.forEachIndexed { i, d ->
                map.overlays.add(Marker(map).apply {
                    position = GeoPoint(d.lat, d.lon)
                    icon = cache.getOrPut(d.color) { dotDrawable(map.context, d.color) }
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    setInfoWindow(null)
                    setOnMarkerClickListener { _, _ -> tap.value(i); true }
                })
            }
            map.invalidate()
        },
        onRelease = { it.onDetach() },
    )
}
