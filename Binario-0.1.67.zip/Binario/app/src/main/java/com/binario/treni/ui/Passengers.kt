package com.binario.treni.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Pax
import com.binario.treni.data.tx

/** "1 adulto", "2 adulti, 1 ragazzo"… */
fun paxLabel(p: Pax): String {
    val a = if (p.adults == 1) tx("1 adulto") else "${p.adults} " + tx("adulti")
    val c = when (p.children) {
        0 -> ""
        1 -> ", " + tx("1 ragazzo")
        else -> ", ${p.children} " + tx("ragazzi")
    }
    return a + c
}

/** Scelta del numero di passeggeri (come nelle app di vendita): adulti 1–9, ragazzi 0–9. */
@Composable
fun PaxDialog(pax: Pax, onDismiss: () -> Unit, onDone: (Pax) -> Unit) {
    var adults by remember { mutableIntStateOf(pax.adults) }
    var children by remember { mutableIntStateOf(pax.children) }
    var rules by remember { mutableStateOf(false) }
    if (rules) AgeRulesDialog { rules = false }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Passeggeri")) },
        text = {
            Column {
                PaxStepper(tx("Adulti"), "", adults, 1, 9 - children) { adults = it }
                PaxStepper(tx("Ragazzi"), tx("da 4 a 14 anni (sotto i 4 anni gratis senza posto)"), children, 0, 9 - adults) { children = it }
                Spacer(Modifier.height(6.dp))
                Text(tx("I prezzi mostrati sono il totale per tutti i passeggeri."), color = Muted, fontSize = 12.sp)
                Text(tx("Gli sconti per età cambiano in base ai paesi e alle aziende: qui i ragazzi sono da 4 a 14 anni, ma altre aziende usano altre età. Sconti per famiglie: verifica all'acquisto."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                TextButton({ rules = true }, contentPadding = PaddingValues(0.dp)) { Text(tx("Regole per età di ogni azienda"), color = Green) }
            }
        },
        confirmButton = { TextButton({ onDone(Pax(adults, children)) }) { Text(tx("Fatto"), color = Green) } },
        dismissButton = { TextButton(onDismiss) { Text(tx("Annulla")) } },
    )
}

@Composable
private fun PaxStepper(title: String, sub: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 12.sp)
        }
        IconButton({ if (value > min) onChange(value - 1) }, enabled = value > min) { Icon(Icons.Filled.Remove, tx("Meno")) }
        Text("$value", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.widthIn(min = 24.dp))
        IconButton({ if (value < max) onChange(value + 1) }, enabled = value < max) { Icon(Icons.Filled.Add, tx("Più"), tint = Green) }
    }
}
