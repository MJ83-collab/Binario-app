package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Treni in Germania: ICE, IC/EC, RE/RB, S-Bahn, FlixTrain, treni notte e tutte le aziende regionali
 * (DB Regio, Arverio, Bayerische Regiobahn, Länderbahn, metronom, ODEG, NordWestBahn…).
 *
 * Fonte: Transitous (api.transitous.org), che raccoglie gli orari ufficiali tedeschi DELFI (GTFS) con il tempo reale
 * (ritardi, binari, soppressioni) quando pubblicato. Verificato il 30/10/2026 su München Hbf e München → Berlin.
 * La vecchia API pubblica di Deutsche Bahn (v6.db.transport.rest) è stata spenta: per questo i prezzi non sono
 * disponibili nell'app e si rimanda a bahn.de (con la nota del Deutschlandticket per i soli treni regionali).
 *
 * Le stazioni hanno id "DE" + id Transitous (es. "DEat-Railway-Current-Reference-Data-2026_de:09162:100:11:11").
 */
object GermanyLive {
    private const val BASE = "https://api.transitous.org/api/v1/"
    const val PREFIX = "DE"
    const val SUFFIX = " (DE)"
    const val SOURCE = "Transitous · orari ufficiali DELFI"

    /** Treni (niente bus, tram e metropolitana; la S-Bahn sì). */
    private val RAIL = setOf("RAIL", "REGIONAL_RAIL", "REGIONAL_FAST_RAIL", "SUBURBAN", "HIGHSPEED_RAIL", "LONG_DISTANCE", "NIGHT_RAIL")

    val coords = java.util.concurrent.ConcurrentHashMap<String, Pair<Double, Double>>()
    private val utc = TimeZone.getTimeZone("UTC")

    fun isGerman(id: String) = id.startsWith(PREFIX)

    /** Austria e Francia usano lo stesso motore (Transitous) con prefisso proprio: "AT…" e "FR…". */
    const val AT = "AT"
    const val FR = "FR"
    private val ABROAD = listOf(AT, FR)
    fun isAbroad(id: String) = ABROAD.any { id.startsWith(it) }
    /** Stazione tedesca, austriaca o francese presa da Transitous. */
    fun isTransitous(id: String) = isGerman(id) || isAbroad(id)
    /** Prefisso del paese di una stazione (2 lettere). */
    fun prefixOf(id: String) = id.take(2)
    /** Codice treno "DE|…", "AT|…" o "FR|…" (originCode). */
    fun isTransitousRef(code: String) = code.length > 3 && code[2] == '|' && code.take(2) in setOf(PREFIX, AT, FR)
    private fun stopId(id: String) = id.drop(2)

    private fun get(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 25000
            setRequestProperty("User-Agent", "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)")
            setRequestProperty("Accept-Language", "de")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun JSONObject.str(k: String): String = if (!has(k) || isNull(k)) "" else optString(k)

    private fun parseTime(s: String): Long = if (s.isBlank()) 0L else try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = utc }.parse(s)?.time ?: 0L
    } catch (_: Exception) {
        0L
    }

    private fun iso(t: Long) = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = utc }.format(Date(t))
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Nomi italiani e inglesi delle città tedesche → nome tedesco usato negli orari. */
    private val EXONYMS = mapOf(
        "monaco di baviera" to "München", "monaco baviera" to "München", "munich" to "München", "munchen" to "München",
        "berlino" to "Berlin", "amburgo" to "Hamburg", "colonia" to "Köln", "cologne" to "Köln", "koln" to "Köln",
        "francoforte" to "Frankfurt", "stoccarda" to "Stuttgart", "norimberga" to "Nürnberg", "nuremberg" to "Nürnberg",
        "nurnberg" to "Nürnberg", "lipsia" to "Leipzig", "dresda" to "Dresden", "brema" to "Bremen", "hanover" to "Hannover",
        "annover" to "Hannover", "magonza" to "Mainz", "treviri" to "Trier", "aquisgrana" to "Aachen", "ratisbona" to "Regensburg",
        "augusta" to "Augsburg", "friburgo" to "Freiburg", "costanza" to "Konstanz", "passavia" to "Passau",
        "dusseldorf" to "Düsseldorf", "wurzburg" to "Würzburg", "lubecca" to "Lübeck", "lubeck" to "Lübeck",
        "brunswick" to "Braunschweig", "coblenza" to "Koblenz", "heidelberga" to "Heidelberg", "garmisch" to "Garmisch-Partenkirchen",
    )

    private fun germanQuery(q: String): String {
        val l = q.trim().lowercase(Locale.ITALY)
        EXONYMS.entries.sortedByDescending { it.key.length }.firstOrNull { l == it.key || l.startsWith(it.key + " ") }?.let { (k, v) ->
            return v + q.trim().substring(k.length)
        }
        return q.trim()
    }

    private fun isRail(modes: JSONArray?): Boolean = modes != null && (0 until modes.length()).any { modes.optString(it) in RAIL }

    /** Città della fermata (per "Hauptbahnhof (tief)" → "Stuttgart Hauptbahnhof (tief)"). */
    private fun city(o: JSONObject): String {
        val a = o.optJSONArray("areas") ?: return ""
        val list = (0 until a.length()).map { a.getJSONObject(it) }
        return (list.firstOrNull { it.optBoolean("default") } ?: list.firstOrNull { it.optInt("adminLevel") == 6 })?.str("name").orEmpty()
    }

    private fun displayName(o: JSONObject): String {
        val n = o.str("name")
        val c = city(o)
        return if (c.isNotBlank() && !n.contains(c, true) && !n.contains(c.substringBefore(' '), true)) "$c $n" else n
    }

    private fun remember(o: JSONObject?, px: String = PREFIX) {
        o ?: return
        val id = o.str("stopId").ifBlank { o.str("id") }
        if (id.isBlank() || !o.has("lat")) return
        coords[px + id] = o.optDouble("lat") to o.optDouble("lon")
    }

    /** Stazioni ferroviarie in Germania che corrispondono al testo (anche "Monaco di Baviera", "Colonia"…). */
    fun searchStations(q: String): List<Station> = searchCountry(q, PREFIX)

    /** Nomi italiani e inglesi di città austriache e francesi → nome locale. */
    private val EXONYMS_ABROAD = mapOf(
        "vienna" to "Wien", "salisburgo" to "Salzburg", "villaco" to "Villach", "bolzano" to "Bolzano", "brennero" to "Brenner",
        "parigi" to "Paris", "lione" to "Lyon", "marsiglia" to "Marseille", "nizza" to "Nice", "strasburgo" to "Strasbourg",
        "digione" to "Dijon", "tolosa" to "Toulouse", "bordeaux" to "Bordeaux", "montpellier" to "Montpellier", "mentone" to "Menton",
        "avignone" to "Avignon", "cannes" to "Cannes", "chambery" to "Chambéry", "ginevra" to "Genève", "ventimiglia" to "Vintimille",
    )

    private fun abroadQuery(q: String): String {
        val l = q.trim().lowercase(Locale.ITALY)
        EXONYMS_ABROAD.entries.sortedByDescending { it.key.length }.firstOrNull { l == it.key || l.startsWith(it.key + " ") }?.let { (k, v) ->
            return v + q.trim().substring(k.length)
        }
        return q.trim()
    }

    /** Stazioni ferroviarie del paese [px] ("DE", "AT" o "FR") che corrispondono al testo. */
    fun searchCountry(q: String, px: String): List<Station> = try {
        val text = if (px == PREFIX) germanQuery(q) else abroadQuery(q)
        val lang = if (px == FR) "fr" else "de"
        val a = JSONArray(get(BASE + "geocode?type=STOP&language=$lang&text=" + enc(text)))
        val words = text.lowercase(Locale.GERMANY).split(Regex("[\\s()/-]+")).filter { it.length >= 3 }
        fun simple(s: String) = java.text.Normalizer.normalize(s.lowercase(Locale.GERMANY).replace("ß", "ss"), java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        val suffix = " ($px)"
        (0 until a.length()).map { a.getJSONObject(it) }
            .filter { o -> o.str("country") == px && isRail(o.optJSONArray("modes")) }
            // Solo risultati che contengono davvero il testo cercato (niente "Frankfurt … Münchener Straße" cercando München)
            .filter { o -> val n = simple(displayName(o)); words.isEmpty() || words.all { w -> n.contains(simple(w)) || (simple(w) in setOf("hbf", "hauptbahnhof") && (n.contains("hbf") || n.contains("hauptbahnhof"))) } }
            .map { o -> remember(o, px); Station(displayName(o) + suffix, px + o.str("id")) }
            .distinctBy { it.name.lowercase() }
            .take(5)
    } catch (_: Exception) {
        emptyList()
    }

    fun coord(id: String): Pair<Double, Double>? = coords[id]

    /** "DB Regio AG S-Bahn München" → "S-Bahn München", "DB Fernverkehr AG" → "DB Fernverkehr", "Deutsche Bahn AG" → "DB". */
    fun operatorOf(agency: String): String {
        val a = agency.trim()
        Railways.match(a)?.let { if (it.country == Railways.Country.DE) return it.short }
        return a.replace(Regex("^DB Regio AG\\s+(?=S-Bahn)"), "").replace("Deutsche Bahn AG", "DB")
            .replace(Regex("\\s+(AG|GmbH|GmbH & Co\\. KG|mbH|KG|e\\.V\\.)$"), "").trim()
    }

    /**
     * Impresa di un treno di una soluzione di viaggio: anche i tratti in Svizzera, Austria e Italia
     * ("Schweizerische Bundesbahnen SBB" → "SBB", "Trenitalia S.p.A." → "Trenitalia").
     */
    fun legOperator(agency: String): String {
        val a = agency.trim()
        if (a.isBlank()) return ""
        Railways.match(a)?.let { if (it.country == Railways.Country.DE) return it.short }
        val u = a.uppercase()
        return when {
            u.contains("TILO") -> "TILO"
            u.contains("TRENORD") -> "Trenord"
            u.contains("TRENITALIA") -> "Trenitalia"
            u.contains("ITALO") || u.contains("NTV") -> "Italo"
            u.contains("ÖBB") || u.contains("OEBB") || u.contains("ÖSTERREICHISCHE BUNDESBAHNEN") -> "ÖBB"
            u.contains("SBB") || u.contains("SCHWEIZERISCHE BUNDESBAHNEN") || u.contains("CFF") -> "SBB"
            u.contains("SNCF") -> "SNCF"
            else -> Railways.match(a)?.short ?: operatorOf(a)
        }
    }

    /** "RB55 (77307)" → ("RB55", "77307"); "ICE 1211" → ("ICE", "1211"); "S4" + "008429" → ("S4", "8429"). */
    private fun catNum(route: String, trip: String): Pair<String, String> {
        val r = route.trim()
        Regex("^([A-Za-zÄÖÜ]+\\s?\\d*)\\s*\\((\\d+)\\)$").find(r)?.let { return it.groupValues[1].replace(" ", "") to it.groupValues[2].trimStart('0') }
        Regex("^([A-Za-z]+)\\s+(\\d+)$").find(r)?.let { return it.groupValues[1] to it.groupValues[2] }
        val num = trip.trim().let { t -> if (t.contains(' ')) t.substringAfterLast(' ') else t }.trimStart('0')
        return r to num
    }

    /** Il treno è una S-Bahn o un treno vero (la metropolitana e il tram no). */
    private fun keep(mode: String, route: String, agency: String): Boolean =
        mode in RAIL || (mode == "METRO" && (Regex("^S\\d").containsMatchIn(route) || agency.contains("S-Bahn", true)))

    /** Partenze (o arrivi, con [arrivals]) dalla stazione tedesca, in tempo reale quando pubblicato. */
    fun board(st: Station, time: Long, arrivals: Boolean = false): List<BoardItem> {
        val px = prefixOf(st.id)
        val o = JSONObject(get(BASE + "stoptimes?n=250&stopId=" + enc(stopId(st.id)) + "&time=" + enc(iso(time)) +
            (if (arrivals) "&arriveBy=true" else "")))
        remember(o.optJSONObject("place"), px)
        val a = o.optJSONArray("stopTimes") ?: return emptyList()
        val items = (0 until a.length()).mapNotNull { i ->
            val s = a.getJSONObject(i)
            val route = s.str("routeShortName").ifBlank { s.str("displayName") }
            val agency = s.str("agencyName")
            if (!keep(s.str("mode"), route, agency)) return@mapNotNull null
            val p = s.optJSONObject("place") ?: return@mapNotNull null
            val sched = parseTime(p.str(if (arrivals) "scheduledArrival" else "scheduledDeparture")).takeIf { it > 0 } ?: return@mapNotNull null
            val real = parseTime(p.str(if (arrivals) "arrival" else "departure")).takeIf { it > 0 } ?: sched
            val rt = s.optBoolean("realTime")
            val (cat, num) = catNum(route, s.str("tripShortName"))
            // Senza tempo reale il campo "track" a volte non è affidabile: si usa il binario programmato
            val schedTrack = p.str("scheduledTrack").ifBlank { if (rt) "" else p.str("track") }
            val track = if (rt) p.str("track") else ""
            val cancelled = s.optBoolean("cancelled") || s.optBoolean("tripCancelled")
            Triple(s.str("tripId"), sched, BoardItem(
                number = num, category = if (cancelled) "$cat ✕" else cat,
                otherEnd = if (arrivals) s.optJSONObject("tripFrom")?.str("name").orEmpty().ifBlank { s.str("headsign") } else s.str("headsign"),
                time = sched, delay = if (rt) ((real - sched) / 60_000L).toInt() else 0,
                platform = track.ifBlank { schedTrack }, platformConfirmed = rt && track.isNotBlank(),
                originCode = px + "|" + s.str("tripId"), departureDate = sched, inStation = false,
                schedPlatform = schedTrack, realPlatform = track, operator = if (px == PREFIX) operatorOf(agency) else legOperator(agency),
            ))
        }
        // Lo stesso treno può arrivare da due fonti (es. ICE verso l'Austria): si tiene quella tedesca (DELFI)
        // (a volte con sigla diversa: "RJ 113" e "ICE 113" sono lo stesso treno) → stesso numero e stesso orario
        return items.groupBy { (_, sched, b) -> b.number.ifBlank { b.category } + "|" + sched }
            .values.map { same -> (same.firstOrNull { it.first.contains("de-DELFI") } ?: same.first()).third }
            .sortedBy { it.time }
    }

    private fun simpleName(s: String) = java.text.Normalizer.normalize(s.lowercase(Locale.ITALY), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9]+"), "")

    /**
     * Cerca su Transitous la corsa di un treno italiano (Trenord, Trenitalia, TILO…) dal tabellone della fermata [stopName]:
     * stesso numero di treno oppure stessa ora di partenza (±1 min) e stessa destinazione. Restituisce il riferimento "DE|tripId"
     * da passare a [status], oppure null. [near] = coordinate della fermata per scegliere la più vicina fra omonime.
     */
    fun findTripRef(number: String, stopName: String, near: Pair<Double, Double>?, sched: Long, destination: String, country: String? = "IT"): TrainRef? = try {
        val g = JSONArray(get(BASE + "geocode?type=STOP&language=it&text=" + enc(stopName)))
        val cands = (0 until g.length()).map { g.getJSONObject(it) }.filter { isRail(it.optJSONArray("modes")) }
        val pick = cands.filter { country == null || it.str("country") == country || it.str("country").isBlank() }.let { l ->
            if (near != null) l.minByOrNull { o -> Math.abs(o.optDouble("lat", 0.0) - near.first) + Math.abs(o.optDouble("lon", 0.0) - near.second) }
            else l.firstOrNull { simpleName(displayName(it)) == simpleName(stopName) } ?: l.firstOrNull()
        } ?: throw IOException("fermata non trovata")
        val o = JSONObject(get(BASE + "stoptimes?n=40&stopId=" + enc(pick.str("id")) + "&time=" + enc(iso(sched - 120_000L))))
        val a = o.optJSONArray("stopTimes") ?: throw IOException("nessun orario")
        val items = (0 until a.length()).map { a.getJSONObject(it) }
        val dest = simpleName(destination)
        fun depOf(s: JSONObject): Long = parseTime(s.optJSONObject("place")?.str("scheduledDeparture").orEmpty())
        val byNumber = items.firstOrNull { s ->
            val digits = (s.str("tripShortName") + " " + s.str("routeShortName") + " " + s.str("displayName")).split(Regex("\\D+")).filter { it.isNotBlank() }.map { it.trimStart('0') }
            number.trimStart('0') in digits && Math.abs(depOf(s) - sched) <= 30 * 60_000L
        }
        val hit = byNumber ?: items.firstOrNull { s ->
            val h = simpleName(s.str("headsign"))
            Math.abs(depOf(s) - sched) <= 60_000L && dest.isNotBlank() && h.isNotBlank() && (h.contains(dest) || dest.contains(h))
        }
        hit?.str("tripId")?.takeIf { it.isNotBlank() }?.let { TrainRef(number, "$PREFIX|$it", sched, number) }
    } catch (_: Exception) {
        null
    }

    /** Scheda del treno: tutte le fermate della corsa, con ritardi e binari. */
    fun status(ref: TrainRef): TrainStatus {
        val px = ref.originCode.take(2).takeIf { isTransitousRef(ref.originCode) } ?: PREFIX
        val tripId = ref.originCode.removePrefix("$px|")
        val o = JSONObject(get(BASE + "trip?tripId=" + enc(tripId)))
        val leg = o.optJSONArray("legs")?.optJSONObject(0) ?: throw IOException(I18n.tr("Corsa non trovata", "Trip not found"))
        val now = System.currentTimeMillis()
        val rt = leg.optBoolean("realTime")
        fun stop(p: JSONObject): TrainStop {
            remember(p, px)
            val sa = parseTime(p.str("scheduledArrival")); val sd = parseTime(p.str("scheduledDeparture"))
            val ra = parseTime(p.str("arrival")).takeIf { it > 0 } ?: sa
            val rd = parseTime(p.str("departure")).takeIf { it > 0 } ?: sd
            val delay = if (rt) ((if (rd > 0 && sd > 0) rd - sd else ra - sa) / 60_000L).toInt() else 0
            val schedTrack = p.str("scheduledTrack").ifBlank { if (rt) "" else p.str("track") }
            val track = if (rt) p.str("track") else ""
            return TrainStop(p.str("name"), px + p.str("stopId"), sa, sd,
                if (ra in 1 until now) ra else 0L, if (rd in 1 until now) rd else 0L, delay, track.ifBlank { schedTrack },
                track.isNotBlank() && schedTrack.isNotBlank() && track != schedTrack, rt && track.isNotBlank(), schedTrack, track)
        }
        val stops = buildList {
            leg.optJSONObject("from")?.let { add(stop(it)) }
            leg.optJSONArray("intermediateStops")?.let { arr -> (0 until arr.length()).forEach { add(stop(arr.getJSONObject(it))) } }
            leg.optJSONObject("to")?.let { add(stop(it)) }
        }
        val (cat, num) = catNum(leg.str("routeShortName").ifBlank { leg.str("displayName") }, leg.str("tripShortName"))
        return TrainStatus(
            number = num.ifBlank { ref.number }, category = cat,
            origin = leg.optJSONObject("tripFrom")?.str("name") ?: stops.firstOrNull()?.name.orEmpty(),
            destination = leg.str("headsign").ifBlank { stops.lastOrNull()?.name.orEmpty() },
            originCode = ref.originCode, date = stops.firstOrNull()?.schedDep ?: 0L,
            delay = stops.lastOrNull { it.passed }?.delay ?: stops.firstOrNull()?.delay ?: 0, lastStation = "", lastTime = 0L,
            cancelled = leg.optBoolean("cancelled") || leg.optBoolean("tripCancelled"), stops = stops,
            info = (leg.str("routeLongName").takeIf { it.isNotBlank() }?.let { "$it\n" } ?: "") +
                (if (rt) I18n.tr("Tempo reale · ", "Real time · ") else I18n.tr("Orario programmato (tempo reale non pubblicato per questa corsa) · ", "Scheduled times (no real time for this trip) · ")) +
                SOURCE,
            operator = if (px == PREFIX) operatorOf(leg.str("agencyName")) else legOperator(leg.str("agencyName")),
        )
    }

    /** Fermata per pianificare: tedesca (id diretto) oppure italiana/svizzera cercata per nome (viaggi Italia ⇄ Germania). */
    private fun placeFor(st: Station): String? {
        if (isTransitous(st.id)) return stopId(st.id)
        val name = st.name.substringBefore(" (").trim()
        return try {
            val a = JSONArray(get(BASE + "geocode?type=STOP&text=" + enc(name)))
            (0 until a.length()).map { a.getJSONObject(it) }.firstOrNull { isRail(it.optJSONArray("modes")) }?.str("id")
        } catch (_: Exception) {
            null
        }
    }

    /** Soluzioni di viaggio da/per la Germania (anche con cambi e da/per l'Italia). Prezzi: su bahn.de. */
    fun solutions(from: Station, to: Station, time: Long, directOnly: Boolean = false): List<Solution> {
        val f = placeFor(from) ?: throw IOException(I18n.tr("Stazione di partenza non trovata negli orari tedeschi", "Departure station not found"))
        val t = placeFor(to) ?: throw IOException(I18n.tr("Stazione di arrivo non trovata negli orari tedeschi", "Arrival station not found"))
        val o = JSONObject(get(BASE + "plan?numItineraries=6&transitModes=RAIL&fromPlace=" + enc(f) + "&toPlace=" + enc(t) +
            "&time=" + enc(iso(time)) + (if (directOnly) "&maxTransfers=0" else "")))
        val its = o.optJSONArray("itineraries") ?: return emptyList()
        return (0 until its.length()).mapNotNull { i ->
            val itin = its.getJSONObject(i)
            val arr0 = itin.optJSONArray("legs") ?: return@mapNotNull null
            val legs = (0 until arr0.length()).map { k -> arr0.getJSONObject(k) }.filter { l -> l.str("mode") != "WALK" }.map { l ->
                val (cat, num) = catNum(l.str("routeShortName").ifBlank { l.str("displayName") }, l.str("tripShortName"))
                Leg(
                    number = num, category = if (l.str("mode") == "BUS" || l.str("mode") == "COACH") "BUS" else cat,
                    from = l.optJSONObject("from")?.str("name").orEmpty(), to = l.optJSONObject("to")?.str("name").orEmpty(),
                    dep = parseTime(l.str("startTime")), arr = parseTime(l.str("endTime")),
                    operator = legOperator(l.str("agencyName")),
                )
            }
            if (legs.isEmpty()) return@mapNotNull null
            val dep = parseTime(itin.str("startTime")); val arr = parseTime(itin.str("endTime"))
            Solution(from.name, to.name, dep, arr, Fmt.duration(dep, arr), null, legs,
                source = if (isGerman(from.id) || isGerman(to.id)) "bahn.de" else "transitous")
        }.distinctBy { s -> s.dep.toString() + s.legs.joinToString { it.title } }
    }

    // ---------------- Biglietti, stazioni, assistenza ----------------

    /** Categorie regionali: valide con il Deutschlandticket (non ICE, IC, EC, FlixTrain, treni notte). */
    fun isRegional(category: String): Boolean {
        val c = category.uppercase().trim()
        return Regex("^(RE|RB|S|IRE|MEX|RS|ERB|BRB|NWB|ALX|ME|HLB|RT|FEX|TER)\\s?\\d*$").matches(c) || c.startsWith("S") && c.drop(1).all { it.isDigit() }
    }

    /** Tutti i treni della soluzione sono regionali: viaggio coperto dal Deutschlandticket. */
    fun deutschlandTicketOk(s: Solution): Boolean = s.legs.isNotEmpty() && s.legs.all { isRegional(it.category) || it.category == "BUS" }

    /** Prezzo del Deutschlandticket (verificato su regional.bahn.de il 30/10/2026): 63 € fino al 31/12/2026, poi 66,80 €. */
    fun deutschlandTicketPrice(now: Long = System.currentTimeMillis()): String =
        if (now < 1798758000000L) "63 €" else "66,80 €" // 1/1/2027 00:00 ora tedesca

    /** Ricerca su bahn.de con partenza, arrivo e ora già compilati. */
    fun bahnUrl(from: String, to: String, time: Long): String {
        val t = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("Europe/Berlin") }.format(Date(time))
        fun clean(n: String) = n.removeSuffix(SUFFIX).substringBefore(" (").trim()
        return "https://www.bahn.de/buchung/fahrplan/suche#sts=true&so=" + enc(clean(from)) + "&zo=" + enc(clean(to)) + "&kl=2&hd=" + enc(t) + "&hza=D"
    }

    /** Pagina della stazione su bahnhof.de ("München Hbf" → https://www.bahnhof.de/muenchen-hbf). */
    fun bahnhofUrl(name: String, page: String = ""): String {
        val slug = name.removeSuffix(SUFFIX).substringBefore(" (").lowercase(Locale.GERMANY)
            .replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
            .replace("hauptbahnhof", "hbf").replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return "https://www.bahnhof.de/$slug" + (if (page.isNotBlank()) "/$page" else "")
    }

    /** Mobilitätsservice-Zentrale DB (assistenza per persone con disabilità), verificato su bahn.de il 30/10/2026. */
    const val MSZ_PHONE = "+493065212888"
    const val MSZ_LABEL = "030 65212888"
    const val MSZ_FORM = "https://msz.bahnhof.de"

    // ---------------- Stazioni vicine ----------------

    /** Vero se la posizione è (circa) in Germania. */
    fun inGermany(lat: Double, lon: Double) = lat in 47.2..55.1 && lon in 5.8..15.1

    /**
     * Stazioni ferroviarie tedesche vicine (orari DELFI), per «Stazioni vicine»: fermate in un riquadro attorno
     * alla posizione (prima ~3 km, poi ~12 km se non se ne trovano), raggruppate per nome.
     */
    fun nearby(lat: Double, lon: Double): List<Triple<Station, Double, Double>> {
        for (d in listOf(0.03, 0.12)) {
            val a = try {
                JSONArray(get(BASE + "map/stops?min=" + (lat - d) + "," + (lon - d * 1.5) + "&max=" + (lat + d) + "," + (lon + d * 1.5)))
            } catch (_: Exception) {
                return emptyList()
            }
            val list = (0 until a.length()).map { a.getJSONObject(it) }
                .filter { o -> o.str("stopId").startsWith("de-DELFI_") && isRail(o.optJSONArray("modes")) }
                .groupBy { it.str("name") }
                .map { (name, same) ->
                    val o = same.first()
                    remember(o)
                    Triple(Station(name + SUFFIX, PREFIX + o.str("stopId")), o.optDouble("lat"), o.optDouble("lon"))
                }
            if (list.size >= 3 || d > 0.1) return list
        }
        return emptyList()
    }

    // ---------------- Scioperi in Germania ----------------

    /** Notizia su uno sciopero ferroviario in Germania. */
    data class StrikeNews(val title: String, val source: String, val time: Long, val url: String) {
        val key: String get() = "de-strike:" + title.lowercase().hashCode()
    }

    /** Scioperi di altri paesi da scartare ("Bahnstreik in Italien", "in den Niederlanden"…). */
    private val OTHER = Regex("italien|niederland|frankreich|belgien|südtirol|suedtirol|schweiz|österreich|oesterreich|spanien|großbritannien|england|polen|tschech", RegexOption.IGNORE_CASE)
    private val STRIKE = Regex("streik|warnstreik|ausstand|arbeitskampf", RegexOption.IGNORE_CASE)
    private val RAILWORDS = Regex("bahn|gdl|evg|zug|züge|lokführer|s-bahn|fernverkehr|regionalverkehr|db ", RegexOption.IGNORE_CASE)

    /**
     * Notizie degli ultimi 14 giorni sugli scioperi dei treni in Germania (GDL, EVG, DB e aziende regionali).
     * In Germania non esiste un calendario ufficiale degli scioperi come quello del Ministero in Italia:
     * gli scioperi vengono annunciati dai sindacati pochi giorni prima, quindi si usano le notizie (Google News, in tedesco).
     */
    fun strikeNews(): List<StrikeNews> {
        val q = "(Bahnstreik OR \"GDL Streik\" OR \"EVG Streik\" OR \"Warnstreik Bahn\" OR \"S-Bahn Streik\") when:14d"
        val xml = get("https://news.google.com/rss/search?q=" + enc(q) + "&hl=de&gl=DE&ceid=DE:de")
        val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
        fun field(s: String, n: String): String = Regex("<$n[^>]*>(.*?)</$n>", RegexOption.DOT_MATCHES_ALL).find(s)?.groupValues?.get(1)
            ?.replace("<![CDATA[", "")?.replace("]]>", "")?.replace("&amp;", "&")?.replace("&quot;", "\"")?.replace("&#39;", "'")?.trim().orEmpty()
        val now = System.currentTimeMillis()
        return Regex("<item>(.*?)</item>", RegexOption.DOT_MATCHES_ALL).findAll(xml).mapNotNull { m ->
            val s = m.groupValues[1]
            val raw = field(s, "title")
            val src = field(s, "source")
            // Google News aggiunge " - Testata" in fondo al titolo
            val title = if (src.isNotBlank()) raw.removeSuffix(" - $src").trim() else raw
            val t = try { fmt.parse(field(s, "pubDate"))?.time ?: 0L } catch (_: Exception) { 0L }
            if (t < now - 14 * 86_400_000L || !STRIKE.containsMatchIn(title) || !RAILWORDS.containsMatchIn(title) || OTHER.containsMatchIn(title)) null
            else StrikeNews(title, src, t, field(s, "link"))
        }.distinctBy { it.title.lowercase() }.sortedByDescending { it.time }.take(10).toList()
    }

    /** DB Verkehrslage: guasti, cantieri e informazioni di viaggio ufficiali (anche durante gli scioperi), verificata il 30/10/2026. */
    const val DB_TRAFFIC = "https://verkehrslage.bahnhof.de"

    /**
     * L'utente viaggia in Germania: solo scelte volontarie (preferiti o treno seguito in Germania). Le ricerche recenti non
     * contano: basta cercare una volta una stazione tedesca per provarla e arriverebbero avvisi non voluti.
     */
    fun usesGermany(store: Store): Boolean =
        store.favRoutes().any { isGerman(it.from.id) || isGerman(it.to.id) } ||
            store.favStations().any { isGerman(it.id) } ||
            (store.tracked()?.originCode?.startsWith("$PREFIX|") == true)
}
