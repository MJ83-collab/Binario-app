package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.tx

/** «Treni in Austria» e «Treni in Francia»: come cercarli, fonte dei dati e siti ufficiali (stesso motore della Germania: Transitous). */
@Composable
fun AbroadScreen(country: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val at = country == "AT"
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { GreenTopBar(if (at) tx("Treni in Austria") else tx("Treni in Francia"), onBack) }
        item {
            WhiteCard {
                Column(Modifier.padding(16.dp)) {
                    Text((if (at) "🇦🇹 " else "🇫🇷 ") + (if (at) tx("Orari, ritardi e binari dei treni austriaci (ÖBB, Westbahn e aziende regionali), quando i dati in tempo reale sono pubblicati.")
                    else tx("Orari, ritardi e binari dei treni francesi (TGV, TER, Intercités, RER), quando i dati in tempo reale sono pubblicati.")),
                        fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tx("Cerca la stazione anche con il nome italiano: «Vienna», «Salisburgo», «Parigi», «Lione», «Marsiglia». Funzionano ricerca viaggi (anche con l'Italia), tabellone, scheda del treno e «Segui»."), fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tx("Dati: orari ufficiali tramite Transitous; il tempo reale dipende da quanto pubblicano le aziende e può mancare per alcune corse. I prezzi non sono pubblici: biglietti sui siti ufficiali. Fanno sempre fede tabelloni e annunci."),
                        color = Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            WhiteCard {
                if (at) MenuRow(Icons.Filled.ShoppingCart, "ÖBB", tx("Biglietti e informazioni ufficiali") + " · oebb.at") { openUrl(ctx, "https://www.oebb.at/") }
                else MenuRow(Icons.Filled.ShoppingCart, "SNCF Connect", tx("Biglietti e informazioni ufficiali") + " · sncf-connect.com") { openUrl(ctx, "https://www.sncf-connect.com/") }
            }
        }
    }
}
