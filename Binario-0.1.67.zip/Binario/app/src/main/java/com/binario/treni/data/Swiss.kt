package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Tratta di un itinerario dell'orario svizzero (include TILO e treni lombardi). */
data class CSection(
    val train: String,
    val operator: String,
    val from: String,
    val to: String,
    val dep: Long,
    val arr: Long,
    val depPlatform: String,
    val arrPlatform: String,
    val delay: Int,
    val walk: Boolean,
    /** Occupazione prevista (SBB): 1 bassa, 2 media, 3 alta; null se non disponibile. */
    val capacity2nd: Int? = null,
    val capacity1st: Int? = null,
) {
    val crowd: Crowd? get() = Crowd.fromSbb(capacity2nd, capacity1st)
}

data class Connection(
    val dep: Long,
    val arr: Long,
    val transfers: Int,
    val sections: List<CSection>,
    val products: List<String>,
) {
    val minutes: Int get() = ((arr - dep) / 60000).toInt()
    val rides: List<CSection> get() = sections.filter { !it.walk }

    /** Minuti di coincidenza a ogni cambio. */
    val transferSlack: List<Pair<String, Int>> get() {
        val r = rides
        return (0 until r.size - 1).map { i -> r[i].to to ((r[i + 1].dep - r[i].arr) / 60000).toInt() }
    }

    val passesSwitzerland: Boolean get() = sections.any { s ->
        listOf("mendrisio", "chiasso", "stabio", "lugano", "bellinzona", "balerna", "gaggiolo").any { s.from.lowercase().contains(it) || s.to.lowercase().contains(it) }
    }
}

/**
 * Orario ufficiale svizzero tramite transport.opendata.ch (servizio pubblico e gratuito).
 * Contiene i treni TILO e la gran parte dei treni regionali lombardi, quindi permette di confrontare
 * percorsi transfrontalieri (es. Varese → Mendrisio → Como) con quelli interni (Varese → Milano → Como).
 */
object Swiss {
    private const val BASE = "https://transport.opendata.ch/v1/"

    private fun get(url: String): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 25000
            setRequestProperty("User-Agent", "Binario/2.2 (Android)")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun parse(s: String): Long {
        if (s.isBlank() || s == "null") return 0L
        for (p in listOf("yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mm:ssXXX")) {
            try {
                return SimpleDateFormat(p, Locale.US).parse(s)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    private fun JSONObject.str(k: String): String = if (!has(k) || isNull(k)) "" else optString(k)

    private fun nm(x: String) = x.lowercase().replace('ü', 'u').replace('ä', 'a').replace('ö', 'o').replace('é', 'e').replace('è', 'e')
        .replace(Regex("[^a-z0-9]"), "")

    /**
     * Id della stazione italiana nell'orario svizzero. Il nome da solo è ambiguo ("MALPENSA AEROPORTO" veniva scambiato
     * con una fermata di Lugano-Agno) e il codice "83"+RFI vale solo per le stazioni RFI (non per Malpensa T1 8325635 / T2 8320005
     * né per le stazioni FerrovieNord): si cerca per nome tra le sole stazioni ferroviarie italiane (id 83…) e si preferisce
     * il nome identico, poi il codice previsto, poi la prima che contiene il nome.
     */
    fun resolveItalianId(s: Station): String {
        val code = uicOfItalian(s)
        return try {
            val a = get(BASE + "locations?type=station&query=" + enc(s.name)).optJSONArray("stations") ?: JSONArray()
            val trains = (0 until a.length()).map { a.getJSONObject(it) }
                .filter { it.str("icon") == "train" && it.str("id").startsWith("83") }
            val t = nm(s.name)
            trains.firstOrNull { nm(it.str("name")) == t }?.str("id")
                ?: trains.firstOrNull { it.str("id") == code }?.str("id")
                ?: trains.firstOrNull { nm(it.str("name")).startsWith(t) || t.startsWith(nm(it.str("name"))) }?.str("id")
                ?: trains.firstOrNull()?.str("id")
                ?: code ?: s.name
        } catch (e: Exception) {
            code ?: s.name
        }
    }

    /** Posto da passare all'orario svizzero: id UIC per stazioni svizzere (CH…) o italiane risolte. */
    fun placeOf(s: Station): String = if (SwissLive.isSwiss(s.id)) s.id.removePrefix(SwissLive.PREFIX) else resolveItalianId(s)

    /** Codice UIC della stazione italiana: "83" + codice RFI a 5 cifre (S01700 → 8301700); null per altri id. */
    fun uicOfItalian(s: Station): String? =
        if (s.id.startsWith("S") && s.id.drop(1).isNotEmpty() && s.id.drop(1).all { it.isDigit() } && s.num > 0)
            "83" + s.num.toString().padStart(5, '0') else null

    /** Nome stazione come lo conosce l'orario svizzero (es. "COMO S.GIOVANNI" → "Como S. Giovanni"). */
    fun resolveName(name: String): String = try {
        val a = get(BASE + "locations?type=station&query=" + enc(name)).optJSONArray("stations") ?: JSONArray()
        (0 until a.length()).map { a.getJSONObject(it) }
            .firstOrNull { it.str("id").isNotBlank() }?.str("name")?.ifBlank { null } ?: name
    } catch (e: Exception) {
        name
    }

    fun connections(from: String, to: String, time: Long, via: String? = null, limit: Int = 4): List<Connection> {
        val rome = TimeZone.getTimeZone("Europe/Rome")
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date(time))
        val t = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = rome }.format(Date(time))
        var url = BASE + "connections?from=" + enc(from) + "&to=" + enc(to) + "&date=$d&time=$t&limit=$limit"
        if (!via.isNullOrBlank()) url += "&via[]=" + enc(via)
        val arr = get(url).optJSONArray("connections") ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val c = arr.getJSONObject(i)
            val secs = c.optJSONArray("sections") ?: JSONArray()
            val sections = (0 until secs.length()).map { k ->
                val s = secs.getJSONObject(k)
                val dep = s.optJSONObject("departure") ?: JSONObject()
                val arrv = s.optJSONObject("arrival") ?: JSONObject()
                val j = s.optJSONObject("journey")
                val name = j?.let {
                    val cat = it.str("category"); val num = it.str("number")
                    (if (cat.isNotBlank() && num.isNotBlank() && !num.startsWith(cat)) "$cat$num" else num.ifBlank { it.str("name") }).trim()
                } ?: "A piedi"
                CSection(
                    train = name,
                    operator = j?.str("operator") ?: "",
                    from = dep.optJSONObject("station")?.str("name") ?: "",
                    to = arrv.optJSONObject("station")?.str("name") ?: "",
                    dep = parse(dep.str("departure")),
                    arr = parse(arrv.str("arrival")),
                    depPlatform = dep.str("platform"),
                    arrPlatform = arrv.str("platform"),
                    delay = dep.optInt("delay", 0),
                    walk = j == null,
                    capacity2nd = j?.let { if (it.isNull("capacity2nd")) null else it.optInt("capacity2nd") }?.takeIf { it in 1..3 },
                    capacity1st = j?.let { if (it.isNull("capacity1st")) null else it.optInt("capacity1st") }?.takeIf { it in 1..3 },
                )
            }
            val products = c.optJSONArray("products")?.let { p -> (0 until p.length()).map { p.optString(it) } } ?: emptyList()
            Connection(
                dep = parse(c.optJSONObject("from")?.str("departure") ?: ""),
                arr = parse(c.optJSONObject("to")?.str("arrival") ?: ""),
                transfers = c.optInt("transfers", (sections.count { !it.walk } - 1).coerceAtLeast(0)),
                sections = sections,
                products = products,
            )
        }.filter { it.dep > 0 && it.arr > 0 }
    }
}

/**
 * Stazioni, tabellone e treni svizzeri in tempo reale (tutte le imprese: FFS, BLS, SOB, RhB, TILO, Thurbo…)
 * dall'orario ufficiale svizzero. Le stazioni svizzere hanno id "CH" + codice UIC (es. "CH8505300" = Lugano).
 */
object SwissLive {
    private const val BASE = "https://transport.opendata.ch/v1/"
    const val PREFIX = "CH"
    const val SUFFIX = " (CH)"

    /** Coordinate delle stazioni svizzere viste (per mappa e servizi in stazione). */
    val coords = java.util.concurrent.ConcurrentHashMap<String, Pair<Double, Double>>()
    private val names = java.util.concurrent.ConcurrentHashMap<String, String>()

    /** Fermate successive di ogni treno visto sul tabellone, per aprirne la scheda. */
    private val journeys = java.util.concurrent.ConcurrentHashMap<String, Pair<JSONObject, String>>()

    fun isSwiss(id: String) = id.startsWith(PREFIX)
    private fun uic(id: String) = id.removePrefix(PREFIX)

    private fun get(url: String): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("User-Agent", "Binario/2.3 (Android; com.binario.treni)")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    private fun JSONObject.str(k: String): String = if (!has(k) || isNull(k)) "" else optString(k)
    private fun JSONObject.ts(k: String): Long = if (!has(k) || isNull(k)) 0L else optLong(k) * 1000L

    private fun remember(st: JSONObject?) {
        if (st == null) return
        val id = st.str("id").ifBlank { return }
        st.str("name").takeIf { it.isNotBlank() }?.let { names[id] = it }
        val c = st.optJSONObject("coordinate") ?: return
        if (c.isNull("x") || c.isNull("y")) return
        coords[PREFIX + id] = c.optDouble("x") to c.optDouble("y")
    }

    /** Stazioni ferroviarie svizzere (solo treni, niente fermate bus). */
    fun searchStations(q: String): List<Station> = try {
        val a = get(BASE + "locations?type=station&query=" + URLEncoder.encode(q.trim(), "UTF-8")).optJSONArray("stations") ?: JSONArray()
        (0 until a.length()).map { a.getJSONObject(it) }
            .filter { it.str("icon") == "train" && it.str("id").startsWith("85") }
            .map { o -> remember(o); Station(o.str("name") + SUFFIX, PREFIX + o.str("id")) }
            .take(5)
    } catch (e: Exception) {
        emptyList()
    }

    fun coord(id: String): Pair<Double, Double>? = coords[id] ?: try {
        val a = get(BASE + "locations?type=station&query=" + uic(id)).optJSONArray("stations")
        a?.optJSONObject(0)?.let { remember(it) }
        coords[id]
    } catch (e: Exception) {
        null
    }

    private fun opName(raw: String): String = Railways.match(raw.substringBefore('-'))?.short ?: raw.substringBefore('-')

    /** Partenze dalla stazione svizzera [st] a partire da [time]. */
    fun departures(st: Station, time: Long): List<BoardItem> {
        val rome = TimeZone.getTimeZone("Europe/Rome")
        val dt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = rome }.format(Date(time))
        val o = get(BASE + "stationboard?id=" + uic(st.id) + "&limit=40&type=departure&datetime=" + URLEncoder.encode(dt, "UTF-8"))
        remember(o.optJSONObject("station"))
        val a = o.optJSONArray("stationboard") ?: return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val j = a.getJSONObject(i)
            val stop = j.optJSONObject("stop") ?: return@mapNotNull null
            val dep = stop.ts("departureTimestamp").takeIf { it > 0 } ?: return@mapNotNull null
            val num = j.str("name").trimStart('0').ifBlank { j.str("number") }
            val cat = j.str("category")
            val line = j.str("number")
            val label = if (line.isNotBlank() && line != num && cat in setOf("S", "RE", "IR", "IC", "R", "SN", "PE")) "$cat$line" else cat
            val schedPl = stop.str("platform")
            val realPl = stop.optJSONObject("prognosis")?.str("platform").orEmpty()
            val key = "$PREFIX|${uic(st.id)}|$dep|$num"
            journeys[key] = j to st.name
            (j.optJSONArray("passList") ?: JSONArray()).let { pl -> (0 until pl.length()).forEach { k -> remember(pl.getJSONObject(k).optJSONObject("station")) } }
            BoardItem(
                number = num, category = label, otherEnd = j.str("to"), time = dep, delay = stop.optInt("delay", 0),
                platform = realPl.ifBlank { schedPl }, platformConfirmed = realPl.isNotBlank(),
                originCode = "$PREFIX|${uic(st.id)}|$dep", departureDate = dep, inStation = false,
                schedPlatform = schedPl, realPlatform = realPl, operator = opName(j.str("operator")),
            )
        }
    }

    /** Scheda di un treno svizzero: fermate dalla stazione in cui è stato visto fino al capolinea, in tempo reale. */
    fun status(ref: TrainRef): TrainStatus {
        val parts = ref.originCode.split("|")
        val stationUic = parts.getOrNull(1).orEmpty()
        val dep = parts.getOrNull(2)?.toLongOrNull() ?: 0L
        val key = "$PREFIX|$stationUic|$dep|${ref.number}"
        var hit = journeys[key]
        if (hit == null || System.currentTimeMillis() - (hit.first.optLong("_at", 0L)) > 60_000L) {
            // Rilegge il tabellone della stazione per avere ritardi aggiornati
            departures(Station(coordsName(stationUic), PREFIX + stationUic), dep - 60_000L)
            hit = journeys[key] ?: hit
        }
        val (j, stName) = hit ?: throw IOException("Treno ${ref.number} non trovato nell'orario svizzero")
        j.put("_at", System.currentTimeMillis())
        val pl = j.optJSONArray("passList") ?: JSONArray()
        val now = System.currentTimeMillis()
        val stops = (0 until pl.length()).map { k ->
            val p = pl.getJSONObject(k)
            val s = p.optJSONObject("station")
            val name = s?.str("name")?.ifBlank { null } ?: stName.removeSuffix(SUFFIX)
            val sa = p.ts("arrivalTimestamp"); val sd = p.ts("departureTimestamp")
            val delay = p.optInt("delay", 0)
            val ra = if (sa > 0 && sa + delay * 60_000L < now) sa + delay * 60_000L else 0L
            val rd = if (sd > 0 && sd + delay * 60_000L < now) sd + delay * 60_000L else 0L
            val schedPl = p.str("platform"); val realPl = p.optJSONObject("prognosis")?.str("platform").orEmpty()
            TrainStop(name, PREFIX + (s?.str("id") ?: stationUic), sa, sd, ra, rd, delay, realPl.ifBlank { schedPl },
                realPl.isNotBlank() && realPl != schedPl, realPl.isNotBlank(), schedPl, realPl)
        }
        val cat = j.str("category")
        return TrainStatus(
            number = ref.number, category = cat, origin = stops.firstOrNull()?.name ?: stName, destination = j.str("to"),
            originCode = ref.originCode, date = dep, delay = stops.firstOrNull()?.delay ?: 0,
            lastStation = "", lastTime = 0L, cancelled = false, stops = stops,
            info = I18n.tr("Fermate da ${stops.firstOrNull()?.name ?: stName} al capolinea · orario ufficiale svizzero (transport.opendata.ch)",
                "Stops from ${stops.firstOrNull()?.name ?: stName} to the terminus · official Swiss timetable (transport.opendata.ch)"),
            operator = opName(j.str("operator")),
        )
    }

    private fun simple(s: String) = java.text.Normalizer.normalize(s.lowercase(Locale.ITALY), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9]+"), "")

    /**
     * Cerca nell'orario svizzero (transport.opendata.ch) un treno italiano che entra in Svizzera (es. TILO/Trenord Malpensa–Stabio–Lugano):
     * si guarda il tabellone della prima fermata svizzera [stopName] all'ora [sched] e si cerca lo stesso numero (o la stessa ora e destinazione).
     * Restituisce il riferimento da passare a [status], oppure null.
     */
    fun findRef(number: String, stopName: String, sched: Long, destination: String): TrainRef? = try {
        val st = searchStations(stopName).firstOrNull { simple(it.name.removeSuffix(SUFFIX)) == simple(stopName) }
            ?: searchStations(stopName).firstOrNull { simple(it.name).contains(simple(stopName)) } ?: throw IOException("fermata non svizzera")
        val dest = simple(destination)
        val items = departures(st, sched - 120_000L)
        val digits = number.trimStart('0')
        val hit = items.firstOrNull { it.number.filter(Char::isDigit).trimStart('0') == digits && Math.abs(it.time - sched) <= 30 * 60_000L }
            ?: items.firstOrNull { b ->
                val h = simple(b.otherEnd)
                Math.abs(b.time - sched) <= 60_000L && dest.isNotBlank() && h.isNotBlank() && (h.contains(dest) || dest.contains(h))
            }
        hit?.let { TrainRef(it.number, it.originCode, it.departureDate, it.title) }
    } catch (_: Exception) {
        null
    }

    private fun coordsName(uicCode: String): String = (names[uicCode] ?: uicCode) + SUFFIX

    /**
     * Affollamento previsto dalle FFS per il treno visto sul tabellone (prognosis.capacity1st/2nd: 1 basso, 2 medio, 3 alto).
     * Null se il dato non c'è.
     */
    fun crowd(ref: TrainRef): Crowd? {
        val parts = ref.originCode.split("|")
        val key = "$PREFIX|${parts.getOrNull(1).orEmpty()}|${parts.getOrNull(2)?.toLongOrNull() ?: 0L}|${ref.number}"
        val j = journeys[key]?.first ?: return null
        val prog = j.optJSONObject("stop")?.optJSONObject("prognosis") ?: return null
        fun cap(k: String) = if (prog.isNull(k)) null else prog.optInt(k).takeIf { it in 1..3 }
        return Crowd.fromSbb(cap("capacity2nd"), cap("capacity1st"))
    }

    /** Soluzioni di viaggio quando partenza o arrivo sono in Svizzera. */
    fun solutions(from: Station, to: Station, time: Long): List<Solution> {
        fun isMalpensa(x: Station) = !isSwiss(x.id) && x.name.uppercase().contains("MALPENSA")
        // Malpensa: due stazioni distinte (T1 8325635, T2 8320005). Si cercano entrambe, e oltre al percorso più rapido anche
        // quelli con cambio a Gallarate (TILO + nuovo collegamento Gallarate–T2 dal 23/01/2026) o via Busto Arsizio (Malpensa Express).
        val fromList = if (isMalpensa(from)) listOf("8325635", "8320005") else listOf(Swiss.placeOf(from))
        val toList = if (isMalpensa(to)) listOf("8325635", "8320005") else listOf(Swiss.placeOf(to))
        val vias: List<String?> = if (isMalpensa(from) || isMalpensa(to)) listOf(null, "8301030", "8301031", "8325631") else listOf(null)
        val jobs = fromList.flatMap { f -> toList.flatMap { t -> vias.map { v -> Triple(f, t, v) } } }
        val pool = java.util.concurrent.Executors.newFixedThreadPool(minOf(jobs.size, 6).coerceAtLeast(1))
        val results = try {
            jobs.map { (f, t, v) ->
                pool.submit(java.util.concurrent.Callable<List<Connection>> {
                    try { Swiss.connections(f, t, time, via = v, limit = 6) } catch (e: Exception) { emptyList() }
                })
            }.flatMap { fut -> try { fut.get(40, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) { emptyList() } }
        } finally {
            pool.shutdown()
        }
        val list = results
            .distinctBy { c -> c.dep.toString() + "|" + c.arr + "|" + c.rides.joinToString(">") { it.train + it.from + it.to } }
            .sortedBy { it.dep }
            .let { if (it.size > 12) it.take(12) else it }
        // Prezzo ufficiale Arcobaleno (CHF) convertito in euro come lo vende Trainline, quando la tratta è nella tabella
        val fare = CrossBorderFares.find(from.name, to.name)
        return list.map { c ->
            val rides = c.rides
            val eur = if (rides.size <= 1) fare?.let { Math.round(it.chf * CrossBorderFares.EUR_PER_CHF * 100) / 100.0 } else null
            Solution(
                from = from.name, to = to.name, dep = c.dep, arr = c.arr,
                duration = "${c.minutes / 60}h${(c.minutes % 60).toString().padStart(2, '0')}",
                // La tariffa Arcobaleno vale solo per il treno diretto: con un cambio (Gallarate, Busto Arsizio...) le tariffe cambiano
                price = eur,
                // 1ª classe: stima (2ª classe + supplemento medio), non esiste una tabella ufficiale
                priceFirst = eur?.let { Math.round((it + CrossBorderFares.FIRST_SURCHARGE_EUR) * 100) / 100.0 },
                legs = rides.map { r -> Leg(number = r.train, category = "", from = r.from, to = r.to, dep = r.dep, arr = r.arr, operator = opName(r.operator)) },
                source = "sbb.ch",
            )
        }
    }
}

/** Tariffe ufficiali transfrontaliere pubblicate da Arcobaleno (2ª classe, corsa semplice, valide dal 14.12.2025). */
object CrossBorderFares {
    /** Cambio indicativo EUR per 1 CHF (ricavato dai prezzi Trainline del 25/10/2026: 18,16 € = CHF 16,00). */
    const val EUR_PER_CHF = 1.135
    /** Supplemento indicativo della 1ª classe in euro (osservato su Trainline): il prezzo in 1ª è una stima. */
    const val FIRST_SURCHARGE_EUR = 8.40
    fun eur(chf: Double): String = "≈ %.2f €".format(java.util.Locale.ITALY, chf * EUR_PER_CHF)

    data class Fare(val from: String, val to: String, val chf: Double, val halfChf: Double, val via: String)

    val list = listOf(
        Fare("Mendrisio", "Como", 4.00, 3.40, "Chiasso"),
        Fare("Chiasso", "Como", 4.00, 3.40, "Chiasso"),
        Fare("Lugano", "Como", 11.80, 6.60, "Chiasso"),
        Fare("Mendrisio", "Milano", 8.20, 7.60, "Chiasso"),
        Fare("Lugano", "Malpensa", 25.00, 19.80, "Gaggiolo"),
        // Calcolatore Arcobaleno, 25/10/2026: Lugano – Cantello-Gaggiolo = biglietto singolo «transfrontaliero» (metà = 2 zone ridotto)
        Fare("Lugano", "Gaggiolo", 10.40, 5.20, "Stabio"),
    )

    const val VALIDITY = "Corsa semplice valida 4 ore per l'intero percorso (in Italia dalla convalida, in Svizzera dall'ora stampata)."
    const val RULE = "Il prezzo somma la tariffa a zone Arcobaleno (tratta svizzera) e la tariffa chilometrica Trenord (tratta lombarda)."

    fun find(from: String, to: String): Fare? = list.firstOrNull { f ->
        (from.contains(f.from, true) && to.contains(f.to, true)) || (from.contains(f.to, true) && to.contains(f.from, true))
    }

    /** Località svizzere servite dai treni lombardi e TILO (per riconoscerle anche nei nomi di ViaggiaTreno). */
    private val SWISS_PLACES = listOf(
        "LUGANO", "CHIASSO", "MENDRISIO", "BALERNA", "STABIO", "BELLINZONA", "LOCARNO", "BIASCA", "GIUBIASCO", "MELIDE",
        "MAROGGIA", "CAPOLAGO", "RANZO", "TENERO", "CADENAZZO", "RIVERA", "TAVERNE", "LAMONE", "COLDRERIO", "LIGORNETTO",
        "AIROLO", "FAIDO", "GORDOLA", "MINUSIO", "MURALTO", "MAGADINO", "ARBEDO", "OSOGNA", "LAVORGO",
        "ZURIGO", "ZÜRICH", "ZURICH", "BASILEA", "BASEL", "BERNA", "BERN", "LUCERNA", "LUZERN", "GINEVRA", "GENÈVE", "GENEVE",
        "LOSANNA", "LAUSANNE", "BRIGA", "BRIG", "ARTH", "ZUGO", "ZUG", "SAN GALLO", "ST. GALLEN",
    )

    /** La stazione è in Svizzera (orario svizzero oppure nome di una località svizzera). */
    fun isSwissStation(s: Station): Boolean {
        if (SwissLive.isSwiss(s.id) || s.name.endsWith(SwissLive.SUFFIX)) return true
        val n = s.name.uppercase().replace('-', ' ').trim()
        return SWISS_PLACES.any { p -> n == p || n.startsWith("$p ") }
    }

    /**
     * Prezzi in euro verificati sul negozio online Trenord (biglietto transfrontaliero integrato, corsa semplice adulti).
     * Il tariffario Trenord non pubblica tabelle per la Svizzera: si aggiungono solo prezzi controllati sul sito.
     */
    data class EurFare(val a: String, val b: String, val second: Double, val first: Double, val checked: String)

    val VERIFIED_EUR = listOf(
        EurFare("Varese", "Lugano", 12.50, 21.00, "19/10/2026"),
    )

    fun findEur(from: String, to: String): EurFare? {
        fun m(n: String, k: String) = n.uppercase().let { u -> u == k.uppercase() || u.startsWith(k.uppercase() + " ") } && !n.uppercase().contains("NORD")
        return VERIFIED_EUR.firstOrNull { f -> (m(from, f.a) && m(to, f.b)) || (m(from, f.b) && m(to, f.a)) }
    }

    /** Prezzi letti su sbb.ch (corsa semplice adulti, senza riduzioni). */
    data class SbbFare(val a: String, val b: String, val second: Double, val first: Double, val checked: String)

    val VERIFIED_SBB = listOf(
        SbbFare("Induno Olona", "Lugano", 12.30, 20.50, "25/10/2026"),
    )

    fun findSbb(from: String, to: String): SbbFare? {
        fun m(n: String, k: String) = n.uppercase().let { u -> u == k.uppercase() || u.startsWith(k.uppercase() + " ") } && !n.uppercase().contains("NORD")
        return VERIFIED_SBB.firstOrNull { f -> (m(from, f.a) && m(to, f.b)) || (m(from, f.b) && m(to, f.a)) }
    }

    /** Ricerca già compilata su sbb.ch (partenza, arrivo, giorno e ora). */
    fun sbbUrl(from: String, to: String, time: Long): String {
        val rome = TimeZone.getTimeZone("Europe/Rome")
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date(time))
        val t = SimpleDateFormat("HH_mm", Locale.US).apply { timeZone = rome }.format(Date(time))
        fun e(s: String) = URLEncoder.encode(s, "UTF-8")
        return "https://www.sbb.ch/it?stops=" + e(from) + "~" + e(to) + "&day=$d&time=$t&moment=dep&reduction=none"
    }

    const val TRENORD_STORE = "https://www.trenord.it/store/"
    const val ARCOBALENO_PAGE = "https://arcobaleno.ch/it/home/biglietti/biglietto-transfrontaliero"
    const val ARCOBALENO_CALC = "https://arcobaleno.ch/it/home/Calcolatore"
    const val ARCOBALENO_PASSES = "https://arcobaleno.ch/it/home/abbonamenti/abbonamento-mensile-transfrontaliero"
}
