package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Modalità sviluppatore: ordine e visibilità delle sezioni della Home, delle azioni rapide e delle schede di "Altro",
 * scelti trascinandoli nello strumento "Disposizione dell'app". Si sblocca toccando 7 volte "Versione App" nelle
 * Impostazioni e inserendo la password dello sviluppatore. La password non è scritta nell'app: c'è solo la sua impronta
 * SHA-256 (chi smonta l'app non la legge in chiaro; non è comunque una protezione bancaria).
 */
object DevLayout {
    private const val PREFS = "dev_layout"
    private const val PASSWORD_SHA256 = "937d0982913f2f4a7a5695aebcccc060b1b3caa9c044b85135e3ee7dd6896d6f"

    const val HOME = "home"
    const val QUICK = "quick"
    const val MORE = "more"

    /** Elementi di ogni elenco: chiave → nome da mostrare nello strumento. */
    val ITEMS: Map<String, List<Pair<String, String>>> = linkedMapOf(
        HOME to listOf(
            "trip" to "Viaggio in corso", "next" to "Prossimo treno", "a11y" to "Accessibilità rapida",
            "quick" to "Azioni rapide", "recent" to "Recenti e preferite", "dae" to "Defibrillatore più vicino",
        ),
        QUICK to listOf(
            "explore" to "Esplora a voce", "nearby" to "Stazioni vicine",
            "news" to "Scioperi e notizie", "offline" to "Orari offline", "alarms" to "Allarmi",
        ),
        MORE to listOf(
            "alpha" to "Avviso versione alpha", "companies" to "Per azienda", "station" to "In stazione e strumenti",
            "a11y" to "Accessibilità", "app" to "App",
        ),
    )

    val TITLES = mapOf(HOME to "Rapido", QUICK to "Azioni rapide della Home", MORE to "Altro")

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------------- Accesso ----------------

    fun unlocked(ctx: Context) = prefs(ctx).getBoolean("unlocked", false)

    fun lock(ctx: Context) = prefs(ctx).edit().putBoolean("unlocked", false).apply()

    /** Controlla la password (confrontando l'impronta) e, se giusta, sblocca la modalità sviluppatore. */
    fun unlock(ctx: Context, password: String): Boolean {
        val h = java.security.MessageDigest.getInstance("SHA-256").digest(password.toByteArray()).joinToString("") { "%02x".format(it) }
        val ok = h == PASSWORD_SHA256
        if (ok) prefs(ctx).edit().putBoolean("unlocked", true).apply()
        return ok
    }

    // ---------------- Disposizione ----------------

    private fun keys(list: String) = ITEMS[list].orEmpty().map { it.first }

    /** Ordine attuale: quello salvato, con eventuali elementi nuovi aggiunti in fondo. */
    fun order(ctx: Context, list: String): List<String> {
        if (list == HOME) moveDaeLast(ctx)
        val known = keys(list)
        val saved = prefs(ctx).getString("order_$list", null)?.split(",")?.filter { it in known }.orEmpty()
        return (saved + known.filter { it !in saved }).distinct()
    }

    /** Dalla 0.1.2 il defibrillatore sta in fondo alla Home: sposta anche le disposizioni già salvate (una volta sola). */
    private fun moveDaeLast(ctx: Context) {
        val p = prefs(ctx)
        if (p.getBoolean("m_dae_last", false)) return
        val saved = p.getString("order_$HOME", null)
        val e = p.edit().putBoolean("m_dae_last", true)
        if (saved != null) e.putString("order_$HOME", (saved.split(",").filter { it.isNotBlank() && it != "dae" } + "dae").joinToString(","))
        e.apply()
    }

    fun hidden(ctx: Context, list: String): Set<String> =
        prefs(ctx).getString("hidden_$list", null)?.split(",")?.filter { it.isNotBlank() }?.toSet().orEmpty()

    /** Elementi da mostrare, nell'ordine scelto. */
    fun visible(ctx: Context, list: String): List<String> { val h = hidden(ctx, list); return order(ctx, list).filter { it !in h } }

    fun save(ctx: Context, list: String, order: List<String>, hidden: Set<String>) {
        prefs(ctx).edit().putString("order_$list", order.joinToString(",")).putString("hidden_$list", hidden.joinToString(","))
            .putLong("changed", System.currentTimeMillis()).apply()
    }

    fun reset(ctx: Context, list: String) {
        prefs(ctx).edit().remove("order_$list").remove("hidden_$list").putLong("changed", System.currentTimeMillis()).apply()
    }

    /** Disposizione in un breve testo JSON, da mandare allo sviluppatore per renderla quella di serie. */
    fun export(ctx: Context): String {
        val o = JSONObject().put("binarioLayout", 1).put("version", com.binario.treni.ui.APP_VERSION)
        ITEMS.keys.forEach { l ->
            o.put(l, JSONObject().put("order", JSONArray(order(ctx, l))).put("hidden", JSONArray(hidden(ctx, l).toList())))
        }
        return o.toString(2)
    }

    /** Applica una disposizione esportata; false se il testo non è valido. */
    fun importLayout(ctx: Context, text: String): Boolean = try {
        val o = JSONObject(text.trim())
        if (!o.has("binarioLayout")) throw IllegalArgumentException()
        ITEMS.keys.forEach { l ->
            o.optJSONObject(l)?.let { x ->
                val ord = x.optJSONArray("order")?.let { a -> (0 until a.length()).map { a.optString(it) } }.orEmpty()
                val hid = x.optJSONArray("hidden")?.let { a -> (0 until a.length()).map { a.optString(it) } }.orEmpty().toSet()
                save(ctx, l, ord, hid)
            }
        }
        true
    } catch (e: Exception) {
        false
    }

    /** Cambia ogni volta che si modifica la disposizione: le schermate la rileggono. */
    fun stamp(ctx: Context) = prefs(ctx).getLong("changed", 0L)
}
