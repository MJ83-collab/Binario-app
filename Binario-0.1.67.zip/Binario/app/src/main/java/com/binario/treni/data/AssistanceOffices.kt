package com.binario.treni.data

import android.content.Context

/**
 * Uffici di assistenza clienti delle varie aziende, ognuno con il nome che usa l'azienda e la sua fonte:
 * - Trenord: "My Link Point" (Milano Cadorna e Milano Porta Garibaldi) → letti dal sito biglietterie.trenord.it (TicketSellers).
 * - Trenitalia: "Ufficio Assistenza Clienti" e biglietterie nelle grandi stazioni → trenitalia.com, "Gli uffici Assistenza Clienti"
 *   (orari aggiornati da Trenitalia ad aprile 2025, letti il 19/10/2026).
 * - Italo: "Casa Italo" (biglietteria con personale) e punti con sole emettitrici Italo → italotreno.com, "Biglietterie in stazione"
 *   (letti il 19/10/2026).
 * - FFS / TILO: "Centro viaggiatori FFS" nelle stazioni ticinesi servite da TILO → sbb.ch e comunità tariffale Arcobaleno.
 */
object AssistanceOffices {
    const val TRENITALIA_URL = "https://www.trenitalia.com/it/informazioni/gli-uffici-assistenzaclienti.html"
    const val ITALO_URL = "https://www.italotreno.com/en/the-train/italo-ticket-office"
    const val SBB_URL = "https://www.sbb.ch/it/informazioni-viaggio/stazioni/trova-stazione.html"
    const val ARCOBALENO_URL = "https://arcobaleno.ch/it/contatti"

    /** Trenitalia: stazione, orario biglietteria, orario Ufficio Assistenza (trenitalia.com, aprile 2025). */
    private val TRENITALIA = listOf(
        Triple("Ancona", "06:00–20:30", "06:00–20:30"),
        Triple("Bari Centrale", "06:20–21:00", "06:15–21:10"),
        Triple("Bologna Centrale", "06:30–21:00", "06:00–23:00"),
        Triple("Bolzano", "06:30–20:00", "06:30–20:00"),
        Triple("Brescia", "06:00–20:40", "06:00–21:00"),
        Triple("Firenze Santa Maria Novella", "06:30–21:00", "06:30–22:30"),
        Triple("Milano Centrale", "06:15–21:30", "06:30–24:00"),
        Triple("Milano Porta Garibaldi", "07:00–20:30", "07:00–21:00"),
        Triple("Milano Rogoredo", "06:30–21:00", "06:30–21:00"),
        Triple("Napoli Afragola", "05:40–20:00", "05:40–20:00"),
        Triple("Napoli Centrale", "06:30–21:00", "06:30–21:00"),
        Triple("Padova", "06:00–21:00", "06:00–22:00"),
        Triple("Reggio Emilia AV", "07:00–21:00", "07:00–21:00"),
        Triple("Roma Termini", "06:30–21:40", "06:30–21:40"),
        Triple("Roma Tiburtina", "06:35–20:20", "06:35–20:20"),
        Triple("Salerno", "06:00–20:30", "06:00–20:30"),
        Triple("Torino Porta Nuova", "06:30–20:30", "06:30–20:30"),
        Triple("Torino Porta Susa", "06:30–20:30", "06:30–20:30"),
        Triple("Venezia Mestre", "06:00–21:00", "06:00–23:30"),
        Triple("Venezia Santa Lucia", "06:00–21:00", "06:00–21:00"),
        Triple("Verona Porta Nuova", "06:00–21:00", "06:00–23:00"),
        Triple("Vicenza", "06:00–20:30", "06:00–20:30"),
    )

    /** Italo: stazione, orario (vuoto = non indicato), con personale (true) o solo emettitrici (italotreno.com). */
    private val ITALO = listOf(
        Triple("Torino Porta Nuova", "06:00–20:00", true), Triple("Torino Porta Susa", "06:00–20:00", true),
        Triple("Milano Centrale", "06:15–20:45", true), Triple("Milano Rogoredo", "06:10–20:00", true),
        Triple("Bergamo", "", false), Triple("Brescia", "06:10–20:15", true), Triple("Desenzano del Garda", "", false),
        Triple("Peschiera del Garda", "", false), Triple("Verona Porta Nuova", "06:40–20:30", true), Triple("Rovereto", "", false),
        Triple("Trento", "", false), Triple("Vicenza", "", false), Triple("Venezia Mestre", "06:30–20:30", false),
        Triple("Venezia Santa Lucia", "06:30–20:30", true), Triple("Padova", "06:10–20:30", true), Triple("Rovigo", "", false),
        Triple("Ferrara", "", false), Triple("Reggio Emilia AV", "06:10–20:30", true), Triple("Bologna Centrale", "06:40–20:50", true),
        Triple("Firenze Santa Maria Novella", "07:00–21:10", true), Triple("Napoli Centrale", "05:45–20:00", true),
        Triple("Napoli Afragola", "06:35–19:30", false), Triple("Salerno", "06:00–20:15", true),
        Triple("Roma Termini", "06:15–21:00", true), Triple("Roma Tiburtina", "06:15–20:15", true),
    )

    /** FFS: Centri viaggiatori nelle stazioni TILO del Ticino (coordinate delle stazioni). */
    private val SBB = listOf(
        Triple("Lugano", 46.00546, 8.94690), Triple("Bellinzona", 46.19560, 9.02940), Triple("Locarno", 46.17240, 8.80110),
        Triple("Mendrisio", 45.87040, 8.98130), Triple("Chiasso", 45.83230, 9.03130),
    )

    @Volatile private var memo: List<TicketSellers.Seller>? = null

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        .replace("santa maria novella", "s m novella").replace("s maria novella", "s m novella")

    /** Coordinate di una stazione italiana dal nome (elenco stazioni ViaggiaTreno e FerrovieNord). */
    private fun coords(all: List<Api.GeoStation>, name: String): Pair<Double, Double>? {
        val n = norm(name)
        val hit = all.firstOrNull { norm(it.station.name) == n }
            ?: all.filter { norm(it.station.name).startsWith(n) }.minByOrNull { it.station.name.length }
            ?: all.firstOrNull { val w = n.split(" "); norm(it.station.name).split(" ").containsAll(w) }
        return hit?.let { it.lat to it.lon }
    }

    /** Tutti gli uffici (con coordinate quando la stazione è nota). */
    fun all(ctx: Context): List<TicketSellers.Seller> {
        memo?.let { return it }
        FnNetwork.ensure(ctx)
        val stations = FnNetwork.stations + try { Api.allStations(ctx) } catch (e: Exception) { emptyList() }
        val out = ArrayList<TicketSellers.Seller>()
        TRENITALIA.forEach { (st, ticket, assist) ->
            val c = coords(stations, st) ?: (0.0 to 0.0)
            out += TicketSellers.Seller("Trenitalia", OsmPlace.Kind.TICKET_OFFICE, "Trenitalia · $st", c.first, c.second, nearStation = st,
                hours = "Lun–Dom $assist", url = TRENITALIA_URL, brand = "Ufficio Assistenza Clienti", assist = true,
                services = I18n.tr("Informazioni, assistenza in caso di disagi, assistenza PRM, Carta Blu, reclami", "Information, help during disruption, reduced mobility, Carta Blu, complaints"))
            out += TicketSellers.Seller("Trenitalia", OsmPlace.Kind.TICKET_OFFICE, "Trenitalia · $st", c.first, c.second, nearStation = st,
                hours = "Lun–Dom $ticket", url = TRENITALIA_URL, brand = "Biglietteria Trenitalia")
        }
        ITALO.forEach { (st, h, staff) ->
            val c = coords(stations, st) ?: (0.0 to 0.0)
            out += if (staff) {
                TicketSellers.Seller("Italo", OsmPlace.Kind.TICKET_OFFICE, "Italo · $st", c.first, c.second, nearStation = st,
                    hours = if (h.isNotBlank()) "Lun–Dom $h" else "", url = ITALO_URL, brand = "Casa Italo", assist = true,
                    services = I18n.tr("Biglietti Italo, cambi, rimborsi e assistenza", "Italo tickets, changes, refunds and help"))
            } else {
                TicketSellers.Seller("Italo", OsmPlace.Kind.TICKET_MACHINE, "Italo · $st", c.first, c.second, nearStation = st,
                    url = ITALO_URL, brand = I18n.tr("Emettitrici Italo (senza personale)", "Italo ticket machines (unstaffed)"))
            }
        }
        SBB.forEach { (st, la, lo) ->
            out += TicketSellers.Seller("FFS", OsmPlace.Kind.TICKET_OFFICE, "FFS · $st", la, lo, nearStation = st, url = SBB_URL,
                brand = "Centro viaggiatori FFS", assist = true,
                services = I18n.tr("Biglietti TILO/FFS e Arcobaleno, abbonamenti, informazioni e assistenza", "TILO/SBB and Arcobaleno tickets, passes, information and help"))
        }
        return out.also { if (stations.size > 500) memo = it }
    }
}
