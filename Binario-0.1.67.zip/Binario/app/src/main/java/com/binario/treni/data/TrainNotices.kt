package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import java.util.Calendar
import java.util.TimeZone

/**
 * Avvisi sull'orario di singoli treni (es. Trenord 126.1: «allungamento a destino +3'» per i treni pari della S5 dal 9/11 al 12/12/2026).
 * Dati da asset (train_notices.json), validi solo nel periodo indicato e solo se la corsa ha la destinazione attesa:
 * il numero da solo non basta, perché lo stesso numero può essere un altro treno.
 */
object TrainNotices {
    data class Notice(
        val id: String, val operator: String, val minutes: Int, val reason: String, val note: String, val src: String,
        val from: String, val to: String,
    )

    private class Raw(val n: Notice, val numbers: Set<String>, val dest: String)

    @Volatile
    private var raws: List<Raw> = emptyList()

    fun ensure(ctx: Context) {
        if (raws.isNotEmpty()) return
        raws = try {
            val a = JSONArray(ctx.applicationContext.assets.open("train_notices.json").bufferedReader().use { it.readText() })
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val nums = o.getJSONArray("numbers").let { l -> (0 until l.length()).map { l.getString(it).trimStart('0') }.toSet() }
                Raw(Notice(o.getString("id"), o.optString("operator"), o.optInt("minutes"), o.optString("reason"), o.optString("note"),
                    o.optString("src"), o.getString("from"), o.getString("to")), nums, o.optString("dest").lowercase())
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun dayKey(t: Long): String {
        val c = Calendar.getInstance(TimeZone.getTimeZone("Europe/Rome")).apply { timeInMillis = t }
        return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** Avvisi che valgono per questa corsa (numero + giorno + destinazione). */
    fun forTrain(st: TrainStatus): List<Notice> {
        val num = Api.trainDigits(st.number).trimStart('0')
        val day = dayKey(if (st.depTime > 0) st.depTime else System.currentTimeMillis())
        val dest = (st.stops.lastOrNull()?.name ?: st.destination).lowercase()
        return raws.filter { r -> num in r.numbers && day >= r.n.from && day <= r.n.to && (r.dest.isBlank() || dest.contains(r.dest)) }.map { it.n }
    }
}
