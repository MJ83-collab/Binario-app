package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Bot
import com.binario.treni.data.Fmt
import com.binario.treni.data.GreenCalc
import com.binario.treni.data.GreenDay
import com.binario.treni.data.GreenProfile
import com.binario.treni.data.GreenResult
import com.binario.treni.data.I18n
import com.binario.treni.data.Station
import com.binario.treni.data.TrainRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

private fun tr(a: String, b: String) = I18n.tr(a, b)
private fun eur(v: Double) = String.format(Locale.ITALY, "%.2f €", v)
private fun kg(v: Double) = if (v >= 1000) String.format(Locale.ITALY, "%.2f t", v / 1000) else String.format(Locale.ITALY, "%.1f kg", v)

// ---------------------------------------------------------------------------
// Quanto sei green
// ---------------------------------------------------------------------------

@Composable
fun GreenScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var profile by remember { mutableStateOf(GreenCalc.profile(ctx)) }
    var editing by remember { mutableStateOf(profile == null) }
    var result by remember { mutableStateOf<GreenResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var log by remember { mutableStateOf(GreenCalc.log(ctx)) }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(profile, tick) {
        val p = profile ?: return@LaunchedEffect
        result = null; error = null
        try {
            result = withContext(Dispatchers.IO) { GreenCalc.compute(ctx, vm.store, p, log) }
        } catch (e: Exception) {
            error = e.message ?: tr("Calcolo non riuscito", "Calculation failed")
        }
    }

    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        item {
            GreenTopBar(tr("Quanto sei green", "How green are you"), onBack) {
                if (profile != null) IconButton({ editing = !editing }) { Icon(Icons.Filled.Edit, tr("Modifica", "Edit")) }
            }
        }
        if (editing || profile == null) item {
            GreenSetup(profile) { p0 ->
                // I valori personalizzati restano; distanza e pedaggi solo se la tratta è la stessa
                val old = profile
                val same = old != null && old.from.id == p0.from.id && old.to.id == p0.to.id
                val p = p0.copy(
                    carKm = if (same) old?.carKm else null, tollDay = if (same) old?.tollDay else null,
                    fuelPriceCustom = if (old?.fuel == p0.fuel) old?.fuelPriceCustom else null,
                )
                GreenCalc.saveProfile(ctx, p); profile = p; editing = false; tick++
            }
        }
        val p = profile
        val r = result
        if (p != null && !editing) {
            item {
                Text("${p.from.name} ⇄ ${p.to.name}", fontWeight = FontWeight.SemiBold, fontSize = 17.sp,
                    modifier = Modifier.padding(start = 16.dp, top = 12.dp))
            }
            when {
                error != null -> item { MessageBox(error ?: "") }
                r == null -> item { LoadingBox() }
                else -> {
                    val travelled = log.size
                    val cal = Calendar.getInstance()
                    val year = cal.get(Calendar.YEAR).toString()
                    val yearDays = log.count { it.date.startsWith(year) }
                    val plannedYear = (p.days.size * 46).coerceAtLeast(1) // ~46 settimane lavorative
                    item { BigStats(r, 1, tr("Ogni giorno (andata e ritorno)", "Every day (round trip)")) }
                    item { BigStats(r, plannedYear, tr("In un anno (${plannedYear} giorni di viaggio)", "In a year ($plannedYear travel days)")) }
                    if (yearDays > 0) item { BigStats(r, yearDays, tr("Finora nel $year ($yearDays giorni registrati)", "So far in $year ($yearDays days logged)")) }
                    item { TimeCard(r) }
                    item { DetailsCard(r, p) { np -> GreenCalc.saveProfile(ctx, np); profile = np } }
                    item {
                        DelayLog(log, travelled, onToggleToday = {
                            val k = GreenCalc.todayKey()
                            if (log.any { it.date == k }) GreenCalc.removeDay(ctx, k) else GreenCalc.setDay(ctx, GreenDay(k, null, null))
                            log = GreenCalc.log(ctx); tick++
                        })
                    }
                }
            }
        }
        item {
            Text(
                tr(
                    "Stime: CO₂ con fattori ISPRA/EEA (auto in base al carburante e ai consumi, treno regionale ~35 g per passeggero-km). " +
                        "Carburante: prezzo medio self del Ministero (MIMIT), aggiornato ogni giorno. Percorso stradale e pedaggi: OpenStreetMap/OSRM " +
                        "(pedaggio medio ${GreenCalc.TOLL_EURO_PER_KM} €/km sui tratti a pagamento). Traffico nelle ore di punta: +35% sul tempo senza traffico. " +
                        "Ritardi: ViaggiaTreno, registrati in automatico ogni sera.",
                    "Estimates: CO₂ using ISPRA/EEA factors (car by fuel and consumption, regional train ~35 g per passenger-km). " +
                        "Fuel: Italian Ministry (MIMIT) average self-service price, updated daily. Road route and tolls: OpenStreetMap/OSRM " +
                        "(average toll ${GreenCalc.TOLL_EURO_PER_KM} €/km on toll sections). Rush-hour traffic: +35% over free-flow time. " +
                        "Delays: ViaggiaTreno, logged automatically every evening.",
                ),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(16.dp),
            )
        }
    }
}

@Composable
private fun BigStats(r: GreenResult, days: Int, title: String) {
    WhiteCard {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 13.sp)
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Eco, null, tint = Green, modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(kg(r.co2SavedKg * days), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green)
                    Text(tr("di CO₂ risparmiata", "of CO₂ saved"), fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(eur(r.savedEuro * days), fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        color = if (r.savedEuro >= 0) Green else LateRed)
                    Text(if (r.savedEuro >= 0) tr("risparmiati", "saved") else tr("spesi in più", "extra cost"), fontSize = 13.sp)
                }
            }
            if (days >= 30) {
                val trees = (r.co2SavedKg * days / 22.0).toInt() // un albero assorbe ~22 kg CO₂/anno
                Text(tr("≈ la CO₂ assorbita in un anno da $trees alberi", "≈ the CO₂ absorbed in a year by $trees trees"),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
private fun TimeCard(r: GreenResult) {
    WhiteCard {
        CardTitle(tr("Tempo di viaggio (solo andata)", "Travel time (one way)"))
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Train, null, tint = Green)
                Spacer(Modifier.width(10.dp))
                Text(tr("Treno", "Train"), Modifier.weight(1f))
                Text("${r.trainMinutes}' + ${"%.0f".format(r.avgDelay)}' " + tr("ritardo medio", "avg delay"), fontWeight = FontWeight.SemiBold)
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.DirectionsCar, null, tint = Muted)
                Spacer(Modifier.width(10.dp))
                Text(tr("Auto", "Car"), Modifier.weight(1f))
                Text("${r.car.minutes}' " + tr("senza traffico", "free flow") + " · ${r.carMinutesTraffic}' " + tr("ore di punta", "rush hour"), fontWeight = FontWeight.SemiBold)
            }
            val diff = r.carMinutesTraffic - (r.trainMinutes + r.avgDelay).toInt()
            Text(
                if (diff >= 0) tr("In treno risparmi circa $diff minuti a tratta nelle ore di punta (e puoi leggere o lavorare).",
                    "By train you save about $diff minutes each way at rush hour (and you can read or work).")
                else tr("In auto impiegheresti circa ${-diff} minuti in meno a tratta, ma senza poter usare il tempo di viaggio.",
                    "By car it would take about ${-diff} minutes less each way, but you couldn't use the travel time."),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}

@Composable
private fun DetailsCard(r: GreenResult, p: GreenProfile, onSave: (GreenProfile) -> Unit) {
    // Campo in modifica: km, toll, fuel, parking, pass, cons
    var edit by remember { mutableStateOf<String?>(null) }
    WhiteCard {
        CardTitle(tr("Dettaglio giornaliero (A/R)", "Daily breakdown (round trip)"))
        Column(Modifier.padding(16.dp)) {
            @Composable
            fun line(a: String, b: String, bold: Boolean = false, mine: Boolean = false, key: String? = null) = Row(
                (if (key != null) Modifier.clickable(onClickLabel = tr("Modifica", "Edit")) { edit = key } else Modifier).padding(vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(a + (if (mine) " · " + tr("tuo", "yours") else ""), Modifier.weight(1f), fontSize = 14.sp, color = if (mine) Green else MaterialTheme.colorScheme.onSurface)
                Text(b, fontSize = 14.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
                if (key != null) Icon(Icons.Filled.Edit, null, tint = Muted, modifier = Modifier.padding(start = 6.dp).size(16.dp))
            }
            line(tr("Distanza in auto", "Road distance"), String.format(Locale.ITALY, "%.0f km × 2", r.car.km), mine = r.customKm, key = "km")
            line(tr("di cui a pedaggio", "of which tolled"), String.format(Locale.ITALY, "%.0f km", r.car.tollKm))
            line(tr("Consumo", "Consumption"), String.format(Locale.ITALY, "%.1f", p.consumption) + (if (p.fuel == "elettrica") " kWh/100 km" else " l/100 km"), key = "cons")
            line(tr("Carburante", "Fuel") + " (${p.fuel}, ${eur(r.fuelPrice)}/" + (if (p.fuel == "elettrica") "kWh" else "l") + ")", eur(r.fuelEuro), mine = r.customFuel, key = "fuel")
            Text(r.fuelPriceSource, color = Muted, fontSize = 11.sp)
            line(tr("Pedaggi autostradali", "Motorway tolls") + (if (r.customToll) "" else tr(" (stima)", " (estimate)")), eur(r.tollEuro), mine = r.customToll, key = "toll")
            line(tr("Parcheggio", "Parking"), eur(r.parkingEuro), mine = p.parking > 0, key = "parking")
            line(tr("Totale auto", "Car total"), eur(r.carEuro), true)
            line(tr("Treno (quota giornaliera abbonamento)", "Train (daily share of pass)"), eur(r.trainEuro), mine = p.trainMonthly > 0, key = "pass")
            Text(tr("Tocca una voce con ✎ per inserire il tuo valore: il calcolo si rifà subito e i valori restano salvati.",
                "Tap an item with ✎ to enter your own value: everything is recalculated at once and saved."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            line(tr("CO₂ auto", "Car CO₂"), kg(r.co2CarKg))
            line(tr("CO₂ treno", "Train CO₂"), kg(r.co2TrainKg))
            line(tr("CO₂ evitata", "CO₂ avoided"), kg(r.co2SavedKg), true)
        }
    }
    edit?.let { k ->
        val (title, unit, current, custom) = when (k) {
            "km" -> listOf(tr("Distanza in auto (sola andata)", "Road distance (one way)"), "km", String.format(Locale.US, "%.0f", r.car.km), r.customKm.toString())
            "toll" -> listOf(tr("Pedaggi al giorno (andata e ritorno)", "Tolls per day (round trip)"), "€", String.format(Locale.US, "%.2f", r.tollEuro * p.passengers.coerceAtLeast(1)), r.customToll.toString())
            "fuel" -> listOf(tr("Prezzo del carburante", "Fuel price"), if (p.fuel == "elettrica") "€/kWh" else "€/l", String.format(Locale.US, "%.3f", r.fuelPrice), r.customFuel.toString())
            "parking" -> listOf(tr("Parcheggio al giorno", "Parking per day"), "€", String.format(Locale.US, "%.2f", p.parking), "true")
            "pass" -> listOf(tr("Abbonamento treno al mese", "Train pass per month"), "€", String.format(Locale.US, "%.2f", p.trainMonthly), "true")
            else -> listOf(tr("Consumo dell'auto", "Car consumption"), if (p.fuel == "elettrica") "kWh/100 km" else "l/100 km", String.format(Locale.US, "%.1f", p.consumption), "true")
        }
        var value by remember(k) { mutableStateOf(current) }
        AlertDialog(
            onDismissRequest = { edit = null },
            title = { Text(title) },
            text = {
                Column {
                    OutlinedTextField(value, { value = it }, singleLine = true, label = { Text(unit) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    if (custom == "true" && k in setOf("km", "toll", "fuel")) TextButton({
                        onSave(when (k) { "km" -> p.copy(carKm = null); "toll" -> p.copy(tollDay = null); else -> p.copy(fuelPriceCustom = null) })
                        edit = null
                    }) { Text(tr("Torna al valore calcolato dall'app", "Back to the app's estimate"), color = Green) }
                }
            },
            confirmButton = {
                Button({
                    val v = value.replace(',', '.').trim().toDoubleOrNull()
                    if (v != null && v >= 0) {
                        onSave(when (k) {
                            "km" -> p.copy(carKm = v.coerceAtLeast(1.0))
                            "toll" -> p.copy(tollDay = v)
                            "fuel" -> p.copy(fuelPriceCustom = v.takeIf { it > 0 })
                            "parking" -> p.copy(parking = v)
                            "pass" -> p.copy(trainMonthly = v)
                            else -> p.copy(consumption = v.coerceAtLeast(0.1))
                        })
                    }
                    edit = null
                }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr("Salva e ricalcola", "Save and recalculate")) }
            },
            dismissButton = { TextButton({ edit = null }) { Text(tr("Annulla", "Cancel")) } },
        )
    }
}

@Composable
private fun DelayLog(log: List<GreenDay>, travelled: Int, onToggleToday: () -> Unit) {
    val today = GreenCalc.todayKey()
    WhiteCard {
        CardTitle(tr("Registro viaggi e ritardi", "Trip and delay log"))
        Column(Modifier.padding(16.dp)) {
            val all = log.flatMap { listOfNotNull(it.delayOut, it.delayBack) }
            Text(tr("Giorni registrati: $travelled", "Days logged: $travelled") +
                (if (all.isNotEmpty()) tr(" · ritardo medio ", " · avg delay ") + "%.1f'".format(all.average()) +
                    tr(" · massimo ", " · max ") + "${all.max()}'" else ""), fontSize = 14.sp)
            OutlinedButton(onToggleToday, Modifier.padding(vertical = 8.dp)) {
                Text(if (log.any { it.date == today }) tr("Togli oggi dal registro", "Remove today") else tr("Oggi ho viaggiato in treno", "I took the train today"), color = Green)
            }
            log.sortedByDescending { it.date }.take(10).forEach { d ->
                Row(Modifier.padding(vertical = 2.dp)) {
                    Text(d.date, Modifier.weight(1f), fontSize = 13.sp)
                    Text(tr("andata ", "out ") + (d.delayOut?.let { "${it}'" } ?: "–") + tr("  ritorno ", "  back ") + (d.delayBack?.let { "${it}'" } ?: "–"),
                        fontSize = 13.sp, color = Muted)
                }
            }
            Text(tr("Nei giorni di viaggio, dopo le 21, l'app salva da sola i ritardi dei tuoi treni abituali.",
                "On travel days after 9 pm the app automatically logs the delays of your usual trains."),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun GreenSetup(initial: GreenProfile?, onSave: (GreenProfile) -> Unit) {
    val ctx = LocalContext.current
    var from by remember { mutableStateOf(initial?.from) }
    var to by remember { mutableStateOf(initial?.to) }
    var out by remember { mutableStateOf(initial?.trainOut ?: "") }
    var back by remember { mutableStateOf(initial?.trainBack ?: "") }
    var fuel by remember { mutableStateOf(initial?.fuel ?: "benzina") }
    var cons by remember { mutableStateOf((initial?.consumption ?: 6.5).toString()) }
    var park by remember { mutableStateOf((initial?.parking ?: 0.0).toString()) }
    var pass by remember { mutableStateOf((initial?.trainMonthly ?: 0.0).toString()) }
    var days by remember { mutableStateOf(initial?.days ?: setOf(2, 3, 4, 5, 6)) }
    var pick by remember { mutableStateOf<Int?>(null) }

    WhiteCard {
        CardTitle(tr("La tua tratta da pendolare", "Your commute"))
        Column(Modifier.padding(16.dp)) {
            OutlinedButton({ pick = 0 }, Modifier.fillMaxWidth()) { Text(tr("Partenza: ", "From: ") + (from?.name ?: tr("scegli", "choose"))) }
            OutlinedButton({ pick = 1 }, Modifier.fillMaxWidth()) { Text(tr("Arrivo: ", "To: ") + (to?.name ?: tr("scegli", "choose"))) }
            Row {
                OutlinedTextField(out, { v -> out = v.filter { it.isDigit() } }, Modifier.weight(1f).padding(end = 4.dp),
                    label = { Text(tr("Treno andata", "Outbound train")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(back, { v -> back = v.filter { it.isDigit() } }, Modifier.weight(1f).padding(start = 4.dp),
                    label = { Text(tr("Treno ritorno", "Return train")) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Text(tr("Giorni di viaggio", "Travel days"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Row {
                listOf(2 to tr("L", "M"), 3 to tr("M", "T"), 4 to tr("M", "W"), 5 to tr("G", "T"), 6 to tr("V", "F"), 7 to tr("S", "S"), 1 to tr("D", "S"))
                    .forEach { (d, l) ->
                        val on = d in days
                        Box(
                            Modifier.padding(2.dp).size(38.dp).clip(RoundedCornerShape(19.dp))
                                .background(if (on) Green else Color(0xFFE0E0E0)).clickable { days = if (on) days - d else days + d },
                            contentAlignment = Alignment.Center,
                        ) { Text(l, color = if (on) Color.White else Color.Black) }
                    }
            }
            Text(tr("Carburante dell'auto", "Car fuel"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.fillMaxWidth()) {
                listOf("benzina", "gasolio", "gpl", "metano", "elettrica").forEach { f ->
                    FilterChip(fuel == f, { fuel = f }, label = { Text(f, fontSize = 12.sp) }, modifier = Modifier.padding(end = 4.dp))
                }
            }
            OutlinedTextField(cons, { cons = it }, label = { Text(if (fuel == "elettrica") "kWh/100 km" else tr("Consumo l/100 km", "Consumption l/100 km")) },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(park, { park = it }, label = { Text(tr("Parcheggio € al giorno", "Parking € per day")) },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pass, { pass = it }, label = { Text(tr("Abbonamento treno € al mese", "Train pass € per month")) },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            Button(
                {
                    val f = from; val t = to
                    if (f == null || t == null) toast(ctx, tr("Scegli partenza e arrivo", "Choose origin and destination"))
                    else onSave(
                        GreenProfile(f, t, out, back, days, fuel,
                            cons.replace(',', '.').toDoubleOrNull() ?: 6.5,
                            park.replace(',', '.').toDoubleOrNull() ?: 0.0,
                            pass.replace(',', '.').toDoubleOrNull() ?: 0.0),
                    )
                },
                Modifier.fillMaxWidth().padding(top = 10.dp), colors = ButtonDefaults.buttonColors(containerColor = Green),
            ) { Text(tr("Calcola", "Calculate")) }
        }
    }
    pick?.let { w ->
        key(w) {
            StationPickerDialog(if (w == 0) tr("Partenza", "From") else tr("Arrivo", "To"), { pick = null }) { s ->
                if (w == 0) from = s else to = s
                pick = null
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Assistente (bot)
// ---------------------------------------------------------------------------

private data class Msg(val mine: Boolean, val text: String, val train: TrainRef? = null, val station: Station? = null,
    val source: String = "", val url: String = "")

@Composable
fun BotScreen(
    vm: MainViewModel, onBack: () -> Unit, onTrain: (TrainRef) -> Unit, onStation: (Station) -> Unit,
    startListening: Boolean = false,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs = remember { mutableStateListOf(Msg(false, Bot.help())) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    // Le risposte vengono lette ad alta voce se la domanda è arrivata a voce o se la modalità non vedenti è attiva
    var speakReplies by remember { mutableStateOf(startListening || vm.store.blindMode) }
    val list = rememberLazyListState()
    DisposableEffect(Unit) { onDispose { com.binario.treni.service.Speech.stop() } }

    fun send(q: String, shown: String = q) {
        if (q.isBlank() || busy) return
        msgs += Msg(true, shown)
        input = ""
        busy = true
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                try {
                    Bot.answer(q, vm.store)
                } catch (e: Exception) {
                    Bot.Reply(tr("Si è verificato un errore di rete. Riprova.", "A network error occurred. Please try again."))
                }
            }
            msgs += Msg(false, r.text, r.train, r.station, r.source, r.url)
            if (speakReplies) {
                com.binario.treni.service.Speech.stop()
                com.binario.treni.service.Speech.say(ctx, r.text + (if (r.train != null) tr(". Puoi seguire il treno con gli avvisi vocali.", ". You can follow the train with voice alerts.") else ""),
                    com.binario.treni.service.Speech.Sound.INFO, force = true)
            }
            busy = false
            list.animateScrollToItem(msgs.size)
        }
    }

    // Riconoscimento vocale del telefono (Google o quello predefinito): nessun permesso microfono richiesto all'app
    val voice = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
    ) { res ->
        val text = res.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) { speakReplies = true; send(text) }
    }
    fun listen() {
        val i = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, I18n.speechTag)
            .putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, tr("Chiedi un treno, una stazione o un tragitto", "Ask about a train, station or route"))
        try {
            voice.launch(i)
        } catch (e: Exception) {
            msgs += Msg(false, tr("Il riconoscimento vocale non è disponibile su questo telefono. Installa o attiva l'app Google.",
                "Speech recognition is not available on this phone. Install or enable the Google app."))
        }
    }
    LaunchedEffect(startListening) { if (startListening) listen() }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tr("Assistente treni", "Train assistant"), onBack) {
            IconButton({ speakReplies = !speakReplies; if (!speakReplies) com.binario.treni.service.Speech.stop() }) {
                Icon(if (speakReplies) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                    if (speakReplies) tr("Lettura ad alta voce attiva", "Read aloud on") else tr("Lettura ad alta voce spenta", "Read aloud off"))
            }
        }
        LazyColumn(Modifier.weight(1f), state = list, contentPadding = PaddingValues(10.dp)) {
            items(msgs) { m ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
                    Column(
                        Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (m.mine) Green else MaterialTheme.colorScheme.surface).padding(12.dp),
                    ) {
                        Text(m.text, color = if (m.mine) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
                        m.train?.let { t ->
                            TextButton({ onTrain(t) }) { Text(tr("Apri il treno", "Open train"), color = Green) }
                            TextButton({
                                com.binario.treni.service.TrackingService.start(ctx, t)
                                com.binario.treni.service.Speech.say(ctx, tr("Seguo il treno. Ti avviserò con la voce.", "Following the train. I will give you voice alerts."),
                                    com.binario.treni.service.Speech.Sound.PLATFORM, force = true)
                            }) { Text(tr("Segui con avvisi vocali", "Follow with voice alerts"), color = Green) }
                        }
                        m.station?.let { s -> TextButton({ onStation(s) }) { Text(tr("Apri la stazione", "Open station"), color = Green) } }
                        if (m.url.isNotBlank()) SourceLink(m.source, m.url)
                    }
                }
            }
            if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(8.dp), color = Green) }
            item {
                Row(Modifier.padding(top = 6.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
                    listOf(
                        Triple("Dov'è il mio treno?", "Where is my train?", "where is my train"), Triple("Ci sono scioperi?", "Any strikes?", "any strikes"),
                        Triple("Circolazione", "Traffic", "traffic"), Triple("Rimborso per ritardo", "Delay compensation", "delay compensation"),
                        Triple("Posso portare la bici?", "Can I bring my bike?", "can i bring my bike"), Triple("Treni garantiti", "Guaranteed trains", "guaranteed trains"),
                        Triple("Assistenza disabili", "Disability assistance", "disability assistance"),
                    ).forEach { (it0, en0, query) ->
                        val s = tr(it0, en0)
                        AssistChip({ send(query, s) }, label = { Text(s, fontSize = 12.sp) }, modifier = Modifier.padding(end = 6.dp))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f),
                placeholder = { Text(tr("Es. ritardo treno 2070", "e.g. delay train 2070")) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send(input) }),
            )
            if (input.isBlank()) {
                // Microfono grande: facile da trovare anche con TalkBack
                FilledIconButton({ listen() }, Modifier.size(52.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green)) {
                    Icon(Icons.Filled.Mic, tr("Parla: fai una domanda a voce", "Speak: ask a question"), tint = Color.White)
                }
            } else {
                IconButton({ send(input) }) { Icon(Icons.AutoMirrored.Filled.Send, tr("Invia", "Send"), tint = Green) }
            }
        }
    }
}
