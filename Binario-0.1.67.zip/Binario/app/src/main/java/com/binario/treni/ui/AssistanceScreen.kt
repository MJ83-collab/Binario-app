package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n

private fun tr(a: String, b: String) = I18n.tr(a, b)

/**
 * Assistenza per viaggiatori con disabilità (di qualsiasi tipo) o a mobilità ridotta: chi chiamare, come prenotare,
 * con quanto anticipo. Fonti: RFI Sale Blu, Trenord, Italo, FFS (pagine ufficiali, ottobre 2026).
 */
@Composable
fun AssistanceScreen(onBack: () -> Unit, onCapotreno: () -> Unit = {}) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tr("Assistenza disabili", "Disability assistance"), onBack)
        WhiteCard {
            Column(Modifier.padding(16.dp)) {
                Text(tr("L'assistenza è gratuita, in stazione e per salire e scendere dal treno.", "Assistance is free, in the station and for getting on and off the train."),
                    fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(tr("Vale per persone in carrozzina o con difficoltà a camminare (anche temporanee), persone cieche o ipovedenti, sorde o con difficoltà di comunicazione, con disabilità intellettiva o psichica, anziani e donne in gravidanza.",
                    "It covers wheelchair users and people with walking difficulties (even temporary), blind or partially sighted, deaf or with communication difficulties, people with intellectual or mental disabilities, older people and pregnant women."),
                    fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                Text(tr("Chi chiamare dipende dalla stazione e dal treno: nelle stazioni RFI (quasi tutte le stazioni italiane) l'assistenza la fanno le Sale Blu per tutte le imprese; nelle stazioni FerrovieNord la fa Trenord; in Svizzera le FFS.",
                    "Who to call depends on the station and train: at RFI stations (almost all Italian stations) the Sale Blu assist for every operator; at FerrovieNord stations Trenord does; in Switzerland, SBB."),
                    color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        WhiteCard {
            CardTitle(tr("RFI Sale Blu · Trenitalia, Italo, Trenord nelle stazioni RFI", "RFI Sale Blu · Trenitalia, Italo, Trenord at RFI stations"))
            MenuRow(Icons.Filled.Call, "800 90 60 60", tr("Numero verde da telefono fisso · tutti i giorni 6:45–21:30", "Toll-free from landlines · daily 6:45–21:30")) { dial(ctx, "800906060") }
            MenuRow(Icons.Filled.PhoneAndroid, "+39 02 32 32 32", tr("Da cellulare e dall'estero (tariffa normale)", "From mobiles and abroad (standard rate)")) { dial(ctx, "+3902323232") }
            MenuRow(Icons.Filled.Email, "salablu.nazionale@rfi.it", tr("Almeno 6 ore prima: stazioni, data, treno, tipo di assistenza, telefono", "At least 6 hours before: stations, date, train, type of assistance, phone")) { mail(ctx, "salablu.nazionale@rfi.it") }
            MenuRow(Icons.Filled.Language, tr("SalaBlu Online e app SalaBlu+", "SalaBlu Online and SalaBlu+ app"), tr("Prenotazione fino a 3 ore prima; chat per persone sorde", "Booking up to 3 hours before; chat for deaf people")) {
                openUrl(ctx, "https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/le-informazioni-sull-assistenza-delle-sale-blu-in-un-click.html")
            }
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                Text(tr("Con quanto anticipo: nelle grandi stazioni (es. Milano Porta Garibaldi) fino a 1 ora prima per i treni tra le 7:45 e le 22:30; nelle altre stazioni e di notte almeno 12 ore prima. Gruppi da 3 persone: 24 ore. Viaggi all'estero: 24–48 ore.",
                    "How far ahead: at major stations (e.g. Milano Porta Garibaldi) up to 1 hour before for trains between 7:45 and 22:30; at other stations and at night at least 12 hours before. Groups of 3+: 24 hours. Trips abroad: 24–48 hours."),
                    fontSize = 13.sp)
                Text(tr("Presentati al punto d'incontro almeno 30 minuti prima: il personale ha il gilet arancione. Per disdire avvisa almeno 4 ore prima.",
                    "Be at the meeting point at least 30 minutes before: staff wear orange vests. To cancel, give at least 4 hours' notice."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        WhiteCard {
            CardTitle(tr("Trenord e stazioni FerrovieNord", "Trenord and FerrovieNord stations"))
            MenuRow(Icons.Filled.Call, "800 210 955", tr("Numero verde assistenza Trenord · prenota preferibilmente 48 ore prima", "Trenord assistance toll-free · book preferably 48 hours ahead")) { dial(ctx, "800210955") }
            MenuRow(Icons.Filled.PhoneAndroid, "+39 02 72 49 49 49", tr("Contact center Trenord (anche da cellulare)", "Trenord contact centre (also from mobiles)")) { dial(ctx, "+390272494949") }
            MenuRow(Icons.Filled.Email, "assistenza.prm@trenord.it", tr("Informazioni e prenotazioni", "Information and bookings")) { mail(ctx, "assistenza.prm@trenord.it") }
            MenuRow(Icons.Filled.ReportProblem, "senzabarriere@trenord.it", tr("Segnala barriere tra treno e stazione", "Report barriers between train and station")) { mail(ctx, "senzabarriere@trenord.it") }
        }

        WhiteCard {
            CardTitle("Italo")
            MenuRow(Icons.Filled.Call, "06 07 08", tr("Pronto Italo · tutti i giorni 7–23: posto adatto e prenotazione dell'assistenza (in stazione la fa RFI)", "Pronto Italo · daily 7–23: suitable seat and assistance booking (provided in station by RFI)")) { dial(ctx, "060708") }
            MenuRow(Icons.Filled.Language, tr("Pagina assistenza Italo", "Italo assistance page"), "italotreno.com") {
                openUrl(ctx, "https://www.italotreno.com/it/contatti-supporto/assistenza-persone-mobilita-ridotta")
            }
        }

        WhiteCard {
            CardTitle(tr("Svizzera · FFS e TILO", "Switzerland · SBB and TILO"))
            MenuRow(Icons.Filled.Call, "+41 800 007 102", tr("Contact Center Handicap FFS dall'Italia · tutti i giorni 5–24 (dalla Svizzera 0800 007 102, gratuito)", "SBB Contact Center Handicap from Italy · daily 5–24 (from Switzerland 0800 007 102, free)")) { dial(ctx, "+41800007102") }
            MenuRow(Icons.Filled.Language, tr("Prenota online", "Book online"), tr("swisspass.ch/handicap · almeno 1 ora prima (viaggi internazionali 24 ore)", "swisspass.ch/handicap · at least 1 hour before (international trips 24 hours)")) {
                openUrl(ctx, "https://www.sbb.ch/it/informazioni-viaggio/esigenze-individuali/viaggiare-mobilita-ridotta/contact-center-handicap.html")
            }
        }

        WhiteCard {
            CardTitle(tr("Consigli per tipo di disabilità", "Tips by type of disability"))
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                Tip("♿", tr("Carrozzina: salita e discesa con pedana o elevatore. Carrozzina al massimo 70 cm di larghezza, 120 cm di lunghezza e 250 kg con la persona. Nella scheda della stazione vedi ascensori per binario e guasti in corso.",
                    "Wheelchair: boarding with ramp or lift. Wheelchair at most 70 cm wide, 120 cm long and 250 kg including the person. The station screen shows lifts per platform and current faults."))
                Tip("🦯", tr("Persone cieche o ipovedenti: il cane guida viaggia gratis; puoi chiedere un posto adatto quando prenoti. Attiva l'opzione parlata: l'app ti dice binario, partenza e fermata dove scendere.",
                    "Blind or partially sighted: guide dogs travel free; you can ask for a suitable seat when booking. Turn on the spoken option: the app tells you platform, departure and your stop."))
                Tip("🧏", tr("Persone sorde: le Sale Blu hanno una chat (con registrazione su SalaBlu Online). Nel Mio Capotreno usa \"Trascrivi chi parla\" e \"Fai parlare il telefono\"; attiva vibrazione e flash per gli avvisi.",
                    "Deaf people: the Sale Blu have a chat (after registering on SalaBlu Online). In My Conductor use \"Transcribe speech\" and \"Let the phone speak\"; turn on vibration and flash alerts."))
                Tip("🧠", tr("Disabilità intellettiva o psichica, o chi non è autosufficiente: può servire un accompagnatore; l'assistenza accompagna dal punto d'incontro al treno e alla coincidenza.",
                    "Intellectual or mental disabilities, or people who are not self-sufficient: a companion may be needed; staff escort you from the meeting point to the train and connection."))
                Tip("🤰", tr("Anziani, donne in gravidanza, ingessature o difficoltà temporanee: l'assistenza vale anche per voi, con sedia a rotelle su richiesta e aiuto con un bagaglio a mano.",
                    "Older people, pregnant women, casts or temporary difficulties: assistance is for you too, with a wheelchair on request and help with one piece of hand luggage."))
                Tip("🔁", tr("Coincidenze: lascia almeno 30 minuti tra un treno e l'altro quando prenoti l'assistenza.", "Connections: allow at least 30 minutes between trains when booking assistance."))
            }
            TextButton({ onCapotreno() }, Modifier.padding(start = 8.dp, bottom = 8.dp)) { Text(tr("Apri Il mio Capotreno", "Open My Conductor"), color = Green) }
        }

        WhiteCard {
            CardTitle(tr("Emergenza", "Emergency"))
            MenuRow(Icons.Filled.LocalHospital, "112", tr("Numero unico di emergenza (Italia e Svizzera)", "Single emergency number (Italy and Switzerland)")) { dial(ctx, "112") }
        }
        Text(tr("Numeri e regole dalle pagine ufficiali di RFI, Trenord, Italo e FFS (ottobre 2026): in caso di dubbio verifica sul sito dell'impresa.",
            "Numbers and rules from the official RFI, Trenord, Italo and SBB pages (October 2026): if in doubt, check the operator's site."),
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
    }
}

@Composable
private fun Tip(icon: String, text: String) {
    Row(Modifier.padding(vertical = 4.dp)) {
        Text(icon, fontSize = 18.sp, modifier = Modifier.width(30.dp))
        Text(text, fontSize = 14.sp)
    }
}
