package com.binario.treni.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.Osm
import com.binario.treni.data.OsmPlace
import com.binario.treni.data.Station
import com.binario.treni.data.TicketSellers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

private fun tr(a: String, b: String) = I18n.tr(a, b)

/** Colori in stile sito Trenord: link rossi in corsivo, limitazioni in arancione. */
private val TrenordRed = Color(0xFFC8102E)
private val LimitOrange = Color(0xFFE65100)

/** Categorie del sito Trenord (My Link Point, Biglietterie, Emettitrici automatiche, Rivendite) più "altro" (OpenStreetMap). */
private const val CAT_OFFICE = 0
private const val CAT_MACHINE = 1
private const val CAT_RESELLER = 2
private const val CAT_OTHER = 3
private const val CAT_LINK = 4

private val CAT_KEYS = mapOf(CAT_LINK to "link", CAT_OFFICE to "office", CAT_MACHINE to "machine", CAT_RESELLER to "reseller", CAT_OTHER to "other")

private fun isLinkPoint(name: String, url: String) = url.contains("my-link-point", true) || name.contains("link point", true)

private fun catOf(k: OsmPlace.Kind, name: String = "", url: String = "", assist: Boolean = false) = when (k) {
    OsmPlace.Kind.TICKET_OFFICE -> if (assist || isLinkPoint(name, url)) CAT_LINK else CAT_OFFICE
    OsmPlace.Kind.TICKET_MACHINE -> CAT_MACHINE
    OsmPlace.Kind.RESELLER -> CAT_RESELLER
    else -> CAT_OTHER
}

private fun catShort(c: Int) = when (c) {
    CAT_LINK -> tr("Ufficio assistenza", "Customer service")
    CAT_OFFICE -> tr("Biglietterie", "Ticket offices")
    CAT_MACHINE -> tr("Emettitrici automatiche", "Ticket machines")
    CAT_RESELLER -> tr("Rivendite", "Resellers")
    else -> tr("Obliteratrici e altro", "Validators & more")
}

/** Un punto vendita pronto da mostrare (dall'elenco Trenord, dalle FFS, dall'Alto Adige o da OpenStreetMap). */
private data class SalePoint(
    val cat: Int,
    val name: String,
    val lat: Double,
    val lon: Double,
    val located: Boolean,
    val distance: Int?,
    val status: String = "",
    val near: String = "",
    val nearDist: Int = 0,
    val address: String = "",
    val hours: String = "",
    val url: String = "",
    val machines: Int = 0,
    val pay: String = "",
    val source: String = "",
    val official: Boolean = true,
    val contactless: Boolean = false,
    val cards: Boolean = false,
    val services: String = "",
    val kindLabel: String = "",
    val province: String = "",
    /** Nome che l'azienda dà al punto: My Link Point, Ufficio Assistenza Clienti, Casa Italo, Centro viaggiatori FFS… */
    val brand: String = "",
)

/** Azienda del punto vendita. */
private fun operatorOf(s: SalePoint) = when (s.source) {
    "Trenord" -> "Trenord"
    "Trenitalia" -> "Trenitalia"
    "Italo" -> "Italo"
    "FFS", "FFS/SBB" -> "FFS / TILO"
    "altoadigemobilità" -> "altoadigemobilità (STA)"
    else -> s.source.ifBlank { "OpenStreetMap" }
}

/** Fonte del dato, da mostrare su ogni scheda. */
private fun sourceOf(s: SalePoint) = when (s.source) {
    "Trenord" -> "biglietterie.trenord.it" + if (s.status.isNotBlank()) tr(" (aperto/chiuso dal sito Trenord)", " (open/closed from Trenord)") else ""
    "Trenitalia" -> tr("trenitalia.com · Uffici Assistenza Clienti (orari di aprile 2025)", "trenitalia.com · Customer service offices (April 2025 hours)")
    "Italo" -> tr("italotreno.com · Biglietterie in stazione", "italotreno.com · Station ticket offices")
    "FFS" -> "sbb.ch · arcobaleno.ch"
    "FFS/SBB" -> tr("dati aperti FFS (data.sbb.ch)", "SBB open data (data.sbb.ch)")
    "altoadigemobilità" -> "suedtirolmobil.info"
    else -> tr("OpenStreetMap (volontari): verifica sul posto", "OpenStreetMap (volunteers): check on site")
}

private fun metres(from: Pair<Double, Double>?, lat: Double, lon: Double): Int? = from?.let {
    val r = FloatArray(1); android.location.Location.distanceBetween(it.first, it.second, lat, lon, r); r[0].toInt()
}

private fun fromPlace(p: OsmPlace, from: Pair<Double, Double>?) = SalePoint(
    cat = catOf(p.kind, p.name, p.tags["x_url"].orEmpty(), p.tags["x_assist"] == "yes"), brand = p.tags["x_brand"].orEmpty(), name = p.name, lat = p.lat, lon = p.lon, located = true,
    distance = metres(from, p.lat, p.lon) ?: p.distance,
    status = p.tags["x_status"].orEmpty(), near = p.tags["x_near"].orEmpty(), nearDist = p.tags["x_near_dist"]?.toIntOrNull() ?: 0,
    address = p.tags["x_address"].orEmpty(), hours = p.hours, url = p.tags["x_url"].orEmpty(),
    machines = p.tags["x_machines"]?.toIntOrNull() ?: 0, pay = p.tags["x_pay"].orEmpty(),
    source = p.tags["x_source"] ?: "OpenStreetMap", official = p.tags["x_official"] == "yes",
    contactless = p.contactless, cards = p.cards, services = p.tags["x_services"].orEmpty(), kindLabel = p.kind.label,
)

private fun fromSeller(s: TicketSellers.Seller, from: Pair<Double, Double>?) = SalePoint(
    cat = catOf(s.kind, s.name, s.url, s.assist), brand = s.brand, name = s.name, lat = s.lat, lon = s.lon, located = s.located,
    distance = if (s.located) metres(from, s.lat, s.lon) else null,
    status = s.status, near = s.nearStation, nearDist = s.nearDist, address = s.address, hours = s.hours, url = s.url,
    machines = s.machines, pay = s.pay, source = s.source, services = s.services, kindLabel = s.kind.label, province = s.province,
)

/**
 * Punti vendita in stile sito Trenord (biglietterie.trenord.it/punti-vendita): casella "Inserisci città o stazione",
 * quattro pulsanti grandi (My Link point, Biglietterie, Emettitrici automatiche, Rivendite), mappa con segnalini grigi
 * e simbolo della categoria (cerchi verdi numerati quando sono tanti) e il pulsante "Mostra elenco".
 * Tutta la Lombardia dall'elenco Trenord (aperto/chiuso letto dal vivo per la provincia che guardi) più, vicino a te,
 * biglietterie automatiche FFS, punti altoadigemobilità e OpenStreetMap.
 */
@Composable
fun SellersScreen(vm: MainViewModel, station: Station?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("sellers_ui", android.content.Context.MODE_PRIVATE) }
    var center by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var status by remember { mutableStateOf(tr("Carico i punti vendita…", "Loading sales points…")) }
    var trenord by remember { mutableStateOf<List<TicketSellers.Seller>?>(null) }
    var extras by remember { mutableStateOf<List<OsmPlace>>(emptyList()) }
    var cat by remember { mutableStateOf<Int?>(prefs.getInt("cat", CAT_OFFICE).takeIf { it >= 0 }) }
    var showList by remember { mutableStateOf(!vm.store.mapsEnabled) }
    var query by remember { mutableStateOf("") }
    var focus by remember { mutableStateOf<Osm.Poi?>(null) }
    var searching by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    var liveProvince by remember { mutableStateOf<String?>(null) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> granted = r.values.any { it } }

    LaunchedEffect(station?.id, granted) {
        if (station != null) {
            center = withContext(Dispatchers.IO) { Api.stationCoord(vm.store, station.id) }
        } else if (granted) {
            (lastLocation(ctx) ?: currentLocation(ctx))?.let { center = it.latitude to it.longitude }
        } else {
            launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }
    // Elenco Trenord di tutta la Lombardia (della settimana), con le emettitrici collegate alla loro stazione
    LaunchedEffect(retry) {
        trenord = withContext(Dispatchers.IO) {
            runCatching { TicketSellers.withCoords(ctx.applicationContext, TicketSellers.ensureList(ctx.applicationContext) { status = it }) }.getOrNull()
        }.orEmpty() + withContext(Dispatchers.IO) {
            // Uffici assistenza e biglietterie di Trenitalia, Italo e FFS (TILO), ognuno con la sua fonte
            runCatching { com.binario.treni.data.AssistanceOffices.all(ctx.applicationContext) }.getOrDefault(emptyList())
        }
    }
    // Riferimento: il luogo cercato, altrimenti io (o la stazione)
    val ref: Pair<Double, Double>? = focus?.let { it.lat to it.lon } ?: center
    // Aperto/chiuso dal vivo (ed emettitrici aggiornate) per la provincia del luogo che guardi
    LaunchedEffect(ref?.first?.let { Math.round(it * 20) }, ref?.second?.let { Math.round(it * 20) }, trenord != null) {
        val r = ref ?: return@LaunchedEffect
        val key = TicketSellers.nearestProvince(r.first, r.second) ?: return@LaunchedEffect
        if (key == liveProvince || trenord == null) return@LaunchedEffect
        val live = withContext(Dispatchers.IO) { runCatching { TicketSellers.province(ctx.applicationContext, key) }.getOrNull() } ?: return@LaunchedEffect
        if (!live.second) return@LaunchedEffect
        liveProvince = key
        trenord = trenord.orEmpty().filter { it.province != key } + live.first
    }
    // Vicino a me: FFS, Alto Adige e OpenStreetMap (biglietterie, emettitrici, obliteratrici non Trenord)
    LaunchedEffect(ref?.first?.let { Math.round(it * 100) }, ref?.second?.let { Math.round(it * 100) }, retry) {
        val c = ref ?: return@LaunchedEffect
        extras = withContext(Dispatchers.IO) {
            coroutineScope {
                val jobs = listOf(
                    async { runCatching { TicketSellers.altoAdigeNear(ctx.applicationContext, c.first, c.second, 2000).map { (s, d) -> TicketSellers.toPlace(s, d) } }.getOrDefault(emptyList()) },
                    async { runCatching { TicketSellers.sbbMachines(c.first, c.second, 2000).map { (s, d) -> TicketSellers.toPlace(s, d) } }.getOrDefault(emptyList()) },
                    async { runCatching { Osm.ticketPlaces(c.first, c.second, 1500) }.getOrDefault(emptyList()) },
                )
                withTimeoutOrNull(25_000) { jobs.awaitAll().flatten() } ?: emptyList()
            }
        }
    }

    val t = trenord
    val official = t.orEmpty().map { fromSeller(it, ref) }
    // Un punto OpenStreetMap vicino a uno ufficiale dello stesso tipo è lo stesso punto (le emettitrici Trenord stanno "in stazione")
    val extra = extras.map { fromPlace(it, ref) }.filter { p ->
        official.none { q ->
            val station = q.cat == CAT_MACHINE && q.source == "Trenord"
            q.located && q.source == "Trenord" && (q.cat == p.cat || (q.cat == CAT_LINK && p.cat == CAT_OFFICE)) &&
                Math.abs(q.lat - p.lat) < (if (station) 0.0014 else 0.0004) && Math.abs(q.lon - p.lon) < (if (station) 0.0019 else 0.0005)
        }
    }
    val everything = official + extra
    val q = query.trim().lowercase()
    val provinceHit = TicketSellers.provinceNames.firstOrNull { it.second.lowercase() == q || it.first == q }?.first
    val textMatches = if (q.isEmpty()) everything else everything.filter { p ->
        (provinceHit != null && p.province == provinceHit) ||
            p.name.lowercase().contains(q) || p.near.lowercase().contains(q) || p.address.lowercase().contains(q)
    }
    // Se il testo non corrisponde a nessun nome ma ho trovato il luogo, mostro i punti attorno a quel luogo
    val pool = if (textMatches.isEmpty() && focus != null) everything else textMatches
    val counts = listOf(CAT_LINK, CAT_OFFICE, CAT_MACHINE, CAT_RESELLER, CAT_OTHER).associate { c -> CAT_KEYS.getValue(c) to pool.count { it.cat == c } }
    val shown = pool.filter { cat == null || it.cat == cat }.sortedWith(compareBy({ it.distance ?: Int.MAX_VALUE }, { it.name }))
    val nearestKm = shown.firstOrNull()?.distance?.let { it / 1000 }

    fun submit() {
        val text = query.trim()
        if (text.isEmpty()) { focus = null; return }
        searching = true
    }
    LaunchedEffect(searching) {
        if (!searching) return@LaunchedEffect
        val text = query.trim()
        focus = withContext(Dispatchers.IO) {
            runCatching { Osm.geocode(if (provinceHit != null) "$text, Lombardia" else text, center).firstOrNull() }.getOrNull()
        }
        searching = false
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(if (station != null) tr("Punti vendita", "Sales points") + " · ${station.name}" else tr("Punti vendita", "Sales points"), onBack)
        TrenordSearchField(query, { query = it; if (it.isBlank()) focus = null }, { submit() }, onMyLocation = {
            query = ""; focus = null
            if (!granted) launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        })
        TrenordChoiceGrid(
            listOf(
                TrenordChoice("link", tr("Ufficio assistenza", "Customer service"), Icons.Outlined.Info),
                TrenordChoice("office", tr("Biglietterie", "Ticket offices"), Icons.Outlined.SupportAgent),
                TrenordChoice("machine", tr("Emettitrici automatiche", "Ticket machines"), Icons.Outlined.PointOfSale),
                TrenordChoice("reseller", tr("Rivendite", "Resellers"), Icons.Outlined.Storefront),
            ),
            isSelected = { k -> cat?.let { CAT_KEYS[it] } == k },
            counts = counts,
        ) { k ->
            val c = CAT_KEYS.entries.first { it.value == k }.key
            cat = if (cat == c) null else c
            prefs.edit().putInt("cat", cat ?: -1).apply()
        }
        // Obliteratrici e punti OpenStreetMap senza categoria Trenord, e "tutti"
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp)) {
            FilterChip(cat == null, { cat = null; prefs.edit().putInt("cat", -1).apply() }, label = { Text(tr("Tutti", "All") + " · ${pool.size}") },
                modifier = Modifier.padding(end = 6.dp))
            if ((counts["other"] ?: 0) > 0) FilterChip(cat == CAT_OTHER, { cat = if (cat == CAT_OTHER) null else CAT_OTHER },
                label = { Text(tr("Obliteratrici e altro", "Validators & more") + " · ${counts["other"]}") },
                leadingIcon = { Icon(Icons.Filled.Nfc, null, Modifier.size(16.dp)) })
            if (searching) CircularProgressIndicator(Modifier.size(22.dp).padding(start = 8.dp), strokeWidth = 2.dp, color = Green)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                t == null -> MessageBox(status)
                showList || !vm.store.mapsEnabled -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                    item {
                        val where = focus?.name?.substringBefore(",") ?: if (station != null) station.name else if (center != null) tr("te", "you") else null
                        Text(
                            (cat?.let { catShort(it) } ?: tr("Punti vendita", "Sales points")) + " · ${shown.size}" +
                                (where?.let { " · " + tr("dal più vicino a", "nearest to") + " " + it } ?: ""),
                            fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
                        )
                        if (nearestKm != null && nearestKm > 25) Text(
                            tr("I punti vendita Trenord sono in Lombardia. Qui vicino: biglietterie automatiche FFS, punti altoadigemobilità e OpenStreetMap; nel resto d'Italia usa la mappa ufficiale Trenitalia (in fondo).",
                                "Trenord sales points are in Lombardy. Nearby: SBB machines, altoadigemobilità and OpenStreetMap points; elsewhere in Italy use the official Trenitalia map (at the bottom)."),
                            color = LimitOrange, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp),
                        )
                        if (liveProvince != null) Text(tr("Aperto/chiuso aggiornato adesso dal sito Trenord per la provincia di", "Open/closed updated now from Trenord for the province of") + " " +
                            (TicketSellers.provinceNames.firstOrNull { it.first == liveProvince }?.second ?: liveProvince.orEmpty()) + ".",
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
                        if (shown.isEmpty()) MessageBox(tr("Nessun punto vendita trovato.", "No sales points found."))
                    }
                    items(shown.take(300)) { s -> SellerCard(s) }
                    if (shown.size > 300) item {
                        Text(tr("Mostro i 300 più vicini: cerca una città o una stazione per gli altri.", "Showing the nearest 300: search a town or station for the others."),
                            color = Muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
                    }
                    item { NearbyFooter(ref) }
                }
                else -> {
                    val pts = shown.filter { it.located }
                    OsmMap(
                        pts.map { p ->
                            MapPoint(p.lat, p.lon, p.name,
                                listOfNotNull(
                                    catShort(p.cat),
                                    p.status.takeIf { it.isNotBlank() },
                                    if (p.machines > 0) machinesLabel(p.machines) else null,
                                    p.distance?.let { distLabel(it) },
                                ).joinToString(" · ") + "\n" + tr("Tocca di nuovo per le indicazioni", "Tap again for directions"),
                                glyph = CAT_KEYS[p.cat],
                            ) { directions(ctx, p) }
                        },
                        drawLine = false, modifier = Modifier.fillMaxSize(),
                        me = if (station == null) center else null, googleQuery = "biglietteria treni",
                        target = focus?.let { MapPoint(it.lat, it.lon, it.name, tr("Luogo cercato", "Searched place")) }
                            ?: if (station != null) center?.let { MapPoint(it.first, it.second, station.name, tr("Stazione", "Station")) } else null,
                        selected = -1, cluster = pts.size > 15, fitNearest = if (ref != null) 8 else null,
                    )
                }
            }
            if (vm.store.mapsEnabled && t != null) ShowListButton(showList, Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)) { showList = !showList }
        }
    }
}

/** Scheda di un punto vendita in stile Trenord: triangolino verde, nome, dettagli, stato e "Ottieni indicazioni". */
@Composable
private fun SellerCard(s: SalePoint) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    WhiteCard {
        Column(Modifier.padding(start = 12.dp, end = 14.dp, top = 12.dp, bottom = 6.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Filled.PlayArrow, null, tint = Green, modifier = Modifier.size(20.dp).padding(top = 2.dp))
                Spacer(Modifier.width(4.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    // Sempre: di quale azienda è, come la chiama l'azienda e da dove arriva il dato
                    Text(operatorOf(s) + " · " + s.brand.ifBlank { s.kindLabel }, color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(tr("Fonte: ", "Source: ") + sourceOf(s), color = Muted, fontSize = 11.sp)
                }
                s.distance?.let { d ->
                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 8.dp)) {
                        Text(distLabel(d), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${(d / 80).coerceAtLeast(1)} " + tr("min a piedi", "min walk"), color = Muted, fontSize = 11.sp)
                    }
                }
            }
            Column(Modifier.padding(start = 24.dp, top = 4.dp)) {
                when (s.cat) {
                    CAT_RESELLER -> if (s.near.isNotBlank()) {
                        Text(tr("Stazione più vicina: ", "Nearest station: ") + s.near, fontSize = 14.sp)
                        if (s.nearDist > 0) Text(tr("Distanza: ", "Distance: ") + s.nearDist + " " + tr("metri", "metres"), fontSize = 14.sp)
                    }
                    CAT_MACHINE -> if (s.machines > 0 || s.pay.isNotBlank()) {
                        if (s.machines > 0) Text(machinesLabel(s.machines), fontSize = 14.sp)
                        PaymentRow(s.pay)
                    }
                    else -> {}
                }
                if (s.address.isNotBlank()) Text(s.address, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                if (s.status.isNotBlank()) StatusLine(s.status)
                if (s.cat == CAT_OTHER || s.source == "OpenStreetMap") {
                    val badges = listOfNotNull(
                        if (s.contactless) tr("📶 contactless", "📶 contactless") else if (s.cards) tr("💳 carte", "💳 cards") else null,
                        s.hours.takeIf { it.isNotBlank() && !(s.cat == CAT_OFFICE || s.cat == CAT_LINK) }?.let { "🕒 $it" },
                    )
                    if (badges.isNotEmpty()) Text(badges.joinToString("  "), fontSize = 13.sp, color = Muted)
                }
                if (s.services.isNotBlank()) Text(tr("Vende: ", "Sells: ") + s.services, color = Muted, fontSize = 12.sp, maxLines = 3)
                if (s.hours.isNotBlank() && (s.cat == CAT_OFFICE || s.cat == CAT_LINK)) {
                    Row(
                        Modifier.clickable { open = !open }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Schedule, null, tint = Green, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(tr("Orari della settimana", "Weekly opening hours"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Icon(if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, null, tint = Green, modifier = Modifier.size(18.dp))
                    }
                    if (open) HoursTable(s.hours)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TrenordLink(tr("Ottieni indicazioni", "Get directions")) { directions(ctx, s) }
                    if (s.url.isNotBlank()) {
                        Spacer(Modifier.width(16.dp))
                        TrenordLink(tr("Visita la pagina", "Visit the page")) { openUrl(ctx, s.url) }
                    }
                }
            }
        }
    }
}

/** "Aperto - Chiude alle: 20:00" con la prima parola in grassetto, verde se aperto e rossa se chiuso (come sul sito). */
@Composable
private fun StatusLine(status: String) {
    val head = status.substringBefore(" - ").trim()
    val rest = status.substringAfter(" - ", "").trim()
    val open = head.startsWith("Aperto", true) || head.startsWith("Open", true)
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = if (open) Green else LateRed)) { append(head) }
            if (rest.isNotBlank()) append(" - $rest")
        },
        fontSize = 15.sp, modifier = Modifier.padding(vertical = 2.dp),
    )
}

/** Metodi di pagamento delle emettitrici: carta, monete, banconote; in arancione con * se "operativa con limitazioni". */
@Composable
private fun PaymentRow(pay: String) {
    val list = pay.split(",").filter { it.isNotBlank() }
    if (list.isEmpty()) return
    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        list.forEach { p ->
            val limited = p.endsWith("!")
            val (icon, label) = when (p[0]) {
                'E' -> Icons.Filled.CreditCard to tr("Carta", "Card")
                'M' -> Icons.Filled.Paid to tr("Monete", "Coins")
                else -> Icons.Filled.Payments to tr("Banconote", "Notes")
            }
            val col = if (limited) LimitOrange else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
            Row(
                Modifier.padding(end = 6.dp).border(1.dp, col.copy(alpha = 0.4f), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 3.dp)
                    .semantics { contentDescription = label + if (limited) tr(", operativa con limitazioni", ", limited operation") else "" },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(icon, null, tint = col, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(3.dp))
                Text(label + if (limited) "*" else "", color = col, fontSize = 12.sp)
            }
        }
    }
    if (list.any { it.endsWith("!") }) Text(tr("*Operativa con limitazioni", "*Limited operation"), color = LimitOrange, fontSize = 12.sp)
}

/** Orari "Lun–Ven 6:00–20:00 · Sab 7:00–13:00" come tabella giorno / orario. */
@Composable
private fun HoursTable(hours: String) {
    Column(Modifier.padding(start = 20.dp, bottom = 4.dp)) {
        hours.split(" · ").forEach { part ->
            val day = part.substringBefore(" ")
            val time = part.substringAfter(" ", "")
            Row(Modifier.padding(vertical = 1.dp)) {
                Text(day, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.width(90.dp))
                Text(if (time.equals("chiuso", true)) tr("chiuso", "closed") else time, fontSize = 14.sp,
                    color = if (time.equals("chiuso", true)) LateRed else MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
private fun NearbyFooter(center: Pair<Double, Double>?) {
    val ctx = LocalContext.current
    val gmaps = listOf(tr("Biglietterie", "Ticket offices") to "biglietteria treni", tr("Punti Mooney", "Mooney points") to "Mooney punto vendita",
        "PuntoLIS" to "PuntoLIS Lottomatica")
    center?.let { c ->
        Column(Modifier.padding(horizontal = 8.dp)) {
            Text(tr("Non trovi quello che cerchi? Cerca su Google Maps:", "Can't find it? Search on Google Maps:"), color = Muted, fontSize = 13.sp,
                modifier = Modifier.padding(start = 8.dp, top = 8.dp))
            GoogleMapsButtons(c.first, c.second, gmaps)
        }
    }
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) { TrenitaliaMapButton() }
    val upd = TicketSellers.updatedAt(ctx)
    Text(
        tr("Fonti", "Sources") + ": " + listOf(
            tr("biglietterie, emettitrici e rivenditori Trenord", "Trenord offices, machines and resellers") +
                (if (upd > 0) " (" + tr("elenco del", "list from") + " " + Fmt.day(upd) + ", " + tr("aperto/chiuso letto ora", "open/closed read now") + ")" else ""),
            tr("punti vendita altoadigemobilità (Alto Adige)", "altoadigemobilità outlets (South Tyrol)"),
            tr("biglietterie automatiche FFS (data.sbb.ch)", "SBB ticket machines (data.sbb.ch)"),
            tr("altri punti da", "other points from") + " " + Osm.lastSource.ifBlank { "OpenStreetMap" },
        ).joinToString("; ") + ". " +
            tr("Nel resto d'Italia i biglietti regionali Trenitalia si comprano nei punti PuntoLIS e Mooney: li mostra la mappa ufficiale Trenitalia.",
                "Elsewhere in Italy, Trenitalia regional tickets are sold at PuntoLIS and Mooney points: see the official Trenitalia map."),
        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp),
    )
    SourceLink("Trenord · punti vendita", TicketSellers.TRENORD_SITE, Modifier.padding(horizontal = 16.dp))
    SourceLink("Trenitalia · punti vendita", TicketSellers.TRENITALIA_INFO, Modifier.padding(horizontal = 16.dp))
    SourceLink("altoadigemobilità · punti vendita", TicketSellers.BZ_SITE, Modifier.padding(horizontal = 16.dp))
    SourceLink("FFS · billetautomat", TicketSellers.SBB_DATA, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
}

/** Mappa ufficiale Trenitalia dei punti vendita (tutta Italia). */
@Composable
private fun TrenitaliaMapButton() {
    val ctx = LocalContext.current
    OutlinedButton({ openUrl(ctx, TicketSellers.TRENITALIA_MAP) }) {
        Icon(Icons.Filled.Map, null, Modifier.size(18.dp), tint = Green)
        Spacer(Modifier.width(6.dp))
        Text(tr("Mappa ufficiale Trenitalia (tutta Italia)", "Official Trenitalia map (all Italy)"), color = Green)
    }
}

private fun machinesLabel(n: Int) = if (n == 1) tr("1 emettitrice", "1 machine") else "$n " + tr("emettitrici", "machines")

private fun distLabel(m: Int) = if (m < 1000) "$m m" else if (m % 1000 == 0) "${m / 1000} km" else String.format("%.1f km", m / 1000.0)

/** Indicazioni a piedi con Google Maps (o con la stazione, se il punto non ha coordinate proprie). */
private fun directions(ctx: android.content.Context, s: SalePoint) {
    val dest = if (s.located) "${s.lat},${s.lon}"
    else java.net.URLEncoder.encode("stazione " + s.near.ifBlank { s.name }, "UTF-8")
    openUrl(ctx, "https://www.google.com/maps/dir/?api=1&destination=$dest&travelmode=walking")
}

@SuppressLint("MissingPermission")
private fun lastLocation(ctx: android.content.Context): android.location.Location? = try {
    val lm = ctx.getSystemService(LocationManager::class.java)
    lm?.getProviders(true)?.mapNotNull { p ->
        try {
            lm.getLastKnownLocation(p)
        } catch (e: SecurityException) {
            null
        }
    }?.maxByOrNull { it.time }
} catch (e: Exception) {
    null
}
