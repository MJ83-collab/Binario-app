package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n

private fun tr(a: String, b: String) = I18n.tr(a, b)

/**
 * Oggetti smarriti: cosa fare subito e a chi rivolgersi per impresa (Trenord, Trenitalia, Italo, FFS/TILO).
 * Fonti: pagine ufficiali Trenord e FFS, servizio Trenitalia (ottobre 2026).
 */
@Composable
fun LostScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val tracked = remember { vm.store.tracked() }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tr("Oggetti smarriti", "Lost property"), onBack)

        WhiteCard {
            CardTitle(tr("Cosa fare subito", "What to do right away"))
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                LostStep("1", tr("Se sei ancora sul treno o in stazione, avvisa subito il capotreno o il personale: è il modo più veloce per ritrovarlo.",
                    "If you are still on the train or in the station, tell the conductor or staff straight away: it's the fastest way to find it."))
                LostStep("2", tr("Annota numero del treno, giorno, ora, carrozza e posto, e descrivi bene l'oggetto (marca, colore, contenuto).",
                    "Note the train number, day, time, coach and seat, and describe the item well (brand, colour, contents)."))
                LostStep("3", tr("Contatta l'impresa del treno (qui sotto): ognuna ha il suo servizio oggetti smarriti.",
                    "Contact the train's operator (below): each has its own lost property service."))
                LostStep("4", tr("Documenti, carte o telefono: blocca le carte e, per furto o documenti, fai denuncia alla Polizia Ferroviaria (Polfer) o ai Carabinieri.",
                    "Documents, cards or phone: block your cards and, for theft or documents, report it to the Railway Police (Polfer) or Carabinieri."))
                LostStep("5", tr("Dopo qualche giorno gli oggetti non ritirati passano all'ufficio oggetti rinvenuti del Comune: chiedi lì.",
                    "After a few days unclaimed items go to the town's lost property office: ask there."))
                tracked?.let { t ->
                    Text(tr("Il treno che stai seguendo: ", "The train you are following: ") + t.label, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        modifier = Modifier.padding(top = 8.dp))
                }
            }
        }

        WhiteCard {
            CardTitle(tr("Trenord, Malpensa Express e stazioni FerrovieNord", "Trenord, Malpensa Express and FerrovieNord stations"))
            MenuRow(Icons.Filled.Call, "02 72 49 49 49", tr("Contact Center Trenord: oggetti persi sul treno o sulle banchine", "Trenord Contact Center: items lost on trains or platforms")) { dial(ctx, "+390272494949") }
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(tr("Gli oggetti ritrovati sono custoditi ai My Link Point di Milano Cadorna e Milano Porta Garibaldi per pochi giorni (fino a 6), poi passano all'Ufficio Oggetti Rinvenuti del Comune di Milano.",
                    "Found items are kept at the My Link Points in Milano Cadorna and Milano Porta Garibaldi for a few days (up to 6), then go to the City of Milan lost property office."), fontSize = 14.sp)
            }
            MenuRow(Icons.Filled.Call, tr("Comune di Milano · Oggetti rinvenuti", "City of Milan · Lost property"), tr("Via Friuli 30, Milano · 02 884 53900", "Via Friuli 30, Milan · 02 884 53900")) { dial(ctx, "+390288453900") }
            MenuRow(Icons.Filled.Language, tr("Pagina Trenord oggetti smarriti", "Trenord lost property page"), "trenord.it") {
                openUrl(ctx, "https://www.trenord.it/assistenza/servizi/oggetti-smarriti/")
            }
        }

        WhiteCard {
            CardTitle("Trenitalia")
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(tr("Frecce: rivolgiti al Frecciadesk o all'assistenza clienti in stazione appena te ne accorgi, il personale può far controllare il tuo posto. Regionali e Intercity: gli oggetti ritrovati vengono di solito consegnati all'ufficio oggetti rinvenuti del Comune della stazione di arrivo del treno.",
                    "Frecce: go to the Frecciadesk or customer service in the station as soon as you notice, staff can have your seat checked. Regional and Intercity: found items are usually handed to the lost property office of the town where the train terminates."), fontSize = 14.sp)
            }
            MenuRow(Icons.Filled.Search, tr("Servizio ricerca oggetti smarriti", "Lost items search service"), "trenitalia.com") {
                openUrl(ctx, "https://www.trenitalia.com/it/informazioni/servizio-ricercaoggettismarriti.html")
            }
            MenuRow(Icons.Filled.SupportAgent, tr("Uffici assistenza clienti", "Customer service offices"), "trenitalia.com") {
                openUrl(ctx, "https://www.trenitalia.com/it/informazioni/gli-uffici-assistenzaclienti.html")
            }
        }

        WhiteCard {
            CardTitle("Italo")
            MenuRow(Icons.Filled.Call, "06 07 08", tr("Pronto Italo, tutti i giorni 7–23: segnala l'oggetto con numero del treno, carrozza e posto", "Pronto Italo, daily 7–23: report the item with train number, coach and seat")) { dial(ctx, "060708") }
        }

        WhiteCard {
            CardTitle(tr("Svizzera · FFS e TILO", "Switzerland · SBB and TILO"))
            MenuRow(Icons.Filled.Language, tr("Segnala lo smarrimento online", "Report the loss online"), "lostandfound.sbb.ch") {
                openUrl(ctx, "https://lostandfound.sbb.ch/home/sbb/SBB/app?Culturename=it")
            }
            MenuRow(Icons.Filled.Call, "+41 848 44 66 88", tr("Contact Center FFS, 24 ore su 24", "SBB Contact Center, 24 hours")) { dial(ctx, "+41848446688") }
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                Text(tr("Al ritiro si paga CHF 20 (CHF 10 con l'abbonamento generale); dispositivi elettronici e oggetti ingombranti CHF 25 (CHF 15). Sui treni TILO tra Italia e Svizzera segnala sia alle FFS sia a Trenord.",
                    "On collection you pay CHF 20 (CHF 10 with a GA travelcard); electronics and bulky items CHF 25 (CHF 15). On TILO trains between Italy and Switzerland report to both SBB and Trenord."),
                    fontSize = 13.sp)
            }
        }

        Text(tr("Informazioni dalle pagine ufficiali di Trenord, Trenitalia e FFS (ottobre 2026): tempi e modalità possono cambiare.",
            "Information from the official Trenord, Trenitalia and SBB pages (October 2026): times and procedures may change."),
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
    }
}

@Composable
private fun LostStep(n: String, text: String) {
    Row(Modifier.padding(vertical = 4.dp)) {
        Text(n, color = Green, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.width(24.dp))
        Text(text, fontSize = 14.sp)
    }
}
