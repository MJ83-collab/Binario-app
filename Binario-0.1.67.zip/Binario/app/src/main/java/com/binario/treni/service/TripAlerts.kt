package com.binario.treni.service

import android.content.Context
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.MyRoute
import com.binario.treni.data.SearchFilter
import com.binario.treni.data.Solution
import com.binario.treni.data.Station
import com.binario.treni.data.Store
import com.binario.treni.data.TrainRef
import com.binario.treni.data.tx
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Avvisi sul «Mio viaggio» (tratta salvata in «La mia tratta»), controllati dal lavoro periodico ogni ~15 minuti:
 *  - Esci di casa: prima del treno di andata, calcolato con il ritardo attuale e i minuti a piedi impostati;
 *  - Ultimo treno utile: la sera, sul ritorno (arrivo → partenza), quando la prossima corsa è l'ultima;
 *  - Coincidenza a rischio: se il ritardo di un treno lascia meno di 3 minuti per il cambio.
 * Fuori dalle finestre orarie non fa nessuna richiesta di rete.
 */
object TripAlerts {
    private val rome = TimeZone.getTimeZone("Europe/Rome")
    private const val MIN = 60_000L

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("binario_trip", Context.MODE_PRIVATE)
    private fun dayKey(t: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date(t))

    private fun already(ctx: Context, key: String): Boolean = prefs(ctx).getBoolean(key, false)
    private fun mark(ctx: Context, key: String) {
        val p = prefs(ctx)
        // Tiene solo le chiavi recenti
        val old = p.all.keys.filter { it.substringBefore('|') < dayKey(System.currentTimeMillis() - 3 * 86_400_000L) }
        val e = p.edit()
        old.forEach { e.remove(it) }
        e.putBoolean(key, true).apply()
    }

    private fun todayAt(hhmm: String, now: Long): Long? {
        val m = Regex("^(\\d{1,2})[:.](\\d{2})").find(hhmm.trim()) ?: return null
        return Calendar.getInstance(rome).apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, m.groupValues[1].toInt()); set(Calendar.MINUTE, m.groupValues[2].toInt()); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    /** Soluzione che parte più vicina all'orario abituale (entro 12 minuti), con o senza cambi. */
    private fun solutionAt(from: Station, to: Station, t: Long): Solution? = try {
        Api.solutions(from, to, t - 5 * MIN, SearchFilter.ALL)
            .filter { it.legs.isNotEmpty() && kotlin.math.abs(it.dep - t) <= 12 * MIN }
            .minByOrNull { kotlin.math.abs(it.dep - t) }
    } catch (_: Exception) {
        null
    }

    private fun delayOf(number: String): Int? = try { Api.statusBasic(TrainRef(number)).delay } catch (_: Exception) { null }

    fun run(ctx: Context) {
        val store = Store(ctx)
        val r = store.myRoute() ?: return
        val from = r.from ?: return
        val to = r.to ?: return
        if (!r.complete || !r.alerts) return
        val now = System.currentTimeMillis()
        val dow = Calendar.getInstance(rome).apply { timeInMillis = now }.get(Calendar.DAY_OF_WEEK)
        val today = dayKey(now)
        if (dow in r.days) {
            todayAt(r.out, now)?.let { t ->
                leaveHome(ctx, r, from, to, t, now, today)
                connections(ctx, from, to, t, now, today, "out")
            }
            todayAt(r.back, now)?.let { t -> connections(ctx, to, from, t, now, today, "back") }
        }
        lastTrain(ctx, to, from, now)
    }

    private fun leaveHome(ctx: Context, r: MyRoute, from: Station, to: Station, t: Long, now: Long, today: String) {
        val key = "$today|leave"
        if (already(ctx, key)) return
        val walk = r.walk.coerceIn(0, 120) * MIN
        if (now < t - walk - 40 * MIN || now > t + 5 * MIN) return
        val sol = solutionAt(from, to, t) ?: return
        val delay = (delayOf(sol.legs.first().number) ?: 0).coerceAtLeast(0)
        val dep = sol.dep + delay * MIN
        val leaveAt = dep - walk
        // Si avvisa quando mancano al massimo 15 minuti al momento di uscire (e il treno non è ancora partito)
        if (now < leaveAt - 15 * MIN || now > dep) return
        Notif.createChannels(ctx)
        Notif.post(ctx, 9701, Notif.CH_ALERT, "🚶 " + tx("Esci di casa"),
            tx("Esci di casa entro le") + " " + Fmt.time(leaveAt) + " · " + tx("per il treno delle") + " " + Fmt.time(sol.dep) +
                (if (delay > 0) " (+$delay min)" else ""),
            Notif.openApp(ctx, TrainRef(sol.legs.first().number), 9701))
        if (Notif.canPost(ctx)) mark(ctx, key)
    }

    private fun connections(ctx: Context, a: Station, b: Station, t: Long, now: Long, today: String, tag: String) {
        if (now < t - 10 * MIN || now > t + 150 * MIN) return
        val sol = solutionAt(a, b, t) ?: return
        if (sol.legs.size < 2) return
        for (i in 0 until sol.legs.size - 1) {
            val l1 = sol.legs[i]
            val l2 = sol.legs[i + 1]
            val key = "$today|conn|$tag|$i"
            if (already(ctx, key)) continue
            val st = try { Api.statusBasic(TrainRef(l1.number)) } catch (_: Exception) { continue }
            val stop = st.stops.firstOrNull { it.name.equals(l1.to, true) } ?: continue
            if (stop.realArr > 0) continue // già arrivato
            val exp = (if (stop.schedArr > 0) stop.schedArr else l1.arr) + stop.delay.coerceAtLeast(0) * MIN
            val d2 = (delayOf(l2.number) ?: 0).coerceAtLeast(0)
            val next = l2.dep + d2 * MIN
            if (next - exp >= 3 * MIN) continue
            Notif.createChannels(ctx)
            Notif.post(ctx, 9710 + i + (if (tag == "back") 5 else 0), Notif.CH_ALERT, "🔀 " + tx("Coincidenza a rischio a") + " " + l1.to,
                tx("arrivo previsto") + " " + Fmt.time(exp) + " · " + tx("ripartenza") + " " + Fmt.time(next) + " (" + l2.title + ")",
                Notif.openApp(ctx, st.ref, 9710 + i))
            if (Notif.canPost(ctx)) mark(ctx, key)
        }
    }

    private fun lastTrain(ctx: Context, a: Station, b: Station, now: Long) {
        val hour = Calendar.getInstance(rome).apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY)
        if (hour in 2..19) return
        val day = dayKey(if (hour < 2) now - 6 * 3600_000L else now)
        val key = "$day|last"
        if (already(ctx, key)) return
        val list = try { Api.solutions(a, b, now, SearchFilter.ALL) } catch (_: Exception) { return }
        val first = list.filter { it.dep >= now }.minByOrNull { it.dep } ?: return
        if (first.dep - now > 60 * MIN) return
        val later = try { Api.solutions(a, b, first.dep + MIN, SearchFilter.ALL) } catch (_: Exception) { return }
        // Nessuna altra corsa nelle 4 ore successive: questa è l'ultima utile
        if (later.any { it.dep > first.dep && it.dep - first.dep <= 4 * 3600_000L }) return
        Notif.createChannels(ctx)
        Notif.post(ctx, 9720, Notif.CH_ALERT, "🌙 " + tx("Ultimo treno utile"),
            tx("Ultimo treno utile verso") + " " + b.name + " · " + tx("parte alle") + " " + Fmt.time(first.dep) + " (" + first.legs.first().title + ")",
            Notif.openApp(ctx, TrainRef(first.legs.first().number), 9720))
        if (Notif.canPost(ctx)) mark(ctx, key)
    }
}
