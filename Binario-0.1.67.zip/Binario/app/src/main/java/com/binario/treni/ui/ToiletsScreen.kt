package com.binario.treni.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Accessibility
import androidx.compose.material.icons.outlined.BabyChangingStation
import androidx.compose.material.icons.outlined.MoneyOff
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.binario.treni.data.Api
import com.binario.treni.data.I18n
import com.binario.treni.data.Osm
import com.binario.treni.data.Station
import com.binario.treni.data.Toilet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun tr(a: String, b: String) = I18n.tr(a, b)

/**
 * Bagni pubblici in stile sito Trenord (come i Punti vendita): casella "Inserisci città o stazione", quattro filtri
 * grandi (Gratuiti, Accessibili, Fasciatoio, Aperti a tutti), mappa con segnalini grigi "WC" e "Mostra elenco".
 * Dati OpenStreetMap, gli stessi del tema "Bagni pubblici" di MapComplete (mapcomplete.org/toilets), con i suoi dettagli:
 * prezzo, accessibilità, fasciatoio, uomini/donne/unisex, seduti/orinatoi, carta, lavandino, piano, orari.
 * Da ogni bagno si può aprire MapComplete per vedere foto o correggere i dati.
 */
@Composable
fun ToiletsScreen(vm: MainViewModel, station: Station?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var center by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var list by remember { mutableStateOf<List<Toilet>?>(null) }
    var status by remember { mutableStateOf(tr("Ricerca della posizione…", "Finding your location…")) }
    var failed by remember { mutableStateOf(false) }
    var radius by remember { mutableIntStateOf(1000) }
    var retry by remember { mutableIntStateOf(0) }
    var showList by remember { mutableStateOf(!vm.store.mapsEnabled) }
    val filters = remember { mutableStateListOf<String>() }
    var query by remember { mutableStateOf("") }
    var focus by remember { mutableStateOf<Osm.Poi?>(null) }
    var searching by remember { mutableStateOf(false) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> granted = r.values.any { it } }

    LaunchedEffect(station?.id, granted) {
        if (station != null) {
            center = withContext(Dispatchers.IO) { Api.stationCoord(vm.store, station.id) }
            if (center == null) status = tr("Coordinate della stazione non disponibili: cerca una città o una stazione.", "Station coordinates not available: search a town or station.")
        } else if (granted) {
            val l = lastKnown(ctx) ?: currentLocation(ctx)
            if (l != null) center = l.latitude to l.longitude
            else status = tr("Posizione non disponibile: attiva il GPS o cerca una città o una stazione.", "Location not available: turn on GPS or search a town or station.")
        } else {
            launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            status = tr("Serve il permesso di posizione, oppure cerca una città o una stazione.", "Location permission needed, or search a town or station.")
        }
    }
    val ref: Pair<Double, Double>? = focus?.let { it.lat to it.lon } ?: center
    LaunchedEffect(ref, radius, retry) {
        val c = ref ?: return@LaunchedEffect
        list = null
        failed = false
        status = tr("Cerco i bagni pubblici entro", "Looking for public toilets within") + " " + (if (radius < 1000) "$radius m" else "${radius / 1000} km") + "…"
        list = try {
            withContext(Dispatchers.IO) { Osm.toilets(c.first, c.second, radius) }
        } catch (e: Exception) {
            failed = true
            status = tr("I server OpenStreetMap non rispondono. Riprova tra poco o cerca su Google Maps.", "OpenStreetMap servers are not responding. Try again shortly or search Google Maps."); null
        }
    }
    LaunchedEffect(searching) {
        if (!searching) return@LaunchedEffect
        focus = withContext(Dispatchers.IO) { runCatching { Osm.geocode(query.trim(), center).firstOrNull() }.getOrNull() }
        if (focus == null) status = tr("Luogo non trovato: prova con il nome della città o della stazione.", "Place not found: try the town or station name.")
        searching = false
    }

    fun ok(w: Toilet) = ("free" !in filters || w.fee == "no") && ("wheel" !in filters || w.wheelchair == "yes") &&
        ("baby" !in filters || w.changingTable) && ("public" !in filters || (w.access != "customers" && w.access != "private"))
    val all = list.orEmpty()
    val shown = all.filter { ok(it) }
    val counts = mapOf(
        "free" to all.count { it.fee == "no" }, "wheel" to all.count { it.wheelchair == "yes" },
        "baby" to all.count { it.changingTable }, "public" to all.count { it.access != "customers" && it.access != "private" },
    )

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(if (station != null) tr("Bagni pubblici", "Public toilets") + " · ${station.name}" else tr("Bagni pubblici", "Public toilets"), onBack)
        TrenordSearchField(query, { query = it; if (it.isBlank()) focus = null }, { if (query.isNotBlank()) searching = true else focus = null },
            onMyLocation = {
                query = ""; focus = null
                if (!granted) launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            })
        TrenordChoiceGrid(
            listOf(
                TrenordChoice("free", tr("Gratuiti", "Free"), Icons.Outlined.MoneyOff),
                TrenordChoice("wheel", tr("Accessibili", "Accessible"), Icons.Outlined.Accessibility),
                TrenordChoice("baby", tr("Fasciatoio", "Baby changing"), Icons.Outlined.BabyChangingStation),
                TrenordChoice("public", tr("Aperti a tutti", "Open to all"), Icons.Outlined.Public),
            ),
            isSelected = { it in filters }, counts = if (list != null) counts else emptyMap(),
        ) { k -> if (k in filters) filters.remove(k) else filters.add(k) }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(500, 1000, 2000).forEach { r ->
                FilterChip(radius == r, { radius = r }, label = { Text(if (r < 1000) "$r m" else "${r / 1000} km") }, modifier = Modifier.padding(end = 6.dp))
            }
            if (searching || (list == null && ref != null && !failed)) CircularProgressIndicator(Modifier.size(22.dp).padding(start = 4.dp), strokeWidth = 2.dp, color = Green)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val l = list
            when {
                l == null -> Column {
                    MessageBox(status)
                    val c = ref
                    if (failed && c != null) Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        OutlinedButton({ retry++ }) { Text(tr("Riprova", "Retry"), color = Green) }
                        GoogleMapsButtons(c.first, c.second, listOf(tr("Bagni pubblici", "Public toilets") to "bagni pubblici"))
                    }
                }
                showList || !vm.store.mapsEnabled -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                    item {
                        Text(tr("Bagni pubblici", "Public toilets") + " · ${shown.size}" +
                            (focus?.let { " · " + tr("vicino a", "near") + " " + it.name.substringBefore(",") } ?: ""),
                            fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp))
                        if (shown.isEmpty()) {
                            MessageBox(tr("Nessun bagno pubblico mappato qui con questi filtri.", "No public toilets mapped here with these filters."))
                            if (radius < 2000) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                OutlinedButton({ radius = 2000 }) { Text(tr("Cerca entro 2 km", "Search within 2 km"), color = Green) }
                            }
                        }
                    }
                    items(shown) { w -> ToiletCard(w) }
                    item {
                        ref?.let {
                            Column(Modifier.padding(horizontal = 8.dp)) {
                                Text(tr("Non trovi quello che cerchi? Cerca su Google Maps:", "Can't find it? Search on Google Maps:"), color = Muted, fontSize = 13.sp,
                                    modifier = Modifier.padding(start = 8.dp, top = 8.dp))
                                GoogleMapsButtons(it.first, it.second, listOf(tr("Bagni pubblici", "Public toilets") to "bagni pubblici"))
                            }
                        }
                        Text(tr("Dati © OpenStreetMap, gli stessi della mappa MapComplete \"Bagni pubblici\" (", "Data © OpenStreetMap, the same as the MapComplete \"Public toilets\" map (") +
                            Osm.lastSource.ifBlank { "Overpass" } + "). " +
                            tr("Prezzi, orari e accessibilità li inseriscono i volontari: verifica sul posto. Se qualcosa è sbagliato puoi correggerlo da \"Vedi su MapComplete\".",
                                "Prices, hours and accessibility are entered by volunteers: check on site. If something is wrong you can fix it via \"View on MapComplete\"."),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
                        SourceLink("MapComplete · Bagni pubblici", "https://mapcomplete.org/toilets.html", Modifier.padding(horizontal = 16.dp))
                    }
                }
                else -> OsmMap(
                    shown.map { w ->
                        MapPoint(w.lat, w.lon, w.name.ifBlank { tr("Bagno pubblico", "Public toilet") },
                            w.feeText + (if (w.wheelchair == "yes") " · ♿" else "") + (if (w.changingTable) " · 🚼" else "") +
                                " · " + (if (w.distance < 1000) "${w.distance} m" else String.format("%.1f km", w.distance / 1000.0)) +
                                "\n" + tr("Tocca di nuovo per le indicazioni", "Tap again for directions"),
                            glyph = "wc",
                        ) { toiletDirections(ctx, w) }
                    },
                    drawLine = false, modifier = Modifier.fillMaxSize(), me = if (station == null) center else null, googleQuery = "bagni pubblici",
                    target = focus?.let { MapPoint(it.lat, it.lon, it.name, tr("Luogo cercato", "Searched place")) }
                        ?: if (station != null) center?.let { MapPoint(it.first, it.second, station.name, tr("Stazione", "Station")) } else null,
                    selected = -1,
                )
            }
            if (vm.store.mapsEnabled && list != null) ShowListButton(showList, Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)) { showList = !showList }
        }
    }
}

/** Scheda di un bagno in stile Trenord, con i dettagli che mostra MapComplete. */
@Composable
private fun ToiletCard(w: Toilet) {
    val ctx = LocalContext.current
    WhiteCard {
        Column(Modifier.padding(start = 12.dp, end = 14.dp, top = 12.dp, bottom = 6.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                TrenordName(w.name.ifBlank { tr("Bagno pubblico", "Public toilet") }, Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 8.dp)) {
                    Text(if (w.distance < 1000) "${w.distance} m" else String.format("%.1f km", w.distance / 1000.0), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${(w.distance / 80).coerceAtLeast(1)} " + tr("min a piedi", "min walk"), color = Muted, fontSize = 11.sp)
                }
            }
            Column(Modifier.padding(start = 24.dp, top = 4.dp)) {
                Text(w.feeText, color = if (w.fee == "no") Green else MaterialTheme.colorScheme.onSurface, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                val lines = listOfNotNull(
                    when (w.wheelchair) {
                        "yes" -> tr("♿ Accessibile in carrozzina", "♿ Wheelchair accessible")
                        "limited" -> tr("♿ In parte accessibile", "♿ Partly accessible")
                        "no" -> tr("Non accessibile in carrozzina", "Not wheelchair accessible")
                        else -> null
                    },
                    if (w.changingTable) tr("🚼 Fasciatoio", "🚼 Baby changing table") else null,
                    when (w.gender) {
                        "unisex" -> tr("Unisex", "Unisex")
                        "both" -> tr("Uomini e donne", "Men and women")
                        "male" -> tr("Solo uomini", "Men only")
                        "female" -> tr("Solo donne", "Women only")
                        else -> null
                    },
                    when {
                        w.position.contains("seated") && w.position.contains("urinal") -> tr("Con seduta e orinatoi", "Seated and urinals")
                        w.position.contains("urinal") -> tr("Solo orinatoi", "Urinals only")
                        w.position.contains("squat") -> tr("Alla turca", "Squat toilet")
                        w.position.contains("seated") -> tr("Con seduta", "Seated")
                        else -> null
                    },
                    listOfNotNull(
                        if (w.paper == "yes") tr("carta igienica", "toilet paper") else null,
                        if (w.handwashing == "yes") tr("lavandino", "hand washing") else null,
                    ).takeIf { it.isNotEmpty() }?.joinToString(" e ", prefix = tr("Con ", "With ")),
                    when (w.access) {
                        "customers" -> tr("Solo per i clienti", "Customers only")
                        "private", "no" -> tr("Non aperto al pubblico", "Not open to the public")
                        else -> null
                    },
                    w.level.takeIf { it.isNotBlank() }?.let { tr("Piano", "Level") + " " + it },
                    w.operator.takeIf { it.isNotBlank() && it != w.name }?.let { tr("Gestito da", "Operated by") + " " + it },
                )
                lines.forEach { Text(it, fontSize = 14.sp) }
                if (w.hours.isNotBlank()) Text("🕒 " + w.hours, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                if (w.description.isNotBlank()) Text(w.description, fontSize = 13.sp, color = Muted, maxLines = 3)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TrenordLink(tr("Ottieni indicazioni", "Get directions")) { toiletDirections(ctx, w) }
                    Spacer(Modifier.width(16.dp))
                    TrenordLink(tr("Vedi su MapComplete", "View on MapComplete")) { openUrl(ctx, w.mapCompleteUrl) }
                }
            }
        }
    }
}

private fun toiletDirections(ctx: android.content.Context, w: Toilet) =
    openUrl(ctx, "https://www.google.com/maps/dir/?api=1&destination=${w.lat},${w.lon}&travelmode=walking")

@SuppressLint("MissingPermission")
private fun lastKnown(ctx: android.content.Context): android.location.Location? = try {
    val lm = ctx.getSystemService(LocationManager::class.java)
    lm?.getProviders(true)?.mapNotNull { p ->
        try {
            lm.getLastKnownLocation(p)
        } catch (e: SecurityException) {
            null
        }
    }?.maxByOrNull { it.time }
} catch (e: Exception) {
    null
}
