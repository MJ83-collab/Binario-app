package com.binario.treni.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.TrainRef
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/**
 * «Treni con più ritardo adesso»: campione preso dai tabelloni di ViaggiaTreno dei principali nodi (partenze delle prossime
 * ore). Non è l'elenco di tutta la rete: i treni che non partono da questi nodi non compaiono.
 */
private object DelayedNow {
    data class Item(val ref: TrainRef, val title: String, val dest: String, val delay: Int, val from: String)

    private val HUBS = listOf(
        "S08409" to "Roma Termini", "S01700" to "Milano Centrale", "S09218" to "Napoli Centrale", "S06421" to "Firenze S.M.N.",
        "S05043" to "Bologna Centrale", "S00219" to "Torino Porta Nuova", "S02593" to "Venezia S. Lucia", "S02430" to "Verona Porta Nuova",
        "S04700" to "Genova Piazza Principe", "S11119" to "Bari Centrale", "S08217" to "Roma Tiburtina", "S01820" to "Milano Rogoredo",
        "S02581" to "Padova", "S09818" to "Salerno",
    )
    @Volatile private var cache: Pair<Long, List<Item>>? = null

    suspend fun load(): List<Item> {
        cache?.let { (at, l) -> if (System.currentTimeMillis() - at < 3 * 60_000L) return l }
        val now = System.currentTimeMillis()
        val rows = coroutineScope {
            HUBS.map { (id, name) ->
                async(Dispatchers.IO) {
                    try {
                        val a = Api.rawBoard("partenze", id, now)
                        (0 until a.length()).mapNotNull { i ->
                            val o = a.optJSONObject(i) ?: return@mapNotNull null
                            val delay = o.optInt("ritardo", 0)
                            val n = o.opt("numeroTreno")?.toString().orEmpty()
                            val org = o.optString("codOrigine")
                            if (delay < 5 || n.isBlank() || org.isBlank()) return@mapNotNull null
                            val title = o.optString("compNumeroTreno").trim().ifBlank { n }
                            val dest = o.optString("destinazione").lowercase().split(" ").joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
                            val ref = TrainRef(n, org, o.optLong("dataPartenzaTreno"), "$n - $dest")
                            Item(ref, title, dest, delay, name)
                        }
                    } catch (_: Exception) {
                        emptyList()
                    }
                }
            }.awaitAll().flatten()
        }
        val out = rows.distinctBy { it.ref.number + "/" + it.ref.originCode }.sortedByDescending { it.delay }.take(8)
        cache = now to out
        return out
    }
}

@Composable
fun DelayedNowCard(onTrain: (TrainRef) -> Unit) {
    var rows by remember { mutableStateOf<List<DelayedNow.Item>?>(null) }
    LaunchedEffect(Unit) { rows = withContext(Dispatchers.IO) { runCatching { DelayedNow.load() }.getOrDefault(emptyList()) } }
    WhiteCard {
        CardTitle(tx("Treni con più ritardo adesso"))
        val r = rows
        if (r == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), color = Green)
        } else if (r.isEmpty()) {
            Text(tx("Nessun ritardo rilevante nei principali nodi, oppure il servizio non risponde."), color = Muted, fontSize = 13.sp,
                modifier = Modifier.padding(16.dp))
        } else {
            r.forEach { x ->
                Row(Modifier.fillMaxWidth().clickable { onTrain(x.ref) }.padding(horizontal = 16.dp, vertical = 7.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(x.title + " → " + x.dest, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(tx("Da") + " " + x.from, color = Muted, fontSize = 12.sp)
                    }
                    Text("+" + x.delay + " min", color = if (x.delay >= 30) androidx.compose.ui.graphics.Color(0xFFC62828) else androidx.compose.ui.graphics.Color(0xFFEF6C00), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            Text(
                tx("Campione dai tabelloni dei principali nodi (partenze delle prossime ore): non è l'elenco di tutta la rete. Fonte: ViaggiaTreno."),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 10.dp),
            )
        }
    }
}
