package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Ferrovie italiane con rete propria (EAV-Circumvesuviana, Cumana, Circumflegrea, ARST, Ferrotramviaria, FAL,
 * Circumetnea, Trentino Trasporti…) tramite Transitous (api.transitous.org): servizio europeo gratuito e comunitario
 * che raccoglie gli orari ufficiali GTFS pubblicati dalle aziende.
 * Gli orari sono di norma PROGRAMMATI: i ritardi compaiono solo se l'azienda pubblica dati in tempo reale.
 * Le stazioni hanno id "TX" + id Transitous (es. "TXit-Campania-EAV_6001" = Napoli Porta Nolana).
 */
object LocalRail {
    private const val BASE = "https://api.transitous.org/api/v1/"
    const val PREFIX = "TX"
    const val SOURCE = "Transitous (orari ufficiali GTFS delle aziende)"
    const val SOURCE_URL = "https://transitous.org"

    /** Modi di trasporto su ferro (niente bus). */
    private val RAIL = setOf("RAIL", "REGIONAL_RAIL", "REGIONAL_FAST_RAIL", "SUBURBAN", "HIGHSPEED_RAIL", "LONG_DISTANCE", "NIGHT_RAIL")

    /** Fonti già coperte da ViaggiaTreno o dall'orario svizzero: le escludiamo per non avere doppioni. */
    private val COVERED = listOf("it-trenitalia", "it-Lombardia-Trenord", "it-Lombardia-ATM", "eu-flixbus", "ch-", "eu-")

    val coords = java.util.concurrent.ConcurrentHashMap<String, Pair<Double, Double>>()
    private val utc = TimeZone.getTimeZone("UTC")

    fun isLocal(id: String) = id.startsWith(PREFIX)
    private fun stopId(id: String) = id.removePrefix(PREFIX)

    private fun get(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("User-Agent", "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)")
            setRequestProperty("Accept-Language", when (I18n.lang) { "it", "de", "fr", "es", "ja", "zh" -> I18n.lang; else -> "en" })
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun JSONObject.str(k: String): String = if (!has(k) || isNull(k)) "" else optString(k)

    private fun parseTime(s: String): Long {
        if (s.isBlank()) return 0L
        return try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = utc }.parse(s)?.time ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    private fun iso(t: Long) = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = utc }.format(Date(t))

    /** "it-Campania-EAV_6001" → "EAV"; "it-Sardegna-ARST_F_22602" → "ARST". */
    private fun feedLabel(id: String): String = id.substringBefore('_').substringAfterLast('-')

    private fun remember(o: JSONObject?) {
        o ?: return
        val id = o.str("stopId").ifBlank { o.str("id") }
        if (id.isBlank() || !o.has("lat")) return
        coords[PREFIX + id] = o.optDouble("lat") to o.optDouble("lon")
    }

    private fun isRail(modes: JSONArray?): Boolean = modes != null && (0 until modes.length()).any { modes.optString(it) in RAIL }

    /** Stazioni delle ferrovie con rete propria che corrispondono al testo cercato. */
    fun searchStations(q: String): List<Station> = try {
        val a = JSONArray(get(BASE + "geocode?type=STOP&language=it&text=" + URLEncoder.encode(q.trim(), "UTF-8")))
        (0 until a.length()).map { a.getJSONObject(it) }
            .filter { o ->
                val id = o.str("id")
                o.str("country") == "IT" && isRail(o.optJSONArray("modes")) && COVERED.none { id.startsWith(it) }
            }
            .map { o -> remember(o); Station(o.str("name") + " (" + feedLabel(o.str("id")) + ")", PREFIX + o.str("id")) }
            .distinctBy { it.name.lowercase() }
            .take(4)
    } catch (e: Exception) {
        emptyList()
    }

    fun coord(id: String): Pair<Double, Double>? = coords[id]

    private fun operatorOf(agency: String): String =
        Railways.match(agency)?.short ?: agency.substringBefore(" -").substringBefore(" srl").substringBefore(" SpA").substringBefore(" S.p.A").trim()

    /** Partenze dei treni dalla stazione (orario programmato; ritardo solo se l'azienda lo pubblica). */
    fun departures(st: Station, time: Long): List<BoardItem> {
        val o = JSONObject(get(BASE + "stoptimes?n=60&stopId=" + URLEncoder.encode(stopId(st.id), "UTF-8") + "&time=" + URLEncoder.encode(iso(time), "UTF-8")))
        remember(o.optJSONObject("place"))
        val a = o.optJSONArray("stopTimes") ?: return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val s = a.getJSONObject(i)
            if (s.str("mode") !in RAIL) return@mapNotNull null
            val p = s.optJSONObject("place") ?: return@mapNotNull null
            val sched = parseTime(p.str("scheduledDeparture")).takeIf { it > 0 } ?: return@mapNotNull null
            val real = parseTime(p.str("departure")).takeIf { it > 0 } ?: sched
            val rt = s.optBoolean("realTime")
            val short = s.str("routeShortName")
            val trip = s.str("tripShortName")
            val track = p.str("track"); val schedTrack = p.str("scheduledTrack").ifBlank { track }
            BoardItem(
                number = trip.ifBlank { short.takeIf { it.length <= 8 } ?: "" },
                category = if (trip.isNotBlank() && short.length <= 6 && short.any { c -> c.isLetter() }) short else "REG",
                otherEnd = s.str("headsign").ifBlank { s.optJSONObject("tripTo")?.str("name").orEmpty() },
                time = sched, delay = if (rt) ((real - sched) / 60_000L).toInt() else 0,
                platform = track.ifBlank { schedTrack }, platformConfirmed = rt && track.isNotBlank(),
                originCode = PREFIX + "|" + s.str("tripId"), departureDate = sched, inStation = false,
                schedPlatform = schedTrack, realPlatform = if (rt) track else "",
                operator = operatorOf(s.str("agencyName")),
            )
        }.distinctBy { it.originCode }
    }

    /** Scheda del treno: tutte le fermate della corsa. */
    fun status(ref: TrainRef): TrainStatus {
        val tripId = ref.originCode.removePrefix("$PREFIX|")
        val o = JSONObject(get(BASE + "trip?tripId=" + URLEncoder.encode(tripId, "UTF-8")))
        val leg = o.optJSONArray("legs")?.optJSONObject(0) ?: throw IOException("Corsa non trovata")
        val now = System.currentTimeMillis()
        val rt = leg.optBoolean("realTime")
        fun stop(p: JSONObject): TrainStop {
            remember(p)
            val sa = parseTime(p.str("scheduledArrival")); val sd = parseTime(p.str("scheduledDeparture"))
            val ra = parseTime(p.str("arrival")).takeIf { it > 0 } ?: sa
            val rd = parseTime(p.str("departure")).takeIf { it > 0 } ?: sd
            val delay = if (rt) (((if (rd > 0) rd - sd else ra - sa)) / 60_000L).toInt() else 0
            val track = p.str("track")
            return TrainStop(p.str("name"), PREFIX + p.str("stopId"), sa, sd,
                if (ra in 1 until now) ra else 0L, if (rd in 1 until now) rd else 0L, delay, track, false, rt && track.isNotBlank(),
                p.str("scheduledTrack").ifBlank { track }, if (rt) track else "")
        }
        val stops = buildList {
            leg.optJSONObject("from")?.let { add(stop(it)) }
            leg.optJSONArray("intermediateStops")?.let { arr -> (0 until arr.length()).forEach { add(stop(arr.getJSONObject(it))) } }
            leg.optJSONObject("to")?.let { add(stop(it)) }
        }
        val short = leg.str("routeShortName")
        return TrainStatus(
            number = ref.number, category = if (short.length <= 6 && short.any { c -> c.isLetter() }) short else "REG",
            origin = leg.optJSONObject("tripFrom")?.str("name") ?: stops.firstOrNull()?.name.orEmpty(),
            destination = leg.str("headsign").ifBlank { stops.lastOrNull()?.name.orEmpty() },
            originCode = ref.originCode, date = stops.firstOrNull()?.schedDep ?: 0L,
            delay = stops.firstOrNull()?.delay ?: 0, lastStation = "", lastTime = 0L,
            cancelled = leg.optBoolean("cancelled"), stops = stops,
            info = (leg.str("routeLongName").takeIf { it.isNotBlank() }?.let { "$it\n" } ?: "") +
                (if (rt) I18n.tr("Tempo reale dall'azienda · ", "Real time from the operator · ") else I18n.tr("Orario programmato: ritardi non pubblicati dall'azienda · ", "Scheduled times: delays not published by the operator · ")) +
                SOURCE,
            operator = operatorOf(leg.str("agencyName")),
        )
    }

    /** Fermata ferroviaria più adatta per una stazione italiana o svizzera (per pianificare viaggi misti). */
    private fun placeFor(st: Station): String? {
        if (isLocal(st.id)) return stopId(st.id)
        val name = st.name.substringBefore(" (").trim()
        return try {
            val a = JSONArray(get(BASE + "geocode?type=STOP&language=it&text=" + URLEncoder.encode(name, "UTF-8")))
            val rail = (0 until a.length()).map { a.getJSONObject(it) }.filter { isRail(it.optJSONArray("modes")) }
            // Le fermate Trenord (anche rete FerrovieNord) hanno lo stesso codice di ViaggiaTreno: "it-Lombardia-Trenord_S01738"
            (rail.firstOrNull { it.str("id").endsWith("_" + st.id) } ?: rail.firstOrNull())?.str("id")
        } catch (e: Exception) {
            null
        }
    }

    /** Soluzioni di viaggio con almeno una ferrovia a rete propria (anche con cambi su Trenitalia/Trenord). */
    fun solutions(from: Station, to: Station, time: Long): List<Solution> {
        val f = placeFor(from) ?: throw IOException(I18n.tr("Stazione di partenza non trovata negli orari regionali", "Departure station not found"))
        val t = placeFor(to) ?: throw IOException(I18n.tr("Stazione di arrivo non trovata negli orari regionali", "Arrival station not found"))
        val o = JSONObject(get(BASE + "plan?numItineraries=6&fromPlace=" + URLEncoder.encode(f, "UTF-8") + "&toPlace=" +
            URLEncoder.encode(t, "UTF-8") + "&time=" + URLEncoder.encode(iso(time), "UTF-8")))
        val its = o.optJSONArray("itineraries") ?: return emptyList()
        return (0 until its.length()).mapNotNull { i ->
            val itin = its.getJSONObject(i)
            val legsArr = itin.optJSONArray("legs") ?: return@mapNotNull null
            val legs = (0 until legsArr.length()).map { k -> legsArr.getJSONObject(k) }.filter { l -> l.str("mode") != "WALK" }.map { l ->
                val op = operatorOf(l.str("agencyName"))
                val short = l.str("routeShortName")
                Leg(
                    number = listOf(op, l.str("tripShortName").ifBlank { short }).filter { s -> s.isNotBlank() }.joinToString(" "),
                    category = if (l.str("mode") == "BUS") "BUS" else "",
                    from = l.optJSONObject("from")?.str("name").orEmpty(), to = l.optJSONObject("to")?.str("name").orEmpty(),
                    dep = parseTime(l.str("startTime")), arr = parseTime(l.str("endTime")),
                    operator = op,
                )
            }
            if (legs.isEmpty()) return@mapNotNull null
            val dep = parseTime(itin.str("startTime")); val arr = parseTime(itin.str("endTime"))
            val min = ((arr - dep) / 60_000L).toInt()
            Solution(from.name, to.name, dep, arr, "${min / 60}h${(min % 60).toString().padStart(2, '0')}", null, legs, "transitous.org")
        }
    }
}
