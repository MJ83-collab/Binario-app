package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n

private fun tr(a: String, b: String) = I18n.tr(a, b)

/**
 * Regole per viaggiare con animali, per impresa. Fonti: pagine ufficiali Trenord, Trenitalia, Italo, FFS
 * (consultate a ottobre 2026). Le promozioni cambiano: per il prezzo esatto vale quello mostrato all'acquisto.
 */
@Composable
fun AnimalsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tr("Viaggiare con animali", "Travelling with pets"), onBack)

        WhiteCard {
            Column(Modifier.padding(16.dp)) {
                Text(tr("In breve", "In short"), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Green)
                Rule("🐱", tr("Animali piccoli (gatti, cani piccoli, conigli, uccelli) nel trasportino: quasi sempre gratis.", "Small animals (cats, small dogs, rabbits, birds) in a carrier: almost always free."))
                Rule("🐕", tr("Cani più grandi: guinzaglio e museruola; spesso serve un biglietto per il cane.", "Larger dogs: leash and muzzle; a dog ticket is often needed."))
                Rule("🦮", tr("Cani guida e cani d'assistenza: sempre gratis, su tutti i treni e in tutte le classi, senza limiti di orario.", "Guide and assistance dogs: always free, on all trains and classes, with no time limits."))
                Rule("📄", tr("Porta sempre il certificato di iscrizione all'anagrafe canina e il libretto sanitario (dall'estero: passaporto europeo per animali).", "Always carry the dog-registry certificate and health booklet (from abroad: EU pet passport)."))
                Rule("🚫", tr("L'animale non deve occupare posti a sedere né disturbare: il personale può farlo scendere se crea pericolo o disturbo.", "The animal must not take up seats or disturb others: staff may ask you to leave if it causes danger or disturbance."))
            }
        }

        OperatorCard("Trenord", listOf(
            tr("Animali piccoli nel trasportino (massimo 70×30×50 cm): gratis in Lombardia.", "Small animals in a carrier (max 70×30×50 cm): free within Lombardy."),
            tr("Cani di qualsiasi taglia: museruola, guinzaglio e certificato dell'anagrafe canina; gratis in Lombardia.", "Dogs of any size: muzzle, leash and dog-registry certificate; free within Lombardy."),
            tr("Fasce vietate nei giorni feriali (lunedì–venerdì): 7:00–9:30 e 17:30–19:30, anche per gli animali piccoli. I cani guida possono viaggiare sempre.", "Not allowed on weekdays (Monday–Friday) 7:00–9:30 and 17:30–19:30, small animals included. Guide dogs can always travel."),
            tr("Fuori dalla Lombardia e verso la Svizzera serve il supplemento animali, secondo le regole dell'impresa che fa il servizio.", "Beyond Lombardy and to Switzerland an animal supplement is needed, under the rules of the operating company."),
            tr("Malpensa Express: il cane viaggia gratis come bagaglio con la carta d'imbarco; senza carta d'imbarco paga il supplemento animali.", "Malpensa Express: dogs travel free as luggage with a boarding pass; without one they pay the animal supplement."),
        ), "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/trasporto-animali/") { openUrl(ctx, it) }

        OperatorCard("Trenitalia", listOf(
            tr("Animali piccoli nel trasportino (massimo 70×30×50 cm): sempre gratis, su tutti i treni.", "Small animals in a carrier (max 70×30×50 cm): always free, on all trains."),
            tr("Regionali: i cani di taglia più grande viaggiano con un biglietto di 2ª classe scontato del 50%, con guinzaglio e museruola.", "Regional trains: larger dogs travel with a 2nd-class ticket at 50% off, with leash and muzzle."),
            tr("Frecce e Intercity: il cane fuori dal trasportino va aggiunto all'acquisto (\"Viaggia con il tuo cane\"); il prezzo è quello mostrato in fase d'acquisto e in alcuni periodi ci sono promozioni (es. cani gratis d'estate).", "Frecce and Intercity: a dog outside the carrier must be added when buying (\"Travel with your dog\"); the price is the one shown at checkout, with promotions in some periods (e.g. dogs free in summer)."),
            tr("Documenti: certificato dell'anagrafe canina e libretto sanitario; il personale può chiederli. I cani d'assistenza ammessi anche nelle carrozze bar/ristorante e sui bus sostitutivi.", "Documents: dog-registry certificate and health booklet; staff may ask for them. Assistance dogs are also allowed in bar/restaurant cars and replacement buses."),
        ), "https://www.trenitalia.com/it/servizi/trasporto-animali-domestici.html") { openUrl(ctx, it) }

        OperatorCard("Italo", listOf(
            tr("Animali piccoli (fino a circa 5 kg) nel trasportino: gratis.", "Small animals (up to about 5 kg) in a carrier: free."),
            tr("Cani più grandi: ammessi in Smart e Prima con prenotazione del servizio \"Cane\" (online o Pronto Italo 06 07 08, fino a 2 ore prima); guinzaglio sempre e museruola a salita e discesa o su richiesta. Prezzo mostrato all'acquisto.", "Larger dogs: allowed in Smart and Prima by booking the \"Dog\" service (online or Pronto Italo 06 07 08, up to 2 hours before); always on a leash, muzzle when boarding/leaving or on request. Price shown at checkout."),
            tr("Cani guida: gratis, di qualsiasi taglia.", "Guide dogs: free, any size."),
        ), "https://blog.italotreno.com/idee-di-viaggio/viaggiare-in-treno-con-il-cane/") { openUrl(ctx, it) }

        OperatorCard(tr("Svizzera · FFS e TILO", "Switzerland · SBB and TILO"), listOf(
            tr("Cani fino a 30 cm al garrese e altri piccoli animali in borsa o trasportino: gratis, come bagaglio a mano.", "Dogs up to 30 cm at the withers and other small animals in a bag or carrier: free, as hand luggage."),
            tr("Cani più grandi (o fuori dal trasportino): metà prezzo di 2ª classe, oppure carta giornaliera per cani CHF 25 (vale anche su bus, tram e battelli); abbonamento cani CHF 60 al mese o CHF 350 all'anno.", "Larger dogs (or outside a carrier): half the 2nd-class fare, or the dog day pass CHF 25 (also valid on buses, trams and boats); dog pass CHF 60 a month or CHF 350 a year."),
            tr("Il cane sta sotto il tuo sedile, senza bloccare il passaggio. Non ammessi nelle carrozze ristorante (tranne cani guida e d'assistenza).", "The dog stays under your seat without blocking the aisle. Not allowed in restaurant cars (except guide and assistance dogs)."),
        ), "https://www.sbb.ch/it/informazioni-viaggio/esigenze-individuali/viaggiare-cane.html") { openUrl(ctx, it) }

        Text(tr("Regole dalle pagine ufficiali delle imprese (ottobre 2026). Prezzi e promozioni cambiano: prima di partire controlla la pagina dell'impresa con il tasto qui sopra.",
            "Rules from the operators' official pages (October 2026). Prices and promotions change: before travelling check the operator's page with the button above."),
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
    }
}

@Composable
private fun Rule(icon: String, text: String) {
    Row(Modifier.padding(top = 6.dp)) {
        Text(icon, fontSize = 18.sp, modifier = Modifier.width(30.dp))
        Text(text, fontSize = 14.sp)
    }
}

@Composable
private fun OperatorCard(name: String, rules: List<String>, url: String, open: (String) -> Unit) {
    WhiteCard {
        CardTitle(name)
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 4.dp)) {
            rules.forEach { r -> Text("• $r", fontSize = 14.sp, modifier = Modifier.padding(vertical = 3.dp)) }
        }
        TextButton({ open(url) }, Modifier.padding(start = 8.dp, bottom = 6.dp)) {
            Text(tr("Pagina ufficiale ", "Official page ") + name, color = Green)
        }
    }
}
