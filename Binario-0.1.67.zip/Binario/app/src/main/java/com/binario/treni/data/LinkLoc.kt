package com.binario.treni.data

/**
 * Apre le pagine ufficiali nella lingua dell'app, quando l'azienda ha la stessa pagina in quella lingua.
 * Gli indirizzi tradotti sono quelli che le pagine stesse dichiarano come «alternate» (hreflang), verificati il 04/11/2026.
 * Se la pagina non esiste nella lingua scelta si usa l'inglese (cinese, giapponese, spagnolo) o, in mancanza, l'originale.
 */
object LinkLoc {
    /** Pagina italiana → [tedesco, francese, inglese]; null = non disponibile. */
    private val MAP: Map<String, Array<String?>> = mapOf(
        "https://www.sbb.ch/it" to arrayOf<String?>("https://www.sbb.ch/de", "https://www.sbb.ch/fr", "https://www.sbb.ch/en"),
        "https://www.sbb.ch/it/biglietti-offerte/acquistare.html" to arrayOf<String?>("https://www.sbb.ch/de/billette-angebote/kaufen.html", "https://www.sbb.ch/fr/billets-offres/acheter.html", "https://www.sbb.ch/en/tickets-offers/buy.html"),
        "https://www.sbb.ch/it/informazioni-viaggio/esigenze-individuali/viaggiare-cane.html" to arrayOf<String?>("https://www.sbb.ch/de/reiseinformationen/individuelle-beduerfnisse/reisen-mit-hund.html", "https://www.sbb.ch/fr/informations-voyages/besoins-individuels/voyager-avec-chien.html", "https://www.sbb.ch/en/travel-information/individual-needs/travelling-with-dogs.html"),
        "https://www.sbb.ch/it/informazioni-viaggio/esigenze-individuali/viaggiare-con-bambini/biglietti-abbonamenti.html" to arrayOf<String?>("https://www.sbb.ch/de/reiseinformationen/individuelle-beduerfnisse/reisen-mit-kindern/billette-abos.html", "https://www.sbb.ch/fr/informations-voyages/besoins-individuels/voyager-avec-enfants/billets-abonnements.html", "https://www.sbb.ch/en/travel-information/individual-needs/travelling-with-children/tickets-travelcards.html"),
        "https://www.sbb.ch/it/informazioni-viaggio/esigenze-individuali/viaggiare-mobilita-ridotta/contact-center-handicap.html" to arrayOf<String?>("https://www.sbb.ch/de/reiseinformationen/individuelle-beduerfnisse/reisen-eingeschraenkte-mobilitaet/contact-center-handicap.html", "https://www.sbb.ch/fr/informations-voyages/besoins-individuels/voyager-mobilite-reduite/contact-center-handicap.html", "https://www.sbb.ch/en/travel-information/individual-needs/travelling-reduced-mobility/contact-center-handicap.html"),
        "https://www.sbb.ch/it/informazioni-viaggio/stazioni/trova-stazione.html" to arrayOf<String?>("https://www.sbb.ch/de/reiseinformationen/bahnhoefe/bahnhof-finden.html", "https://www.sbb.ch/fr/informations-voyages/gares/trouver-gare.html", "https://www.sbb.ch/en/travel-information/stations/find-station.html"),
        "https://www.sbb.ch/it/pianificare/informazioni-traffico-ferroviario" to arrayOf<String?>("https://www.sbb.ch/de/planen/bahnverkehrsinfo", "https://www.sbb.ch/fr/planifier/information-trafic-ferroviaire", "https://www.sbb.ch/en/plan/rail-traffic-information"),
        "https://www.sbb.ch/it/offerte/condizioni.html" to arrayOf<String?>("https://www.sbb.ch/de/angebote/konditionen", "https://www.sbb.ch/fr/offres/conditions", "https://www.sbb.ch/en/offers/conditions"),
        "https://www.italotreno.com/it" to arrayOf<String?>(null, null, "https://www.italotreno.com/en/"),
        "https://www.italotreno.com/it/contatti-supporto" to arrayOf<String?>(null, null, "https://www.italotreno.com/en/support-contacts"),
        "https://www.italotreno.com/it/contatti-supporto/assistenza-persone-mobilita-ridotta" to arrayOf<String?>(null, null, "https://www.italotreno.com/en/support-contacts/Assistance-passengers-reduced-mobility"),
        "https://www.italotreno.com/it/il-treno/tariffe" to arrayOf<String?>(null, null, "https://www.italotreno.com/en/the-train/fares"),
        "https://www.italotreno.com/it/offerte-treno/bambini-gratis" to arrayOf<String?>(null, null, "https://www.italotreno.com/en/train-offers/free-child-train-tickets"),
        "https://www.italotreno.com/it/offerte-treno/italo-senior" to arrayOf<String?>(null, null, "https://www.italotreno.com/en/train-offers/italo-senior"),
        "https://www.italotreno.com/it/termini-condizioni" to arrayOf<String?>(null, null, "https://www.italotreno.com/en/terms-conditions"),
        "https://www.oebb.at/de/fragen-und-antworten/kundenkarten/vorteilscard/alle-vorteilscards" to arrayOf<String?>(null, null, "https://www.oebb.at/en/fragen-und-antworten/kundenkarten/vorteilscard/alle-vorteilscards"),
        "https://www.oebb.at/de/tickets-kundenkarten" to arrayOf<String?>(null, null, "https://www.oebb.at/en/tickets-kundenkarten"),
        "https://www.suedtirolmobil.info/it/ticket/condizioni-di-trasporto" to arrayOf<String?>("https://www.suedtirolmobil.info/de/tickets/befoerderungsbedingungen", null, "https://www.suedtirolmobil.info/en/tickets/conditions-of-carriage"),
        "https://www.suedtirolmobil.info/it/ticket/punti-vendita/punti-vendita-altoadigemobilita" to arrayOf<String?>("https://www.suedtirolmobil.info/de/tickets/verkaufsstellen/suedtirolmobil-verkaufsstellen", null, "https://www.suedtirolmobil.info/en/tickets/where-to-buy-tickets/suedtirolmobil-ticket-offices"),
        "https://www.suedtirolmobil.info/it/ticket/sistema-ticketing-e-convalida-dei-biglietti" to arrayOf<String?>("https://www.suedtirolmobil.info/de/tickets/ticketing-system-und-fahrschein-entwertung", null, "https://www.suedtirolmobil.info/en/tickets/ticketing-system-and-ticket-validation"),
        "https://www.trentinotrasporti.it/it/tariffe" to arrayOf<String?>("https://www.trentinotrasporti.it/de/preise", null, "https://www.trentinotrasporti.it/en/rates"),
    )

    fun url(url: String): String {
        if (I18n.lang == "it") return url
        val base = url.substringBefore('?').substringBefore('#').trimEnd('/')
        val tail = url.removePrefix(url.substringBefore('?').substringBefore('#'))
        val v = MAP[base] ?: MAP[base + "/"] ?: MAP[url.substringBefore('#')] ?: return url
        val pick = when (I18n.lang) {
            "de" -> v[0] ?: v[2]
            "fr" -> v[1] ?: v[2]
            else -> v[2]
        } ?: return url
        return pick + (if (pick.contains('?')) "" else if (tail.startsWith("?")) tail.substringBefore('#') else "")
    }
}
