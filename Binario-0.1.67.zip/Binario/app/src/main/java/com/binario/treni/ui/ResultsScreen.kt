package com.binario.treni.ui

import com.binario.treni.data.tx
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.ChangeRisk
import com.binario.treni.data.Fmt
import com.binario.treni.data.Leg
import com.binario.treni.data.Reminder
import com.binario.treni.data.Solution
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.Tratta
import com.binario.treni.service.Reminders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ResultsScreen(vm: MainViewModel, onBack: () -> Unit, onTrain: (TrainRef) -> Unit, onStation: (com.binario.treni.data.Station) -> Unit = {}, onPrices: () -> Unit = {}) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val f0 = vm.from
    val t0 = vm.to
    val tratta = if (f0 != null && t0 != null) Tratta(f0, t0) else null
    var fav by remember { mutableStateOf(tratta?.let { vm.store.isFavRoute(it) } ?: false) }
    val offline = vm.offlineTitle != null
    // Ordine dei risultati: partenza, prezzo (i senza prezzo in fondo) o durata
    var sort by remember { mutableIntStateOf(0) }
    val all = if (tab == 0) vm.results else vm.returnResults
    // Solo treni (predefinito): le soluzioni con metropolitana, tram o bus si mostrano solo se l'utente lo sceglie
    var onlyTrains by remember { mutableStateOf(vm.store.onlyTrains) }
    val trainsOnly = all.filter { s -> s.legs.all { it.isTrain } }
    val hiddenCount = all.size - trainsOnly.size
    // Se senza metro/bus non resta nessuna soluzione (es. linea interrotta con bus sostitutivo) si mostrano tutte
    val noTrainOnly = onlyTrains && trainsOnly.isEmpty() && all.isNotEmpty()
    val raw = if (onlyTrains && !noTrainOnly) trainsOnly else all
    val list = when (sort) {
        1 -> raw.sortedWith(compareBy<Solution> { PricePrefs.of(it) == null }.thenBy { PricePrefs.of(it) ?: 0.0 }.thenBy { it.dep })
        2 -> raw.sortedWith(compareBy<Solution> { it.arr - it.dep }.thenBy { it.dep })
        else -> raw
    }
    var pdf by remember { mutableStateOf(false) }
    PricePrefs.load(vm.store)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(if (offline) tx("Salvato offline") else tx("Soluzioni"), onBack) {
            if (!offline) IconButton({ vm.search() }) { Icon(Icons.Filled.Refresh, tx("Aggiorna")) }
            if (!offline && tratta != null) {
                IconButton({ fav = vm.store.toggleFavRoute(tratta) }) {
                    Icon(if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder, tx("Preferito"))
                }
            }
            val share = BarAction(Icons.Filled.Share, tx("Condividi orari")) {
                val text = buildString {
                    append(vm.offlineTitle ?: tratta?.label ?: "").append("\n")
                    list.take(8).forEach { s -> append(solutionLine(s)).append("\n") }
                }
                shareText(ctx, text)
            }
            BarOverflow(
                if (!offline && tratta != null) listOf(
                    BarAction(Icons.Filled.CalendarMonth, tx("Prezzi migliori per giorno e fascia oraria"), onPrices),
                    BarAction(Icons.Filled.PictureAsPdf, tx("Scarica l'orario del giorno in PDF")) { pdf = true },
                    BarAction(Icons.Filled.DownloadForOffline, tx("Salva offline")) {
                        toast(ctx, if (vm.saveOffline()) tx("Orari salvati per la consultazione offline") else tx("Niente da salvare"))
                    },
                    share,
                ) else listOf(share),
            )
        }
        if (vm.roundTrip && !offline) GreenTabs(listOf(tx("Andata"), tx("Ritorno")), tab) { tab = it }
        // Senza rete: si mostrano gli ultimi orari scaricati per questa tratta
        vm.staleNote?.let { n ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CloudOff, null, tint = Color(0xFFEF6C00), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(n, color = Color(0xFFEF6C00), fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton({ vm.search() }) { Text(tx("Riprova"), color = Green) }
            }
        }
        if (pdf && tratta != null) PdfTimetableDialog(tratta.from, tratta.to, vm.date, vm.store) { pdf = false }
        PullRefresh(vm.loading, { if (!offline) vm.search() }) { when {
            vm.loading -> LoadingBox()
            list.isEmpty() -> PullableMessage(vm.error ?: tx("Nessuna soluzione"))
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 6.dp)) {
                item {
                    Text(
                        (vm.offlineTitle ?: Fmt.dayLong(list.first().dep)) + (if (offline) "" else " · " + vm.filter.label) +
                            (if (!offline && !vm.pax.isSingle) " · 👤 " + paxLabel(vm.pax) else ""),
                        color = Muted, modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 4.dp),
                    )
                    Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tx("Ordina:"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(end = 6.dp))
                        listOf(tx("Partenza"), tx("Prezzo"), tx("Durata")).forEachIndexed { i, l ->
                            FilterChip(sort == i, { sort = i }, label = { Text(l, fontSize = 13.sp) }, modifier = Modifier.padding(end = 6.dp))
                        }
                    }
                    Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tx("Mezzi:"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(end = 6.dp))
                        FilterChip(onlyTrains, { onlyTrains = true; vm.store.onlyTrains = true },
                            label = { Text(tx("Solo treni"), fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Filled.Train, null, modifier = Modifier.size(16.dp)) }, modifier = Modifier.padding(end = 6.dp))
                        FilterChip(!onlyTrains, { onlyTrains = false; vm.store.onlyTrains = false },
                            label = { Text(tx("Anche metro e bus"), fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Filled.DirectionsSubway, null, modifier = Modifier.size(16.dp)) })
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tx("Prezzi:"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(end = 6.dp))
                        FilterChip(!PricePrefs.first, { PricePrefs.first = false; vm.store.priceFirst = false },
                            label = { Text(tx("2ª classe"), fontSize = 13.sp) }, modifier = Modifier.padding(end = 6.dp))
                        FilterChip(PricePrefs.first, { PricePrefs.first = true; vm.store.priceFirst = true },
                            label = { Text(tx("1ª classe"), fontSize = 13.sp) }, modifier = Modifier.padding(end = 10.dp))
                        FilterChip(!PricePrefs.chf, { PricePrefs.chf = false; vm.store.priceChf = false },
                            label = { Text("€", fontSize = 13.sp) }, modifier = Modifier.padding(end = 6.dp))
                        FilterChip(PricePrefs.chf, { PricePrefs.chf = true; vm.store.priceChf = true },
                            label = { Text("CHF", fontSize = 13.sp) })
                    }
                    if (PricePrefs.first && list.any { it.priceFirst != null && it.source == "sbb.ch" }) Text(tx("1ª classe stimata: verifica su sbb.ch"),
                        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                    if (PricePrefs.first && list.any { it.price != null && it.priceFirst == null }) Text(tx("Dove la 1ª classe non c'è (es. molti regionali) è indicato il prezzo di 2ª."),
                        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                    when {
                        noTrainOnly -> Text(tx("Per questo orario non ci sono soluzioni solo in treno: sono mostrate anche quelle con metro o bus."),
                            color = Color(0xFFEF6C00), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                        onlyTrains && hiddenCount > 0 -> Text(
                            tx("Nascoste") + " $hiddenCount " + tx("soluzioni con metro o bus"), color = Muted, fontSize = 13.sp,
                            modifier = Modifier.clickable { onlyTrains = false; vm.store.onlyTrains = false }.padding(horizontal = 16.dp, vertical = 4.dp),
                        )
                    }
                }
                if (!offline && list.size >= 2) item { WhenToLeaveCard(list) }
                items(list) { s ->
                    SolutionCard(vm, s, onTrain, onStation) { old, new ->
                        // La soluzione ricalcolata prende il posto di quella con il cambio rischioso
                        if (tab == 0) vm.results = vm.results.map { if (it === old) new else it }
                        else vm.returnResults = vm.returnResults.map { if (it === old) new else it }
                    }
                }
                if (!offline) item {
                    Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                        if (vm.loadingMore) CircularProgressIndicator(color = Green)
                        else OutlinedButton({ vm.loadMore(tab == 1) }) { Text(tx("Soluzioni successive"), color = Green) }
                    }
                }
            }
        } }
    }
}

private fun solutionLine(s: Solution) =
    "${Fmt.time(s.dep)} → ${Fmt.time(s.arr)}  ${s.legs.joinToString(" + ") { it.title }}  ${PricePrefs.text(s)}".trim()

/** Dati in tempo reale di un treno della soluzione (ritardo e binari). */
private data class LegLive(
    val delay: Int, val depSched: String, val depReal: String, val arrSched: String, val arrReal: String,
    val ref: TrainRef, val cancelled: Boolean,
)

private fun liveFor(leg: Leg, st: TrainStatus): LegLive {
    val a = st.stops.firstOrNull { it.name.equals(leg.from, true) }
    val b = st.stops.firstOrNull { it.name.equals(leg.to, true) }
    return LegLive(st.delay, a?.schedPlatform ?: "", a?.realPlatform ?: "", b?.schedPlatform ?: "", b?.realPlatform ?: "", st.ref, st.cancelled)
}

@Composable
private fun SolutionCard(
    vm: MainViewModel, s: Solution, onTrain: (TrainRef) -> Unit, onStation: (com.binario.treni.data.Station) -> Unit = {},
    onReplace: (Solution, Solution) -> Unit = { _, _ -> },
) {
    val ctx = LocalContext.current
    // Indice del treno dopo il cambio per cui si cercano alternative (null = finestra chiusa)
    var altFor by remember(s) { mutableStateOf<Int?>(null) }
    var menu by remember { mutableStateOf(false) }
    var reminder by remember { mutableStateOf(false) }
    var faresOpen by remember(s) { mutableStateOf(false) }
    val live = remember(s) { mutableStateMapOf<Int, LegLive>() }

    // Ritardi e binari reali solo per i treni vicini all'orario attuale
    LaunchedEffect(s) {
        val now = System.currentTimeMillis()
        if (s.dep in (now - 3 * 3600_000L)..(now + 4 * 3600_000L)) {
            s.legs.take(3).forEachIndexed { i, l ->
                try {
                    val st = withContext(Dispatchers.IO) { Api.status(legRef(l)) }
                    live[i] = liveFor(l.withEnds(s, i), st)
                } catch (_: Exception) {
                }
            }
        }
    }

    val scope = rememberCoroutineScope()
    // Tocco sul nome di una stazione: apre il tabellone partenze e arrivi (cerca la stazione per nome se serve)
    fun openStation(name: String) {
        if (name.isBlank()) return
        listOfNotNull(vm.from, vm.to).firstOrNull { it.name.equals(name, true) }?.let { onStation(it); return }
        scope.launch {
            // I nomi delle soluzioni non sempre coincidono con quelli di ViaggiaTreno ("Rho Fiera Milano", "REPUBBLICA" della metro…)
            val st = withContext(Dispatchers.IO) { runCatching { Api.resolveStation(name, vm.from?.name.orEmpty()) }.getOrNull() }
            when {
                st != null -> onStation(st)
                // Fermata solo di metropolitana, tram o bus: niente tabellone dei treni, la si apre sulla mappa
                else -> {
                    toast(ctx, tx("Non è una stazione ferroviaria: la apro sulla mappa"))
                    openUrl(ctx, "https://www.google.com/maps/search/?api=1&query=" + java.net.URLEncoder.encode(name, "UTF-8"))
                }
            }
        }
    }

    WhiteCard {
        Column(Modifier.padding(start = 14.dp, end = 6.dp, top = 10.dp)) {
            s.legs.forEachIndexed { i, raw ->
                val l = raw.withEnds(s, i)
                val lv = live[i]
                // Tempo per il cambio (come Trainline): tiene conto del ritardo attuale del treno precedente
                if (i > 0) {
                    val prev = s.legs[i - 1].withEnds(s, i - 1)
                    if (prev.arr > 0 && l.dep > 0) {
                        val prevDelay = live[i - 1]?.delay?.coerceAtLeast(0) ?: 0
                        val planned = ((l.dep - prev.arr) / 60_000L).toInt()
                        val real = planned - prevDelay
                        // Tempo consigliato per questo cambio (stazione grande, regionale → Freccia/Italo, cambio di stazione)
                        val need = ChangeRisk.needed(prev, l)
                        val level = ChangeRisk.level(real, need)
                        val at = if (l.from.isNotBlank()) " " + tx("a") + " ${l.from}" else ""
                        val (txt, col) = when (level) {
                            ChangeRisk.Level.MISSED -> (if (prevDelay > 0) tx("Coincidenza a rischio: il treno precedente ha") + " $prevDelay " + tx("min di ritardo")
                                else tx("Cambio rischioso") + ": $real min$at") to LateRed
                            ChangeRisk.Level.RISKY -> (tx("Cambio rischioso") + ": $real min$at") to LateRed
                            ChangeRisk.Level.TIGHT -> (tx("Cambio stretto") + ": $real min$at") to Color(0xFFEF6C00)
                            ChangeRisk.Level.OK -> (tx("Cambio") + ": $real min$at" +
                                (if (prevDelay > 0) " (" + tx("previsti") + " $planned)" else "")) to Muted
                        }
                        Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (level == ChangeRisk.Level.OK) Icons.Filled.TransferWithinAStation else Icons.Filled.Warning, null, tint = col, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(txt, color = col, fontSize = 13.sp, fontWeight = if (col == Muted) FontWeight.Normal else FontWeight.Bold)
                        }
                        // Cambio a rischio: si propone di ricalcolare con i treni successivi da questa stazione
                        if (level != ChangeRisk.Level.OK) Column(Modifier.padding(start = 26.dp, end = 8.dp)) {
                            Text(tx("Per questo cambio sono consigliati almeno") + " $need min: " + tx("con un piccolo ritardo potresti perdere la coincidenza."),
                                color = Muted, fontSize = 12.sp)
                            TextButton({ altFor = i }, contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)) {
                                Icon(Icons.Filled.Refresh, null, tint = Green, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tx("Trova un'alternativa con treni successivi"), color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TrainTitle(l.category, l.number, 17, operator = l.operatorLabel) { onTrain(lv?.ref ?: legRef(l)) }
                    Spacer(Modifier.width(8.dp))
                    CrowdBadge(com.binario.treni.data.Crowd.estimate(l.dep, l.category, s.from, s.to))
                    Spacer(Modifier.weight(1f))
                    if (i == 0) Box {
                        IconButton({ menu = true }, Modifier.size(32.dp)) { Icon(Icons.Filled.MoreVert, tx("Altro"), tint = Muted) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text(tx("Condividi")) }, { menu = false; shareText(ctx, "${s.from} → ${s.to}\n" + solutionLine(s)) })
                            DropdownMenuItem({ Text(tx("Aggiungi al calendario")) }, {
                                menu = false
                                addToCalendar(ctx, com.binario.treni.data.I18n.tr("Treno ", "Train ") + s.legs.joinToString(" + ") { it.title }, s.dep, s.arr, s.from, "${s.from} → ${s.to}")
                            })
                            DropdownMenuItem({ Text(tx("Avvisami (notifica programmata)")) }, { menu = false; reminder = true })
                        }
                    }
                }
                Row(Modifier.padding(end = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        StopLine(true, l.dep, l.from, lv?.depSched ?: "", lv?.depReal ?: "") { openStation(l.from) }
                        StopLine(false, l.arr, l.to, lv?.arrSched ?: "", lv?.arrReal ?: "") { openStation(l.to) }
                    }
                    Box(Modifier.width(56.dp), contentAlignment = Alignment.Center) {
                        if (lv != null) DelayBadge(lv.delay, lv.cancelled, showZero = true)
                    }
                }
            }
        }
        HorizontalDivider(color = Color(0x14000000))
        if (faresOpen) FaresTable(s.fares)
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (s.status.equals("INHIBITED", true)) {
                        Text(tx("Esaurito"), color = LateRed, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Spacer(Modifier.width(14.dp))
                    } else if (s.price != null) {
                        Text((if (s.fares.size == 1 && s.fares[0].offers.size > 1) tx("da") + " " else "") + PricePrefs.text(s), fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        if (s.priceFirst != null || PricePrefs.first) Text(" " + (if (PricePrefs.first && s.priceFirst != null) "1ª" else "2ª"), color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.width(14.dp))
                    }
                    Icon(Icons.Outlined.Timer, null, tint = Color(0xFF555555), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(s.duration.ifBlank { Fmt.duration(s.dep, s.arr) }, fontSize = 16.sp)
                }
                if (s.changes > 0) Row {
                    Text(com.binario.treni.data.I18n.tr5(
                        "${s.changes} camb${if (s.changes == 1) "io" else "i"}",
                        "${s.changes} change${if (s.changes == 1) "" else "s"}",
                        "${s.changes} 次换乘",
                        "${s.changes} Umstieg${if (s.changes == 1) "" else "e"}",
                        "${s.changes} changement${if (s.changes == 1) "" else "s"}",
                    ), color = Muted, fontSize = 14.sp)
                }
                Text(
                    if (s.source == "bahn.de") (if (com.binario.treni.data.GermanyLive.deutschlandTicketOk(s))
                        "✓ " + tx("Valido con il Deutschlandticket") + " (" + com.binario.treni.data.GermanyLive.deutschlandTicketPrice() + tx("/mese") + ") · bahn.de"
                    else tx("Prezzo e biglietti su bahn.de (Sparpreis legati al treno)"))
                    else if (s.source == "transitous") tx("Prezzi e biglietti sui siti delle compagnie (ÖBB, SNCF) o su bahn.de")
                    else if (s.source == "italotreno.com" && s.legs.any { !it.category.uppercase().startsWith("ITA") })
                        tx("Due biglietti: Italo su italotreno.com, l'altro treno su trenitalia.com o trenord.it")
                    else if (s.source == "italotreno.com") tx("Prezzo e acquisto su italotreno.com")
                    else if (s.source == "sbb.ch") (if (s.price != null) "sbb.ch · Arcobaleno" else tx("Prezzo con cambio: verifica su sbb.ch o Trainline"))
                    else buySource(s.legs.firstOrNull()?.category ?: ""),
                    color = Green, fontSize = 14.sp,
                )
                if (s.fares.any { it.offers.size > 1 }) TextButton({ faresOpen = !faresOpen }, contentPadding = PaddingValues(0.dp)) {
                    Text(if (faresOpen) tx("Nascondi le tariffe") else tx("Tutte le tariffe e classi"), color = Green, fontSize = 14.sp)
                }
            }
            IconButton({ shareText(ctx, "${s.from} → ${s.to}\n" + solutionLine(s)) }) { Icon(Icons.Filled.Share, tx("Condividi"), tint = Color(0xFF555555)) }
            if (vm.store.showBuy) IconButton({
                // Germania: ricerca su bahn.de già compilata con stazioni e orario
                if (s.source == "bahn.de" || s.source == "transitous") openUrl(ctx, com.binario.treni.data.GermanyLive.bahnUrl(s.from, s.to, s.dep))
                else openUrl(ctx, buyUrl(s.legs.firstOrNull { it.category.uppercase().startsWith("ITA") }?.category ?: s.legs.firstOrNull()?.category ?: ""))
            }) {
                Icon(Icons.Filled.ShoppingCart, tx("Acquista"), tint = Color(0xFF555555))
            }
        }
    }

    altFor?.let { idx ->
        if (idx in 1 until s.legs.size) AltChangeDialog(vm, s, idx, onDismiss = { altFor = null }) { alt -> altFor = null; onReplace(s, alt) }
    }

    if (reminder) {
        ReminderDialog({ reminder = false }) { min, arrival ->
            val leg = if (arrival) s.legs.lastOrNull() else s.legs.firstOrNull()
            val ev = if (arrival) s.arr else s.dep
            val at = ev - min * 60_000L
            if (leg == null || at < System.currentTimeMillis()) {
                toast(ctx, tx("Orario già passato"))
            } else {
                Reminders.add(
                    ctx,
                    Reminder((System.currentTimeMillis() % 1_000_000).toInt(), leg.number, "", at, ev, "${leg.title} ${s.from} → ${s.to}", arrival),
                )
                toast(ctx, com.binario.treni.data.I18n.tr("Ti avviserò alle ", "I'll remind you at ") + Fmt.time(at))
            }
            reminder = false
        }
    }
}

/** Completa una tratta senza dettagli con gli estremi della soluzione. */
private fun Leg.withEnds(s: Solution, i: Int): Leg {
    if (from.isNotBlank()) return this
    val first = i == 0
    val last = i == s.legs.size - 1
    return copy(
        from = if (first) s.from else "",
        to = if (last) s.to else "",
        dep = if (first) s.dep else 0L,
        arr = if (last) s.arr else 0L,
    )
}

@Composable
private fun StopLine(departure: Boolean, time: Long, name: String, schedPlat: String, realPlat: String, onClick: () -> Unit = {}) {
    if (name.isBlank() && time <= 0) return
    Row(
        Modifier.clip(RoundedCornerShape(4.dp)).clickable(enabled = name.isNotBlank(), onClickLabel = tx("Tabellone partenze e arrivi"), onClick = onClick)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (departure) Icons.Filled.RadioButtonChecked else Icons.Outlined.RadioButtonUnchecked, null,
            tint = Color(0xFF616161), modifier = Modifier.size(16.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(Fmt.time(time), fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.width(8.dp))
        Text(name, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            textDecoration = if (name.isNotBlank()) androidx.compose.ui.text.style.TextDecoration.Underline else null)
        PlatformPair(schedPlat, realPlat, compact = true)
    }
}

/** Classe e valuta dei prezzi scelte dall'utente (predefinito: 2ª classe, euro). */
object PricePrefs {
    var first by mutableStateOf(false)
    var chf by mutableStateOf(false)
    private var loaded = false

    fun load(st: com.binario.treni.data.Store) {
        if (loaded) return
        first = st.priceFirst; chf = st.priceChf; loaded = true
    }

    /** Prezzo in euro secondo la classe scelta; con la 1ª classe senza dato resta il prezzo normale. */
    fun of(s: Solution): Double? = if (first) s.priceFirst ?: s.price else s.price

    /** Il prezzo è una stima (1ª classe stimata, oppure conversione in franchi di un prezzo in euro). */
    fun approx(s: Solution): Boolean = (first && s.priceFirst != null && s.source == "sbb.ch") || (chf && s.source != "sbb.ch")

    fun money(eur: Double?, approx: Boolean): String {
        if (eur == null) return ""
        val body = if (chf) String.format(java.util.Locale.ITALY, "CHF %.2f", eur / com.binario.treni.data.CrossBorderFares.EUR_PER_CHF)
        else Fmt.price(eur)
        return if (approx) "≈ $body" else body
    }

    fun text(s: Solution): String = money(of(s), approx(s))
}

/** Treno della soluzione: i treni Italo hanno la loro fonte in tempo reale. */
private fun legRef(l: Leg): TrainRef =
    if (l.category.uppercase().startsWith("ITA")) TrainRef(Api.trainDigits(l.number), com.binario.treni.data.ItaloLive.PREFIX + "|" + Api.trainDigits(l.number), Fmt.midnight(), l.title)
    else TrainRef(l.number, label = l.title)

/** Tutte le tariffe per classe/livello di servizio, per ogni treno, con i posti rimasti e le esaurite. */
@Composable
private fun FaresTable(fares: List<com.binario.treni.data.FareGrid>) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
        fares.forEach { g ->
            if (fares.size > 1 && g.train.isNotBlank()) Text(g.train, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
            g.offers.groupBy { it.service }.forEach { (service, offers) ->
                Text(service, color = Green, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                offers.sortedWith(compareBy<com.binario.treni.data.FareOffer> { it.soldOut }.thenBy { it.price ?: Double.MAX_VALUE }).forEach { o ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(o.name, fontSize = 14.sp, modifier = Modifier.weight(1f), color = if (o.soldOut) Muted else MaterialTheme.colorScheme.onSurface)
                        if (!o.soldOut && o.available in 1..9) Text(tx("ultimi") + " ${o.available}  ", color = Color(0xFFEF6C00), fontSize = 12.sp)
                        Text(if (o.soldOut) tx("esaurita") else PricePrefs.money(o.price, PricePrefs.chf), fontSize = 14.sp,
                            fontWeight = if (o.soldOut) FontWeight.Normal else FontWeight.SemiBold, color = if (o.soldOut) Muted else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
        Text(tx("Prezzi per 1 adulto da LeFrecce (Trenitalia); possono cambiare fino all'acquisto."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

/** Unisce i treni prima del cambio [idx] con una nuova soluzione dalla stazione di cambio all'arrivo. */
private fun mergeAt(s: Solution, idx: Int, tail: Solution): Solution {
    val head = s.legs.take(idx).mapIndexed { j, l -> l.withEnds(s, j) }
    val rest = tail.legs.mapIndexed { j, l -> l.withEnds(tail, j) }
    val legs = head + rest
    return Solution(
        from = s.from, to = tail.to.ifBlank { s.to }, dep = s.dep, arr = tail.arr, duration = Fmt.duration(s.dep, tail.arr),
        price = null, legs = legs,
        source = if (legs.any { it.category.uppercase().startsWith("ITA") }) "italotreno.com" else s.source,
    )
}

/** Il cambio peggiore di una soluzione (per mostrare se anche l'alternativa ha cambi stretti). */
private fun worstChange(s: Solution): Pair<ChangeRisk.Level, Int> {
    var worst = ChangeRisk.Level.OK
    var gap = Int.MAX_VALUE
    for (i in 1 until s.legs.size) {
        val p = s.legs[i - 1].withEnds(s, i - 1)
        val n = s.legs[i].withEnds(s, i)
        if (p.arr <= 0 || n.dep <= 0) continue
        val g = ((n.dep - p.arr) / 60_000L).toInt()
        val lv = ChangeRisk.level(g, ChangeRisk.needed(p, n))
        if (lv.ordinal > worst.ordinal || (lv == worst && g < gap)) { worst = lv; gap = g }
    }
    return worst to gap
}

/**
 * Alternative a un cambio rischioso: dalla stazione di cambio si cercano i treni successivi verso l'arrivo,
 * con almeno il tempo consigliato per cambiare. La soluzione scelta sostituisce quella originale nella lista
 * e i suoi cambi vengono a loro volta controllati (si può ripetere per ogni cambio successivo).
 */
@Composable
private fun AltChangeDialog(vm: MainViewModel, s: Solution, idx: Int, onDismiss: () -> Unit, onChoose: (Solution) -> Unit) {
    val prev = s.legs[idx - 1].withEnds(s, idx - 1)
    val next = s.legs[idx].withEnds(s, idx)
    val station = next.from.ifBlank { prev.to }
    val need = ChangeRisk.needed(prev, next)
    var options by remember(s, idx) { mutableStateOf<List<Solution>?>(null) }
    var error by remember(s, idx) { mutableStateOf<String?>(null) }

    LaunchedEffect(s, idx) {
        try {
            options = withContext(Dispatchers.IO) {
                val st = Api.resolveStation(station, vm.from?.name.orEmpty()) ?: throw java.io.IOException(tx("Stazione di cambio non trovata"))
                val dest = listOfNotNull(vm.to, vm.from).firstOrNull { it.name.equals(s.to, true) } ?: Api.resolveStation(s.to)
                    ?: throw java.io.IOException(tx("Stazione di arrivo non trovata"))
                val after = prev.arr + need * 60_000L
                Api.solutions(st, dest, after, com.binario.treni.data.SearchFilter.BEST)
                    .filter { it.dep >= after && it.legs.isNotEmpty() }
                    .filter { t -> !(Api.trainDigits(t.legs.first().number) == Api.trainDigits(next.number) && t.dep == next.dep) }
                    .sortedBy { it.arr }.distinctBy { it.arr.toString() + it.legs.joinToString { l -> l.number } }
                    .take(5).map { mergeAt(s, idx, it) }
            }
        } catch (e: Exception) {
            error = e.message ?: tx("Impossibile contattare il server. Controlla la connessione.")
            options = emptyList()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Alternative al cambio a") + " " + station, fontSize = 18.sp) },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                Text(tx("Arrivo con") + " ${prev.title} " + tx("alle") + " ${Fmt.time(prev.arr)}. " +
                    tx("Treni successivi con almeno") + " $need " + tx("min per cambiare") + ":", fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                val list = options
                when {
                    list == null -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
                    list.isEmpty() -> Text(error ?: tx("Nessuna alternativa trovata dopo questo orario."), color = Muted, fontSize = 14.sp)
                    else -> list.forEach { alt ->
                        val (lv, gap) = worstChange(alt)
                        val later = ((alt.arr - s.arr) / 60_000L).toInt()
                        Surface(
                            onClick = { onChoose(alt) }, shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text("${Fmt.time(alt.legs[idx].dep)} → ${Fmt.time(alt.arr)}" + if (later > 0) "  (+$later min)" else "",
                                    fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(alt.legs.drop(idx).joinToString(" + ") { it.title }, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                when (lv) {
                                    ChangeRisk.Level.OK -> Text(tx("Cambi tranquilli"), color = Green, fontSize = 12.sp)
                                    ChangeRisk.Level.TIGHT -> Text(tx("Cambio stretto") + ": $gap min", color = Color(0xFFEF6C00), fontSize = 12.sp)
                                    else -> Text(tx("Cambio rischioso") + ": $gap min", color = LateRed, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(tx("Con i biglietti a treno e orario fissi (Frecce, Italo, Intercity) prendere un altro treno può richiedere il cambio del biglietto. I biglietti regionali valgono su qualsiasi regionale della tratta."),
                    color = Muted, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onDismiss) { Text(tx("Chiudi"), color = Green) } },
    )
}
