package com.binario.treni.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.tx

private class AgeRule(val title: String, val lines: List<String>, val url: String, val senior: List<String> = emptyList(), val seniorUrl: String = "")

private fun ageRules(): List<AgeRule> = listOf(
    AgeRule("🇮🇹 Trenitalia", listOf(
        tx("Treni nazionali: sotto i 4 anni gratis senza posto; da 4 a 14 anni (fino ai 15 non compiuti) sconto 50% sulla tariffa Base."),
        tx("Regionali: sotto i 4 anni gratis (con un adulto, senza posto); da 4 a meno di 12 anni sconto 50%. Alcune regioni hanno regole proprie (Lombardia, Campania, Abruzzo, Sardegna, Puglia, Trento, Bolzano)."),
        tx("Treni internazionali (EuroCity, EuroNight): gratis fino a 5 anni senza posto; da 6 a 14 anni offerta «CHILD» (circa 50%), varia per servizio."),
    ), "https://www.trenitalia.com/it/offerte/sconto-ragazzi.html", senior = listOf(tx("Over 60 con CartaFreccia: offerta FrecciaSENIOR sui treni Frecce (da 29 €). Sconti e condizioni dettagliati sulla pagina ufficiale.")), seniorUrl = "https://www.trenitalia.com/it/offerte/frecciasenior.html"),
    AgeRule("🇮🇹 Trenord", listOf(tx("Fino a 3 anni gratis su tutta la flotta, senza occupare un posto; da 4 a meno di 14 anni sconto 50% sulla Tariffa Unica Regionale; nell'area STIBM i minori di 14 anni viaggiano gratis (con un documento che prova l'età).")), "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/ragazzi-e-bambini-in-treno/", senior = listOf(tx("Dai 65 anni biglietti di corsa semplice scontati del 20% sulla Tariffa Unica Regionale Lombardia; nell'area STIBM sconto del 25% sugli abbonamenti mensili e annuali ordinari (da caricare sulla tessera Io Viaggio, 10 €).")), seniorUrl = "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/senior/"),
    AgeRule("🇮🇹 Italo", listOf(tx("Sotto i 3 anni gratis, senza posto assegnato e in braccio a un adulto (con più di un bambino per adulto serve il posto a pagamento). Offerta Italo Famiglia per 2–4 persone: dettagli sul sito.")), "https://www.italotreno.com/it/offerte-treno/bambini-gratis", senior = listOf(tx("Più di 60 anni: Italo Senior, sconto dal 40% al 60% rispetto alla tariffa Flex, in ambiente Smart e Prima Business; non rimborsabile, modificabile fino a 72 ore prima.")), seniorUrl = "https://www.italotreno.com/it/offerte-treno/italo-senior"),
    AgeRule("🇨🇭 SBB", listOf(tx("Sotto i 6 anni gratis; da 6 a meno di 16 anni metà prezzo (o prezzo minimo), oppure gratis con un genitore che ha un biglietto valido se hai la Carta Junior. Sotto i 25 anni: Metà-prezzo Giovani.")), "https://www.sbb.ch/it/informazioni-viaggio/esigenze-individuali/viaggiare-con-bambini/biglietti-abbonamenti.html", senior = listOf(tx("Abbonamento generale (AG) ridotto per le donne dal 64° compleanno (dal 2028 dal 65°) e per gli uomini dal 65°.")), seniorUrl = "https://cdnsource.sbb.ch/content/dam/internet/sbb/downloads/de/reiseinformationen/beduerfnisse/Angebote-Infos-Reisen-Alter.pdf.sbbdownload.pdf"),
    AgeRule("🇩🇪 Deutsche Bahn", listOf(tx("Sotto i 6 anni gratis; da 6 a 14 anni gratis sui treni a lunga percorrenza se accompagnati da un adulto o da un fratello o sorella di almeno 15 anni. Regionali e biglietti scontati possono avere regole diverse.")), "https://www.deutschebahn.com/resource/blob/13900336/355706d8f2f78e7cfa7d59a2cb43af8a/Faktenblatt_Bahnfahren-mit-Kindern-entspannt-und-preiswert-data.pdf", senior = listOf(tx("Senioren BahnCard dai 65 anni; la BahnCard 50 (dai 27 ai 64 anni) dà il 50% sul Flexpreis e il 25% sugli Sparpreis a lunga percorrenza.")), seniorUrl = "https://www.bahn.de/angebot/bahncard/bahncard50-2-klasse"),
    AgeRule("🇦🇹 ÖBB", listOf(tx("Sotto i 6 anni gratis senza biglietto, con un adulto; da 6 a 14 anni (fino al giorno prima del 15° compleanno) gratis con la Vorteilscard Family (21 €, fino a 4 bambini), solo sui treni ÖBB in Austria; dai 15 anni tariffa adulti.")), "https://www.oebb.at/de/fragen-und-antworten/kundenkarten/vorteilscard/alle-vorteilscards", senior = listOf(tx("Dai 65 anni, uomini e donne: Vorteilscard Senior a 31 € (valida 1 anno).")), seniorUrl = "https://www.oebb.at/de/fragen-und-antworten/kundenkarten/vorteilscard/alle-vorteilscards"),
    AgeRule("🇫🇷 SNCF", listOf(tx("Sotto i 4 anni gratis in braccio (TGV INOUI, TER, Intercités), un solo bambino per viaggiatore; posto proprio con il Forfait Bambin a 9 €. Da 4 a 11 anni: 60% di sconto per chi accompagna un titolare di Carte Avantage Adulte. OUIGO ha tariffe proprie.")), "https://www.sncf-connect.com/aide/l-offre-pour-les-enfants-et-les-familles", senior = listOf(tx("Dai 60 anni: Carte Avantage Senior a 49 € (conferma il prezzo all'acquisto): 30% sui viaggi in 2ª e 1ª classe, 60% per fino a 3 bambini di 4-11 anni che ti accompagnano; sconti TER variabili per regione.")), seniorUrl = "https://www.sncf-connect.com/catalogue/description/carte-avantage-senior"),
)

/** Legenda delle regole per età (gratis, ragazzi, famiglie) di ogni azienda e paese, con il link alla fonte ufficiale. */
@Composable
fun AgeRulesDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Regole per età: aziende e paesi")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(tx("Le riduzioni per età cambiano in base al paese, all'azienda, al tipo di treno e alla tariffa. Sintesi dai siti ufficiali (3/11/2026): possono cambiare, controlla sempre la fonte prima di acquistare."), color = Muted, fontSize = 12.sp)
                ageRules().forEach { r ->
                    Spacer(Modifier.height(10.dp))
                    Text(r.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(tx("Ragazzi"), color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp))
                    r.lines.forEach { Text("• $it", fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp)) }
                    TextButton({ openUrl(ctx, r.url) }, contentPadding = PaddingValues(0.dp)) {
                        Text(tx("Fonte") + ": " + r.url.substringAfter("//").substringBefore("/"), color = Green, fontSize = 13.sp)
                    }
                    if (r.senior.isNotEmpty()) {
                        Text("Senior", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        r.senior.forEach { Text("• $it", fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp)) }
                        TextButton({ openUrl(ctx, r.seniorUrl) }, contentPadding = PaddingValues(0.dp)) {
                            Text(tx("Fonte") + ": " + r.seniorUrl.substringAfter("//").substringBefore("/"), color = Green, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text(tx("Chiudi"), color = Green) } },
    )
}
