package com.binario.treni.ui

import com.binario.treni.data.tx
import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.binario.treni.data.Api
import com.binario.treni.data.CompanyTerms
import com.binario.treni.data.Railways
import com.binario.treni.data.Connection
import com.binario.treni.data.CrossBorderFares
import com.binario.treni.data.Fmt
import com.binario.treni.data.SearchFilter
import com.binario.treni.data.Solution
import com.binario.treni.data.Sources
import com.binario.treni.data.Station
import com.binario.treni.data.Swiss
import com.binario.treni.data.TrainRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Lettore integrato: mostra le pagine ufficiali sempre aggiornate dentro l'app
// ---------------------------------------------------------------------------

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebScreen(title: String, url0: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val url = com.binario.treni.data.LinkLoc.url(url0)
    var loading by remember { mutableStateOf(true) }
    var view by remember { mutableStateOf<WebView?>(null) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(title, onBack = { if (view?.canGoBack() == true) view?.goBack() else onBack() }) {
            IconButton({ view?.reload() }) { Icon(Icons.Filled.Refresh, tx("Aggiorna")) }
            IconButton({ openUrl(ctx, view?.url ?: url) }) { Icon(Icons.Filled.OpenInBrowser, tx("Apri nel browser")) }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(v: WebView, u: String?) {
                            loading = false
                        }

                        override fun shouldOverrideUrlLoading(v: WebView, req: android.webkit.WebResourceRequest): Boolean {
                            val u = req.url.toString()
                            // I PDF si aprono con il lettore del telefono
                            if (u.lowercase().contains(".pdf")) {
                                openUrl(ctx, u); return true
                            }
                            return false
                        }
                    }
                    loadUrl(url)
                    view = this
                }
            },
            onRelease = { it.destroy() },
        )
    }
}

// ---------------------------------------------------------------------------
// Condizioni di trasporto e diritti dei passeggeri
// ---------------------------------------------------------------------------

@Composable
fun ConditionsScreen(onBack: () -> Unit, openWeb: (String, String) -> Unit) {
    val ctx = LocalContext.current
    var openCompany by remember { mutableStateOf<String?>(null) }
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        item { GreenTopBar(tx("Condizioni di trasporto"), onBack) }
        item {
            WhiteCard {
                CardTitle(tx("Documenti ufficiali"))
                MenuRow(Icons.Filled.Train, "Trenord", tx("Condizioni di trasporto, biglietti, bici, animali, sanzioni")) {
                    openWeb(tx("Condizioni Trenord"), "https://www.trenord.it/assistenza/informazioni-utili/condizioni-di-trasporto/")
                }
                MenuRow(Icons.Filled.Train, "Trenitalia", tx("Condizioni generali di trasporto (regionale e media/lunga percorrenza)")) {
                    openWeb(tx("Condizioni Trenitalia"), "https://www.trenitalia.com/it/informazioni/condizioni-generali-di-trasporto.html")
                }
                MenuRow(Icons.Filled.Flight, "Malpensa Express", tx("Condizioni specifiche del collegamento aeroportuale")) {
                    openWeb(tx("Condizioni Malpensa Express"), "https://www.malpensaexpress.it/servizi-e-assistenza/informazioni-utili/condizioni-di-trasporto/")
                }
                MenuRow(Icons.Filled.Gavel, tx("Regolamento UE 2021/782"), tx("Diritti e obblighi dei passeggeri nel trasporto ferroviario (PDF)")) {
                    openUrl(ctx, "https://eur-lex.europa.eu/legal-content/IT/TXT/PDF/?uri=CELEX:32021R0782")
                }
                MenuRow(Icons.Filled.Public, tx("TILO (Ticino–Lombardia)"), tx("Titoli di viaggio, bici, assistenza")) { openWeb(tx("TILO · Servizi"), "https://www.tilo.ch/servizi.html") }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("I tuoi diritti in breve (UE 2021/782)"))
                Column(Modifier.padding(16.dp)) {
                    listOf(
                        tx("Ritardo previsto di almeno 60 minuti all'arrivo: puoi scegliere tra rimborso del biglietto, proseguimento o viaggio con un percorso alternativo."),
                        tx("Indennizzo per ritardo: 25% del prezzo del biglietto da 60 a 119 minuti, 50% da 120 minuti in su. Le aziende possono non pagare importi inferiori a 4 €."),
                        tx("Con ritardi di almeno 60 minuti hai diritto ad assistenza: pasti e bevande in proporzione all'attesa e, se serve, alloggio."),
                        tx("Se l'azienda non ti propone un'alternativa entro 100 minuti, puoi organizzarla tu con altri treni o autobus e chiedere il rimborso delle spese ragionevoli."),
                        tx("Persone con disabilità o mobilità ridotta: assistenza gratuita nelle stazioni e a bordo, da richiedere di norma almeno 24 ore prima."),
                        tx("L'indennizzo per ritardo può non essere dovuto per cause di forza maggiore (es. eventi meteo estremi, calamità naturali, gravi crisi sanitarie)."),
                        tx("Reclami: l'azienda deve rispondere entro un mese (in casi motivati fino a tre mesi)."),
                    ).forEach { t ->
                        Row(Modifier.padding(vertical = 4.dp)) {
                            Text("•", color = Green, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Text(t, fontSize = 14.sp)
                        }
                    }
                    Text(
                        tx("Sintesi informativa: fa fede il testo ufficiale del regolamento e delle condizioni di ciascuna azienda. ") +
                            tx("Le condizioni nazionali e regionali possono prevedere regole diverse per abbonamenti e treni regionali."),
                        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Condizioni e tariffe per azienda"))
                Railways.all.forEach { r ->
                    val t = CompanyTerms.of(r.id)
                    if (t != null && t.any) {
                        val opened = openCompany == r.id
                        MenuRow(Icons.Filled.Train, r.short, r.countryLabel) { openCompany = if (opened) null else r.id }
                        if (opened) {
                            t.conditions?.let { l -> MenuRow(Icons.Filled.Gavel, tx("Condizioni di trasporto"), l.host + " · " + l.lang) { openWeb(r.short, l.url) } }
                            t.fares?.let { l -> MenuRow(Icons.Filled.Euro, tx("Tariffe e biglietti"), l.host + " · " + l.lang) { openWeb(r.short, l.url) } }
                            t.rights?.let { l -> MenuRow(Icons.Filled.Public, tx("Diritti e rimborsi"), l.host + " · " + l.lang) { openWeb(r.short, l.url) } }
                            Text(
                                tx("Fonte: sito ufficiale di") + " " + r.name + " · " + tx("link verificati il") + " " + CompanyTerms.VERIFIED,
                                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                            )
                        }
                    }
                }
                Text(
                    tx("Le condizioni e le tariffe cambiano: l'app apre le pagine ufficiali di ogni azienda, senza copiarne i prezzi. Fa fede il testo dell'azienda."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp),
                )
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Rimborsi e reclami"))
                MenuRow(Icons.Filled.Euro, tx("Trenord · rimborsi e indennizzi"), "") { openWeb("Trenord", "https://www.trenord.it/assistenza/") }
                MenuRow(Icons.Filled.Euro, tx("Trenitalia · rimborsi e indennizzi"), "") { openWeb("Trenitalia", "https://www.trenitalia.com/it/informazioni/indennizzo-per-ritardodeltreno.html") }
                MenuRow(Icons.Filled.Euro, tx("Italo · assistenza"), "") { openWeb("Italo", "https://www.italotreno.com/it/contatti-supporto") }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

// ---------------------------------------------------------------------------
// TILO: linee, servizi, tariffe transfrontaliere
// ---------------------------------------------------------------------------

private data class TiloLine(val code: String, val route: String)

private val TILO_LINES = listOf(
    TiloLine("RE80", tx("Locarno – Lugano – Chiasso – Milano")),
    TiloLine("S10", tx("Biasca – Bellinzona – Lugano – Chiasso – Como")),
    TiloLine("S20", tx("Castione-Arbedo – Bellinzona – Locarno")),
    TiloLine("S30", tx("Cadenazzo – Luino – Gallarate")),
    TiloLine("S40", tx("Como – Mendrisio – Varese")),
    TiloLine("S50", tx("Biasca – Bellinzona – Lugano – Varese – Malpensa")),
    TiloLine("S90", tx("Giubiasco – Lugano – Mendrisio")),
    TiloLine("Pigiama", tx("Servizio notturno TILO Pigiama")),
)

@Composable
fun TiloScreen(onBack: () -> Unit, openWeb: (String, String) -> Unit, onCompare: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        item { GreenTopBar(tx("TILO · Ticino e Lombardia"), onBack) }
        item {
            WhiteCard(onClick = onCompare) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CompareArrows, null, tint = Green, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tx("Confronta itinerari"), fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Text(tx("Es. Varese → Como: via Mendrisio (TILO) o via Milano. Durata, cambi, costo e fattibilità."), color = Muted, fontSize = 13.sp)
                    }
                    Icon(Icons.Filled.ChevronRight, null, tint = Muted)
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Linee"))
                TILO_LINES.forEach { l ->
                    MenuRow(null, l.code, l.route) {
                        val slug = if (l.code == "Pigiama") "tilo-pigiama" else l.code
                        openWeb("TILO ${l.code}", "https://www.tilo.ch/collegamenti/$slug.html")
                    }
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Tariffe transfrontaliere"))
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(tx("2ª classe, corsa semplice, CHF · valide dal 14.12.2025 (fonte Arcobaleno)"), color = Muted, fontSize = 12.sp)
                    Row(Modifier.padding(top = 6.dp)) {
                        Text(tx("Percorso"), Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(tx("Intero"), Modifier.width(60.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(tx("Metà"), Modifier.width(50.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("≈ €", Modifier.width(62.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    CrossBorderFares.list.forEach { f ->
                        Row(Modifier.padding(vertical = 3.dp)) {
                            Text("${f.from} – ${f.to} (via ${f.via})", Modifier.weight(1f), fontSize = 14.sp)
                            Text("%.2f".format(f.chf), Modifier.width(60.dp), fontSize = 14.sp)
                            Text("%.2f €".format(f.chf * CrossBorderFares.EUR_PER_CHF), Modifier.width(62.dp), fontSize = 12.sp, color = Muted)
                            Text("%.2f".format(f.halfChf), Modifier.width(50.dp), fontSize = 14.sp)
                        }
                    }
                    Text(tx("Importi in euro indicativi (cambio circa 1,135 € per CHF): al momento dell'acquisto il cambio può variare."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    Text(CrossBorderFares.RULE, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    Text(CrossBorderFares.VALIDITY, color = Muted, fontSize = 12.sp)
                }
                MenuRow(Icons.Filled.ConfirmationNumber, tx("Biglietto transfrontaliero"), tx("Tabelle prezzi complete")) {
                    openWeb(tx("Biglietto transfrontaliero"), "https://arcobaleno.ch/it/home/biglietti/biglietto-transfrontaliero")
                }
                MenuRow(Icons.Filled.CalendarMonth, tx("Abbonamenti transfrontalieri"), tx("Mensile e annuale")) {
                    openWeb(tx("Abbonamenti transfrontalieri"), "https://arcobaleno.ch/it/transfrontalieri")
                }
                MenuRow(Icons.Filled.Map, tx("Piano zone Arcobaleno"), "PDF") {
                    openWeb(tx("Zone Arcobaleno"), "https://arcobaleno.ch/dam/jcr:ad16d45a-5dec-444e-b7bd-b458fb4bc2eb/20_flyer_piano_zone_01_ITA_2025_WEB.pdf")
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Servizi TILO"))
                listOf(
                    Triple(Icons.Filled.ConfirmationNumber, tx("Titoli di trasporto"), "https://www.tilo.ch/servizi/titoli-di-trasporto.html"),
                    Triple(Icons.Filled.PedalBike, tx("Bici e mobilità lenta"), "https://www.tilo.ch/servizi/bici.html"),
                    Triple(Icons.Filled.Store, tx("Servizi in stazione"), "https://www.tilo.ch/servizi/servizi-in-stazione.html"),
                    Triple(Icons.Filled.Accessible, tx("Viaggiatori con disabilità"), "https://www.tilo.ch/servizi/viaggiatori-disabili.html"),
                    Triple(Icons.Filled.Info, tx("Informazioni clienti e oggetti smarriti"), "https://www.tilo.ch/servizi/informazioni-generali-clienti.html"),
                    Triple(Icons.Filled.Warning, tx("Traffico, ritardi e scioperi"), "https://www.tilo.ch/servizi/informazioni-traffico-ferroviario.html"),
                    Triple(Icons.Filled.Campaign, tx("Avvisi"), "https://www.tilo.ch/avvisi.html"),
                    Triple(Icons.Filled.Hiking, tx("Tempo libero"), "https://www.tilo.ch/servizi/tempo-libero.html"),
                    Triple(Icons.Filled.Phone, tx("Contatti"), "https://www.tilo.ch/chi-siamo/contatti.html"),
                ).forEach { (icon, label, url) -> MenuRow(icon, label) { openWeb("TILO · $label", url) } }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

// ---------------------------------------------------------------------------
// Confronto itinerari (es. Varese → Como via Mendrisio oppure via Milano)
// ---------------------------------------------------------------------------

private data class RouteOption(
    val label: String,
    val conn: Connection?,
    val solution: Solution?,
    val priceText: String,
    val priceNote: String,
)

@Composable
fun CompareScreen(vm: MainViewModel, onBack: () -> Unit, onTrain: (TrainRef) -> Unit) {
    var from by remember { mutableStateOf<Station?>(null) }
    var to by remember { mutableStateOf<Station?>(null) }
    // Esempio predefinito: Varese → Como S. Giovanni (codici risolti dal servizio stazioni)
    LaunchedEffect(Unit) {
        if (from == null) from = withContext(Dispatchers.IO) { findStation("VARESE") }
        if (to == null) to = withContext(Dispatchers.IO) { findStation("COMO S.GIOVANNI") }
    }
    var picking by remember { mutableStateOf<Int?>(null) }
    var time by remember { mutableLongStateOf(MainViewModel.roundToQuarter(System.currentTimeMillis())) }
    var options by remember { mutableStateOf<List<RouteOption>?>(null) }
    var loading by remember { mutableStateOf(false) }
    var run by remember { mutableIntStateOf(0) }

    LaunchedEffect(run) {
        val f = from ?: return@LaunchedEffect
        val t = to ?: return@LaunchedEffect
        if (run == 0) return@LaunchedEffect
        loading = true
        options = withContext(Dispatchers.IO) { buildOptions(f, t, time) }
        loading = false
    }

    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        item { GreenTopBar(tx("Confronta itinerari"), onBack) }
        item {
            WhiteCard {
                Column(Modifier.padding(12.dp)) {
                    OutlinedButton({ picking = 0 }, Modifier.fillMaxWidth()) { Text(tx("Da: ") + (from?.name ?: "scegli")) }
                    OutlinedButton({ picking = 1 }, Modifier.fillMaxWidth()) { Text("A: " + (to?.name ?: "scegli")) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(com.binario.treni.data.I18n.tr("Partenza dalle ", "Departing from ") + Fmt.time(time), Modifier.weight(1f))
                        TextButton({ time -= 30 * 60_000L }) { Text("−30'", color = Green) }
                        TextButton({ time = MainViewModel.roundToQuarter(System.currentTimeMillis()) }) { Text(tx("Ora"), color = Green) }
                        TextButton({ time += 30 * 60_000L }) { Text("+30'", color = Green) }
                    }
                    Button({ run++ }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tx("Confronta")) }
                }
            }
        }
        if (loading) item { LoadingBox() }
        options?.let { list ->
            if (list.isEmpty()) item { MessageBox(tx("Nessun itinerario trovato per quest'ora. Prova più tardi o un altro giorno (alcune linee non circolano la domenica).")) }
            val best = list.filter { it.conn != null || it.solution != null }.minByOrNull { (it.conn?.arr ?: it.solution?.arr ?: Long.MAX_VALUE) }
            items(list) { o -> OptionCard(o, o == best, onTrain) }
            item {
                Text(
                    tx("Orari e cambi: orario ufficiale svizzero (transport.opendata.ch) e Trenitalia/LeFrecce. ") +
                        tx("Il prezzo via Milano è quello Trenitalia/Trenord; quello transfrontaliero è indicativo: verifica in biglietteria o sull'app Trenord/SBB."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp),
                )
            }
        }
    }
    picking?.let { w ->
        key(w) {
            StationPickerDialog(if (w == 0) tx("Partenza") else tx("Arrivo"), { picking = null }) { s ->
                if (w == 0) from = s else to = s
                picking = null
            }
        }
    }
}

private fun findStation(name: String): Station? = try {
    val l = Api.searchStations(name)
    l.firstOrNull { it.name.equals(name, true) } ?: Api.resolveStation(name) ?: l.firstOrNull()
} catch (e: Exception) {
    null
}

/** Calcola le alternative: via Mendrisio (TILO), via Milano, e la più veloce in assoluto. */
private suspend fun buildOptions(from: Station, to: Station, time: Long): List<RouteOption> = coroutineScope {
    val f = async { Swiss.placeOf(from) }
    val t = async { Swiss.placeOf(to) }
    val fName = f.await(); val tName = t.await()

    val viaMendrisio = async { runCatching { Swiss.connections(fName, tName, time, via = "Mendrisio", limit = 3) }.getOrDefault(emptyList()) }
    val viaMilano = async { runCatching { Swiss.connections(fName, tName, time, via = "Milano Centrale", limit = 3) }.getOrDefault(emptyList()) }
    val italian = async { runCatching { Api.solutions(from, to, time, SearchFilter.ALL) }.getOrDefault(emptyList()) }

    val m = viaMendrisio.await()
    val mi = viaMilano.await()
    val ita = italian.await()

    val out = mutableListOf<RouteOption>()
    m.firstOrNull()?.let { c ->
        val fare = CrossBorderFares.find(c.rides.firstOrNull()?.from ?: "", c.rides.lastOrNull()?.to ?: "")
        out += RouteOption(
            tx("Via Mendrisio (TILO, transfrontaliero)"), c, null,
            fare?.let { "CHF %.2f (%s)".format(it.chf, CrossBorderFares.eur(it.chf)) } ?: tx("Biglietto transfrontaliero"),
            fare?.let { tx("Tariffa ufficiale Arcobaleno") }
                ?: tx("Arcobaleno (tratta svizzera) + Trenord (tratta lombarda): prezzo da verificare all'acquisto"),
        )
    }
    // Via Milano: orario svizzero se disponibile, altrimenti soluzione italiana con prezzo
    val milSol = ita.firstOrNull { s -> s.legs.any { l -> l.from.contains("MILANO", true) || l.to.contains("MILANO", true) } || s.changes > 0 }
    val milConn = mi.firstOrNull()
    if (milConn != null || milSol != null) {
        out += RouteOption(
            tx("Via Milano (solo Italia)"), milConn, milSol,
            milSol?.price?.let { Fmt.price(it) } ?: tx("Biglietto regionale"),
            if (milSol?.price != null) tx("Prezzo Trenitalia/Trenord (1 adulto)") else tx("Tariffa regionale lombarda: prezzo da verificare"),
        )
    }
    // Soluzione diretta se esiste e diversa dalle precedenti
    ita.firstOrNull { s -> s.changes == 0 && s != milSol }?.let { s ->
        out += RouteOption(tx("Diretto"), null, s, s.price?.let { p -> Fmt.price(p) } ?: "—", tx("Prezzo Trenitalia/Trenord"))
    }
    out
}

@Composable
private fun OptionCard(o: RouteOption, best: Boolean, onTrain: (TrainRef) -> Unit) {
    val c = o.conn
    val s = o.solution
    val dep = c?.dep ?: s?.dep ?: 0L
    val arr = c?.arr ?: s?.arr ?: 0L
    val changes = c?.transfers ?: s?.changes ?: 0
    val slack = c?.transferSlack ?: emptyList()
    val minSlack = slack.minOfOrNull { it.second }
    val delay = c?.sections?.firstOrNull { !it.walk }?.delay ?: 0
    val (feas, feasColor) = when {
        c == null && s == null -> tx("Non disponibile in questa fascia oraria") to LateRed
        minSlack != null && (minSlack < 2 || minSlack - delay < 1) -> tx("Coincidenza molto a rischio") to LateRed
        minSlack != null && (minSlack < 5 || minSlack - delay < 4) -> tx("Coincidenza stretta") to Color(0xFFEF6C00)
        else -> tx("Fattibile") to Green
    }
    WhiteCard {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(o.label, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                if (best) Text(com.binario.treni.data.I18n.tr("PIÙ VELOCE", "FASTEST"), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.background(Green).padding(horizontal = 6.dp, vertical = 2.dp))
            }
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${Fmt.time(dep)} → ${Fmt.time(arr)}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.width(12.dp))
                Text(Fmt.duration(dep, arr), fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Text(o.priceText, fontWeight = FontWeight.Bold, color = Green, fontSize = 16.sp)
            }
            Text(
                (if (changes == 0) tx("Diretto") else "$changes camb${if (changes == 1) "io" else "i"}") +
                    (if (slack.isNotEmpty()) " · " + slack.joinToString { (st, m) -> "$st ($m')" } else ""),
                color = Muted, fontSize = 13.sp,
            )
            Text("● $feas" + (if (delay > 0) com.binario.treni.data.I18n.tr(" · primo treno +", " · first train +") + "$delay'" else ""), color = feasColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Color(0x14000000))
            if (c != null) {
                c.rides.forEach { r ->
                    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.width(70.dp)) {
                            Text(r.train, color = categoryColor(r.train), fontWeight = FontWeight.Bold)
                            CrowdBadge(r.crowd)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("${Fmt.time(r.dep)} ${r.from}", fontSize = 14.sp)
                            Text("${Fmt.time(r.arr)} ${r.to}", fontSize = 14.sp, color = Muted)
                        }
                        PlatformBox(r.depPlatform, false)
                    }
                }
            } else if (s != null) {
                s.legs.forEach { l ->
                    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        TrainTitle(l.category, l.number, 14, operator = l.operatorLabel) { onTrain(TrainRef(l.number, label = l.title)) }
                        Spacer(Modifier.width(8.dp))
                        Text(listOf(l.from, l.to).filter { it.isNotBlank() }.joinToString(" → "), fontSize = 13.sp, color = Muted)
                    }
                }
            }
            Text(o.priceNote, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            if (c != null && c.rides.isNotEmpty()) {
                val ctx = LocalContext.current
                TextButton({ openUrl(ctx, com.binario.treni.data.CrossBorderFares.sbbUrl(c.rides.first().from, c.rides.last().to, c.dep)) }) {
                    Text(tx("Apri su sbb.ch"), color = Green)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Treni garantiti in caso di sciopero
// ---------------------------------------------------------------------------

@Composable
fun GuaranteedScreen(onBack: () -> Unit, openWeb: (String, String) -> Unit) {
    val ctx = LocalContext.current
    var docs by remember { mutableStateOf<List<Sources.GuaranteedDoc>?>(null) }
    var failed by remember { mutableStateOf<List<String>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        docs = null
        val (d, f) = withContext(Dispatchers.IO) { Sources.guaranteedDocs() }
        docs = d; failed = f
    }
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        item {
            GreenTopBar(tx("Treni garantiti"), onBack) { IconButton({ tick++ }) { Icon(Icons.Filled.Refresh, tx("Aggiorna")) } }
        }
        item {
            WhiteCard {
                CardTitle(tx("Come funziona"))
                Text(
                    tx("Durante gli scioperi del trasporto regionale sono di norma garantiti i treni nelle fasce 6:00–9:00 e 18:00–21:00, ") +
                        tx("oltre ai treni indicati negli elenchi ufficiali delle aziende. Per media e lunga percorrenza valgono gli elenchi pubblicati da ciascuna azienda. ") +
                        tx("Controlla sempre il documento aggiornato prima di partire."),
                    fontSize = 14.sp, modifier = Modifier.padding(16.dp),
                )
            }
        }
        item { SectionHeader(tx("Elenchi ufficiali aggiornati")) }
        val d = docs
        when {
            d == null -> item { LoadingBox() }
            d.isEmpty() -> item { MessageBox(tx("Nessun elenco pubblicato in questo momento.")) }
            else -> items(d) { doc ->
                WhiteCard(onClick = { openUrl(ctx, doc.url) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.PictureAsPdf, null, tint = LateRed)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(doc.title, fontWeight = FontWeight.Medium)
                            // Azienda e nome del file: due elenchi della stessa azienda si distinguono subito
                            Text(doc.source + " · " + doc.url.substringBefore('?').substringAfterLast('/').let { f ->
                                try { java.net.URLDecoder.decode(f, "UTF-8") } catch (_: Exception) { f } }.take(60),
                                color = Muted, fontSize = 13.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        if (failed.isNotEmpty()) item { MessageBox(com.binario.treni.data.I18n.tr("Non raggiungibili ora: ", "Not reachable now: ") + failed.joinToString()) }
        item {
            WhiteCard {
                CardTitle(tx("Pagine ufficiali"))
                MenuRow(Icons.Filled.Train, tx("Trenitalia · treni garantiti"), "") {
                    openWeb(tx("Trenitalia · treni garantiti"), "https://www.trenitalia.com/it/informazioni/treni-garantiti-incasodisciopero.html")
                }
                MenuRow(Icons.Filled.Train, tx("Trenord · avvisi e scioperi"), "") { openWeb(tx("Trenord · avvisi"), "https://www.trenord.it/news/trenord-informa/avvisi/") }
                MenuRow(Icons.Filled.Train, tx("Italo · informazioni e assistenza"), "") { openWeb(tx("Italo · informazioni e assistenza"), "https://www.italotreno.com/it/contatti-supporto") }
                MenuRow(Icons.Filled.Public, tx("TILO · avvisi"), "") { openWeb(tx("TILO · avvisi"), "https://www.tilo.ch/avvisi.html") }
                MenuRow(Icons.Filled.Gavel, tx("Calendario scioperi (Ministero)"), "") {
                    openWeb(tx("Scioperi"), "https://scioperi.mit.gov.it/mit2/public/scioperi")
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}
