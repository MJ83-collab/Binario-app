package com.binario.treni.data

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Elemento OpenStreetMap con posizione e distanza dal punto di riferimento. */
data class OsmPlace(
    val kind: Kind,
    val name: String,
    val lat: Double,
    val lon: Double,
    val distance: Int,
    val tags: Map<String, String>,
) {
    enum class Kind(private val itLabel: String) {
        TICKET_OFFICE("Biglietteria"),
        TICKET_MACHINE("Emettitrice self-service"),
        VALIDATOR("Obliteratrice / validatrice"),
        RESELLER("Rivendita autorizzata"),
        ELEVATOR("Ascensore"),
        PLATFORM("Binario / marciapiede"),
        RAMP("Rampa"),
        ;

        val label: String get() = tx(itLabel)
    }

    val contactless: Boolean get() =
        tags["payment:contactless"] == "yes" || tags["payment:visa_contactless"] == "yes" ||
            tags["payment:mastercard_contactless"] == "yes" || tags["payment:apple_pay"] == "yes" || tags["payment:google_pay"] == "yes"
    val cards: Boolean get() = contactless || tags["payment:credit_cards"] == "yes" || tags["payment:debit_cards"] == "yes" ||
        tags["payment:cards"] == "yes" || tags["payment:visa"] == "yes" || tags["payment:mastercard"] == "yes"
    val wheelchair: String get() = tags["wheelchair"] ?: ""
    val platformRef: String get() = tags["ref"] ?: tags["railway:track_ref"] ?: tags["local_ref"] ?: ""
    val hours: String get() = tags["opening_hours"] ?: ""
    val operator: String get() = tags["operator"] ?: tags["brand"] ?: ""
}

/** Fermata di un mezzo pubblico vicino alla stazione, con le linee che ci passano (se mappate). */
data class TransitStop(val name: String, val lines: List<String>, val distance: Int, val lat: Double, val lon: Double, val extra: String = "")

/** Mezzi per proseguire il viaggio: metro, tram, bus, taxi, bici in condivisione. */
data class StationTransport(
    val metro: List<TransitStop>,
    val tram: List<TransitStop>,
    val bus: List<TransitStop>,
    val taxi: List<TransitStop>,
    val bikes: List<TransitStop>,
    val lat: Double,
    val lon: Double,
) {
    val isEmpty: Boolean get() = metro.isEmpty() && tram.isEmpty() && bus.isEmpty() && taxi.isEmpty() && bikes.isEmpty()
    val sourceUrl: String get() = "https://www.openstreetmap.org/#map=17/$lat/$lon&layers=T"
}

/** Posteggio taxi (stand = true) o società di taxi con telefono. */
data class TaxiPoint(
    val name: String, val stand: Boolean, val phone: String, val capacity: String, val hours: String, val website: String,
    val distance: Int, val lat: Double, val lon: Double,
)

/** Un defibrillatore (DAE) da OpenStreetMap, con i dettagli che i volontari indicano. */
data class Defibrillator(
    val name: String, val where: String, val indoor: String, val access: String, val hours: String, val operator: String,
    val phone: String, val level: String, val distance: Int, val lat: Double, val lon: Double, val osmRef: String = "",
)

/** Radio taxi ufficiali delle grandi città (numeri pubblicati dai servizi taxi cittadini). */
object RadioTaxi {
    data class Number(val label: String, val phone: String)

    private val CITIES: Map<String, List<Number>> = mapOf(
        "MILANO" to listOf(Number("Taxiblu", "024040"), Number("Radiotaxi Milano", "028585"), Number("Yellow Taxi", "026969")),
        "ROMA" to listOf(Number("Roma Capitale · Chiama Taxi", "060609"), Number("Radio Taxi 3570", "063570"), Number("Pronto Taxi 6645", "066645")),
        "FIRENZE" to listOf(Number("Radio Taxi Firenze", "0554242"), Number("SO.CO.TA.", "0554390")),
        "TORINO" to listOf(Number("Radio Taxi Torino", "0115737")),
        "BOLOGNA" to listOf(Number("CO.TA.BO.", "051372727"), Number("C.A.T.", "051534141")),
        "GENOVA" to listOf(Number("Radio Taxi Genova", "0105966")),
    )

    /** Città dalla stazione ("MILANO CENTRALE" → Milano). */
    fun forStation(name: String): Pair<String, List<Number>>? {
        val n = name.uppercase().trim()
        val city = CITIES.keys.firstOrNull { n == it || n.startsWith("$it ") } ?: return null
        return city.lowercase().replaceFirstChar { it.uppercase() } to CITIES.getValue(city)
    }
}

/** Servizi igienici: gratuiti o a pagamento (con prezzo se indicato), accessibilità e orari. */
data class Toilet(
    val fee: String, val charge: String, val wheelchair: String, val hours: String, val distance: Int, val name: String,
    val lat: Double = 0.0, val lon: Double = 0.0,
    /** Fasciatoio, accesso (pubblico/clienti), gestore. */
    val changingTable: Boolean = false, val access: String = "", val operator: String = "",
    /** Dettagli come in MapComplete (tema "Bagni pubblici"): elemento OSM, genere, posizione, carta, lavandino, piano, note. */
    val osmRef: String = "", val gender: String = "", val position: String = "", val paper: String = "",
    val handwashing: String = "", val level: String = "", val description: String = "",
) {
    /** Link per vedere o correggere il bagno su MapComplete (stessi dati OpenStreetMap). */
    val mapCompleteUrl: String get() = "https://mapcomplete.org/toilets.html?z=19&lat=$lat&lon=$lon" + (if (osmRef.isNotBlank()) "#$osmRef" else "")

    /** "Gratuito", "A pagamento · 1 €" o "Pagamento non indicato". */
    val feeText: String get() = when (fee) {
        "no" -> tx("Gratuito")
        "yes" -> tx("A pagamento") + (if (charge.isNotBlank()) " · " + charge.replace("EUR", "€").trim() else "")
        else -> tx("Gratuito o a pagamento: non indicato")
    }
}

/** Riepilogo dei servizi di una stazione, ricavato da OpenStreetMap. */
data class StationOverview(
    val tracks: List<String>,
    val platforms: List<PlatformAccess>,
    val elevators: Int,
    val ramps: Int,
    val escalators: Int,
    val ticketOffices: List<OsmPlace>,
    val machines: List<OsmPlace>,
    val validators: List<OsmPlace>,
    val resellers: List<OsmPlace>,
    val toilets: Int,
    val toiletList: List<Toilet>,
    val wheelchair: String,
    val lat: Double,
    val lon: Double,
) {
    val contactlessMachines: Int get() = machines.count { it.contactless }
    val sourceUrl: String get() = "https://www.openstreetmap.org/#map=18/$lat/$lon"
}

/** Binario con gli impianti di accessibilità vicini (ricavati da OpenStreetMap). */
data class PlatformAccess(val platform: String, val elevators: Int, val ramps: Int, val wheelchair: String)

/**
 * OpenStreetMap tramite Overpass API: rivendite, emettitrici, obliteratrici, ascensori e binari.
 * Dati comunitari: la completezza varia da stazione a stazione.
 */
object Osm {
    /**
     * Server Overpass verificati il 14/10/2026: solo la famiglia overpass-api.de è in linea
     * (kumi.systems, private.coffee, mail.ru, osm.jp e openstreetmap.ru non rispondono più).
     * Dal 2026 Overpass rifiuta (errore 406) le app che non si identificano: per questo
     * mandiamo un User-Agent con nome e indirizzo del progetto.
     */
    private val SERVERS = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://z.overpass-api.de/api/interpreter",
        "https://lz4.overpass-api.de/api/interpreter",
    )

    /** Server della comunità svizzera (OSM.ch, dati della Svizzera): verificato in linea il 14/10/2026. */
    private const val SWISS = "https://overpass.osm.ch/api/interpreter"

    /** Coordinate in Svizzera (riquadro approssimativo; esclude Varese, Como e l'Ossola). */
    private fun inSwitzerland(lat: Double, lon: Double): Boolean =
        lat in 45.82..47.81 && lon in 5.95..10.49 && !(lat < 46.15 && lon < 8.4)

    /** Riserva indipendente: Postpass di Geofabrik (database OpenStreetMap interrogabile in SQL). */
    private const val POSTPASS = "https://postpass.geofabrik.de/api/interpreter"
    private const val UA = "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)"
    private const val REFERER = "app://com.binario.treni"

    /** Ultima fonte che ha risposto (per mostrarla all'utente). */
    @Volatile var lastSource: String = ""
        private set

    /** Risultati recenti in memoria: freschi per 30 minuti, usati come riserva fino a 24 ore se tutti i server falliscono. */
    private val cache = HashMap<String, Pair<Long, JSONObject>>()

    private fun post(server: String, body: String, connectMs: Int, readMs: Int): String {
        val c = (URL(server).openConnection() as HttpURLConnection).apply {
            connectTimeout = connectMs; readTimeout = readMs
            requestMethod = "POST"; doOutput = true
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Referer", REFERER)
            setRequestProperty("Accept", "application/json, application/geo+json, */*")
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
        }
        try {
            c.outputStream.use { it.write(("data=" + URLEncoder.encode(body, "UTF-8")).toByteArray()) }
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun queryOn(server: String, q: String): JSONObject {
        val o = JSONObject(post(server, q, 8000, 22000))
        // Overpass segnala i timeout interni nel campo "remark" con elementi vuoti
        if (o.optString("remark").contains("runtime error", true)) throw IOException("Overpass timeout")
        return o
    }

    /** Area quadrata attorno al punto, per l'indice spaziale di Postpass. */
    private fun envelope(lat: Double, lon: Double, radius: Int): String {
        val dLat = radius / 111_320.0
        val dLon = radius / (111_320.0 * Math.cos(Math.toRadians(lat)))
        return "ST_MakeEnvelope(${lon - dLon},${lat - dLat},${lon + dLon},${lat + dLat},4326)"
    }

    /** Media delle coordinate di una geometria GeoJSON (punto, linea o poligono). */
    private fun center(coords: Any?): Pair<Double, Double>? {
        var sx = 0.0; var sy = 0.0; var n = 0
        fun walk(a: Any?) {
            if (a !is org.json.JSONArray || a.length() == 0) return
            if (a.opt(0) is Number) {
                sx += a.optDouble(0); sy += a.optDouble(1); n++
            } else for (i in 0 until a.length()) walk(a.opt(i))
        }
        walk(coords)
        return if (n == 0) null else (sy / n) to (sx / n)
    }

    /**
     * Interroga Postpass e converte il GeoJSON nel formato di Overpass ("elements" con tags e center),
     * così il resto dell'app non cambia. [maxDist] scarta ciò che sta fuori dal raggio richiesto.
     */
    private fun postpass(lat: Double, lon: Double, radius: Int, where: String, maxDist: (Map<String, String>) -> Int): JSONObject {
        val sql = "SELECT osm_type, osm_id, tags, geom FROM postpass_pointpolygon WHERE geom && ${envelope(lat, lon, radius)} AND ($where)"
        val g = JSONObject(post(POSTPASS, sql, 8000, 25000))
        val feats = g.optJSONArray("features") ?: throw IOException("Postpass: risposta vuota")
        val out = org.json.JSONArray()
        for (i in 0 until feats.length()) {
            val f = feats.optJSONObject(i) ?: continue
            val p = f.optJSONObject("properties") ?: continue
            val tj = p.optJSONObject("tags") ?: continue
            val tags = tj.keys().asSequence().associateWith { tj.optString(it) }
            val (la, lo) = center(f.optJSONObject("geometry")?.opt("coordinates")) ?: continue
            if (dist(lat, lon, la, lo) > maxDist(tags)) continue
            out.put(JSONObject().apply {
                put("type", when (p.optString("osm_type")) { "W" -> "way"; "R" -> "relation"; else -> "node" })
                put("id", p.optLong("osm_id"))
                put("lat", la); put("lon", lo)
                put("tags", tj)
            })
        }
        return JSONObject().put("elements", out)
    }

    /**
     * Prova i server Overpass uno dopo l'altro; se nessuno risponde usa Postpass ([fallback]);
     * se anche questo fallisce restituisce l'ultimo risultato salvato (fino a 24 ore).
     */
    private val pool = java.util.concurrent.Executors.newCachedThreadPool()

    /**
     * Richiesta "a riserva": parte dal primo server; se dopo 6 secondi non ha risposto (o dà errore) parte anche il successivo,
     * e vince la prima risposta valida. Più veloce quando un server è lento, senza caricare tutti i server a ogni richiesta.
     */
    private fun hedged(servers: List<String>, q: String): Pair<String, JSONObject> {
        val cs = java.util.concurrent.ExecutorCompletionService<Pair<String, JSONObject>>(pool)
        val futures = ArrayList<java.util.concurrent.Future<Pair<String, JSONObject>>>()
        var last: Exception? = null
        var started = 0
        var done = 0
        fun start() {
            val s = servers[started++]
            futures += cs.submit(java.util.concurrent.Callable { s to queryOn(s, q) })
        }
        start()
        try {
            while (done < started || started < servers.size) {
                val f = cs.poll(if (started < servers.size) 6L else 30L, java.util.concurrent.TimeUnit.SECONDS)
                if (f == null) {
                    if (started < servers.size) start() else break
                    continue
                }
                done++
                try {
                    return f.get()
                } catch (e: java.util.concurrent.ExecutionException) {
                    last = (e.cause as? Exception) ?: e
                    if (started < servers.size) start()
                }
            }
        } finally {
            futures.forEach { it.cancel(true) }
        }
        throw IOException("Overpass non raggiungibile", last)
    }

    /** Coordinate arrotondate a circa 50 m: piccoli spostamenti del GPS riusano i dati già scaricati. */
    private fun snap(x: Double) = Math.round(x * 2000.0) / 2000.0

    /** Cartella della cache su disco (impostata all'avvio dell'app). */
    @Volatile var diskDir: java.io.File? = null
        set(v) {
            field = v
            // Pulizia: via i dati più vecchi di 30 giorni
            try {
                v?.mkdirs()
                v?.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 30L * 24 * 3600_000L }?.forEach { it.delete() }
            } catch (_: Exception) {
            }
        }

    private fun diskFile(q: String): java.io.File? = diskDir?.let { d ->
        val h = java.security.MessageDigest.getInstance("SHA-1").digest(q.toByteArray()).joinToString("") { "%02x".format(it) }
        java.io.File(d, "$h.json")
    }

    private fun readDisk(q: String, maxAge: Long): JSONObject? = try {
        diskFile(q)?.takeIf { it.exists() && System.currentTimeMillis() - it.lastModified() < maxAge }?.let { JSONObject(it.readText()) }
    } catch (e: Exception) {
        null
    }

    private fun writeDisk(q: String, o: JSONObject) {
        try {
            diskFile(q)?.writeText(o.toString())
        } catch (_: Exception) {
        }
    }

    private fun query(q: String, lat: Double, lon: Double, fallback: (() -> JSONObject)? = null): JSONObject {
        synchronized(cache) {
            cache[q]?.let { (t, o) -> if (System.currentTimeMillis() - t < 30 * 60_000L) return o }
        }
        // Servizi di stazione, WC, taxi, DAE cambiano di rado: se li abbiamo letti negli ultimi 3 giorni li mostriamo subito
        readDisk(q, 3L * 24 * 3600_000L)?.let { o ->
            synchronized(cache) { cache[q] = System.currentTimeMillis() to o }
            lastSource = "OpenStreetMap · " + tx("dati salvati sul telefono")
            return o
        }
        var last: Exception? = null
        // Almeno 3 server Overpass diversi (4 in Svizzera), poi Postpass, poi i dati salvati
        val servers = if (inSwitzerland(lat, lon)) SERVERS + SWISS else SERVERS
        try {
            val (server, o) = hedged(servers, q)
            synchronized(cache) { cache[q] = System.currentTimeMillis() to o }
            writeDisk(q, o)
            lastSource = "OpenStreetMap · Overpass (" + URL(server).host + ")"
            return o
        } catch (e: Exception) {
            last = e
        }
        if (fallback != null) try {
            val o = fallback()
            synchronized(cache) { cache[q] = System.currentTimeMillis() to o }
            writeDisk(q, o)
            lastSource = "OpenStreetMap · Postpass (Geofabrik)"
            return o
        } catch (e: Exception) {
            last = e
        }
        synchronized(cache) {
            cache[q]?.let { (t, o) ->
                if (System.currentTimeMillis() - t < 24 * 3600_000L) {
                    lastSource = "OpenStreetMap · " + tx("dati salvati")
                    return o
                }
            }
        }
        readDisk(q, 30L * 24 * 3600_000L)?.let { o ->
            lastSource = "OpenStreetMap · " + tx("dati salvati")
            return o
        }
        throw IOException("OpenStreetMap non raggiungibile", last)
    }

    private const val SQL_TICKETS = "(tags->>'amenity' = 'vending_machine' AND tags->>'vending' ~ 'ticket|public_transport' AND tags->>'vending' !~ 'parking') " +
        "OR tags->>'vending' = 'public_transport_tickets' OR tags->>'amenity' = 'ticket_validator' " +
        "OR tags->>'shop' = 'ticket' OR tags->>'railway' = 'ticket_office'"
    private const val SQL_ACCESS = "tags->>'highway' = 'elevator' OR tags->>'railway' = 'platform' " +
        "OR (tags->>'public_transport' = 'platform' AND tags->>'train' = 'yes') OR tags->>'ramp' = 'yes' OR tags->>'ramp:wheelchair' = 'yes'"

    private fun dist(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
        return (r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toInt()
    }

    private fun places(json: JSONObject, lat: Double, lon: Double, classify: (Map<String, String>) -> OsmPlace.Kind?): List<OsmPlace> {
        val els = json.optJSONArray("elements") ?: return emptyList()
        return (0 until els.length()).mapNotNull { i ->
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: return@mapNotNull null
            val tags = t.keys().asSequence().associateWith { t.optString(it) }
            val kind = classify(tags) ?: return@mapNotNull null
            val la = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: return@mapNotNull null
            val lo = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: return@mapNotNull null
            val name = tags["name"] ?: tags["brand"] ?: tags["operator"] ?: kind.label
            OsmPlace(kind, name, la, lo, dist(lat, lon, la, lo), tags)
        }.sortedBy { it.distance }
    }

    /**
     * Biglietterie, emettitrici e obliteratrici mappate in OpenStreetMap entro [radius] metri.
     * Le tabaccherie ed edicole generiche NON sono incluse: le rivendite autorizzate arrivano dagli elenchi
     * ufficiali delle aziende ([TicketSellers]).
     */
    fun ticketPlaces(lat: Double, lon: Double, radius: Int = 1000): List<OsmPlace> {
        val a = "(around:$radius,$lat,$lon)"
        val q = """
            [out:json][timeout:20];
            (
              nwr["amenity"="vending_machine"]["vending"~"ticket|public_transport"]["vending"!~"parking"]$a;
              nwr["shop"="ticket"]$a;
              nwr["amenity"="ticket_validator"]$a;
              nwr["vending"="public_transport_tickets"]$a;
              nwr["railway"="ticket_office"]$a;
            );
            out center tags;
        """.trimIndent()
        val json = query(q, lat, lon) {
            postpass(lat, lon, radius, SQL_TICKETS) { radius }
        }
        return places(json, lat, lon) { t ->
            when {
                t["amenity"] == "ticket_validator" -> OsmPlace.Kind.VALIDATOR
                (t["amenity"] == "vending_machine" || t["vending"] == "public_transport_tickets") && t["vending"]?.contains("parking") != true -> OsmPlace.Kind.TICKET_MACHINE
                t["shop"] == "ticket" || t["railway"] == "ticket_office" -> OsmPlace.Kind.TICKET_OFFICE
                t["shop"] in setOf("tobacco", "kiosk", "newsagent") -> OsmPlace.Kind.RESELLER
                else -> null
            }
        }
    }

    /** Ascensori, rampe e binari attorno alla stazione. */
    fun stationAccess(lat: Double, lon: Double, radius: Int = 350): List<OsmPlace> {
        val a = "(around:$radius,$lat,$lon)"
        val q = """
            [out:json][timeout:20];
            (
              nwr["highway"="elevator"]$a;
              nwr["railway"="platform"]$a;
              nwr["public_transport"="platform"]["train"="yes"]$a;
              nwr["ramp"="yes"]$a;
              nwr["ramp:wheelchair"="yes"]$a;
            );
            out center tags;
        """.trimIndent()
        val json = query(q, lat, lon) { postpass(lat, lon, radius, SQL_ACCESS) { radius } }
        return places(json, lat, lon) { t ->
            when {
                t["highway"] == "elevator" -> OsmPlace.Kind.ELEVATOR
                t["railway"] == "platform" || (t["public_transport"] == "platform" && t["train"] == "yes") -> OsmPlace.Kind.PLATFORM
                t["ramp"] == "yes" || t["ramp:wheelchair"] == "yes" -> OsmPlace.Kind.RAMP
                else -> null
            }
        }
    }

    /** Numeri di binario contenuti in un ref OSM: "1;2", "1-2", "3 e 4", "1a" → ["1","2"], ["3","4"], ["1a"]. */
    fun trackRefs(ref: String): List<String> =
        ref.split(';', ',', '/', '-', '–').flatMap { it.split(Regex("\\s+e\\s+|\\s+")) }
            .map { it.trim().removePrefix("Binario").removePrefix("binario").trim() }
            .filter { it.isNotBlank() && it.length <= 4 && it.any { c -> c.isDigit() } }

    /**
     * Riepilogo completo della stazione con una sola richiesta: binari, ascensori per binario, rampe, scale mobili,
     * biglietterie, emettitrici self-service (con contactless), obliteratrici, rivendite vicine, servizi igienici.
     */
    fun stationOverview(lat: Double, lon: Double): StationOverview {
        val inSt = "(around:350,$lat,$lon)"
        val near = "(around:500,$lat,$lon)"
        val q = """
            [out:json][timeout:20];
            (
              nwr["highway"="elevator"]$inSt;
              nwr["highway"="steps"]["conveying"]$inSt;
              nwr["railway"="platform"]$inSt;
              nwr["public_transport"="platform"]["train"="yes"]$inSt;
              nwr["ramp"="yes"]$inSt;
              nwr["ramp:wheelchair"="yes"]$inSt;
              nwr["amenity"="vending_machine"]["vending"~"ticket|public_transport"]["vending"!~"parking"]$inSt;
              nwr["vending"="public_transport_tickets"]$inSt;
              nwr["amenity"="ticket_validator"]$inSt;
              nwr["shop"="ticket"]$inSt;
              nwr["railway"="ticket_office"]$inSt;
              nwr["amenity"="toilets"]$inSt;
              nwr["railway"="station"]$inSt;
            );
            out center tags;
        """.trimIndent()
        val json = query(q, lat, lon) {
            postpass(lat, lon, 500, "$SQL_ACCESS OR $SQL_TICKETS OR tags->>'amenity' = 'toilets' OR tags->>'railway' = 'station' " +
                "OR (tags->>'highway' = 'steps' AND tags ? 'conveying')") { 350 }
        }
        val all = places(json, lat, lon) { t ->
            when {
                t["highway"] == "elevator" -> OsmPlace.Kind.ELEVATOR
                t["railway"] == "platform" || (t["public_transport"] == "platform" && t["train"] == "yes") -> OsmPlace.Kind.PLATFORM
                t["ramp"] == "yes" || t["ramp:wheelchair"] == "yes" -> OsmPlace.Kind.RAMP
                t["amenity"] == "ticket_validator" -> OsmPlace.Kind.VALIDATOR
                (t["amenity"] == "vending_machine" || t["vending"] == "public_transport_tickets") && t["vending"]?.contains("parking") != true -> OsmPlace.Kind.TICKET_MACHINE
                t["shop"] == "ticket" || t["railway"] == "ticket_office" -> OsmPlace.Kind.TICKET_OFFICE
                t["shop"] in setOf("tobacco", "kiosk", "newsagent") -> OsmPlace.Kind.RESELLER
                else -> null
            }
        }
        val els = json.optJSONArray("elements")
        var escalators = 0
        var toilets = 0
        val toiletList = mutableListOf<Toilet>()
        var wheelchair = ""
        if (els != null) for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: continue
            if (t.optString("highway") == "steps" && t.has("conveying")) escalators++
            if (t.optString("amenity") == "toilets") {
                toilets++
                val la = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: lat
                val lo = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: lon
                toiletList += Toilet(t.optString("fee"), t.optString("charge"), t.optString("wheelchair"),
                    t.optString("opening_hours"), dist(lat, lon, la, lo), t.optString("name").ifBlank { t.optString("operator") }, la, lo,
                    t.optString("changing_table") == "yes", t.optString("access"), t.optString("operator"))
            }
            if (t.optString("railway") == "station") {
                if (wheelchair.isBlank()) wheelchair = t.optString("wheelchair")
                // A volte i bagni sono indicati direttamente sulla stazione (toilets=yes, toilets:fee=…)
                if (t.optString("toilets") == "yes" && toiletList.isEmpty()) {
                    toilets++
                    toiletList += Toilet(t.optString("toilets:fee"), t.optString("toilets:charge"), t.optString("toilets:wheelchair"),
                        t.optString("toilets:opening_hours"), 0, "")
                }
            }
        }
        val platforms = platformSummary(all)
        val tracks = all.filter { it.kind == OsmPlace.Kind.PLATFORM }
            .flatMap { trackRefs(it.platformRef) }
            .distinct()
            .sortedWith(compareBy({ it.filter { c -> c.isDigit() }.take(3).toIntOrNull() ?: 999 }, { it }))
        return StationOverview(
            tracks = tracks,
            platforms = platforms,
            elevators = all.count { it.kind == OsmPlace.Kind.ELEVATOR },
            ramps = all.count { it.kind == OsmPlace.Kind.RAMP },
            escalators = escalators,
            ticketOffices = all.filter { it.kind == OsmPlace.Kind.TICKET_OFFICE },
            machines = all.filter { it.kind == OsmPlace.Kind.TICKET_MACHINE },
            validators = all.filter { it.kind == OsmPlace.Kind.VALIDATOR },
            resellers = all.filter { it.kind == OsmPlace.Kind.RESELLER },
            toilets = toilets,
            toiletList = toiletList.sortedBy { it.distance },
            wheelchair = wheelchair,
            lat = lat, lon = lon,
        )
    }

    /**
     * Servizi igienici entro [radius] metri (OpenStreetMap): gratuiti o a pagamento, accessibili, orari, fasciatoio.
     * Include i bagni indicati sulla stazione stessa (toilets=yes) e quelli di bar/ristoranti aperti a tutti.
     */
    fun toilets(lat0: Double, lon0: Double, radius: Int = 800): List<Toilet> {
        val lat = snap(lat0)
        val lon = snap(lon0)
        val a = "(around:$radius,$lat,$lon)"
        val q = """
            [out:json][timeout:20];
            (
              nwr["amenity"="toilets"]$a;
              nwr["railway"="station"]["toilets"="yes"]$a;
              nwr["toilets"="yes"]["toilets:access"~"^(yes|customers)$"]$a;
            );
            out center tags;
        """.trimIndent()
        val json = query(q, lat, lon) {
            postpass(lat, lon, radius, "tags->>'amenity' = 'toilets' OR (tags->>'railway' = 'station' AND tags->>'toilets' = 'yes') " +
                "OR (tags->>'toilets' = 'yes' AND tags->>'toilets:access' IN ('yes','customers'))") { radius }
        }
        val els = json.optJSONArray("elements") ?: return emptyList()
        return (0 until els.length()).mapNotNull { i ->
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: return@mapNotNull null
            val la = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: return@mapNotNull null
            val lo = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: return@mapNotNull null
            val own = t.optString("amenity") == "toilets"
            // Per stazioni e locali i dati del bagno stanno nei tag "toilets:…"
            fun tg(k: String) = if (own) t.optString(k) else t.optString("toilets:$k")
            val name = when {
                own -> t.optString("name").ifBlank { t.optString("operator") }
                t.optString("railway") == "station" -> tx("Stazione") + " " + t.optString("name")
                else -> t.optString("name") + " (" + tx("per i clienti") + ")"
            }
            Toilet(tg("fee"), tg("charge"), tg("wheelchair"), tg("opening_hours").ifBlank { if (!own) t.optString("opening_hours") else "" },
                dist(lat0, lon0, la, lo), name, la, lo,
                tg("changing_table") == "yes", if (own) t.optString("access") else t.optString("toilets:access"), t.optString("operator"),
                osmRef = if (e.optLong("id") > 0 && e.optString("type").isNotBlank()) e.optString("type") + "/" + e.optLong("id") else "",
                gender = when {
                    tg("unisex") == "yes" -> "unisex"
                    tg("male") == "yes" && tg("female") == "yes" -> "both"
                    tg("male") == "yes" -> "male"
                    tg("female") == "yes" -> "female"
                    else -> ""
                },
                position = tg("toilets:position").ifBlank { t.optString("toilets:position") },
                paper = t.optString("toilets:paper_supplied"), handwashing = t.optString("toilets:handwashing"),
                level = t.optString("level"), description = t.optString("description"))
        }.distinctBy { "${it.lat.toString().take(7)}|${it.lon.toString().take(6)}" }.sortedBy { it.distance }
    }

    /** Categorie per "Esplora" (orientamento per persone non vedenti). */
    enum class PoiKind(val itName: String, val en: String, val zh: String, val de: String = en, val fr: String = en, val es: String = en, val ja: String = en) {
        STATION("stazione", "station", "车站", "Bahnhof", "gare", "estación", "駅"), PLATFORM("binario", "platform", "站台", "Gleis", "voie", "vía", "番線"), ELEVATOR("ascensore", "lift", "电梯", "Aufzug", "ascenseur", "ascensor", "エレベーター"),
        STEPS("scale", "stairs", "楼梯", "Treppe", "escaliers", "escaleras", "階段"), ESCALATOR("scala mobile", "escalator", "自动扶梯", "Rolltreppe", "escalier mécanique", "escalera mecánica", "エスカレーター"), ENTRANCE("ingresso", "entrance", "入口", "Eingang", "entrée", "entrada", "入口"),
        TICKETS("biglietteria", "ticket office", "售票处", "Fahrkartenschalter", "guichet", "taquilla", "切符売り場"), MACHINE("emettitrice di biglietti", "ticket machine", "售票机", "Fahrkartenautomat", "distributeur de billets", "máquina expendedora", "券売機"),
        VALIDATOR("obliteratrice", "validator", "验票机", "Entwerter", "composteur", "validadora", "刻印機"), TOILETS("WC", "toilets", "厕所", "Toiletten", "toilettes", "aseos", "トイレ"), TAXI("posteggio taxi", "taxi rank", "出租车站", "Taxistand", "station de taxi", "parada de taxis", "タクシー乗り場"),
        BUS("fermata bus", "bus stop", "巴士站", "Bushaltestelle", "arrêt de bus", "parada de autobús", "バス停"), INFO("punto informazioni", "information point", "问询处", "Infopunkt", "point d'information", "punto de información", "案内所"), CAFE("bar", "café", "咖啡馆", "Café", "café", "cafetería", "カフェ"),
        DAE("defibrillatore", "defibrillator", "除颤器", "Defibrillator", "défibrillateur", "desfibrilador", "AED"),
        ;

        val label: String get() = I18n.tr5(itName, en, zh, de, fr, es, ja)
    }

    data class Poi(val kind: PoiKind, val name: String, val lat: Double, val lon: Double, val distance: Int, val id: String, val detail: String = "")

    /** Punti utili attorno (stazioni, binari, ascensori, scale, ingressi, biglietterie, WC, taxi, bus, bar). */
    fun pois(lat0: Double, lon0: Double, radius: Int = 300): List<Poi> {
        val lat = snap(lat0)
        val lon = snap(lon0)
        val a = "(around:$radius,$lat,$lon)"
        val q = """
            [out:json][timeout:20];
            (
              nwr["railway"~"^(station|halt)$"](around:${radius * 4},$lat,$lon);
              nwr["public_transport"="platform"]["train"="yes"]$a;
              nwr["railway"="platform"]$a;
              nwr["highway"="elevator"]$a;
              way["highway"="steps"]$a;
              nwr["highway"="steps"]$a;
              nwr["conveying"]$a;
              node["entrance"]$a;
              node["railway"="subway_entrance"]$a;
              nwr["shop"="ticket"]$a;
              nwr["railway"="ticket_office"]$a;
              nwr["amenity"="vending_machine"]["vending"~"tickets"]$a;
              nwr["amenity"="ticket_validator"]$a;
              nwr["amenity"="toilets"]$a;
              nwr["amenity"="taxi"]$a;
              node["highway"="bus_stop"]$a;
              nwr["tourism"="information"]["information"="office"]$a;
              nwr["amenity"~"^(cafe|bar|fast_food)$"]$a;
              nwr["emergency"="defibrillator"]$a;
            );
            out center tags;
        """.trimIndent()
        val json = query(q, lat, lon)
        val els = json.optJSONArray("elements") ?: return emptyList()
        return (0 until els.length()).mapNotNull { i ->
            val e = els.optJSONObject(i) ?: return@mapNotNull null
            val t = e.optJSONObject("tags") ?: return@mapNotNull null
            val la = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: return@mapNotNull null
            val lo = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: return@mapNotNull null
            fun g(k: String) = t.optString(k)
            val kind = when {
                g("railway") == "station" || g("railway") == "halt" -> PoiKind.STATION
                g("highway") == "elevator" -> PoiKind.ELEVATOR
                g("conveying").isNotBlank() -> PoiKind.ESCALATOR
                g("highway") == "steps" -> PoiKind.STEPS
                g("railway") == "platform" || g("public_transport") == "platform" -> PoiKind.PLATFORM
                g("entrance").isNotBlank() || g("railway") == "subway_entrance" -> PoiKind.ENTRANCE
                g("shop") == "ticket" || g("railway") == "ticket_office" -> PoiKind.TICKETS
                g("amenity") == "vending_machine" -> PoiKind.MACHINE
                g("amenity") == "ticket_validator" -> PoiKind.VALIDATOR
                g("amenity") == "toilets" -> PoiKind.TOILETS
                g("amenity") == "taxi" -> PoiKind.TAXI
                g("highway") == "bus_stop" -> PoiKind.BUS
                g("tourism") == "information" -> PoiKind.INFO
                g("emergency") == "defibrillator" -> PoiKind.DAE
                else -> PoiKind.CAFE
            }
            val name = when (kind) {
                PoiKind.PLATFORM -> g("ref").ifBlank { g("local_ref") }.let { if (it.isNotBlank()) I18n.tr("binario ", "platform ") + it.replace(";", " e ") else g("name") }
                else -> g("name").ifBlank { g("ref") }
            }
            val detail = listOfNotNull(
                g("wheelchair").takeIf { it == "yes" }?.let { I18n.tr("accessibile", "accessible") },
                g("tactile_paving").takeIf { it == "yes" }?.let { I18n.tr("percorso tattile", "tactile paving") },
                g("step_count").takeIf { it.isNotBlank() }?.let { it + " " + I18n.tr("gradini", "steps") },
                g("handrail").takeIf { it == "yes" }?.let { I18n.tr("corrimano", "handrail") },
                g("level").takeIf { it.isNotBlank() }?.let { I18n.tr("piano ", "level ") + it },
                g("defibrillator:location").takeIf { it.isNotBlank() },
            ).joinToString(", ")
            Poi(kind, name, la, lo, dist(lat0, lon0, la, lo), e.optString("type") + e.optLong("id"), detail)
        }.distinctBy { it.id }.sortedBy { it.distance }
    }

    /** Cerca un luogo per nome (OpenStreetMap Nominatim), vicino alla posizione se nota. */
    fun geocode(q: String, near: Pair<Double, Double>?): List<Poi> {
        val enc = URLEncoder.encode(q, "UTF-8")
        val bias = near?.let { (la, lo) -> "&viewbox=${lo - 0.3},${la + 0.2},${lo + 0.3},${la - 0.2}" } ?: ""
        val c = (URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=8&accept-language=it&countrycodes=it,ch&q=$enc$bias")
            .openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 12000
            setRequestProperty("User-Agent", UA)
        }
        val body = try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
        val a = org.json.JSONArray(body)
        return (0 until a.length()).mapNotNull { i ->
            val o = a.optJSONObject(i) ?: return@mapNotNull null
            val la = o.optString("lat").toDoubleOrNull() ?: return@mapNotNull null
            val lo = o.optString("lon").toDoubleOrNull() ?: return@mapNotNull null
            Poi(PoiKind.INFO, o.optString("display_name").split(",").take(3).joinToString(",").trim(), la, lo,
                near?.let { dist(it.first, it.second, la, lo) } ?: 0, "nom" + o.optLong("place_id"))
        }
    }

    /**
     * Taxi vicino a una stazione: posteggi (amenity=taxi) e società/cooperative di taxi con il telefono (office=taxi,
     * craft=taxi), da OpenStreetMap.
     */
    fun taxis(lat0: Double, lon0: Double, radius: Int = 1500): List<TaxiPoint> {
        val lat = snap(lat0)
        val lon = snap(lon0)
        val a = "(around:$radius,$lat,$lon)"
        val far = "(around:${radius * 5},$lat,$lon)"
        val q = """
            [out:json][timeout:20];
            (
              nwr["amenity"="taxi"]$a;
              nwr["office"="taxi"]$far;
              nwr["craft"="taxi"]$far;
              nwr["shop"="taxi"]$far;
            );
            out center tags;
        """.trimIndent()
        val json = query(q, lat, lon) {
            postpass(lat, lon, radius * 5, "tags->>'amenity' = 'taxi' OR tags->>'office' = 'taxi' OR tags->>'craft' = 'taxi' OR tags->>'shop' = 'taxi'") { radius * 5 }
        }
        val els = json.optJSONArray("elements") ?: return emptyList()
        return (0 until els.length()).mapNotNull { i ->
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: return@mapNotNull null
            val la = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: return@mapNotNull null
            val lo = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: return@mapNotNull null
            val stand = t.optString("amenity") == "taxi"
            val d = dist(lat0, lon0, la, lo)
            if (stand && d > radius) return@mapNotNull null
            val phone = listOf("phone", "contact:phone", "contact:mobile", "mobile").map { t.optString(it) }.firstOrNull { it.isNotBlank() }.orEmpty()
            TaxiPoint(
                name = t.optString("name").ifBlank { t.optString("operator") },
                stand = stand, phone = phone.split(';').first().trim(),
                capacity = t.optString("capacity"), hours = t.optString("opening_hours"),
                website = t.optString("website").ifBlank { t.optString("contact:website") },
                distance = d, lat = la, lon = lo,
            )
        }.filter { it.stand || it.phone.isNotBlank() }
            .distinctBy { "${it.lat.toString().take(7)}|${it.lon.toString().take(6)}|${it.phone}" }
            .sortedWith(compareBy<TaxiPoint> { !it.stand }.thenBy { it.distance })
    }

    /** Defibrillatori (emergency=defibrillator) entro [radius] metri, dal più vicino. */
    fun defibrillators(lat0: Double, lon0: Double, radius: Int = 1500): List<Defibrillator> {
        val lat = snap(lat0)
        val lon = snap(lon0)
        val q = """
            [out:json][timeout:20];
            nwr["emergency"="defibrillator"](around:$radius,$lat,$lon);
            out center tags;
        """.trimIndent()
        val json = query(q, lat, lon) { postpass(lat, lon, radius, "tags->>'emergency' = 'defibrillator'") { radius } }
        val els = json.optJSONArray("elements") ?: return emptyList()
        return (0 until els.length()).mapNotNull { i ->
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: return@mapNotNull null
            val la = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: return@mapNotNull null
            val lo = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: return@mapNotNull null
            val d = dist(lat0, lon0, la, lo)
            if (d > radius) return@mapNotNull null
            Defibrillator(
                name = t.optString("name").ifBlank { t.optString("operator") },
                where = listOf("defibrillator:location:it", "defibrillator:location", "description:it", "description").map { t.optString(it) }.firstOrNull { it.isNotBlank() }.orEmpty(),
                indoor = t.optString("indoor"), access = t.optString("access"), hours = t.optString("opening_hours"),
                operator = t.optString("operator"), phone = t.optString("phone").ifBlank { t.optString("emergency:phone") },
                level = t.optString("level"), distance = d, lat = la, lon = lo,
                osmRef = if (e.optLong("id") > 0 && e.optString("type").isNotBlank()) e.optString("type") + "/" + e.optLong("id") else "",
            )
        }.distinctBy { "${it.lat.toString().take(8)}|${it.lon.toString().take(7)}" }.sortedBy { it.distance }
    }

    /** Ospedali (con indicazione del pronto soccorso) e farmacie entro [radius] metri: dove chiedere aiuto o un DAE. */
    fun helpPlaces(lat0: Double, lon0: Double, radius: Int = 3000): List<Poi> {
        val lat = snap(lat0)
        val lon = snap(lon0)
        val q = """
            [out:json][timeout:20];
            (
              nwr["amenity"="hospital"](around:${radius * 3},$lat,$lon);
              nwr["amenity"="pharmacy"](around:$radius,$lat,$lon);
            );
            out center tags;
        """.trimIndent()
        val json = query(q, lat, lon) { postpass(lat, lon, radius * 3, "tags->>'amenity' IN ('hospital','pharmacy')") { radius * 3 } }
        val els = json.optJSONArray("elements") ?: return emptyList()
        return (0 until els.length()).mapNotNull { i ->
            val e = els.optJSONObject(i) ?: return@mapNotNull null
            val t = e.optJSONObject("tags") ?: return@mapNotNull null
            val la = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: return@mapNotNull null
            val lo = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: return@mapNotNull null
            val hospital = t.optString("amenity") == "hospital"
            val name = t.optString("name").ifBlank { if (hospital) I18n.tr("Ospedale", "Hospital") else I18n.tr("Farmacia", "Pharmacy") }
            val detail = listOfNotNull(
                if (hospital) (if (t.optString("emergency") == "yes") I18n.tr("pronto soccorso", "emergency department") else I18n.tr("ospedale", "hospital")) else I18n.tr("farmacia", "pharmacy"),
                t.optString("opening_hours").takeIf { it.isNotBlank() },
            ).joinToString(" · ")
            Poi(if (hospital) PoiKind.INFO else PoiKind.CAFE, name, la, lo, dist(lat0, lon0, la, lo), (if (hospital) "H" else "P") + e.optLong("id"), detail)
        }.distinctBy { it.id }.sortedBy { it.distance }
    }

    /** Linee indicate su una fermata OSM: route_ref "1;5;N25", oppure line/ref. */
    private fun linesOf(t: Map<String, String>): List<String> =
        (t["route_ref"] ?: t["line"] ?: t["lines"] ?: "")
            .split(';', ',', '/').map { it.trim() }.filter { it.isNotBlank() && it.length <= 12 }.distinct()

    /**
     * Metro, tram, bus, taxi e bike sharing entro [radius] metri dalla stazione (OpenStreetMap).
     * Le fermate con lo stesso nome (es. i due lati della strada) vengono unite.
     */
    fun stationTransport(lat: Double, lon: Double, radius: Int = 400): StationTransport {
        val a = "(around:$radius,$lat,$lon)"
        val q = """
            [out:json][timeout:20];
            (
              node["highway"="bus_stop"]$a;
              node["public_transport"="platform"]["bus"="yes"]$a;
              nwr["railway"="tram_stop"]$a;
              node["public_transport"="stop_position"]["tram"="yes"]$a;
              nwr["railway"="station"]["station"="subway"]$a;
              node["railway"="subway_entrance"]$a;
              nwr["station"="light_rail"]$a;
              nwr["amenity"="taxi"]$a;
              nwr["amenity"="bicycle_rental"]$a;
            )->.s;
            .s out center tags;
            rel(bn.s)["route"~"^(subway|tram|bus|trolleybus|light_rail)$"];
            out body;
        """.trimIndent()
        // Postpass non ha i percorsi (relazioni): le linee arrivano solo dai tag route_ref delle fermate
        val json = query(q, lat, lon) {
            postpass(lat, lon, radius, "tags->>'highway' = 'bus_stop' OR (tags->>'public_transport' IN ('platform','stop_position') " +
                "AND (tags->>'bus' = 'yes' OR tags->>'tram' = 'yes')) OR tags->>'railway' IN ('tram_stop','subway_entrance') " +
                "OR tags->>'station' IN ('subway','light_rail') OR tags->>'amenity' IN ('taxi','bicycle_rental')") { radius }
        }
        // Linee che passano da ogni fermata, ricavate dai percorsi (relazioni) di OpenStreetMap
        val linesById = HashMap<Long, MutableSet<String>>()
        json.optJSONArray("elements")?.let { all ->
            for (i in 0 until all.length()) {
                val r = all.getJSONObject(i)
                if (r.optString("type") != "relation") continue
                val ref = r.optJSONObject("tags")?.optString("ref")?.trim().orEmpty()
                if (ref.isBlank() || ref.length > 12) continue
                val mem = r.optJSONArray("members") ?: continue
                for (k in 0 until mem.length()) {
                    val m = mem.getJSONObject(k)
                    if (m.optString("type") == "node") linesById.getOrPut(m.optLong("ref")) { HashSet() } += ref
                }
            }
        }
        val els = json.optJSONArray("elements") ?: return StationTransport(emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), lat, lon)
        val metro = mutableListOf<TransitStop>(); val tram = mutableListOf<TransitStop>(); val bus = mutableListOf<TransitStop>()
        val taxi = mutableListOf<TransitStop>(); val bikes = mutableListOf<TransitStop>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            if (e.optString("type") == "relation") continue
            val tj = e.optJSONObject("tags") ?: continue
            val t = tj.keys().asSequence().associateWith { tj.optString(it) }
            val relLines = linesById[e.optLong("id")]?.toList().orEmpty()
            val la = if (e.has("lat")) e.optDouble("lat") else e.optJSONObject("center")?.optDouble("lat") ?: continue
            val lo = if (e.has("lon")) e.optDouble("lon") else e.optJSONObject("center")?.optDouble("lon") ?: continue
            val d = dist(lat, lon, la, lo)
            val name = t["name"] ?: ""
            when {
                t["station"] == "subway" || t["railway"] == "subway_entrance" || t["station"] == "light_rail" -> {
                    // Gli ingressi spesso hanno solo il nome della stazione; le linee stanno sulla stazione
                    val lines = (linesOf(t) + relLines).distinct()
                    metro += TransitStop(name.ifBlank { tx("Ingresso metropolitana") }, lines, d, la, lo,
                        listOfNotNull(t["network"], if (t["wheelchair"] == "yes") tx("♿ accessibile") else null).joinToString(" · "))
                }
                t["railway"] == "tram_stop" || t["tram"] == "yes" -> tram += TransitStop(name.ifBlank { tx("Fermata tram") }, (linesOf(t) + relLines).distinct(), d, la, lo)
                t["highway"] == "bus_stop" || t["bus"] == "yes" -> bus += TransitStop(name.ifBlank { tx("Fermata bus") }, (linesOf(t) + relLines).distinct(), d, la, lo,
                    if (t["shelter"] == "yes") tx("pensilina") else "")
                t["amenity"] == "taxi" -> taxi += TransitStop(name.ifBlank { tx("Posteggio taxi") }, emptyList(), d, la, lo,
                    listOfNotNull(t["phone"] ?: t["contact:phone"], t["capacity"]?.let { "$it " + tx("posti") }).joinToString(" · "))
                t["amenity"] == "bicycle_rental" -> bikes += TransitStop(name.ifBlank { t["network"] ?: t["operator"] ?: tx("Bici in condivisione") },
                    emptyList(), d, la, lo, t["network"] ?: t["operator"] ?: "")
            }
        }
        fun merge(l: List<TransitStop>): List<TransitStop> = l.groupBy { it.name.lowercase() }.map { (_, g) ->
            val near = g.minBy { it.distance }
            near.copy(lines = g.flatMap { it.lines }.distinct().sortedWith(compareBy({ it.filter { c -> c.isDigit() }.toIntOrNull() ?: 9999 }, { it })),
                extra = g.map { it.extra }.filter { it.isNotBlank() }.distinct().joinToString(" · "))
        }.sortedBy { it.distance }
        return StationTransport(merge(metro).take(4), merge(tram).take(5), merge(bus).take(8), taxi.sortedBy { it.distance }.take(3),
            bikes.sortedBy { it.distance }.take(3), lat, lon)
    }

    /** Associa ogni ascensore/rampa al marciapiede più vicino e riassume per binario. */
    fun platformSummary(items: List<OsmPlace>): List<PlatformAccess> {
        val platforms = items.filter { it.kind == OsmPlace.Kind.PLATFORM && it.platformRef.isNotBlank() }
        if (platforms.isEmpty()) return emptyList()
        val elev = HashMap<OsmPlace, Int>()
        val ramps = HashMap<OsmPlace, Int>()
        items.filter { it.kind == OsmPlace.Kind.ELEVATOR || it.kind == OsmPlace.Kind.RAMP }.forEach { x ->
            val p = platforms.minByOrNull { dist(x.lat, x.lon, it.lat, it.lon) } ?: return@forEach
            if (dist(x.lat, x.lon, p.lat, p.lon) > 120) return@forEach
            if (x.kind == OsmPlace.Kind.ELEVATOR) elev[p] = (elev[p] ?: 0) + 1 else ramps[p] = (ramps[p] ?: 0) + 1
        }
        return platforms.map { p -> PlatformAccess(p.platformRef, elev[p] ?: 0, ramps[p] ?: 0, p.wheelchair) }
            .distinctBy { it.platform }
            .sortedWith(compareBy({ it.platform.filter { c -> c.isDigit() }.take(3).toIntOrNull() ?: 999 }, { it.platform }))
    }
}
