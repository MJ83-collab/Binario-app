package com.binario.treni.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Station
import com.binario.treni.data.tx
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tasti rapidi della Home, scelti dall'utente: funzioni dell'app (animali, notizie, WC…), un treno preciso,
 * il tabellone di una stazione o una tratta da cercare con un tocco. Salvati come JSON nelle preferenze.
 */
data class HomeShortcut(
    /** Id della funzione ([ShortcutCatalog]) oppure "train", "board", "trip". */
    val kind: String,
    /** Numero del treno (kind = "train"). */
    val number: String = "",
    /** Stazione del tabellone (board) o di partenza (trip). */
    val a: Station? = null,
    /** Stazione di arrivo (trip). */
    val b: Station? = null,
) {
    fun toJson(): JSONObject = JSONObject().put("k", kind).apply {
        if (number.isNotBlank()) put("n", number)
        a?.let { put("a", it.toJson()) }
        b?.let { put("b", it.toJson()) }
    }

    val key: String get() = kind + "|" + number + "|" + (a?.id ?: "") + "|" + (b?.id ?: "")

    companion object {
        fun from(o: JSONObject) = HomeShortcut(
            o.optString("k"), o.optString("n"),
            o.optJSONObject("a")?.let { Station.from(it) }, o.optJSONObject("b")?.let { Station.from(it) },
        )

        private const val PREF = "home_shortcuts"
        private val DEFAULT = listOf(HomeShortcut("news"), HomeShortcut("nearby"), HomeShortcut("animals"))

        fun load(ctx: Context): List<HomeShortcut> {
            val raw = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).getString(PREF, null) ?: return DEFAULT
            return try {
                val arr = JSONArray(raw)
                (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { from(it) } }
                    .filter { it.kind in setOf("train", "board", "trip") || ShortcutCatalog.find(it.kind) != null }
            } catch (_: Exception) {
                DEFAULT
            }
        }

        fun save(ctx: Context, list: List<HomeShortcut>) {
            val arr = JSONArray()
            list.forEach { arr.put(it.toJson()) }
            ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).edit().putString(PREF, arr.toString()).apply()
        }
    }
}

/** Funzioni dell'app che si possono aggiungere come tasto rapido: id, etichetta (italiano, tradotta con tx), icona, schermata. */
object ShortcutCatalog {
    data class Item(val id: String, val label: String, val icon: ImageVector, val route: String)

    val ITEMS = listOf(
        Item("bot", "Assistente treni", Icons.Filled.Forum, "bot"),
        Item("news", "Scioperi e notizie", Icons.Filled.Campaign, "news"),
        Item("guaranteed", "Treni garantiti in caso di sciopero", Icons.Filled.EventBusy, "guaranteed"),
        Item("animals", "Viaggiare con animali", Icons.Filled.Pets, "animals"),
        Item("assistance", "Assistenza", Icons.Filled.Accessible, "assistance"),
        Item("nearby", "Stazioni vicine", Icons.Filled.NearMe, "nearby"),
        Item("dae", "Defibrillatori", Icons.Filled.MonitorHeart, "dae?id=&name="),
        Item("toilets", "WC in stazione", Icons.Filled.Wc, "toilets?id=&name="),
        Item("taxi", "Taxi vicini", Icons.Filled.LocalTaxi, "taxi?id=&name="),
        Item("rbus", "Bus sostitutivi", Icons.Filled.DirectionsBus, "rbus?id=&name="),
        Item("sellers", "Punti vendita", Icons.Filled.Storefront, "sellers?id=&name="),
        Item("saved", "Orari offline", Icons.Filled.DownloadForOffline, "saved"),
        Item("reminders", "Allarmi", Icons.Filled.Alarm, "reminders"),
        Item("explore", "Esplora a voce", Icons.Filled.Explore, "explore"),
        Item("lost", "Oggetti smarriti", Icons.Filled.Luggage, "lost"),
        Item("conditions", "Diritti e rimborsi", Icons.Filled.Gavel, "conditions"),
        Item("malpensa", "Malpensa Express · tariffe", Icons.Filled.LocalAirport, "malpensa?from="),
        Item("fares", "Abbonamenti e biglietti Trenord", Icons.Filled.ConfirmationNumber, "fares"),
        Item("tilo", "TILO · Ticino e Lombardia", Icons.Filled.Train, "tilo"),
        Item("compare", "Confronta itinerari", Icons.Filled.CompareArrows, "compare"),
        Item("lines", "Tutte le linee", Icons.Filled.Route, "lines"),
        Item("green", "Quanto sei green", Icons.Filled.Eco, "green"),
        Item("settings", "Impostazioni", Icons.Filled.Settings, "settings"),
    )

    fun find(id: String): Item? = ITEMS.firstOrNull { it.id == id }
}

private fun HomeShortcut.label(): String = when (kind) {
    "train" -> tx("Treno") + " " + number
    "board" -> a?.name ?: ""
    "trip" -> (a?.name ?: "") + " → " + (b?.name ?: "")
    else -> ShortcutCatalog.find(kind)?.let { tx(it.label) } ?: kind
}

private fun HomeShortcut.icon(): ImageVector = when (kind) {
    "train" -> Icons.Filled.Train
    "board" -> Icons.Filled.DepartureBoard
    "trip" -> Icons.Filled.Directions
    else -> ShortcutCatalog.find(kind)?.icon ?: Icons.Filled.Star
}

/**
 * Riga dei tasti rapidi sotto "Cerca": tocca un tasto per aprire la funzione; "+" per aggiungerne uno,
 * "−" per scegliere quale togliere (con conferma).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeShortcutsSection(vm: MainViewModel, go: (String) -> Unit, onSearch: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(HomeShortcut.load(ctx)) }
    var adding by remember { mutableStateOf(false) }
    var removeMode by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<HomeShortcut?>(null) }
    var askTrain by remember { mutableStateOf(false) }
    var pickBoard by remember { mutableStateOf(false) }

    fun add(s: HomeShortcut) {
        if (list.any { it.key == s.key }) { toast(ctx, tx("Questo tasto c'è già")); return }
        list = list + s
        HomeShortcut.save(ctx, list)
    }

    fun open(s: HomeShortcut) {
        when (s.kind) {
            "train" -> go("train?num=" + Uri.encode(s.number))
            "board" -> s.a?.let { go("board?id=" + Uri.encode(it.id) + "&name=" + Uri.encode(it.name)) }
            "trip" -> if (s.a != null && s.b != null) {
                vm.from = s.a; vm.to = s.b
                vm.date = MainViewModel.roundToQuarter(System.currentTimeMillis())
                vm.search(); onSearch()
            }
            else -> ShortcutCatalog.find(s.kind)?.let { go(it.route) }
        }
    }

    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tx("Tasti rapidi"), fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f).padding(start = 4.dp))
            if (removeMode) TextButton({ removeMode = false }) { Text(tx("Fatto"), color = Green) }
            else {
                IconButton({ adding = true }) { Icon(Icons.Filled.Add, tx("Aggiungi tasto rapido"), tint = Green) }
                if (list.isNotEmpty()) IconButton({ removeMode = true }) { Icon(Icons.Filled.Remove, tx("Elimina tasto rapido"), tint = Green) }
            }
        }
        if (removeMode) Text(tx("Tocca il tasto da eliminare."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 2.dp))
        if (list.isEmpty()) Text(tx("Nessun tasto rapido: tocca + per aggiungere le funzioni che usi di più."), color = Muted, fontSize = 13.sp,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            list.forEach { s ->
                AssistChip(
                    onClick = { if (removeMode) confirm = s else open(s) },
                    label = { Text(s.label(), fontSize = 13.sp, maxLines = 1) },
                    leadingIcon = { Icon(s.icon(), null, tint = Green, modifier = Modifier.size(18.dp)) },
                    trailingIcon = { if (removeMode) Icon(Icons.Filled.Close, tx("Elimina"), tint = LateRed, modifier = Modifier.size(16.dp)) },
                )
            }
        }
    }

    if (adding) AlertDialog(
        onDismissRequest = { adding = false },
        title = { Text(tx("Aggiungi tasto rapido")) },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                item { AddRow(Icons.Filled.Train, tx("Un treno preciso (per numero)")) { adding = false; askTrain = true } }
                item { AddRow(Icons.Filled.DepartureBoard, tx("Tabellone di una stazione")) { adding = false; pickBoard = true } }
                item {
                    val a = vm.from; val b = vm.to
                    if (a != null && b != null && a.id != b.id) AddRow(Icons.Filled.Directions, tx("Questa tratta") + ": " + a.name + " → " + b.name) {
                        adding = false; add(HomeShortcut("trip", a = a, b = b))
                    }
                }
                item { HorizontalDivider(Modifier.padding(vertical = 4.dp)) }
                items(ShortcutCatalog.ITEMS.filter { c -> list.none { it.kind == c.id } }) { c ->
                    AddRow(c.icon, tx(c.label)) { adding = false; add(HomeShortcut(c.id)) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton({ adding = false }) { Text(tx("Annulla")) } },
    )

    if (askTrain) {
        var num by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { askTrain = false },
            title = { Text(tx("Un treno preciso (per numero)")) },
            text = {
                OutlinedTextField(num, { v -> num = v.filter { it.isDigit() }.take(6) }, singleLine = true,
                    label = { Text(tx("Numero del treno")) },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number))
            },
            confirmButton = {
                TextButton({ if (num.isNotBlank()) { add(HomeShortcut("train", number = num)); askTrain = false } }, enabled = num.isNotBlank()) {
                    Text(tx("Aggiungi"), color = Green)
                }
            },
            dismissButton = { TextButton({ askTrain = false }) { Text(tx("Annulla")) } },
        )
    }

    if (pickBoard) StationPickerDialog(tx("Tabellone di una stazione"), { pickBoard = false }) { s ->
        pickBoard = false
        add(HomeShortcut("board", a = s))
    }

    confirm?.let { s ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(tx("Eliminare il tasto rapido?")) },
            text = { Text("«" + s.label() + "»\n" + tx("Vuoi davvero eliminarlo? Potrai aggiungerlo di nuovo con +.")) },
            confirmButton = {
                TextButton({
                    list = list.filter { it.key != s.key }
                    HomeShortcut.save(ctx, list)
                    confirm = null
                    if (list.isEmpty()) removeMode = false
                }) { Text(tx("Elimina"), color = LateRed) }
            },
            dismissButton = { TextButton({ confirm = null }) { Text(tx("Annulla")) } },
        )
    }
}

@Composable
private fun AddRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Surface(onClick = onClick, color = Color.Transparent) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(14.dp))
            Text(label, fontSize = 15.sp)
        }
    }
}

/** App ufficiale AREU Lombardia per chiamare il 112 inviando la posizione. */
private const val AREU_APP = "it.Beta80Group.whereareu"

/**
 * Banner AREU (Agenzia Regionale Emergenza Urgenza): apre l'app «112 Where ARE U» se installata,
 * altrimenti la sua pagina su Google Play; il link sotto apre il sito AREU.
 */
@Composable
fun AreuHomeCard() {
    val ctx = LocalContext.current
    // App di emergenza del paese scelto (Impostazioni › Paese): AREU in Italia, Rega in Svizzera, nora in Germania
    val country = remember { com.binario.treni.data.Emergency.current(ctx) }
    val pkg = country.appPackage
    Surface(
        onClick = {
            val launch = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) ctx.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                openUrl(ctx, "https://play.google.com/store/apps/details?id=$pkg")
            }
        },
        shape = RoundedCornerShape(12.dp), color = Color(0xFF0D47A1),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.LocalHospital, null, tint = Color.White, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(country.flag + " " + country.appName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(country.appText, color = Color(0xEEFFFFFF), fontSize = 13.sp)
                }
            }
            Text((if (country == com.binario.treni.data.Emergency.Country.IT) tx("Sito AREU Lombardia") else tx("Sito ufficiale")) + " ›", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 42.dp, top = 6.dp).clickable { openUrl(ctx, country.appSite) })
        }
    }
}

