package com.binario.treni.data

import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/**
 * Mappa dei treni: campione dai tabelloni dei principali nodi d'Italia, Svizzera e Germania (partenze della prossima ora).
 * Non sono posizioni GPS: ogni treno è disposto attorno al nodo da cui parte.
 */
object TrainsMap {
    data class Dot(
        val country: String, val hub: String, val lat: Double, val lon: Double, val title: String, val dest: String,
        val delay: Int, val known: Boolean, val time: Long, val ref: TrainRef?, val refined: Boolean = false, val extra: TrenordGtfs.RunTrip? = null,
    )

    private class Hub(val country: String, val name: String, val station: Station?, val lat: Double, val lon: Double)

    private val IT = listOf(
        Hub("IT", "Roma Termini", Station("Roma Termini", "S08409"), 41.9009, 12.5016),
        Hub("IT", "Milano Centrale", Station("Milano Centrale", "S01700"), 45.4861, 9.2043),
        Hub("IT", "Napoli Centrale", Station("Napoli Centrale", "S09218"), 40.8530, 14.2720),
        Hub("IT", "Firenze S.M.N.", Station("Firenze S.M.N.", "S06421"), 43.7765, 11.2478),
        Hub("IT", "Bologna Centrale", Station("Bologna Centrale", "S05043"), 44.5058, 11.3430),
        Hub("IT", "Torino Porta Nuova", Station("Torino Porta Nuova", "S00219"), 45.0620, 7.6783),
        Hub("IT", "Venezia S. Lucia", Station("Venezia S. Lucia", "S02593"), 45.4410, 12.3210),
        Hub("IT", "Verona Porta Nuova", Station("Verona Porta Nuova", "S02430"), 45.4286, 10.9822),
        Hub("IT", "Genova Piazza Principe", Station("Genova Piazza Principe", "S04700"), 44.4160, 8.9213),
        Hub("IT", "Bari Centrale", Station("Bari Centrale", "S11119"), 41.1177, 16.8700),
        Hub("IT", "Roma Tiburtina", Station("Roma Tiburtina", "S08217"), 41.9105, 12.5309),
        Hub("IT", "Milano Rogoredo", Station("Milano Rogoredo", "S01820"), 45.4327, 9.2395),
        Hub("IT", "Padova", Station("Padova", "S02581"), 45.4175, 11.8806),
        Hub("IT", "Salerno", Station("Salerno", "S09818"), 40.6757, 14.7856),
    )
    private val CH = listOf("Zürich HB", "Bern", "Basel SBB", "Genève", "Lausanne", "Luzern", "Lugano", "Chiasso", "Bellinzona", "Winterthur", "St. Gallen", "Chur", "Olten")
    private val DE = listOf(
        "Berlin Hbf", "Hamburg Hbf", "München Hbf", "Köln Hbf", "Frankfurt (Main) Hbf", "Stuttgart Hbf", "Hannover Hbf",
        "Düsseldorf Hbf", "Nürnberg Hbf", "Leipzig Hbf", "Dresden Hbf", "Dortmund Hbf", "Bremen Hbf", "Essen Hbf",
    )

    private val resolved = ConcurrentHashMap<String, Hub>()
    @Volatile private var cache: Pair<Long, List<Dot>>? = null

    fun clearCache() { cache = null }

    private fun resolve(country: String, q: String): Hub? {
        resolved[country + q]?.let { return it }
        val st = (if (country == "CH") SwissLive.searchStations(q) else GermanyLive.searchStations(q)).firstOrNull() ?: return null
        val c = (if (country == "CH") SwissLive.coord(st.id) else GermanyLive.coord(st.id)) ?: return null
        return Hub(country, q.substringBefore(" ("), st, c.first, c.second).also { resolved[country + q] = it }
    }

    suspend fun load(force: Boolean = false): List<Dot> {
        if (!force) cache?.let { (at, l) -> if (System.currentTimeMillis() - at < 3 * 60_000L) return l }
        val now = System.currentTimeMillis()
        val gate = Semaphore(8)
        val out = coroutineScope {
            val jobs = IT.map { h -> async(Dispatchers.IO) { gate.withPermit { dots(h, now) } } } +
                CH.map { q -> async(Dispatchers.IO) { gate.withPermit { resolve("CH", q)?.let { dots(it, now) } ?: emptyList() } } } +
                DE.map { q -> async(Dispatchers.IO) { gate.withPermit { resolve("DE", q)?.let { dots(it, now) } ?: emptyList() } } }
            jobs.awaitAll().flatten()
        }
        if (out.isNotEmpty()) cache = now to out
        return out
    }

    private fun dots(h: Hub, now: Long): List<Dot> = try {
        val st = h.station ?: return emptyList()
        val list = Api.departures(st, now).filter { it.time in (now - 5 * 60_000L)..(now + 75 * 60_000L) }
            .distinctBy { it.number + "/" + it.time }.sortedBy { it.time }.take(24)
        val cosLat = Math.cos(Math.toRadians(h.lat)).coerceAtLeast(0.3)
        list.mapIndexed { k, b ->
            // Disposizione a spirale attorno al nodo, così i treni dello stesso nodo non si sovrappongono
            val angle = k * 2.399963
            val r = 0.016 * Math.sqrt(k + 0.5)
            Dot(
                h.country, h.name, h.lat + r * Math.sin(angle), h.lon + r * Math.cos(angle) / cosLat,
                "${b.category} ${b.number}".trim(), b.otherEnd, b.delay, b.inStation || b.delay != 0, b.time, b.ref,
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    /**
     * Posizione stimata dei treni italiani lungo la tratta: dall'andamento del treno (ultima fermata fatta e prossima) e dalle
     * coordinate delle stazioni, in proporzione all'orario. Non è GPS. Le posizioni arrivano a gruppi: [onBatch] riceve
     * (posizione nell'elenco → coordinate). I treni senza dati restano attorno al nodo.
     */
    suspend fun refine(base: List<Dot>, store: Store, onBatch: (Map<Int, Pair<Double, Double>>) -> Unit) {
        val found = ConcurrentHashMap<Int, Pair<Double, Double>>()
        val gate = Semaphore(6)
        val now = System.currentTimeMillis()
        var done = 0
        coroutineScope {
            base.mapIndexedNotNull { i, d -> if (d.country == "IT" && d.extra == null) i to d else null }.map { (i, d) ->
                async(Dispatchers.IO) {
                    gate.withPermit {
                        try { d.ref?.let { r -> position(Api.statusBasic(r), store, now)?.let { found[i] = it } } } catch (_: Exception) { }
                        val n = synchronized(found) { ++done }
                        if (n % 25 == 0) onBatch(HashMap(found))
                    }
                }
            }.awaitAll()
        }
        onBatch(HashMap(found))
    }

    private fun position(st: TrainStatus, store: Store, now: Long): Pair<Double, Double>? {
        if (st.cancelled || st.arrived || st.stops.size < 2) return null
        val s = st.stops
        val last = s.indexOfLast { it.passed }
        fun coord(i: Int) = Api.stationCoord(store, s[i].id)
        if (last < 0) return coord(0)
        if (last >= s.size - 1) return null
        val a = s[last]; val b = s[last + 1]
        val late = st.delay.coerceAtLeast(0) * 60_000L
        val dep = if (a.realDep > 0) a.realDep else a.schedDep + late
        val arr = b.schedArr + late
        val ca = coord(last) ?: return null
        val cb = coord(last + 1) ?: return ca
        val f = if (arr > dep) ((now - dep).toDouble() / (arr - dep)).coerceIn(0.0, 1.0) else 0.0
        return (ca.first + (cb.first - ca.first) * f) to (ca.second + (cb.second - ca.second) * f)
    }

    // ---------------- Posizioni GPS reali (Finlandia, Norvegia) ----------------

    private fun http(url: String, post: String? = null, headers: Map<String, String> = emptyMap()): String {
        val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 25000
            setRequestProperty("User-Agent", "Binario (Android app com.binario.treni)")
            setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
            if (post != null) { requestMethod = "POST"; doOutput = true; setRequestProperty("Content-Type", "application/json") }
        }
        try {
            if (post != null) c.outputStream.use { it.write(post.toByteArray()) }
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Treni con posizione GPS da fonti libere: Digitraffic (Finlandia) ed Entur (Norvegia). Un errore di una fonte non blocca l'altra. */
    @Volatile private var liveCache: Pair<Long, List<Dot>>? = null

    suspend fun loadLive(force: Boolean = false): List<Dot> {
        if (!force) liveCache?.let { (at, l) -> if (System.currentTimeMillis() - at < 90_000L) return l }
        val out = coroutineScope {
            listOf(async(Dispatchers.IO) { runCatching { finland() }.getOrDefault(emptyList()) },
                async(Dispatchers.IO) { runCatching { norway() }.getOrDefault(emptyList()) },
                async(Dispatchers.IO) { runCatching { transitous() }.getOrDefault(emptyList()) }).awaitAll().flatten()
        }
        if (out.isNotEmpty()) liveCache = System.currentTimeMillis() to out
        return out
    }

    // ---------------- Transitous (MOTIS) map/trips: treni in marcia lungo la linea ----------------

    private class Box(val code: String, val lat1: Double, val lon1: Double, val lat2: Double, val lon2: Double)

    // L'Italia resta ai dati di ViaggiaTreno; qui Germania, Austria, Svizzera e Francia
    private val EU_BOXES = listOf(
        Box("DE", 51.0, 5.8, 55.1, 15.1), Box("DE", 47.2, 5.8, 51.0, 13.9),
        Box("AT", 46.3, 13.9, 49.1, 17.2), Box("CH", 45.8, 5.9, 47.8, 10.5),
        Box("FR", 42.3, -1.8, 51.1, 8.2),
    )

    private fun parseInstant(s: String?): Long {
        if (s.isNullOrBlank()) return 0L
        return try { java.time.OffsetDateTime.parse(s).toInstant().toEpochMilli() } catch (_: Exception) {
            try { java.time.Instant.parse(s).toEpochMilli() } catch (_: Exception) { 0L }
        }
    }

    /** Polilinea codificata (Google, precisione 5 o 6) → elenco di (lat, lon). */
    private fun decodePolyline(enc: String, precision: Int): List<Pair<Double, Double>> {
        val f = Math.pow(10.0, precision.toDouble())
        val out = ArrayList<Pair<Double, Double>>()
        var i = 0; var lat = 0L; var lon = 0L
        while (i < enc.length) {
            var shift = 0; var r = 0L
            while (true) { val b = enc[i++].code - 63; r = r or ((b and 0x1f).toLong() shl shift); shift += 5; if (b < 0x20 || i >= enc.length) break }
            lat += if (r and 1L != 0L) (r shr 1).inv() else r shr 1
            shift = 0; r = 0L
            while (true) { val b = enc[i++].code - 63; r = r or ((b and 0x1f).toLong() shl shift); shift += 5; if (b < 0x20 || i >= enc.length) break }
            lon += if (r and 1L != 0L) (r shr 1).inv() else r shr 1
            out += (lat / f) to (lon / f)
        }
        return out
    }

    private fun along(pts: List<Pair<Double, Double>>, frac: Double): Pair<Double, Double>? {
        if (pts.isEmpty()) return null
        if (pts.size == 1) return pts[0]
        val cos = Math.cos(Math.toRadians(pts[0].first))
        val seg = DoubleArray(pts.size - 1) { k ->
            val dy = pts[k + 1].first - pts[k].first; val dx = (pts[k + 1].second - pts[k].second) * cos
            Math.sqrt(dx * dx + dy * dy)
        }
        val total = seg.sum()
        if (total <= 0.0) return pts[0]
        var target = total * frac.coerceIn(0.0, 1.0)
        for (k in seg.indices) {
            if (target <= seg[k] || k == seg.size - 1) {
                val t = if (seg[k] > 0) (target / seg[k]).coerceIn(0.0, 1.0) else 0.0
                return (pts[k].first + (pts[k + 1].first - pts[k].first) * t) to (pts[k].second + (pts[k + 1].second - pts[k].second) * t)
            }
            target -= seg[k]
        }
        return pts.last()
    }

    private fun transitous(): List<Dot> {
        val now = System.currentTimeMillis()
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val a = java.net.URLEncoder.encode(fmt.format(java.util.Date(now)), "UTF-8")
        val b = java.net.URLEncoder.encode(fmt.format(java.util.Date(now + 60_000L)), "UTF-8")
        val ua = mapOf("User-Agent" to "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)")
        val seen = HashSet<String>()
        val out = ArrayList<Dot>()
        for (box in EU_BOXES) {
            val body = try {
                http("https://api.transitous.org/api/v1/map/trips?zoom=8&min=${box.lat1},${box.lon1}&max=${box.lat2},${box.lon2}&startTime=$a&endTime=$b", headers = ua)
            } catch (_: Exception) { continue }
            val arr = try { org.json.JSONArray(body) } catch (_: Exception) { continue }
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val mode = o.optString("mode")
                if (!(mode.contains("RAIL") || mode == "SUBURBAN")) continue
                val dep = parseInstant(o.optString("departure")); val arrv = parseInstant(o.optString("arrival"))
                if (dep <= 0 || arrv <= dep || now < dep - 30_000L || now > arrv + 30_000L) continue
                val trip = o.optJSONArray("trips")?.optJSONObject(0)
                val name = (trip?.optString("routeShortName")?.takeIf { it.isNotBlank() && it != "null" }
                    ?: trip?.optString("displayName")?.takeIf { it.isNotBlank() && it != "null" } ?: "").trim()
                val id = (trip?.optString("tripId") ?: "") + "|" + name + "|" + dep
                if (!seen.add(id)) continue
                val pl = o.opt("polyline")
                val pts = when (pl) {
                    is String -> decodePolyline(pl, 5)
                    is org.json.JSONObject -> decodePolyline(pl.optString("points"), pl.optInt("precision", 5))
                    else -> emptyList()
                }
                val pos = along(pts, (now - dep).toDouble() / (arrv - dep)) ?: continue
                val sched = parseInstant(o.optString("scheduledDeparture"))
                val real = o.optBoolean("realTime")
                val delay = if (real && sched > 0) Math.round((dep - sched) / 60_000.0).toInt() else 0
                val dest = o.optJSONObject("to")?.optString("name")?.takeIf { it != "null" }.orEmpty()
                // Riferimento alla corsa (scheda del treno): prefisso Transitous del paese; la Svizzera usa quello tedesco (stesso servizio)
                val tripId = trip?.optString("tripId")?.takeIf { it.isNotBlank() && it != "null" }
                val px = if (box.code == "AT" || box.code == "FR") box.code else "DE"
                val tNum = trip?.optString("tripShortName")?.takeIf { it.isNotBlank() && it != "null" }?.trimStart('0').orEmpty()
                val ref = tripId?.let { TrainRef(tNum, "$px|$it", dep, name.ifBlank { mode }) }
                out += Dot(box.code, "Transitous", pos.first, pos.second, name.ifBlank { mode }, dest, delay, real && sched > 0, dep, ref)
            }
        }
        return out
    }

    private fun finland(): List<Dot> {
        val a = org.json.JSONArray(http("https://rata.digitraffic.fi/api/v1/train-locations/latest/", headers = mapOf("Digitraffic-User" to "Binario")))
        val now = System.currentTimeMillis()
        val out = ArrayList<Dot>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val xy = o.optJSONObject("location")?.optJSONArray("coordinates") ?: continue
            val lon = xy.optDouble(0, Double.NaN); val lat = xy.optDouble(1, Double.NaN)
            if (lat.isNaN() || lon.isNaN()) continue
            val t = try { java.time.Instant.parse(o.optString("timestamp")).toEpochMilli() } catch (_: Exception) { now }
            if (now - t > 15 * 60_000L) continue
            out += Dot("FI", "", lat, lon, "VR ${o.optInt("trainNumber")}", "", 0, false, t, null)
        }
        return out
    }

    private fun norway(): List<Dot> {
        val q = """{"query":"{ vehicles(mode: RAIL) { vehicleId line { lineRef lineName } location { latitude longitude } delay destinationName lastUpdated } }"}"""
        val root = org.json.JSONObject(http("https://api.entur.io/realtime/v2/vehicles/graphql", q, mapOf("ET-Client-Name" to "binario-app")))
        val a = root.optJSONObject("data")?.optJSONArray("vehicles") ?: return emptyList()
        val now = System.currentTimeMillis()
        val out = ArrayList<Dot>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val loc = o.optJSONObject("location") ?: continue
            val lat = loc.optDouble("latitude", Double.NaN); val lon = loc.optDouble("longitude", Double.NaN)
            if (lat.isNaN() || lon.isNaN()) continue
            val line = o.optJSONObject("line")
            val title = (line?.optString("lineName")?.takeIf { it.isNotBlank() && it != "null" } ?: line?.optString("lineRef").orEmpty()).ifBlank { o.optString("vehicleId") }
            val hasDelay = o.has("delay") && !o.isNull("delay")
            val delayMin = if (hasDelay) Math.round(o.optDouble("delay", 0.0) / 60.0).toInt() else 0
            out += Dot("NO", "", lat, lon, title, o.optString("destinationName").takeIf { it != "null" }.orEmpty(), delayMin, hasDelay, now, null)
        }
        return out
    }

    // ---------------- Trenord / FerrovieNord dalle fonti Trenord ----------------

    /**
     * Treni Trenord e FerrovieNord in marcia dall'orario ufficiale (feed GTFS di Trenord, Open Data Regione Lombardia): posizione
     * secondo l'orario. Il ritardo si aggiunge dopo con [refineTrenord]. Lancia un'eccezione se il feed non è disponibile.
     */
    fun trenordRuns(now: Long = System.currentTimeMillis()): List<Dot> = TrenordGtfs.running(now).mapNotNull { r ->
        val pos = r.at(now) ?: return@mapNotNull null
        val title = (r.line + " " + r.number).trim()
        val first = r.stops.first()
        Dot("IT", "Trenord", pos.first, pos.second, title, r.head, 0, false, r.first,
            TrainRef(r.number, first.id, r.midnight, title), false, r)
    }

    /**
     * Ritardo di ogni treno Trenord dal servizio live del sito Trenord; la posizione si sposta di conseguenza (orario − ritardo).
     * [onBatch] riceve (posizione nell'elenco → latitudine, longitudine, ritardo in minuti, dato live).
     */
    suspend fun refineTrenord(base: List<Dot>, onBatch: (Map<Int, Triple<Double, Double, Pair<Int, Boolean>>>) -> Unit) {
        val found = ConcurrentHashMap<Int, Triple<Double, Double, Pair<Int, Boolean>>>()
        val gate = Semaphore(4)
        val now = System.currentTimeMillis()
        var done = 0
        coroutineScope {
            base.mapIndexedNotNull { i, d -> d.extra?.let { i to it } }.map { (i, trip) ->
                async(Dispatchers.IO) {
                    gate.withPermit {
                        try {
                            Api.trenordDelayBest(trip.number, base[i].ref)?.let { (delay, live) ->
                                val p = trip.at(now - delay.coerceAtLeast(0) * 60_000L) ?: trip.at(now)
                                if (p != null) found[i] = Triple(p.first, p.second, delay to live)
                            }
                        } catch (_: Exception) { }
                        val n = synchronized(found) { ++done }
                        if (n % 20 == 0) onBatch(HashMap(found))
                    }
                }
            }.awaitAll()
        }
        onBatch(HashMap(found))
    }
}
