package com.binario.treni.data

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Informazioni della rete FERROVIENORD (gestore dell'infrastruttura delle linee Milano–Saronno–Varese/Como/Novara,
 * Milano–Asso, Saronno–Seregno, Brescia–Iseo–Edolo), dal sito ferrovienord.it e dal suo "PIR web":
 * - ascensori e scale mobili fuori servizio e banchine non accessibili (pagina "Comunicazioni accessibilità stazioni");
 * - stato impianti in tempo reale (maps.manutenzionefn.it);
 * - schede di accessibilità delle stazioni, assistenza alle persone con disabilità;
 * - defibrillatori (DAE) in tutte le stazioni;
 * - documenti della rete (prospetto informativo, indicatori di qualità, piano di utilizzo stazioni).
 */
object FerrovieNord {
    const val SITE = "https://www.ferrovienord.it"
    const val PIR = "https://www.ferrovienord.it/pirweb/"
    const val OUTAGES_URL = "https://www.ferrovienord.it/comunicazioni-accessibilita-stazioni/"
    const val LIVE_STATUS = "https://maps.manutenzionefn.it/"
    const val ACCESSIBILITY = "https://www.ferrovienord.it/accessibilita-stazioni/"
    const val PMR = "https://www.ferrovienord.it/accessibilita-pmr/"
    const val SHEETS_MILANO = "https://www.ferrovienord.it/wp-content/uploads/2026/07/Schede-tratte-MI.pdf"
    const val SHEETS_ISEO = "https://www.ferrovienord.it/wp-content/uploads/2026/07/Schede-tratte-IS.pdf"
    const val DEFIBRILLATORS = "https://www.ferrovienord.it/defibrillatori/"
    const val QUALITY_2026 = "https://www.ferrovienord.it/3d-flip-book/pirweb_allegato-indicatori-qualita-servizi-2026/"
    const val STATION_PLAN = "https://www.ferrovienord.it/3d-flip-book/pirweb-piano-utilizzo-stazioni/"
    const val LINES = "https://www.ferrovienord.it/3d-flip-book/pirweb-caratteristiche_linee_impianti/"
    const val NETWORK_STATEMENT = "https://www.ferrovienord.it/prospetto-informativo-rete/"
    const val PMR_WORKS = "https://www.ferrovienord.it/3d-flip-book/pirweb-2024-10-10-adeguamento-impianti-fn-alle-sti-pmr-pir-24_25"
    const val ASSIST_PHONE = "800210955"
    const val ASSIST_EMAIL = "disabili@trenord.it"
    const val ASSIST_PAGE = "https://www.trenord.it/assistenza/supporto/assistenza-viaggiatori-con-disabilita/"

    /** Un impianto non disponibile: stazione, cosa, da quando, fino a quando (previsto). */
    data class Outage(val station: String, val platform: String, val item: String, val since: String, val until: String) {
        /** Testo breve da mostrare o leggere a voce. */
        val text: String get() = listOf(item, platform.takeIf { it.isNotBlank() }?.let { I18n.tr("banchina non accessibile: ", "platform not accessible: ") + it })
            .filterNotNull().filter { it.isNotBlank() }.joinToString(" · ") +
            (if (until.isNotBlank()) " · " + I18n.tr("ripristino previsto il ", "expected back on ") + until else "")
    }

    @Volatile private var cache: Pair<Long, List<Outage>>? = null

    private fun http(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 15000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36 Binario")
            setRequestProperty("Accept-Language", "it-IT,it;q=0.9")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun text(h: String) = h.replace(Regex("(?is)<br\\s*/?>"), " ").replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&#8211;", "–").replace("&#8217;", "’").replace("&#039;", "'")
        .replace(Regex("\\s+"), " ").trim()

    /** Legge la tabella della pagina "Comunicazioni accessibilità stazioni" (5 colonne). */
    fun parseOutages(html: String): List<Outage> {
        val rows = Regex("(?is)<tr[^>]*>(.*?)</tr>").findAll(html).map { r ->
            Regex("(?is)<t[dh][^>]*>(.*?)</t[dh]>").findAll(r.groupValues[1]).map { text(it.groupValues[1]) }.toList()
        }.filter { it.size >= 5 }.toList()
        return rows.filter { c ->
            c[0].isNotBlank() && !c[0].equals("stazione", true) && !c[0].contains("STAZIONE") && (c[1].isNotBlank() || c[2].isNotBlank())
        }.map { c -> Outage(c[0].trim(), c[1].trim(), c[2].trim(), c[3].trim(), c[4].trim()) }
    }

    /** Impianti fuori servizio (letti dal sito al massimo ogni 30 minuti; in caso di errore l'ultimo elenco letto). */
    fun outages(force: Boolean = false): List<Outage> {
        val c = cache
        if (!force && c != null && System.currentTimeMillis() - c.first < 30 * 60_000L) return c.second
        return try {
            parseOutages(http(OUTAGES_URL)).also { cache = System.currentTimeMillis() to it }
        } catch (e: Exception) {
            c?.second ?: throw e
        }
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()

    /** Impianti fuori servizio in una stazione (confronto per nome). */
    fun outagesAt(stationName: String, list: List<Outage>): List<Outage> {
        val n = norm(stationName)
        if (n.isBlank()) return emptyList()
        return list.filter { o -> norm(o.station) == n }
    }
}
