package com.binario.treni.ui

// «Report correzioni» tradotto (stesso contenuto di FIXES_TEXT).

const val FIXES_TEXT_EN = """2.4 · IN PROGRESS
• Fixes in progress: they will be listed here on release
"""

const val FIXES_TEXT_DE = """2.4 · IN ARBEIT
• Laufende Korrekturen: Sie werden hier bei der Veröffentlichung aufgelistet
"""

const val FIXES_TEXT_FR = """2.4 · EN COURS
• Corrections en cours : elles seront listées ici à la publication
"""

const val FIXES_TEXT_ES = """2.4 · EN CURSO
• Correcciones en curso: se enumerarán aquí al publicar
"""

const val FIXES_TEXT_ZH = """2.4 · 进行中
• 正在进行的修复：发布时将列在此处
"""

const val FIXES_TEXT_JA = """2.4 · 作業中
• 進行中の修正：リリース時にここへ掲載します
"""

