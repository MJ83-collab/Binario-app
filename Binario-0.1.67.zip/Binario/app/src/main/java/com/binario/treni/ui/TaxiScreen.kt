package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.I18n
import com.binario.treni.data.Osm
import com.binario.treni.data.RadioTaxi
import com.binario.treni.data.Station
import com.binario.treni.data.TaxiPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun tr(a: String, b: String) = I18n.tr(a, b)

/**
 * Trova taxi: posteggi taxi fuori dalla stazione (o vicino a te) con distanza a piedi e mappa, radio taxi della città
 * con il numero da chiamare, società di taxi con telefono (OpenStreetMap) e app taxi.
 */
@Composable
fun TaxiScreen(vm: MainViewModel, station: Station?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var center by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var city by remember { mutableStateOf(station?.name) }
    var list by remember { mutableStateOf<List<TaxiPoint>?>(null) }
    var status by remember { mutableStateOf(tr("Ricerca della posizione…", "Finding your location…")) }
    var failed by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var granted by remember { mutableStateOf(hasLocation(ctx)) }
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions(),
    ) { r -> granted = r.values.any { it } }

    LaunchedEffect(station?.id, granted) {
        if (station != null) {
            center = withContext(Dispatchers.IO) { Api.stationCoord(vm.store, station.id) }
            if (center == null) status = tr("Coordinate della stazione non disponibili", "Station coordinates not available")
        } else if (granted) {
            val l = currentLocation(ctx)
            if (l == null) { status = tr("Posizione non disponibile: attiva il GPS.", "Location not available: turn on GPS."); return@LaunchedEffect }
            center = l.latitude to l.longitude
            // Città: dalla stazione più vicina
            city = withContext(Dispatchers.IO) {
                runCatching {
                    Api.allStations(ctx).minByOrNull { g ->
                        val d = FloatArray(1); android.location.Location.distanceBetween(l.latitude, l.longitude, g.lat, g.lon, d); d[0]
                    }?.station?.name
                }.getOrNull()
            }
        } else {
            launcher.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION))
            status = tr("Serve il permesso di posizione", "Location permission needed")
        }
    }
    LaunchedEffect(center, retry) {
        val c = center ?: return@LaunchedEffect
        list = null; failed = false
        status = tr("Cerco i posteggi taxi…", "Looking for taxi ranks…")
        list = try {
            withContext(Dispatchers.IO) { Osm.taxis(c.first, c.second) }
        } catch (e: Exception) {
            failed = true
            status = tr("I server OpenStreetMap non rispondono. Usa i numeri qui sotto o Google Maps.", "OpenStreetMap servers are not responding. Use the numbers below or Google Maps."); null
        }
    }
    val radio = city?.let { RadioTaxi.forStation(it) }
    val stands = list.orEmpty().filter { it.stand }
    val companies = list.orEmpty().filter { !it.stand }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(if (station != null) "Taxi · ${station.name}" else tr("Taxi vicini", "Nearby taxis"), onBack)
        if (vm.store.mapsEnabled) GreenTabs(listOf(tr("Elenco", "List"), tr("Mappa", "Map")), tab) { tab = it }
        val c = center
        if (tab == 1 && vm.store.mapsEnabled && c != null && list != null) {
            OsmMap(
                stands.map { MapPoint(it.lat, it.lon, it.name.ifBlank { tr("Posteggio taxi", "Taxi rank") },
                    "${it.distance} m" + (if (it.capacity.isNotBlank()) " · " + tr("posti", "spaces") + " " + it.capacity else "")) },
                drawLine = false, modifier = Modifier.fillMaxSize(),
                me = if (station == null) c else null, googleQuery = "taxi",
                target = if (station != null) MapPoint(c.first, c.second, station.name, tr("Stazione", "Station")) else null,
            )
            return@Column
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 6.dp)) {
            // Chiama un taxi: radio taxi della città e app
            item {
                WhiteCard {
                    CardTitle(tr("Chiama un taxi", "Call a taxi"))
                    if (radio != null) {
                        radio.second.forEach { n ->
                            MenuRow(Icons.Filled.Call, n.label, n.phone.chunked(3).joinToString(" ") + " · " + radio.first) { dial(ctx, n.phone) }
                        }
                    } else {
                        Text(tr("Per questa città non ho un numero di radio taxi verificato: usa un'app o cerca il numero.", "I don't have a verified radio taxi number for this city: use an app or search for the number."),
                            color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
                    }
                    MenuRow(Icons.Filled.Search, tr("Cerca il numero dei taxi", "Search for the taxi number") + (city?.let { " · " + it.substringBefore(" ").lowercase().replaceFirstChar { ch -> ch.uppercase() } } ?: ""), "") {
                        openUrl(ctx, "https://www.google.com/search?q=" + java.net.URLEncoder.encode("radio taxi " + (city?.substringBefore(" ") ?: "") + " numero", "UTF-8"))
                    }
                    MenuRow(Icons.Filled.LocalTaxi, "itTaxi", tr("App dei radio taxi italiani: chiami e paghi dall'app", "Italian radio taxi app: book and pay in the app")) { openUrl(ctx, "https://www.ittaxi.it") }
                    MenuRow(Icons.Filled.LocalTaxi, "FREENOW", tr("Taxi in molte città italiane", "Taxis in many Italian cities")) { openUrl(ctx, "https://www.free-now.com/it/") }
                    MenuRow(Icons.Filled.LocalTaxi, "Uber", tr("Uber Taxi nelle città dove è attivo", "Uber Taxi in cities where available")) { openUrl(ctx, "https://m.uber.com") }
                }
            }
            when {
                list == null -> item {
                    MessageBox(status)
                    if (failed) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        OutlinedButton({ retry++ }) { Text(tr("Riprova", "Retry"), color = Green) }
                    }
                    if (!granted && station == null) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Button({ launcher.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)) },
                            colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr("Concedi permesso", "Grant permission")) }
                    }
                }
                else -> {
                    item { SectionHeader(tr("Dove prendere il taxi", "Where to get a taxi")) }
                    if (stands.isEmpty()) item {
                        MessageBox(tr("Nessun posteggio taxi mappato entro 1,5 km. Di solito il posteggio è davanti all'uscita principale della stazione.",
                            "No taxi rank mapped within 1.5 km. The rank is usually in front of the station's main exit."))
                    }
                    items(stands) { t -> TaxiRow(t) }
                    if (companies.isNotEmpty()) {
                        item { SectionHeader(tr("Società di taxi della zona", "Local taxi companies")) }
                        items(companies) { t -> TaxiRow(t) }
                    }
                }
            }
            item {
                c?.let {
                    Column(Modifier.padding(horizontal = 8.dp)) {
                        GoogleMapsButtons(it.first, it.second, listOf(tr("Posteggi taxi", "Taxi ranks") to "taxi"))
                    }
                }
                Text(tr("Posteggi e telefoni da OpenStreetMap (volontari), radio taxi dai servizi cittadini: verifica sul posto. Il numero unico 112 è solo per le emergenze.",
                    "Ranks and phones from OpenStreetMap (volunteers), radio taxis from city services: check on site. 112 is for emergencies only."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun TaxiRow(t: TaxiPoint) {
    val ctx = LocalContext.current
    WhiteCard(onClick = {
        if (!t.stand && t.phone.isNotBlank()) dial(ctx, t.phone)
        else openUrl(ctx, "geo:${t.lat},${t.lon}?q=${t.lat},${t.lon}(Taxi)")
    }) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (t.stand) Icons.Filled.LocalTaxi else Icons.Filled.Call, null, tint = Green, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(t.name.ifBlank { if (t.stand) tr("Posteggio taxi", "Taxi rank") else "Taxi" }, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                val info = listOfNotNull(
                    if (t.stand && t.capacity.isNotBlank()) tr("posti", "spaces") + " " + t.capacity else null,
                    t.phone.takeIf { it.isNotBlank() }?.let { "📞 $it" },
                    t.hours.takeIf { it.isNotBlank() }?.let { "🕒 $it" },
                )
                if (info.isNotEmpty()) Text(info.joinToString(" · "), fontSize = 13.sp, color = Muted)
                Text(if (t.stand) tr("Tocca per aprire la posizione", "Tap to open the location") else tr("Tocca per chiamare", "Tap to call"), color = Green, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(if (t.distance < 1000) "${t.distance} m" else String.format("%.1f km", t.distance / 1000.0), fontWeight = FontWeight.Bold)
                if (t.stand) Text("${(t.distance / 80).coerceAtLeast(1)} " + tr("min a piedi", "min walk"), color = Muted, fontSize = 12.sp)
            }
        }
    }
}
