package com.binario.treni.data

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Registri ufficiali dei defibrillatori pubblicati come dati aperti (oltre a OpenStreetMap):
 * - Emilia-Romagna: Registro Regionale Unico dei Defibrillatori (circa 6900 DAE), pubblicato sul portale open data
 *   del Comune di Bologna (dataset "progetto-dae"), con indirizzo, posizione interna/esterna, disponibilità e orari.
 * La Lombardia (AREU) non pubblica il suo registro come dati aperti (solo la mappa sul sito e un'API riservata E015):
 * l'app apre la mappa ufficiale AREU.
 */
object DaeSources {
    const val ER_DATASET = "https://opendata.comune.bologna.it/explore/dataset/progetto-dae/"
    const val AREU_MAP = "https://www.areu.lombardia.it/web/home/mappa-dae-lombardia"
    const val TICINO_MAP = "https://tessin.momentum.surevive.ch/dae/index"

    fun inEmiliaRomagna(lat: Double, lon: Double) = lat in 43.7..45.15 && lon in 9.2..12.8
    fun inLombardy(lat: Double, lon: Double) = lat in 44.67..46.64 && lon in 8.49..11.43

    private fun http(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 15000
            setRequestProperty("User-Agent", "Binario (Android app com.binario.treni)")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun dist(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
        val r = FloatArray(1)
        android.location.Location.distanceBetween(lat1, lon1, lat2, lon2, r)
        return r[0].toInt()
    }

    /** DAE del registro regionale dell'Emilia-Romagna entro [radius] metri. */
    fun emiliaRomagna(lat: Double, lon: Double, radius: Int): List<Defibrillator> {
        if (!inEmiliaRomagna(lat, lon)) return emptyList()
        val where = URLEncoder.encode("within_distance(geo_point, geom'POINT($lon $lat)', ${radius}m)", "UTF-8")
        val o = JSONObject(http("https://opendata.comune.bologna.it/api/explore/v2.1/catalog/datasets/progetto-dae/records?limit=100&where=$where"))
        val a = o.optJSONArray("results") ?: return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val r = a.optJSONObject(i) ?: return@mapNotNull null
            val g = r.optJSONObject("geo_point") ?: return@mapNotNull null
            val la = g.optDouble("lat"); val lo = g.optDouble("lon")
            fun s(k: String) = if (r.isNull(k)) "" else r.optString(k).trim()
            val ubic = s("ubicazione").lowercase()
            val note = s("note")
            Defibrillator(
                name = s("nome").lowercase().split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } },
                where = listOf(s("indirizzo"), s("citta")).filter { it.isNotBlank() }.joinToString(", "),
                indoor = if (ubic.contains("esterno")) "no" else if (ubic.contains("interno")) "yes" else "",
                access = if (note.contains("libera", true)) "yes" else if (note.isNotBlank()) "customers" else "",
                hours = s("orari").ifBlank { if (note.contains("libera", true) && ubic.contains("esterno")) "24/7" else "" },
                operator = "", phone = s("telefono"), level = "", distance = dist(lat, lon, la, lo), lat = la, lon = lo,
            )
        }.sortedBy { it.distance }
    }
}
