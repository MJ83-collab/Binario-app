package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Soluzioni Italo con orari e prezzi per qualsiasi data, dal servizio di vendita usato dal sito italotreno.com
 * (big.ntvspa.it, "GetAvailableTrains"). Servizio non ufficiale: il parsing è difensivo e ogni errore dà "nessun dato".
 * Il prezzo è la tariffa più economica in vendita (di solito Smart); la 1ª classe è la tariffa "Prima" (ProductClass P).
 */
object ItaloBooking {
    private const val BASE = "https://big.ntvspa.it/BIG/v7/Rest/"
    private val lock = Any()
    @Volatile private var signature: String? = null
    @Volatile private var signedAt = 0L
    private val cache = ConcurrentHashMap<String, Pair<Long, List<Solution>>>()

    private fun post(path: String, body: JSONObject): JSONObject {
        val c = (URL(BASE + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 15000
            requestMethod = "POST"; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
        }
        try {
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (text.isBlank()) throw IOException("Italo HTTP $code")
            return JSONObject(text)
        } finally {
            c.disconnect()
        }
    }

    private fun sign(force: Boolean = false): String = synchronized(lock) {
        val now = System.currentTimeMillis()
        val old = signature
        if (!force && old != null && now - signedAt < 8 * 60_000L) return old
        val o = post(
            "SessionManager.svc/Login",
            JSONObject().put(
                "Login", JSONObject().put("Username", "WWW_Anonymous").put("Password", "Accenture\$1")
                    .put("Domain", "WWW").put("VersionNumber", "10.0.1"),
            ).put("SourceSystem", 2),
        )
        val s = o.optString("Signature").takeIf { it.isNotBlank() && it != "null" } ?: throw IOException("Italo: accesso non riuscito")
        signature = s
        signedAt = now
        s
    }

    private fun date(ms: Long) = "/Date($ms)/"

    /** "/Date(1730275200000+0100)/" → millisecondi (il numero è già UTC). */
    private fun parseDate(s: String?): Long {
        val m = Regex("Date\\((-?\\d+)").find(s ?: return 0L) ?: return 0L
        return m.groupValues[1].toLongOrNull() ?: 0L
    }

    /** Soluzioni Italo tra due stazioni (codici Italo, es. "MC_" → "RMT") con partenza tra start ed end. */
    fun search(fromCode: String, toCode: String, start: Long, end: Long, pax: Pax = Pax.ONE): List<Solution> {
        if (fromCode == toCode) return emptyList()
        val now = System.currentTimeMillis()
        val s0 = maxOf(start, now - 5 * 60_000L)
        if (end <= s0) return emptyList()
        // Cache 10 minuti per fascia (il calendario prezzi chiede molte fasce dello stesso giorno)
        val key = "$fromCode>$toCode@${s0 / 600_000L}-${end / 600_000L}#${pax.adults}/${pax.children}"
        cache[key]?.let { (t, v) -> if (now - t < 10 * 60_000L) return v }
        val res = try { request(fromCode, toCode, s0, end, sign(), pax) } catch (e: SessionExpired) { request(fromCode, toCode, s0, end, sign(force = true), pax) }
        cache[key] = now to res
        return res
    }

    private class SessionExpired : Exception()

    private fun request(a: String, b: String, start: Long, end: Long, sig: String, pax: Pax): List<Solution> {
        val req = JSONObject()
            .put("RoundTrip", false).put("DepartureStation", a).put("ArrivalStation", b)
            .put("IntervalStartDateTime", date(start)).put("IntervalEndDateTime", date(end))
            .put("RoundTripIntervalStartDateTime", date(start)).put("RoundTripIntervalEndDateTime", date(end))
            .put("AdultNumber", pax.adults.coerceIn(1, 9)).put("YoungNumber", 0).put("ChildNumber", pax.children.coerceIn(0, 9)).put("InfantNumber", 0).put("SeniorNumber", 0)
            .put("CurrencyCode", "EUR").put("ShowNestedSSR", true).put("IsGuest", true)
            .put("OverrideIntervalTimeRestriction", true).put("AvailabilityFilter", 1).put("FareClassControl", 0)
        val o = post("BookingManager.svc/GetAvailableTrains", JSONObject().put("GetAvailableTrains", req).put("Signature", sig).put("SourceSystem", 2))
        if (o.optInt("Code", 0) == 1033) throw SessionExpired()
        val markets = o.optJSONArray("JourneyDateMarkets") ?: return emptyList()
        val out = ArrayList<Solution>()
        for (i in 0 until markets.length()) {
            val js = markets.optJSONObject(i)?.optJSONArray("Journeys") ?: continue
            for (j in 0 until js.length()) journey(js.optJSONObject(j) ?: continue, a, b, pax.count)?.let { out += it }
        }
        return out.filter { it.dep in start..end }.distinctBy { it.dep.toString() + it.legs.joinToString { l -> l.number } }.sortedBy { it.dep }
    }

    private fun name(code: String) = ItaloLive.STATIONS[code] ?: code

    /** [people]: le tariffe Italo sono per persona; il totale è tariffa × passeggeri (stima per i ragazzi). */
    private fun journey(j: JSONObject, a: String, b: String, people: Int = 1): Solution? {
        val segs = j.optJSONArray("Segments") ?: return null
        val legs = ArrayList<Leg>()
        var price = 0.0
        var priced = true
        var first = 0.0
        var firstOk = true
        var soldOut = true
        for (k in 0 until segs.length()) {
            val s = segs.optJSONObject(k) ?: continue
            val stops = s.optJSONArray("Legs")
            val depCode = s.optString("DepartureStation").ifBlank { stops?.optJSONObject(0)?.optString("DepartureStation").orEmpty() }
            val arrCode = s.optString("ArrivalStation").ifBlank { stops?.optJSONObject((stops.length() - 1).coerceAtLeast(0))?.optString("ArrivalStation").orEmpty() }
            val dep = parseDate(s.optString("STD"))
            val arr = parseDate(s.optString("STA"))
            if (dep <= 0 || arr <= 0) return null
            val number = s.optString("TrainNumber").trim().ifBlank { Regex("\\b([89]\\d{3})\\b").find(j.optString("JourneySellKey"))?.value.orEmpty() }
            legs += Leg(number = number, category = "ITA", from = name(depCode.ifBlank { a }), to = name(arrCode.ifBlank { b }), dep = dep, arr = arr, operator = "Italo")
            val fares = fareList(s.optJSONArray("Fares"))
            if (fares.isNotEmpty()) soldOut = false
            val cheapest = fares.minOfOrNull { it.second }
            if (cheapest == null) priced = false else price += cheapest
            val prima = fares.filter { it.first == "P" }.minOfOrNull { it.second }
            if (prima == null) firstOk = false else first += prima
        }
        if (legs.isEmpty()) return null
        val dep = legs.first().dep
        val arr = legs.last().arr
        val n = people.coerceAtLeast(1)
        val p = if (priced) Math.round(price * n * 100) / 100.0 else null
        return Solution(
            from = legs.first().from, to = legs.last().to, dep = dep, arr = arr, duration = Fmt.duration(dep, arr),
            price = p, legs = legs, source = "italotreno.com",
            status = if (soldOut) "INHIBITED" else "SALEABLE",
            priceFirst = if (priced && firstOk) Math.round(first * n * 100) / 100.0 else null,
        )
    }

    /** (classe, prezzo) delle tariffe in vendita di un treno. Classe: S Smart, T Comfort, P Prima, C Club. */
    private fun fareList(a: JSONArray?): List<Pair<String, Double>> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val f = a.optJSONObject(i) ?: return@mapNotNull null
            if (f.optBoolean("SoldOut", false) || f.optBoolean("IsSoldOut", false)) return@mapNotNull null
            if (f.has("AvailableCount") && f.optInt("AvailableCount", 1) <= 0) return@mapNotNull null
            val p = farePrice(f) ?: return@mapNotNull null
            f.optString("ProductClass").uppercase() to p
        }
    }

    private val PRICE_KEYS = listOf("FullFarePrice", "TotalFarePrice", "TotalPrice", "FarePrice", "Price", "Amount", "TotalAmount", "PublishedFare")

    private fun farePrice(f: JSONObject): Double? {
        for (k in PRICE_KEYS) {
            if (!f.has(k) || f.isNull(k)) continue
            val v = f.opt(k)
            val d = when (v) {
                is Number -> v.toDouble()
                is String -> v.replace(',', '.').toDoubleOrNull()
                is JSONObject -> v.optDouble("Amount").takeIf { !it.isNaN() }
                else -> null
            }
            if (d != null && d > 0.5) return d
        }
        // Formato Navitaire: PaxFares[].ServiceCharges[] con la voce "FarePrice" (ChargeType 0)
        val pax = f.optJSONArray("PaxFares")?.optJSONObject(0)
        val ch = pax?.optJSONArray("ServiceCharges")
        if (ch != null) {
            var sum = 0.0
            for (i in 0 until ch.length()) {
                val c = ch.optJSONObject(i) ?: continue
                val type = c.optString("ChargeType")
                val amount = c.optDouble("Amount").takeIf { !it.isNaN() } ?: continue
                when {
                    type == "0" || type.equals("FarePrice", true) -> sum += amount
                    type.contains("Discount", true) || type == "1" -> sum -= amount
                }
            }
            if (sum > 0.5) return sum
        }
        return deepPrice(f, 0)
    }

    /** Ultima risorsa: il più piccolo importo positivo in un campo "…Price"/"…Amount" (esclusi sconti, tasse, punti). */
    private fun deepPrice(o: Any?, depth: Int): Double? {
        if (depth > 4) return null
        return when (o) {
            is JSONObject -> o.keys().asSequence().mapNotNull { k ->
                val v = o.opt(k)
                val bad = Regex("discount|tax|fee|point|percent|rate", RegexOption.IGNORE_CASE).containsMatchIn(k)
                when {
                    bad -> null
                    v is Number && Regex("price|amount", RegexOption.IGNORE_CASE).containsMatchIn(k) -> v.toDouble().takeIf { it > 0.5 }
                    v is JSONObject || v is JSONArray -> deepPrice(v, depth + 1)
                    else -> null
                }
            }.minOrNull()
            is JSONArray -> (0 until o.length()).mapNotNull { deepPrice(o.opt(it), depth + 1) }.minOrNull()
            else -> null
        }
    }
}
