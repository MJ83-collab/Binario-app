package com.binario.treni.data

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.TimeZone
import java.util.zip.ZipFile

/**
 * Orario ufficiale Trenord (feed GTFS) dagli Open Data della Regione Lombardia (dati.lombardia.it, dataset 3z4k-mxz9,
 * licenza CC BY 4.0, titolare Trenord). È la fonte PRINCIPALE degli orari dei bus sostitutivi Trenord: se non è
 * raggiungibile o non si legge, [ReplacementBus] ripiega su Transitous, che ripubblica lo stesso feed.
 *
 * Il file (circa 1,6 MB) si scarica una volta al giorno al massimo e resta nella cache dell'app. Le colonne si leggono
 * per nome dall'intestazione, così un cambio dell'ordine non rompe nulla. Gli orari sono programmati (nessun tempo reale).
 */
object TrenordGtfs {
    const val PAGE = "https://www.dati.lombardia.it/d/3z4k-mxz9"
    private const val META = "https://www.dati.lombardia.it/api/views/3z4k-mxz9.json"
    private const val FILES = "https://www.dati.lombardia.it/api/views/3z4k-mxz9/files/"
    private const val LEGACY = "https://www.dati.lombardia.it/download/3z4k-mxz9/application%2Fzip"
    private const val MAX_AGE_MS = 24 * 3600_000L
    private val rome = TimeZone.getTimeZone("Europe/Rome")

    @Volatile
    private var appCtx: Context? = null

    fun ensure(ctx: Context) {
        appCtx = ctx.applicationContext
    }

    /** Un bus Trenord in partenza da una fermata vicina. */
    data class Dep(val line: String, val headsign: String, val time: Long, val stopName: String, val lat: Double, val lon: Double)

    private class Table(val cols: Map<String, Int>, val rows: Sequence<List<String>>) {
        fun idx(name: String): Int = cols[name] ?: -1
    }

    private fun http(url: String, timeout: Int): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = timeout
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)")
        return c
    }

    private fun download(dest: File) {
        val urls = mutableListOf<String>()
        // L'identificativo del file cambia quando Trenord lo aggiorna: lo leggiamo dalla scheda del dataset
        try {
            val c = http(META, 20000)
            try {
                if (c.responseCode in 200..299) {
                    val id = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optString("blobId")
                    if (id.isNotBlank()) urls += FILES + id + "?download=true&filename=trenord_gtfs.zip"
                }
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
        }
        urls += LEGACY
        var last: Exception? = null
        for (u in urls) {
            val tmp = File(dest.path + ".tmp")
            try {
                val c = http(u, 90000)
                try {
                    if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                } finally {
                    c.disconnect()
                }
                // Un file ZIP comincia con "PK" e un feed vero pesa almeno qualche decina di KB
                val head = tmp.inputStream().use { val b = ByteArray(2); it.read(b); b }
                if (tmp.length() < 20_000 || head[0] != 'P'.code.toByte() || head[1] != 'K'.code.toByte()) throw IOException("File non valido")
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) throw IOException("Salvataggio non riuscito")
                return
            } catch (e: Exception) {
                last = e
                tmp.delete()
            }
        }
        throw last ?: IOException("Download non riuscito")
    }

    /** Il file in cache (scaricato se manca o ha più di un giorno; se la rete non va si usa quello vecchio). */
    private fun file(): File {
        val ctx = appCtx ?: throw IOException("Contesto non pronto")
        val f = File(ctx.cacheDir, "trenord_gtfs.zip")
        val fresh = f.exists() && System.currentTimeMillis() - f.lastModified() < MAX_AGE_MS
        if (!fresh) {
            try {
                download(f)
            } catch (e: Exception) {
                if (!f.exists()) throw e
            }
        }
        return f
    }

    /** Ultimo giorno coperto dal feed (aaaammgg), letto una volta per ogni file scaricato e tenuto accanto al file. 0 se non si sa. */
    fun validUntil(): Int {
        return try {
            val ctx = appCtx ?: return 0
            val zip = File(ctx.cacheDir, "trenord_gtfs.zip")
            if (!zip.exists()) return 0
            val side = File(ctx.cacheDir, "trenord_gtfs.until")
            if (side.exists() && side.lastModified() >= zip.lastModified()) return side.readText().trim().toIntOrNull() ?: 0
            val m = ZipFile(zip).use { z ->
                z.table("calendar_dates.txt") { t ->
                    val dt = t.idx("date")
                    var max = 0
                    if (dt >= 0) for (r in t.rows) {
                        val v = r.at(dt).toIntOrNull() ?: continue
                        if (v > max) max = v
                    }
                    max
                } ?: 0
            }
            side.writeText(m.toString())
            m
        } catch (e: Exception) {
            0
        }
    }

    private fun daysLeft(until: Int, now: Long): Int {
        val today = Calendar.getInstance(rome).apply {
            timeInMillis = now; set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val end = Calendar.getInstance(rome).apply { clear(); set(until / 10000, (until / 100) % 100 - 1, until % 100, 12, 0, 0) }
        return Math.round((end.timeInMillis - today.timeInMillis) / 86_400_000.0).toInt()
    }

    private fun niceDate(until: Int) = "%02d/%02d/%04d".format(until % 100, (until / 100) % 100, until / 10000)

    /**
     * Avviso da mostrare accanto ai bus: il file sta per scadere (14 giorni o meno) oppure è già scaduto (in quel caso
     * [buses] non lo usa più e l'app ripiega su Transitous). Null se va tutto bene o la data non è nota.
     */
    fun expiryNotice(now: Long = System.currentTimeMillis()): String? {
        val u = validUntil()
        if (u <= 0) return null
        val left = daysLeft(u, now)
        return when {
            left < 0 -> I18n.tr("Il file orari Trenord (Regione Lombardia) è scaduto il", "The Trenord timetable file (Lombardy Region) expired on") +
                " " + niceDate(u) + I18n.tr(": per Trenord si usano gli orari di Transitous.", ": Transitous timetables are used for Trenord instead.")
            left <= 14 -> I18n.tr("L'orario Trenord dei bus sostitutivi vale fino al", "The Trenord replacement-bus timetable is valid until") +
                " " + niceDate(u) + I18n.tr(". Dopo il cambio orario i bus possono mancare finché Trenord non pubblica il nuovo file.",
                ". After the timetable change buses may be missing until Trenord publishes the new file.")
            else -> null
        }
    }

    /** Divide una riga CSV: virgole, campi tra virgolette e virgolette doppie. */
    private fun split(line: String): List<String> {
        val out = ArrayList<String>(12)
        val sb = StringBuilder()
        var q = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                q && ch == '"' && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                ch == '"' -> q = !q
                ch == ',' && !q -> { out.add(sb.toString()); sb.setLength(0) }
                else -> sb.append(ch)
            }
            i++
        }
        out.add(sb.toString())
        return out
    }

    private inline fun <T> ZipFile.table(name: String, block: (Table) -> T): T? {
        val e = getEntry(name) ?: return null
        return getInputStream(e).use { s ->
            val r = BufferedReader(InputStreamReader(s, Charsets.UTF_8), 64 * 1024)
            val head = r.readLine()?.removePrefix("\uFEFF")
            if (head == null) null else {
                val cols = split(head).mapIndexed { i, n -> n.trim() to i }.toMap()
                block(Table(cols, generateSequence { r.readLine() }.filter { it.isNotBlank() }.map { split(it) }))
            }
        }
    }

    private fun List<String>.at(i: Int): String = if (i in indices) this[i].trim() else ""

    private fun seconds(t: String): Int {
        val p = t.split(":")
        if (p.size < 2) return -1
        return (p[0].toIntOrNull() ?: return -1) * 3600 + (p[1].toIntOrNull() ?: return -1) * 60 + (p.getOrNull(2)?.toIntOrNull() ?: 0)
    }

    private fun dist(la1: Double, lo1: Double, la2: Double, lo2: Double): Double {
        val r = 6371000.0
        val p1 = Math.toRadians(la1); val p2 = Math.toRadians(la2)
        val dp = p2 - p1; val dl = Math.toRadians(lo2 - lo1)
        val a = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2)
        return 2 * r * Math.asin(Math.sqrt(a))
    }

    private fun dayKey(c: Calendar) = c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH)

    /**
     * Bus (route_type 3 o 7xx) in partenza entro [radius] metri da (lat, lon) nelle prossime [hours] ore.
     * Lancia un'eccezione se il feed non si può scaricare o leggere: chi chiama ripiega su Transitous.
     *
     * Com'è fatto il feed (verificato sul file del 2/11/2026): niente calendar.txt, solo calendar_dates.txt (circa 385.000 righe,
     * quindi si tengono solo i servizi dei bus e i tre giorni che servono); niente trip_headsign (il capolinea è l'ultima fermata
     * della corsa); le fermate sono le stazioni (codici "S01700" come in ViaggiaTreno); le linee dei bus sostitutivi sono
     * route_type 3 («TN Bus sostitutivi», «R23», «RE_4»…).
     */
    fun buses(lat: Double, lon: Double, radius: Int, now: Long, hours: Int = 6): List<Dep> {
        val f = file()
        // Feed scaduto: meglio gli orari più recenti di Transitous (chi chiama ripiega da solo)
        val until = validUntil()
        if (until in 1..Int.MAX_VALUE && daysLeft(until, now) < 0) throw IOException("Feed scaduto il $until")
        return ZipFile(f).use { z ->
            // 1) fermate: nomi di tutte, posizione di quelle vicine
            val names = HashMap<String, String>()
            val near = HashMap<String, Triple<String, Double, Double>>()
            z.table("stops.txt") { t ->
                val id = t.idx("stop_id"); val nm = t.idx("stop_name"); val la = t.idx("stop_lat"); val lo = t.idx("stop_lon")
                if (id < 0 || la < 0 || lo < 0) throw IOException("stops.txt non riconosciuto")
                for (r in t.rows) {
                    names[r.at(id)] = r.at(nm)
                    val a = r.at(la).toDoubleOrNull() ?: continue
                    val b = r.at(lo).toDoubleOrNull() ?: continue
                    if (dist(lat, lon, a, b) <= radius) near[r.at(id)] = Triple(r.at(nm), a, b)
                }
            } ?: throw IOException("stops.txt mancante")
            if (near.isEmpty()) return emptyList()

            // 2) linee-bus: nome = nome lungo, preceduto dalla sigla se non ne è già contenuta
            class Route(val short: String, val label: String)
            val busRoutes = HashMap<String, Route>()
            z.table("routes.txt") { t ->
                val id = t.idx("route_id"); val ty = t.idx("route_type"); val sh = t.idx("route_short_name"); val lg = t.idx("route_long_name")
                if (id < 0 || ty < 0) throw IOException("routes.txt non riconosciuto")
                for (r in t.rows) {
                    val type = r.at(ty).toIntOrNull() ?: continue
                    if (type == 3 || type in 700..799) {
                        val short = r.at(sh); val long = r.at(lg)
                        val label = when {
                            long.isBlank() -> short
                            short.isBlank() || long.contains(short, ignoreCase = true) -> long
                            else -> "$short · $long"
                        }
                        busRoutes[r.at(id)] = Route(short, label)
                    }
                }
            } ?: throw IOException("routes.txt mancante")
            if (busRoutes.isEmpty()) return emptyList()

            // 3) corse dei bus
            class Trip(val route: String, val service: String, val head: String, val number: String)
            val trips = HashMap<String, Trip>()
            z.table("trips.txt") { t ->
                val id = t.idx("trip_id"); val ro = t.idx("route_id"); val sv = t.idx("service_id")
                val hs = t.idx("trip_headsign"); val sn = t.idx("trip_short_name")
                if (id < 0 || ro < 0 || sv < 0) throw IOException("trips.txt non riconosciuto")
                for (r in t.rows) {
                    val route = r.at(ro)
                    val rt = busRoutes[route] ?: continue
                    // "RE_4 - 2414" → "2414"; "2375A" resta com'è
                    val num = r.at(sn).substringAfterLast(" - ").trim()
                    trips[r.at(id)] = Trip(route, r.at(sv), r.at(hs), num)
                }
            } ?: throw IOException("trips.txt mancante")
            if (trips.isEmpty()) return emptyList()

            // 4) passaggi dei bus alle fermate vicine + ultima fermata di ogni corsa (il capolinea)
            class Call(val trip: String, val stop: String, val sec: Int)
            val calls = ArrayList<Call>()
            val last = HashMap<String, Pair<Int, String>>() // corsa -> (stop_sequence massimo, fermata)
            z.table("stop_times.txt") { t ->
                val tr = t.idx("trip_id"); val st = t.idx("stop_id"); val dp = t.idx("departure_time"); val ar = t.idx("arrival_time")
                val sq = t.idx("stop_sequence")
                if (tr < 0 || st < 0 || (dp < 0 && ar < 0)) throw IOException("stop_times.txt non riconosciuto")
                for (r in t.rows) {
                    val trip = r.at(tr)
                    if (trip !in trips) continue
                    val stop = r.at(st)
                    val seq = r.at(sq).toIntOrNull() ?: 0
                    val prev = last[trip]
                    if (prev == null || seq >= prev.first) last[trip] = seq to stop
                    if (stop !in near) continue
                    val s = seconds(r.at(if (dp >= 0) dp else ar).ifBlank { r.at(ar) })
                    if (s >= 0) calls.add(Call(trip, stop, s))
                }
            } ?: throw IOException("stop_times.txt mancante")
            if (calls.isEmpty()) return emptyList()

            // 5) i tre giorni che servono (ieri per le corse oltre la mezzanotte, oggi, domani)
            val cals = (-1..1).map { shift ->
                val c = Calendar.getInstance(rome)
                c.timeInMillis = now
                c.add(Calendar.DAY_OF_MONTH, shift)
                c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
                c
            }
            val wantedDays = cals.map { dayKey(it).toString() }.toSet()
            val services = trips.values.map { it.service }.toSet()

            // 6) servizio attivo: calendar.txt (se c'è) e calendar_dates.txt, tenendo solo servizi e giorni utili
            val weekly = HashMap<String, Triple<BooleanArray, Int, Int>>() // servizio -> (lun..dom, dal, al)
            z.table("calendar.txt") { t ->
                val sv = t.idx("service_id"); val s = t.idx("start_date"); val e = t.idx("end_date")
                val d = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday").map { t.idx(it) }
                if (sv >= 0 && s >= 0 && e >= 0 && d.all { it >= 0 }) {
                    for (r in t.rows) {
                        if (r.at(sv) !in services) continue
                        weekly[r.at(sv)] = Triple(BooleanArray(7) { i -> r.at(d[i]) == "1" }, r.at(s).toIntOrNull() ?: 0, r.at(e).toIntOrNull() ?: 99999999)
                    }
                }
            }
            val added = HashSet<String>(); val removed = HashSet<String>()
            z.table("calendar_dates.txt") { t ->
                val sv = t.idx("service_id"); val dt = t.idx("date"); val ex = t.idx("exception_type")
                if (sv >= 0 && dt >= 0 && ex >= 0) {
                    for (r in t.rows) {
                        val day = r.at(dt)
                        if (day !in wantedDays) continue
                        val service = r.at(sv)
                        if (service !in services) continue
                        if (r.at(ex) == "1") added.add("$service|$day") else if (r.at(ex) == "2") removed.add("$service|$day")
                    }
                }
            }

            fun active(service: String, c: Calendar): Boolean {
                val key = dayKey(c)
                val k = "$service|$key"
                if (k in removed) return false
                if (k in added) return true
                val d = weekly[service] ?: return false
                val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // lunedì = 0
                return d.first[dow] && key >= d.second && key <= d.third
            }

            // 7) orari assoluti
            val out = ArrayList<Dep>()
            val end = now + hours * 3600_000L
            for (c in cals) {
                val midnight = c.timeInMillis
                for (cl in calls) {
                    val abs = midnight + cl.sec * 1000L
                    if (abs < now || abs > end) continue
                    val trip = trips[cl.trip] ?: continue
                    if (!active(trip.service, c)) continue
                    val s = near[cl.stop] ?: continue
                    val route = busRoutes[trip.route]
                    val line = listOf(route?.label.orEmpty(), trip.number).filter { it.isNotBlank() && !(it == trip.number && route?.label.orEmpty().contains(it)) }.joinToString(" · ")
                    val head = trip.head.ifBlank { names[last[cl.trip]?.second.orEmpty()].orEmpty() }
                    // Il bus che finisce proprio in questa fermata non è una partenza
                    if (last[cl.trip]?.second == cl.stop && trip.head.isBlank()) continue
                    out.add(Dep(line, head, abs, s.first, s.second, s.third))
                }
            }
            out
        }
    }

    // ---------------- Treni in marcia (per la mappa) ----------------

    class RunStop(val id: String, val name: String, val lat: Double, val lon: Double, val arr: Long, val dep: Long)

    /** Una corsa ferroviaria di un giorno preciso: orari assoluti (ms) di tutte le fermate. */
    class RunTrip(val number: String, val line: String, val midnight: Long, val stops: List<RunStop>) {
        val head: String get() = stops.lastOrNull()?.name.orEmpty()
        val first: Long get() = stops.firstOrNull()?.dep ?: 0L
        val last: Long get() = stops.lastOrNull()?.arr ?: 0L

        /** Posizione all'istante [t] secondo l'orario (fra due fermate si interpola in linea retta). Null se non è in corsa. */
        fun at(t: Long): Pair<Double, Double>? {
            if (stops.size < 2 || t < first || t > last) return null
            for (i in stops.indices) {
                val s = stops[i]
                if (t in s.arr..s.dep) return s.lat to s.lon
                if (i < stops.size - 1) {
                    val n = stops[i + 1]
                    if (t > s.dep && t < n.arr) {
                        val f = (t - s.dep).toDouble() / (n.arr - s.dep).coerceAtLeast(1L)
                        return (s.lat + (n.lat - s.lat) * f) to (s.lon + (n.lon - s.lon) * f)
                    }
                }
            }
            return null
        }
    }

    @Volatile private var runKey = ""
    @Volatile private var runTrips: List<RunTrip> = emptyList()

    /**
     * Corse ferroviarie Trenord/FerrovieNord del feed ufficiale (route_type 2 o 1xx) di ieri e oggi, con gli orari assoluti delle fermate.
     * Si leggono una volta per giorno e per file scaricato. Lancia un'eccezione se il feed non c'è o è scaduto.
     */
    private fun railTrips(now: Long): List<RunTrip> {
        val f = file()
        val until = validUntil()
        if (until in 1..Int.MAX_VALUE && daysLeft(until, now) < 0) throw IOException("Feed scaduto il $until")
        val cals = (-1..0).map { shift ->
            Calendar.getInstance(rome).apply {
                timeInMillis = now; add(Calendar.DAY_OF_MONTH, shift)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
        }
        val key = dayKey(cals[1]).toString() + "|" + f.lastModified()
        if (key == runKey) return runTrips
        val out = ZipFile(f).use { z ->
            val stops = HashMap<String, Triple<String, Double, Double>>()
            z.table("stops.txt") { t ->
                val id = t.idx("stop_id"); val nm = t.idx("stop_name"); val la = t.idx("stop_lat"); val lo = t.idx("stop_lon")
                if (id < 0 || la < 0 || lo < 0) throw IOException("stops.txt non riconosciuto")
                for (r in t.rows) {
                    val a = r.at(la).toDoubleOrNull() ?: continue
                    val b = r.at(lo).toDoubleOrNull() ?: continue
                    stops[r.at(id)] = Triple(r.at(nm), a, b)
                }
            } ?: throw IOException("stops.txt mancante")
            val rail = HashMap<String, String>() // route_id -> sigla
            z.table("routes.txt") { t ->
                val id = t.idx("route_id"); val ty = t.idx("route_type"); val sh = t.idx("route_short_name")
                if (id < 0 || ty < 0) throw IOException("routes.txt non riconosciuto")
                for (r in t.rows) {
                    val type = r.at(ty).toIntOrNull() ?: continue
                    if (type == 2 || type in 100..199) rail[r.at(id)] = r.at(sh)
                }
            } ?: throw IOException("routes.txt mancante")
            class T(val route: String, val service: String, val number: String)
            val trips = HashMap<String, T>()
            z.table("trips.txt") { t ->
                val id = t.idx("trip_id"); val ro = t.idx("route_id"); val sv = t.idx("service_id"); val sn = t.idx("trip_short_name")
                if (id < 0 || ro < 0 || sv < 0) throw IOException("trips.txt non riconosciuto")
                for (r in t.rows) {
                    if (r.at(ro) !in rail) continue
                    val num = r.at(sn).substringAfterLast(" - ").trim().ifBlank { r.at(id) }
                    trips[r.at(id)] = T(r.at(ro), r.at(sv), num)
                }
            } ?: throw IOException("trips.txt mancante")
            val wanted = cals.map { dayKey(it).toString() }.toSet()
            val services = trips.values.map { it.service }.toSet()
            val weekly = HashMap<String, Triple<BooleanArray, Int, Int>>()
            z.table("calendar.txt") { t ->
                val sv = t.idx("service_id"); val s0 = t.idx("start_date"); val e0 = t.idx("end_date")
                val d = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday").map { t.idx(it) }
                if (sv >= 0 && s0 >= 0 && e0 >= 0 && d.all { it >= 0 }) {
                    for (r in t.rows) {
                        if (r.at(sv) !in services) continue
                        weekly[r.at(sv)] = Triple(BooleanArray(7) { i -> r.at(d[i]) == "1" }, r.at(s0).toIntOrNull() ?: 0, r.at(e0).toIntOrNull() ?: 99999999)
                    }
                }
            }
            val added = HashSet<String>(); val removed = HashSet<String>()
            z.table("calendar_dates.txt") { t ->
                val sv = t.idx("service_id"); val dt = t.idx("date"); val ex = t.idx("exception_type")
                if (sv >= 0 && dt >= 0 && ex >= 0) {
                    for (r in t.rows) {
                        val day = r.at(dt)
                        if (day !in wanted) continue
                        val service = r.at(sv)
                        if (service !in services) continue
                        if (r.at(ex) == "1") added.add("$service|$day") else if (r.at(ex) == "2") removed.add("$service|$day")
                    }
                }
            }
            fun active(service: String, c: Calendar): Boolean {
                val k = dayKey(c)
                if ("$service|$k" in removed) return false
                if ("$service|$k" in added) return true
                val d = weekly[service] ?: return false
                val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
                return d.first[dow] && k >= d.second && k <= d.third
            }
            // corse attive in almeno uno dei due giorni
            val activeDays = HashMap<String, List<Calendar>>()
            for ((id, tr) in trips) {
                val days = cals.filter { active(tr.service, it) }
                if (days.isNotEmpty()) activeDays[id] = days
            }
            class Row(val seq: Int, val stop: String, val arr: Int, val dep: Int)
            val rows = HashMap<String, MutableList<Row>>()
            z.table("stop_times.txt") { t ->
                val tr = t.idx("trip_id"); val st = t.idx("stop_id"); val dp = t.idx("departure_time"); val ar = t.idx("arrival_time"); val sq = t.idx("stop_sequence")
                if (tr < 0 || st < 0 || (dp < 0 && ar < 0)) throw IOException("stop_times.txt non riconosciuto")
                for (r in t.rows) {
                    val trip = r.at(tr)
                    if (trip !in activeDays) continue
                    val a = seconds(r.at(ar).ifBlank { r.at(dp) }); val d = seconds(r.at(dp).ifBlank { r.at(ar) })
                    if (a < 0 || d < 0) continue
                    rows.getOrPut(trip) { ArrayList() }.add(Row(r.at(sq).toIntOrNull() ?: 0, r.at(st), a, d))
                }
            } ?: throw IOException("stop_times.txt mancante")
            val res = ArrayList<RunTrip>()
            for ((id, list) in rows) {
                val tr = trips[id] ?: continue
                list.sortBy { it.seq }
                for (c in activeDays[id].orEmpty()) {
                    val mid = c.timeInMillis
                    val ss = list.mapNotNull { r ->
                        val st = stops[r.stop] ?: return@mapNotNull null
                        RunStop(r.stop, st.first, st.second, st.third, mid + r.arr * 1000L, mid + r.dep * 1000L)
                    }
                    if (ss.size >= 2) res += RunTrip(tr.number, rail[tr.route].orEmpty(), mid, ss)
                }
            }
            res
        }
        runTrips = out; runKey = key
        return out
    }

    /** La corsa [number] del feed (quella del giorno [date] se c'è, altrimenti una qualsiasi); null se il feed non c'è o non la contiene. */
    fun tripFor(number: String, date: Long, now: Long = System.currentTimeMillis()): RunTrip? = try {
        val all = railTrips(now).filter { it.number == number }
        all.firstOrNull { date > 0 && it.midnight == date } ?: all.firstOrNull()
    } catch (_: Exception) { null }

    /** Corse Trenord/FN in marcia adesso secondo l'orario ufficiale (senza ritardi). */
    fun running(now: Long = System.currentTimeMillis()): List<RunTrip> = railTrips(now).filter { now in it.first..it.last }
}
