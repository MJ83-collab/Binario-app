package com.binario.treni.data

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Statistiche di puntualità mensili dagli open data di TrovaTreno.it (licenza CC BY 4.0).
 * Puntuale = arrivo entro 5 minuti dall'orario previsto.
 */
data class PunctRow(
    val key: String, // operatore, codice stazione o numero treno
    val name: String,
    val extra: String, // categoria/operatore/destinazione
    val percent: Double,
    val avgDelay: Double,
    val observed: Int,
    val cancelled: Int,
    val onTime: Int,
    val severe: Int = 0,
    val category: String = "",
    val operator: String = "",
)

/** Tipo di servizio, per confrontare treni simili: regionali con regionali, alta velocità con alta velocità. */
enum class Segment(val itLabel: String, val enLabel: String) {
    REGIONAL("Regionali e suburbani", "Regional and suburban"),
    HIGH_SPEED("Alta velocità", "High speed"),
    INTERCITY("Intercity e lunga percorrenza", "Intercity and long distance");

    val label: String get() = I18n.tr(itLabel, enLabel)

    companion object {
        fun of(category: String, operator: String): Segment? {
            val c = category.uppercase().trim()
            return when {
                c in setOf("FR", "FA", "IT", "ITA") || operator.equals("italo", true) -> HIGH_SPEED
                c in setOf("IC", "ICN", "EC", "EN", "FB", "EXP") -> INTERCITY
                c in setOf("REG", "RV", "TN", "MET", "ARL", "S", "RE", "R", "SFM", "MXP", "TS", "LEX") -> REGIONAL
                c.isBlank() && operator.equals("trenord", true) -> REGIONAL
                else -> null // categoria sconosciuta: non la mescoliamo
            }
        }
    }
}

data class MonthStats(val month: String, val operators: List<PunctRow>, val stations: List<PunctRow>, val trains: List<PunctRow>) {
    val totalObserved: Int get() = operators.sumOf { it.observed }
    val totalOnTime: Int get() = operators.sumOf { it.onTime }
    val totalCancelled: Int get() = operators.sumOf { it.cancelled }
    val percent: Double get() = if (totalObserved == 0) 0.0 else totalOnTime * 100.0 / totalObserved

    fun train(number: String): List<PunctRow> = trains.filter { it.key == number }

    /**
     * Puntualità per tipo di servizio e operatore, ricalcolata dai dati per treno: così Trenord si confronta
     * con i regionali Trenitalia e non con Frecce e Intercity. Ritardo medio pesato sugli arrivi.
     */
    fun bySegment(): Map<Segment, List<PunctRow>> {
        val groups = trains.groupBy { Segment.of(it.category, it.operator) to it.operator }
        val out = HashMap<Segment, MutableList<PunctRow>>()
        groups.forEach { (k, list) ->
            val seg = k.first ?: return@forEach
            val obs = list.sumOf { it.observed }
            // Sotto i 100 arrivi osservati il confronto non è significativo
            if (obs < 100) return@forEach
            val on = list.sumOf { it.onTime }
            val canc = list.sumOf { it.cancelled }
            val ran = list.sumOf { (it.observed - it.cancelled).coerceAtLeast(0) }
            val avg = if (ran == 0) 0.0 else list.sumOf { it.avgDelay * (it.observed - it.cancelled).coerceAtLeast(0) } / ran
            val pctOk = if (ran == 0) 0.0 else on * 100.0 / ran
            val name = when {
                seg == Segment.HIGH_SPEED && k.second.equals("trenitalia", true) -> "Trenitalia · Frecce"
                seg == Segment.REGIONAL && k.second.equals("trenitalia", true) -> "Trenitalia · Regionale"
                else -> Stats.opName(k.second)
            }
            out.getOrPut(seg) { mutableListOf() } += PunctRow(k.second, name, "${list.size}", pctOk, avg, obs, canc, on, operator = k.second)
        }
        return out.mapValues { (_, v) -> v.sortedByDescending { it.percent } }
    }
    fun station(id: String, name: String): PunctRow? =
        stations.firstOrNull { it.key.substringAfter('_') == id } ?: stations.firstOrNull { it.name.equals(name, true) }
}

object Stats {
    private const val BASE = "https://www.trovatreno.it/open-data/"
    const val SOURCE = "TrovaTreno.it · open data CC BY 4.0"

    private fun get(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 40000
            setRequestProperty("User-Agent", "Binario/0.3 (Android)")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Divide una riga CSV con separatore ';' rispettando i campi tra virgolette. */
    private fun split(line: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var q = false
        for (ch in line) {
            when {
                ch == '"' -> q = !q
                ch == ';' && !q -> { out += sb.toString(); sb.setLength(0) }
                else -> sb.append(ch)
            }
        }
        out += sb.toString()
        return out.map { it.trim() }
    }

    private fun rows(csv: String): List<Map<String, String>> {
        val lines = csv.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return emptyList()
        val head = split(lines.first().removePrefix("﻿"))
        return lines.drop(1).map { l -> val v = split(l); head.indices.associate { head[it] to (v.getOrNull(it) ?: "") } }
    }

    private fun Map<String, String>.d(k: String) = this[k]?.replace(',', '.')?.toDoubleOrNull() ?: 0.0
    private fun Map<String, String>.i(k: String) = this[k]?.toIntOrNull() ?: 0

    private fun cacheFile(ctx: Context, kind: String, month: String) = File(ctx.cacheDir, "punct-$kind-$month.csv")

    private fun csv(ctx: Context, kind: String, month: String): String {
        val f = cacheFile(ctx, kind, month)
        // I mesi chiusi non cambiano: la copia locale resta valida (si riscarica dopo 7 giorni per sicurezza)
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < 7L * 24 * 3600_000) return f.readText()
        val t = get("${BASE}puntualita-$kind-$month.csv")
        f.writeText(t)
        return t
    }

    fun opName(op: String): String = when (op.lowercase()) {
        "trenord" -> "Trenord"
        "trenitalia" -> "Trenitalia"
        "italo" -> "Italo"
        "tper" -> "Trenitalia Tper"
        "eav" -> "EAV"
        "fdg" -> "Ferrovie del Gargano"
        "tua" -> "TUA Abruzzo"
        "bls" -> "BLS"
        "estero" -> I18n.tr("Imprese estere (ÖBB, DB)", "Foreign operators (ÖBB, DB)")
        "altro" -> I18n.tr("Altre imprese", "Other operators")
        else -> op.replaceFirstChar { it.uppercase() }
    }

    /**
     * TrovaTreno raggruppa in "altro" tutte le imprese diverse da Trenord, Trenitalia e Italo.
     * Le separiamo in base a destinazione e numero del treno. Verifiche sul codice impresa di ViaggiaTreno
     * (15/10/2026): REG 2451 Milano–Bologna, REG 19230 La Spezia–Parma e REG 90000 Vignola–Bologna = 18, Trenitalia Tper.
     * Napoli–Piedimonte Matese è una linea EAV; Foggia–Lucera è delle Ferrovie del Gargano; Domodossola–Berna/Briga è BLS.
     * Ciò che non si riconosce con sicurezza resta in "Altre imprese".
     */
    fun classifyOther(destination: String, number: String): String {
        val d = destination.uppercase()
        val n = number.toIntOrNull() ?: 0
        return when {
            d.contains("LUCERA") -> "fdg"
            d.contains("PIEDIMONTE") || ((d.contains("NAPOLI") || d.contains("CANCELLO")) && n in 7800..7899) -> "eav"
            d.contains("VASTO") && n in 90400..90499 -> "tua"
            d == "BERN" || d == "BRIG" || d.startsWith("BERN ") -> "bls"
            d.contains("WIEN") || d.contains("INNSBRUCK") || d.contains("STUTTGART") || d.contains("MUENCHEN") || d.contains("MÜNCHEN") ||
                d.contains("LIENZ") || (d.contains("VENEZIA") && n < 1000) -> "estero"
            n in 16950..18199 || n in 90000..90099 || n in 2440..2499 || n in 2060..2085 || n in 19200..19299 || n in 22450..22480 -> "tper"
            else -> "altro"
        }
    }

    /**
     * TrovaTreno chiama "Milano" sia Porta Garibaldi sia Centrale: se il nome è solo la città, usiamo lo slug
     * ("milano-porta-garibaldi" → "Milano Porta Garibaldi"), così la ricerca e l'elenco sono chiari.
     */
    fun stationName(name: String, slug: String): String {
        if (name.contains(' ') || !slug.contains('-')) return name
        val fromSlug = slug.split('-').filter { it.isNotBlank() }.joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
        return if (fromSlug.lowercase().startsWith(name.lowercase())) fromSlug else name
    }

    /** Stazioni del Passante ferroviario di Milano (linee S), per il filtro dedicato. */
    val PASSANTE_SLUGS = setOf(
        "milano-villapizzone", "milano-lancetti", "milano-porta-garibaldi", "milano-repubblica", "milano-porta-venezia",
        "milano-dateo", "milano-porta-vittoria", "milano-forlanini", "milano-rogoredo", "milano-certosa",
    )

    fun load(ctx: Context, month: String): MonthStats {
        val ops = rows(csv(ctx, "operatori", month)).map {
            PunctRow(it["operatore"] ?: "", opName(it["operatore"] ?: ""), "", it.d("puntualita_percento"), it.d("ritardo_medio_minuti"),
                it.i("n_osservazioni"), it.i("n_soppressi"), it.i("n_in_orario"))
        }
        val st = try {
            rows(csv(ctx, "stazioni", month)).map {
                PunctRow(it["codice_stazione"] ?: "", stationName(it["stazione"] ?: "", it["slug"] ?: ""), it["slug"] ?: "", it.d("puntualita_percento"),
                    it.d("ritardo_medio_minuti"), it.i("n_osservazioni"), it.i("n_soppressi"), it.i("n_in_orario"), it.i("n_ritardi_gravi"))
            }
        } catch (e: Exception) {
            emptyList()
        }
        val tr = try {
            rows(csv(ctx, "treni", month)).map {
                val raw = it["operatore"] ?: ""
                val op = if (raw.equals("altro", true)) classifyOther(it["destinazione"] ?: "", it["numero_treno"] ?: "") else raw
                PunctRow(it["numero_treno"] ?: "", "${it["categoria"] ?: ""} ${it["numero_treno"] ?: ""}".trim(),
                    "${opName(op)} → ${it["destinazione"] ?: ""}", it.d("puntualita_percento"),
                    it.d("ritardo_medio_minuti"), it.i("n_osservazioni"), it.i("n_soppressi"), it.i("n_in_orario"),
                    category = it["categoria"] ?: "", operator = op)
            }
        } catch (e: Exception) {
            emptyList()
        }
        return MonthStats(month, ops, st, tr)
    }

    /** Mesi disponibili: dal mese scorso all'indietro, tenendo quelli che esistono davvero. */
    fun availableMonths(ctx: Context, max: Int = 12): List<String> {
        val p = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE)
        val cached = p.getString("punct_months", null)
        val stamp = p.getLong("punct_months_at", 0L)
        if (cached != null && System.currentTimeMillis() - stamp < 24 * 3600_000L) return cached.split(',').filter { it.isNotBlank() }
        val fmt = SimpleDateFormat("yyyy-MM", Locale.US)
        val c = Calendar.getInstance()
        val out = mutableListOf<String>()
        var misses = 0
        for (k in 0 until max + 2) {
            val m = fmt.format(c.time)
            c.add(Calendar.MONTH, -1)
            val ok = cacheFile(ctx, "operatori", m).exists() || try {
                csv(ctx, "operatori", m); true
            } catch (e: Exception) {
                false
            }
            if (ok) {
                out += m; misses = 0
            } else if (out.isNotEmpty() && ++misses >= 2) break
            if (out.size >= max) break
        }
        // Se la rete non c'era non salviamo un elenco vuoto, altrimenti le statistiche resterebbero "non disponibili" per un giorno
        if (out.isNotEmpty()) p.edit().putString("punct_months", out.joinToString(",")).putLong("punct_months_at", System.currentTimeMillis()).apply()
        else if (cached != null) return cached.split(',').filter { it.isNotBlank() }
        return out
    }

    fun monthLabel(m: String): String = try {
        val d = SimpleDateFormat("yyyy-MM", Locale.US).parse(m)!!
        SimpleDateFormat("MMMM yyyy", I18n.locale).format(d).replaceFirstChar { it.uppercase() }
    } catch (e: Exception) {
        m
    }
}
