package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.R
import com.binario.treni.data.Sources
import com.binario.treni.data.Strike
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

private data class DrawerEntry(val icon: ImageVector, val label: String, val route: String)

/**
 * Menù laterale della Home (☰): tutte le sezioni dell'app in un posto, raggruppate, come nelle app di orari.
 * Le schede in basso restano; qui si arriva in un tocco anche alle funzioni "nascoste" in Altro.
 */
@Composable
fun HomeDrawerContent(go: (String) -> Unit, onClose: () -> Unit, onShare: () -> Unit) {
    val groups = listOf(
        tx("Viaggio") to listOf(
            DrawerEntry(Icons.Filled.CalendarMonth, tx("Prezzi migliori"), "prices"),
            DrawerEntry(Icons.Filled.Forum, tx("Assistente treni"), "bot"),
            DrawerEntry(Icons.Filled.Map, com.binario.treni.data.I18n.tr("Mappa dei treni", "Train map"), "trainsmap"),
            DrawerEntry(Icons.Filled.DownloadForOffline, tx("Orari offline"), "saved"),
            DrawerEntry(Icons.Filled.Alarm, tx("Allarmi"), "reminders"),
            DrawerEntry(Icons.Filled.Route, tx("Tutte le linee"), "lines"),
            DrawerEntry(Icons.Filled.Public, tx("Treni in Germania"), "germany"),
            DrawerEntry(Icons.Filled.Public, tx("Treni in Austria"), "austria"),
            DrawerEntry(Icons.Filled.Public, tx("Treni in Francia"), "france"),
        ),
        tx("Accessibilità") to listOf(
            DrawerEntry(Icons.Filled.Explore, tx("Esplora a voce"), "explore"),
            DrawerEntry(Icons.Filled.Accessible, tx("Assistenza disabili in viaggio"), "assistance"),
            DrawerEntry(Icons.Filled.Tune, tx("Daltonici, voce e vibrazione"), "settings"),
        ),
        tx("Scioperi e notizie") to listOf(
            DrawerEntry(Icons.Filled.Campaign, tx("Scioperi e notizie"), "news"),
            DrawerEntry(Icons.Filled.EventAvailable, tx("Treni garantiti"), "guaranteed"),
        ),
        tx("In stazione") to listOf(
            DrawerEntry(Icons.Filled.NearMe, tx("Stazioni vicine"), "nearby"),
            DrawerEntry(Icons.Filled.Wc, tx("WC vicini"), "toilets?id=&name="),
            DrawerEntry(Icons.Filled.ConfirmationNumber, tx("Rivendite e biglietterie vicine"), "sellers?id=&name="),
            DrawerEntry(Icons.Filled.MonitorHeart, com.binario.treni.data.I18n.tr("Defibrillatori (DAE)", "Defibrillators (AED)"), "dae?id=&name="),
        ),
        tx("Biglietti") to listOf(
            DrawerEntry(Icons.Filled.LocalActivity, tx("Biglietti e abbonamenti"), "tickets"),
            DrawerEntry(Icons.Filled.Euro, tx("Tariffe"), "fares"),
        ),
        tx("App") to listOf(
            DrawerEntry(Icons.Filled.Settings, tx("Impostazioni"), "settings"),
            DrawerEntry(Icons.Filled.HelpOutline, tx("Aiuto e FAQ"), "help"),
            DrawerEntry(Icons.Filled.NewReleases, tx("Novità"), "changelog"),
            DrawerEntry(Icons.Filled.Feedback, tx("Invia un feedback"), "feedback?bug=false"),
        ),
    )
    ModalDrawerSheet(Modifier.widthIn(max = 320.dp)) {
        Column(Modifier.fillMaxHeight().verticalScroll(rememberScrollState())) {
            // Intestazione con la nuova icona
            Row(Modifier.fillMaxWidth().background(Green).padding(horizontal = 20.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF3F8F3A))) {
                    Icon(painterResource(R.drawable.ic_launcher_fg), null, tint = Color.Unspecified, modifier = Modifier.fillMaxSize())
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Binario", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Text(APP_VERSION, color = Color(0xDDFFFFFF), fontSize = 13.sp)
                    TextButton(
                        { if (!ManualUpdate.checking) { ManualUpdate.request++ } },
                        contentPadding = PaddingValues(0.dp),
                    ) {
                        Text(if (ManualUpdate.checking) tx("Controllo in corso…") else tx("Cerca aggiornamenti"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            groups.forEach { (title, items) ->
                Text(title, color = Green, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 28.dp, top = 14.dp, bottom = 4.dp))
                items.forEach { e ->
                    NavigationDrawerItem(
                        label = { Text(e.label) }, selected = false,
                        icon = { Icon(e.icon, null, tint = Green) },
                        onClick = { onClose(); go(e.route) },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    )
                }
            }
        }
    }
}

private val dmy = SimpleDateFormat("dd/MM/yyyy", Locale.ITALY)

private fun parseDay(s: String): Long? = try { dmy.parse(s.trim().take(10))?.time } catch (_: Exception) { null }

/**
 * Riquadro in Home con il prossimo sciopero dei treni (come "prossimi scioperi" di altre app):
 * date, aziende, area e i collegamenti ai treni garantiti. Compare solo se c'è uno sciopero nei prossimi 30 giorni.
 */
@Composable
fun NextStrikeCard(onNews: () -> Unit, onGuaranteed: () -> Unit) {
    var strikes by remember { mutableStateOf(NewsCache.strikes) }
    LaunchedEffect(Unit) {
        if (strikes == null || System.currentTimeMillis() - NewsCache.at > 30 * 60_000L) {
            val l = withContext(Dispatchers.IO) { runCatching { Sources.railStrikes() }.getOrNull() }
            if (l != null) { strikes = l; NewsCache.strikes = l; NewsCache.at = System.currentTimeMillis() }
        }
    }
    val today = com.binario.treni.data.Fmt.midnight()
    val next: List<Strike> = strikes.orEmpty().filter { Sources.isTrainStrike(it) }.mapNotNull { st ->
        val a = parseDay(st.start) ?: return@mapNotNull null
        val b = parseDay(st.end.ifBlank { st.start }) ?: a
        if (b >= today && a <= today + 30 * 86_400_000L) st to a else null
    }.sortedBy { it.second }.map { it.first }
    val st = next.firstOrNull() ?: return
    WhiteCard(onClick = onNews) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Block, null, tint = LateRed)
                Spacer(Modifier.width(10.dp))
                Text(tx("Prossimo sciopero dei treni"), fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                if (next.size > 1) Text("+${next.size - 1}", color = Muted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text(st.start.take(5) + (if (st.end.isNotBlank() && st.end != st.start) " → " + st.end.take(5) else "") + " · " + st.company.take(70),
                fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            val area = listOf(st.relevance, st.region).filter { it.isNotBlank() }.joinToString(" · ")
            if (area.isNotBlank()) Text(area, color = Muted, fontSize = 13.sp)
            if (st.modality.isNotBlank()) Text(st.modality.take(140), color = Muted, fontSize = 12.sp)
            Row {
                TextButton(onGuaranteed, contentPadding = PaddingValues(horizontal = 0.dp)) { Text(tx("Treni garantiti") + " ›", color = Green) }
                Spacer(Modifier.width(16.dp))
                TextButton(onNews, contentPadding = PaddingValues(horizontal = 0.dp)) { Text(tx("Dettagli") + " ›", color = Green) }
            }
        }
    }
}
