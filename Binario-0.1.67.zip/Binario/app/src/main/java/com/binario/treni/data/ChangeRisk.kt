package com.binario.treni.data

/**
 * Valuta se un cambio tra due treni è a rischio. Il tempo minimo consigliato dipende dalla stazione
 * (le grandi stazioni hanno binari lontani e molta gente), dal tipo di treni (un regionale in ritardo fa perdere
 * la Freccia o l'Italo, che non aspetta) e dal cambio di stazione.
 */
object ChangeRisk {
    enum class Level { OK, TIGHT, RISKY, MISSED }

    private val BIG = listOf(
        "MILANO CENTRALE", "MILANO PORTA GARIBALDI", "MILANO ROGOREDO", "ROMA TERMINI", "ROMA TIBURTINA", "NAPOLI CENTRALE",
        "FIRENZE SANTA MARIA NOVELLA", "FIRENZE S M N", "FIRENZE S.M.N.", "BOLOGNA CENTRALE", "BOLOGNA C LE", "TORINO PORTA NUOVA",
        "TORINO PORTA SUSA", "VENEZIA SANTA LUCIA", "VENEZIA S LUCIA", "VENEZIA MESTRE", "VERONA PORTA NUOVA", "GENOVA PIAZZA PRINCIPE",
        "GENOVA BRIGNOLE", "BARI CENTRALE", "PALERMO CENTRALE", "ZURICH HB", "ZÜRICH HB", "RHO FIERA",
    )
    private val FAST = listOf("FR", "FA", "FB", "ITA", "IC", "ICN", "EC", "EN", "TGV", "RJ")

    private fun norm(s: String) = s.uppercase().replace(Regex("[^A-Z0-9ÀÈÉÌÒÙÜ]+"), " ").trim()
        .replace(Regex("\\bC LE\\b"), "CENTRALE").replace(Regex("\\b(FS|RFI|FN)\\b"), "").replace(Regex("\\s+"), " ").trim()

    private fun isFast(l: Leg): Boolean {
        val c = l.category.uppercase().trim()
        return FAST.any { c == it || c.startsWith("$it ") } || c.contains("FRECCIA") || c.contains("ITALO")
    }

    /** Minuti consigliati per cambiare tra [prev] e [next]. */
    fun needed(prev: Leg, next: Leg): Int {
        val a = norm(prev.to)
        val b = norm(next.from)
        // Cambio di stazione (es. Milano Cadorna → Milano Centrale): servono metro o bus
        if (a.isNotEmpty() && b.isNotEmpty() && a != b && !a.startsWith(b) && !b.startsWith(a)) return 30
        val st = b.ifEmpty { a }
        var need = if (BIG.any { st == norm(it) || st.startsWith(norm(it)) }) 15 else 8
        // Da un regionale a un treno veloce prenotato: margine in più per i ritardi
        if (!isFast(prev) && isFast(next)) need += 3
        if (!prev.isTrain || !next.isTrain) need = maxOf(need, 10)
        return need
    }

    fun level(gapMin: Int, need: Int): Level = when {
        gapMin < 0 -> Level.MISSED
        gapMin < 5 || gapMin < need / 2 -> Level.RISKY
        gapMin < need -> Level.TIGHT
        else -> Level.OK
    }
}
