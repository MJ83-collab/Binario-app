package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Calendar
import java.util.TimeZone

/**
 * Treni Italo in tempo reale (ViaggiaTreno non li ha). Usa il servizio pubblico del sito "Italo in viaggio":
 * - RicercaTrenoService?TrainNumber=9920 → fermate, orari previsti e stimati, ritardo;
 * - RicercaStazioneService?CodiceStazione=MC_ → prossime partenze e arrivi Italo di una stazione.
 * Servizio non ufficiale: il parsing è difensivo e ogni errore restituisce "nessun dato".
 */
object ItaloLive {
    const val PREFIX = "ITALO"
    const val SOURCE = "italoinviaggio.italotreno.com"
    private const val BASE = "https://italoinviaggio.italotreno.com/api/"
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")

    /** Stazioni servite da Italo con il loro codice (dalla pagina stazioni di Italo in viaggio). */
    val STATIONS: Map<String, String> = linkedMapOf(
        "AGR" to "Agropoli", "FF_" to "Ancona", "BAC" to "Bari Centrale", "BLT" to "Barletta", "BEN" to "Benevento",
        "BGM" to "Bergamo", "BIG" to "Bisceglie", "BC_" to "Bologna Centrale", "BLZ" to "Bolzano", "BSC" to "Brescia",
        "CEA" to "Caserta", "CON" to "Conegliano", "DSG" to "Desenzano", "F__" to "Ferrara",
        "SMN" to "Firenze Santa Maria Novella", "FG_" to "Foggia", "GB_" to "Genova Brignole", "G__" to "Genova Piazza Principe",
        "LON" to "Lamezia Terme Centrale", "LTL" to "Latisana Lignano Bibione", "MRT" to "Maratea", "MC_" to "Milano Centrale",
        "RRO" to "Rho Fiera", "RG_" to "Milano Rogoredo", "ML_" to "Molfetta", "MNF" to "Monfalcone",
        "NAF" to "Napoli Afragola", "NAC" to "Napoli Centrale", "PD_" to "Padova", "PAR" to "Paola", "PY_" to "Pesaro",
        "PSY" to "Peschiera del Garda", "22187" to "Pisa Centrale", "PNE" to "Pordenone", "PGR" to "Portogruaro Caorle",
        "RCE" to "Reggio Calabria Centrale", "AAV" to "Reggio Emilia AV", "RO_" to "Riccione", "J__" to "Rimini",
        "RMT" to "Roma Termini", "RTB" to "Roma Tiburtina", "RUT" to "Rosarno", "RVR" to "Rovereto", "R__" to "Rovigo",
        "SAL" to "Salerno", "SRI" to "Sapri", "SDC" to "Scalea", "TOP" to "Torino Porta Nuova", "OUE" to "Torino Porta Susa",
        "TR_" to "Trani", "TCN" to "Trento", "TVC" to "Treviso Centrale", "TSC" to "Trieste Centrale", "UDN" to "Udine",
        "VLH" to "Vallo della Lucania", "VEM" to "Venezia Mestre", "VSL" to "Venezia Santa Lucia", "VPN" to "Verona Porta Nuova",
        "VIC" to "Vicenza", "VIP" to "Vibo Valentia Pizzo", "VSG" to "Villa San Giovanni",
    )

    /** Numeri dei treni Italo: 4 cifre che iniziano per 8 o 9. */
    fun looksItalo(number: String): Boolean = Regex("^[89]\\d{3}$").matches(Api.trainDigits(number))

    fun isItalo(ref: TrainRef) = ref.originCode.startsWith("$PREFIX|")

    private fun norm(s: String): String = s.uppercase()
        .replace("S.M.N.", "SANTA MARIA NOVELLA").replace("S. M. N.", "SANTA MARIA NOVELLA").replace("SMN", "SANTA MARIA NOVELLA")
        .replace("P.TA", "PORTA").replace("P. NUOVA", "PORTA NUOVA").replace("P.NUOVA", "PORTA NUOVA").replace("P. SUSA", "PORTA SUSA")
        .replace("P.SUSA", "PORTA SUSA").replace("S.LUCIA", "SANTA LUCIA").replace("S. LUCIA", "SANTA LUCIA")
        .replace("P.ZA", "PIAZZA").replace("P. PRINCIPE", "PIAZZA PRINCIPE").replace("P.PRINCIPE", "PIAZZA PRINCIPE")
        .replace("MEDIOPADANA", "AV").replace(Regex("[^A-Z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Codice Italo di una stazione (es. "MILANO CENTRALE" → "MC_"), se Italo vi ferma. */
    fun codeFor(stationName: String): String? {
        val n = norm(stationName)
        if (n.isBlank()) return null
        STATIONS.entries.firstOrNull { norm(it.value) == n }?.let { return it.key }
        // "BOLOGNA C.LE", "PISA C.LE", "TRIESTE C.LE"…
        val base = n.replace(Regex(" (C LE|CENTRALE)$"), "")
        STATIONS.entries.firstOrNull { norm(it.value).replace(Regex(" CENTRALE$"), "") == base }?.let { return it.key }
        // "REGGIO EMILIA AV MEDIOPADANA", "RHO FIERA MILANO", "LATISANA LIGNANO BIBIONE"…
        return STATIONS.entries.firstOrNull { e ->
            val v = norm(e.value)
            v.contains(' ') && (n.startsWith("$v ") || n == v)
        }?.key
    }

    /** Tempi brevi: le partenze Italo si aggiungono al tabellone e non devono rallentarlo. */
    private fun get(url: String): JSONObject {
        val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 6000; readTimeout = 8000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Binario/1.0")
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    /** Corse Italo con questo numero (oggi). */
    fun lookup(number: String): List<TrainRef> = try {
        val n = Api.trainDigits(number)
        val o = get(BASE + "RicercaTrenoService?TrainNumber=" + n)
        val t = o.optJSONObject("TrainSchedule")
        if (o.optBoolean("IsEmpty", true) || t == null) emptyList()
        else listOf(
            TrainRef(n, "$PREFIX|$n", Fmt.midnight(),
                "ITA $n " + t.optString("DepartureStationDescription") + " → " + t.optString("ArrivalStationDescription") +
                    " · " + t.optString("DepartureDate")),
        )
    } catch (_: Exception) {
        emptyList()
    }

    /** "HH:mm" di oggi (o di domani se l'ora è molto prima di [after], per i treni che passano la mezzanotte). */
    private fun at(hhmm: String, day: Long, after: Long = 0L): Long {
        val m = Regex("^(\\d{1,2}):(\\d{2})").find(hhmm.trim()) ?: return 0L
        val c = Calendar.getInstance(rome).apply {
            timeInMillis = day
            set(Calendar.HOUR_OF_DAY, m.groupValues[1].toInt()); set(Calendar.MINUTE, m.groupValues[2].toInt())
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        var t = c.timeInMillis
        if (after > 0 && t < after - 3 * 3_600_000L) t += 86_400_000L
        return t
    }

    fun status(ref: TrainRef): TrainStatus {
        val n = Api.trainDigits(ref.number)
        val o = get(BASE + "RicercaTrenoService?TrainNumber=" + n)
        val t = o.optJSONObject("TrainSchedule")
        if (o.optBoolean("IsEmpty", true) || t == null) throw IOException("Treno Italo $n non trovato (circola solo nel giorno di viaggio)")
        val day = Fmt.midnight()
        val dist = t.optJSONObject("Distruption")
        val delay = dist?.optInt("DelayAmount", 0) ?: 0
        val running = dist?.optInt("RunningState", 0) ?: 0
        val raw = ArrayList<JSONObject>()
        t.optJSONObject("StazionePartenza")?.let { raw += it }
        fun addAll(a: JSONArray?) { if (a != null) for (i in 0 until a.length()) a.optJSONObject(i)?.let { raw += it } }
        addAll(t.optJSONArray("StazioniFerme"))
        addAll(t.optJSONArray("StazioniNonFerme"))
        val seq = raw.distinctBy { it.optInt("StationNumber", -1).toString() + it.optString("LocationCode") }
            .sortedBy { it.optInt("StationNumber", 0) }
        val now = System.currentTimeMillis()
        var prev = 0L
        val stops = seq.mapIndexed { i, s ->
            val first = i == 0; val last = i == seq.lastIndex
            val sa = if (first) 0L else at(s.optString("EstimatedArrivalTime"), day, prev)
            val sd = if (last) 0L else at(s.optString("EstimatedDepartureTime"), day, maxOf(prev, sa))
            val ea = if (first) 0L else at(s.optString("ActualArrivalTime"), day, prev)
            val ed = if (last) 0L else at(s.optString("ActualDepartureTime"), day, maxOf(prev, ea))
            prev = maxOf(prev, sa, sd)
            // Partito dalla fermata: Italo compila l'orario di partenza effettivo solo dopo la partenza
            val left = !last && s.optString("ActualDepartureTime").isNotBlank()
            val stopDelay = when {
                ed > 0 && sd > 0 -> ((ed - sd) / 60_000L).toInt()
                ea > 0 && sa > 0 -> ((ea - sa) / 60_000L).toInt()
                else -> delay
            }
            val reached = left || (last && (running == 2 || (ea > 0 && ea < now && seq.size > 1)))
            val plat = s.optString("ActualArrivalPlatform").takeIf { it != "null" }.orEmpty()
            TrainStop(
                name = s.optString("LocationDescription"), id = "IT" + s.optString("LocationCode"),
                schedArr = sa, schedDep = sd,
                realArr = if (reached && !first) (if (ea > 0) ea else sa) else 0L,
                realDep = if (left) (if (ed > 0) ed else sd) else 0L,
                delay = stopDelay, platform = plat, platformChanged = false, platformConfirmed = plat.isNotBlank(),
                schedPlatform = "", realPlatform = plat,
            )
        }
        if (stops.isEmpty()) throw IOException("Nessuna fermata per il treno Italo $n")
        val fixed = stops
        val passed = fixed.lastOrNull { it.passed }
        return TrainStatus(
            number = n, category = "ITA", origin = t.optString("DepartureStationDescription").ifBlank { fixed.first().name },
            destination = t.optString("ArrivalStationDescription").ifBlank { fixed.last().name },
            originCode = "$PREFIX|$n", date = day, delay = delay,
            lastStation = passed?.name.orEmpty(), lastTime = passed?.let { if (it.realDep > 0) it.realDep else it.realArr } ?: 0L,
            cancelled = false, stops = fixed,
            info = I18n.tr("Dati in tempo reale Italo ($SOURCE)", "Italo real-time data ($SOURCE)"),
            operator = "Italo",
        )
    }

    /**
     * Soluzioni Italo dirette tra due stazioni servite da Italo, per le prossime ore (il servizio pubblico di Italo
     * dà solo i treni del giorno in partenza a breve). Orari ufficiali, senza prezzo: si acquista su italotreno.com.
     */
    fun directSolutions(from: Station, to: Station, time: Long): List<Solution> {
        val a = codeFor(from.name) ?: return emptyList()
        val b = codeFor(to.name) ?: return emptyList()
        if (a == b) return emptyList()
        val now = System.currentTimeMillis()
        if (time > now + 4 * 3_600_000L || time < now - 3 * 3_600_000L) return emptyList()
        val board = departures(Station(STATIONS[a] ?: from.name, "IT$a")).filter { it.time + it.delay * 60_000L >= time - 5 * 60_000L }.take(12)
        if (board.isEmpty()) return emptyList()
        val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
        try {
            val futures = board.map { item -> pool.submit<Solution?> { solutionFor(item.number, a, b) } }
            // Tempo massimo complessivo 8 secondi: Italo lento non deve rallentare la ricerca delle soluzioni
            val deadline = System.currentTimeMillis() + 8_000L
            return futures.mapNotNull { f ->
                try { f.get((deadline - System.currentTimeMillis()).coerceAtLeast(1L), java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Exception) { null }
            }
                .filter { it.dep >= time - 5 * 60_000L }
                .distinctBy { it.legs.firstOrNull()?.number }
                .sortedBy { it.dep }
        } finally {
            pool.shutdownNow()
        }
    }

    private fun solutionFor(number: String, fromCode: String, toCode: String): Solution? {
        val st = try { status(TrainRef(number, "$PREFIX|$number")) } catch (_: Exception) { return null }
        val i = st.stops.indexOfFirst { it.id == "IT$fromCode" }
        val j = st.stops.indexOfFirst { it.id == "IT$toCode" }
        if (i < 0 || j <= i) return null
        val x = st.stops[i]; val y = st.stops[j]
        val dep = if (x.schedDep > 0) x.schedDep else x.schedArr
        val arr = if (y.schedArr > 0) y.schedArr else y.schedDep
        if (dep <= 0 || arr <= 0) return null
        val leg = Leg(number = number, category = "ITA", from = x.name, to = y.name, dep = dep, arr = arr, operator = "Italo")
        return Solution(x.name, y.name, dep, arr, Fmt.duration(dep, arr), null, listOf(leg), source = "italotreno.com")
    }

    /** Prossime partenze Italo da una stazione (solo per l'ora attuale: il servizio dà le prossime ore). */
    fun departures(st: Station): List<BoardItem> {
        val code = codeFor(st.name) ?: return emptyList()
        return try {
            val o = get(BASE + "RicercaStazioneService?CodiceStazione=" + code)
            val a = o.optJSONArray("ListaTreniPartenza") ?: return emptyList()
            val day = Fmt.midnight()
            val now = System.currentTimeMillis()
            (0 until a.length()).mapNotNull { i ->
                val x = a.optJSONObject(i) ?: return@mapNotNull null
                val num = x.optString("Numero").trim()
                if (num.isBlank()) return@mapNotNull null
                val time = at(x.optString("OraPassaggio"), day, now)
                val plat = x.optString("Binario").takeIf { it != "null" }.orEmpty()
                BoardItem(
                    number = num, category = "ITA", otherEnd = x.optString("DescrizioneLocalita"), time = time,
                    delay = x.optInt("Ritardo", 0), platform = plat, platformConfirmed = plat.isNotBlank(),
                    originCode = "$PREFIX|$num", departureDate = day, inStation = false,
                    schedPlatform = "", realPlatform = plat, operator = "Italo",
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
