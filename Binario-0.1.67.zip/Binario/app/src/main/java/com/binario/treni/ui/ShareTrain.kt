package com.binario.treni.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n

/**
 * "Condividi stato del treno": manda lo stato del treno seguito (ritardo, binario, prossima fermata) con WhatsApp,
 * Telegram, Signal o WeChat, oppure con qualsiasi altra app. Binario non legge e non salva niente di queste app:
 * apre solo l'app scelta con il testo già scritto, e l'invio lo decide la persona.
 */
object TrainShare {
    data class App(val name: String, val pkg: String, val color: Long)

    val APPS = listOf(
        App("WhatsApp", "com.whatsapp", 0xFF25D366),
        App("Telegram", "org.telegram.messenger", 0xFF229ED9),
        App("Signal", "org.thoughtcrime.securesms", 0xFF3A76F0),
        App("WeChat", "com.tencent.mm", 0xFF07C160),
    )

    fun withSignature(text: String) = "$text\n\n— via Binario"

    /** Intent che apre la scelta delle app (anche dalla notifica). */
    fun chooser(text: String): Intent {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, withSignature(text))
        return Intent.createChooser(send, I18n.tr("Condividi stato del treno", "Share train status")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Apre l'app indicata con il testo pronto; se non è installata lo dice e mostra le altre app. */
    fun send(ctx: Context, text: String, app: App?) {
        if (app == null) { ctx.startActivity(chooser(text)); return }
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").setPackage(app.pkg)
            .putExtra(Intent.EXTRA_TEXT, withSignature(text)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (_: ActivityNotFoundException) {
            toast(ctx, I18n.tr("${app.name} non è installata: scegli un'altra app", "${app.name} is not installed: choose another app"))
            ctx.startActivity(chooser(text))
        } catch (_: SecurityException) {
            ctx.startActivity(chooser(text))
        }
    }
}

/** Riga di pulsanti "Condividi stato del treno". */
@Composable
fun ShareTrainRow(text: String) {
    val ctx = LocalContext.current
    Column(Modifier.padding(top = 8.dp)) {
        Text(I18n.tr("Condividi stato del treno", "Share train status"), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Muted)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TrainShare.APPS.forEach { a ->
                OutlinedButton(
                    { TrainShare.send(ctx, text, a) },
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.padding(end = 6.dp),
                ) { Text(a.name, color = Color(a.color), fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            }
            IconButton({ TrainShare.send(ctx, text, null) }) { Icon(Icons.Filled.Share, I18n.tr("Altre app", "Other apps"), tint = Green) }
        }
    }
}
