package com.binario.treni.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Lingua dell'interfaccia: "it", "en", "zh", "de", "fr", "es" o "ja". Lo stato è osservabile, così l'app cambia lingua all'istante. */
object I18n {
    var lang by mutableStateOf("it")

    /** Vero per ogni lingua diversa dall'italiano: inglese, cinese, tedesco e francese partono dal testo inglese. */
    val en: Boolean get() = lang != "it"
    val zh: Boolean get() = lang == "zh"
    val de: Boolean get() = lang == "de"
    val fr: Boolean get() = lang == "fr"
    val es: Boolean get() = lang == "es"
    val ja: Boolean get() = lang == "ja"

    /** Lingue con ideogrammi: le parole non sono separate da spazi. */
    val cjk: Boolean get() = lang == "zh" || lang == "ja"

    /** Lingua per il riconoscimento vocale. */
    val speechTag: String get() = when (lang) { "en" -> "en-GB"; "zh" -> "zh-CN"; "de" -> "de-DE"; "fr" -> "fr-FR"; "es" -> "es-ES"; "ja" -> "ja-JP"; else -> "it-IT" }

    /** Lingua per la sintesi vocale. */
    val locale: java.util.Locale get() = when (lang) {
        "en" -> java.util.Locale.UK; "zh" -> java.util.Locale.SIMPLIFIED_CHINESE
        "de" -> java.util.Locale.GERMANY; "fr" -> java.util.Locale.FRANCE; "es" -> java.util.Locale("es", "ES")
        "ja" -> java.util.Locale.JAPAN; else -> java.util.Locale.ITALY
    }

    /** Testo con variante inglese esplicita (per frasi con valori variabili); nelle altre lingue si cerca la traduzione dell'inglese. */
    fun tr(it: String, en: String): String = when (lang) {
        "it" -> it; "zh" -> Zh.of(it, en); "de" -> De.of(it, en); "fr" -> Fr.of(it, en); "es" -> Es.of(it, en); "ja" -> Ja.of(it, en); else -> en
    }

    /** Testo con italiano, inglese e cinese scritti nel codice (per le frasi della voce); tedesco e francese passano dalla tabella. */
    fun tr3(it: String, en: String, zh: String): String = when (lang) {
        "it" -> it; "zh" -> zh; "de" -> De.of(it, en); "fr" -> Fr.of(it, en); "es" -> Es.of(it, en); "ja" -> Ja.of(it, en); else -> en
    }

    /**
     * Come tr3 ma con tedesco e francese scritti nel codice (frasi della voce, nomi brevi, testi lunghi).
     * Spagnolo e giapponese si possono passare (es, ja); se mancano si cerca la traduzione dell'inglese nella tabella.
     */
    fun tr5(it: String, en: String, zh: String, de: String, fr: String, es: String? = null, ja: String? = null): String = when (lang) {
        "it" -> it; "zh" -> zh; "de" -> de; "fr" -> fr; "es" -> es ?: Es.of(it, en); "ja" -> ja ?: Ja.of(it, en); else -> en
    }
}

/**
 * Assistente per domande su treni e circolazione. Riconosce la domanda in 7 lingue (italiano, inglese, tedesco, francese,
 * spagnolo, cinese, giapponese: le ultime cinque sono convertite in parole inglesi da [BotLang])
 * e risponde con i dati in tempo reale di ViaggiaTreno, LeFrecce, Osservatorio scioperi e comunicati.
 */
object Bot {
    private fun tr(a: String, b: String) = I18n.tr(a, b)

    data class Reply(
        val text: String,
        val train: TrainRef? = null,
        val station: Station? = null,
        /** Fonte della risposta, mostrata con il link diretto. */
        val source: String = "",
        val url: String = "",
    )

    fun help(): String = tr(
        """Posso aiutarti con:
• "ritardo treno 2070" oppure "dov'è il 9544"
• "treni da Varese a Milano"
• "partenze da Varese" / "arrivi a Como"
• "ci sono scioperi?"
• "circolazione sulla S5" / "problemi a Saronno"
• "ascensori a Saronno"
• "treni garantiti"
• "dov'è il mio treno?" (il treno che stai seguendo)
• "prossimo treno per Milano"
• "bus, metro e taxi a Milano Centrale"
• "WC a Saronno" / "servizi a Varese"
• "rimborso per ritardo", "posso portare la bici?", "bambini", "assistenza disabili", "oggetti smarriti"
Tocca il microfono per chiedere a voce.""",
        """I can help with:
• "delay train 2070" or "where is 9544"
• "trains from Varese to Milano"
• "departures from Varese" / "arrivals at Como"
• "any strikes?"
• "traffic on S5" / "problems at Saronno"
• "elevators at Saronno"
• "guaranteed trains"
• "where is my train?" (the train you follow)
• "next train to Milano"
• "bus, metro and taxi at Milano Centrale"
• "toilets at Saronno" / "services at Varese"
• "delay compensation", "can I bring my bike?", "children", "disability assistance", "lost property"
Tap the microphone to ask by voice.""",
    )

    private fun has(q: String, vararg w: String) = w.any { q.contains(it) }

    /** Parola intera (così "bus" non scatta su "Busto Arsizio" e "bagno" non su "Bagnolo"). */
    private fun hasWord(q: String, vararg w: String) = w.any { Regex("\\b" + Regex.escape(it) + "\\b").containsMatchIn(q) }

    private fun search1(clean: String): Station? = try {
        val l = Api.searchStations(clean)
        l.firstOrNull { it.name.equals(clean, true) } ?: l.firstOrNull()
    } catch (e: Exception) {
        null
    }

    /**
     * Stazione per nome. Se il testo intero non è una stazione si tolgono fino a 3 parole in fondo ("milano cadorna funziona",
     * "lecco station") e, con [lead], fino a 2 all'inizio ("has milano centrale").
     */
    private fun station(text: String, lead: Boolean = false): Station? {
        val clean = text.trim().trim('?', '.', '!', ',').trim()
        if (clean.length < 2) return null
        search1(clean)?.let { return it }
        val words = clean.split(" ")
        for (k in 1..minOf(3, words.size - 1)) {
            val c = words.dropLast(k).joinToString(" ")
            if (c.length >= 3) search1(c)?.let { return it }
        }
        if (lead) for (k in 1..minOf(2, words.size - 1)) {
            val c = words.drop(k).joinToString(" ")
            if (c.length >= 3) search1(c)?.let { return it }
        }
        return null
    }

    /** Parole di cortesia e riempitivi tolti prima di cercare il nome di una stazione. */
    private val filler = Regex("\\b(per favore|grazie|please|thanks|mi sai dire|sai dirmi|vorrei sapere|dimmi|ciao|buongiorno|buonasera|scusa)\\b")

    /** Nome di stazione alla fine di frasi tipo "... a Varese", "... di Milano Centrale", "... near Como", "services from la station from Como". */
    private fun stationAfter(q: String, vararg keys: String): Station? {
        val k = keys.joinToString("|")
        // ".*" iniziale: si prende il testo dopo l'ULTIMA parola chiave ("bus e taxi a Varese" → "Varese")
        val m = Regex(".*\\b(?:$k)\\b\\s*(?:(?:alla|nella|della|vicino alla|vicino a|presso|in the|in|ad|a|di|da|de|near|at|to|from|of)\\s+)?(?:stazione\\s+(?:di\\s+)?|station\\s+)?(.+)$").find(q)
            ?: return null
        val raw = m.groupValues[1].replace(Regex("\\?|\\."), "").trim()
        // Il testo dopo l'ULTIMA preposizione ("c'è a Milano Centrale", "from la station from induno olona" → "induno olona")
        val tail = Regex(".*(?:^|\\s)(?:a|ad|di|da|de|in|alla|della|nella|near|at|from|of)\\s+(.+)$").find(raw)?.groupValues?.get(1)
        return tail?.let { station(it, true) } ?: station(raw, true)
    }

    private fun w(x: String) = Regex("(?<![\\p{L}\\d])$x(?![\\p{L}\\d])")

    private fun latin(l: List<Pair<String, String>>) = l.sortedByDescending { it.first.length }.map { (a, b) -> w(Regex.escape(a)) to b }
    private val deMap by lazy { latin(BotLang.DE) }
    private val frMap by lazy { latin(BotLang.FR) }
    private val esMap by lazy { latin(BotLang.ES) }

    /** Domanda in tedesco, francese, spagnolo, giapponese o cinese → parole inglesi che le regole riconoscono. */
    private fun foreign(question: String): String {
        var t = question.lowercase()
        when (I18n.lang) {
            "de" -> for ((r, e) in deMap) t = r.replace(t, e)
            "fr" -> {
                // prima le frasi ("bus de remplacement", "à bord"), poi le preposizioni rimaste: "de X à Y" = "from X to Y"
                for ((r, e) in frMap) t = r.replace(t, e)
                val a = w("à")
                t = if (Regex("(?<![\\p{L}])de(?![\\p{L}]).*(?<![\\p{L}])à(?![\\p{L}])").containsMatchIn(t)) a.replace(w("de").replace(t, "from"), "to") else a.replace(t, "at")
                t = w("de").replace(t, "from")
            }
            "es" -> {
                for ((r, e) in esMap) t = r.replace(t, e)
                // "de Varese a Milano" = "from Varese to Milano"; da sola "a" resta (le regole la capiscono come in italiano)
                if (Regex("(?<![\\p{L}])de(?![\\p{L}]).*(?<![\\p{L}])a(?![\\p{L}])").containsMatchIn(t)) {
                    t = w("de").replace(t, "from"); t = w("a").replace(t, "to")
                }
            }
            "ja", "zh" -> t = BotLang.cjk(t, I18n.lang == "ja")
        }
        return t
    }

    private val transportWords = arrayOf("autobus", "bus", "buses", "taxis", "trams", "pullman", "metropolitana", "metro", "tram", "taxi", "mezzi",
        "coincidenze con", "bike sharing", "bici in condivisione", "public transport", "trasporti pubblici", "mezzi pubblici")
    private val wcWords = arrayOf("wc", "bagno", "bagni", "toilette", "toilet", "toilets", "servizi igienici", "gabinetto", "restroom")
    private val svcWords = arrayOf("biglietteria", "biglietterie", "emettitrice", "emettitrici", "obliteratrice", "obliteratrici", "servizi",
        "ticket office", "ticket offices", "services", "quanti binari", "binari ha", "how many platforms")
    /** Numeri che non sono treni: emergenze e "Regolamento 2021/782". */
    private val notTrains = setOf("112", "118", "144", "911", "782")
    /** Argomenti che non devono passare davanti a una tratta ("treni da Milano Cadorna a Malpensa"). */
    private val earlyExclude = setOf("malpensa", "svizzera")
    /** "Il mio treno ha cambiato binario?" è una domanda sul treno seguito, non una spiegazione. */
    private val myTrainBeats = setOf("binario_spiegazione", "puntualita", "app_sveglia")

    fun answer(question: String, store: Store): Reply {
        val raw = if (I18n.lang == "it" || I18n.lang == "en") question else foreign(question)
        val q = filler.replace(raw.lowercase(), " ").replace(Regex("\\s+"), " ").trim().trim('?', '!', '.')
        val n = Knowledge.normalize(q)

        // Numero del treno (anche "binario del 2512", "ritardo 9544"), ma non "da Varese a Milano alle 1830" né "Regolamento 2021/782"
        val num = if (has(n, "regolament", "regulation", "verordnung", "reglement", "reglamento")) null
            else Regex("\\b(\\d{3,5})\\b").findAll(q).map { it.groupValues[1] }.firstOrNull { it !in notTrains }
        if (num != null && !Regex("(?:da|from)\\s+.+?\\s+(?:a|ad|to|per|fino a)\\s+").containsMatchIn(q)) return trainAnswer(TrainRef(num))

        // Domande generali con parole molto chiare (rimborsi, bici, bambini, assistenza…): prima di tutto il resto
        val k = Knowledge.find(q)
        val strongK = k != null && Knowledge.score(k, n.split(" ")) >= 7
        if (strongK && k != null && k.id in myTrainBeats && has(n, "mio treno", "my train")) {
            val t = store.tracked() ?: return Reply(tr("Non stai seguendo nessun treno. Chiedi per esempio \"treno 2512\" e poi tocca \"Segui con avvisi vocali\".",
                "You are not following any train. Ask for example \"train 2512\" and then tap \"Follow with voice alerts\"."))
            return trainAnswer(t)
        }
        if (strongK && k != null && k.id !in earlyExclude) {
            // "obliteratrice a Como", "WC a Saronno": se è nominata una stazione vince la domanda sulla stazione
            if (k.id != "bus_sostitutivi") {
                if (hasWord(n, *svcWords)) stationAfter(q, *svcWords)?.let { return servicesAnswer(it, toiletsOnly = false, store = store) }
                if (hasWord(n, *wcWords)) stationAfter(q, *wcWords)?.let { return servicesAnswer(it, toiletsOnly = true, store = store) }
                if (hasWord(n, *transportWords)) stationAfter(q, *transportWords)?.let { return transportAnswer(it, store) }
            }
            return Reply(k.text, source = k.source, url = k.url)
        }

        if (q.isBlank() || has(n, "aiut", "help", "cosa sai", "cosa puoi", "what can") ||
            (has(n, "come funzion", "how does", "how do") && has(n, "assist"))) return Reply(help())

        // Il treno che sto seguendo
        if (has(n, "mio treno", "my train", "treno seguito", "followed train")) {
            val t = store.tracked() ?: return Reply(tr("Non stai seguendo nessun treno. Chiedi per esempio \"treno 2512\" e poi tocca \"Segui con avvisi vocali\".",
                "You are not following any train. Ask for example \"train 2512\" and then tap \"Follow with voice alerts\"."))
            return trainAnswer(t)
        }

        // Bus, metro, tram, taxi vicino a una stazione
        if (hasWord(n, *transportWords)) {
            val st = stationAfter(q, *transportWords) ?: store.boardingStation() ?: store.favStations().firstOrNull()
            if (st != null) return transportAnswer(st, store)
            return Reply(tr("Di quale stazione? Chiedi per esempio \"bus e taxi a Varese\".", "Which station? Ask for example \"bus and taxi at Varese\"."))
        }

        // WC, servizi e ascensori di una stazione
        if (hasWord(n, *wcWords)) {
            val st = stationAfter(q, *wcWords) ?: return Reply(tr("In quale stazione? Chiedi per esempio \"WC a Saronno\".", "Which station? Ask for example \"toilets at Saronno\"."))
            return servicesAnswer(st, toiletsOnly = true, store = store)
        }
        if (hasWord(n, *svcWords) && !has(n, "rimbors")) {
            stationAfter(q, *svcWords)?.let { return servicesAnswer(it, toiletsOnly = false, store = store) }
        }

        // Da X a Y
        Regex("(?:da|from)\\s+(.+?)\\s+(?:a|ad|to|per|fino a)\\s+(.+)").find(q)?.let { m ->
            val a = station(m.groupValues[1]); val b = station(m.groupValues[2])
            if (a != null && b != null) return routeAnswer(a, b, store)
        }

        // Prossimo treno per X: partenza dall'ultima tratta cercata o preferita
        Regex("(?:prossimo treno|prossimi treni|primo treno|ultimo treno|next train|next trains|treni|treno|train|trains)\\s+(?:per|a|verso|to|for)\\s+(.+)").find(q)?.let { m ->
            if (has(q, " da ", " from ")) return@let
            val to = station(m.groupValues[1]) ?: return@let
            val from = (store.recentRoutes() + store.favRoutes()).map { it.from }.firstOrNull { it.id != to.id }
                ?: return Reply(tr("Da quale stazione parti? Di' per esempio \"da Varese a ${to.name}\".",
                    "Which station do you leave from? Say for example \"from Varese to ${to.name}\"."))
            return routeAnswer(from, to, store)
        }

        // Partenze / arrivi
        Regex("(?:partenze|departures|departure board|parte|leaving|tabellone)\\s+(?:(?:da|from|di|at|in|a)\\s+)?(.+)").find(q)?.let { m ->
            station(m.groupValues[1])?.let { return boardAnswer(it, true) }
        }
        Regex("(?:arrivi|arrivals|arriva)\\s+(?:(?:a|at|in|di|to)\\s+)?(.+)").find(q)?.let { m ->
            station(m.groupValues[1])?.let { return boardAnswer(it, false) }
        }

        if (has(n, "ascensor", "elevator", "lift", "scale mobili", "escalator")) {
            val st = stationAfter(q, "ascensori", "ascensore", "elevators", "elevator", "lift", "lifts", "scale mobili", "escalators", "escalator")
            if (st != null) {
                val (issues, _) = Sources.issuesFor(st.name)
                return Reply(
                    if (issues.isEmpty()) tr("Nessun ascensore o scala fuori servizio segnalato a ${st.name} (FerrovieNord/RFI). Nella scheda della stazione trovi gli ascensori per binario.",
                        "No out-of-service elevators or escalators reported at ${st.name} (FerrovieNord/RFI). The station screen lists lifts per platform.")
                    else issues.joinToString("\n", prefix = tr("Fuori servizio a ${st.name}:\n", "Out of service at ${st.name}:\n")) {
                        "• " + (if (it.platform.isNotBlank()) tr("Binario", "Platform") + " ${it.platform}: " else "") + it.device +
                            (if (it.until.isNotBlank()) " → ${it.until}" else "")
                    },
                    station = st,
                )
            }
        }

        if (strongK && k != null) return Reply(k.text, source = k.source, url = k.url)

        if (has(n, "garantit", "guaranteed", "fasce")) {
            return Reply(tr(
                "Durante gli scioperi dei regionali sono di norma garantiti i treni 6:00–9:00 e 18:00–21:00 nei giorni feriali (7:00–10:00 e 18:00–21:00 nei festivi). Gli elenchi ufficiali aggiornati sono in Altro → Treni garantiti.",
                "During regional rail strikes trains are normally guaranteed 6:00–9:00 and 18:00–21:00 on weekdays (7:00–10:00 and 18:00–21:00 on holidays). Updated official lists are in More → Guaranteed trains.",
            ), source = "Trenitalia · treni garantiti", url = Sources.TRENITALIA_GUARANTEED_URL)
        }
        if (has(n, "sciopero", "scioperi", "strike")) return strikeAnswer()

        if (k != null) return Reply(k.text, source = k.source, url = k.url)

        if (has(n, "circolazione", "traffico", "traffic", "problem", "ritardi", "delays", "interrott", "sospes", "guasto", "disruption", "linea", "line",
                "lavori", "works", "blocked", "bloccat", "succede", "going on")) {
            return trafficAnswer(q, store)
        }
        if (has(n, "ritardo", "delay", "binario", "platform", "dove e il treno", "where is", "che ora", "what time", "wie viel uhr", "quelle heure", "que hora") ||
            hasWord(n, "late", "delayed")) {
            return Reply(tr("Dimmi il numero del treno, per esempio \"ritardo treno 2512\" o \"binario del 9544\".",
                "Tell me the train number, for example \"delay train 2512\" or \"platform of 9544\"."))
        }

        // Ultimo tentativo: il testo è il nome di una stazione → partenze
        station(q)?.let { return boardAnswer(it, true) }
        return Reply(tr("Non ho capito la domanda. Prova con uno di questi argomenti: ", "Sorry, I didn't understand. Try one of these topics: ") +
            Knowledge.topics.joinToString(", ") + "\n\n" + help())
    }

    /** Bus, metro, tram, taxi e bici vicino alla stazione. */
    private fun transportAnswer(st: Station, store: Store): Reply = try {
        val c = Api.stationCoord(store, st.id) ?: throw java.io.IOException("coord")
        val t = Osm.stationTransport(c.first, c.second)
        if (t.isEmpty) Reply(tr("Non trovo fermate di bus, metro, tram o taxi mappate entro 400 m da ${st.name}.",
            "I can't find bus, metro, tram or taxi stops mapped within 400 m of ${st.name}."), station = st, source = "OpenStreetMap", url = t.sourceUrl)
        else {
            fun line(label: String, l: List<TransitStop>) = if (l.isEmpty()) "" else "\n$label:\n" + l.take(4).joinToString("\n") { s ->
                "• ${s.name} (${s.distance} m)" + (if (s.lines.isNotEmpty()) " — " + tr("linee ", "lines ") + s.lines.take(10).joinToString(", ") else "")
            }
            Reply(tr("Vicino a ${st.name}:", "Near ${st.name}:") + line(tr("Metropolitana", "Metro"), t.metro) + line("Tram", t.tram) +
                line("Bus", t.bus) + line("Taxi", t.taxi) + line(tr("Bici in condivisione", "Bike sharing"), t.bikes),
                station = st, source = "OpenStreetMap", url = t.sourceUrl)
        }
    } catch (e: Exception) {
        Reply(tr("Dati sui mezzi non raggiungibili ora per ${st.name}.", "Transport data not reachable now for ${st.name}."), station = st)
    }

    /** Servizi della stazione: binari, ascensori, biglietteria, self-service, obliteratrici, WC. */
    private fun servicesAnswer(st: Station, toiletsOnly: Boolean, store: Store): Reply = try {
        val c = Api.stationCoord(store, st.id) ?: throw java.io.IOException("coord")
        val o = Osm.stationOverview(c.first, c.second)
        val wc = if (o.toiletList.isEmpty()) tr("WC: non mappati", "Toilets: not mapped")
        else tr("WC: ", "Toilets: ") + o.toiletList.take(3).joinToString("; ") { w ->
            w.feeText + (if (w.wheelchair == "yes") tr(", accessibile", ", accessible") else "") +
                (if (w.hours.isNotBlank()) tr(", orari ", ", hours ") + w.hours else "")
        }
        val text = if (toiletsOnly) "${st.name} · $wc" else buildString {
            append(tr("Servizi a ${st.name}:", "Services at ${st.name}:"))
            append("\n• ").append(tr("Binari: ", "Platforms: ")).append(if (o.tracks.isEmpty()) tr("non mappati", "not mapped") else "${o.tracks.size} (${o.tracks.joinToString(", ")})")
            append("\n• ").append(tr("Ascensori: ", "Lifts: ")).append(o.elevators)
            append("\n• ").append(tr("Biglietteria: ", "Ticket office: ")).append(if (o.ticketOffices.isEmpty()) tr("non mappata", "not mapped") else tr("presente", "yes"))
            append("\n• ").append(tr("Self-service: ", "Ticket machines: ")).append(o.machines.size)
                .append(if (o.contactlessMachines > 0) tr(" (contactless ${o.contactlessMachines})", " (contactless ${o.contactlessMachines})") else "")
            append("\n• ").append(tr("Obliteratrici: ", "Validators: ")).append(o.validators.size)
            append("\n• ").append(wc)
        }
        Reply(text, station = st, source = "OpenStreetMap", url = o.sourceUrl)
    } catch (e: Exception) {
        Reply(tr("Dati della stazione non raggiungibili ora.", "Station data not reachable now."), station = st)
    }

    private fun trainAnswer(ref: TrainRef): Reply = try {
        val num = ref.number
        val st = Api.status(ref)
        val next = st.nextStop
        val sb = StringBuilder("${st.title} ${st.origin} → ${st.destination}\n")
        sb.append(
            when {
                st.cancelled -> tr("Treno soppresso.", "Train cancelled.")
                st.arrived -> tr("Arrivato", "Arrived") + if (st.delay > 0) tr(" con ${st.delay} min di ritardo.", " ${st.delay} min late.") else "."
                !st.departed -> tr("Non ancora partito", "Not departed yet") + " (${Fmt.time(st.depTime)})" +
                    if (st.delay > 0) tr(", ritardo previsto ${st.delay} min.", ", expected delay ${st.delay} min.") else "."
                st.delay > 0 -> tr("In viaggio con ${st.delay} min di ritardo.", "Running ${st.delay} min late.")
                st.delay < 0 -> tr("In viaggio con ${-st.delay} min di anticipo.", "Running ${-st.delay} min early.")
                else -> tr("In viaggio, in orario.", "Running on time.")
            },
        )
        // Dove prenderlo: binario alla stazione di partenza
        val first = st.stops.firstOrNull()
        if (!st.departed && !st.cancelled && first != null) {
            val p = first.realPlatform.ifBlank { first.schedPlatform }
            sb.append("\n").append(tr("Parte da ${st.origin}", "Departs from ${st.origin}"))
            sb.append(if (p.isNotBlank()) tr(" dal binario $p", " from platform $p") + (if (first.realPlatform.isBlank()) tr(" (previsto)", " (scheduled)") else "")
                else tr(", binario non ancora indicato", ", platform not yet shown"))
            sb.append(".")
        }
        if (st.departed && st.lastStation.isNotBlank()) sb.append("\n").append(tr("Ultimo rilevamento: ", "Last seen: ")).append("${st.lastStation} ${Fmt.time(st.lastTime)}")
        if (next != null && !st.arrived) {
            sb.append("\n").append(tr("Prossima fermata: ", "Next stop: ")).append(next.name).append(" ")
                .append(Fmt.time(if (next.schedArr > 0) next.schedArr else next.schedDep))
            if (next.schedPlatform.isNotBlank()) sb.append(tr(" · binario previsto ", " · scheduled platform ")).append(next.schedPlatform)
            if (next.realPlatform.isNotBlank()) sb.append(tr(" · reale ", " · actual ")).append(next.realPlatform)
        }
        Reply(sb.toString(), train = st.ref)
    } catch (e: Exception) {
        Reply(tr("Non trovo il treno ${ref.number} oggi.", "I can't find train ${ref.number} today."))
    }

    private fun routeAnswer(a: Station, b: Station, store: Store): Reply = try {
        val l = Api.solutions(a, b, System.currentTimeMillis(), SearchFilter.BEST, store.maxChanges, store.excluded).take(4)
        if (l.isEmpty()) Reply(tr("Nessuna soluzione trovata da ${a.name} a ${b.name}.", "No connections found from ${a.name} to ${b.name}."))
        else {
            val lines = l.mapIndexed { i, s ->
                var extra = ""
                if (i < 2) try {
                    val st = Api.status(TrainRef(s.legs.first().number))
                    extra = if (st.cancelled) tr(" · SOPPRESSO", " · CANCELLED") else if (st.delay > 0) " · +${st.delay}'" else tr(" · in orario", " · on time")
                    // Binario alla stazione di partenza scelta
                    st.stops.firstOrNull { it.id == a.id || it.name.equals(a.name, true) }?.let { stop ->
                        val p = stop.realPlatform.ifBlank { stop.schedPlatform }
                        if (p.isNotBlank()) extra += tr(" · bin. ", " · plat. ") + p
                    }
                } catch (_: Exception) {
                }
                "• ${Fmt.time(s.dep)} → ${Fmt.time(s.arr)}  ${s.legs.joinToString("+") { it.title }}" +
                    (if (s.price != null) "  ${Fmt.price(s.price)}" else "") + extra
            }
            Reply(tr("Prossimi treni ${a.name} → ${b.name}:\n", "Next trains ${a.name} → ${b.name}:\n") + lines.joinToString("\n"))
        }
    } catch (e: Exception) {
        Reply(tr("Servizio orari non raggiungibile.", "Timetable service unreachable."))
    }

    private fun boardAnswer(st: Station, departures: Boolean): Reply = try {
        // Solo da adesso in poi: il tabellone di ViaggiaTreno include anche treni appena partiti (con il ritardo reale)
        val now = System.currentTimeMillis()
        fun fetch(t: Long) = if (departures) Api.departures(st, t) else Api.arrivals(st, t)
        fun upcoming(x: List<com.binario.treni.data.BoardItem>) = x.filter { it.time + it.delay.coerceAtLeast(0) * 60_000L >= now - 30_000L }
        var l = upcoming(fetch(now))
        if (l.size < 6) l = (l + upcoming(runCatching { fetch(now + 90 * 60_000L) }.getOrDefault(emptyList()))).distinctBy { it.number + "|" + it.time }
        l = l.sortedBy { it.time + it.delay.coerceAtLeast(0) * 60_000L }.take(6)
        val head = if (departures) tr("Partenze da ${st.name}:", "Departures from ${st.name}:") else tr("Arrivi a ${st.name}:", "Arrivals at ${st.name}:")
        Reply(
            head + "\n" + l.joinToString("\n") { b ->
                "• ${Fmt.time(b.time)} ${b.title} ${if (departures) "→" else "←"} ${b.otherEnd}" +
                    (if (b.delay > 0) " +${b.delay}'" else "") + (if (b.platformText.isNotBlank()) tr(" bin.", " plat.") + b.platformText else "")
            },
            station = st,
        )
    } catch (e: Exception) {
        Reply(tr("Tabellone non disponibile per ${st.name}.", "Board not available for ${st.name}."))
    }

    private fun strikeAnswer(): Reply = try {
        val l = Sources.railStrikes().take(4)
        if (l.isEmpty()) Reply(tr("Nessuno sciopero ferroviario proclamato (fonte: Osservatorio scioperi MIT).", "No rail strikes announced (source: Italian Ministry strike observatory)."))
        else Reply(tr("Scioperi ferroviari proclamati:\n", "Announced rail strikes:\n") + l.joinToString("\n") { "• ${it.start}: ${it.company.take(70)} — ${it.modality}" } +
            tr("\n\nTreni garantiti: Altro → Treni garantiti.", "\n\nGuaranteed trains: More → Guaranteed trains."))
    } catch (e: Exception) {
        Reply(tr("Osservatorio scioperi non raggiungibile.", "Strike observatory unreachable."))
    }

    private fun trafficAnswer(q: String, store: Store): Reply {
        val all = Sources.allNotices().filter { it.kind == Notice.Kind.BLOCKED || it.kind == Notice.Kind.WORKS }
        val words = q.split(Regex("[^a-zà-ù0-9]+")).filter { it.length >= 2 && it !in setOf("circolazione", "traffico", "traffic", "sulla", "sulle", "linea", "line", "problemi", "problems", "ritardi", "delays", "the", "on", "at", "a", "di", "da", "ci", "sono", "are", "there", "any") }
        val favWords = (store.favLines().map { it.name } + store.favRoutes().flatMap { listOf(it.from.name, it.to.name) }).map { it.lowercase() }
        val keys = words.ifEmpty { favWords }
        val hits = if (keys.isEmpty()) all else all.filter { n -> keys.any { k -> (n.title + " " + n.text).lowercase().contains(k) } }
        if (hits.isEmpty()) return Reply(
            if (keys.isEmpty()) tr("Nessuna anomalia di circolazione segnalata ora.", "No traffic disruptions reported right now.")
            else tr("Nessuna anomalia segnalata per: ${keys.joinToString()}.", "No disruptions reported for: ${keys.joinToString()}."),
        )
        return Reply(hits.take(4).joinToString("\n\n") { "⚠️ ${it.source}: ${it.title}" + (if (it.text.isNotBlank()) "\n" + it.text.take(220) else "") })
    }
}
