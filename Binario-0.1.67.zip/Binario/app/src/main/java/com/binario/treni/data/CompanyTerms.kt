package com.binario.treni.data

/**
 * Condizioni di trasporto, tariffe e diritti dei passeggeri: per ogni azienda i link alle pagine UFFICIALI
 * dell'azienda stessa (la fonte è sempre il sito dell'azienda). Nessuna cifra è copiata nell'app: si apre la pagina
 * aggiornata, così non si mostrano prezzi o regole superati. Link controllati il 04/11/2026.
 */
object CompanyTerms {
    const val VERIFIED = "04/11/2026"

    /** Un link ufficiale con la lingua della pagina (IT, DE, FR, EN). */
    data class L(val url: String, val lang: String) {
        val host: String get() = url.substringAfter("://").substringBefore("/").removePrefix("www.")
    }

    data class Terms(val conditions: L?, val fares: L?, val rights: L?) {
        val any: Boolean get() = conditions != null || fares != null || rights != null
    }

    /** Chiave = id in [Railways.all]. */
    val byId: Map<String, Terms> = mapOf(
        "trenitalia" to Terms(L("https://www.trenitalia.com/it/informazioni/condizioni-generali-di-trasporto.html", "DE"), L("https://www.trenitalia.com/it/offerte.html", "DE"), L("https://www.trenitalia.com/it/informazioni/indennizzo-per-ritardodeltreno.html", "DE")),
        "italo" to Terms(L("https://www.italotreno.com/it/termini-condizioni", "DE"), L("https://www.italotreno.com/it/il-treno/tariffe", "DE"), L("https://www.italotreno.com/it/contatti-supporto", "DE")),
        "trenord" to Terms(L("https://www.trenord.it/assistenza/informazioni-utili/condizioni-di-trasporto/", "IT"), L("https://www.trenord.it/biglietti/titoli-di-viaggio/abbonamenti/", "IT"), L("https://www.trenord.it/assistenza/servizi/rimborsi-e-indennizzi/", "IT")),
        "tper" to Terms(null, L("https://www.tper.it/tariffe", "IT"), null),
        "sad" to Terms(L("https://www.suedtirolmobil.info/it/ticket/condizioni-di-trasporto", "IT"), L("https://www.suedtirolmobil.info/it/ticket/sistema-ticketing-e-convalida-dei-biglietti", "IT"), null),
        "tua" to Terms(L("https://www.tuabruzzo.it/condizioni-di-trasporto/56.html", "IT"), L("https://www.tuabruzzo.it/biglietti-e-abbonamenti/46.html", "IT"), L("https://www.tuabruzzo.it/rimborsi-e-cambio-corsa/60.html", "IT")),
        "fdg" to Terms(null, L("https://ferroviedelgargano.com/viaggia-con-noi/tariffe/", "DE"), L("https://ferroviedelgargano.com/viaggia-con-noi/diritti-del-passeggero/", "DE")),
        "eav" to Terms(L("https://www.eavsrl.it/condizioni-di-utilizzo/", "IT"), L("https://www.eavsrl.it/tariffario/", "IT"), null),
        "fal" to Terms(null, null, L("https://ferrovieappulolucane.it/rimborsi-ed-indennizzi/", "IT")),
        "fdc" to Terms(L("https://web.ferroviedellacalabria.it/normativa-di-trasporto/", "IT"), L("https://web.ferroviedellacalabria.it/punti-vendita-biglietti-e-tariffe/", "IT"), null),
        "fce" to Terms(L("https://www.circumetnea.it/download/norme-e-condizioni/", "IT"), L("https://www.circumetnea.it/biglietti/", "IT"), null),
        "cotral" to Terms(L("https://cotralspa.it/condizioni-generali-di-trasporto/", "IT"), L("https://cotralspa.it/calcola-tariffe/", "IT"), L("https://cotralspa.it/assistenza/rimborsi/", "IT")),
        "busitalia" to Terms(L("https://www.fsbusitalia.it/it/misc/condizioni-trasporto-servizi-trasporto-pubblico-locale.html", "IT"), L("https://www.fsbusitalia.it/it/umbria/titoli-di-viaggio-tariffe-umbria.html", "IT"), null),
        "trentino" to Terms(L("https://www.trentinotrasporti.it/it/viaggia-con-noi/regole-di-viaggio/condizioni-di-trasporto", "IT"), L("https://www.trentinotrasporti.it/it/tariffe", "IT"), L("https://www.trentinotrasporti.it/it/viaggia-con-noi/regole-di-viaggio/diritti-dei-passeggeri-servizi-ferroviari", "IT")),
        "fuc" to Terms(null, L("https://www.ferrovieudinecividale.it/tariffe-2020-udine-cividale-del-friuli/", "IT"), L("https://www.ferrovieudinecividale.it/rimborsi-oggetti-smarriti-fuc-udine-cividale/", "IT")),
        "bls" to Terms(L("https://www.bls.ch/en/pages/agb", "EN"), L("https://www.bls.ch/en/fahren/fahrausweise/billette", "EN"), L("https://www.bls.ch/en/dienstleistungen/nach-der-reise/fahrgastrechte", "EN")),
        "thurbo" to Terms(null, L("https://www.thurbo.ch/reisen/das-richtige-billett/", "DE"), L("https://www.thurbo.ch/reisen/fahrgastrechte/", "DE")),
        "sob" to Terms(null, null, L("https://www.sob.ch/unterwegs-mit-der-sob/nach-der-reise/fahrgastrechte", "DE")),
        "rhb" to Terms(null, L("https://www.rhb.ch/de/tickets/", "DE"), null),
        "zb" to Terms(null, L("https://www.zentralbahn.ch/en/plan/before-travelling/travelcards-and-tickets", "EN"), null),
        "tpf" to Terms(L("https://www.tpf.ch/fr/abos-et-billets/achat-et-conseil/conditions-de-voyage", "FR"), null, null),
        "ab" to Terms(L("https://appenzellerbahnen.ch/de/agb.html", "DE"), L("https://appenzellerbahnen.ch/de/reiseinformationen/abos-tickets.html", "DE"), L("https://appenzellerbahnen.ch/de/services/fahrgastrechte.html", "DE")),
        "aare" to Terms(null, L("https://www.asmobil.ch/de/oeffentlicher-verkehr/mobilitaet/billette-und-abonnemente/", "DE"), L("https://www.asmobil.ch/de/oeffentlicher-verkehr/mobilitaet/fahrgastrechte-im-oeffentlichen-verkehr.html", "DE")),
        "cj" to Terms(L("https://www.les-cj.ch/CGV", "FR"), null, L("https://www.les-cj.ch/Voyager/Droits-des-passagers", "FR")),
        "dbfv" to Terms(L("https://www.bahn.de/agb", "DE"), L("https://www.bahn.de/", "DE"), L("https://www.bahn.de/service/informationen-buchung/fahrgastrechte", "DE")),
        "dbregio" to Terms(L("https://www.bahn.de/agb", "DE"), L("https://regional.bahn.de/tickets/Deutschlandticket", "DE"), L("https://www.bahn.de/service/informationen-buchung/fahrgastrechte", "DE")),
        "db" to Terms(L("https://www.bahn.de/agb", "DE"), L("https://www.bahn.de/", "DE"), L("https://www.bahn.de/service/informationen-buchung/fahrgastrechte", "DE")),
        "sbahnber" to Terms(null, L("https://sbahn.berlin/tickets/", "DE"), null),
        "sbahnstr" to Terms(null, L("https://www.s-bahn-stuttgart.de/s-stuttgart/Tickets_und_Tarife", "DE"), null),
        "brb" to Terms(null, L("https://www.brb.de/de/tickets", "DE"), null),
        "laenderbahn" to Terms(null, L("https://www.laenderbahn.com/tarifver%C3%B6ffentlichungen/", "DE"), null),
        "vlexx" to Terms(null, L("https://www.vlexx.de/tickets/tickets-tarife/", "DE"), null),
        "agilis" to Terms(L("https://www.agilis.de/agb", "DE"), null, null),
        "metronom" to Terms(null, null, L("https://www.der-metronom.de/formulare/fahrgastrechte/", "DE")),
        "enno" to Terms(null, L("https://www.der-enno.de/fahrplan/gueltige-fahrkarten-und-tarife/", "DE"), null),
        "odeg" to Terms(null, L("https://www.odeg.de/tarife-tickets", "DE"), null),
        "neb" to Terms(null, L("https://www.neb.de/tickets/", "DE"), null),
        "nwb" to Terms(null, L("https://www.nordwestbahn.de/de/service/deine-reiseplanung/tickets", "DE"), null),
        "eurobahn" to Terms(L("https://www.eurobahn.de/tarifinformationen/", "DE"), L("https://www.eurobahn.de/tickets-tarife/", "DE"), L("https://www.eurobahn.de/fahrgastrechte/", "DE")),
        "hlb" to Terms(null, L("https://hlb-online.de/fahrplaene-tarife/", "DE"), null),
        "sweg" to Terms(L("https://www.sweg.de/de/tarif-und-befoerderungsbestimmungen/", "DE"), null, L("https://www.sweg.de/de/fahrplan-netz/ihre-fahrgastrechte/", "DE")),
        "bob" to Terms(null, L("https://www.bob-fn.de/tickets/", "DE"), L("https://www.bob-fn.de/service/fahrgastrechte/", "DE")),
        "erfurter" to Terms(L("https://www.erfurter-bahn.de/fuer-fahrgaeste/tickets/tarifbestimmungen-agb", "DE"), L("https://www.erfurter-bahn.de/fuer-fahrgaeste/tickets/ticketuebersicht", "DE"), L("https://www.erfurter-bahn.de/fuer-fahrgaeste/reiseplanung/fahrgastrechte", "DE")),
        "stb" to Terms(L("https://www.sued-thueringen-bahn.de/fuer-fahrgaeste/tickets/tarifbestimmungen-agb", "DE"), L("https://www.sued-thueringen-bahn.de/fuer-fahrgaeste/tickets/ticketuebersicht", "DE"), L("https://www.sued-thueringen-bahn.de/fuer-fahrgaeste/reiseplanung/fahrgastrechte", "DE")),
        "westfalenbahn" to Terms(L("https://www.westfalenbahn.de/tickets-und-tarife/tarife-und-befoerderungsbedingungen/", "DE"), null, L("https://www.westfalenbahn.de/informativ/fahrgastrechte-kundengarantien/", "DE")),
        "nordbahn" to Terms(L("https://www.nordbahn.de/agb/", "DE"), L("https://www.nordbahn.de/reiseplanung/ticketinfos-und-tarife", "DE"), L("https://www.nordbahn.de/service/fahrgastrechte-garantien/", "DE")),
        "akn" to Terms(null, L("https://www.akn.de/fahrplaene-tickets/tarife-tickets", "DE"), null),
        "transdev" to Terms(null, null, L("https://www.transdev.de/de/geschaeftsfelder/kompetenzen-des-kundenservice/fahrgastrechte-und-kundengarantien", "DE")),
        "nightjet" to Terms(null, L("https://www.nightjet.com/de/buchung/tarifinformationen/allgemein", "DE"), null),
        "eusleeper" to Terms(L("https://www.europeansleeper.eu/terms-and-conditions-and-privacy-policy", "EN"), L("https://www.europeansleeper.eu/fare-finder", "EN"), null),
        "oebb" to Terms(null, L("https://www.oebb.at/de/tickets-kundenkarten", "DE"), null),
        "sncf" to Terms(null, L("https://www.sncf-connect.com/tgv-inoui/tarifs", "FR"), L("https://www.sncf-connect.com/aide/droits-des-voyageurs-ferroviaires", "FR")),
        "flixtrain" to Terms(L("https://www.flixbus.com/terms-and-conditions-of-service", "EN"), null, null),
        "sbb" to Terms(L("https://www.sbb.ch/it/offerte/condizioni.html", "IT"), L("https://www.sbb.ch/it/biglietti-offerte/acquistare.html", "IT"), null),
        "tilo" to Terms(L("https://www.tilo.ch/servizi/informazioni-generali-clienti.html", "IT"), L("https://www.tilo.ch/servizi/titoli-di-trasporto.html", "IT"), null),
    )

    fun of(id: String): Terms? = byId[id]
}
