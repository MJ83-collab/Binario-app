package com.binario.treni.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.GermanyLive
import com.binario.treni.data.tx

/**
 * "Treni in Germania": come cercarli nell'app, tipi di treno, biglietti (Deutschlandticket, Sparpreis, BahnCard),
 * diritti dei passeggeri, assistenza e aziende. Fatti verificati il 30/10/2026 su bahn.de e regional.bahn.de.
 */
@Composable
fun GermanyScreen(onBack: () -> Unit, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val dt = GermanyLive.deutschlandTicketPrice()
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { GreenTopBar(tx("Treni in Germania"), onBack) }
        item {
            WhiteCard {
                Column(Modifier.padding(16.dp)) {
                    Text("🇩🇪 " + tx("Orari, ritardi e binari in tempo reale di tutte le aziende tedesche"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tx("Cerca una stazione tedesca come una italiana, anche con il nome italiano: «München», «Monaco di Baviera», «Colonia», «Berlin Hbf». Funzionano ricerca viaggi (anche Italia ⇄ Germania), tabellone partenze e arrivi, scheda del treno e «Segui»."),
                        fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tx("Dati: orari ufficiali tedeschi DELFI tramite Transitous. I prezzi non sono pubblici: si comprano su bahn.de o nell'app DB Navigator."),
                        color = Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Tipi di treno"))
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                    listOf(
                        "ICE" to tx("Alta velocità DB tra le grandi città; prenotazione del posto consigliata."),
                        "IC / EC" to tx("Intercity ed EuroCity: lunga percorrenza, anche verso Austria, Svizzera e Italia."),
                        "RE / RB / IRE" to tx("Regionali (DB Regio e molte altre aziende): validi con il Deutschlandticket."),
                        "S" to tx("S-Bahn delle città (Monaco, Berlino, Amburgo, Stoccarda…): validi con il Deutschlandticket."),
                        "FLX" to tx("FlixTrain: lunga percorrenza low cost, biglietto solo Flix."),
                        "NJ / ES" to tx("Treni notte: ÖBB Nightjet ed European Sleeper."),
                    ).forEach { (k, v) ->
                        Row(Modifier.padding(vertical = 4.dp)) {
                            Text(k, fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.width(96.dp))
                            Text(v, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Biglietti"))
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
                    Text("Deutschlandticket · $dt " + tx("al mese"), fontWeight = FontWeight.Bold)
                    Text(tx("Abbonamento mensile per tutti i treni regionali (RE, RB, S-Bahn), autobus, tram e metro in Germania. Non vale su ICE, IC, EC e FlixTrain. Si disdice entro il 10 del mese. Costa 63 € fino al 31/12/2026 e 66,80 € dal 1° gennaio 2027."),
                        fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Flexpreis", fontWeight = FontWeight.Bold)
                    Text(tx("Prezzo pieno: vale su qualsiasi treno del giorno indicato."), fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Sparpreis / Super Sparpreis", fontWeight = FontWeight.Bold)
                    Text(tx("Più economici se comprati in anticipo, ma legati al treno scelto (Zugbindung)."), fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("BahnCard 25 / 50 / 100", fontWeight = FontWeight.Bold)
                    Text(tx("Carte sconto annuali di DB (25% o 50%, oppure viaggi illimitati con la 100)."), fontSize = 14.sp)
                }
                MenuRow(Icons.Filled.ShoppingCart, tx("Compra su bahn.de"), "bahn.de") { openUrl(ctx, "https://www.bahn.de") }
                MenuRow(Icons.Filled.ConfirmationNumber, tx("Deutschlandticket: informazioni e acquisto"), "regional.bahn.de") {
                    openUrl(ctx, "https://regional.bahn.de/tickets/Deutschlandticket")
                }
                MenuRow(Icons.Filled.PhoneAndroid, tx("App DB Navigator (biglietti sul telefono)"), "Google Play") {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=de.hafas.android.db")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                        openUrl(ctx, "https://play.google.com/store/apps/details?id=de.hafas.android.db")
                    }
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Ritardi: i tuoi diritti"))
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) {
                    listOf(
                        tx("60 minuti o più di ritardo all'arrivo: rimborso del 25% del biglietto; 120 minuti o più: 50% (minimo 4 €)."),
                        tx("Ritardo previsto di oltre 20 minuti: la Zugbindung decade e anche con Sparpreis puoi prendere un altro treno."),
                        tx("Arrivo previsto tra mezzanotte e le 5 con almeno 60 minuti di ritardo: taxi rimborsato fino a 120 €."),
                        tx("La richiesta si fa entro 3 mesi su bahn.de, nel DB Navigator o con il modulo Fahrgastrechte."),
                    ).forEach { Text("• $it", fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
                }
                MenuRow(Icons.Filled.Gavel, tx("Diritti dei passeggeri (Fahrgastrechte)"), "bahn.de") {
                    openUrl(ctx, "https://www.bahn.de/service/informationen-buchung/fahrgastrechte")
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Assistenza per persone con disabilità"))
                MenuRow(Icons.Filled.Phone, "Mobilitätsservice-Zentrale DB · " + GermanyLive.MSZ_LABEL, tx("lun–ven 6–22, sab–dom e festivi 8–20")) {
                    try { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + GermanyLive.MSZ_PHONE))) } catch (_: Exception) { }
                }
                MenuRow(Icons.Filled.EditNote, tx("Prenota l'assistenza online (entro le 20 del giorno prima)"), "msz.bahnhof.de") { openUrl(ctx, GermanyLive.MSZ_FORM) }
            }
        }
        // Scioperi in Germania e circolazione (guasti e cantieri ufficiali DB)
        item { GermanStrikesCard() }
        item {
            WhiteCard {
                CardTitle(tx("Aziende e stazioni"))
                MenuRow(Icons.Filled.Apartment, tx("Tutte le imprese ferroviarie tedesche"), tx("DB, FlixTrain, Arverio, Länderbahn, metronom, ODEG… (filtro «Germania»)")) { go("railways") }
                MenuRow(Icons.Filled.Store, tx("Servizi in stazione"), tx("Apri il tabellone di una stazione tedesca › scheda «Stazione»: servizi, ascensori e accessibilità da bahnhof.de")) {
                    openUrl(ctx, "https://www.bahnhof.de")
                }
            }
        }
    }
}

/**
 * Scioperi dei treni in Germania (notizie degli ultimi 14 giorni). In Germania non c'è un calendario ufficiale
 * come quello del Ministero italiano: GDL ed EVG annunciano gli scioperi pochi giorni prima.
 */
@Composable
fun GermanStrikesCard() {
    val ctx = LocalContext.current
    var news by remember { mutableStateOf<List<GermanyLive.StrikeNews>?>(null) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        news = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try { GermanyLive.strikeNews() } catch (_: Exception) { failed = true; emptyList() }
        }
    }
    WhiteCard {
        CardTitle("🇩🇪 " + tx("Scioperi dei treni in Germania"))
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 4.dp)) {
            val l = news
            when {
                l == null -> LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                failed -> Text(tx("Notizie non raggiungibili ora."), color = Muted, fontSize = 13.sp)
                l.isEmpty() -> Text(tx("Nessuno sciopero dei treni annunciato in Germania negli ultimi 14 giorni."), color = Muted, fontSize = 13.sp)
                else -> l.forEach { n ->
                    Column(Modifier.fillMaxWidth().clickable { openUrl(ctx, n.url) }.padding(vertical = 6.dp)) {
                        Text(n.title, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        Text(listOf(n.source, com.binario.treni.data.Fmt.dayTime(n.time)).filter { it.isNotBlank() }.joinToString(" · "), color = Muted, fontSize = 12.sp)
                    }
                }
            }
            Text(tx("Notizie in tedesco (Google News): in Germania gli scioperi vengono annunciati dai sindacati GDL ed EVG pochi giorni prima, senza un calendario ufficiale."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        MenuRow(Icons.Filled.Warning, tx("Circolazione in Germania: guasti e cantieri (DB)"), "verkehrslage.bahnhof.de") { openUrl(ctx, GermanyLive.DB_TRAFFIC) }
    }
}
