package com.binario.treni.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.SearchFilter
import com.binario.treni.data.Solution
import com.binario.treni.data.Station
import com.binario.treni.data.Store
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * «Piano B»: se perdi il treno o la coincidenza, propone le alternative dalla stazione in cui sei adesso fino alla destinazione
 * di questo treno. La stazione di partenza è quella scelta con «Salgo qui», altrimenti la prossima fermata; si può cambiare.
 */
@Composable
fun PlanBCard(st: TrainStatus, onTrain: (TrainRef) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val dest = st.stops.lastOrNull()?.station ?: return
    val upcoming = remember(st.ref.key, st.stops) { st.stops.filter { !it.passed }.dropLast(1).take(8) }
    var open by remember(st.ref.key) { mutableStateOf(false) }
    var pick by remember { mutableStateOf(false) }
    var from by remember(st.ref.key) {
        mutableStateOf<Station?>(
            Store(ctx).boardingStation()?.takeIf { b -> upcoming.any { it.id == b.id || it.name.equals(b.name, true) } }
                ?: upcoming.firstOrNull()?.station,
        )
    }
    var rows by remember { mutableStateOf<List<Solution>?>(null) }
    LaunchedEffect(open, from?.id) {
        val f = from
        if (!open || f == null) return@LaunchedEffect
        rows = null
        rows = try {
            withContext(Dispatchers.IO) {
                val now = System.currentTimeMillis()
                Api.solutions(f, dest, now - 2 * 60_000L, SearchFilter.ALL).filter { it.dep >= now - 2 * 60_000L }.take(5)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    WhiteCard {
        Column(Modifier.fillMaxWidth().clickable { open = !open }.padding(14.dp)) {
            Text(tx("Piano B"), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (!open) Text(tx("Ho perso il treno o la coincidenza? Trova le alternative da dove sei adesso."), color = Muted, fontSize = 13.sp)
        }
        if (open) {
            Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
                Text(tx("Dove sei adesso"), color = Muted, fontSize = 12.sp)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    upcoming.forEach { s ->
                        FilterChip(from?.id == s.id, { from = s.station }, label = { Text(s.name) }, modifier = Modifier.padding(end = 6.dp))
                    }
                    FilterChip(upcoming.none { it.id == from?.id } && from != null, { pick = true },
                        label = { Text(if (upcoming.none { it.id == from?.id } && from != null) from!!.name else tx("Un'altra stazione…")) })
                }
                Spacer(Modifier.height(6.dp))
                Text(tx("Alternative verso") + " " + dest.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                val r = rows
                when {
                    from == null -> {}
                    r == null -> Text(tx("Cerco le alternative…"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    r.isEmpty() -> Text(tx("Nessuna alternativa trovata nelle prossime ore."), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    else -> {
                        r.forEach { s ->
                            val leg = s.legs.first()
                            Row(Modifier.fillMaxWidth().clickable { onTrain(TrainRef(leg.number, label = leg.title)) }.padding(vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(Fmt.time(s.dep) + " → " + Fmt.time(s.arr), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(s.legs.joinToString(" · ") { it.title } + " · " +
                                        (if (s.changes == 0) tx("diretto") else "${s.changes} " + tx("cambi")), color = Muted, fontSize = 12.sp)
                                }
                                Text(s.duration.ifBlank { Fmt.duration(s.dep, s.arr) }, fontSize = 13.sp)
                            }
                        }
                        Text(tx("Tocca un treno per aprirlo. Gli orari sono quelli programmati: controlla ritardi e binari nella scheda."), color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
    if (pick) StationPickerDialog(tx("Dove sei adesso"), { pick = false }) { s -> from = s; pick = false }
}
