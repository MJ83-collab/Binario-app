package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Storico personale dei ritardi: ogni volta che apri un treno già partito l'app ricorda il ritardo di quel giorno
 * (aggiornato fino all'arrivo). Tutto resta sul telefono. Serve a dire «questo treno, quando l'hai visto, ha fatto in media X min».
 */
object DelayHistory {
    data class Entry(val day: String, val delay: Int, val done: Boolean, val cancelled: Boolean)

    private const val KEEP = 40
    private val rome = TimeZone.getTimeZone("Europe/Rome")

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("binario_hist", Context.MODE_PRIVATE)
    private fun key(st: TrainStatus) = Habits.digits(st.number) + "@" + (st.stops.firstOrNull()?.id ?: st.originCode)
    private fun day(t: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date(t))

    @Synchronized
    fun record(ctx: Context, st: TrainStatus) {
        if (!st.cancelled && !st.departed && !st.arrived) return
        val d = day(if (st.depTime > 0) st.depTime else System.currentTimeMillis())
        val k = key(st)
        val list = entries(ctx, k).filter { it.day != d }.toMutableList()
        val old = entries(ctx, k).firstOrNull { it.day == d }
        // Un valore definitivo (arrivato/soppresso) non viene più sovrascritto
        if (old != null && old.done) return
        list += Entry(d, st.delay, st.arrived || st.cancelled, st.cancelled)
        val out = list.sortedBy { it.day }.takeLast(KEEP)
        val a = JSONArray()
        out.forEach { a.put(JSONObject().put("d", it.day).put("l", it.delay).put("f", it.done).put("c", it.cancelled)) }
        prefs(ctx).edit().putString(k, a.toString()).apply()
    }

    private fun entries(ctx: Context, k: String): List<Entry> = try {
        val a = JSONArray(prefs(ctx).getString(k, "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map { Entry(it.getString("d"), it.getInt("l"), it.optBoolean("f"), it.optBoolean("c")) }
    } catch (_: Exception) {
        emptyList()
    }

    fun forTrain(ctx: Context, st: TrainStatus): List<Entry> = entries(ctx, key(st))
}
