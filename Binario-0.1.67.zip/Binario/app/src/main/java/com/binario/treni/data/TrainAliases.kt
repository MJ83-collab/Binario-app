package com.binario.treni.data

import android.content.Context
import org.json.JSONArray

/**
 * Doppia numerazione dei treni Trenord che passano da una rete all'altra (RFI ↔ FerrovieNord, RFI ↔ FFS).
 * Esempio: l'S50 Mendrisio – Malpensa è il 25553 fino a Busto Arsizio FS e il 20305 sulla rete FerrovieNord.
 * Fonte: intestazioni delle colonne degli orari PDF ufficiali Trenord («Orario ferroviario», trenord.it), dove i due
 * numeri della stessa corsa sono scritti uno sotto l'altro. Quadri letti: S1-S3-S12-S13, S2-S4-S12 (e R16 Q169),
 * MXP (Malpensa Express) e FMV (S50). Le coppie valgono per l'orario in vigore: ad ogni cambio orario vanno riviste.
 * ViaggiaTreno e gli orari aperti (GTFS) mostrano un solo numero, perciò l'abbinamento è fatto qui.
 */
object TrainAliases {
    data class Alias(val other: String, val line: String)

    @Volatile
    private var map: Map<String, List<Alias>> = emptyMap()

    fun ensure(ctx: Context) {
        if (map.isNotEmpty()) return
        map = try {
            val a = JSONArray(ctx.applicationContext.assets.open("train_aliases.json").bufferedReader().use { it.readText() })
            val m = HashMap<String, MutableList<Alias>>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val x = o.getString("a")
                val y = o.getString("b")
                val l = o.optString("l")
                m.getOrPut(x) { mutableListOf() }.add(Alias(y, l))
                m.getOrPut(y) { mutableListOf() }.add(Alias(x, l))
            }
            m
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun key(number: String) = Api.trainDigits(number).trimStart('0')

    /** Altri numeri della stessa corsa (vuoto se il treno non cambia numero). Solo per il numero: vedi [othersFor]. */
    fun others(number: String): List<Alias> = map[key(number)].orEmpty()

    /**
     * Il numero da solo non basta: lo stesso numero esiste su altre reti (es. 20309 è anche un regionale Trenitalia
     * Tivoli – Val d'Ala). La doppia numerazione vale solo se la corsa parte/arriva nell'area della rete Trenord
     * (codici stazione ViaggiaTreno S00 Piemonte-Novara, S01 Lombardia, S04 Liguria-Genova, FFS, FerrovieNord).
     */
    private fun inArea(id: String): Boolean {
        if (id.isBlank()) return false
        if (id.startsWith("S01") || id.startsWith("S00") || id.startsWith("S04") || id.startsWith("83")) return true
        return try { FnNetwork.isFn(id) } catch (_: Exception) { false }
    }

    fun inTrenordArea(originId: String) = inArea(originId)

    /** Alias validi per una corsa precisa (origine = codice stazione di partenza, altri = fermate note). */
    fun othersFor(number: String, originId: String, vararg otherIds: String): List<Alias> {
        val l = others(number)
        if (l.isEmpty()) return l
        return if (inArea(originId) || otherIds.any { inArea(it) }) l else emptyList()
    }

    /** Codice della zona della corsa da passare a TrainTitle: la prima fermata dentro la rete Trenord, altrimenti la prima. */
    fun originKey(st: TrainStatus): String =
        (listOf(st.stops.firstOrNull()?.id ?: "", st.stops.lastOrNull()?.id ?: "", st.originCode)).firstOrNull { inArea(it) }
            ?: (st.stops.firstOrNull()?.id ?: "x")

    /** La corsa è davvero un Trenord/TILO/FNM: impresa compatibile e almeno una fermata nell'area (il numero non basta). */
    fun isTrenordRun(st: TrainStatus): Boolean {
        val opOk = st.operator.isBlank() || Regex("trenord|tilo|sbb|ffs|ferrovienord|fnm", RegexOption.IGNORE_CASE).containsMatchIn(st.operator)
        return opOk && (st.stops.any { inArea(it.id) } || inArea(st.originCode))
    }

    fun othersFor(st: TrainStatus): List<Alias> =
        othersFor(st.number, st.stops.firstOrNull()?.id ?: "", st.stops.lastOrNull()?.id ?: "", st.originCode)
}
