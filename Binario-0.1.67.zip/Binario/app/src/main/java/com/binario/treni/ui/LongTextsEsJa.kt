package com.binario.treni.ui

// Testi lunghi in spagnolo e giapponese (widget, aiuto, privacy, note legali, novità).

const val WIDGETS_TEXT_ES = """Mantén pulsado un espacio vacío de la pantalla de inicio → Widgets → Binario y elige qué mostrar. Toca el título del widget para cambiarlo.

• Trayecto / Línea: próximos trenes de un trayecto o de una línea favorita (p. ej. S5), con retraso y vía.
• Tren: el recorrido de un tren parada a parada.
• Estación: salidas de la estación que elijas.
• Favoritos: el estado de todos tus trenes favoritos de un vistazo.

Toca una fila para abrir el tren o el panel de salidas."""

const val WIDGETS_TEXT_JA = """ホーム画面の空いている場所を長押し → ウィジェット → Binario を選び、表示する内容を選びます。ウィジェットのタイトルをタップすると変更できます。

• ルート／路線：ルートやお気に入りの路線（例：S5）の次の列車と、遅延・番線。
• 列車：列車の停車駅ごとの運行状況。
• 駅：選んだ駅の発車案内。
• お気に入り：お気に入りの列車すべての状況をひと目で。

行をタップすると列車や発車案内が開きます。"""

const val HELP_TEXT_ES = """¿Cómo busco un horario?
En la pestaña Buscar elige origen y destino, fecha y hora, y toca Buscar. Toca el nombre de un tren (p. ej. "TI FR 9627") para ver retrasos, paradas y vías.

¿Cómo veo el panel de salidas de una parada?
En la vista del tren toca una parada y elige "Salidas y llegadas desde aquí".

¿Cómo funciona la alarma de parada?
En la vista del tren toca la parada donde bajas y elige "Despiértame antes de esta parada". La alarma suena cuando el tren sale de la parada anterior (o 4 minutos antes de la llegada prevista). Activa "Avisos para personas sordas o con discapacidad auditiva" en Ajustes para tener vibración fuerte y flash.

¿Cómo añado una línea?
Pestaña Trenes → Líneas favoritas → Añadir, p. ej. S5 con los extremos Varese y Treviglio.

¿Cómo configuro un widget?
Añádelo desde la pantalla de inicio y elige qué mostrar. Para cambiarlo, toca el título del widget.

¿Puedo hacer preguntas?
Sí: abre el asistente de trenes (icono del bocadillo en Buscar) y pregunta p. ej. "retraso tren 2070" o "trenes de Varese a Milano".

¿Dónde veo los trenes en el mapa?
Abre «Mapa de trenes» en el menú (☰): empieza solo con Italia, luego puedes añadir otros países y la app recuerda tu elección. Toca un punto para ver número, empresa, retraso y próxima parada.

¿Dónde encuentro las condiciones y tarifas de una empresa?
Menú (☰) › Condiciones de transporte › Condiciones y tarifas por empresa: abre la empresa y toca el enlace oficial. Se indican la fuente y la fecha de comprobación.

¿Cómo envío un comentario?
Menú (☰) › Enviar comentarios."""

const val HELP_TEXT_JA = """時刻表を検索するには？
検索タブで出発地と目的地、日付と時刻を選び、「検索」をタップします。列車名（例：「TI FR 9627」）をタップすると、遅延、停車駅、番線を確認できます。

停車駅の発車案内を見るには？
列車の画面で停車駅をタップし、「ここからの出発と到着」を選びます。

降車アラームの仕組みは？
列車の画面で降りる駅をタップし、「この駅の前に起こして」を選びます。列車が前の駅を出発したとき（または到着予定の4分前）にアラームが鳴ります。強い振動とフラッシュを使うには、設定で「聴覚に障がいのある方向けの通知」をオンにしてください。

路線を追加するには？
列車タブ → お気に入りの路線 → 追加。例：S5、終点はVareseとTreviglio。

ウィジェットを設定するには？
ホーム画面から追加し、表示する内容を選びます。変更するにはウィジェットのタイトルをタップします。

質問できますか？
はい：列車アシスタント（検索画面の吹き出しアイコン）を開き、たとえば「2070列車の遅延」や「VareseからMilanoへの列車」と質問してください。

地図で列車はどこに表示されますか？
メニュー（☰）から「列車マップ」を開きます。最初はイタリアのみで、他の国を追加でき、選択はアプリが記憶します。点をタップすると、番号、事業者、遅延、次の停車駅が表示されます。

会社の条件や運賃はどこで確認できますか？
メニュー（☰）›「運送条件」›「会社別の条件と運賃」で会社を開き、公式リンクをタップします。出典と確認日が表示されます。

フィードバックはどう送りますか？
メニュー（☰）›「フィードバックを送る」。"""

const val PRIVACY_TEXT_ES = """Política de privacidad (RGPD) · actualizada en noviembre de 2026

Responsable del tratamiento: Marco Jannino, desarrollador independiente de Binario. Contacto: «Comentarios e informar de un error» en la app.

En breve
• Sin cuenta, sin publicidad, sin herramientas de estadísticas ni de seguimiento. Binario no tiene servidor propio y no recibe tus datos.
• Favoritos, búsquedas recientes, trenes habituales, recordatorios, ajustes y registro «verde» quedan solo en tu teléfono. Se borran al desinstalar la app o desde los ajustes de Android.

Servicios externos
Para mostrar horarios, retrasos y mapas, la app contacta directamente con servicios públicos: ViaggiaTreno (RFI/Trenitalia), LeFrecce, Italo, Trenord, FerrovieNord, TILO, SBB, DB, Transitous, TrovaTreno, el observatorio de huelgas del Ministerio, OpenStreetMap (mapas, Overpass, Nominatim, OSRM) y similares. Como cualquier sitio web, reciben tu dirección IP y los datos de la solicitud (por ejemplo, estación o número de tren) y los tratan según sus propias políticas. Binario no los envía a nadie más.

Ubicación
Solo si concedes el permiso y solo en las pantallas que la usan (estaciones cercanas, puntos de venta, servicios). Para buscar lugares cercanos, las coordenadas se envían a los servidores de OpenStreetMap (Overpass), que también reciben tu IP. Binario no las guarda y no usa la ubicación en segundo plano.

Comentarios
Si envías «Comentarios e informar de un error», nombre, correo y mensaje (y, si lo eliges, versión de la app y modelo del teléfono) llegan a un formulario de Google del desarrollador y sirven solo para responderte; Google trata esos datos por cuenta del desarrollador. La dirección del formulario se lee de un archivo público en GitHub. Sin red, el mensaje queda en el teléfono y se envía en cuanto sea posible. Se conserva mientras haga falta para gestionar tu solicitud: puedes pedir que se borre.

Actualizaciones
La app comprueba en GitHub si hay una versión nueva (al abrir y aproximadamente cada hora en segundo plano, con una notificación si la hay) y, si aceptas, descarga el APK desde allí (GitHub recibe tu IP). Para instalarlo, Android pide el permiso «instalar apps desconocidas».

Voz
Los avisos de voz usan la síntesis de voz del teléfono, sin enviar datos. Las preguntas por voz pasan por el reconocimiento de voz del teléfono (normalmente Google): Binario no pide el micrófono.

Permisos
• Notificaciones: notificación fija del tren, recordatorios y avisos de huelga (programados en el teléfono, sin servidor de notificaciones).
• Servicio en primer plano, bloqueo de suspensión y optimización de batería: mantener actualizado el tren seguido.
• Inicio al arrancar, alarmas y recordatorios: restaurar y entregar a tiempo las notificaciones programadas.
• Ubicación: estaciones y servicios cercanos, mapa.
• Instalar apps desconocidas: solo para actualizar Binario.
• Vibración.

Base jurídica y derechos
El único tratamiento del desarrollador (los comentarios) se basa en tu consentimiento, es decir, en enviar el mensaje. Tienes derecho de acceso, rectificación, supresión, limitación, oposición y portabilidad (arts. 15-22 RGPD): escribe desde la app. Puedes presentar una reclamación ante la autoridad italiana de protección de datos (garanteprivacy.it). Para los datos tratados por servicios externos, contacta con ellos.

Esta app no está afiliada a Trenitalia, RFI, Italo ni Trenord."""

const val PRIVACY_TEXT_JA = """プライバシーに関するお知らせ（GDPR）· 2026年11月更新

管理者：Binario の個人開発者 Marco Jannino。連絡先：アプリ内の「フィードバックとバグ報告」。

要点
• アカウントなし、広告なし、統計や追跡ツールなし。Binario は独自のサーバーを持たず、あなたのデータを受け取りません。
• お気に入り、最近の検索、よく使う列車、リマインダー、設定、グリーン記録は端末内にのみ保存され、アプリのアンインストールまたは Android の設定で削除できます。

外部サービス
時刻表、遅延、地図を表示するため、アプリは公的サービスに直接接続します：ViaggiaTreno（RFI/Trenitalia）、LeFrecce、Italo、Trenord、FerrovieNord、TILO、SBB、DB、Transitous、TrovaTreno、省のスト観測所、OpenStreetMap（地図、Overpass、Nominatim、OSRM）など。一般のウェブサイトと同様に、IP アドレスとリクエスト内容（駅名や列車番号など）が先方に届き、各社の方針で扱われます。Binario がそれらを他者へ送ることはありません。

位置情報
許可した場合のみ、位置を使う画面（近くの駅、販売所、サービス）でのみ使います。近くの場所を探すため、座標は OpenStreetMap のサーバー（Overpass）に送信され、IP も先方に届きます。Binario は座標を保存せず、バックグラウンドでも使いません。

フィードバック
「フィードバックとバグ報告」を送ると、名前、メール、メッセージ（選んだ場合はアプリのバージョンと端末モデル）が開発者の Google フォームに届き、返信のためだけに使われます。Google は開発者に代わってそのデータを処理します。フォームのアドレスは GitHub の公開ファイルから読み込みます。ネットワークがないときは端末に保管され、可能になり次第送信されます。対応に必要な間のみ保管し、削除を求めることもできます。

アップデート
アプリは GitHub で新しいバージョンを確認し（起動時とバックグラウンドで約1時間ごと、あれば通知）、同意すると APK をそこからダウンロードします（GitHub に IP が届きます）。インストール時に Android が「不明なアプリのインストール」の許可を求めます。

音声
音声通知は端末の音声合成を使い、データは送信しません。音声での質問は端末の音声認識（通常は Google）を通ります。Binario はマイクの許可を求めません。

権限
• 通知：列車の常時通知、リマインダー、スト通知（端末内でスケジュール、プッシュサーバーなし）。
• フォアグラウンドサービス、スリープ防止、電池の最適化：追跡中の列車を更新し続けるため。
• 起動時の実行、アラーム、リマインダー：予約済みの通知を復元し、時間どおりに届けるため。
• 位置情報：近くの駅とサービス、地図。
• 不明なアプリのインストール：Binario の更新にのみ使用。
• バイブレーション。

法的根拠と権利
開発者が行う唯一の処理（フィードバック）は、メッセージの送信という同意に基づきます。アクセス、訂正、削除、制限、異議、ポータビリティの権利（GDPR 第15〜22条）があります。アプリからご連絡ください。イタリアのデータ保護機関（garanteprivacy.it）に苦情を申し立てることもできます。外部サービスが扱うデータについては、各サービスにお問い合わせください。

このアプリは Trenitalia、RFI、Italo、Trenord とは無関係です。"""

const val LEGAL_NOTE_ES = "Las notas legales aún no están disponibles en español; abajo está el texto original en inglés, que es el que prevalece.\n\n"
const val LEGAL_NOTE_JA = "法的情報の日本語版はまだありません。以下は英語の原文で、原文が優先されます。\n\n"

const val CHANGELOG_TEXT_ES = """0.1.67-alpha
• Corregido el enlace «página oficial de la línea» de Trenord (mostraba «Access Denied»); comprobadas las páginas de líneas TILO y los enlaces de ejes Trenord. Registro de novedades e informe de correcciones reiniciados.

0.1.66-alpha
• Si falla el envío del comentario, aparece el botón «Enviar por correo» (dirección leída del archivo de configuración, no escrita en la app).
"""

const val CHANGELOG_TEXT_JA = """0.1.67-alpha
• Trenordの「路線の公式ページ」リンクを修正しました（「Access Denied」と表示されていました）。TILOの路線ページとTrenordの路線リンクを確認しました。更新履歴と修正レポートを最初からやり直しました。

0.1.66-alpha
• フィードバックの送信に失敗した場合、「メールで送信」ボタンが表示されます（アドレスは設定ファイルから読み込まれ、アプリ内には記載されません）。
"""
