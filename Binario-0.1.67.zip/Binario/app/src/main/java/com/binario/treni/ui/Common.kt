package com.binario.treni.ui

import androidx.lifecycle.compose.currentStateAsState
import kotlinx.coroutines.flow.first

import com.binario.treni.data.tx
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.binario.treni.data.Api
import com.binario.treni.data.Station
import com.binario.treni.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Colore principale: verde, oppure blu / verde acqua in modalità daltonici (si aggiorna subito in tutta l'app). */
private val vintageOn: Boolean get() = com.binario.treni.data.AppStyle.vintage && !com.binario.treni.data.ColorBlind.on
val Green: Color get() = if (vintageOn) Color(0xFF9A7420) else Color(com.binario.treni.data.ColorBlind.brand)
val GreenDark: Color get() = if (vintageOn) Color(0xFF6F5316) else Color(com.binario.treni.data.ColorBlind.brandDark)
val GreenField: Color get() = if (vintageOn) Color(0xFFB48A2C) else Color(com.binario.treni.data.ColorBlind.brandField)
/** Rosso ritardo (arancio in modalità daltonici). */
val LateRed: Color get() = Color(com.binario.treni.data.ColorBlind.late)
/** Verde "in orario" (blu in modalità daltonici). */
val OnTime: Color get() = Color(com.binario.treni.data.ColorBlind.ok)
val EarlyBlue = Color(0xFF1976D2)
val PassedBlue = Color(0xFF1E88E5)
val Muted = Color(0xFF8A8A8A)

@Composable
fun BinarioTheme(theme: String = "system", content: @Composable () -> Unit) {
    val vintage = com.binario.treni.data.AppStyle.vintage
    val dark = if (vintage) true else when (theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val scheme = if (vintage) darkColorScheme(
        primary = Color(0xFFF5C84C), onPrimary = Color.Black, secondary = Color(0xFFF5C84C), onSecondary = Color.Black,
        background = Color(0xFF0B0B0C), onBackground = Color(0xFFF2EFE6), surface = Color(0xFF18181A), onSurface = Color(0xFFF2EFE6),
        surfaceVariant = Color(0xFF242427), onSurfaceVariant = Color(0xFFD8D2C0), outline = Color(0xFF6F6A5C),
    ) else if (dark) darkColorScheme(
        primary = Color(com.binario.treni.data.ColorBlind.brandOnDark), onPrimary = Color.Black, secondary = Color(com.binario.treni.data.ColorBlind.brandOnDark),
        background = Color(0xFF121212), surface = Color(0xFF1F1F1F), surfaceVariant = Color(0xFF2A2A2A),
    ) else lightColorScheme(
        primary = Green, onPrimary = Color.White, secondary = Green, onSecondary = Color.White,
        background = Color(0xFFEDEDED), surface = Color.White, surfaceVariant = Color(0xFFF4F4F4),
    )
    MaterialTheme(colorScheme = scheme, typography = if (vintage) monoTypography() else androidx.compose.material3.Typography(), content = content)
}

/** Tipografia a spaziatura fissa per lo stile vintage. */
private fun monoTypography(): androidx.compose.material3.Typography {
    val b = androidx.compose.material3.Typography()
    val f = androidx.compose.ui.text.font.FontFamily.Monospace
    return b.copy(
        displayLarge = b.displayLarge.copy(fontFamily = f), displayMedium = b.displayMedium.copy(fontFamily = f), displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f), headlineMedium = b.headlineMedium.copy(fontFamily = f), headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f), titleMedium = b.titleMedium.copy(fontFamily = f), titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f), bodyMedium = b.bodyMedium.copy(fontFamily = f), bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f), labelMedium = b.labelMedium.copy(fontFamily = f), labelSmall = b.labelSmall.copy(fontFamily = f),
    )
}

/** Barra superiore verde comune a tutte le schermate. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GreenTopBar(title: String, onBack: (() -> Unit)? = null, onMenu: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = {
            if (com.binario.treni.data.AppStyle.vintage) Text(title.uppercase(), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            else Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 20.sp)
        },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tx("Indietro")) }
            else if (onMenu != null) IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, tx("Menu")) }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = if (com.binario.treni.data.AppStyle.vintage) Color(0xFF141416) else Green,
            titleContentColor = if (com.binario.treni.data.AppStyle.vintage) Color(0xFFF5C84C) else Color.White,
            navigationIconContentColor = if (com.binario.treni.data.AppStyle.vintage) Color(0xFFF5C84C) else Color.White,
            actionIconContentColor = if (com.binario.treni.data.AppStyle.vintage) Color(0xFFF5C84C) else Color.White,
        ),
    )
}

/** Voce del menu ⋮ della barra in alto. */
data class BarAction(val icon: androidx.compose.ui.graphics.vector.ImageVector, val label: String, val onClick: () -> Unit)

/**
 * Menu ⋮ della barra verde: le azioni meno usate vanno qui, con icona e nome, così le icone non si sovrappongono
 * e il titolo resta leggibile anche sui telefoni stretti.
 */
@Composable
fun BarOverflow(items: List<BarAction>) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }) { Icon(Icons.Filled.MoreVert, tx("Altre azioni")) }
        DropdownMenu(open, { open = false }) {
            items.forEach { a ->
                DropdownMenuItem(
                    text = { Text(a.label) },
                    leadingIcon = { Icon(a.icon, null, tint = Green) },
                    onClick = { open = false; a.onClick() },
                )
            }
        }
    }
}

/** Scheda bianca con leggera ombra, come nelle schermate di riferimento. */
@Composable
fun WhiteCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val m = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
    if (onClick != null) {
        Card(
            onClick = onClick, modifier = m, shape = RoundedCornerShape(3.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp), content = content,
        )
    } else {
        Card(
            modifier = m, shape = RoundedCornerShape(3.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp), content = content,
        )
    }
}

@Composable
fun SectionHeader(text: String) {
    Text(
        text, style = MaterialTheme.typography.bodyMedium, color = Muted,
        modifier = Modifier.padding(start = 18.dp, top = 16.dp, bottom = 6.dp),
    )
}

/** Titolo verde di una sezione dentro una scheda (stile impostazioni). */
@Composable
fun CardTitle(text: String) {
    Text(text, color = Green, fontSize = 22.sp, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 10.dp))
    HorizontalDivider(color = Color(0x14000000))
}

fun categoryColor(cat: String): Color {
    val c = cat.uppercase()
    return when {
        c.startsWith("FR") || c.startsWith("FA") || c.contains("FRECCIAROSSA") || c.contains("FRECCIARGENTO") ||
            c.startsWith("ITA") || c.contains("ITALO") -> Color(0xFFC62828)
        c.startsWith("FB") || c.contains("FRECCIABIANCA") -> Color(0xFF1565C0)
        c.startsWith("IC") || c.startsWith("EC") || c.startsWith("EN") || c.contains("THELLO") -> Color(0xFF2E7D32)
        else -> Color(0xFF37474F)
    }
}

/**
 * "Trenord REG 2159", "Trenitalia FR 9627": impresa che effettua il servizio in grigio, categoria e numero colorati.
 * [operator] arriva da ViaggiaTreno quando c'è; altrimenti viene ricavata dal nome del treno.
 */
@Composable
fun TrainTitle(category: String, number: String, size: Int = 18, operator: String? = null, originId: String? = null, onClick: (() -> Unit)? = null) {
    val op = operator?.takeIf { it.isNotBlank() } ?: com.binario.treni.data.Operators.fromText(category, number)
    val num = com.binario.treni.data.Operators.cleanNumber(number).let { n -> if (op.isNotBlank() && n.startsWith("$op ")) n.removePrefix("$op ").trim() else n }
    // Doppia numerazione (RFI / FerrovieNord / FFS): «24114/11813»
    // Il numero da solo non basta (20309 è anche un regionale Trenitalia nel Lazio): serve l'impresa o la zona della corsa.
    val alias = (if (originId != null) com.binario.treni.data.TrainAliases.othersFor(num, originId)
        else if (Regex("trenord|tilo|sbb|ffs|ferrovienord|trenitalia tilo", RegexOption.IGNORE_CASE).containsMatchIn(op)) com.binario.treni.data.TrainAliases.others(num)
        else emptyList()).firstOrNull()?.other
    val shownNum = if (alias != null) "$num/$alias" else num
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = if (onClick != null) Modifier.clip(RoundedCornerShape(4.dp)).clickable(onClick = onClick).padding(vertical = 2.dp) else Modifier,
    ) {
        // Impresa in grassetto con il colore del testo (ben leggibile sia nel tema chiaro sia in quello scuro)
        if (op.isNotBlank()) {
            Text(op, color = MaterialTheme.colorScheme.onSurface, fontSize = size.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(8.dp))
        }
        // Categoria e numero in un'etichetta piena: testo bianco su colore della categoria (alto contrasto)
        Text(
            "$category $shownNum".trim(), color = Color.White, fontSize = (size - 1).sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(categoryColor(category)).padding(horizontal = 6.dp, vertical = 1.dp),
        )
    }
}

/** Riquadro del binario: azzurro se confermato/reale, grigio se programmato. */
@Composable
fun PlatformBox(platform: String, confirmed: Boolean, changed: Boolean = false) {
    if (platform.isBlank()) return
    Box(
        Modifier.clip(RoundedCornerShape(3.dp))
            .background(if (confirmed) Color(0xFFDCEBFB) else Color(0xFFEEEEEE))
            .padding(horizontal = 7.dp, vertical = 2.dp),
    ) {
        Text(platform, color = if (confirmed || changed) EarlyBlue else Color(0xFF555555), fontSize = 15.sp)
    }
}

/**
 * Binario previsto e binario reale affiancati.
 * Grigio = previsto (programmato); azzurro = reale confermato; rosso = binario cambiato rispetto al previsto.
 */
@Composable
fun PlatformPair(sched: String, real: String, compact: Boolean = false) {
    if (sched.isBlank() && real.isBlank()) return
    val changed = real.isNotBlank() && sched.isNotBlank() && real != sched
    if (compact) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            when {
                changed -> {
                    PlatBox(sched, PlatStyle.STRUCK)
                    Text(" → ", color = LateRed, fontSize = 13.sp)
                    PlatBox(real, PlatStyle.CHANGED)
                }
                real.isNotBlank() -> PlatBox(real, PlatStyle.REAL)
                else -> PlatBox(sched, PlatStyle.SCHED)
            }
        }
        return
    }
    Column(horizontalAlignment = Alignment.End) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tx("Previsto") + " ", color = Muted, fontSize = 10.sp)
            PlatBox(sched.ifBlank { "–" }, if (changed) PlatStyle.STRUCK else PlatStyle.SCHED)
        }
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tx("Reale") + " ", color = Muted, fontSize = 10.sp)
            PlatBox(real.ifBlank { "–" }, when {
                real.isBlank() -> PlatStyle.EMPTY
                changed -> PlatStyle.CHANGED
                else -> PlatStyle.REAL
            })
        }
    }
}

private enum class PlatStyle { SCHED, REAL, CHANGED, STRUCK, EMPTY }

@Composable
private fun PlatBox(text: String, style: PlatStyle) {
    val (bg, fg) = when (style) {
        PlatStyle.SCHED -> Color(0xFFEEEEEE) to Color(0xFF555555)
        PlatStyle.REAL -> Color(0xFFDCEBFB) to EarlyBlue
        PlatStyle.CHANGED -> Color(0xFFFDE0E0) to LateRed
        PlatStyle.STRUCK -> Color(0xFFF5F5F5) to Color(0xFF9E9E9E)
        PlatStyle.EMPTY -> Color(0xFFF5F5F5) to Color(0xFFBDBDBD)
    }
    Box(Modifier.clip(RoundedCornerShape(3.dp)).background(bg).padding(horizontal = 7.dp, vertical = 2.dp)) {
        Text(
            text, color = fg, fontSize = 15.sp, fontWeight = if (style == PlatStyle.CHANGED) FontWeight.Bold else FontWeight.Normal,
            textDecoration = if (style == PlatStyle.STRUCK) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
        )
    }
}

/** Icona del treno colorata come nell'app Trenord: verde, giallo, rosso. */
@Composable
fun CrowdBadge(c: com.binario.treni.data.Crowd?, withLabel: Boolean = false) {
    if (c == null) return
    val col = Color(c.level.color)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Train, c.level.label, tint = col, modifier = Modifier.size(18.dp))
        if (com.binario.treni.data.ColorBlind.on) Text(c.level.symbol, color = col, fontSize = 13.sp)
        if (c.source == com.binario.treni.data.Crowd.Source.ESTIMATE) Text("≈", color = col, fontSize = 11.sp)
        if (withLabel) {
            Spacer(Modifier.width(6.dp))
            Text(c.level.label, color = col, fontSize = 13.sp)
        }
    }
}

/** "+13 min" in rosso, "-2 min" in verde. */
@Composable
fun DelayBadge(delay: Int, cancelled: Boolean = false, showZero: Boolean = false) {
    when {
        cancelled -> Text(com.binario.treni.data.ColorBlind.delaySymbol(0, true) + "SOPP.", color = LateRed, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        delay != 0 || showZero -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(com.binario.treni.data.ColorBlind.delaySymbol(delay, false) + (if (delay > 0) "+$delay" else "$delay"), color = if (delay > 0) LateRed else OnTime, fontSize = 20.sp)
            Text("min", color = if (delay > 0) LateRed else OnTime, fontSize = 13.sp)
        }
    }
}

@Composable
fun DelayText(delay: Int, departed: Boolean = true, cancelled: Boolean = false, modifier: Modifier = Modifier) {
    val (txt, col) = when {
        cancelled -> tx("Soppresso") to LateRed
        delay > 0 -> "+$delay'" to LateRed
        delay < 0 -> "$delay'" to OnTime
        departed -> tx("In orario") to OnTime
        else -> "" to Color.Gray
    }
    if (txt.isNotEmpty()) Text(com.binario.treni.data.ColorBlind.delaySymbol(delay, cancelled) + txt, color = col, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = modifier)
}

/** Pallino del tragitto: pieno e blu se già transitato. */
@Composable
fun StopDot(passed: Boolean, size: Int = 14) {
    Box(
        Modifier.size(size.dp).clip(CircleShape)
            .border(2.dp, if (passed) PassedBlue else Color(0xFFBDBDBD), CircleShape)
            .padding(3.dp).clip(CircleShape)
            .background(if (passed) PassedBlue else Color(0xFFBDBDBD)),
    )
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
}

@Composable
fun MessageBox(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Muted, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun ActionChip(icon: ImageVector, label: String, active: Boolean = false, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = if (active) Green else Muted)
        Text(label, fontSize = 11.sp, color = if (active) Green else Muted)
    }
}

/** Riga di menu con icona grigia, come nella scheda "Altro". */
@Composable
fun MenuRow(icon: ImageVector?, title: String, sub: String = "", trailing: @Composable () -> Unit = {}, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color(0xFF757575), modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(26.dp))
        } else Spacer(Modifier.width(36.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 13.sp)
        }
        trailing()
    }
}

@Composable
fun SimpleRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Green)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 13.sp)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = Muted)
        }
    }
    HorizontalDivider(color = Color(0x14000000))
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(6.dp)).border(1.dp, Color.White, RoundedCornerShape(6.dp)),
    ) {
        options.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).fillMaxHeight().background(if (i == selected) Color.White else Color.Transparent)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) { Text(s, color = if (i == selected) Green else Color.White, fontWeight = FontWeight.Medium) }
        }
    }
}

/** Schede in maiuscolo sotto la barra verde (TRAGITTO / INFO / MAPPA). */
@Composable
fun GreenTabs(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    TabRow(
        selectedTabIndex = selected, containerColor = Green, contentColor = Color.White,
        indicator = { pos ->
            if (selected < pos.size) with(TabRowDefaults) {
                SecondaryIndicator(Modifier.tabIndicatorOffset(pos[selected]), color = Color.White)
            }
        },
    ) {
        options.forEachIndexed { i, s ->
            Tab(i == selected, { onSelect(i) }, text = {
                Text(s.uppercase(), fontWeight = FontWeight.SemiBold, color = if (i == selected) Color.White else Color(0xCCFFFFFF))
            })
        }
    }
}

/** Dialog di ricerca stazione con autocompletamento ViaggiaTreno. */
@Composable
fun StationPickerDialog(title: String, onDismiss: () -> Unit, onPick: (Station) -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Station>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    val favs = remember { store.favStations() }
    val recents = remember {
        store.recentRoutes().flatMap { listOf(it.from, it.to) }.distinctBy { it.id }.filter { r -> favs.none { it.id == r.id } }.take(6)
    }
    val focus = remember { FocusRequester() }
    LaunchedEffect(q) {
        if (q.trim().length < 2) {
            results = emptyList(); return@LaunchedEffect
        }
        delay(250)
        loading = true
        results = try {
            withContext(Dispatchers.IO) { Api.searchStations(q) }
        } catch (e: Exception) {
            emptyList()
        }
        loading = false
    }
    LaunchedEffect(Unit) { if (store.openKeyboard) focus.requestFocus() }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true,
                    placeholder = { Text(tx("Nome della stazione")) },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                )
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                LazyColumn {
                    if (q.trim().length < 2) {
                        if (favs.isNotEmpty()) item { SectionHeader(tx("Stazioni preferite")) }
                        items(favs) { s -> PickRow(s, Icons.Filled.Star) { onPick(s) } }
                        if (recents.isNotEmpty()) item { SectionHeader(tx("Recenti")) }
                        items(recents) { s -> PickRow(s, Icons.Filled.History) { onPick(s) } }
                    } else {
                        items(results) { s -> PickRow(s, Icons.Filled.Place) { onPick(s) } }
                    }
                }
                if (q.trim().length >= 2 && !loading && results.isEmpty()) MessageBox(tx("Nessuna stazione trovata"))
            }
        }
    }
}

@Composable
private fun PickRow(s: Station, icon: ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(s.name)
    }
    HorizontalDivider(color = Color(0x14000000))
}

/** Scelta del promemoria: quanti minuti prima, partenza o arrivo. */
@Composable
fun ReminderDialog(onDismiss: () -> Unit, onConfirm: (minutes: Int, arrival: Boolean) -> Unit) {
    var minutes by remember { mutableIntStateOf(15) }
    var arrival by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Notifica programmata")) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(!arrival, { arrival = false }); Text(tx("Prima della partenza"))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(arrival, { arrival = true }); Text(tx("Prima dell'arrivo"))
                }
                Spacer(Modifier.height(8.dp))
                listOf(5, 10, 15, 30, 60).forEach { m ->
                    Row(Modifier.fillMaxWidth().clickable { minutes = m }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(minutes == m, { minutes = m })
                        Text(if (m == 60) tx("1 ora prima") else "$m minuti prima")
                    }
                }
            }
        },
        confirmButton = { TextButton({ onConfirm(minutes, arrival) }) { Text(tx("Imposta"), color = Green) } },
        dismissButton = { TextButton(onDismiss) { Text(tx("Annulla")) } },
    )
}

/** Campo numerico per la ricerca treno. */
@Composable
fun NumberField(value: String, onChange: (String) -> Unit, onSearch: () -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { v -> onChange(v.filter { it.isDigit() }.take(6)) },
        singleLine = true, label = { Text(tx("Numero del treno")) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        trailingIcon = { IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, tx("Cerca")) } },
        modifier = Modifier.fillMaxWidth(),
    )
}

// ---------------- Intent di sistema ----------------

fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(com.binario.treni.data.LinkLoc.url(url))))
    } catch (e: ActivityNotFoundException) {
        toast(ctx, tx("Nessun browser disponibile"))
    }
}

/**
 * Cerca [query] su Google Maps attorno al punto (app Google Maps se installata, altrimenti il browser).
 * Gratuito e senza chiavi: è un semplice collegamento, l'app non riceve dati da Google.
 */
fun googleMaps(ctx: Context, lat: Double, lon: Double, query: String) {
    val url = "https://www.google.com/maps/search/" + Uri.encode(query) + "/@$lat,$lon,16z"
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.apps.maps"))
    } catch (e: Exception) {
        openUrl(ctx, url)
    }
}

/** Riga di pulsanti "Cerca su Google Maps" per una o più ricerche (etichetta → testo da cercare). */
@Composable
fun GoogleMapsButtons(lat: Double, lon: Double, searches: List<Pair<String, String>>) {
    val ctx = LocalContext.current
    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
        searches.forEach { (label, q) ->
            TextButton({ googleMaps(ctx, lat, lon, q) }) {
                Icon(Icons.Filled.Map, null, Modifier.size(18.dp), tint = Green)
                Spacer(Modifier.width(4.dp))
                Text(label, color = Green)
            }
        }
    }
}

/**
 * "Trascina giù per aggiornare": tieni il dito sull'elenco e tiralo verso il basso.
 * Il contenuto deve poter scorrere (LazyColumn o Column con verticalScroll).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PullRefresh(refreshing: Boolean, onRefresh: () -> Unit, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    androidx.compose.material3.pulltorefresh.PullToRefreshBox(
        isRefreshing = refreshing, onRefresh = onRefresh, modifier = modifier.fillMaxSize(), content = content,
    )
}

/** Messaggio in un riquadro che si può tirare giù per aggiornare. */
@Composable
fun PullableMessage(text: String) {
    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState())) { MessageBox(text) }
}

fun shareText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "$text\n\n— via Binario")
    ctx.startActivity(Intent.createChooser(i, tx("Condividi")))
}

fun addToCalendar(ctx: Context, title: String, begin: Long, end: Long, location: String, description: String = "") {
    val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, if (end > begin) end else begin + 3600_000)
        .putExtra(CalendarContract.Events.TITLE, title)
        .putExtra(CalendarContract.Events.EVENT_LOCATION, location)
        .putExtra(CalendarContract.Events.DESCRIPTION, description)
    try {
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        toast(ctx, tx("Nessuna app calendario trovata"))
    }
}

/** Sito di acquisto in base alla categoria del treno. */
fun buyUrl(category: String): String {
    val c = category.uppercase()
    return when {
        c.contains("ITA") || c.contains("NTV") -> "https://www.italotreno.com"
        c.contains("TN") || c.contains("TRENORD") || c.startsWith("MXP") -> "https://www.trenord.it"
        else -> "https://www.lefrecce.it"
    }
}

fun buySource(category: String): String = when (buyUrl(category)) {
    "https://www.italotreno.com" -> "italotreno.it"
    "https://www.trenord.it" -> "trenord.it"
    else -> "trenitalia.com"
}


/**
 * Vero quando l'app è in primo piano. Gli aggiornamenti automatici (tabelloni, treni, notizie) si fermano quando
 * l'app è in background: meno batteria e meno dati, e al ritorno si aggiornano subito.
 */
@Composable
fun rememberForeground(): androidx.compose.runtime.State<Boolean> {
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val state = owner.lifecycle.currentStateAsState()
    return androidx.compose.runtime.remember(state) {
        androidx.compose.runtime.derivedStateOf { state.value.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED) }
    }
}

/** Aspetta che l'app torni in primo piano (subito se lo è già). */
suspend fun waitForeground(fg: androidx.compose.runtime.State<Boolean>) {
    if (fg.value) return
    androidx.compose.runtime.snapshotFlow { fg.value }.first { it }
}
