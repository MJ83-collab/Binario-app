package com.binario.treni.ui

import android.annotation.SuppressLint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.I18n
import com.binario.treni.data.Osm
import com.binario.treni.data.SavedPlace
import com.binario.treni.service.Speech
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun tr(a: String, b: String) = I18n.tr(a, b)

/** Punto verso cui farsi guidare. */
private data class Target(val name: String, val lat: Double, val lon: Double)

private fun distM(a: Location, lat: Double, lon: Double): Int {
    val r = FloatArray(2)
    Location.distanceBetween(a.latitude, a.longitude, lat, lon, r)
    return r[0].toInt()
}

private fun bearing(a: Location, lat: Double, lon: Double): Float {
    val r = FloatArray(2)
    Location.distanceBetween(a.latitude, a.longitude, lat, lon, r)
    return (r[1] + 360f) % 360f
}

/** Direzione a ore (12 = davanti a te), oppure punto cardinale se non si conosce la direzione del telefono. */
private fun direction(a: Location, lat: Double, lon: Double, heading: Float?): String {
    val b = bearing(a, lat, lon)
    if (heading == null) {
        val names = when {
            I18n.de -> listOf("Norden", "Nordosten", "Osten", "Südosten", "Süden", "Südwesten", "Westen", "Nordwesten")
            I18n.fr -> listOf("le nord", "le nord-est", "l'est", "le sud-est", "le sud", "le sud-ouest", "l'ouest", "le nord-ouest")
            I18n.zh -> listOf("北", "东北", "东", "东南", "南", "西南", "西", "西北")
            I18n.ja -> listOf("北", "北東", "東", "南東", "南", "南西", "西", "北西")
            I18n.es -> listOf("el norte", "el noreste", "el este", "el sureste", "el sur", "el suroeste", "el oeste", "el noroeste")
            I18n.en -> listOf("north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west")
            else -> listOf("nord", "nord-est", "est", "sud-est", "sud", "sud-ovest", "ovest", "nord-ovest")
        }
        return tr("verso ", "towards ") + names[(((b + 22.5f) % 360f) / 45f).toInt() % 8]
    }
    val rel = ((b - heading) + 360f) % 360f
    var h = Math.round(rel / 30f)
    if (h == 0) h = 12
    val words = when (h) {
        12 -> tr("davanti a te", "straight ahead"); 3 -> tr("a destra", "to your right"); 6 -> tr("dietro di te", "behind you"); 9 -> tr("a sinistra", "to your left")
        1, 2 -> tr("avanti a destra", "ahead on the right"); 10, 11 -> tr("avanti a sinistra", "ahead on the left")
        4, 5 -> tr("dietro a destra", "behind on the right"); else -> tr("dietro a sinistra", "behind on the left")
    }
    return tr("ore $h, $words", "$h o'clock, $words")
}

private fun meters(m: Int): String = if (m < 1000) "$m " + tr("metri", "metres") else String.format(java.util.Locale.ITALY, "%.1f km", m / 1000.0)

/**
 * "Esplora" (ispirato a Lazarillo, pensato per i treni): annuncia a voce dove sei (stazione, binari, ascensori, scale,
 * ingressi, biglietterie, WC, taxi) mentre cammini o sei in viaggio; cerca per categoria o per nome; ti guida
 * verso un punto con distanza e direzione "a ore"; salva luoghi con il GPS (es. il punto giusto del binario).
 */
@SuppressLint("MissingPermission")
@Composable
fun ExploreScreen(vm: MainViewModel, onBack: () -> Unit, onBoard: (com.binario.treni.data.Station) -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(hasLocation(ctx)) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> granted = r.values.any { it } }
    var loc by remember { mutableStateOf<Location?>(null) }
    var heading by remember { mutableStateOf<Float?>(null) }
    var pois by remember { mutableStateOf<List<Osm.Poi>>(emptyList()) }
    var poisAt by remember { mutableStateOf<Location?>(null) }
    var loadingPois by remember { mutableStateOf(false) }
    var exploring by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf<Target?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var lastSaid by remember { mutableStateOf("") }
    val announced = remember { HashSet<String>() }
    var lastSpeak by remember { mutableLongStateOf(0L) }
    var stationNow by remember { mutableStateOf<String?>(null) }
    var places by remember { mutableStateOf(vm.store.places()) }
    var naming by remember { mutableStateOf(false) }

    fun speak(text: String, force: Boolean = true) {
        lastSaid = text
        Speech.say(ctx, text, Speech.Sound.INFO, force = force)
        lastSpeak = System.currentTimeMillis()
    }

    // Elenco stazioni pronto in memoria (lettura una sola volta, fuori dal thread principale)
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { runCatching { Api.allStations(ctx) } } }
    LaunchedEffect(Unit) { if (!granted) perm.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)) }
    // Schermo sempre acceso mentre si esplora o si è guidati
    DisposableEffect(exploring, target) {
        view.keepScreenOn = exploring || target != null
        onDispose { view.keepScreenOn = false }
    }
    // Posizione continua (GPS e rete)
    DisposableEffect(granted) {
        val lm = ctx.getSystemService(LocationManager::class.java)
        val listener = object : LocationListener {
            override fun onLocationChanged(l: Location) {
                val cur = loc
                if (cur == null || l.accuracy <= cur.accuracy + 15 || l.time - cur.time > 10_000) loc = l
            }
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        if (granted && lm != null) {
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                try {
                    if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 2000L, 2f, listener, Looper.getMainLooper())
                    lm.getLastKnownLocation(p)?.let { if (loc == null) loc = it }
                } catch (_: Exception) {
                }
            }
        }
        onDispose { try { lm?.removeUpdates(listener) } catch (_: Exception) { } }
    }
    // Direzione del telefono (bussola)
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val rot = FloatArray(9); val ori = FloatArray(3)
        var lastSet = 0L
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val now = System.currentTimeMillis()
                if (now - lastSet < 400) return
                lastSet = now
                SensorManager.getRotationMatrixFromVector(rot, e.values)
                SensorManager.getOrientation(rot, ori)
                heading = ((Math.toDegrees(ori[0].toDouble()).toFloat()) + 360f) % 360f
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null) sm?.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm?.unregisterListener(l) }
    }
    // Punti utili attorno: ricaricati quando ti sposti di 150 metri
    LaunchedEffect(loc) {
        val l = loc ?: return@LaunchedEffect
        val last = poisAt
        if (loadingPois || (last != null && last.distanceTo(l) < 150f)) return@LaunchedEffect
        loadingPois = true
        val list = withContext(Dispatchers.IO) { runCatching { Osm.pois(l.latitude, l.longitude) }.getOrNull() }
        if (list != null) { pois = list; poisAt = l }
        loadingPois = false
    }
    // Annunci mentre esplori
    LaunchedEffect(loc, exploring) {
        val l = loc ?: return@LaunchedEffect
        if (!exploring) return@LaunchedEffect
        val now = System.currentTimeMillis()
        if (now - lastSpeak < 5000) return@LaunchedEffect
        val moving = l.hasSpeed() && l.speed > 6f
        val near = withContext(Dispatchers.IO) {
            runCatching {
                // Prima un calcolo veloce approssimato su tutte le stazioni, poi la distanza esatta solo per la più vicina
                val k = Math.cos(Math.toRadians(l.latitude))
                Api.allStations(ctx).minByOrNull { g -> val dx = (g.lon - l.longitude) * k; val dy = g.lat - l.latitude; dx * dx + dy * dy }
                    ?.let { it to FloatArray(1).also { r -> Location.distanceBetween(l.latitude, l.longitude, it.lat, it.lon, r) }[0] }
            }.getOrNull()
        }
        if (moving) {
            // In treno o in auto: la stazione più vicina, una volta per stazione
            if (near != null && near.second < 3000 && stationNow != near.first.station.name) {
                stationNow = near.first.station.name
                speak(tr("In viaggio, vicino alla stazione di ", "Travelling, near the station of ") + near.first.station.name + ", " + meters(near.second.toInt()) + ".")
            }
            return@LaunchedEffect
        }
        if (near != null && near.second < 250 && stationNow != near.first.station.name) {
            stationNow = near.first.station.name
            // Rete FERROVIENORD: avvisa degli ascensori e scale mobili fuori servizio (fonte ferrovienord.it)
            val out = if (com.binario.treni.data.FnNetwork.isFn(near.first.station.id)) withContext(Dispatchers.IO) {
                runCatching { com.binario.treni.data.FerrovieNord.outagesAt(near.first.station.name, com.binario.treni.data.FerrovieNord.outages()) }.getOrDefault(emptyList())
            } else emptyList()
            speak(tr("Sei alla stazione di ", "You are at ") + near.first.station.name + "." +
                (if (out.isNotEmpty()) " " + tr("Attenzione, fuori servizio: ", "Warning, out of service: ") + out.joinToString("; ") { it.item.ifBlank { it.platform } } + "." else ""))
            return@LaunchedEffect
        }
        // Rimetti in lista i punti da cui ti sei allontanato
        pois.filter { distM(l, it.lat, it.lon) > 60 }.forEach { announced.remove(it.id) }
        val close = pois.filter { it.kind != Osm.PoiKind.STATION && it.kind != Osm.PoiKind.CAFE && it.id !in announced }
            .map { it to distM(l, it.lat, it.lon) }.filter { it.second <= 25 }.sortedBy { it.second }.take(2)
        if (close.isNotEmpty()) {
            close.forEach { announced += it.first.id }
            speak(close.joinToString(". ") { (p, d) ->
                (p.kind.label.replaceFirstChar { it.uppercase() }) + (if (p.name.isNotBlank() && p.kind != Osm.PoiKind.PLATFORM) " " + p.name else if (p.kind == Osm.PoiKind.PLATFORM && p.name.isNotBlank()) ", " + p.name else "") +
                    ", " + meters(d) + ", " + direction(l, p.lat, p.lon, heading) + (if (p.detail.isNotBlank()) ", " + p.detail else "")
            } + ".")
        }
    }
    // Guida verso un punto: distanza e direzione ogni 12 secondi, arrivo sotto gli 8 metri
    LaunchedEffect(target) {
        val t = target ?: return@LaunchedEffect
        while (target == t) {
            val l = loc
            if (l != null) {
                val d = distM(l, t.lat, t.lon)
                if (d <= 8) {
                    speak(tr("Sei arrivato: ", "You have arrived: ") + t.name + ".")
                    com.binario.treni.service.Haptic.alert(ctx, com.binario.treni.service.Haptic.Kind.REMINDER)
                    target = null
                    break
                }
                speak(t.name + ", " + meters(d) + ", " + direction(l, t.lat, t.lon, heading) + ".")
            }
            delay(12_000L)
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tr("Esplora", "Explore"), onBack)
        GreenTabs(listOf(tr("Dove sono", "Where am I"), tr("Categorie", "Categories"), tr("Cerca", "Search"), tr("Preferiti", "Favourites")), tab) { tab = it }
        val l = loc
        // Guida in corso
        target?.let { t ->
            Column(Modifier.fillMaxWidth().background(Color(0xFF1565C0)).padding(14.dp).semantics { liveRegion = LiveRegionMode.Polite }) {
                Text(tr("Ti guido verso: ", "Guiding you to: ") + t.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (l != null) Text(meters(distM(l, t.lat, t.lon)) + " · " + direction(l, t.lat, t.lon, heading), color = Color.White, fontSize = 22.sp)
                Row {
                    TextButton({ openUrl(ctx, "google.navigation:q=${t.lat},${t.lon}&mode=w") }) { Text(tr("Navigazione a piedi", "Walking navigation"), color = Color.White) }
                    TextButton({ target = null; Speech.stop() }) { Text(tr("Ferma la guida", "Stop guiding"), color = Color.White) }
                }
            }
        }
        if (!granted) {
            MessageBox(tr("Serve il permesso di posizione per esplorare.", "Location permission is needed to explore."))
            Button({ perm.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)) },
                Modifier.align(Alignment.CenterHorizontally), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr("Concedi permesso", "Grant permission")) }
            return@Column
        }
        if (l == null) { MessageBox(tr("Cerco la tua posizione… Attiva il GPS.", "Finding your position… Turn on GPS.")); return@Column }

        fun goTo(name: String, lat: Double, lon: Double) {
            target = Target(name, lat, lon)
            speak(tr("Ti guido verso ", "Guiding you to ") + name + ". " + meters(distM(l, lat, lon)) + ", " + direction(l, lat, lon, heading) + ".")
        }

        when (tab) {
            0 -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                Button(
                    {
                        exploring = !exploring
                        announced.clear(); stationNow = null
                        speak(if (exploring) tr("Esplorazione attiva. Ti dirò stazioni, binari, ascensori, scale e servizi vicini.", "Exploring. I'll tell you about nearby stations, platforms, lifts, stairs and services.")
                        else tr("Esplorazione ferma.", "Exploring stopped."))
                    },
                    Modifier.fillMaxWidth().height(64.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (exploring) Color(0xFFD32F2F) else Green),
                ) { Text(if (exploring) tr("Ferma l'esplorazione", "Stop exploring") else tr("Avvia l'esplorazione a voce", "Start spoken exploration"), fontSize = 18.sp) }
                OutlinedButton(
                    {
                        val st = runCatching { Api.allStations(ctx) }.getOrNull()?.minByOrNull { distM(l, it.lat, it.lon) }
                        val parts = mutableListOf<String>()
                        st?.let { parts += tr("Stazione più vicina: ", "Nearest station: ") + it.station.name + ", " + meters(distM(l, it.lat, it.lon)) + ", " + direction(l, it.lat, it.lon, heading) }
                        pois.filter { it.kind != Osm.PoiKind.STATION }.map { it to distM(l, it.lat, it.lon) }.sortedBy { it.second }.take(3).forEach { (p, d) ->
                            parts += p.kind.label + (if (p.name.isNotBlank()) " " + p.name else "") + ", " + meters(d) + ", " + direction(l, p.lat, p.lon, heading)
                        }
                        if (l.hasSpeed() && l.speed > 6f) parts += tr("Ti stai muovendo a ", "You are moving at ") + (l.speed * 3.6f).toInt() + " km/h"
                        speak(parts.joinToString(". ").ifBlank { tr("Non trovo punti utili qui attorno.", "No useful places found nearby.") } + ".")
                    },
                    Modifier.fillMaxWidth().padding(top = 8.dp).height(56.dp),
                ) { Icon(Icons.Filled.RecordVoiceOver, null); Spacer(Modifier.width(8.dp)); Text(tr("Dove sono? Dimmelo", "Where am I? Tell me"), fontSize = 17.sp) }
                Text(tr("Ultimo annuncio", "Last announcement"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp).semantics { heading() })
                Text(lastSaid.ifBlank { "—" }, fontSize = 18.sp, modifier = Modifier.padding(top = 4.dp).semantics { liveRegion = LiveRegionMode.Polite })
                Text(tr("Precisione GPS: ", "GPS accuracy: ") + "±${l.accuracy.toInt()} m" + (if (heading == null) tr(" · bussola non disponibile: direzioni con i punti cardinali", " · no compass: directions by compass points") else ""),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                Text(tr("Tieni il telefono davanti a te: \"ore 12\" è davanti, \"ore 3\" a destra, \"ore 9\" a sinistra. In stazione il GPS può sbagliare di alcuni metri: chiedi aiuto al personale o alle Sale Blu (Altro → Assistenza disabili).",
                    "Hold the phone in front of you: \"12 o'clock\" is ahead, \"3\" right, \"9\" left. In stations GPS can be off by a few metres: ask staff or the Sale Blu for help (More → Disability assistance)."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            1 -> {
                var kind by remember { mutableStateOf(Osm.PoiKind.STATION) }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp)) {
                    listOf(Osm.PoiKind.STATION, Osm.PoiKind.PLATFORM, Osm.PoiKind.ELEVATOR, Osm.PoiKind.STEPS, Osm.PoiKind.ENTRANCE, Osm.PoiKind.TICKETS,
                        Osm.PoiKind.MACHINE, Osm.PoiKind.TOILETS, Osm.PoiKind.DAE, Osm.PoiKind.TAXI, Osm.PoiKind.BUS, Osm.PoiKind.INFO, Osm.PoiKind.CAFE).forEach { k ->
                        FilterChip(kind == k, { kind = k }, label = { Text(k.label.replaceFirstChar { it.uppercase() }) }, modifier = Modifier.padding(end = 6.dp))
                    }
                }
                val rows: List<Triple<String, Pair<Double, Double>, String>> = if (kind == Osm.PoiKind.STATION) {
                    remember(l.latitude.toInt(), l.longitude.toInt()) { runCatching { Api.allStations(ctx) }.getOrDefault(emptyList()) }
                        .sortedBy { distM(l, it.lat, it.lon) }.take(10).map { Triple(it.station.name, it.lat to it.lon, it.station.id) }
                } else pois.filter { it.kind == kind }.take(20).map { Triple(it.name.ifBlank { it.kind.label.replaceFirstChar { c -> c.uppercase() } }, it.lat to it.lon, it.detail) }
                LazyColumn {
                    if (loadingPois && rows.isEmpty()) item { LoadingBox() }
                    if (!loadingPois && rows.isEmpty()) item { MessageBox(tr("Nessun punto di questo tipo mappato qui attorno (300 m).", "None of these mapped nearby (300 m).")) }
                    items(rows) { (name, ll, extra) ->
                        val d = distM(l, ll.first, ll.second)
                        WhiteCard {
                            Column(Modifier.padding(12.dp)) {
                                Text(name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text(meters(d) + " · " + direction(l, ll.first, ll.second, heading) + (if (kind != Osm.PoiKind.STATION && extra.isNotBlank()) " · $extra" else ""), fontSize = 15.sp)
                                Row {
                                    TextButton({ goTo(name, ll.first, ll.second) }) { Text(tr("Guidami", "Guide me"), color = Green) }
                                    if (kind == Osm.PoiKind.STATION) TextButton({ onBoard(com.binario.treni.data.Station(name, extra)) }) { Text(tr("Tabellone", "Board"), color = Green) }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                var q by remember { mutableStateOf("") }
                var results by remember { mutableStateOf<List<Osm.Poi>?>(null) }
                var busy by remember { mutableStateOf(false) }
                fun search(text: String) {
                    if (text.isBlank()) return
                    q = text; busy = true
                    scope.launch {
                        results = withContext(Dispatchers.IO) { runCatching { Osm.geocode(text, l.latitude to l.longitude) }.getOrDefault(emptyList()) }
                        busy = false
                        val r = results.orEmpty()
                        speak(if (r.isEmpty()) tr("Nessun risultato per ", "No results for ") + text else tr("Trovati ", "Found ") + r.size + tr(" risultati. Il primo: ", " results. First: ") + r[0].name + ", " + meters(r[0].distance))
                    }
                }
                val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
                    res.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { search(it) }
                }
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, label = { Text(tr("Luogo, indirizzo, stazione…", "Place, address, station…")) },
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { search(q) }))
                        FilledIconButton({
                            try {
                                voice.launch(android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                    .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, I18n.speechTag))
                            } catch (_: Exception) {
                            }
                        }, Modifier.padding(start = 6.dp).size(52.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green)) {
                            Icon(Icons.Filled.Mic, tr("Cerca a voce", "Search by voice"), tint = Color.White)
                        }
                    }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                    LazyColumn {
                        items(results.orEmpty()) { p ->
                            WhiteCard {
                                Column(Modifier.padding(12.dp)) {
                                    Text(p.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Text(meters(distM(l, p.lat, p.lon)) + " · " + direction(l, p.lat, p.lon, heading), fontSize = 14.sp)
                                    Row {
                                        TextButton({ goTo(p.name, p.lat, p.lon) }) { Text(tr("Guidami", "Guide me"), color = Green) }
                                        TextButton({ openUrl(ctx, "google.navigation:q=${p.lat},${p.lon}&mode=w") }) { Text(tr("Navigazione a piedi", "Walking navigation"), color = Green) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else -> LazyColumn {
                item {
                    Button({ naming = true }, Modifier.fillMaxWidth().padding(12.dp).height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                        Icon(Icons.Filled.AddLocationAlt, null); Spacer(Modifier.width(8.dp)); Text(tr("Salva questo punto", "Save this spot"), fontSize = 17.sp)
                    }
                    Text(tr("Es. \"Binario 3, testa del treno\", \"Ascensore lato bar\", \"Uscita taxi\": poi \"Guidami\" ti riporta lì. Stazioni e treni preferiti sono nelle schede Stazioni e Treni.",
                        "E.g. \"Platform 3, front of the train\", \"Lift by the café\", \"Taxi exit\": then \"Guide me\" brings you back. Favourite stations and trains are in the Stations and Trains tabs."),
                        color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
                }
                if (places.isEmpty()) item { MessageBox(tr("Nessun luogo salvato.", "No saved places.")) }
                items(places) { p ->
                    WhiteCard {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(meters(distM(l, p.lat, p.lon)) + " · " + direction(l, p.lat, p.lon, heading) + (if (p.station.isNotBlank()) " · " + p.station else ""), fontSize = 14.sp)
                            Row {
                                TextButton({ goTo(p.name, p.lat, p.lon) }) { Text(tr("Guidami", "Guide me"), color = Green) }
                                TextButton({ places = places - p; vm.store.savePlaces(places) }) { Text(tr("Elimina", "Delete"), color = LateRed) }
                            }
                        }
                    }
                }
            }
        }
        if (naming) {
            var name by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { naming = false },
                title = { Text(tr("Salva questo punto", "Save this spot")) },
                text = {
                    Column {
                        OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(tr("Nome", "Name")) })
                        Text(tr("Posizione attuale, precisione ±", "Current position, accuracy ±") + "${l.accuracy.toInt()} m", color = Muted, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    Button({
                        val st = runCatching { Api.allStations(ctx) }.getOrNull()?.minByOrNull { distM(l, it.lat, it.lon) }
                            ?.takeIf { distM(l, it.lat, it.lon) < 400 }?.station?.name.orEmpty()
                        val p = SavedPlace(name.ifBlank { tr("Punto salvato", "Saved spot") + " " + (places.size + 1) }, l.latitude, l.longitude, st)
                        places = places + p; vm.store.savePlaces(places); naming = false
                        speak(tr("Salvato: ", "Saved: ") + p.name)
                    }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr("Salva", "Save")) }
                },
                dismissButton = { TextButton({ naming = false }) { Text(tr("Annulla", "Cancel")) } },
            )
        }
    }
}
