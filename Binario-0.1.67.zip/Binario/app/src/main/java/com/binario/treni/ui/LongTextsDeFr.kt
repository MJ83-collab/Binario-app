package com.binario.treni.ui

/** Testi lunghi in tedesco e francese. Le note legali restano in inglese con un avviso: fa fede il testo originale. */

const val WIDGETS_TEXT_DE = """Halte eine leere Stelle auf dem Startbildschirm gedrückt → Widgets → Binario und wähle dann, was angezeigt werden soll. Tippe auf den Widget-Titel, um ihn zu ändern.

• Strecke / Linie: die nächsten Züge einer Strecke oder Lieblingslinie (z. B. S5), mit Verspätung und Gleis.
• Zug: der Fahrtverlauf eines Zuges Halt für Halt.
• Bahnhof: Abfahrten von einem Bahnhof deiner Wahl.
• Favoriten: der Status aller deiner Lieblingszüge auf einen Blick.

Tippe auf eine Zeile, um den Zug oder die Abfahrtstafel zu öffnen."""

const val WIDGETS_TEXT_FR = """Appuyez longuement sur un endroit vide de l'écran d'accueil → Widgets → Binario, puis choisissez ce qu'il faut afficher. Touchez le titre du widget pour le modifier.

• Itinéraire / Ligne : les prochains trains d'un itinéraire ou d'une ligne favorite (par ex. S5), avec retard et voie.
• Train : la progression d'un train arrêt par arrêt.
• Gare : les départs d'une gare de votre choix.
• Favoris : l'état de tous vos trains favoris en un coup d'œil.

Touchez une ligne pour ouvrir le train ou le tableau des départs."""

const val HELP_TEXT_DE = """Wie suche ich einen Fahrplan?
Wähle im Reiter Suche Start und Ziel, Datum und Uhrzeit und tippe dann auf Suchen. Tippe auf einen Zugnamen (z. B. "TI FR 9627"), um Verspätungen, Halte und Gleise zu sehen.

Wie sehe ich die Abfahrtstafel einer Haltestelle?
Tippe in der Zugansicht auf eine Haltestelle und wähle "Abfahrten und Ankünfte von hier".

Wie funktioniert der Wecker?
Tippe in der Zugansicht auf die Haltestelle zum Aussteigen und wähle "Weck mich vor dieser Haltestelle". Der Alarm klingelt, wenn der Zug die vorherige Haltestelle verlässt (oder 4 Minuten vor der erwarteten Ankunft). Schalte in den Einstellungen "Hinweise für gehörlose oder schwerhörige Menschen" für starke Vibration und Blitz ein.

Wie füge ich eine Linie hinzu?
Reiter Züge → Lieblingslinien → Hinzufügen, z. B. S5 mit den Endstationen Varese und Treviglio.

Wie richte ich ein Widget ein?
Füge es vom Startbildschirm aus hinzu und wähle, was angezeigt werden soll. Zum Ändern tippe auf den Widget-Titel.

Kann ich Fragen stellen?
Ja: Öffne den Zugassistenten (Sprechblasen-Symbol in der Suche) und frage z. B. "Verspätung Zug 2070" oder "Züge von Varese nach Milano".

Wo sehe ich Züge auf der Karte?
Öffne „Zugkarte“ im Menü (☰): Sie startet nur mit Italien, danach kannst du weitere Länder hinzufügen und die App merkt sich deine Wahl. Tippe auf einen Punkt für Nummer, Unternehmen, Verspätung und nächsten Halt.

Wo finde ich Bedingungen und Tarife eines Unternehmens?
Menü (☰) › Beförderungsbedingungen › Bedingungen und Tarife nach Unternehmen: Unternehmen öffnen und den offiziellen Link antippen. Quelle und Prüfdatum werden angezeigt.

Wie sende ich Feedback?
Menü (☰) › Feedback senden."""

const val HELP_TEXT_FR = """Comment rechercher un horaire ?
Dans l'onglet Recherche, choisissez l'origine et la destination, la date et l'heure, puis touchez Rechercher. Touchez le nom d'un train (par ex. "TI FR 9627") pour voir les retards, les arrêts et les voies.

Comment voir le tableau des départs d'un arrêt ?
Dans la vue du train, touchez un arrêt et choisissez "Départs et arrivées d'ici".

Comment fonctionne l'alarme de réveil ?
Dans la vue du train, touchez l'arrêt où vous descendez et choisissez "Me réveiller avant cet arrêt". L'alarme sonne quand le train quitte l'arrêt précédent (ou 4 minutes avant l'arrivée prévue). Activez "Alertes pour les personnes sourdes ou malentendantes" dans les Paramètres pour une forte vibration et le flash.

Comment ajouter une ligne ?
Onglet Trains → Lignes favorites → Ajouter, par ex. S5 avec les terminus Varese et Treviglio.

Comment configurer un widget ?
Ajoutez-le depuis l'écran d'accueil et choisissez ce qu'il faut afficher. Pour le modifier, touchez le titre du widget.

Puis-je poser des questions ?
Oui : ouvrez l'assistant train (icône de bulle dans Recherche) et demandez par exemple "retard train 2070" ou "trains de Varese à Milano".

Où voir les trains sur la carte ?
Ouvrez « Carte des trains » dans le menu (☰) : elle démarre avec l'Italie seule, puis vous pouvez ajouter d'autres pays et l'appli retient votre choix. Touchez un point pour le numéro, l'entreprise, le retard et le prochain arrêt.

Où trouver les conditions et tarifs d'une entreprise ?
Menu (☰) › Conditions de transport › Conditions et tarifs par entreprise : ouvrez l'entreprise et touchez le lien officiel. La source et la date de vérification sont indiquées.

Comment envoyer un retour ?
Menu (☰) › Envoyer un retour."""

const val PRIVACY_TEXT_DE = """Datenschutzerklärung (DSGVO) · Stand November 2026

Verantwortlicher: Marco Jannino, unabhängiger Entwickler von Binario. Kontakt: „Feedback und Fehler melden“ in der App.

Kurz gesagt
• Kein Konto, keine Werbung, keine Statistik- oder Tracking-Tools. Binario hat keinen eigenen Server und erhält deine Daten nicht.
• Favoriten, letzte Suchen, übliche Züge, Erinnerungen, Einstellungen und das Grün-Protokoll bleiben nur auf deinem Handy. Sie werden beim Deinstallieren oder in den Android-Einstellungen gelöscht.

Externe Dienste
Um Fahrpläne, Verspätungen und Karten zu zeigen, kontaktiert die App öffentliche Dienste direkt: ViaggiaTreno (RFI/Trenitalia), LeFrecce, Italo, Trenord, FerrovieNord, TILO, SBB, DB, Transitous, TrovaTreno, die Streik-Beobachtungsstelle des Ministeriums, OpenStreetMap (Karten, Overpass, Nominatim, OSRM) und ähnliche. Wie jede Website erhalten sie deine IP-Adresse und die Anfragedaten (z. B. Bahnhof oder Zugnummer) und verarbeiten sie nach ihren eigenen Richtlinien. Binario gibt sie an niemanden sonst weiter.

Standort
Nur wenn du die Berechtigung erteilst und nur in den Bildschirmen, die ihn nutzen (Bahnhöfe in der Nähe, Verkaufsstellen, Dienste). Um Orte in der Nähe zu finden, werden die Koordinaten an OpenStreetMap-Server (Overpass) gesendet, die auch deine IP erhalten. Binario speichert sie nicht und nutzt den Standort nicht im Hintergrund.

Feedback
Wenn du „Feedback und Fehler melden“ sendest, gehen Name, E-Mail und Nachricht (und, wenn du es wählst, App-Version und Handymodell) an ein Google-Formular des Entwicklers und dienen nur zur Antwort; Google verarbeitet die Daten im Auftrag des Entwicklers. Die Formularadresse wird aus einer öffentlichen Datei auf GitHub gelesen. Ohne Netz bleibt die Nachricht auf dem Handy und wird so bald wie möglich gesendet. Sie wird gespeichert, solange sie für die Bearbeitung nötig ist; du kannst die Löschung verlangen.

Updates
Die App prüft auf GitHub, ob es eine neue Version gibt (beim Öffnen und etwa stündlich im Hintergrund, bei Neuigkeiten mit Benachrichtigung), und lädt bei Zustimmung die APK von dort herunter (GitHub erhält deine IP). Zum Installieren fragt Android nach der Berechtigung „Unbekannte Apps installieren“.

Sprache
Sprachhinweise nutzen die Sprachausgabe des Handys, ohne Daten zu senden. Sprachfragen laufen über die Spracherkennung des Handys (meist Google): Binario fragt nicht nach dem Mikrofon.

Berechtigungen
• Benachrichtigungen: dauerhafte Zugmeldung, Erinnerungen und Streikhinweise (auf dem Handy geplant, ohne Push-Server).
• Vordergrunddienst, Wake-Lock und Akku-Optimierung: damit der verfolgte Zug aktuell bleibt.
• Start beim Hochfahren, Alarme und Erinnerungen: geplante Meldungen wiederherstellen und pünktlich zustellen.
• Standort: Bahnhöfe und Dienste in der Nähe, Karte.
• Unbekannte Apps installieren: nur um Binario zu aktualisieren.
• Vibration.

Rechtsgrundlage und Rechte
Die einzige Verarbeitung durch den Entwickler (Feedback) beruht auf deiner Einwilligung, nämlich dem Absenden. Du hast Rechte auf Auskunft, Berichtigung, Löschung, Einschränkung, Widerspruch und Übertragbarkeit (Art. 15–22 DSGVO): schreibe aus der App. Du kannst dich bei der italienischen Datenschutzbehörde beschweren (garanteprivacy.it). Für Daten bei externen Diensten wende dich an diese.

Diese App steht in keiner Verbindung zu Trenitalia, RFI, Italo oder Trenord."""

const val PRIVACY_TEXT_FR = """Politique de confidentialité (RGPD) · mise à jour novembre 2026

Responsable du traitement : Marco Jannino, développeur indépendant de Binario. Contact : « Retour et signaler un bug » dans l'appli.

En bref
• Pas de compte, pas de publicité, aucun outil de statistiques ou de suivi. Binario n'a pas de serveur propre et ne reçoit pas vos données.
• Favoris, recherches récentes, trains habituels, rappels, réglages et journal « vert » restent uniquement sur votre téléphone. Ils sont supprimés en désinstallant l'appli ou depuis les réglages Android.

Services externes
Pour afficher horaires, retards et cartes, l'appli contacte directement des services publics : ViaggiaTreno (RFI/Trenitalia), LeFrecce, Italo, Trenord, FerrovieNord, TILO, CFF/SBB, DB, Transitous, TrovaTreno, l'observatoire des grèves du ministère, OpenStreetMap (cartes, Overpass, Nominatim, OSRM) et similaires. Comme tout site web, ils reçoivent votre adresse IP et les données de la requête (p. ex. gare ou numéro de train) et les traitent selon leurs propres politiques. Binario ne les transmet à personne d'autre.

Localisation
Seulement si vous accordez l'autorisation et seulement dans les écrans qui l'utilisent (gares proches, points de vente, services). Pour trouver les lieux proches, les coordonnées sont envoyées aux serveurs d'OpenStreetMap (Overpass), qui reçoivent aussi votre IP. Binario ne les enregistre pas et n'utilise pas la localisation en arrière-plan.

Retours
Si vous envoyez « Retour et signaler un bug », nom, e-mail et message (et, si vous le choisissez, version de l'appli et modèle du téléphone) arrivent dans un formulaire Google du développeur et servent uniquement à vous répondre ; Google traite ces données pour le compte du développeur. L'adresse du formulaire est lue dans un fichier public sur GitHub. Sans réseau, le message reste sur le téléphone et part dès que possible. Il est conservé le temps de traiter votre demande : vous pouvez en demander la suppression.

Mises à jour
L'appli vérifie sur GitHub s'il existe une nouvelle version (à l'ouverture et environ toutes les heures en arrière-plan, avec une notification s'il y en a une) et, si vous acceptez, y télécharge l'APK (GitHub reçoit votre IP). Pour l'installer, Android demande l'autorisation « installer des applis inconnues ».

Voix
Les alertes vocales utilisent la synthèse vocale du téléphone, sans envoi de données. Les questions vocales passent par la reconnaissance vocale du téléphone (en général Google) : Binario ne demande pas le micro.

Autorisations
• Notifications : notification permanente du train, rappels et alertes de grève (programmées sur le téléphone, sans serveur de notifications).
• Service au premier plan, verrou de veille et optimisation de la batterie : garder le train suivi à jour.
• Démarrage au lancement, alarmes et rappels : restaurer et délivrer à l'heure les notifications programmées.
• Localisation : gares et services proches, carte.
• Installer des applis inconnues : uniquement pour mettre à jour Binario.
• Vibration.

Base légale et droits
Le seul traitement effectué par le développeur (les retours) repose sur votre consentement, c'est-à-dire l'envoi du message. Vous avez un droit d'accès, de rectification, d'effacement, de limitation, d'opposition et de portabilité (art. 15-22 RGPD) : écrivez depuis l'appli. Vous pouvez déposer une plainte auprès de l'autorité italienne de protection des données (garanteprivacy.it). Pour les données traitées par les services externes, adressez-vous à eux.

Cette appli n'est pas affiliée à Trenitalia, RFI, Italo ou Trenord."""

const val LEGAL_NOTE_DE = "Die rechtlichen Hinweise sind noch nicht auf Deutsch verfügbar; unten steht der englische Originaltext, maßgeblich ist der Originaltext.\n\n"
const val LEGAL_NOTE_FR = "Les mentions légales ne sont pas encore disponibles en français ; voici le texte original en anglais, qui fait foi.\n\n"

const val CHANGELOG_TEXT_DE = """0.1.67-alpha
• Der Link „Offizielle Linienseite“ von Trenord wurde korrigiert (zeigte „Access Denied“); die TILO-Linienseiten und Trenord-Streckenlinks wurden geprüft. Änderungsprotokoll und Korrekturbericht beginnen neu.

0.1.66-alpha
• Schlägt das Senden des Feedbacks fehl, erscheint die Schaltfläche „Per E-Mail senden“ (Adresse aus der Konfigurationsdatei, nicht in der App hinterlegt).
"""

const val CHANGELOG_TEXT_FR = """0.1.67-alpha
• Lien « page officielle de la ligne » de Trenord corrigé (affichait « Access Denied ») ; pages des lignes TILO et liens des axes Trenord vérifiés. Journal des nouveautés et rapport des corrections repartis de zéro.

0.1.66-alpha
• Si l’envoi du retour échoue, un bouton « Envoyer par e-mail » apparaît (adresse lue dans le fichier de configuration, non écrite dans l’application).
"""
