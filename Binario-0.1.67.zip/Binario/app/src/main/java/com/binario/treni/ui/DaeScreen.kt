package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.outlined.Accessibility
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Train
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.FerrovieNord
import com.binario.treni.data.FnNetwork
import com.binario.treni.data.I18n
import com.binario.treni.data.Osm
import com.binario.treni.data.Station
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun tr(a: String, b: String) = I18n.tr(a, b)

private const val AREU_MAP = "https://www.areu.lombardia.it/web/home/mappa-dae-lombardia"
private const val TICINO_CUORE = "https://www.ticinocuore.ch/defibrillatori"

/** Un defibrillatore da mostrare, con l'azienda o la fonte. */
private data class DaePoint(
    val name: String, val where: String, val lat: Double, val lon: Double, val distance: Int,
    val fn: Boolean, val publicAccess: Boolean, val always: Boolean, val outdoor: Boolean,
    val hours: String, val operator: String, val source: String, val osmRef: String = "",
    /** Entro 300 m da una stazione ferroviaria (qualsiasi azienda). */
    val atStation: Boolean = false,
    /** "dae", oppure "hospital"/"pharmacy" per i luoghi dove chiedere aiuto (non sono DAE certi). */
    val kind: String = "dae",
)

/**
 * Defibrillatori (DAE) vicino a te o a una stazione, in stile Trenord: mappa con il cuore rosso, elenco con dove si trova,
 * se è accessibile a tutti e quando, e chi lo gestisce. Fonti: OpenStreetMap (volontari) per tutti i DAE mappati;
 * FERROVIENORD per le sue stazioni (un DAE in ogni stazione, di solito sulla facciata esterna); mappe ufficiali AREU
 * Lombardia e Ticino Cuore. In alto il tasto per chiamare il 112 (144 in Svizzera).
 */
@Composable
fun DaeScreen(vm: MainViewModel, station: Station?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var center by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var list by remember { mutableStateOf<List<DaePoint>?>(null) }
    var status by remember { mutableStateOf(tr("Ricerca della posizione…", "Finding your location…")) }
    var failed by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    // Prima l'elenco (dal più vicino): toccando un DAE si apre subito Google Maps a piedi
    var showList by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var focus by remember { mutableStateOf<Osm.Poi?>(null) }
    var searching by remember { mutableStateOf(false) }
    val filters = remember { mutableStateListOf<String>() }

    LaunchedEffect(station?.id) {
        if (station != null) {
            center = withContext(Dispatchers.IO) { Api.stationCoord(vm.store, station.id) }
        } else if (hasLocation(ctx)) {
            currentLocation(ctx)?.let { center = it.latitude to it.longitude }
                ?: run { status = tr("Posizione non disponibile: cerca una città o una stazione.", "Location not available: search a town or station.") }
        } else status = tr("Cerca una città o una stazione qui sopra.", "Search a town or station above.")
    }
    val ref = focus?.let { it.lat to it.lon } ?: center
    // Numero d'emergenza del paese in cui si trova il telefono (non del luogo cercato)
    val number = remember { emergencyNumber(ctx) }
    LaunchedEffect(ref, retry) {
        val c = ref ?: return@LaunchedEffect
        list = null; failed = false
        status = tr("Cerco i defibrillatori…", "Looking for defibrillators…")
        // Fonti in parallelo per ogni raggio: OpenStreetMap + registro ufficiale dell'Emilia-Romagna (se sei lì).
        // Il raggio si allarga finché trova abbastanza DAE: 1,5 km, poi 5 km, poi 15 km (oltre i confini della stazione)
        var osm: List<com.binario.treni.data.Defibrillator>? = null
        var er: List<com.binario.treni.data.Defibrillator> = emptyList()
        for (r in listOf(1500, 5000, 15000)) {
            status = tr("Cerco i defibrillatori entro ", "Looking for defibrillators within ") + (if (r < 1000) "$r m" else "${r / 1000.0} km".replace(".0 ", " ")) + "…"
            val got = withContext(Dispatchers.IO) { runCatching { Osm.defibrillators(c.first, c.second, r) }.getOrNull() }
            er = withContext(Dispatchers.IO) { runCatching { com.binario.treni.data.DaeSources.emiliaRomagna(c.first, c.second, r) }.getOrDefault(er) }
            if (got == null) { if (osm == null) failed = true; if (er.isEmpty()) break } else { osm = got; failed = false }
            if (osm.orEmpty().size + er.size >= 8) break
        }
        FnNetwork.ensure(ctx)
        // Stazioni FERROVIENORD vicine: ognuna ha un DAE (ferrovienord.it)
        val fnAll = FnNetwork.stations.map { g ->
            val r = FloatArray(1); android.location.Location.distanceBetween(c.first, c.second, g.lat, g.lon, r)
            g to r[0]
        }.sortedBy { it.second }
        // Tutte quelle entro 5 km e comunque le 5 più vicine (entro 40 km)
        val fn = fnAll.filterIndexed { i, (_, d) -> d <= 5000 || (i < 5 && d <= 40_000) }.map { (g, d) ->
            DaePoint(
                tr("Stazione ", "Station ") + g.station.name, tr("DAE della stazione: di solito sulla facciata esterna, in una teca segnalata", "Station AED: usually on the outside wall, in a marked case"),
                g.lat, g.lon, d.toInt(), fn = true, publicAccess = true, always = true, outdoor = true, hours = "",
                operator = "FERROVIENORD", source = tr("ferrovienord.it · DAE in tutte le stazioni FERROVIENORD", "ferrovienord.it · AEDs in all FERROVIENORD stations"),
                atStation = true,
            )
        }
        fun toPoint(d: com.binario.treni.data.Defibrillator, src: String) = DaePoint(
            d.name.ifBlank { tr("Defibrillatore", "Defibrillator") }, d.where, d.lat, d.lon, d.distance, fn = false,
            publicAccess = d.access.isBlank() || d.access == "yes" || d.access == "public", always = d.hours == "24/7",
            outdoor = d.indoor == "no", hours = d.hours, operator = d.operator, source = src, osmRef = d.osmRef,
        )
        val fromEr = er.map { toPoint(it, tr("Registro regionale DAE Emilia-Romagna (dati aperti)", "Emilia-Romagna regional AED register (open data)")) }
        val fromOsm = osm.orEmpty().map { toPoint(it, tr("OpenStreetMap (volontari): verifica sul posto", "OpenStreetMap (volunteers): check on site")) }
            .filter { o -> fromEr.none { e -> Math.abs(o.lat - e.lat) < 0.0004 && Math.abs(o.lon - e.lon) < 0.0005 } }
        val official = fromEr + fromOsm
        // Un DAE a meno di 60 m da una stazione FERROVIENORD è probabilmente lo stesso: tengo quello mappato (più preciso)
        val fnOnly = fn.filter { s -> official.none { o -> Math.abs(o.lat - s.lat) < 0.0006 && Math.abs(o.lon - s.lon) < 0.0008 } }
        // "Stazioni": DAE entro 300 m da una stazione ferroviaria di qualsiasi azienda
        val stations = withContext(Dispatchers.IO) { runCatching { com.binario.treni.data.Api.allStations(ctx) }.getOrDefault(emptyList()) } + FnNetwork.stations
        val k = Math.cos(Math.toRadians(c.first))
        fun nearAStation(la: Double, lo: Double) = stations.any { g -> val dx = (g.lon - lo) * k * 111_320; val dy = (g.lat - la) * 111_320; dx * dx + dy * dy < 300.0 * 300.0 }
        val daes = (official.map { it.copy(atStation = nearAStation(it.lat, it.lon)) } + fnOnly).sortedBy { it.distance }
        // Dove chiedere aiuto vicino: pronto soccorso/ospedali e farmacie (molte hanno un DAE, non è garantito)
        val help = withContext(Dispatchers.IO) { runCatching { Osm.helpPlaces(c.first, c.second, 3000) }.getOrDefault(emptyList()) }
        val hospitals = help.filter { it.id.startsWith("H") }.take(3)
        val pharmacies = help.filter { it.id.startsWith("P") }.take(4)
        val helpPoints = (hospitals + pharmacies).map { p ->
            val h = p.id.startsWith("H")
            DaePoint(p.name, p.detail, p.lat, p.lon, p.distance, fn = false, publicAccess = true, always = h && p.detail.contains("pronto"),
                outdoor = false, hours = "", operator = "", source = "OpenStreetMap", kind = if (h) "hospital" else "pharmacy")
        }
        list = daes + helpPoints
        if (failed && list.isNullOrEmpty()) status = tr("I server OpenStreetMap non rispondono: usa la mappa ufficiale qui sotto o riprova.", "OpenStreetMap servers are not responding: use the official map below or retry.")
    }
    LaunchedEffect(searching) {
        if (!searching) return@LaunchedEffect
        focus = withContext(Dispatchers.IO) { runCatching { Osm.geocode(query.trim(), center).firstOrNull() }.getOrNull() }
        searching = false
    }
    val all = list.orEmpty()
    fun ok(d: DaePoint) = (d.kind == "dae" || filters.isEmpty()) && ("fn" !in filters || d.atStation) && ("public" !in filters || d.publicAccess) && ("always" !in filters || d.always) && ("out" !in filters || d.outdoor)
    val shown = all.filter { ok(it) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tr("Defibrillatori", "Defibrillators") + (station?.let { " · ${it.name}" } ?: ""), onBack)
        // Emergenza prima di tutto
        Button(
            { dial(ctx, number) },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F), contentColor = Color.White),
            shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(52.dp),
        ) {
            Icon(Icons.Filled.Call, null)
            Spacer(Modifier.width(8.dp))
            Text(tr("Emergenza: chiama il ", "Emergency: call ") + number,
                fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
        Text(tr("Chi risponde ti guida nel massaggio cardiaco e ti dice dov'è il DAE più vicino. Il DAE si usa anche sui bambini e dà istruzioni a voce.",
            "The operator guides you through CPR and tells you where the nearest AED is. AEDs can be used on children too and give voice instructions."),
            fontSize = 13.sp, color = Muted, modifier = Modifier.padding(horizontal = 16.dp))
        TrenordSearchField(query, { query = it; if (it.isBlank()) focus = null }, { if (query.isNotBlank()) searching = true else focus = null })
        TrenordChoiceGrid(
            listOf(
                TrenordChoice("fn", tr("Stazioni", "Stations"), Icons.Outlined.Train),
                TrenordChoice("public", tr("Accesso pubblico", "Public access"), Icons.Outlined.Accessibility),
                TrenordChoice("always", tr("Sempre disponibili", "Always available"), Icons.Outlined.Schedule),
                TrenordChoice("out", tr("All'aperto", "Outdoors"), Icons.Outlined.WbSunny),
            ),
            isSelected = { it in filters },
            counts = if (list != null) all.filter { it.kind == "dae" }.let { d -> mapOf("fn" to d.count { it.atStation }, "public" to d.count { it.publicAccess }, "always" to d.count { it.always }, "out" to d.count { it.outdoor }) } else emptyMap(),
        ) { k -> if (k in filters) filters.remove(k) else filters.add(k) }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val l = list
            when {
                l == null -> Column {
                    MessageBox(status)
                    if (failed) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        OutlinedButton({ retry++ }) { Text(tr("Riprova", "Retry"), color = Green) }
                    }
                }
                showList || !vm.store.mapsEnabled -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                    val daeList = shown.filter { it.kind == "dae" }
                    val helpList = shown.filter { it.kind != "dae" }
                    item {
                        // Elenco ufficiale completo: in Lombardia è solo sulla mappa AREU (non pubblicato come dati aperti)
                        val r = ref
                        OfficialSourcesCard(r)
                        Text(tr("Defibrillatori vicini", "Nearby defibrillators") + " · ${daeList.size}", fontWeight = FontWeight.Bold, fontSize = 17.sp,
                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp))
                        if (daeList.isEmpty()) MessageBox(tr("Nessun defibrillatore negli elenchi aperti qui. Chiama il 112: la centrale conosce tutti i DAE registrati e ti guida.",
                            "No defibrillator in the open lists here. Call 112: the dispatch centre knows all registered AEDs and guides you."))
                    }
                    items(daeList) { d -> DaeCard(d) }
                    if (helpList.isNotEmpty()) {
                        item {
                            SectionHeader(tr("Dove chiedere aiuto qui vicino", "Where to get help nearby"))
                            Text(tr("Pronto soccorso e farmacie: molte farmacie hanno un DAE, ma non è garantito.",
                                "Emergency departments and pharmacies: many pharmacies have an AED, but it isn't guaranteed."),
                                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
                        }
                        items(helpList) { d -> DaeCard(d) }
                    }
                    item {
                        SectionHeader(tr("Mappe ufficiali e fonti", "Official maps and sources"))
                        SourceLink(tr("AREU Lombardia · mappa DAE (ufficiale)", "AREU Lombardy · AED map (official)"), AREU_MAP, Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                        SourceLink(tr("Ticino Cuore · defibrillatori in Ticino", "Ticino Cuore · AEDs in Ticino"), TICINO_CUORE, Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                        SourceLink(tr("FERROVIENORD · defibrillatori in stazione", "FERROVIENORD · station AEDs"), FerrovieNord.DEFIBRILLATORS, Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                        SourceLink("MapComplete · defibrillatori (OpenStreetMap)", "https://mapcomplete.org/aed.html", Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                        Text(tr("FERROVIENORD: 125 DAE installati tra il 2022 e il 2023 in tutte le sue stazioni, dove possibile sulla facciata esterna per essere raggiungibili anche di notte, in teche allarmate e collegati alle centrali del 112/118. Gli altri DAE vengono da OpenStreetMap (volontari): verifica sul posto. Trenitalia/RFI, Italo e FFS non pubblicano un elenco dei DAE nelle stazioni: chiedi al personale o chiama il 112 (144 in Svizzera).",
                            "FERROVIENORD: 125 AEDs installed in 2022–2023 in all its stations, where possible on the outside wall so they can be reached at night, in alarmed cases linked to 112/118 dispatch. Other AEDs come from OpenStreetMap (volunteers): check on site. Trenitalia/RFI, Italo and SBB don't publish a list of station AEDs: ask staff or call 112 (144 in Switzerland)."),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
                    }
                }
                else -> OsmMap(
                    shown.map { d ->
                        MapPoint(d.lat, d.lon, d.name, listOfNotNull(d.where.takeIf { it.isNotBlank() }, if (d.distance < 1000) "${d.distance} m" else String.format("%.1f km", d.distance / 1000.0))
                            .joinToString(" · ") + "\n" + tr("Tocca di nuovo per le indicazioni", "Tap again for directions"), glyph = if (d.kind == "dae") "dae" else "help") {
                            walkTo(ctx, d.lat, d.lon)
                        }
                    },
                    drawLine = false, modifier = Modifier.fillMaxSize(), me = if (station == null && focus == null) center else null,
                    target = focus?.let { MapPoint(it.lat, it.lon, it.name, tr("Luogo cercato", "Searched place")) }
                        ?: if (station != null) center?.let { MapPoint(it.first, it.second, station.name, tr("Stazione", "Station")) } else null,
                    selected = -1, googleQuery = "defibrillatore", fitNearest = 6,
                )
            }
            if (vm.store.mapsEnabled && list != null) ShowListButton(showList, Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)) { showList = !showList }
        }
    }
}

@Composable
private fun DaeCard(d: DaePoint) {
    val ctx = LocalContext.current
    // Tocco sulla scheda: Google Maps con il percorso a piedi fino al defibrillatore
    WhiteCard(onClick = { walkTo(ctx, d.lat, d.lon) }) {
        Column(Modifier.padding(start = 12.dp, end = 14.dp, top = 12.dp, bottom = 6.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                TrenordName(d.name, Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 8.dp)) {
                    Text(if (d.distance < 1000) "${d.distance} m" else String.format("%.1f km", d.distance / 1000.0), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${(d.distance / 80).coerceAtLeast(1)} " + tr("min a piedi", "min walk"), color = Muted, fontSize = 11.sp)
                }
            }
            Column(Modifier.padding(start = 24.dp, top = 4.dp)) {
                Text(when {
                    d.kind == "hospital" -> tr("Ospedale · chiedi aiuto qui", "Hospital · ask for help here")
                    d.kind == "pharmacy" -> tr("Farmacia · chiedi se hanno un DAE", "Pharmacy · ask if they have an AED")
                    d.fn -> "FERROVIENORD"
                    else -> d.operator.ifBlank { tr("Gestore non indicato", "Operator not stated") }
                },
                    color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                if (d.where.isNotBlank()) Text(d.where, fontSize = 14.sp)
                val tags = listOfNotNull(
                    if (d.kind != "dae") null else if (d.always) tr("Disponibile 24 ore su 24", "Available 24/7") else d.hours.takeIf { it.isNotBlank() }?.let { "🕒 $it" },
                    if (d.kind == "dae" && !d.publicAccess) tr("Accesso limitato", "Restricted access") else null,
                    if (d.kind == "dae" && d.outdoor) tr("All'aperto", "Outdoors") else null,
                    if (d.kind == "dae" && d.atStation && !d.fn) tr("In stazione o a pochi passi", "At or next to a station") else null,
                )
                tags.forEach { Text(it, fontSize = 14.sp) }
                Text(tr("Fonte: ", "Source: ") + d.source, color = Muted, fontSize = 11.sp)
                Row {
                    TrenordLink(tr("Ottieni indicazioni", "Get directions")) { walkTo(ctx, d.lat, d.lon) }
                    if (d.osmRef.isNotBlank()) {
                        Spacer(Modifier.width(16.dp))
                        TrenordLink(tr("Vedi su MapComplete", "View on MapComplete")) {
                            openUrl(ctx, "https://mapcomplete.org/aed.html?z=19&lat=${d.lat}&lon=${d.lon}#${d.osmRef}")
                        }
                    }
                }
            }
        }
    }
}


/** Numero di emergenza del paese in cui si trova il telefono (rete mobile): 144 in Svizzera e Liechtenstein, altrimenti 112. */
/** Numero di emergenza del paese scelto in Impostazioni (automatico: dalla rete mobile). 144 in Svizzera, 112 in Italia e Germania. */
fun emergencyNumber(ctx: android.content.Context): String = com.binario.treni.data.Emergency.current(ctx).number

/** Scheda rossa in Home: DAE più vicino e chiamata d'emergenza con un tocco. */
@Composable
fun DaeHomeCard(onOpen: () -> Unit) {
    Surface(
        onClick = onOpen, shape = RoundedCornerShape(12.dp), color = Color(0xFFD32F2F),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.MonitorHeart, null, tint = Color.White, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tr("Defibrillatore più vicino", "Nearest defibrillator"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(tr("Elenco e mappa dei DAE · tocca per vederli", "List and map of AEDs · tap to see them"), color = Color(0xEEFFFFFF), fontSize = 13.sp)
            }
        }
    }
}


/** Apre Google Maps (app se installata) con il percorso a piedi fino al punto. */
fun walkTo(ctx: android.content.Context, lat: Double, lon: Double) {
    val nav = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("google.navigation:q=$lat,$lon&mode=w"))
        .setPackage("com.google.android.apps.maps")
    try {
        ctx.startActivity(nav)
    } catch (e: Exception) {
        openUrl(ctx, "https://www.google.com/maps/dir/?api=1&destination=$lat,$lon&travelmode=walking")
    }
}


/** In cima all'elenco: le mappe ufficiali complete (AREU in Lombardia, Ticino Cuore in Ticino) e la ricerca su Google Maps. */
@Composable
private fun OfficialSourcesCard(ref: Pair<Double, Double>?) {
    val ctx = LocalContext.current
    val country = remember { com.binario.treni.data.Emergency.current(ctx) }
    val lombardy = country == com.binario.treni.data.Emergency.Country.IT && (ref?.let { com.binario.treni.data.DaeSources.inLombardy(it.first, it.second) } ?: true)
    // Ticino: mappa Ticino Cuore; resto della Svizzera: defikarte.ch; Germania: OpenAEDMap
    val ticino = ref?.let { it.first in 45.8..46.65 && it.second in 8.38..9.17 } ?: false
    WhiteCard {
        Column(Modifier.padding(12.dp)) {
            Text(tr("Elenco ufficiale completo", "Complete official list"), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (lombardy) Text(
                tr("⏳ In attesa dei dati ufficiali AREU: Binario ha chiesto di poter usare il registro ufficiale dei defibrillatori della Lombardia. Finché non arriva l'autorizzazione l'elenco qui sotto può essere incompleto: per vederli tutti apri la mappa ufficiale AREU.",
                    "⏳ Waiting for official AREU data: Binario has asked to use Lombardy's official defibrillator register. Until permission arrives the list below may be incomplete: open the official AREU map to see them all."),
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFB34700), modifier = Modifier.padding(vertical = 4.dp),
            )
            Text(tr("Qui sotto vedi i DAE degli elenchi aperti (OpenStreetMap, FERROVIENORD, registro Emilia-Romagna).",
                "Below are the AEDs from open lists (OpenStreetMap, FERROVIENORD, Emilia-Romagna register)."),
                fontSize = 13.sp, color = Muted)
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                when {
                    lombardy -> TrenordLink(tr("Mappa ufficiale AREU", "Official AREU map")) { openUrl(ctx, com.binario.treni.data.DaeSources.AREU_MAP) }
                    country == com.binario.treni.data.Emergency.Country.CH && ticino ->
                        TrenordLink(tr("Mappa Ticino Cuore", "Ticino Cuore map")) { openUrl(ctx, com.binario.treni.data.DaeSources.TICINO_MAP) }
                    country == com.binario.treni.data.Emergency.Country.CH -> TrenordLink("defikarte.ch") { openUrl(ctx, country.aedMapUrl) }
                    country == com.binario.treni.data.Emergency.Country.DE -> TrenordLink("OpenAEDMap") { openUrl(ctx, country.aedMapUrl) }
                    else -> TrenordLink(tr("Mappa Ticino Cuore", "Ticino Cuore map")) { openUrl(ctx, com.binario.treni.data.DaeSources.TICINO_MAP) }
                }
                Spacer(Modifier.width(16.dp))
                TrenordLink(tr("Cerca su Google Maps", "Search Google Maps")) {
                    val c = ref
                    if (c != null) openGoogleMapsAt(ctx, c.first, c.second, "defibrillatore DAE")
                    else openUrl(ctx, "https://www.google.com/maps/search/defibrillatore")
                }
            }
        }
    }
}
