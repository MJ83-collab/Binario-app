package com.binario.treni.data

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Bus sostitutivi dei treni vicino a una stazione, con l'azienda e la fonte di ogni dato:
 * - Orari e punto di fermata del bus: Trenord dagli Open Data della Regione Lombardia (feed GTFS ufficiale, [TrenordGtfs]);
 *   le altre aziende (Trenitalia, FFS…), e Trenord se il feed non si legge, tramite Transitous (api.transitous.org). Il bus parte spesso da una fermata vicina, non dal binario:
 *   ne diamo nome e posizione.
 * - Bus in partenza nel tabellone: ViaggiaTreno (RFI), che elenca i bus sostitutivi con categoria "BUS".
 * - Pagine ufficiali: mappa bus sostitutivi Trenord, infomobilità Trenitalia, TILO / FFS.
 */
object ReplacementBus {
    private const val BASE = "https://api.transitous.org/api/v1/"
    const val TRENORD_MAP = "https://www.trenord.it/linee-e-orari/il-nostro-servizio/bus-sostitutivi/"
    const val TRENITALIA_INFO = "https://www.trenitalia.com"
    const val RFI_INFO = "https://www.rfi.it/it/news-e-media/infomobilita.html"
    const val TILO_INFO = "https://www.tilo.ch/"
    const val SBB_INFO = "https://www.sbb.ch/it"

    /** Un bus sostitutivo in partenza. */
    data class Bus(
        val operator: String,
        val line: String,
        val headsign: String,
        val time: Long,
        val delay: Int,
        val stopName: String,
        val lat: Double,
        val lon: Double,
        /** Da dove arriva il dato: "Transitous · orario ufficiale Trenord (GTFS)" o "ViaggiaTreno (RFI)". */
        val source: String,
        val realTime: Boolean = false,
        val bay: String = "",
    )

    private val utc = TimeZone.getTimeZone("UTC")

    private fun parseTime(s: String): Long = try {
        if (s.isBlank()) 0L else SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = utc }.parse(s)?.time ?: 0L
    } catch (e: Exception) {
        0L
    }

    private fun iso(t: Long) = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = utc }.format(Date(t))

    private fun get(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("User-Agent", "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)")
            setRequestProperty("Accept-Language", when (I18n.lang) { "it", "de", "fr", "es", "ja", "zh" -> I18n.lang; else -> "en" })
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun JSONObject.str(k: String): String = if (!has(k) || isNull(k)) "" else optString(k)

    /** Le aziende ferroviarie (i bus di linea urbani ed extraurbani non sono "sostitutivi"). */
    private fun railOperator(feedOrTrip: String, agency: String, route: String): String? {
        val a = agency.lowercase()
        val r = route.lowercase()
        return when {
            feedOrTrip.startsWith("it-Lombardia-Trenord") || a.contains("trenord") -> "Trenord"
            feedOrTrip.startsWith("it-trenitalia", true) || a.contains("trenitalia") -> "Trenitalia"
            a.contains("tilo") -> "TILO"
            a.contains("ferrovienord") || a.contains("ferrovie nord") -> "FerrovieNord"
            a.contains("sbb") || a.contains("ffs") || a.contains("cff") -> if (r.contains("ersatz") || r.startsWith("ev") || r.contains("sostitut")) "FFS" else null
            r.contains("sostitutiv") || r.contains("bus sost") -> agency.ifBlank { "?" }
            else -> null
        }
    }

    /**
     * Bus sostitutivi delle aziende ferroviarie che partono entro [radius] metri dalla stazione nelle prossime ore
     * (orari ufficiali GTFS via Transitous). [stopId] è il codice ViaggiaTreno/Trenord della stazione, se noto.
     */
    fun fromGtfs(lat: Double, lon: Double, stationId: String?, radius: Int = 600, time: Long = System.currentTimeMillis()): List<Bus> {
        // Trenord: prima gli Open Data della Regione Lombardia (feed GTFS ufficiale); se non si leggono, Transitous
        val lombardia: List<Bus>? = try {
            TrenordGtfs.buses(lat, lon, radius, time).map { d ->
                Bus(
                    operator = "Trenord", line = d.line.ifBlank { I18n.tr("Bus sostitutivo", "Replacement bus") }, headsign = d.headsign,
                    time = d.time, delay = 0, stopName = d.stopName, lat = d.lat, lon = d.lon,
                    source = I18n.tr("Open Data Regione Lombardia · orario ufficiale Trenord (GTFS)", "Lombardy Region open data · official Trenord timetable (GTFS)"),
                )
            }
        } catch (e: Exception) {
            null
        }
        val transitous: List<Bus> = try {
            fromTransitous(lat, lon, stationId, radius, time)
        } catch (e: Exception) {
            if (lombardia == null) throw e else emptyList()
        }
        val all = if (lombardia != null) lombardia + transitous.filter { it.operator != "Trenord" } else transitous
        return all.distinctBy { "${it.time}|${it.headsign}|${it.line}" }.sortedBy { it.time }
    }

    private fun fromTransitous(lat: Double, lon: Double, stationId: String?, radius: Int, time: Long): List<Bus> {
        val stop = stationId?.takeIf { it.startsWith("S") }?.let { "&stopId=" + URLEncoder.encode("it-Lombardia-Trenord_$it", "UTF-8") }.orEmpty()
        val o = JSONObject(get(BASE + "stoptimes?n=60&mode=BUS&radius=$radius&exactRadius=true&center=$lat,$lon" + stop +
            "&time=" + URLEncoder.encode(iso(time), "UTF-8") + "&window=21600"))
        val a = o.optJSONArray("stopTimes") ?: return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val s = a.getJSONObject(i)
            if (s.str("mode") != "BUS") return@mapNotNull null
            val p = s.optJSONObject("place") ?: return@mapNotNull null
            val route = listOf(s.str("routeShortName"), s.str("routeLongName")).filter { it.isNotBlank() }.joinToString(" · ")
            val op = railOperator(p.str("stopId").ifBlank { s.str("tripId") }, s.str("agencyName"), route) ?: return@mapNotNull null
            val sched = parseTime(p.str("scheduledDeparture")).takeIf { it > 0 } ?: return@mapNotNull null
            val real = parseTime(p.str("departure")).takeIf { it > 0 } ?: sched
            val rt = s.optBoolean("realTime")
            Bus(
                operator = op, line = route.ifBlank { I18n.tr("Bus sostitutivo", "Replacement bus") },
                headsign = s.str("headsign").ifBlank { s.optJSONObject("tripTo")?.str("name").orEmpty() },
                time = sched, delay = if (rt) ((real - sched) / 60_000L).toInt() else 0,
                stopName = p.str("name"), lat = p.optDouble("lat"), lon = p.optDouble("lon"),
                source = I18n.tr("Transitous · orario ufficiale $op (GTFS)", "Transitous · official $op timetable (GTFS)"),
                realTime = rt, bay = p.str("track"),
            )
        }.distinctBy { "${it.time}|${it.headsign}|${it.line}" }.sortedBy { it.time }
    }

    /** Bus sostitutivi nel tabellone ViaggiaTreno della stazione (categoria "BUS"), per le prossime ore. */
    fun fromBoard(st: Station): List<Bus> =
        Api.boardAhead(st, departures = true, hours = 6).filter { val c = it.category.uppercase(); c.contains("BUS") || c == "EV" }.map { b ->
            Bus(
                operator = b.operator.ifBlank { "Trenitalia / Trenord" }, line = (b.title).trim(), headsign = b.otherEnd,
                time = b.time, delay = b.delay, stopName = "", lat = Double.NaN, lon = Double.NaN,
                source = if (SwissLive.isSwiss(st.id)) I18n.tr("Orario FFS (transport.opendata.ch)", "SBB timetable (transport.opendata.ch)")
                else I18n.tr("ViaggiaTreno (RFI) · tabellone della stazione", "ViaggiaTreno (RFI) · station board"),
                realTime = b.delay != 0, bay = b.platformText,
            )
        }

    /** Pagine ufficiali da consultare per ogni azienda (nome, indirizzo). */
    fun officialPages(): List<Pair<String, String>> = listOf(
        I18n.tr("Trenord · mappa bus sostitutivi", "Trenord · replacement bus map") to TRENORD_MAP,
        I18n.tr("RFI · infomobilità (lavori e bus sostitutivi su rete RFI)", "RFI · travel updates (works and replacement buses)") to RFI_INFO,
        "Trenitalia" to TRENITALIA_INFO,
        "TILO" to TILO_INFO,
        "FFS" to SBB_INFO,
    )
}
