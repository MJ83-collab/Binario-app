package com.binario.treni.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.FnNetwork
import com.binario.treni.data.Solution
import com.binario.treni.data.Stats
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * «Quando partire»: tra le soluzioni trovate indica quali hanno i treni più puntuali, dalle statistiche del mese più recente
 * (TrovaTreno.it, arrivo entro 5 minuti). Una soluzione vale quanto il suo treno meno puntuale. Si basa sul numero del treno:
 * i treni della rete FerrovieNord sono esclusi (TrovaTreno non li ha e lo stesso numero può essere un altro treno).
 * Compare solo se almeno due soluzioni hanno dati sufficienti (almeno 8 corse osservate per ogni treno).
 */
@Composable
fun WhenToLeaveCard(list: List<Solution>) {
    val ctx = LocalContext.current
    val key = list.joinToString(",") { it.dep.toString() }
    var rows by remember(key) { mutableStateOf<List<Triple<Solution, Double, Double>>?>(null) }
    LaunchedEffect(key) {
        rows = withContext(Dispatchers.IO) {
            try {
                val month = Stats.availableMonths(ctx).firstOrNull() ?: return@withContext emptyList()
                val ms = Stats.load(ctx, month)
                list.mapNotNull { s ->
                    val trainLegs = s.legs.filter { l ->
                        val c = l.category.uppercase()
                        c != "BUS" && c != "METRO" && c != "MM" && Api.trainDigits(l.number).length >= 2
                    }
                    if (trainLegs.isEmpty()) return@mapNotNull null
                    val found = trainLegs.map { l ->
                        // Stazioni FerrovieNord: nessun dato affidabile
                        if (FnNetwork.search(l.from).any { it.name.equals(l.from, true) } || FnNetwork.search(l.to).any { it.name.equals(l.to, true) }) return@mapNotNull null
                        ms.train(Api.trainDigits(l.number)).maxByOrNull { it.observed }?.takeIf { it.observed >= 8 } ?: return@mapNotNull null
                    }
                    Triple(s, found.minOf { it.percent }, found.maxOf { it.avgDelay })
                }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
    val r = rows ?: return
    if (r.size < 2) return
    val best = r.maxOf { it.second }
    val shown = r.sortedByDescending { it.second }.take(4)
    WhiteCard {
        CardTitle(tx("Quale orario è più puntuale"))
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            shown.forEach { (s, p, d) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Text(
                        Fmt.time(s.dep) + " → " + Fmt.time(s.arr), fontWeight = if (p == best) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 15.sp, modifier = Modifier.weight(1f),
                    )
                    Text(
                        String.format(Locale.ITALY, "%.0f%%", p) + " " + tx("in orario") + " · " + String.format(Locale.ITALY, "%.1f", d) + " min",
                        color = punctColor(p), fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            Text(
                tx("Conta il treno meno puntuale di ogni soluzione. Statistiche del mese più recente, non una previsione: scioperi e lavori possono cambiare tutto.") +
                    " " + Stats.SOURCE,
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}
