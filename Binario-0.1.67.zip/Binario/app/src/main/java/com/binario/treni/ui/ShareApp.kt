package com.binario.treni.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Updater
import com.binario.treni.data.tx

/** Link che scarica sempre l'ultima versione pubblicata (copia con nome fisso nella release). */
const val LATEST_APK_URL = "https://github.com/${Updater.REPO}/releases/latest/download/Binario.apk"

fun shareAppText(): String =
    tx("Ti consiglio Binario, l'app gratuita per i treni in Italia e Svizzera: orari, ritardi in tempo reale, binari, scioperi, Trenord e FerrovieNord, avvisi sul tuo treno. Senza pubblicità.") +
        "\n\n📱 " + tx("Solo per smartphone e tablet Android: non funziona su iPhone e iPad.") +
        "\n\n" + tx("Scarica l'ultima versione per Android:") + "\n" + LATEST_APK_URL +
        "\n\n" + tx("Dopo il download apri il file e consenti l'installazione: l'app poi si aggiorna da sola.")

/** Condivide il messaggio con WhatsApp, Telegram o qualsiasi altra app (se quella scelta non c'è, apre la scelta di Android). */
fun shareApp(ctx: Context, pkg: String? = null) {
    val send = Intent(Intent.ACTION_SEND).setType("text/plain")
        .putExtra(Intent.EXTRA_SUBJECT, "Binario")
        .putExtra(Intent.EXTRA_TEXT, shareAppText())
    if (pkg != null) {
        try {
            ctx.startActivity(Intent(send).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (_: ActivityNotFoundException) {
            toast(ctx, tx("App non installata: scegli un'altra app"))
        }
    }
    ctx.startActivity(Intent.createChooser(send, tx("Condividi Binario")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** Invia il file APK dell'app installata (WhatsApp, Telegram, Bluetooth…). Chi lo riceve deve comunque aprirlo e consentire l'installazione. */
fun shareApk(ctx: Context) {
    try {
        val src = java.io.File(ctx.applicationInfo.sourceDir)
        val dir = java.io.File(ctx.cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = java.io.File(dir, "Binario-$APP_VERSION.apk")
        src.copyTo(out, overwrite = true)
        val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", out)
        val send = Intent(Intent.ACTION_SEND).setType("application/vnd.android.package-archive")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_TEXT, tx("Binario, l'app gratuita per i treni in Italia e Svizzera. Apri il file e consenti l'installazione.") + "\n📱 " + tx("Solo per smartphone e tablet Android: non funziona su iPhone e iPad."))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, tx("Condividi Binario")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        toast(ctx, tx("Impossibile preparare il file dell'app"))
    }
}

/** Finestra "Condividi Binario": WhatsApp, Telegram o altre app. */
@Composable
fun ShareAppDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Condividi Binario")) },
        text = {
            Column {
                Text(tx("Invia ai tuoi contatti il link per scaricare l'ultima versione dell'app."), fontSize = 14.sp)
                Text("📱 " + tx("Solo per smartphone e tablet Android: non funziona su iPhone e iPad."), fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                MenuRow(Icons.Filled.Chat, "WhatsApp") { onDismiss(); shareApp(ctx, "com.whatsapp") }
                MenuRow(Icons.Filled.Send, "Telegram") { onDismiss(); shareApp(ctx, "org.telegram.messenger") }
                MenuRow(Icons.Filled.Share, tx("Altre app (SMS, email…)")) { onDismiss(); shareApp(ctx) }
                Spacer(Modifier.height(12.dp))
                Text(tx("Oppure invia direttamente il file dell'app (versione installata):"), fontSize = 14.sp)
                MenuRow(Icons.Filled.Send, tx("File dell'app (APK)")) { onDismiss(); shareApk(ctx) }
                Text(tx("Chi lo riceve deve aprirlo e consentire l'installazione. WhatsApp può rifiutare i file APK: in quel caso usa il link."),
                    fontSize = 12.sp, color = Muted, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text(tx("Chiudi")) } },
    )
}
