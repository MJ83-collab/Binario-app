package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n
import com.binario.treni.data.TrainsMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val C_OK = 0xFF43A047.toInt()
private const val C_Y = 0xFFE6B422.toInt()
private const val C_O = 0xFFF57C00.toInt()
private const val C_R = 0xFFE53935.toInt()
private const val C_ND = 0xFF9AA0AE.toInt()

/** Barra impilata: ogni fascia ha larghezza proporzionale al numero di treni. */
@Composable
private fun StackBar(parts: List<Pair<Int, Int>>) {
    val shown = parts.filter { it.first > 0 }
    Row(Modifier.fillMaxWidth().height(20.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x22888888))) {
        shown.forEach { (n, c) -> Box(Modifier.weight(n.toFloat()).fillMaxHeight().background(Color(c))) }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, color = Muted, fontSize = 11.sp, maxLines = 2)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/**
 * Ritardi adesso in Italia, Svizzera e Germania, dal campione dei grandi nodi (lo stesso della mappa dei treni):
 * fasce di ritardo per paese, ritardo medio, quota in orario e nodi con più ritardo.
 */
@Composable
fun DelayCompareCard() {
    var dots by remember { mutableStateOf<List<TrainsMap.Dot>?>(null) }
    LaunchedEffect(Unit) { dots = withContext(Dispatchers.IO) { runCatching { TrainsMap.load() }.getOrDefault(emptyList()) } }
    WhiteCard {
        CardTitle(I18n.tr("Ritardi adesso: Italia, Svizzera, Germania", "Delays right now: Italy, Switzerland, Germany"))
        val d = dots
        if (d == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(16.dp), color = Green)
            return@WhiteCard
        }
        if (d.size < 10) {
            Text(I18n.tr("Dati insufficienti al momento", "Not enough data right now"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            return@WhiteCard
        }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Text(I18n.tr("Treni per fascia di ritardo", "Trains by delay band"), fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            listOf("IT" to I18n.tr("Italia", "Italy"), "CH" to I18n.tr("Svizzera", "Switzerland"), "DE" to I18n.tr("Germania", "Germany")).forEach { (code, name) ->
                val c = d.filter { it.country == code }
                if (c.isEmpty()) return@forEach
                val known = c.filter { it.known }
                val avg = if (known.isEmpty()) null else known.sumOf { it.delay.coerceAtLeast(0) }.toDouble() / known.size
                val onTime = if (known.isEmpty()) null else known.count { it.delay <= 5 } * 100 / known.size
                Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                StackBar(
                    listOf(
                        known.count { it.delay <= 0 } to C_OK, known.count { it.delay in 1..5 } to C_Y,
                        known.count { it.delay in 6..14 } to C_O, known.count { it.delay >= 15 } to C_R, (c.size - known.size) to C_ND,
                    ),
                )
                Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp)) {
                    Metric(I18n.tr("Ritardo medio", "Average delay"), if (avg == null) "–" else "%.1f min".format(java.util.Locale.ITALY, avg), Modifier.weight(1f))
                    Metric(I18n.tr("In orario (fino a 5 min)", "On time (up to 5 min)"), if (onTime == null) "–" else "$onTime%", Modifier.weight(1f))
                    Metric(I18n.tr("Treni con ritardo rilevato", "Trains with a delay reading"), "${known.size}/${c.size}", Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(C_OK to ("In orario" to "On time"), C_Y to ("1–5 min di ritardo" to "1–5 min late"), C_O to ("6–14 min di ritardo" to "6–14 min late"),
                    C_R to ("15+ min di ritardo" to "15+ min late"), C_ND to ("Ritardo n.d." to "Delay n.a.")).forEach { (col, l) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(col)))
                        Spacer(Modifier.width(3.dp))
                        Text(I18n.tr(l.first, l.second), fontSize = 9.sp, color = Muted, maxLines = 1)
                    }
                }
            }

            // Nodi con il ritardo medio più alto (almeno 3 treni con ritardo rilevato)
            val hubs = d.filter { it.known }.groupBy { it.country + "|" + it.hub }
                .filter { it.value.size >= 3 }
                .map { (_, v) -> Triple(v.first().country, v.first().hub, v.sumOf { it.delay.coerceAtLeast(0) }.toDouble() / v.size) }
                .sortedByDescending { it.third }.take(8)
            if (hubs.isNotEmpty()) {
                Text(I18n.tr("Nodi con il ritardo medio più alto", "Hubs with the highest average delay"), fontWeight = FontWeight.Medium, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                val max = hubs.maxOf { it.third }.coerceAtLeast(1.0)
                hubs.forEach { (country, hub, avg) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                        Text("$country · $hub", fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(0.46f))
                        Box(Modifier.weight(0.42f).height(12.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x22888888))) {
                            Box(Modifier.fillMaxWidth((avg / max).toFloat().coerceIn(0.03f, 1f)).fillMaxHeight()
                                .background(Color(if (avg <= 1) C_OK else if (avg <= 5) C_Y else if (avg <= 14) C_O else C_R)))
                        }
                        Text("%.1f".format(java.util.Locale.ITALY, avg) + " min", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(0.2f).padding(start = 6.dp), maxLines = 1)
                    }
                }
            }
            Text(
                I18n.tr(
                    "Campione dei treni in partenza dai grandi nodi nella prossima ora, non tutta la rete. Per i treni italiani il ritardo è noto solo dopo la partenza dall'origine (fonte ViaggiaTreno): per questo si contano i treni con ritardo rilevato e il confronto con Svizzera e Germania, che danno anche il ritardo previsto, è solo indicativo. Per le statistiche mensili e il confronto tra aziende vedi più sotto.",
                    "Sample of trains departing from the big hubs in the next hour, not the whole network. For Italian trains the delay is known only after departure from the origin (ViaggiaTreno): so only trains with a delay reading are counted, and the comparison with Switzerland and Germany, which also give the predicted delay, is only indicative. For monthly statistics and the comparison between companies see below.",
                ),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp, bottom = 6.dp),
            )
        }
    }
}
