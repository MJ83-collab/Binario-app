package com.binario.treni.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Stile dell'app scelto dall'utente: tradizionale oppure vintage (tabellone a palette Solari, scuro, ambra, a spaziatura fissa). */
object AppStyle {
    var vintage by mutableStateOf(false)
}
