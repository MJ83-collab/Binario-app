package com.binario.treni.data

import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Controllo delle fonti di dati dell'app. Ogni controllo scarica poco e verifica che la risposta abbia ancora il
 * formato atteso: se un sito cambia, il problema si vede qui (e nel controllo giornaliero su GitHub) prima che
 * gli utenti trovino funzioni vuote. Niente Android qui dentro: lo usano anche i test automatici.
 */
object Health {
    enum class Area(val itLabel: String) {
        TRAINS("Treni e tabelloni"), JOURNEYS("Soluzioni di viaggio"), NEWS("Notizie e scioperi"),
        MAPS("Mappe e servizi in stazione"), SELLERS("Rivendite"), STATS("Puntualità"),
    }

    /**
     * [alternatives]: altri server che fanno lo stesso servizio (la fonte è "ok" se almeno uno risponde, come fa l'app).
     * [ua]: alcuni siti (ViaggiaTreno) rifiutano i programmi che non si presentano come browser: usiamo lo stesso nome dell'app.
     */
    data class Check(
        val id: String, val name: String, val area: Area, val url: String,
        val alternatives: List<String> = emptyList(), val ua: String = UA, val test: (String) -> Boolean,
    )

    data class Result(val check: Check, val ok: Boolean, val millis: Long, val detail: String)

    private const val APP_UA = "Mozilla/5.0 (Android) Binario/1.0"
    private const val UA = "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)"

    val checks: List<Check> = listOf(
        Check("vt", "ViaggiaTreno (treni in tempo reale)", Area.TRAINS,
            "http://www.viaggiatreno.it/infomobilita/resteasy/viaggiatreno/autocompletaStazione/MILANO%20CENTRALE", ua = APP_UA) { it.contains("|S01700") },
        Check("lefrecce", "LeFrecce (orari e soluzioni Trenitalia)", Area.JOURNEYS,
            "https://www.lefrecce.it/Channels.Website.BFF.WEB/website/locations/search?name=milano&limit=3") { it.contains("Milano", true) },
        Check("ch", "Orario svizzero (transport.opendata.ch)", Area.TRAINS,
            "https://transport.opendata.ch/v1/locations?type=station&query=Lugano") { it.contains("8505300") },
        Check("transitous", "Transitous (EAV, ARST, Trentino Trasporti, Cotral)", Area.TRAINS,
            "https://api.transitous.org/api/v1/geocode?type=STOP&language=it&text=Napoli%20Porta%20Nolana") { it.contains("it-Campania-EAV") },
        Check("lombardia_gtfs", "Open Data Regione Lombardia (orario Trenord GTFS)", Area.TRAINS,
            "https://www.dati.lombardia.it/api/views/3z4k-mxz9.json") { it.contains("trenord_gtfs", true) && it.contains("blobId") },
        Check("mit", "Ministero dei Trasporti (scioperi)", Area.NEWS, Sources.MIT_URL) { it.contains("sciop", true) },
        Check("trenitalia_news", "Trenitalia (notizie infomobilità)", Area.NEWS, Sources.TRENITALIA_INFO_URL) { it.contains("nfomobilit", true) },
        Check("overpass", "OpenStreetMap · Overpass", Area.MAPS, "https://overpass-api.de/api/status",
            listOf("https://z.overpass-api.de/api/status", "https://lz4.overpass-api.de/api/status", "https://overpass.osm.ch/api/status")) {
            it.contains("slots available", true) || it.contains("Rate limit", true) || it.contains("Connected as", true)
        },
        Check("postpass", "OpenStreetMap · Postpass (riserva)", Area.MAPS,
            "https://postpass.geofabrik.de/api/interpreter?data=" + java.net.URLEncoder.encode(
                "SELECT osm_type, osm_id, tags, geom FROM postpass_pointpolygon WHERE geom && ST_MakeEnvelope(8.83,45.81,8.84,45.82,4326) " +
                    "AND tags->>'railway' = 'station'", "UTF-8")) {
            it.contains("FeatureCollection")
        },
        Check("tiles", "Mappe (tessere OpenStreetMap)", Area.MAPS, "https://tile.openstreetmap.org/0/0/0.png") { true },
        Check("trenord_sellers", "Trenord (rivendite autorizzate)", Area.SELLERS, "https://biglietterie.trenord.it/it/punti-vendita-varese") {
            TicketSellers.parseProvince(it, "varese").isNotEmpty()
        },
        Check("bz_sellers", "altoadigemobilità (punti vendita)", Area.SELLERS, TicketSellers.BZ_SITE) { TicketSellers.parseAltoAdige(it).size >= 10 },
        Check("trovatreno", "TrovaTreno (puntualità Italia)", Area.STATS,
            "https://www.trovatreno.it/open-data/puntualita-operatori-corrente-30g.csv") { it.startsWith("operatore;") || it.contains("operatore;puntualita") },
        Check("sbb_ist", "FFS (puntualità Svizzera)", Area.STATS,
            "https://data.sbb.ch/api/explore/v2.1/catalog/datasets/ist-daten-sbb/records?limit=1") { it.contains("betreiber_abk") },
    )

    private fun fetch(url: String, ua: String): Pair<Int, String> {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("User-Agent", ua)
            setRequestProperty("Accept-Language", "it-IT,it;q=0.9")
        }
        try {
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            return code to body
        } finally {
            c.disconnect()
        }
    }

    fun run(check: Check): Result {
        val t0 = System.currentTimeMillis()
        var first: Result? = null
        (listOf(check.url) + check.alternatives).forEachIndexed { i, url ->
            val r = try {
                val (code, body) = fetch(url, check.ua)
                val ms = System.currentTimeMillis() - t0
                when {
                    code !in 200..299 -> Result(check, false, ms, "HTTP $code")
                    !check.test(body) -> Result(check, false, ms, I18n.tr("risponde ma il formato è cambiato", "responds but the format changed"))
                    else -> Result(check, true, ms, if (i == 0) "OK" else I18n.tr("OK (server di riserva: ", "OK (backup server: ") + URL(url).host + ")")
                }
            } catch (e: Exception) {
                Result(check, false, System.currentTimeMillis() - t0, e.javaClass.simpleName + (e.message?.let { ": " + it.take(80) } ?: ""))
            }
            if (r.ok) return r
            if (first == null) first = r
        }
        return first!!
    }

    /** Esegue tutti i controlli in parallelo (massimo 30 secondi in tutto). */
    fun runAll(list: List<Check> = checks): List<Result> {
        val pool = Executors.newFixedThreadPool(6)
        try {
            val futures = list.map { c -> pool.submit(Callable { run(c) }) }
            return list.indices.map { i ->
                try {
                    futures[i].get(30, TimeUnit.SECONDS)
                } catch (e: Exception) {
                    Result(list[i], false, 30_000, I18n.tr("nessuna risposta", "no response"))
                }
            }
        } finally {
            pool.shutdownNow()
        }
    }
}
