package com.binario.treni.widget

import com.binario.treni.data.tx
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.binario.treni.data.Api
import com.binario.treni.data.Station
import com.binario.treni.data.Store
import com.binario.treni.data.TrainRef
import com.binario.treni.data.Tratta
import com.binario.treni.data.WidgetConfig
import com.binario.treni.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Scelta di cosa mostrare in un widget appena aggiunto (o toccando il suo titolo). */
class WidgetConfigActivity : ComponentActivity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetId = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish(); return
        }
        val type = Widgets.typeOf(this, widgetId)
        if (type == WidgetType.FAV) {
            done(WidgetConfig(title = tx("Preferiti"))); return
        }
        setContent {
            BinarioTheme(Store(this).theme) {
                ConfigScreen(type, onCancel = { finish() }, onDone = { done(it) })
            }
        }
    }

    private fun done(c: WidgetConfig) {
        Store(this).setWidgetConfig(widgetId, c)
        val mgr = AppWidgetManager.getInstance(this)
        Widgets.update(this, mgr, widgetId, Widgets.typeOf(this, widgetId))
        mgr.notifyAppWidgetViewDataChanged(intArrayOf(widgetId), com.binario.treni.R.id.w_list)
        setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}

@Composable
private fun ConfigScreen(type: WidgetType, onCancel: () -> Unit, onDone: (WidgetConfig) -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var pickStation by remember { mutableStateOf<Int?>(null) } // 0 stazione widget, 1 partenza, 2 arrivo
    var routeFrom by remember { mutableStateOf<Station?>(null) }
    var trainNum by remember { mutableStateOf("") }
    var trainChoices by remember { mutableStateOf<List<TrainRef>>(emptyList()) }

    val title = when (type) {
        WidgetType.STATION -> tx("Widget Stazione")
        WidgetType.ROUTE -> tx("Widget Tragitto / Linea")
        WidgetType.TRAIN -> tx("Widget Treno")
        WidgetType.FAV -> tx("Widget Preferiti")
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(title, onBack = onCancel)
        LazyColumn {
            when (type) {
                WidgetType.STATION -> {
                    item { SimpleRow(Icons.Filled.Search, tx("Cerca una stazione"), "") { pickStation = 0 } }
                    val favs = store.favStations()
                    if (favs.isNotEmpty()) item { SectionHeader(tx("Stazioni preferite")) }
                    items(favs) { s -> SimpleRow(Icons.Filled.Place, s.name, "") { onDone(WidgetConfig(station = s, title = s.name)) } }
                }
                WidgetType.ROUTE -> {
                    item {
                        SimpleRow(Icons.Filled.Search, tx("Scegli partenza e arrivo"),
                            routeFrom?.let { com.binario.treni.data.I18n.tr("Partenza: ${it.name} — ora scegli l'arrivo", "Departure: ${it.name} — now choose the arrival") } ?: "") { pickStation = 1 }
                    }
                    val lines = store.favLines()
                    if (lines.isNotEmpty()) item { SectionHeader(tx("Linee preferite")) }
                    lines.forEach { l ->
                        items(listOf(false, true)) { back ->
                            val t = l.direction(back)
                            SimpleRow(Icons.Filled.Timeline, "${l.name}  ${t.from.name} → ${t.to.name}", "") {
                                onDone(WidgetConfig(tratta = t, title = "${l.name} ${t.from.name} → ${t.to.name}".trim()))
                            }
                        }
                    }
                    val routes = store.recentAndFav().map { it.first }
                    if (routes.isNotEmpty()) item { SectionHeader(tx("Tratte preferite e recenti")) }
                    items(routes) { t -> SimpleRow(Icons.Filled.Route, t.label, "") { onDone(WidgetConfig(tratta = t, title = t.label)) } }
                }
                WidgetType.TRAIN -> {
                    item {
                        Surface(color = MaterialTheme.colorScheme.surface) {
                            Column(Modifier.padding(16.dp)) {
                                NumberField(trainNum, { trainNum = it; trainChoices = emptyList() }) {
                                    scope.launch {
                                        val l = try {
                                            withContext(Dispatchers.IO) { Api.trainLookup(trainNum) }
                                        } catch (e: Exception) {
                                            emptyList()
                                        }
                                        when (l.size) {
                                            0 -> toast(ctx, tx("Treno non trovato"))
                                            1 -> onDone(WidgetConfig(train = l[0].copy(date = 0L), title = com.binario.treni.data.I18n.tr("Treno ", "Train ") + l[0].number))
                                            else -> trainChoices = l
                                        }
                                    }
                                }
                            }
                        }
                    }
                    items(trainChoices) { r ->
                        SimpleRow(Icons.Filled.Train, r.label, "") { onDone(WidgetConfig(train = r.copy(date = 0L), title = com.binario.treni.data.I18n.tr("Treno ", "Train ") + r.number)) }
                    }
                    val favs = store.favTrains()
                    if (favs.isNotEmpty()) item { SectionHeader(tx("Treni preferiti")) }
                    items(favs) { r -> SimpleRow(Icons.Filled.Train, r.label, "") { onDone(WidgetConfig(train = r, title = r.label)) } }
                }
                WidgetType.FAV -> {}
            }
        }
    }

    pickStation?.let { which -> key(which) {
        StationPickerDialog(
            when (which) {
                1 -> tx("Stazione di partenza")
                2 -> tx("Stazione di arrivo")
                else -> tx("Stazione")
            },
            { pickStation = null },
        ) { s ->
            when (which) {
                0 -> onDone(WidgetConfig(station = s, title = s.name))
                1 -> {
                    routeFrom = s; pickStation = 2; return@StationPickerDialog
                }
                2 -> routeFrom?.let { f -> onDone(WidgetConfig(tratta = Tratta(f, s), title = "${f.name} → ${s.name}")) }
            }
            pickStation = null
        }
    } }
}
