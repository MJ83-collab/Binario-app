package com.binario.treni.data

import android.content.Context
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

/**
 * Confronto della puntualità tra aziende e paesi.
 * Fonti:
 *  - Italia: TrovaTreno.it (open data mensili, arrivi entro 5 minuti), per tipo di servizio e impresa;
 *    rete FerrovieNord raccolta dall'app (entro 5 minuti).
 *  - Svizzera: dati aperti FFS Ist-Daten raccolti dall'app (meno di 3 minuti).
 *  - Germania: valori ufficiali mensili DB (deutschebahn.com, fermate con meno di 6 minuti).
 *  - Austria: valori ufficiali mensili ÖBB (oebb.at, entro 5 minuti).
 * DB e ÖBB vengono riletti dal sito ufficiale (al massimo una volta ogni 12 ore); se il sito non risponde si usano gli
 * ultimi valori letti o, la prima volta, quelli verificati il 30/10/2026 (settembre 2026).
 */
object PunctCompare {
    enum class Country(val flag: String, val itLabel: String, val enLabel: String) {
        IT("🇮🇹", "Italia", "Italy"), CH("🇨🇭", "Svizzera", "Switzerland"), DE("🇩🇪", "Germania", "Germany"), AT("🇦🇹", "Austria", "Austria");
        val label: String get() = I18n.tr(itLabel, enLabel)
    }

    /** Tipo di servizio per filtrare il confronto. */
    enum class Kind(val itLabel: String, val enLabel: String) {
        REGIONAL("Regionali", "Regional"), LONG("Lunga percorrenza e alta velocità", "Long distance and high speed");
        val label: String get() = I18n.tr(itLabel, enLabel)
    }

    data class Entry(
        val id: String,
        val country: Country,
        val name: String,
        val kind: Kind,
        val percent: Double,
        /** Soglia di puntualità: "≤ 5 min", "< 6 min", "< 3 min". */
        val threshold: String,
        val period: String,
        val source: String,
        val sourceUrl: String,
        /** Arrivi osservati (0 se non noto, per i valori ufficiali). */
        val observed: Int = 0,
        val avgDelay: Double? = null,
    )

    /** Selezione predefinita: le principali aziende di ciascun paese. */
    val DEFAULT = listOf(
        "it:REGIONAL:trenitalia", "it:REGIONAL:trenord", "it:HIGH_SPEED:trenitalia", "it:HIGH_SPEED:italo",
        "ch:sbb:REGIONAL", "ch:sbb:INTERCITY", "de:db:regio", "de:db:fern", "at:oebb:nah", "at:oebb:fern",
    )

    private const val PREF = "punct_compare"

    fun selected(ctx: Context): List<String> {
        val s = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).getString(PREF, null) ?: return DEFAULT
        return s.split(',').filter { it.isNotBlank() }
    }

    fun setSelected(ctx: Context, ids: List<String>) =
        ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).edit().putString(PREF, ids.distinct().joinToString(",")).apply()

    // ---------------- Valori ufficiali DB e ÖBB ----------------

    const val DB_URL = "https://www.deutschebahn.com/de/konzern/konzernprofil/zahlen_fakten/puenktlichkeitswerte-6878476"
    const val OEBB_URL = "https://www.oebb.at/de/rechtliches/puenktlichkeit/oesterreich"

    /** (mese "yyyy-MM", regionali, lunga percorrenza). */
    data class Official(val month: String, val regional: Double, val long: Double)

    private val FALLBACK_DB = Official("2026-09", 88.2, 52.4)
    private val FALLBACK_OEBB = Official("2026-09", 92.9, 84.6)

    private val MONTHS_DE = listOf("januar", "februar", "märz", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "dezember")

    private fun fetch(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Binario/2.3")
            setRequestProperty("Accept-Language", "de")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun text(html: String) = html.replace(Regex("<script.*?</script>", RegexOption.DOT_MATCHES_ALL), " ")
        .replace(Regex("<[^>]+>"), " ").replace("&nbsp;", " ").replace("&#246;", "ö").replace("&ouml;", "ö").replace("&Ouml;", "Ö")
        .replace("&auml;", "ä").replace("&uuml;", "ü").replace("&szlig;", "ß")
        .replace(Regex("&#(\\d+);")) { m -> m.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: " " }
        .replace(Regex("\\s+"), " ")

    private fun num(s: String) = s.replace(',', '.').toDoubleOrNull()

    private fun monthOf(name: String, year: Int?): String? {
        val i = MONTHS_DE.indexOf(name.lowercase().replace("jänner", "januar"))
        if (i < 0) return null
        val now = Calendar.getInstance()
        val y = year ?: (if (i > now.get(Calendar.MONTH)) now.get(Calendar.YEAR) - 1 else now.get(Calendar.YEAR))
        return String.format(java.util.Locale.US, "%04d-%02d", y, i + 1)
    }

    /** DB: "Pünktlichkeitswerte für den September 2026", righe "Betriebliche Pünktlichkeit Nahverkehr/Fernverkehr" (ultimo valore). */
    fun parseDb(html: String): Official? {
        val t = text(html)
        val m = Regex("Pünktlichkeitswerte für den (\\p{L}+) (\\d{4})").find(t) ?: return null
        val month = monthOf(m.groupValues[1], m.groupValues[2].toInt()) ?: return null
        fun last(label: String) = Regex(Regex.escape(label) + "\\s*((?:\\d{1,3},\\d\\s*)+)").find(t)?.groupValues?.get(1)
            ?.trim()?.split(Regex("\\s+"))?.lastOrNull()?.let { num(it) }
        val reg = last("Betriebliche Pünktlichkeit Nahverkehr") ?: return null
        val long = last("Betriebliche Pünktlichkeit Fernverkehr") ?: return null
        return Official(month, reg, long)
    }

    /** ÖBB: "September ÖBB-Personenverkehr: 92,2% ÖBB-Nahverkehr: 92,9% ÖBB-Fernverkehr: 84,6%". */
    fun parseOebb(html: String): Official? {
        val t = text(html)
        val month = Regex("(\\p{L}+)\\s*ÖBB-Personenverkehr").find(t)?.groupValues?.get(1)?.let { monthOf(it, null) } ?: return null
        val reg = Regex("ÖBB-Nahverkehr:\\s*([\\d,]+)\\s*%").find(t)?.groupValues?.get(1)?.let { num(it) } ?: return null
        val long = Regex("ÖBB-Fernverkehr:\\s*([\\d,]+)\\s*%").find(t)?.groupValues?.get(1)?.let { num(it) } ?: return null
        return Official(month, reg, long)
    }

    private fun official(ctx: Context, key: String, url: String, fallback: Official, parse: (String) -> Official?): Official {
        val p = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE)
        val saved = p.getString("punct_off_$key", null)?.split('|')?.takeIf { it.size == 3 }?.let { a ->
            val r = a[1].toDoubleOrNull(); val l = a[2].toDoubleOrNull()
            if (r != null && l != null) Official(a[0], r, l) else null
        }
        val at = p.getLong("punct_off_${key}_at", 0L)
        if (saved != null && System.currentTimeMillis() - at < 12 * 3600_000L) return saved
        val fresh = try { parse(fetch(url)) } catch (_: Exception) { null }
        // Si accetta solo un valore plausibile e non più vecchio di quello già salvato
        if (fresh != null && fresh.regional in 30.0..100.0 && fresh.long in 20.0..100.0 && fresh.month >= (saved?.month ?: "")) {
            p.edit().putString("punct_off_$key", "${fresh.month}|${fresh.regional}|${fresh.long}").putLong("punct_off_${key}_at", System.currentTimeMillis()).apply()
            return fresh
        }
        return saved ?: fallback
    }

    /** Tutte le voci disponibili per il confronto (va chiamata fuori dal thread principale). */
    fun all(ctx: Context, italy: MonthStats?): List<Entry> {
        val out = ArrayList<Entry>()
        italy?.let { d ->
            val period = Stats.monthLabel(d.month)
            d.bySegment().forEach { (seg, rows) ->
                rows.forEach { r ->
                    out += Entry(
                        "it:${seg.name}:${r.operator.lowercase()}", Country.IT, r.name + (if (seg == Segment.INTERCITY) " · Intercity" else ""),
                        if (seg == Segment.REGIONAL) Kind.REGIONAL else Kind.LONG, r.percent, "≤ 5 min", period, Stats.SOURCE,
                        "https://www.trovatreno.it/open-data/", r.observed, r.avgDelay,
                    )
                }
            }
        }
        FnStats.summary(ctx)?.let { f ->
            if (f.total.observed > 0) out += Entry("it:fn", Country.IT, I18n.tr("Trenord · rete FerrovieNord", "Trenord · FerrovieNord network"), Kind.REGIONAL,
                f.total.percent, "≤ 5 min", I18n.tr("ultimi ", "last ") + f.days + I18n.tr(" giorni", " days"), FnStats.SOURCE, "", f.total.observed, f.total.avgDelay)
        }
        SwissStats.summary(ctx)?.let { s ->
            s.rows.forEach { (seg, r) ->
                out += Entry("ch:sbb:${seg.name}", Country.CH, r.name, if (seg == Segment.REGIONAL) Kind.REGIONAL else Kind.LONG, r.percent, "< 3 min",
                    I18n.tr("ultimi ", "last ") + s.days + I18n.tr(" giorni", " days"), SwissStats.SOURCE, SwissStats.SOURCE_URL, r.observed)
            }
        }
        val db = official(ctx, "db", DB_URL, FALLBACK_DB, ::parseDb)
        out += Entry("de:db:regio", Country.DE, "DB Regio (" + I18n.tr("regionali e S-Bahn", "regional and S-Bahn") + ")", Kind.REGIONAL, db.regional, "< 6 min",
            Stats.monthLabel(db.month), I18n.tr("Deutsche Bahn · valori ufficiali", "Deutsche Bahn · official figures"), DB_URL)
        out += Entry("de:db:fern", Country.DE, "DB Fernverkehr (ICE, IC, EC)", Kind.LONG, db.long, "< 6 min",
            Stats.monthLabel(db.month), I18n.tr("Deutsche Bahn · valori ufficiali", "Deutsche Bahn · official figures"), DB_URL)
        val oe = official(ctx, "oebb", OEBB_URL, FALLBACK_OEBB, ::parseOebb)
        out += Entry("at:oebb:nah", Country.AT, "ÖBB · " + I18n.tr("regionali", "regional"), Kind.REGIONAL, oe.regional, "≤ 5 min",
            Stats.monthLabel(oe.month), I18n.tr("ÖBB · valori ufficiali", "ÖBB · official figures"), OEBB_URL)
        out += Entry("at:oebb:fern", Country.AT, "ÖBB · " + I18n.tr("lunga percorrenza (Railjet, IC, Nightjet)", "long distance (Railjet, IC, Nightjet)"), Kind.LONG,
            oe.long, "≤ 5 min", Stats.monthLabel(oe.month), I18n.tr("ÖBB · valori ufficiali", "ÖBB · official figures"), OEBB_URL)
        return out
    }
}
