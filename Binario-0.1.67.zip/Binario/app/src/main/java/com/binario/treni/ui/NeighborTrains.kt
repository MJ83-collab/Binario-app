package com.binario.treni.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.BoardItem
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class Neighbors(val station: String, val ahead: List<BoardItem>, val behind: List<BoardItem>)

/**
 * Treni davanti e dietro al tuo: guarda il tabellone della prossima fermata (o dell'origine, se non è partito) e prende i treni
 * nella stessa direzione che passano nei 45 minuti prima e dopo il tuo. Se quello davanti è in ritardo, può rallentare il tuo.
 */
private fun load(st: TrainStatus): Neighbors? {
    // Fermata di riferimento: la prossima (non l'ultima, dove non ci sono partenze)
    val idx = st.stops.indexOfFirst { !it.passed }
    if (idx < 0 || idx >= st.stops.size - 1) return null
    val ref = st.stops[idx]
    val mine = if (ref.schedDep > 0) ref.schedDep else ref.schedArr
    if (mine <= 0) return null
    val later = st.stops.drop(idx + 1).map { it.name.trim().uppercase() }.toSet()
    val window = 45 * 60_000L
    val board = Api.departures(ref.station, mine - window)
        .filter { it.time in (mine - window)..(mine + window) && it.number != st.number }
        .filter { it.otherEnd.trim().uppercase() in later }
        .distinctBy { it.number + "/" + it.time }
    val ahead = board.filter { it.time < mine }.sortedByDescending { it.time }.take(2)
    val behind = board.filter { it.time > mine }.sortedBy { it.time }.take(2)
    return Neighbors(ref.name, ahead, behind)
}

@Composable
fun NeighborTrainsCard(st: TrainStatus, onTrain: (TrainRef) -> Unit) {
    if (st.cancelled || st.arrived) return
    var data by remember(st.number, st.originCode) { mutableStateOf<Neighbors?>(null) }
    var done by remember(st.number, st.originCode) { mutableStateOf(false) }
    LaunchedEffect(st.number, st.originCode) {
        data = withContext(Dispatchers.IO) { runCatching { load(st) }.getOrNull() }
        done = true
    }
    if (done && (data == null || (data!!.ahead.isEmpty() && data!!.behind.isEmpty()))) return
    WhiteCard {
        CardTitle(I18n.tr("Treni davanti e dietro al tuo", "Trains ahead and behind yours"))
        val d = data
        if (d == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), color = Green)
            return@WhiteCard
        }
        Text(I18n.tr("Confronto alla prossima fermata: ", "Compared at the next stop: ") + d.station, color = Muted, fontSize = 12.sp,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 4.dp))
        d.ahead.forEach { NeighborRow(it, I18n.tr("Davanti", "Ahead"), onTrain) }
        Text("▼ " + I18n.tr("Il tuo treno", "Your train") + " · " + st.title + (if (st.delay != 0) "  " + (if (st.delay > 0) "+" else "") + st.delay + " min" else ""),
            fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        d.behind.forEach { NeighborRow(it, I18n.tr("Dietro", "Behind"), onTrain) }
        val front = d.ahead.firstOrNull()
        if (front != null && front.delay >= st.delay + 5) {
            Text("⚠ " + I18n.tr("Il treno davanti è in ritardo e potrebbe rallentare il tuo.", "The train ahead is running late and could slow yours down."),
                color = LateRed, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        Text(I18n.tr("Treni nella stessa direzione che passano da quella fermata nei 45 minuti prima e dopo il tuo. Fonte: ViaggiaTreno.",
            "Trains in the same direction passing that stop in the 45 minutes before and after yours. Source: ViaggiaTreno."),
            color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 10.dp))
    }
}

@Composable
private fun NeighborRow(b: BoardItem, label: String, onTrain: (TrainRef) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onTrain(b.ref) }.padding(horizontal = 16.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.width(64.dp))
        Column(Modifier.weight(1f)) {
            Text("${b.category} ${b.number}".trim() + " → " + b.otherEnd, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(Fmt.time(b.time), color = Muted, fontSize = 12.sp)
        }
        if (b.inStation || b.delay != 0) {
            Text((if (b.delay > 0) "+" else "") + b.delay + " min", fontWeight = FontWeight.Bold, fontSize = 14.sp,
                color = if (b.delay > 0) LateRed else OnTime)
        }
    }
}
