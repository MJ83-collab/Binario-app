package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Punti vendita UFFICIALI dei biglietti (non tutte le tabaccherie):
 * - Trenord (Lombardia): rivendite autorizzate (bar, tabaccherie, edicole, agenzie) e biglietterie con orari,
 *   dal sito biglietterie.trenord.it. L'elenco si aggiorna ogni settimana; lo stato "aperto/chiuso" è letto dal vivo.
 * - FFS/SBB (Svizzera): biglietterie automatiche dai dati aperti data.sbb.ch.
 * - Trenitalia (resto d'Italia): i biglietti regionali si vendono nei punti dei circuiti PuntoLIS e Mooney;
 *   Trenitalia non pubblica un elenco scaricabile, quindi l'app apre la sua mappa ufficiale ([TRENITALIA_MAP]).
 */
object TicketSellers {
    const val TRENORD_SITE = "https://biglietterie.trenord.it/it/punti-vendita"
    const val TRENITALIA_MAP = "https://locator.ubiest.com/storeLocator/customers/trenitalia/biglietterie/"
    const val TRENITALIA_INFO = "https://www.trenitalia.com/it/informazioni/punti-vendita.html"
    const val SBB_DATA = "https://data.sbb.ch/explore/dataset/billetautomat/"
    const val BZ_SITE = "https://www.suedtirolmobil.info/it/ticket/punti-vendita/punti-vendita-altoadigemobilita"
    private const val BASE = "https://biglietterie.trenord.it"
    private const val WEEK = 7 * 24 * 3600_000L
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36 Binario/2.3"

    /** Province delle pagine Trenord con il codice usato negli indirizzi delle biglietterie. */
    private val PROVINCES = linkedMapOf(
        "bergamo" to "bg", "brescia" to "bs", "como" to "co", "cremona" to "cr", "lecco" to "lc", "lodi" to "lo",
        "mantova" to "mn", "milano" to "mi", "monza" to "mb", "pavia" to "pv", "sondrio" to "so", "varese" to "va",
    )

    private val DAYS = listOf("lunedì", "martedì", "mercoledì", "giovedì", "venerdì", "sabato", "domenica")
    private val DAYS_SHORT = listOf("Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom")

    /** Un punto vendita ufficiale. */
    data class Seller(
        val source: String,
        val kind: OsmPlace.Kind,
        val name: String,
        val lat: Double,
        val lon: Double,
        val nearStation: String = "",
        val province: String = "",
        /** Stato letto dal vivo, es. "Aperto - Chiude alle: 19:30". */
        val status: String = "",
        /** Orari settimanali in forma compatta, es. "Lun–Dom 6:00–20:00". */
        val hours: String = "",
        val address: String = "",
        val url: String = "",
        /** Cosa si può comprare (es. "Biglietti singoli · Mobilcard"). */
        val services: String = "",
        /** Distanza a piedi dalla stazione più vicina, in metri (rivendite Trenord). */
        val nearDist: Int = 0,
        /** Numero di emettitrici automatiche nella stazione (solo per le emettitrici Trenord). */
        val machines: Int = 0,
        /** Pagamenti accettati dalle emettitrici: "E" elettronico, "M" moneta, "B" banconote; "!" = operativa con limitazioni. */
        val pay: String = "",
        /** Nome che l'azienda dà al punto (es. "My Link Point", "Ufficio Assistenza Clienti", "Casa Italo"). */
        val brand: String = "",
        /** Ufficio di assistenza clienti (informazioni, reclami, rimborsi, disagi), non solo vendita. */
        val assist: Boolean = false,
    ) {
        /** Coordinate note (le emettitrici Trenord hanno solo il nome della stazione finché non le colleghiamo). */
        val located: Boolean get() = !lat.isNaN() && !lon.isNaN() && (lat != 0.0 || lon != 0.0)
        val payments: List<Pair<Char, Boolean>> get() = pay.split(",").filter { it.isNotBlank() }.map { it[0] to it.endsWith("!") }
        val limited: Boolean get() = pay.contains("!")

        fun toJson(): JSONObject = JSONObject().put("s", source).put("k", kind.name).put("n", name)
            .put("la", if (located) lat else 0.0).put("lo", if (located) lon else 0.0)
            .put("ns", nearStation).put("p", province).put("st", status).put("h", hours).put("a", address).put("u", url)
            .put("sv", services).put("nd", nearDist).put("m", machines).put("py", pay).put("bn", brand).put("as", assist)

        companion object {
            fun from(o: JSONObject) = Seller(o.optString("s"), OsmPlace.Kind.valueOf(o.optString("k", "RESELLER")), o.optString("n"),
                o.optDouble("la", 0.0), o.optDouble("lo", 0.0), o.optString("ns"), o.optString("p"), o.optString("st"), o.optString("h"),
                o.optString("a"), o.optString("u"), o.optString("sv"), o.optInt("nd"), o.optInt("m"), o.optString("py"),
                o.optString("bn"), o.optBoolean("as"))
        }
    }

    // ---------------- Rete ----------------

    private fun http(url: String, timeout: Int = 15000): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = timeout
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept-Language", "it-IT,it;q=0.9")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun text(html: String): String = html
        .replace(Regex("(?is)<script.*?</script>|<style.*?</style>"), " ")
        .replace(Regex("<[^>]+>"), " ")
        .replace("&amp;", "&").replace("&nbsp;", " ").replace("&#x27;", "'").replace("&#39;", "'").replace("&quot;", "\"")
        .replace(Regex("\\s+"), " ").trim()

    private fun cap(s: String) = s.trim().lowercase().split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }

    // ---------------- Trenord: rivendite autorizzate (pagine di provincia) ----------------

    /** Legge le rivendite di una provincia: nome, posizione, stazione più vicina e stato attuale. */
    fun parseProvince(html: String, province: String): List<Seller> {
        val out = ArrayList<Seller>()
        val re = Regex("destination=(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)")
        val marks = re.findAll(html).toList()
        marks.forEachIndexed { i, m ->
            val end = if (i + 1 < marks.size) marks[i + 1].range.first else minOf(html.length, m.range.last + 4000)
            val card = html.substring(m.range.last, end)
            if (!card.contains("Stazione più vicina") && !card.contains("Stazione pi&ugrave; vicina")) return@forEachIndexed
            val name = Regex("<h3[^>]*>([^<]+)</h3>").find(card)?.groupValues?.get(1)?.trim() ?: return@forEachIndexed
            val near = Regex("vicina:\\s*(?:<[^>]+>\\s*)*([^<]+)<").find(card)?.groupValues?.get(1)?.trim().orEmpty()
            val statusRaw = Regex("bold-status[^>]*>([^<]+)</span>([^<]*)").find(card)?.let { s ->
                (s.groupValues[1] + s.groupValues[2]).replace(Regex("\\s+"), " ").trim()
            }.orEmpty()
            val walk = Regex("Distanza:\\s*(\\d+)\\s*metri").find(card)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            out += Seller("Trenord", OsmPlace.Kind.RESELLER, cap(text(name)), m.groupValues[1].toDouble(), m.groupValues[2].toDouble(),
                nearStation = cap(text(near)), province = province, status = statusRaw, nearDist = walk, brand = "Rivendita autorizzata Trenord")
        }
        return out.distinctBy { "${it.name}|${it.lat}|${it.lon}" }
    }

    /**
     * Le pagine di provincia Trenord hanno tre sezioni (titoli h2): "Biglietterie" (a Milano "My link point"),
     * "Emettitrici automatiche" e "Rivenditori". Restituisce il pezzo di pagina di ciascuna.
     */
    fun sections(html: String): Map<String, String> {
        val heads = Regex("(?is)<h2[^>]*>(.*?)</h2>").findAll(html).toList()
        val out = HashMap<String, String>()
        heads.forEachIndexed { i, h ->
            val t = text(h.groupValues[1]).lowercase()
            val key = when {
                t.contains("emettitric") -> "machine"
                t.contains("rivendit") -> "reseller"
                t.contains("bigliett") || t.contains("link point") -> "office"
                else -> return@forEachIndexed
            }
            val end = if (i + 1 < heads.size) heads[i + 1].range.first else html.length
            out[key] = (out[key] ?: "") + html.substring(h.range.last + 1, end)
        }
        return out
    }

    /** Emettitrici automatiche di una provincia: stazione, quante sono e come si paga (con eventuali limitazioni). */
    fun parseMachines(html: String, province: String): List<Seller> {
        val part = sections(html)["machine"] ?: return emptyList()
        val heads = Regex("<h3[^>]*>([^<]+)</h3>").findAll(part).toList()
        return heads.mapIndexedNotNull { i, h ->
            val end = if (i + 1 < heads.size) heads[i + 1].range.first else part.length
            val card = part.substring(h.range.last, end)
            val n = Regex(">\\s*(\\d+)\\s*emet").find(card)?.groupValues?.get(1)?.toIntOrNull() ?: 1
            val pay = Regex("title=\"([^\"]+)\"").findAll(card).map { it.groupValues[1] }.mapNotNull { t ->
                val c = when {
                    t.startsWith("Elettronic", true) -> 'E'
                    t.startsWith("Monet", true) -> 'M'
                    t.startsWith("Banconot", true) -> 'B'
                    else -> null
                } ?: return@mapNotNull null
                if (t.contains("limitazion", true)) "$c!" else "$c"
            }.distinct().joinToString(",")
            val station = cap(text(h.groupValues[1]))
            if (station.isBlank()) null
            else Seller("Trenord", OsmPlace.Kind.TICKET_MACHINE, station, 0.0, 0.0, nearStation = station, province = province,
                machines = n, pay = pay, brand = "Emettitrice Trenord")
        }.distinctBy { it.name }
    }

    /** Biglietterie / My Link Point elencati nella pagina di provincia: nome, stato attuale e indirizzo della pagina. */
    fun parseProvinceOffices(html: String, province: String): List<Seller> {
        val part = sections(html)["office"] ?: return emptyList()
        val heads = Regex("<h3[^>]*>([^<]+)</h3>").findAll(part).toList()
        return heads.mapIndexedNotNull { i, h ->
            val start = if (i > 0) heads[i - 1].range.last else 0
            val end = if (i + 1 < heads.size) heads[i + 1].range.first else part.length
            val href = Regex("href=\"(?:\\.\\./)*/?(it/punti-vendita-[^\"]+)\"").findAll(part.substring(start, h.range.first)).lastOrNull()
                ?.groupValues?.get(1)
            val card = part.substring(h.range.last, end)
            val status = Regex("bold-status[^>]*>([^<]+)</span>([^<]*)").find(card)?.let { s ->
                (s.groupValues[1] + s.groupValues[2]).replace(Regex("\\s+"), " ").trim()
            }.orEmpty()
            val name = cap(text(h.groupValues[1]))
            if (name.isBlank()) null
            else {
                val link = href?.contains("my-link-point", true) == true
                Seller("Trenord", OsmPlace.Kind.TICKET_OFFICE, name, 0.0, 0.0, province = province, status = status,
                    url = href?.let { "$BASE/$it" }.orEmpty(), brand = if (link) "My Link Point" else "Biglietteria Trenord", assist = link)
            }
        }
    }

    /** Tutto ciò che c'è in una pagina di provincia: biglietterie, emettitrici e rivendite. */
    fun parseProvinceAll(html: String, province: String): List<Seller> =
        parseProvinceOffices(html, province) + parseMachines(html, province) + parseProvince(html, province)

    // ---------------- Trenord: biglietterie con orari (pagine singole) ----------------

    /** Orari settimanali in forma compatta: giorni consecutivi con lo stesso orario vengono uniti. */
    fun compactHours(byDay: List<String>): String {
        if (byDay.all { it.isBlank() }) return ""
        val groups = ArrayList<Triple<Int, Int, String>>()
        byDay.forEachIndexed { d, h ->
            val last = groups.lastOrNull()
            if (last != null && last.third == h && last.second == d - 1) groups[groups.size - 1] = Triple(last.first, d, h)
            else groups += Triple(d, d, h)
        }
        return groups.filter { it.third.isNotBlank() }.joinToString(" · ") { (a, b, h) ->
            (if (a == b) DAYS_SHORT[a] else DAYS_SHORT[a] + "–" + DAYS_SHORT[b]) + " " + h
        }
    }

    fun parseOffice(html: String, url: String): Seller? {
        val coord = Regex("destination=(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)").find(html) ?: return null
        val t = text(html)
        val title = Regex("(?is)<title>([^<|]+)").find(html)?.groupValues?.get(1)?.trim() ?: return null
        val byDay = DAYS.map { day ->
            Regex("(?i)$day\\s+((?:\\d{1,2}[:.]\\d{2}\\s*-\\s*\\d{1,2}[:.]\\d{2}[\\s,;]*)+|chiuso)").find(t)
                ?.groupValues?.get(1)?.trim()?.trimEnd(',', ';')?.replace(" - ", "–")?.replace("-", "–")?.let {
                    if (it.equals("chiuso", true)) "chiuso" else it
                }.orEmpty()
        }
        val status = Regex("(Aperto|Chiuso)\\s*-\\s*(?:Chiude|Apre)[^0-9]{0,30}\\d{1,2}[:.]\\d{2}").find(t)?.value.orEmpty()
        val address = Regex("\\d{1,2}[:.]\\d{2}\\s+([^:]{5,90}?,\\s*\\d{5},\\s*Lombardia)").find(t)?.groupValues?.get(1)?.trim().orEmpty()
        val province = PROVINCES.entries.firstOrNull { url.contains("punti-vendita-${it.value}/") }?.key.orEmpty()
        val link = url.contains("my-link-point", true) || title.contains("link point", true)
        return Seller("Trenord", OsmPlace.Kind.TICKET_OFFICE, cap(title.trim()),
            coord.groupValues[1].toDouble(), coord.groupValues[2].toDouble(), province = province,
            status = status, hours = compactHours(byDay), address = address, url = url,
            brand = if (link) "My Link Point" else "Biglietteria Trenord", assist = link)
    }

    /** Indirizzi di tutte le biglietterie Trenord, dalla mappa del sito. */
    private fun officeUrls(): List<String> =
        Regex("<loc>([^<]+)</loc>").findAll(http("$BASE/sitemap1.xml")).map { it.groupValues[1].trim() }
            .filter { it.contains("/it/punti-vendita-") && (it.contains("/biglietteria-") || it.contains("/my-link-point")) }
            .distinct().toList()

    // ---------------- Alto Adige (altoadigemobilità / STA, treni SAD e Trenitalia) ----------------

    /** Una voce dell'elenco altoadigemobilità prima di ricavare le coordinate. */
    data class RawPoint(val town: String, val name: String, val address: String, val hours: String, val services: String)

    /** Legge l'elenco ufficiale altoadigemobilità: località, nome, indirizzo, orari e servizi venduti. */
    fun parseAltoAdige(html: String): List<RawPoint> {
        val marks = Regex("(?is)AccordionCMS__labelText\">([^<]+)<|<h2[^>]*>(.*?)</h2>").findAll(html).toList()
        val out = ArrayList<RawPoint>()
        var town = ""
        marks.forEachIndexed { i, m ->
            if (m.groupValues[1].isNotBlank()) { town = text(m.groupValues[1]); return@forEachIndexed }
            val name = text(m.groupValues[2])
            if (name.isBlank()) return@forEachIndexed
            val end = if (i + 1 < marks.size) marks[i + 1].range.first else html.length
            val block = html.substring(m.range.last + 1, end)
            val services = Regex("(?is)<li[^>]*>(.*?)</li>").findAll(block).map { text(it.groupValues[1]) }.filter { it.isNotBlank() }.joinToString(" · ")
            val t = text(block.replace(Regex("(?is)<ul.*?</ul>"), " "))
            val address = Regex("""(?i)(?:Indirizzo|Adresse):\s*(.+?)(?=\s*(?:Orari?o?\s+d|Telefono|Servizi|E-mail|$))""").find(t)?.groupValues?.get(1)?.trim().orEmpty()
            val hours = Regex("""(?i)Orari?o?\s+d[i’']\s*apertura:?\s*(.+?)(?=\s*(?:Telefono|Servizi|E-mail|$))""").find(t)?.groupValues?.get(1)
                ?.replace("ore ", "")?.trim().orEmpty()
            out += RawPoint(town, name, address, hours, services)
        }
        return out
    }

    private fun geoCacheFile(ctx: Context) = File(ctx.filesDir, "geocode_cache.json")

    /**
     * Coordinate da un indirizzo con il servizio gratuito Nominatim di OpenStreetMap (massimo 1 richiesta al secondo,
     * come chiede la sua policy). I risultati restano in memoria: le settimane successive si cercano solo gli indirizzi nuovi.
     */
    private fun geocode(ctx: Context, queries: List<String>): Map<String, Pair<Double, Double>> {
        val cache = try { JSONObject(geoCacheFile(ctx).readText()) } catch (e: Exception) { JSONObject() }
        val out = HashMap<String, Pair<Double, Double>>()
        var asked = 0
        for (q in queries.distinct()) {
            val hit = cache.optString(q)
            if (hit.isNotBlank()) {
                if (hit != "x") hit.split(",").let { p -> out[q] = p[0].toDouble() to p[1].toDouble() }
                continue
            }
            if (asked > 0) Thread.sleep(1100)
            asked++
            val r = try {
                val c = (URL("https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=it,at&q=" +
                    java.net.URLEncoder.encode(q, "UTF-8")).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000; readTimeout = 15000
                    setRequestProperty("User-Agent", "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)")
                }
                try { JSONArray(c.inputStream.bufferedReader().use { it.readText() }) } finally { c.disconnect() }
            } catch (e: Exception) {
                null
            } ?: continue // errore di rete: si riprova la prossima volta
            val first = r.optJSONObject(0)
            if (first != null) {
                val la = first.optString("lat").toDouble(); val lo = first.optString("lon").toDouble()
                out[q] = la to lo; cache.put(q, "$la,$lo")
            } else cache.put(q, "x")
        }
        try { geoCacheFile(ctx).writeText(cache.toString()) } catch (_: Exception) { }
        return out
    }

    private fun bzCacheFile(ctx: Context) = File(ctx.filesDir, "sellers_altoadige.json")

    /** Scarica di nuovo l'elenco altoadigemobilità e ricava le coordinate (solo per gli indirizzi nuovi). */
    @Synchronized
    fun refreshAltoAdige(ctx: Context, onProgress: (String) -> Unit = {}): List<Seller> {
        onProgress(I18n.tr("Scarico i punti vendita dell'Alto Adige…", "Downloading South Tyrol ticket outlets…"))
        val raw = parseAltoAdige(http(BZ_SITE, 25000))
        if (raw.isEmpty()) throw IOException("Elenco altoadigemobilità vuoto")
        fun query(p: RawPoint) = if (p.address.isNotBlank()) p.address else "${p.town}, Alto Adige"
        onProgress(I18n.tr("Calcolo le posizioni…", "Locating outlets…"))
        val geo = geocode(ctx, raw.map { query(it) } + raw.map { "${it.town}, Alto Adige" })
        val items = raw.mapNotNull { p ->
            val c = geo[query(p)] ?: geo["${p.town}, Alto Adige"] ?: return@mapNotNull null
            val kind = if (p.name.contains("Biglietteria", true) || p.name.contains("Infopoint", true)) OsmPlace.Kind.TICKET_OFFICE
            else OsmPlace.Kind.RESELLER
            Seller("altoadigemobilità", kind, if (p.name.startsWith("Biglietteria", true)) "${p.name} · ${p.town}" else p.name,
                c.first, c.second, hours = p.hours, address = p.address.ifBlank { p.town }, url = BZ_SITE, services = p.services)
        }
        val a = JSONArray(); items.forEach { a.put(it.toJson()) }
        try { bzCacheFile(ctx).writeText(JSONObject().put("at", System.currentTimeMillis()).put("items", a).toString()) } catch (_: Exception) { }
        return items
    }

    fun hasAltoAdige(ctx: Context) = bzCacheFile(ctx).exists()

    /** In Alto Adige / Trentino settentrionale (riquadro approssimativo). */
    fun inAltoAdige(lat: Double, lon: Double) = lat in 46.0..47.15 && lon in 10.35..12.5

    fun altoAdigeNear(ctx: Context, lat: Double, lon: Double, radius: Int, onProgress: (String) -> Unit = {}): List<Pair<Seller, Int>> {
        if (!inAltoAdige(lat, lon)) return emptyList()
        val (at, cached) = try {
            val o = JSONObject(bzCacheFile(ctx).readText()); val a = o.getJSONArray("items")
            o.optLong("at") to (0 until a.length()).map { Seller.from(a.getJSONObject(it)) }
        } catch (e: Exception) {
            0L to emptyList()
        }
        var items = cached
        if (items.isEmpty()) items = refreshAltoAdige(ctx, onProgress)
        else if (System.currentTimeMillis() - at > WEEK) Thread { try { refreshAltoAdige(ctx.applicationContext) } catch (_: Exception) { } }.start()
        return items.map { it to dist(lat, lon, it.lat, it.lon) }.filter { it.second <= radius }.sortedBy { it.second }
    }

    // ---------------- Memoria settimanale ----------------

    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "ticket_sellers.json")

    private fun loadCache(ctx: Context): Pair<Long, List<Seller>> = try {
        val o = JSONObject(cacheFile(ctx).readText())
        val a = o.getJSONArray("items")
        o.optLong("at") to (0 until a.length()).map { Seller.from(a.getJSONObject(it)) }
    } catch (e: Exception) {
        0L to emptyList()
    }

    private fun saveCache(ctx: Context, items: List<Seller>) {
        val a = JSONArray()
        items.forEach { a.put(it.toJson()) }
        try {
            cacheFile(ctx).writeText(JSONObject().put("at", System.currentTimeMillis()).put("items", a).toString())
        } catch (_: Exception) {
        }
    }

    /** Data dell'ultimo aggiornamento completo (0 = mai). */
    fun updatedAt(ctx: Context): Long = loadCache(ctx).first

    /**
     * Elenco già pronto, preparato ogni settimana su GitHub dallo stesso lettore dell'app (un solo file invece di
     * decine di pagine del sito Trenord): è il modo più veloce e affidabile.
     */
    const val PUBLISHED_URL = "https://raw.githubusercontent.com/MJ83-collab/Binario-app/main/sellers.json"

    /** Scarica e legge l'elenco pubblicato; null se non disponibile. Restituisce (data di preparazione, elenco). */
    fun fetchPublished(): Pair<Long, List<Seller>>? = try {
        val o = JSONObject(http(PUBLISHED_URL, 20000))
        val a = o.getJSONArray("items")
        val items = (0 until a.length()).mapNotNull { runCatching { Seller.from(a.getJSONObject(it)) }.getOrNull() }
        if (items.size < 50) null else o.optLong("at") to items
    } catch (e: Exception) {
        null
    }

    /**
     * Legge dal sito Trenord le pagine di alcune province (o di tutte): rivendite, emettitrici automatiche e, se richiesto,
     * le biglietterie / My Link Point con orari e indirizzo (dalle loro pagine).
     */
    fun downloadTrenord(provinces: Collection<String> = PROVINCES.keys, offices: Boolean = true, onProgress: (String) -> Unit = {}): List<Seller> {
        val pool = Executors.newFixedThreadPool(6)
        try {
            onProgress(I18n.tr("Scarico i punti vendita Trenord…", "Downloading Trenord sales points…"))
            val provFutures = provinces.map { p -> pool.submit<List<Seller>> { parseProvinceAll(http("$BASE/it/punti-vendita-$p"), p) } }
            val fromProvinces = provFutures.flatMap { f -> try { f.get(30, TimeUnit.SECONDS) } catch (e: Exception) { emptyList() } }
            val listed = fromProvinces.filter { it.kind == OsmPlace.Kind.TICKET_OFFICE }
            val detailed = if (!offices) emptyList() else try {
                onProgress(I18n.tr("Scarico gli orari delle biglietterie…", "Downloading ticket office hours…"))
                officeUrls().map { u -> pool.submit<Seller?> { try { parseOffice(http(u), u) } catch (e: Exception) { null } } }
                    .mapNotNull { f -> try { f.get(30, TimeUnit.SECONDS) } catch (e: Exception) { null } }
            } catch (e: Exception) {
                emptyList()
            }
            return fromProvinces.filter { it.kind != OsmPlace.Kind.TICKET_OFFICE } + mergeOffices(detailed, listed)
        } finally {
            pool.shutdownNow()
        }
    }

    private fun slug(url: String) = url.substringAfter("/it/", url).trimEnd('/').lowercase()

    /** Unisce le biglietterie con orari (pagine singole) con quelle elencate nelle province (stato aggiornato, nome breve). */
    private fun mergeOffices(detailed: List<Seller>, listed: List<Seller>): List<Seller> {
        val bySlug = listed.filter { it.url.isNotBlank() }.associateBy { slug(it.url) }
        val merged = detailed.map { d ->
            val l = bySlug[slug(d.url)]
            if (l == null) d else d.copy(status = l.status.ifBlank { d.status }, province = d.province.ifBlank { l.province },
                assist = d.assist || l.assist, brand = if (l.assist) l.brand else d.brand)
        }
        val known = merged.map { slug(it.url) }.toSet()
        return merged + listed.filter { it.url.isBlank() || slug(it.url) !in known }
    }

    private fun normName(s: String) = s.lowercase()
        .replace("à", "a").replace("è", "e").replace("é", "e").replace("ì", "i").replace("ò", "o").replace("ù", "u")
        .replace(Regex("[^a-z0-9]+"), " ").trim()

    /**
     * Le emettitrici Trenord sono elencate per stazione, senza coordinate: le colleghiamo alla stazione con lo stesso nome
     * (elenco stazioni FerrovieNord e ViaggiaTreno). Anche le biglietterie senza pagina prendono la posizione della stazione.
     */
    fun withCoords(ctx: Context, items: List<Seller>): List<Seller> {
        if (items.all { it.located }) return items
        FnNetwork.ensure(ctx)
        val all = FnNetwork.stations + try { Api.allStations(ctx) } catch (e: Exception) { emptyList() }
        val lombardy = all.filter { inLombardy(it.lat, it.lon) || it.lat in 45.0..46.7 && it.lon in 8.4..11.5 }
        val index = lombardy.groupBy { normName(it.station.name) }
        fun find(name: String): Api.GeoStation? {
            val n = normName(name).removePrefix("stazione ").removePrefix("biglietteria ")
            if (n.isBlank()) return null
            index[n]?.firstOrNull()?.let { return it }
            val words = n.split(" ").filter { it.length > 1 }
            // Stessi nomi con parole in più o in meno (es. "Laveno Mombello Lago" / "Laveno Lago")
            return lombardy.filter { g ->
                val gw = normName(g.station.name).split(" ").filter { it.length > 1 }
                gw.isNotEmpty() && (gw.containsAll(words) || words.containsAll(gw)) && gw.first() == words.firstOrNull()
            }.minByOrNull { Math.abs(normName(it.station.name).length - n.length) }
        }
        return items.map { s ->
            if (s.located) s else find(s.nearStation.ifBlank { s.name })?.let { g -> s.copy(lat = g.lat, lon = g.lon) } ?: s
        }
    }

    /** Elenco Trenord della settimana (vuoto se non è mai stato scaricato). */
    fun cached(ctx: Context): List<Seller> = loadCache(ctx).second

    @Volatile private var triedMachines = false

    /** Elenco Trenord della settimana, scaricandolo se manca (file già pronto o sito Trenord). */
    fun ensureList(ctx: Context, onProgress: (String) -> Unit = {}): List<Seller> {
        val (at, items) = loadCache(ctx)
        if (items.isEmpty() || (!triedMachines && items.none { it.kind == OsmPlace.Kind.TICKET_MACHINE })) {
            triedMachines = true
            onProgress(I18n.tr("Scarico l'elenco dei punti vendita…", "Downloading the sales points list…"))
            val got = fetchPublished()?.second?.also { saveCache(ctx, it) }
            if (got != null && got.any { it.kind == OsmPlace.Kind.TICKET_MACHINE }) return got
            if (items.isEmpty()) return got ?: emptyList()
        } else if (System.currentTimeMillis() - at > WEEK) {
            Thread { try { refreshAll(ctx.applicationContext) } catch (_: Exception) { } }.start()
        }
        return items
    }

    /** Elenco delle province Trenord: chiave della pagina → nome da mostrare. */
    val provinceNames: List<Pair<String, String>> = PROVINCES.keys.map { k ->
        k to (if (k == "monza") "Monza e Brianza" else k.replaceFirstChar { it.uppercase() })
    }

    /**
     * Una provincia come sul sito Trenord: rilegge dal vivo la pagina (stato aperto/chiuso, emettitrici) e completa
     * le biglietterie con orari e indirizzo dall'elenco della settimana. Se il sito non risponde usa solo l'elenco.
     */
    fun province(ctx: Context, key: String): Pair<List<Seller>, Boolean> {
        val week = ensureList(ctx).filter { it.province == key }
        val live = try { parseProvinceAll(http("$BASE/it/punti-vendita-$key", 15000), key) } catch (e: Exception) { null }
        val items = if (live.isNullOrEmpty()) week else {
            val offices = mergeOffices(week.filter { it.kind == OsmPlace.Kind.TICKET_OFFICE }, live.filter { it.kind == OsmPlace.Kind.TICKET_OFFICE })
            val machines = live.filter { it.kind == OsmPlace.Kind.TICKET_MACHINE }.ifEmpty { week.filter { it.kind == OsmPlace.Kind.TICKET_MACHINE } }
            val resellers = live.filter { it.kind == OsmPlace.Kind.RESELLER }.ifEmpty { week.filter { it.kind == OsmPlace.Kind.RESELLER } }
            offices + machines + resellers
        }
        return withCoords(ctx, items) to !live.isNullOrEmpty()
    }

    private val refreshing = java.util.concurrent.atomic.AtomicBoolean(false)

    /**
     * Aggiorna l'elenco Trenord (ogni settimana in background e la prima volta che serve): prima il file già pronto,
     * poi, se non c'è, il sito Trenord. In caso di errore tiene i dati precedenti. Se un aggiornamento è già in corso
     * non lo ripete (prima l'app restava ferma su "Cerco i punti vendita" aspettando quello in background).
     */
    fun refreshAll(ctx: Context, onProgress: (String) -> Unit = {}): List<Seller> {
        val old = loadCache(ctx).second
        if (!refreshing.compareAndSet(false, true)) return old
        try {
            fetchPublished()?.let { (_, items) ->
                saveCache(ctx, items)
                return items
            }
            val got = downloadTrenord(onProgress = onProgress)
            // Se una parte non è arrivata, teniamo quella della settimana precedente
            val all = listOf(OsmPlace.Kind.RESELLER, OsmPlace.Kind.TICKET_OFFICE, OsmPlace.Kind.TICKET_MACHINE).flatMap { k ->
                got.filter { it.kind == k }.ifEmpty { old.filter { it.kind == k } }
            }
            if (all.isEmpty()) throw IOException("Sito Trenord non raggiungibile")
            saveCache(ctx, all)
            return all
        } finally {
            refreshing.set(false)
        }
    }

    /** Centro approssimativo di ogni provincia, per scaricare solo quelle vicine quando manca l'elenco completo. */
    private val PROVINCE_CENTER = mapOf(
        "bergamo" to (45.70 to 9.67), "brescia" to (45.54 to 10.22), "como" to (45.81 to 9.09), "cremona" to (45.13 to 10.02),
        "lecco" to (45.85 to 9.39), "lodi" to (45.31 to 9.50), "mantova" to (45.16 to 10.79), "milano" to (45.46 to 9.19),
        "monza" to (45.58 to 9.27), "pavia" to (45.19 to 9.16), "sondrio" to (46.17 to 9.87), "varese" to (45.82 to 8.83),
    )

    /** Provincia Trenord più vicina a un punto (null se fuori dalla Lombardia). */
    fun nearestProvince(lat: Double, lon: Double): String? = if (!inLombardy(lat, lon)) null
    else PROVINCE_CENTER.minByOrNull { (_, c) -> dist(lat, lon, c.first, c.second) }?.key

    private fun dist(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
        return (r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toInt()
    }

    /** Coordinate in Lombardia (riquadro approssimativo): solo lì servono gli elenchi Trenord. */
    fun inLombardy(lat: Double, lon: Double) = lat in 44.67..46.64 && lon in 8.49..11.43

    fun inSwitzerland(lat: Double, lon: Double) = lat in 45.82..47.81 && lon in 5.95..10.49 && !(lat < 46.15 && lon < 8.4)

    /**
     * Punti vendita Trenord entro [radius] metri: elenco della settimana, con lo stato aperto/chiuso aggiornato
     * rileggendo dal vivo solo le province che servono.
     */
    fun trenordNear(ctx: Context, lat: Double, lon: Double, radius: Int, live: Boolean = true, onProgress: (String) -> Unit = {}): List<Pair<Seller, Int>> {
        if (!inLombardy(lat, lon)) return emptyList()
        var (at, items) = loadCache(ctx)
        if (items.isEmpty()) {
            // Prima volta: il file già pronto; se non c'è, solo le province vicine (senza le pagine delle biglietterie)
            onProgress(I18n.tr("Scarico l'elenco delle rivendite…", "Downloading the sellers list…"))
            items = fetchPublished()?.second?.also { saveCache(ctx, it) } ?: run {
                val near = PROVINCE_CENTER.filter { (_, c) -> dist(lat, lon, c.first, c.second) < 45_000 }.keys.ifEmpty { setOf("milano") }
                downloadTrenord(near, offices = false, onProgress = onProgress)
            }
        } else if (System.currentTimeMillis() - at > WEEK) {
            // Elenco vecchio: lo usiamo subito e lo aggiorniamo in background
            Thread { try { refreshAll(ctx.applicationContext) } catch (_: Exception) { } }.start()
        }
        items = withCoords(ctx, items)
        var near = items.filter { it.located }.map { it to dist(lat, lon, it.lat, it.lon) }.filter { it.second <= radius }
        // Stato dal vivo: rileggo le pagine delle province coinvolte
        val provinces = near.map { it.first.province }.filter { it.isNotBlank() }.distinct()
        if (live && provinces.isNotEmpty()) {
            onProgress(I18n.tr("Controllo chi è aperto adesso…", "Checking who is open now…"))
            val live = HashMap<String, String>()
            provinces.forEach { p ->
                try {
                    parseProvinceAll(http("$BASE/it/punti-vendita-$p", 10000), p).forEach { s ->
                        if (s.kind == OsmPlace.Kind.TICKET_OFFICE) { if (s.url.isNotBlank()) live["u|" + slug(s.url)] = s.status }
                        else if (s.kind == OsmPlace.Kind.RESELLER) live["${s.name}|${s.lat}|${s.lon}"] = s.status
                    }
                } catch (_: Exception) {
                }
            }
            near = near.map { (s, d) ->
                val st = if (s.kind == OsmPlace.Kind.TICKET_OFFICE) live["u|" + slug(s.url)] else live["${s.name}|${s.lat}|${s.lon}"]
                (st?.takeIf { it.isNotBlank() }?.let { s.copy(status = it) } ?: s) to d
            }
        }
        return near.sortedBy { it.second }
    }

    /** Biglietterie automatiche FFS/SBB entro [radius] metri (dati aperti, aggiornati dalle FFS). */
    fun sbbMachines(lat: Double, lon: Double, radius: Int): List<Pair<Seller, Int>> {
        if (!inSwitzerland(lat, lon)) return emptyList()
        val where = java.net.URLEncoder.encode("within_distance(geopos, geom'POINT($lon $lat)', ${radius}m)", "UTF-8")
        val o = JSONObject(http("https://data.sbb.ch/api/explore/v2.1/catalog/datasets/billetautomat/records?limit=100&where=$where"))
        val a = o.optJSONArray("results") ?: return emptyList()
        return (0 until a.length()).mapNotNull { i ->
            val r = a.getJSONObject(i)
            val g = r.optJSONObject("geopos") ?: return@mapNotNull null
            val la = g.optDouble("lat"); val lo = g.optDouble("lon")
            val station = r.optString("bps_name")
            val owner = r.optString("eigentumer_gruppe").ifBlank { "SBB" }
            Seller("FFS/SBB", OsmPlace.Kind.TICKET_MACHINE, I18n.tr("Biglietteria automatica", "Ticket machine") + " $owner",
                la, lo, nearStation = station, url = SBB_DATA) to dist(lat, lon, la, lo)
        }.distinctBy { "${it.first.lat.toString().take(8)}|${it.first.lon.toString().take(7)}" }.sortedBy { it.second }
    }

    /** Converte nel formato usato dagli elenchi e dalla mappa dell'app. */
    fun toPlace(s: Seller, distance: Int): OsmPlace {
        val tags = HashMap<String, String>()
        tags["operator"] = s.source
        if (s.hours.isNotBlank()) tags["opening_hours"] = s.hours
        tags["x_source"] = s.source
        if (s.status.isNotBlank()) tags["x_status"] = s.status
        if (s.nearStation.isNotBlank()) tags["x_near"] = s.nearStation
        if (s.address.isNotBlank()) tags["x_address"] = s.address
        if (s.url.isNotBlank()) tags["x_url"] = s.url
        if (s.services.isNotBlank()) tags["x_services"] = s.services
        if (s.nearDist > 0) tags["x_near_dist"] = s.nearDist.toString()
        if (s.machines > 0) tags["x_machines"] = s.machines.toString()
        if (s.pay.isNotBlank()) tags["x_pay"] = s.pay
        if (s.province.isNotBlank()) tags["x_province"] = s.province
        if (s.brand.isNotBlank()) tags["x_brand"] = s.brand
        if (s.assist) tags["x_assist"] = "yes"
        tags["x_official"] = "yes"
        return OsmPlace(s.kind, s.name, s.lat, s.lon, distance, tags)
    }
}
