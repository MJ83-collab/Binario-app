package com.binario.treni.data

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Negozi e servizi delle grandi stazioni FFS letti dal sito sbb.ch (stessi dati della pagina "negozi" di ogni stazione):
 * nome, posizione in stazione, aperto/chiuso adesso e orari di apertura del periodo in corso.
 * Il sito ha una pagina servizi solo per 35 stazioni (elenco "Trova stazione", verificato il 25/10/2026).
 */
object SbbStations {
    data class Page(val uic: String, val slug: String, val itSlug: String, val names: List<String>)

    data class Service(
        val name: String,
        val location: String,
        val open: Boolean,
        /** Servizio FFS (biglietteria, bagagli, cambio, oggetti trovati…) invece di un negozio. */
        val sbb: Boolean,
        val category: String,
        val path: String,
    ) {
        val url: String get() = "https://www.sbb.ch$path"
    }

    private fun p(uic: String, slug: String, itSlug: String, vararg names: String) = Page(uic, slug, itSlug, names.toList())

    val PAGES = listOf(
        p("8505300", "bahnhof-lugano", "lugano", "Lugano"),
        p("8505213", "bahnhof-bellinzona", "bellinzona", "Bellinzona"),
        p("8505400", "bahnhof-locarno", "locarno", "Locarno"),
        p("8503000", "shopville-zuerich-hb", "zuerich-hb", "Zürich HB", "Zurich HB", "Zurigo Centrale", "Zurigo HB", "Zürich Hauptbahnhof"),
        p("8507000", "bahnhof-bern", "bern", "Bern", "Berna", "Berne"),
        p("8500010", "bahnhof-baselsbb", "basel-sbb", "Basel SBB", "Basilea FFS", "Bâle CFF", "Basel"),
        p("8501008", "bahnhof-genfcornavin", "geneve", "Genève", "Geneve", "Ginevra", "Genf", "Genève Cornavin"),
        p("8505000", "bahnhof-luzern", "luzern", "Luzern", "Lucerna", "Lucerne"),
        p("8502113", "bahnhof-aarau", "aarau", "Aarau"),
        p("8503504", "bahnhof-baden", "baden", "Baden"),
        p("8504300", "bahnhof-bielbienne", "biel-bienne", "Biel/Bienne", "Biel", "Bienne"),
        p("8501609", "bahnhof-brig", "brig", "Brig", "Briga", "Brigue"),
        p("8509000", "bahnhof-chur", "chur", "Chur", "Coira", "Coire"),
        p("8500109", "bahnhof-delemont", "delemont", "Delémont", "Delemont"),
        p("8504100", "bahnhof-fribourg", "fribourg-freiburg", "Fribourg/Freiburg", "Fribourg", "Freiburg", "Friburgo"),
        p("8501026", "bahnhof-geneve-aeroport", "geneve-aeroport", "Genève-Aéroport", "Genève Aéroport", "Ginevra Aeroporto", "Genf Flughafen"),
        p("8516273", "geneve-eaux-vives", "geneve-eaux-vives", "Genève-Eaux-Vives", "Genève Eaux-Vives"),
        p("8501120", "bahnhof-lausanne", "lausanne", "Lausanne", "Losanna"),
        p("8501300", "bahnhof-montreux", "montreux", "Montreux"),
        p("8504221", "bahnhof-neuchatel", "neuchatel", "Neuchâtel", "Neuchatel", "Neuenburg"),
        p("8500218", "bahnhof-olten", "olten", "Olten"),
        p("8503424", "bahnhof-schaffhausen", "schaffhausen", "Schaffhausen", "Sciaffusa", "Schaffhouse"),
        p("8501506", "bahnhof-sion", "sion", "Sion", "Sitten"),
        p("8500207", "bahnhof-solothurn", "solothurn", "Solothurn", "Soletta", "Soleure"),
        p("8506302", "bahnhof-stgallen", "st-gallen", "St. Gallen", "St Gallen", "San Gallo", "Saint-Gall"),
        p("8507100", "bahnhof-thun", "thun", "Thun", "Thoune"),
        p("8503125", "bahnhof-uster", "uster", "Uster"),
        p("8501605", "bahnhof-visp", "visp", "Visp", "Viège"),
        p("8506206", "bahnhof-wil", "wil-sg", "Wil", "Wil SG"),
        p("8506000", "bahnhof-winterthur", "winterthur", "Winterthur"),
        p("8504200", "bahnhof-yverdon-les-bains", "yverdon-les-bains", "Yverdon-les-Bains"),
        p("8502204", "bahnhof-zug", "zug", "Zug", "Zugo", "Zoug"),
        p("8503010", "bahnhof-zuerich-enge", "zuerich-enge", "Zürich Enge", "Zurigo Enge"),
        p("8503006", "bahnhof-zuerich-oerlikon", "zuerich-oerlikon", "Zürich Oerlikon", "Zurigo Oerlikon"),
        p("8503003", "bahnhof-zuerich-stadelhofen", "zuerich-stadelhofen", "Zürich Stadelhofen", "Zurigo Stadelhofen"),
    )

    private fun norm(s: String) = s.lowercase(Locale.ROOT)
        .replace(SwissLive.SUFFIX.lowercase(Locale.ROOT), "")
        .replace('ü', 'u').replace('ä', 'a').replace('ö', 'o').replace('é', 'e').replace('è', 'e').replace('â', 'a').replace('ê', 'e')
        .replace(Regex("[^a-z0-9]+"), " ").trim()

    /** Pagina servizi FFS della stazione (per id svizzero "CH85…" o per nome); null se il sito non ne ha una. */
    fun find(st: Station): Page? {
        val uic = st.id.removePrefix(SwissLive.PREFIX)
        PAGES.firstOrNull { it.uic == uic }?.let { return it }
        val n = norm(st.name)
        return PAGES.firstOrNull { p -> p.names.any { norm(it) == n } }
    }

    private fun lang() = when (I18n.lang) { "it", "de", "fr" -> I18n.lang; else -> "en" }

    fun pageUrl(p: Page) = "https://www.sbb.ch/it/informazioni-viaggio/stazioni/trova-stazione/stazione-di-${p.itSlug}.html"

    private fun get(url: String, untilHead: Boolean = false): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 20000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Binario")
            setRequestProperty("Accept-Language", lang())
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { r ->
                if (!untilHead) return r.readText()
                // Per gli orari basta l'intestazione della pagina (meta description): non scarichiamo il resto
                val sb = StringBuilder()
                while (true) {
                    val line = r.readLine() ?: break
                    sb.append(line).append('\n')
                    if (line.contains("</head>", true) || sb.length > 200_000) break
                }
                return sb.toString()
            }
        } finally {
            c.disconnect()
        }
    }

    private val cache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, List<Service>>>()

    /** Negozi e servizi della stazione con stato aperto/chiuso (aggiornato dal sito FFS, cache 5 minuti). */
    fun services(p: Page): List<Service> {
        val key = p.slug + "|" + lang()
        cache[key]?.let { (t, l) -> if (System.currentTimeMillis() - t < 5 * 60_000) return l }
        val url = "https://www.sbb.ch/content/internet/sbb/${lang()}/reiseinformationen/bahnhoefe/bahnhof-finden/${p.slug}/geschaefte/jcr:content/shopsfilter.results.json"
        val a = JSONObject(get(url)).optJSONArray("shops") ?: return emptyList()
        val out = (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val search = o.optJSONArray("searchTags")
            val tags = (0 until (search?.length() ?: 0)).map { search!!.optString(it) }
            Service(
                name = o.optString("name").trim(),
                location = o.optString("location").trim(),
                open = o.optBoolean("open"),
                sbb = tags.any { it == "sbb_services" },
                category = o.optJSONArray("filterTags")?.optString(0).orEmpty(),
                path = o.optString("link"),
            )
        }.filter { it.name.isNotBlank() }
        cache[key] = System.currentTimeMillis() to out
        return out
    }

    private val hoursCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    /**
     * Orari di apertura del periodo in corso, dal riassunto della pagina del servizio, ad es.
     * "… Aperto 365 giorni l’anno: 2026-10-01-2027-04-30, Lu-Ve 07:00-19:00, Sa-Do 08:00-18:00."
     */
    fun hours(s: Service): String {
        hoursCache[s.path]?.let { return it }
        val html = get(s.url, untilHead = true)
        val desc = Regex("<meta\\s+name=\"description\"\\s+content=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)
            ?: Regex("<meta\\s+content=\"([^\"]*)\"\\s+name=\"description\"", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)
            ?: return ""
        val text = desc.replace("&amp;", "&").replace("&#39;", "'").replace("&rsquo;", "’").replace("&quot;", "\"")
        val r = parseHours(text)
        hoursCache[s.path] = r
        return r
    }

    /** Estrae gli orari validi oggi dal testo (con o senza periodi datati). */
    fun parseHours(text: String, today: String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())): String {
        val body = text.substringAfter(": ", "").trim().trimEnd('.').trim()
        if (body.isBlank()) return ""
        val period = Regex("(\\d{4}-\\d{2}-\\d{2})-(\\d{4}-\\d{2}-\\d{2}),\\s*")
        val ms = period.findAll(body).toList()
        if (ms.isEmpty()) return body
        for ((i, m) in ms.withIndex()) {
            val end = if (i + 1 < ms.size) ms[i + 1].range.first else body.length
            val hours = body.substring(m.range.last + 1, end).trim().trimEnd(',').trim()
            if (today >= m.groupValues[1] && today <= m.groupValues[2]) return hours
        }
        return ""
    }
}
