package com.binario.treni.data

import android.content.Context
import android.os.Build
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Feedback e segnalazioni di bug degli utenti. Vengono inviati a un modulo Google dello sviluppatore, che li
 * inoltra alla sua email: l'indirizzo dello sviluppatore non compare mai nell'app. I dati del modulo (indirizzo
 * e nomi dei campi) stanno in un piccolo file pubblico su GitHub, così si possono cambiare senza una nuova versione.
 * Se manca la rete il messaggio resta sul telefono e parte da solo appena possibile.
 */
object Feedback {
    const val CONFIG_URL = "https://raw.githubusercontent.com/MJ83-collab/Binario-app/main/feedback.json"
    private const val PREFS = "binario"


    data class Config(
        val formUrl: String, val name: String, val email: String, val kind: String, val message: String, val tech: String,
        /** Campo del modulo con la chiave anti-bot (il modulo accetta solo risposte con la chiave giusta). */
        val key: String = "",
        /** Indirizzo di ripiego (facoltativo, dal file pubblico): non è mai mostrato, serve solo se l'invio al modulo non riesce. */
        val to: String = "",
    )

    /**
     * Chiave anti-bot: il modulo Google la richiede (convalida "contiene"), quindi chi prova a scrivere direttamente
     * al modulo senza passare dall'app viene rifiutato da Google. Non è nel file pubblico su GitHub.
     */
    const val FORM_KEY = "binario-7Kq2xW9m"

    // Limiti anti-spam lato app
    const val MAX_PER_DAY = 3
    const val MIN_GAP_MS = 3 * 60_000L
    const val MIN_TYPING_MS = 8_000L
    const val MAX_LEN = 4000

    enum class Block { OK, TOO_FAST, TOO_MANY, TOO_SOON, DUPLICATE, LINKS, NONSENSE, TOO_LONG }

    /**
     * Controlli anti-spam (logica pura, usata anche nei test): tempo di scrittura, quanti messaggi oggi,
     * pausa minima tra due invii, messaggio identico al precedente, troppi link, testo senza senso.
     */
    fun check(message: String, openedAt: Long, now: Long, sentTimes: List<Long>, lastHash: Int): Block {
        val t = message.trim()
        return when {
            now - openedAt < MIN_TYPING_MS -> Block.TOO_FAST
            sentTimes.count { now - it < 86_400_000L } >= MAX_PER_DAY -> Block.TOO_MANY
            sentTimes.any { now - it < MIN_GAP_MS } -> Block.TOO_SOON
            t.length > MAX_LEN -> Block.TOO_LONG
            norm(t).hashCode() == lastHash && lastHash != 0 -> Block.DUPLICATE
            Regex("""https?://|www\.""", RegexOption.IGNORE_CASE).findAll(t).count() > 2 -> Block.LINKS
            nonsense(t) -> Block.NONSENSE
            else -> Block.OK
        }
    }

    private fun norm(t: String) = t.lowercase().replace(Regex("\\s+"), " ").trim()

    /** "aaaaaaaaaaa", "asdasdasdasd" o solo simboli: niente lettere varie o sempre lo stesso carattere. */
    private fun nonsense(t: String): Boolean {
        val letters = t.filter { it.isLetter() }
        if (letters.length < 5) return true
        if (letters.lowercase().toSet().size < 4) return true
        return Regex("""(.)\1{9,}""").containsMatchIn(t)
    }

    fun blockText(b: Block): String = when (b) {
        Block.TOO_FAST -> I18n.tr("Prenditi qualche secondo per scrivere il messaggio.", "Take a few seconds to write the message.")
        Block.TOO_MANY -> I18n.tr("Hai già inviato $MAX_PER_DAY messaggi oggi: riprova domani. Grazie!", "You have already sent $MAX_PER_DAY messages today: try again tomorrow. Thanks!")
        Block.TOO_SOON -> I18n.tr("Hai appena inviato un messaggio: aspetta qualche minuto prima del prossimo.", "You just sent a message: wait a few minutes before the next one.")
        Block.DUPLICATE -> I18n.tr("Questo messaggio è già stato inviato.", "This message has already been sent.")
        Block.LINKS -> I18n.tr("Troppi link nel messaggio: al massimo 2.", "Too many links in the message: at most 2.")
        Block.NONSENSE -> I18n.tr("Il messaggio non sembra un testo: descrivi il problema o il suggerimento a parole.", "The message does not look like text: describe the problem or suggestion in words.")
        Block.TOO_LONG -> I18n.tr("Messaggio troppo lungo (massimo $MAX_LEN caratteri).", "Message too long (max $MAX_LEN characters).")
        Block.OK -> ""
    }

    private fun sentTimes(ctx: Context): List<Long> =
        (ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("feedback_sent", "") ?: "")
            .split(',').mapNotNull { it.toLongOrNull() }

    /** Controlla i limiti con lo storico salvato sul telefono. */
    fun check(ctx: Context, message: String, openedAt: Long): Block =
        check(message, openedAt, System.currentTimeMillis(), sentTimes(ctx),
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("feedback_last", 0))

    private fun markSent(ctx: Context, message: String) {
        val now = System.currentTimeMillis()
        val keep = (sentTimes(ctx).filter { now - it < 86_400_000L } + now).joinToString(",")
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("feedback_sent", keep).putInt("feedback_last", norm(message.trim()).hashCode()).apply()
    }

    data class Report(val name: String, val email: String, val kind: String, val message: String, val tech: String, val at: Long) {
        fun toJson(): JSONObject = JSONObject().put("n", name).put("e", email).put("k", kind).put("m", message).put("t", tech).put("a", at)

        companion object {
            fun from(o: JSONObject) = Report(o.optString("n"), o.optString("e"), o.optString("k"), o.optString("m"), o.optString("t"), o.optLong("a"))
        }
    }

    private val EMAIL = Regex("""^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$""")

    fun validEmail(e: String) = EMAIL.matches(e.trim())

    /** Accetta solo moduli Google e campi "entry.123": niente altri indirizzi. */
    fun parseConfig(json: String): Config? = try {
        val o = JSONObject(json)
        val url = o.optString("formUrl").trim()
        fun entry(k: String) = o.optString(k).trim().takeIf { it.startsWith("entry.") }.orEmpty()
        val (name, email, message) = Triple(entry("name"), entry("email"), entry("message"))
        if (!url.startsWith("https://docs.google.com/forms/") || !url.endsWith("/formResponse")) null
        else if (name.isEmpty() || email.isEmpty() || message.isEmpty()) null
        // "Tipo" e "Dati tecnici" sono facoltativi: se il modulo non li ha, finiscono dentro il messaggio
        else Config(url, name, email, entry("kind"), message, entry("tech"), entry("key"), o.optString("to").trim().takeIf { validEmail(it) }.orEmpty())
    } catch (e: Exception) {
        null
    }

    /** Corpo della richiesta al modulo Google (logica pura, usata anche nei test). */
    fun body(c: Config, r: Report): String {
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
        var msg = r.message.trim()
        if (c.kind.isBlank() && r.kind.isNotBlank()) msg = "[" + r.kind + "] " + msg
        if (c.tech.isBlank() && r.tech.isNotBlank()) msg += "\n\n— " + r.tech
        val parts = mutableListOf(c.name to r.name.trim(), c.email to r.email.trim(), c.message to msg)
        if (c.kind.isNotBlank()) parts += c.kind to r.kind
        if (c.tech.isNotBlank() && r.tech.isNotBlank()) parts += c.tech to r.tech
        if (c.key.isNotBlank()) parts += c.key to FORM_KEY
        return parts.joinToString("&") { (k, v) -> enc(k) + "=" + enc(v) }
    }

    fun techInfo(ctx: Context): String {
        val code = try {
            PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
        } catch (e: Exception) {
            0L
        }
        return "Binario ${versionName(ctx)} ($code) · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · " +
            "${Build.MANUFACTURER} ${Build.MODEL} · ${I18n.lang}"
    }

    private fun versionName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    private fun http(url: String, post: String? = null): Pair<Int, String> {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 15000
            setRequestProperty("User-Agent", "Binario-Android")
            if (post != null) {
                requestMethod = "POST"; doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            }
        }
        try {
            if (post != null) c.outputStream.use { it.write(post.toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            return code to text
        } finally {
            c.disconnect()
        }
    }

    private fun config(ctx: Context): Config? {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val cached = p.getString("feedback_cfg", null)
        val fresh = System.currentTimeMillis() - p.getLong("feedback_cfg_at", 0L) < 24 * 3600_000L
        if (cached != null && fresh) parseConfig(cached)?.let { return it }
        return try {
            val (code, text) = http(CONFIG_URL)
            if (code == 200 && parseConfig(text) != null) {
                p.edit().putString("feedback_cfg", text).putLong("feedback_cfg_at", System.currentTimeMillis()).apply()
                parseConfig(text)
            } else cached?.let { parseConfig(it) }
        } catch (e: Exception) {
            cached?.let { parseConfig(it) }
        }
    }

    /** Indirizzo email di ripiego dal file di configurazione (vuoto se assente); da chiamare fuori dal thread principale. */
    fun fallbackTo(ctx: Context): String = try { config(ctx)?.to.orEmpty() } catch (e: Exception) { "" }

    private fun sendNow(ctx: Context, r: Report): Boolean {
        val c = config(ctx) ?: throw IOException("config")
        val (code, _) = http(c.formUrl, body(c, r))
        return code in 200..299
    }

    /** Invia subito; se non riesce lo mette in coda. Restituisce true se è partito. */
    fun send(ctx: Context, r: Report): Boolean {
        val ok = try {
            sendNow(ctx, r)
        } catch (e: Exception) {
            false
        }
        if (!ok) enqueue(ctx, r)
        markSent(ctx, r.message)
        return ok
    }

    private fun queue(ctx: Context): MutableList<Report> = try {
        val a = JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("feedback_queue", "[]"))
        (0 until a.length()).map { Report.from(a.getJSONObject(it)) }.toMutableList()
    } catch (e: Exception) {
        mutableListOf()
    }

    private fun saveQueue(ctx: Context, l: List<Report>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("feedback_queue", JSONArray().apply { l.forEach { put(it.toJson()) } }.toString()).apply()
    }

    private fun enqueue(ctx: Context, r: Report) = saveQueue(ctx, (queue(ctx) + r).takeLast(10))

    fun pending(ctx: Context): Int = queue(ctx).size

    /** Prova a inviare i messaggi rimasti in coda (chiamato dal lavoro in background). */
    fun flush(ctx: Context) {
        val q = queue(ctx)
        if (q.isEmpty()) return
        val left = q.filterNot { r ->
            try {
                sendNow(ctx, r)
            } catch (e: Exception) {
                false
            }
        }
        // Dopo 30 giorni un messaggio non inviato si scarta
        saveQueue(ctx, left.filter { System.currentTimeMillis() - it.at < 30L * 86_400_000L })
    }

    // Nome ed email ricordati sul telefono, così non vanno riscritti
    fun lastName(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("feedback_name", "") ?: ""
    fun lastEmail(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("feedback_email", "") ?: ""
    fun remember(ctx: Context, name: String, email: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("feedback_name", name.trim()).putString("feedback_email", email.trim()).apply()
    }
}
