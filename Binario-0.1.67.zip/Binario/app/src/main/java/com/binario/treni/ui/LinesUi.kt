package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Station
import com.binario.treni.data.TrainAliases
import com.binario.treni.data.TrainLines
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Etichetta colorata della linea (colore ufficiale se la fonte lo indica). */
@Composable
private fun RailLineBadge(l: TrainLines.RailLine) {
    val bg = l.color?.let { Color(it) } ?: lineColor(l.code, l.operator)
    Box(
        Modifier.clip(RoundedCornerShape(5.dp)).background(bg).padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(l.code, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun RailLineRow(l: TrainLines.RailLine) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth()
            .then(if (l.url.isNotBlank()) Modifier.clickable { openUrl(ctx, l.url) } else Modifier)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RailLineBadge(l)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            if (l.label.isNotBlank()) Text(l.label, fontSize = 15.sp)
            Text(l.operator, color = Muted, fontSize = 12.sp)
        }
        if (l.url.isNotBlank()) Icon(Icons.Filled.OpenInNew, tx("Pagina della linea"), tint = Green, modifier = Modifier.size(20.dp))
    }
}

/**
 * Linea / direttrice del treno (es. Trenord S9 «Saronno – Seregno – Milano – Albairate»), con il link alla pagina ufficiale.
 * Non compare per i treni senza linea nell'orario (Frecce, Intercity, regionali Trenitalia) né per Italo.
 */
@Composable
fun TrainLineCard(st: TrainStatus) {
    val italo = st.originCode.startsWith(com.binario.treni.data.ItaloLive.PREFIX + "|")
    var line by remember(st.number, st.originCode) { mutableStateOf<TrainLines.RailLine?>(null) }
    LaunchedEffect(st.number, st.originCode) {
        if (italo) return@LaunchedEffect
        line = withContext(Dispatchers.IO) { runCatching { TrainLines.forTrain(st) }.getOrNull() }
    }
    val l = line ?: return
    WhiteCard {
        CardTitle(tx("Linea"))
        RailLineRow(l)
        if (l.url.isNotBlank()) Text(tx("Tocca per la pagina ufficiale della linea: fermate, orari e avvisi."),
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 10.dp))
    }
}

/** Linee e direttrici che passano dalla stazione (dalle partenze delle prossime ore). */
@Composable
fun StationLinesCard(station: Station) {
    var lines by remember(station.id) { mutableStateOf<List<TrainLines.RailLine>?>(null) }
    LaunchedEffect(station.id) {
        lines = withContext(Dispatchers.IO) { runCatching { TrainLines.forStation(station) }.getOrDefault(emptyList()) }
    }
    val l = lines
    if (l != null && l.isEmpty()) return
    WhiteCard {
        CardTitle(tx("Linee che passano da qui"))
        if (l == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), color = Green)
        } else {
            l.forEach { RailLineRow(it) }
            Text(tx("Dalle partenze delle prossime ore. Frecce, Intercity e regionali Trenitalia non hanno una linea negli orari ufficiali: sono indicati per categoria e tratta."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 10.dp))
        }
    }
}

/**
 * Doppia numerazione: alcuni treni Trenord cambiano numero passando da una rete all'altra (RFI ↔ FerrovieNord ↔ FFS).
 * Compare solo se l'orario ufficiale Trenord indica un secondo numero per la stessa corsa.
 */
@Composable
fun TrainAliasCard(st: TrainStatus) {
    val others = remember(st.number, st.originCode) { TrainAliases.othersFor(st) }
    if (others.isEmpty() && st.numberChanges.isEmpty()) return
    WhiteCard {
        CardTitle(tx("Doppia numerazione"))
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            st.numberChanges.forEach { (n, where) ->
                Text(
                    (if (where.isNotBlank()) tx("Dopo") + " " + where.trim().lowercase().split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } } + ": " else "") +
                        tx("il treno diventa") + " " + n,
                    fontWeight = FontWeight.Bold, fontSize = 15.sp,
                )
            }
            if (others.isEmpty()) {
                Text(tx("Dichiarato da ViaggiaTreno."), color = Muted, fontSize = 12.sp)
                return@Column
            }
            Text(
                tx("Questa corsa cambia numero quando passa da una rete all'altra (RFI, FerrovieNord, FFS)."),
                fontSize = 14.sp,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                com.binario.treni.data.Api.trainDigits(st.number) + others.joinToString("") { "/" + it.other },
                fontWeight = FontWeight.Bold, fontSize = 18.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                tx("Dagli orari ufficiali Trenord in vigore: ad ogni cambio orario i numeri possono cambiare."),
                color = Muted, fontSize = 12.sp,
            )
        }
    }
}

/** Avviso sull'orario di questo treno (es. allungamento a destino per lavori), dagli avvisi ufficiali dell'impresa. */
@Composable
fun TrainNoticeCard(st: TrainStatus) {
    val ctx = LocalContext.current
    val list = remember(st.number, st.originCode, st.depTime) { com.binario.treni.data.TrainNotices.forTrain(st) }
    if (list.isEmpty()) return
    fun d(s: String) = s.substring(8, 10).trimStart('0') + "/" + s.substring(5, 7).trimStart('0')
    WhiteCard {
        CardTitle(tx("Avviso sull'orario"))
        list.forEach { n ->
            Column(
                Modifier.fillMaxWidth().clickable { if (n.src.isNotBlank()) openUrl(ctx, n.src) }.padding(horizontal = 16.dp, vertical = 6.dp),
            ) {
                Text(
                    tx("Dal") + " " + d(n.from) + " " + tx("al") + " " + d(n.to) + ": " + tx("arrivo a destinazione con") + " +" + n.minutes + " " + tx("minuti"),
                    fontWeight = FontWeight.Bold, fontSize = 15.sp,
                )
                if (n.reason.isNotBlank()) Text(tx(n.reason), fontSize = 14.sp)
                if (n.note.isNotBlank()) Text(tx(n.note), color = Muted, fontSize = 12.sp)
                Text(n.operator + (if (n.src.isNotBlank()) " · " + tx("Tocca per la fonte") else ""), color = Muted, fontSize = 12.sp)
            }
        }
    }
}

/** Avvisi RFI sulle linee e sui treni preferiti: spariscono da soli a fine periodo. Il feed si legge una volta a settimana. */
@Composable
fun RfiNoticesCard(vm: MainViewModel) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(com.binario.treni.data.RfiNotices.active(ctx)) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            if (com.binario.treni.data.RfiNotices.due(ctx)) com.binario.treni.data.RfiNotices.refresh(ctx, vm.store.favLines(), vm.store.favTrains())
        }
        list = com.binario.treni.data.RfiNotices.active(ctx)
    }
    if (list.isEmpty()) return
    WhiteCard {
        CardTitle(tx("Avvisi sulle tue tratte"))
        list.forEach { n ->
            Column(Modifier.fillMaxWidth().clickable { openUrl(ctx, n.link) }.padding(horizontal = 16.dp, vertical = 6.dp)) {
                Text(n.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(tx("Fino al") + " " + n.to.substring(8, 10).trimStart('0') + "/" + n.to.substring(5, 7).trimStart('0') + " · RFI · " + tx("Tocca per la fonte"), color = Muted, fontSize = 12.sp)
            }
        }
    }
}

/** «Il tuo storico»: ritardo medio di questo treno nei giorni in cui l'hai aperto (dati solo sul telefono, almeno 2 giorni). */
@Composable
fun DelayHistoryCard(st: TrainStatus) {
    val ctx = LocalContext.current
    val list = remember(st.number, st.delay, st.arrived) { com.binario.treni.data.DelayHistory.forTrain(ctx, st) }
    if (list.size < 2) return
    val ran = list.filter { !it.cancelled }
    val avg = if (ran.isEmpty()) 0 else Math.round(ran.map { it.delay }.average()).toInt()
    val onTime = ran.count { it.delay <= 5 }
    val worst = ran.maxOfOrNull { it.delay } ?: 0
    val canc = list.count { it.cancelled }
    WhiteCard {
        CardTitle(tx("Il tuo storico su questo treno"))
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Text(tx("Ritardo medio") + ": " + (if (avg > 0) "+" else "") + avg + " min", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(tx("In orario (entro 5 min)") + ": " + onTime + " / " + ran.size + " · " + tx("Peggiore") + ": +" + worst + " min" +
                (if (canc > 0) " · " + tx("Soppresso") + ": " + canc else ""), fontSize = 14.sp)
            Text(tx("Giorni registrati") + ": " + list.size + " · " + tx("Dati solo sul tuo telefono."), color = Muted, fontSize = 12.sp)
        }
    }
}
