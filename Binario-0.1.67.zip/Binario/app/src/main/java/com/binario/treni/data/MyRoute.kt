package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/**
 * La tratta abituale per filtrare le notizie: stazioni, orario del treno di andata e/o ritorno, giorni,
 * imprese usate e regioni attraversate. Uno sciopero "riguarda la mia tratta" se è nazionale o in una mia regione,
 * se coinvolge una mia impresa (o tutte) e se il suo orario copre l'andata o il ritorno in un mio giorno di viaggio.
 */
data class MyRoute(
    val from: Station? = null,
    val to: Station? = null,
    /** "HH:mm" del treno di andata (vuoto = non lo uso). */
    val out: String = "",
    /** "HH:mm" del treno di ritorno (vuoto = non lo uso). */
    val back: String = "",
    /** Giorni Calendar (2 = lunedì … 1 = domenica). */
    val days: Set<Int> = setOf(2, 3, 4, 5, 6),
    val operators: Set<String> = setOf("Trenord", "Trenitalia"),
    val regions: Set<String> = setOf("Lombardia"),
    /** Minuti a piedi da casa alla stazione di partenza (per «Esci di casa»). */
    val walk: Int = 15,
    /** Avvisi sul mio viaggio: esci di casa, ultimo treno utile, coincidenza a rischio. */
    val alerts: Boolean = true,
) {
    val complete: Boolean get() = from != null && to != null && (out.isNotBlank() || back.isNotBlank())
    val label: String get() = listOfNotNull(from?.name, to?.name).joinToString(" ⇄ ")

    fun toJson(): JSONObject = JSONObject().apply {
        from?.let { put("from", it.toJson()) }
        to?.let { put("to", it.toJson()) }
        put("out", out); put("back", back)
        put("days", JSONArray(days.toList())); put("ops", JSONArray(operators.toList())); put("regions", JSONArray(regions.toList()))
        put("walk", walk); put("alerts", alerts)
    }

    companion object {
        fun from(o: JSONObject): MyRoute {
            fun set(a: JSONArray?) = if (a == null) null else (0 until a.length()).map { a.get(it).toString() }.toSet()
            return MyRoute(
                o.optJSONObject("from")?.let { Station.from(it) }, o.optJSONObject("to")?.let { Station.from(it) },
                o.optString("out"), o.optString("back"),
                set(o.optJSONArray("days"))?.mapNotNull { it.toIntOrNull() }?.toSet() ?: setOf(2, 3, 4, 5, 6),
                set(o.optJSONArray("ops")) ?: setOf("Trenord", "Trenitalia"),
                set(o.optJSONArray("regions")) ?: setOf("Lombardia"),
                o.optInt("walk", 15), o.optBoolean("alerts", true),
            )
        }
    }
}

object RouteNews {
    val REGIONS = listOf(
        "Abruzzo", "Basilicata", "Calabria", "Campania", "Emilia-Romagna", "Friuli-Venezia Giulia", "Lazio", "Liguria",
        "Lombardia", "Marche", "Molise", "Piemonte", "Puglia", "Sardegna", "Sicilia", "Toscana", "Trentino-Alto Adige",
        "Umbria", "Valle d'Aosta", "Veneto",
    )
    val OPERATORS = listOf("Trenord", "Trenitalia", "Italo", "TILO", "FerrovieNord", "Trenitalia Tper", "SAD", "Arenaways")

    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")

    fun normRegion(s: String): String = s.lowercase().replace(Regex("[^a-z]"), "")

    /** Lo sciopero tocca la regione (nazionale = tutte; "Emilia-Romagna" = "EMILIA ROMAGNA"). */
    fun inRegion(st: Strike, regions: Set<String>): Boolean {
        val r = normRegion(st.region)
        val mine = regions.map { normRegion(it) }.filter { it.isNotBlank() }.toSet()
        // Se lo sciopero indica le regioni (anche quando è etichettato "nazionale", es. sciopero generale in Toscana),
        // conta la regione indicata: gli scioperi di un'altra regione non compaiono.
        val named = REGIONS.map { normRegion(it) }.filter { r.contains(it) }
        if (named.isNotEmpty()) return named.any { it in mine }
        if (r.contains("tutte") || r.contains("nazional") || r.contains("italia") || r.isBlank()) return st.relevance.contains("nazional", true) || r.isBlank()
        return st.relevance.contains("nazional", true) || mine.any { n -> r.contains(n) || n.contains(r) }
    }

    /**
     * Lo sciopero riguarda una delle mie imprese? Se l'impresa non è indicata o è generica (RFI, gruppo FS,
     * "ferroviario", "tutte"), riguarda tutti.
     */
    fun forOperators(st: Strike, ops: Set<String>): Boolean {
        val c = (st.company + " " + st.note).uppercase()
        val named = mapOf(
            "Trenord" to listOf("TRENORD"), "Trenitalia" to listOf("TRENITALIA"), "Italo" to listOf("ITALO", "NTV"),
            "TILO" to listOf("TILO"), "FerrovieNord" to listOf("FERROVIENORD", "FERROVIE NORD", "FNM"),
            "Trenitalia Tper" to listOf("TPER"), "SAD" to listOf("SAD "), "Arenaways" to listOf("ARENAWAYS"),
        )
        val mentioned = named.filterValues { keys -> keys.any { c.contains(it) } }.keys
        // Personale RFI, gruppo FS o sciopero generale: tocca tutti i treni
        val everyone = mentioned.isEmpty() || c.contains("RFI") || c.contains("RETE FERROVIARIA") || c.contains("GRUPPO FS") ||
            c.contains("FERROVIE DELLO STATO") || st.sector.contains("generale", true)
        return everyone || mentioned.any { it in ops }
    }

    /** Inizio e fine dello sciopero in ms (ora di Roma), letti da data e modalità ("DALLE 21.00 DEL 28/10 ALLE 21.00 DEL 29/10"). */
    fun window(st: Strike): Pair<Long, Long>? {
        val d0 = Sources.parseItDate(st.start).takeIf { it > 0 } ?: return null
        val d1 = Sources.parseItDate(st.end).takeIf { it > 0 } ?: d0
        val year = Calendar.getInstance(rome).apply { timeInMillis = d0 }.get(Calendar.YEAR)
        val m = st.modality.uppercase().replace("ORE ", "")
        fun at(time: String?, date: String?, base: Long): Long {
            val c = Calendar.getInstance(rome).apply { timeInMillis = base }
            if (date != null) {
                val p = date.split("/")
                c.set(Calendar.DAY_OF_MONTH, p[0].toInt()); c.set(Calendar.MONTH, p[1].toInt() - 1)
                c.set(Calendar.YEAR, p.getOrNull(2)?.toIntOrNull()?.let { if (it < 100) 2000 + it else it } ?: year)
            }
            if (time != null) {
                val t = time.split('.', ':')
                c.set(Calendar.HOUR_OF_DAY, t[0].toInt()); c.set(Calendar.MINUTE, t.getOrNull(1)?.toIntOrNull() ?: 0)
            }
            return c.timeInMillis
        }
        val rx = Regex("DALLE\\s+(\\d{1,2}[.:]\\d{2})(?:\\s+DEL\\s+(\\d{1,2}/\\d{1,2}(?:/\\d{2,4})?))?.*?ALLE\\s+(\\d{1,2}[.:]\\d{2})(?:\\s+DEL\\s+(\\d{1,2}/\\d{1,2}(?:/\\d{2,4})?))?")
        val hit = rx.find(m)
        if (hit != null) {
            val (t1, dd1, t2, dd2) = hit.destructured
            var a = at(t1, dd1.ifBlank { null }, d0)
            var b = at(t2, dd2.ifBlank { null }, if (dd2.isBlank()) (if (dd1.isBlank()) d1 else a) else d0)
            // "ALLE 24.00" o fine prima dell'inizio: finisce il giorno dopo
            if (b <= a) b += 86_400_000L
            if (a < d0 - 86_400_000L) a = d0
            return a to b
        }
        // "INTERA GIORNATA" o niente orari: dalle 0 del primo giorno alle 24 dell'ultimo
        return d0 to (d1 + 86_400_000L)
    }

    data class Trip(val time: Long, val outbound: Boolean, val guaranteed: Boolean)

    /** I miei treni (andata/ritorno nei miei giorni) che partono durante lo sciopero. */
    fun affectedTrips(st: Strike, r: MyRoute): List<Trip> {
        val (a, b) = window(st) ?: return emptyList()
        val out = mutableListOf<Trip>()
        var day = Fmt.midnight(a)
        while (day < b) {
            val c = Calendar.getInstance(rome).apply { timeInMillis = day }
            val dow = c.get(Calendar.DAY_OF_WEEK)
            if (dow in r.days) {
                listOf(r.out to true, r.back to false).forEach { (hhmm, isOut) ->
                    val mm = Regex("^(\\d{1,2})[:.](\\d{2})").find(hhmm.trim()) ?: return@forEach
                    val t = Calendar.getInstance(rome).apply {
                        timeInMillis = day
                        set(Calendar.HOUR_OF_DAY, mm.groupValues[1].toInt()); set(Calendar.MINUTE, mm.groupValues[2].toInt())
                    }.timeInMillis
                    if (t in a until b) out += Trip(t, isOut, guaranteedSlot(t))
                }
            }
            day += 86_400_000L
            // cambio dell'ora: riallinea alla mezzanotte
            day = Fmt.midnight(day + 3 * 3_600_000L)
        }
        return out
    }

    /** Fasce di garanzia del trasporto regionale nei giorni feriali: 6–9 e 18–21. */
    fun guaranteedSlot(t: Long): Boolean {
        val c = Calendar.getInstance(rome).apply { timeInMillis = t }
        val dow = c.get(Calendar.DAY_OF_WEEK)
        if (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY) return false
        val min = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return min in 360 until 540 || min in 1080 until 1260
    }

    /** Lo sciopero riguarda la mia tratta: regione + impresa + orario dei miei treni. */
    fun affectsRoute(st: Strike, r: MyRoute): Boolean =
        inRegion(st, r.regions) && forOperators(st, r.operators) && affectedTrips(st, r).isNotEmpty()

    /** Parole per riconoscere la tratta negli avvisi delle aziende: città di partenza e arrivo (senza "Nord", "Centrale"…). */
    fun keywords(r: MyRoute): List<String> {
        val stop = setOf("NORD", "CENTRALE", "C.LE", "PORTA", "SAN", "SANTA", "STAZIONE", "FS", "FN", "LAGO", "BORGHI", "CADORNA", "GARIBALDI")
        return listOfNotNull(r.from?.name, r.to?.name).flatMap { n ->
            val w = n.uppercase().replace(Regex("\\(.*?\\)"), "").split(Regex("[\\s\\-]+")).filter { it.length >= 4 && it !in stop }
            listOfNotNull(w.firstOrNull())
        }.distinct()
    }

    /** Città (capoluoghi e nodi ferroviari) per riconoscere la regione di un avviso che non la nomina. */
    private val CITY_REGION: Map<String, String> = buildMap {
        fun r(region: String, vararg cities: String) = cities.forEach { put(it.uppercase(), region) }
        r("Lombardia", "Milano", "Bergamo", "Brescia", "Como", "Cremona", "Lecco", "Lodi", "Mantova", "Monza", "Pavia", "Sondrio", "Varese",
            "Malpensa", "Saronno", "Gallarate", "Treviglio", "Rho", "Seregno", "Codogno", "Voghera", "Luino", "Chiasso", "Busto Arsizio",
            "Legnano", "Desenzano", "Tirano", "Colico", "Novate", "Garbagnate", "Mortara", "Stradella")
        r("Piemonte", "Torino", "Alessandria", "Asti", "Biella", "Cuneo", "Novara", "Verbania", "Vercelli", "Domodossola", "Arona", "Bardonecchia")
        r("Valle d'Aosta", "Aosta")
        r("Liguria", "Genova", "Savona", "La Spezia", "Imperia", "Ventimiglia", "Sanremo", "Chiavari", "Sestri Levante")
        r("Veneto", "Venezia", "Mestre", "Verona", "Padova", "Vicenza", "Treviso", "Rovigo", "Belluno", "Peschiera")
        r("Trentino-Alto Adige", "Trento", "Bolzano", "Merano", "Rovereto", "Brennero")
        r("Friuli-Venezia Giulia", "Trieste", "Udine", "Pordenone", "Gorizia", "Tarvisio")
        r("Emilia-Romagna", "Bologna", "Modena", "Parma", "Piacenza", "Reggio Emilia", "Ferrara", "Ravenna", "Rimini", "Forlì", "Cesena", "Fidenza")
        r("Toscana", "Firenze", "Pisa", "Livorno", "Lucca", "Pistoia", "Siena", "Arezzo", "Grosseto", "Viareggio")
        r("Umbria", "Perugia", "Terni", "Foligno", "Orvieto")
        r("Marche", "Ancona", "Pesaro", "Macerata", "Ascoli Piceno")
        r("Lazio", "Roma", "Latina", "Frosinone", "Viterbo", "Rieti", "Civitavecchia", "Fiumicino", "Cassino")
        r("Abruzzo", "L'Aquila", "Pescara", "Chieti", "Teramo", "Sulmona")
        r("Molise", "Campobasso", "Isernia", "Termoli")
        r("Campania", "Napoli", "Salerno", "Caserta", "Avellino", "Benevento")
        r("Puglia", "Bari", "Foggia", "Lecce", "Taranto", "Brindisi", "Barletta")
        r("Basilicata", "Potenza", "Matera", "Metaponto")
        r("Calabria", "Reggio Calabria", "Catanzaro", "Cosenza", "Crotone", "Lamezia", "Villa San Giovanni")
        r("Sicilia", "Palermo", "Catania", "Messina", "Siracusa", "Trapani", "Agrigento", "Ragusa", "Caltanissetta")
        r("Sardegna", "Cagliari", "Sassari", "Olbia", "Oristano", "Nuoro")
    }

    /** Nomi con cui le regioni compaiono negli avvisi. */
    private val REGION_WORDS: Map<String, List<String>> = REGIONS.associateWith { g ->
        when (g) {
            "Emilia-Romagna" -> listOf("EMILIA-ROMAGNA", "EMILIA ROMAGNA")
            "Friuli-Venezia Giulia" -> listOf("FRIULI")
            "Trentino-Alto Adige" -> listOf("TRENTINO", "ALTO ADIGE", "SÜDTIROL")
            "Valle d'Aosta" -> listOf("VALLE D'AOSTA", "VALLE D’AOSTA", "VAL D'AOSTA")
            else -> listOf(g.uppercase())
        }
    }

    private val NATIONAL = Regex("NAZIONAL|INTERO TERRITORIO|TUTTA ITALIA|TUTTO IL TERRITORIO|TUTTE LE REGIONI")

    private fun word(text: String, w: String) = Regex("(?<![\\p{L}])" + Regex.escape(w) + "(?![\\p{L}])").containsMatchIn(text)

    /** Regioni toccate da un avviso: dalla fonte (Trenord, FerrovieNord, TILO, "Trenitalia · Lazio"), dai nomi di regione e dalle città. */
    fun noticeRegions(n: Notice): Set<String> {
        val out = mutableSetOf<String>()
        val src = n.source.uppercase()
        if (src.startsWith("TRENORD") || src.startsWith("FERROVIENORD") || src.startsWith("TILO")) out += "Lombardia"
        // Prima le regioni nominate nel titolo/fonte («Infolavori Liguria»): le città citate nel testo (es. Milano per la
        // Milano–Genova) non devono far comparire l'avviso in un'altra regione. Poi quelle nel testo, infine le città.
        val head = (n.source + " " + n.title).uppercase()
        val body = (n.title + " " + n.text).uppercase()
        REGION_WORDS.forEach { (g, words) -> if (words.any { word(head, it) }) out += g }
        if (out.isNotEmpty() && !(src.startsWith("TRENORD") || src.startsWith("FERROVIENORD") || src.startsWith("TILO"))) return out
        if (out.isEmpty()) REGION_WORDS.forEach { (g, words) -> if (words.any { word(body, it) }) out += g }
        if (out.isEmpty()) CITY_REGION.forEach { (city, g) -> if (word(body, city)) out += g }
        return out
    }

    /** L'avviso riguarda una delle mie regioni (o tutta Italia). Senza indicazioni di luogo non è mostrato. */
    fun noticeInRegion(n: Notice, regions: Set<String>): Boolean {
        if (NATIONAL.containsMatchIn((n.title + " " + n.text).uppercase())) return true
        val mine = regions.map { normRegion(it) }.toSet()
        return noticeRegions(n).any { normRegion(it) in mine }
    }

    fun noticeForRoute(n: Notice, r: MyRoute): Boolean {
        val text = (n.title + " " + n.text).uppercase()
        // Devono comparire entrambi i capolinea della mia tratta (un solo nome, es. Milano, farebbe passare avvisi di altre linee)
        val kw = keywords(r)
        if (kw.isEmpty()) return false
        return kw.all { k -> Regex("\\b" + Regex.escape(k) + "\\b").containsMatchIn(text) }
    }

    /** Tratta salvata; altrimenti quella di "Quanto sei green" o il treno abituale più usato. */
    fun defaultRoute(store: Store, ctx: android.content.Context): MyRoute {
        store.myRoute()?.let { return it }
        GreenCalc.profile(ctx)?.let { g -> return MyRoute(g.from, g.to, g.trainOut, g.trainBack, g.days) }
        store.habits().maxByOrNull { it.days.sum() }?.let { h ->
            val days = h.days.mapIndexedNotNull { i, n -> if (n > 0) (if (i == 6) Calendar.SUNDAY else i + 2) else null }.toSet()
            return MyRoute(h.board, h.alight, h.timeText, "", days.ifEmpty { setOf(2, 3, 4, 5, 6) })
        }
        return MyRoute()
    }

    fun describe(t: Trip): String {
        val c = Calendar.getInstance(rome).apply { timeInMillis = t.time }
        return I18n.tr(if (t.outbound) "Andata" else "Ritorno", if (t.outbound) "Outbound" else "Return") + " " +
            "%02d/%02d".format(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1) + " " + Fmt.time(t.time) +
            if (t.guaranteed) I18n.tr(" · fascia garantita 6–9 / 18–21", " · guaranteed band 6–9 / 18–21") else ""
    }
}
