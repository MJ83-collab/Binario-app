package com.binario.treni.service

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.binario.treni.MainActivity
import com.binario.treni.R
import com.binario.treni.data.Api
import com.binario.treni.data.Sources
import com.binario.treni.data.Fmt
import com.binario.treni.data.Reminder
import com.binario.treni.data.Store
import com.binario.treni.data.TrainRef
import com.binario.treni.data.delayText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Notif {
    const val CH_TRACK = "tracking"
    const val CH_REMIND = "reminders"
    const val CH_NEWS = "news"
    const val CH_WAKE = "wake"
    const val CH_ALERT = "alerts"
    const val CH_WATCH = "watch"
    /** Canale nuovo ("updates2", importanza alta: compare con un popup): quello vecchio ("updates") era silenzioso e non si può cambiare dopo la creazione. */
    const val CH_UPDATE = "updates2"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_TRACK, com.binario.treni.data.I18n.tr("Treno seguito", "Followed train"), NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_REMIND, com.binario.treni.data.I18n.tr("Promemoria partenza e arrivo", "Departure and arrival reminders"), NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
        })
        nm.createNotificationChannel(NotificationChannel(CH_NEWS, com.binario.treni.data.I18n.tr("Scioperi e news", "Strikes and news"), NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, com.binario.treni.data.I18n.tr("Interruzioni su tratte e linee preferite", "Disruptions on favourite routes and lines"), NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
        })
        // Stato del treno per orologi e fasce: notifica normale, senza suono sul telefono, così viene inoltrata
        nm.createNotificationChannel(NotificationChannel(CH_WATCH, com.binario.treni.data.I18n.tr("Stato sull'orologio", "Watch status"), NotificationManager.IMPORTANCE_DEFAULT).apply {
            setSound(null, null)
            enableVibration(false)
        })
        nm.deleteNotificationChannel("updates")
        nm.createNotificationChannel(NotificationChannel(CH_UPDATE, com.binario.treni.data.I18n.tr("Aggiornamenti dell'app", "App updates"), NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, com.binario.treni.data.I18n.tr("Sveglia fermata", "Stop alarm"), NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 800, 400, 800, 400, 800, 400, 800)
            setSound(
                android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM),
                android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
        })
    }

    fun canPost(ctx: Context): Boolean = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Apre l'app, eventualmente sulla scheda di un treno. */
    fun openApp(ctx: Context, ref: TrainRef? = null, req: Int = 0, screen: String? = null): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (ref != null) i.putExtra(MainActivity.EXTRA_TRAIN, ref.toJson().toString())
        if (screen != null) i.putExtra(MainActivity.EXTRA_SCREEN, screen)
        return PendingIntent.getActivity(ctx, req, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun post(ctx: Context, id: Int, channel: String, title: String, text: String, tap: PendingIntent, vararg actions: NotificationCompat.Action) {
        if (!canPost(ctx)) return
        val b = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_train)
            .setContentTitle(title)
            .setContentText(text.lineSequence().firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(tap)
            .setAutoCancel(true)
            .setColor(com.binario.treni.data.ColorBlind.brand.toInt())
            // Orologi e fasce (Wear OS, Mi Band…): la notifica viene inoltrata al polso, con le azioni
            .setLocalOnly(false)
            .setPriority(if (channel == CH_NEWS || channel == CH_WATCH) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_HIGH)
            .extend(NotificationCompat.WearableExtender())
        actions.forEach { b.addAction(it) }
        ctx.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}

/**
 * Avvisi accessibili per persone sorde o ipoudenti: vibrazione forte con uno schema
 * riconoscibile per ogni tipo di avviso, più il lampeggio del flash.
 */
object Haptic {
    enum class Kind(val pattern: LongArray) {
        /** Sveglia fermata: tre impulsi lunghissimi, ripetuti. */
        WAKE(longArrayOf(0, 1500, 500, 1500, 500, 1500, 1000, 1500, 500, 1500, 500, 1500)),
        /** Promemoria partenza/arrivo: tre impulsi brevi, due volte. */
        REMINDER(longArrayOf(0, 300, 200, 300, 200, 300, 800, 300, 200, 300, 200, 300)),
        /** Interruzione o soppressione: due impulsi lunghi. */
        ALERT(longArrayOf(0, 1000, 400, 1000)),
        /** Sciopero/news: un impulso medio. */
        NEWS(longArrayOf(0, 600)),
    }

    fun alert(ctx: Context, kind: Kind, spoken: String? = null) {
        val store = Store(ctx)
        // Non vedenti: suono distinto + voce
        if (spoken != null && store.blindMode) {
            Speech.say(ctx, spoken, when (kind) {
                Kind.WAKE -> Speech.Sound.IMMINENT
                Kind.REMINDER -> Speech.Sound.DEPART
                Kind.ALERT -> Speech.Sound.ALERT
                Kind.NEWS -> Speech.Sound.INFO
            }, times = if (kind == Kind.WAKE) 2 else 1, essential = kind == Kind.WAKE)
        }
        if (!store.deafMode) return
        try {
            val v = ctx.getSystemService(android.os.Vibrator::class.java)
            val amps = IntArray(kind.pattern.size) { i -> if (i % 2 == 1) 255 else 0 }
            if (v != null && v.hasVibrator()) {
                v.vibrate(android.os.VibrationEffect.createWaveform(kind.pattern, amps, -1))
            }
        } catch (_: Exception) {
        }
        if (store.flashAlerts && kind != Kind.NEWS) flash(ctx, if (kind == Kind.WAKE) 10 else 4)
    }

    /** Lampeggia la torcia [times] volte (non serve il permesso fotocamera). */
    private fun flash(ctx: Context, times: Int) {
        Thread {
            try {
                val cm = ctx.getSystemService(android.hardware.camera2.CameraManager::class.java) ?: return@Thread
                val id = cm.cameraIdList.firstOrNull { cid ->
                    cm.getCameraCharacteristics(cid).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: return@Thread
                repeat(times) {
                    cm.setTorchMode(id, true); Thread.sleep(250)
                    cm.setTorchMode(id, false); Thread.sleep(250)
                }
            } catch (_: Exception) {
            }
        }.start()
    }
}

/** Notifica fissa con lo stato del treno aggiornato ogni minuto. */
class TrackingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val store = Store(this)
        if (intent?.action == ACTION_STOP) {
            store.setTracked(null)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        intent?.getStringExtra(EXTRA_REF)?.let {
            try {
                store.setTracked(TrainRef.from(JSONObject(it)))
            } catch (_: Exception) {
            }
        }
        val ref = store.tracked()
        if (ref == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val resumed = intent?.getBooleanExtra(EXTRA_RESUMED, false) == true
        if (resumed) getSystemService(NotificationManager::class.java).cancel(ID + 6)
        val first = build(ref, ref.label, com.binario.treni.data.I18n.tr("Aggiornamento in corso…", "Updating…"))
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(ID, first)
        }
        job?.cancel()
        // Nuovo treno seguito: si riparte con gli annunci da capo
        if (announcedFor != ref.key) {
            announcedFor = ref.key
            announcedIntro = false; knownPlatforms.clear(); lastDelay = null; lastNextStop = null
            saidDepartSoon = false; saidPreWake = false; saidCancelled = false; seenRunning = false
        }
        job = scope.launch {
            val nm = getSystemService(NotificationManager::class.java)
            while (isActive) {
                var wait = 60_000L
                try {
                    val st = Api.status(ref)
                    val wake = store.wakeTarget()
                    val title = "${st.title} · ${st.origin} → ${st.destination}"
                    val board = store.boardingStation()?.let { b -> st.stops.firstOrNull { it.id == b.id || it.name.equals(b.name, true) } }
                    val boardLine = if (board != null && !board.passed) {
                        val p = board.realPlatform.ifBlank { board.schedPlatform }
                        "\n🚉 " + com.binario.treni.data.I18n.tr("Sali a ", "Board at ") + board.name + com.binario.treni.data.I18n.tr(" alle ", " at ") +
                            Fmt.time((if (board.schedDep > 0) board.schedDep else board.schedArr) + st.delay * 60_000L) +
                            (if (p.isNotBlank()) com.binario.treni.data.I18n.tr(" · binario ", " · platform ") + p else "")
                    } else ""
                    val extra = boardLine + (if (wake != null) "\n⏰ " + com.binario.treni.data.I18n.tr("Sveglia prima di ", "Alarm before ") + wake.name else "")
                    // Come le app di viaggio: pallino colorato con il ritardo e barra di avanzamento del viaggio
                    val target = wake?.let { w -> st.stops.firstOrNull { it.id == w.id || it.name.equals(w.name, true) } }
                    nm.notify(ID, build(st.ref, title, st.summary() + extra, st.shareText(), progressOf(st, board, target), statusLine(st)))
                    try { announce(st, wake) } catch (_: Exception) { }
                    if (wake != null && !store.wakeFired) checkWake(st, wake)
                    // Dopo il viaggio: riepilogo dell'arrivo e fine dell'inseguimento (solo se il treno è stato visto in viaggio)
                    if (!st.arrived && !st.cancelled) seenRunning = true
                    // Ripreso dopo un riavvio ma il viaggio era già finito: smette senza disturbare
                    if (resumed && !seenRunning && (st.arrived || st.cancelled)) {
                        store.setTracked(null)
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                        break
                    }
                    if (seenRunning && arrivalDone(st, wake)) {
                        store.setTracked(null)
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                        break
                    }
                    val dep = (board?.let { if (it.schedDep > 0) it.schedDep else it.schedArr } ?: st.depTime) + st.delay * 60_000L
                    if (st.arrived || st.cancelled) wait = 15 * 60_000L // dopo l'arrivo rallenta
                    else if (wake != null && !store.wakeFired) wait = 30_000L // più frequente vicino alla fermata
                    else if (dep - System.currentTimeMillis() in 0..20 * 60_000L) wait = 30_000L // poco prima di salire: più aggiornamenti
                } catch (e: Exception) {
                    nm.notify(ID, build(ref, ref.label, com.binario.treni.data.I18n.tr("Dati momentaneamente non disponibili", "Data temporarily unavailable")))
                }
                delay(wait)
            }
        }
        return START_STICKY
    }

    // ---- Annunci (voce per non vedenti, notifiche di cambio binario/ritardo per tutti) ----
    private var announcedFor: String? = null
    private var announcedIntro = false
    private val knownPlatforms = HashMap<String, String>()
    private var lastDelay: Int? = null
    private var lastNextStop: String? = null
    private var saidDepartSoon = false
    private var saidPreWake = false
    private var saidCancelled = false
    private var seenRunning = false

    /**
     * Il viaggio è finito: il treno è arrivato al capolinea oppure ha lasciato la fermata dove scendo.
     * Manda il riepilogo ("Il mio Capotreno": prima, durante e dopo il viaggio) e restituisce true.
     */
    private fun arrivalDone(st: com.binario.treni.data.TrainStatus, wake: com.binario.treni.data.Station?): Boolean {
        val en = com.binario.treni.data.I18n.en
        fun t(itText: String, enText: String) = com.binario.treni.data.I18n.tr(itText, enText)
        val target = wake?.let { w -> st.stops.firstOrNull { it.id == w.id || it.name.equals(w.name, true) } }
        val stop = when {
            target != null && target.realDep > 0 -> target
            st.arrived -> st.stops.lastOrNull()
            else -> null
        } ?: return false
        val delay = stop.delay.coerceAtLeast(0)
        val at = if (stop.realArr > 0) stop.realArr else stop.realDep
        val text = StringBuilder(
            t("Arrivato a ${stop.name}", "Arrived at ${stop.name}") + (if (at > 0) t(" alle ${Fmt.time(at)}", " at ${Fmt.time(at)}") else "") +
                if (delay > 0) t(" con $delay minuti di ritardo.", ", $delay minutes late.") else t(" in orario.", " on time."),
        )
        if (delay >= 60) text.append(t("\nCon 60 minuti o più di ritardo puoi chiedere l'indennizzo: trovi come in Altro › Condizioni, diritti e rimborsi.",
            "\nWith a delay of 60 minutes or more you can claim compensation: see More › Conditions, rights and refunds."))
        else if (delay >= 15) text.append(t("\nSe hai un abbonamento, i ritardi contano per il bonus mensile (Trenord) o l'indennizzo.",
            "\nIf you have a season ticket, delays count towards the monthly bonus (Trenord) or compensation."))
        text.append(t("\nSmetto di seguire il treno. Buona giornata!", "\nI've stopped following the train. Have a good day!"))
        Notif.post(this, ID + 5, Notif.CH_ALERT, "🏁 ${st.title} · " + t("viaggio concluso", "trip completed"), text.toString(),
            Notif.openApp(this, null, 7, "capotreno"))
        Speech.say(this, text.lineSequence().first(), Speech.Sound.INFO)
        return true
    }

    private fun platOf(s: com.binario.treni.data.TrainStop): String = s.realPlatform.ifBlank { s.schedPlatform }

    private fun announce(st: com.binario.treni.data.TrainStatus, wake: com.binario.treni.data.Station?) {
        val en = com.binario.treni.data.I18n.en
        fun t(itText: String, enText: String) = com.binario.treni.data.I18n.tr(itText, enText)
        val now = System.currentTimeMillis()
        // Dove salgo: la fermata scelta ("Salgo qui") oppure l'origine del treno
        val boardSt = store.boardingStation()
        val first = (if (boardSt != null) st.stops.firstOrNull { it.id == boardSt.id || it.name.equals(boardSt.name, true) } else null)
            ?: st.stops.firstOrNull()
        val boardedOrPassed = first?.passed == true
        val atOrigin = first == st.stops.firstOrNull()
        val next = st.nextStop

        // 1) Inizio: dove prendere il treno
        if (!announcedIntro) {
            announcedIntro = true
            val sb = StringBuilder("${st.title} ${t("per", "to")} ${st.destination}. ")
            if (!boardedOrPassed && first != null) {
                val at = (if (first.schedDep > 0) first.schedDep else first.schedArr)
                sb.append(if (atOrigin) t("Parte da ${first.name} alle ${Fmt.time(at)}", "Departs from ${first.name} at ${Fmt.time(at)}")
                    else t("Sali a ${first.name}: passa alle ${Fmt.time(at)}", "Board at ${first.name}: due at ${Fmt.time(at)}"))
                if (platOf(first).isNotBlank()) sb.append(t(", binario ${platOf(first)}", ", platform ${platOf(first)}"))
                else sb.append(t(", binario non ancora indicato", ", platform not yet announced"))
                sb.append(". ")
            } else if (next != null) {
                sb.append(t("Prossima fermata ${next.name}", "Next stop ${next.name}"))
                if (platOf(next).isNotBlank()) sb.append(t(", binario ${platOf(next)}", ", platform ${platOf(next)}"))
                sb.append(". ")
            }
            if (st.delay > 0) sb.append(t("Ritardo ${st.delay} minuti.", "${st.delay} minutes late."))
            if (wake != null) sb.append(t(" Ti avviserò prima di ${wake.name}.", " I will warn you before ${wake.name}."))
            Speech.say(this, sb.toString(), Speech.Sound.PLATFORM)
        }

        // 2) Soppressione
        if (st.cancelled && !saidCancelled) {
            saidCancelled = true
            Speech.say(this, t("Attenzione: il treno ${st.title} è soppresso.", "Warning: train ${st.title} is cancelled."), Speech.Sound.ALERT)
        }

        // 3) Cambio binario alla stazione di partenza o alla prossima fermata
        val watch = if (!boardedOrPassed) first else next
        if (watch != null) {
            val p = platOf(watch)
            val old = knownPlatforms[watch.id]
            if (p.isNotBlank()) {
                if (old != null && old.isNotBlank() && old != p) {
                    val msg = t("Cambio binario a ${watch.name}: il treno ${st.title} arriva al binario $p invece del $old.",
                        "Platform change at ${watch.name}: train ${st.title} now uses platform $p instead of $old.")
                    if (store.changeAlerts) Notif.post(this, ID + 2, Notif.CH_ALERT, "🔀 " + t("Cambio binario", "Platform change") + ": $old → $p",
                        msg, Notif.openApp(this, st.ref, 5))
                    Haptic.alert(this, Haptic.Kind.ALERT, msg)
                } else if (old == null && watch.realPlatform.isNotBlank() && announcedIntro && !boardedOrPassed) {
                    // Binario confermato per la prima volta
                    Speech.say(this, t("Binario confermato: ${watch.realPlatform}.", "Platform confirmed: ${watch.realPlatform}."), Speech.Sound.PLATFORM)
                }
                knownPlatforms[watch.id] = p
            }
        }

        // 5) Stato sull'orologio / fascia (opzionale): notifica normale, non fissa, che gli orologi inoltrano
        if (store.watchStatus && !st.arrived) pushToWatch(st, next?.name, if (watch != null) platOf(watch) else "")

        // 4) Ritardo aumentato di almeno 5 minuti
        val ld = lastDelay
        if (ld != null && !st.arrived && !st.cancelled && st.delay - ld >= 5) {
            val msg = t("Il treno ${st.title} ora ha ${st.delay} minuti di ritardo.", "Train ${st.title} is now ${st.delay} minutes late.")
            if (store.changeAlerts) Notif.post(this, ID + 3, Notif.CH_ALERT, "⏱ ${st.title} +${st.delay}'", msg, Notif.openApp(this, st.ref, 6))
            Haptic.alert(this, Haptic.Kind.ALERT, msg)
            lastDelay = st.delay
        } else if (ld == null || st.delay < ld) {
            lastDelay = st.delay
        }

        // 5) Partenza tra 5 minuti
        if (!boardedOrPassed && !saidDepartSoon && first != null) {
            val leave = (if (first.schedDep > 0) first.schedDep else first.schedArr) + st.delay * 60_000L
            val mins = ((leave - now) / 60_000L).toInt()
            if (leave > now && mins <= 5) {
                saidDepartSoon = true
                val plat = platOf(first)
                Speech.say(this,
                    t("Il treno ${st.title} " + (if (atOrigin) "parte" else "arriva a ${first.name}") + " tra ${maxOf(mins, 1)} minuti" +
                        (if (plat.isNotBlank()) ", binario $plat." else "."),
                        "Train ${st.title} " + (if (atOrigin) "leaves" else "reaches ${first.name}") + " in ${maxOf(mins, 1)} minutes" +
                            (if (plat.isNotBlank()) ", platform $plat." else ".")),
                    Speech.Sound.DEPART)
            }
        }

        // 6) Annuncio di ogni fermata (come a bordo), solo con la voce attiva
        if (st.departed && boardedOrPassed && !st.arrived && next != null && next.id != lastNextStop) {
            if (lastNextStop != null && store.announceStops && (wake == null || next.id != wake.id)) {
                val eta = (if (next.schedArr > 0) next.schedArr else next.schedDep) + st.delay * 60_000L
                Speech.say(this, t("Prossima fermata: ${next.name}", "Next stop: ${next.name}") +
                    (if (eta > 0) t(", alle ${Fmt.time(eta)}.", ", at ${Fmt.time(eta)}.") else "."), Speech.Sound.INFO)
            }
            lastNextStop = next.id
        }

        // 7) Preavviso 10 minuti prima della fermata dove scendere
        if (wake != null && !saidPreWake && !store.wakeFired) {
            val target = st.stops.firstOrNull { it.id == wake.id || it.name.equals(wake.name, true) }
            if (target != null && !target.passed) {
                val eta = (if (target.schedArr > 0) target.schedArr else target.schedDep) + st.delay * 60_000L
                if (eta > 0 && eta - now in 4 * 60_000L..10 * 60_000L) {
                    saidPreWake = true
                    val mins = ((eta - now) / 60_000L).toInt()
                    Speech.say(this, t("Tra circa $mins minuti arrivi a ${target.name}. Inizia a prepararti.",
                        "In about $mins minutes you arrive at ${target.name}. Start getting ready."), Speech.Sound.PLATFORM, essential = true)
                }
            }
        }
    }

    /** Suona quando il treno lascia la fermata prima di quella scelta (o 4 minuti prima dell'arrivo previsto). */
    private fun checkWake(st: com.binario.treni.data.TrainStatus, wake: com.binario.treni.data.Station) {
        val idx = st.stops.indexOfFirst { it.id == wake.id || it.name.equals(wake.name, true) }
        if (idx <= 0) return
        val prev = st.stops[idx - 1]
        val target = st.stops[idx]
        val eta = (if (target.schedArr > 0) target.schedArr else target.schedDep) + st.delay * 60_000L
        val now = System.currentTimeMillis()
        val leftPrev = prev.realDep > 0 || prev.realArr > 0
        if (target.passed) {
            store.wakeFired = true; return
        }
        if (leftPrev || (eta > 0 && eta - now < 4 * 60_000L)) {
            store.wakeFired = true
            val n = NotificationCompat.Builder(this, Notif.CH_WAKE)
                .setSmallIcon(R.drawable.ic_train)
                .setContentTitle("⏰ " + com.binario.treni.data.I18n.tr("Sveglia! Prossima fermata: ", "Wake up! Next stop: ") + target.name)
                .setContentText(com.binario.treni.data.I18n.tr("Arrivo previsto alle ", "Expected arrival at ") + Fmt.time(eta) +
                    (if (target.platformText.isNotBlank()) com.binario.treni.data.I18n.tr(" · binario ", " · platform ") + target.platformText else ""))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(Notif.openApp(this, st.ref, 3))
                .setFullScreenIntent(Notif.openApp(this, st.ref, 4), true)
                .build()
            n.flags = n.flags or Notification.FLAG_INSISTENT
            if (Notif.canPost(this)) getSystemService(NotificationManager::class.java).notify(ID + 1, n)
            val en = com.binario.treni.data.I18n.en
            val plat = target.realPlatform.ifBlank { target.schedPlatform }
            Haptic.alert(this, Haptic.Kind.WAKE,
                com.binario.treni.data.I18n.tr5(
                    "Attenzione! Prossima fermata: ${target.name}. Preparati a scendere." + (if (plat.isNotBlank()) " Binario $plat." else ""),
                    "Attention! Next stop: ${target.name}. Get ready to get off." + (if (plat.isNotBlank()) " Platform $plat." else ""),
                    "注意！下一站：${target.name}。请准备下车。" + (if (plat.isNotBlank()) " 站台 $plat。" else ""),
                    "Achtung! Nächster Halt: ${target.name}. Mach dich bereit zum Aussteigen." + (if (plat.isNotBlank()) " Gleis $plat." else ""),
                    "Attention ! Prochain arrêt : ${target.name}. Préparez-vous à descendre." + (if (plat.isNotBlank()) " Voie $plat." else ""),
                    "¡Atención! Próxima parada: ${target.name}. Prepárate para bajar." + (if (plat.isNotBlank()) " Vía $plat." else ""),
                    "ご注意ください。次は${target.name}です。降りる準備をしてください。" + (if (plat.isNotBlank()) " ${plat}番線。" else ""),
                ))
        }
    }

    private val store by lazy { Store(this) }

    /** "🟢 In orario", "🟢 1 min in anticipo", "🟡 +3 min", "🔴 +12 min", "⛔ Soppresso". */
    private fun statusLine(st: com.binario.treni.data.TrainStatus): String {
        fun t(a: String, b: String) = com.binario.treni.data.I18n.tr(a, b)
        val d = st.delay
        return when {
            st.cancelled -> "⛔ " + t("Soppresso", "Cancelled")
            d < 0 -> "🟢 ${-d} " + t("min in anticipo", "min early")
            d == 0 -> "🟢 " + t("In orario", "On time")
            d < 5 -> "🟡 +$d min"
            else -> "🔴 +$d min " + t("di ritardo", "late")
        }
    }

    /** Avanzamento del viaggio (0–100) tra la fermata dove salgo (o l'origine) e quella dove scendo (o il capolinea). */
    private fun progressOf(st: com.binario.treni.data.TrainStatus, from: com.binario.treni.data.TrainStop?, to: com.binario.treni.data.TrainStop?): Int? {
        val a = from ?: st.stops.firstOrNull() ?: return null
        val b = to ?: st.stops.lastOrNull() ?: return null
        val t0 = if (a.schedDep > 0) a.schedDep else a.schedArr
        val t1 = if (b.schedArr > 0) b.schedArr else b.schedDep
        if (t0 <= 0 || t1 <= t0 || st.cancelled) return null
        val now = System.currentTimeMillis() - st.delay * 60_000L
        return (((now - t0) * 100) / (t1 - t0)).toInt().coerceIn(0, 100)
    }

    private fun build(
        ref: TrainRef, title: String, text: String, share: String? = null, progress: Int? = null, status: String? = null,
    ): Notification {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        // "Aggiorna": rilegge subito lo stato del treno
        val refresh = PendingIntent.getService(
            this, 3, Intent(this, TrackingService::class.java).setAction(ACTION_REFRESH),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val first = text.lineSequence().firstOrNull() ?: ""
        val b = NotificationCompat.Builder(this, Notif.CH_TRACK)
            .setSmallIcon(R.drawable.ic_train)
            .setContentTitle(title)
            .setContentText(if (status != null) "$status · $first" else first)
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (status != null) status + "\n" + text else text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            // Visibile anche sulla schermata di blocco, come nelle app che "seguono il treno sulla home"
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setColor(com.binario.treni.data.ColorBlind.brand.toInt())
            .setContentIntent(Notif.openApp(this, ref, 2))
            .addAction(0, com.binario.treni.data.I18n.tr("Aggiorna", "Refresh"), refresh)
            .addAction(0, com.binario.treni.data.I18n.tr("Smetti di seguire", "Stop following"), stop)
        if (progress != null) b.setProgress(100, progress, false)
        // "Condividi": apre la scelta delle app (WhatsApp, Telegram, Signal, WeChat…) con lo stato del treno già scritto
        if (share != null) {
            val pi = PendingIntent.getActivity(
                this, 5, com.binario.treni.ui.TrainShare.chooser(share),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            b.addAction(0, com.binario.treni.data.I18n.tr("Condividi", "Share"), pi)
        }
        return b.build()
    }

    private var lastWatchKey = ""
    private var lastWatchAt = 0L

    /** Una notifica normale (non fissa) con ritardo, binario e prossima fermata: al massimo una ogni 3 minuti e solo se qualcosa è cambiato. */
    private fun pushToWatch(st: com.binario.treni.data.TrainStatus, nextName: String?, platform: String) {
        fun t(itText: String, enText: String) = com.binario.treni.data.I18n.tr(itText, enText)
        val key = "${st.delay}|$nextName|$platform|${st.cancelled}"
        val now = System.currentTimeMillis()
        if (key == lastWatchKey || now - lastWatchAt < 3 * 60_000L) return
        lastWatchKey = key; lastWatchAt = now
        val sb = StringBuilder()
        if (st.cancelled) sb.append(t("Soppresso", "Cancelled"))
        else sb.append(if (st.delay > 0) t("+${st.delay} min", "+${st.delay} min") else t("In orario", "On time"))
        if (!nextName.isNullOrBlank()) sb.append(" · ").append(t("Prossima: ", "Next: ")).append(nextName)
        if (platform.isNotBlank()) sb.append(" · ").append(t("Bin. ", "Pl. ")).append(platform)
        Notif.post(this, ID + 7, Notif.CH_WATCH, "🚆 ${st.title}", sb.toString(), Notif.openApp(this, st.ref, 7))
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ID = 4242
        const val ACTION_STOP = "com.binario.treni.STOP_TRACKING"
        const val ACTION_REFRESH = "com.binario.treni.REFRESH_TRACKING"
        const val EXTRA_REF = "ref"
        const val EXTRA_RESUMED = "resumed"

        /** Segue il treno; [boarding] = stazione dove salgo (null = dall'origine o quella già scelta per lo stesso treno). */
        fun start(ctx: Context, ref: TrainRef, boarding: com.binario.treni.data.Station? = null) {
            val s = Store(ctx)
            val same = s.tracked()?.number == ref.number
            s.setTracked(ref)
            s.setWakeTarget(null)
            if (boarding != null) s.setBoardingStation(boarding) else if (!same) s.setBoardingStation(null)
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))
            com.binario.treni.ui.BatteryHelp.maybeAsk(ctx)
        }

        /**
         * Dopo un riavvio del telefono o un aggiornamento dell'app: riprende a seguire il treno se il viaggio
         * non è finito (corsa di oggi o di ieri sera). Su Android 15+ un servizio di questo tipo non può partire
         * all'accensione: si mostra una notifica "Riprendi a seguire" da toccare.
         */
        fun resumeAfterRestart(ctx: Context, boot: Boolean) {
            val s = Store(ctx)
            val ref = s.tracked() ?: return
            val age = System.currentTimeMillis() - (if (ref.date > 0) ref.date else System.currentTimeMillis())
            if (age > 36 * 3_600_000L) { s.setTracked(null); return }
            val intent = Intent(ctx, TrackingService::class.java).putExtra(EXTRA_RESUMED, true)
            val direct = !(boot && Build.VERSION.SDK_INT >= 35)
            if (direct) {
                try {
                    ContextCompat.startForegroundService(ctx, intent); return
                } catch (_: Exception) {
                }
            }
            val tap = PendingIntent.getForegroundService(ctx, 4300, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val en = com.binario.treni.data.I18n.en
            Notif.post(ctx, ID + 6, Notif.CH_ALERT,
                com.binario.treni.data.I18n.tr("Riprendi a seguire ", "Resume following ") + ref.label,
                com.binario.treni.data.I18n.tr("Il telefono si è riavviato: tocca per continuare a ricevere avvisi su binario, ritardi e arrivo.", "The phone restarted: tap to keep receiving platform, delay and arrival alerts."),
                tap)
        }

        /** Segue il treno e suona la sveglia prima della fermata scelta. */
        fun startWake(ctx: Context, ref: TrainRef, stop: com.binario.treni.data.Station) {
            val s = Store(ctx)
            if (s.tracked()?.number != ref.number) s.setBoardingStation(null)
            s.setTracked(ref)
            s.setWakeTarget(stop)
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))
            com.binario.treni.ui.BatteryHelp.maybeAsk(ctx)
        }

        fun stop(ctx: Context) {
            Store(ctx).setTracked(null)
            ctx.startService(Intent(ctx, TrackingService::class.java).setAction(ACTION_STOP))
        }
    }
}

/** Promemoria programmati di partenza/arrivo. */
object Reminders {
    fun schedule(ctx: Context, r: Reminder) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, r.id)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
        }
    }

    fun add(ctx: Context, r: Reminder) {
        Store(ctx).addReminder(r)
        schedule(ctx, r)
    }

    fun cancel(ctx: Context, id: Int) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, id))
        Store(ctx).removeReminder(id)
    }

    fun rescheduleAll(ctx: Context) {
        val store = Store(ctx)
        val now = System.currentTimeMillis()
        store.reminders().forEach { r ->
            if (r.eventTime < now) store.removeReminder(r.id) else schedule(ctx, r.copy(at = maxOf(r.at, now + 5000)))
        }
    }

    private fun pending(ctx: Context, id: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, id, Intent(ctx, ReminderReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val store = Store(ctx)
        val r = store.reminders().firstOrNull { it.id == id } ?: return
        val pending = goAsync()
        Thread {
            try {
                val ref = TrainRef(r.number, r.originCode, 0L, r.label)
                val tr = { a: String, b: String -> com.binario.treni.data.I18n.tr(a, b) }
                var text = (if (r.arrival) tr("Arrivo previsto alle ", "Expected arrival at ") else tr("Partenza prevista alle ", "Expected departure at ")) + Fmt.time(r.eventTime)
                var tapRef = ref
                try {
                    val st = Api.status(ref)
                    tapRef = st.ref
                    val stop = if (r.arrival) st.stops.lastOrNull() else st.stops.firstOrNull()
                    text = (if (r.arrival) tr("Arrivo a ", "Arrival at ") + st.destination + tr(" alle ", " at ") else tr("Partenza da ", "Departure from ") + st.origin + tr(" alle ", " at ")) +
                        Fmt.time(if (r.arrival) st.arrTime else st.depTime) + delayText(st.delay, true)
                    if (stop != null && stop.platformText.isNotBlank()) text += tr(" · binario ", " · platform ") + stop.platformText
                    if (st.cancelled) text = tr("Attenzione: il treno risulta soppresso", "Warning: the train is cancelled")
                } catch (_: Exception) {
                }
                val follow = PendingIntent.getForegroundService(
                    ctx, 10_000 + id,
                    Intent(ctx, TrackingService::class.java).putExtra(TrackingService.EXTRA_REF, tapRef.toJson().toString()),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
                Notif.post(
                    ctx, 20_000 + id, Notif.CH_REMIND, r.label, text, Notif.openApp(ctx, tapRef, 30_000 + id),
                    NotificationCompat.Action(0, com.binario.treni.data.I18n.tr("Segui treno", "Follow train"), follow),
                )
                Haptic.alert(ctx, Haptic.Kind.REMINDER, r.label + ". " + text)
                store.removeReminder(id)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            Reminders.rescheduleAll(ctx)
            TrackingService.resumeAfterRestart(ctx, boot = true)
        } else if (intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            // Dopo l'aggiornamento dell'app il servizio viene chiuso dal sistema: riparte da solo
            TrackingService.resumeAfterRestart(ctx, boot = false)
        }
    }
}

/** Controlla periodicamente le news di infomobilità e notifica i nuovi scioperi. */
class StrikeWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val store = Store(ctx)
        // Risparmio batteria: di notte (1–5) e con il risparmio energetico attivo il giro completo si fa al massimo
        // una volta ogni ora (o 45 minuti), a meno che tu non stia seguendo un treno
        val now = System.currentTimeMillis()
        val hour = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Rome")).get(java.util.Calendar.HOUR_OF_DAY)
        val saver = try { (ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isPowerSaveMode } catch (e: Exception) { false }
        val wp = ctx.getSharedPreferences("worker_pace", Context.MODE_PRIVATE)
        val gap = now - wp.getLong("full", 0L)
        if (store.newsSeeded && store.tracked() == null && ((hour in 1..4 && gap < 60 * 60_000L) || (saver && gap < 45 * 60_000L))) {
            return Result.success()
        }
        wp.edit().putLong("full", now).apply()
        val first = !store.newsSeeded
        val seen = store.seenNews()
        val newSeen = mutableListOf<String>()

        // Parole che identificano tratte, linee e stazioni dell'utente
        val names = (store.favRoutes().flatMap { listOf(it.from.name, it.to.name) } +
            store.favLines().flatMap { listOf(it.a.name, it.b.name) } +
            store.favStations().map { it.name } +
            (store.tracked()?.let { listOf(it.label) } ?: emptyList()))
            .map { it.trim() }.filter { it.length >= 3 }.distinct()
        val lineNames = store.favLines().map { it.name }.filter { it.isNotBlank() }
        fun mine(text: String): String? =
            names.firstOrNull { text.contains(it, true) } ?: lineNames.firstOrNull { Regex("\\b${Regex.escape(it)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) }

        // Tratta scelta per le notifiche di sciopero (Notizie › La mia tratta, oppure quella dedotta dai treni abituali)
        val rn = com.binario.treni.data.RouteNews
        val myRoute = rn.defaultRoute(store, ctx)
        val routeOnly = store.strikeRouteOnly && myRoute.from != null && myRoute.to != null
        // Avvisi di sciopero silenziati dall'utente fino a una certa ora: gli scioperi si segnano come visti
        // (alla fine della pausa non arriva una raffica di notifiche vecchie)
        val strikesMuted = now < store.strikeMuteUntil

        // Una sola notifica per giorno di sciopero: una quando viene pubblicato e una il giorno prima.
        // Più voci (Osservatorio MIT con orari o aziende diverse, comunicati delle aziende) dello stesso giorno contano come una.
        val sp = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE)
        val romeTz = java.util.TimeZone.getTimeZone("Europe/Rome")
        val dmy = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.ITALY).apply { timeZone = romeTz }
        fun dayMs(d: String): Long? = try { dmy.parse(d.trim().take(10))?.time } catch (_: Exception) { null }
        val todayStr = dmy.format(java.util.Date(now))
        val tomorrowStr = dmy.format(java.util.Date(now + 24 * 3600_000L))
        // Pulizia: si dimenticano i giorni di sciopero passati da più di una settimana
        sp.all.keys.filter { it.startsWith("sa_") }.forEach { k ->
            val d = dayMs(k.substringAfter("sa_").substringAfter('_'))
            if (d != null && d < now - 7 * 24 * 3600_000L) sp.edit().remove(k).apply()
        }
        /** Vero se per questo giorno (gg/mm/aaaa) l'avviso "pub" o "eve" non è ancora partito; lo segna come partito. */
        fun claim(kind: String, day: String): Boolean {
            val k = "sa_${kind}_$day"
            if (sp.contains(k)) return false
            sp.edit().putLong(k, now).apply()
            return true
        }
        /** Avvisato oggi per questo giorno di sciopero (alla pubblicazione): il giorno prima non serve un secondo avviso. */
        fun alertedToday(day: String): Boolean {
            val t = sp.getLong("sa_pub_$day", 0L)
            return t > 0 && dmy.format(java.util.Date(t)) == todayStr
        }
        fun strikeRelevant(st: com.binario.treni.data.Strike): Boolean {
            val route = if (routeOnly) myRoute else store.myRoute()
            return when {
                // Solo la tratta scelta: con gli orari conta se un mio treno parte durante lo sciopero,
                // senza orari bastano regione e impresa
                routeOnly && myRoute.complete -> rn.affectsRoute(st, myRoute)
                routeOnly -> rn.inRegion(st, myRoute.regions) && rn.forOperators(st, myRoute.operators)
                // L'utente vuole solo gli scioperi che toccano la sua tratta e i suoi orari
                store.newsFilter == "route" && route != null && route.complete -> rn.affectsRoute(st, route)
                store.newsFilter == "region" && route != null -> rn.inRegion(st, route.regions)
                else -> st.relevance.contains("nazional", true) || st.region.contains("lombard", true) ||
                    mine(st.company + " " + st.region) != null
            }
        }
        fun postStrike(st: com.binario.treni.data.Strike, eve: Boolean) {
            val route = if (routeOnly) myRoute else store.myRoute()
            val trips = if (route != null && route.complete) rn.affectedTrips(st, route) else emptyList()
            val head = if (eve) com.binario.treni.data.I18n.tr("Domani sciopero", "Strike tomorrow") + " · " + st.company.take(60) else "🚫 ${st.title}"
            Notif.post(ctx, ("sd" + st.start).hashCode(), Notif.CH_NEWS, if (eve) "🚫 $head" else head,
                "${st.modality}\n${st.unions} · ${st.region}" +
                    (if (trips.isNotEmpty()) "\n🚆 " + trips.joinToString("; ") { rn.describe(it) } else ""), Notif.openApp(ctx, null, 5001, "news"))
            Haptic.alert(ctx, Haptic.Kind.NEWS)
        }

        // 1) Scioperi ferroviari dalla fonte ufficiale (Osservatorio MIT)
        if (store.strikeAlerts) {
            try {
                val list = Sources.railStrikes()
                list.forEach { st ->
                    if (st.key !in seen) {
                        newSeen += st.key
                        // Solo scioperi che riguardano i treni (non autobus, aerei, appalti…); un avviso per giorno
                        if (!first && !strikesMuted && Sources.isTrainStrike(st) && strikeRelevant(st) && claim("pub", st.start.trim().take(10))) {
                            postStrike(st, eve = false)
                        }
                    }
                }
                // Il giorno prima (dalle 8): un promemoria, se oggi non è già arrivato l'avviso di pubblicazione
                if (!strikesMuted && hour >= 8) {
                    list.filter { Sources.isTrainStrike(it) && it.start.trim().take(10) == tomorrowStr }.forEach { st ->
                        val day = st.start.trim().take(10)
                        if (strikeRelevant(st) && !alertedToday(day) && claim("eve", day)) postStrike(st, eve = true)
                    }
                }
            } catch (_: Exception) {
            }
        }

        // 1b) Germania: notizie sugli scioperi dei treni (GDL, EVG…), solo per chi viaggia in Germania
        if (store.strikeAlerts && com.binario.treni.data.GermanyLive.usesGermany(store)) {
            try {
                val dp = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE)
                val seeded = dp.getBoolean("de_strikes_seeded", false)
                com.binario.treni.data.GermanyLive.strikeNews().forEach { n ->
                    if (n.key in seen) return@forEach
                    newSeen += n.key
                    // La prima volta si segnano come già viste, senza raffica di notifiche
                    if (seeded && !strikesMuted && now - sp.getLong("sa_de_last", 0L) > 24 * 3600_000L) {
                        sp.edit().putLong("sa_de_last", now).apply()
                        Notif.post(ctx, n.key.hashCode(), Notif.CH_NEWS, "🚫 🇩🇪 " + com.binario.treni.data.I18n.tr("Sciopero treni in Germania", "Train strike in Germany"),
                            n.title + (if (n.source.isNotBlank()) "\n" + n.source else ""), Notif.openApp(ctx, null, 5003, "news"))
                        Haptic.alert(ctx, Haptic.Kind.NEWS)
                    }
                }
                if (!seeded) dp.edit().putBoolean("de_strikes_seeded", true).apply()
            } catch (_: Exception) {
            }
        }

        // 2) Comunicati: scioperi, interruzioni programmate, circolazione bloccata
        try {
            Sources.allNotices().forEach { n ->
                val body = n.title + " " + n.text
                // Per gli scioperi conta solo il titolo: se l'azienda ritocca il testo non arriva una seconda notifica
                val key = if (n.kind == com.binario.treni.data.Notice.Kind.STRIKE) "ns:" + n.source + ":" + n.title.hashCode()
                    else "n:" + n.source + ":" + (n.title + "|" + n.text).hashCode()
                // Chiave usata fino alla 0.1.19: un comunicato già visto non deve tornare come notifica dopo l'aggiornamento
                val oldKey = "n:" + n.source + ":" + (n.title + "|" + n.text).hashCode()
                if (key in seen || oldKey in seen) {
                    if (key !in seen) newSeen += key
                    return@forEach
                }
                newSeen += key
                if (first) return@forEach
                val hit = mine(body)
                when (n.kind) {
                    com.binario.treni.data.Notice.Kind.STRIKE -> if (store.strikeAlerts && !strikesMuted && Sources.isTrainNotice(n) &&
                        // Comunicati delle aziende: solo se nominano la mia tratta; senza tratta solo quelli della mia regione
                        (if (routeOnly) rn.noticeForRoute(n, myRoute) else rn.noticeInRegion(n, myRoute.regions)) &&
                        // Se indica il giorno dello sciopero e per quel giorno è già partito un avviso, non se ne manda un altro
                        (Regex("\\b(\\d{1,2})/(\\d{1,2})/(\\d{4})\\b").find(body)?.let { m ->
                            claim("pub", "%02d/%02d/%s".format(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3]))
                        } ?: true)) {
                        Notif.post(ctx, ("s" + n.title).hashCode(), Notif.CH_NEWS, "Sciopero · ${n.source}", n.title + "\n" + n.text.take(300),
                            Notif.openApp(ctx, null, 5002, "news"))
                        Haptic.alert(ctx, Haptic.Kind.NEWS)
                    }
                    com.binario.treni.data.Notice.Kind.BLOCKED -> if (store.routeAlerts && hit != null) {
                        // Stesso id per lo stesso titolo: gli aggiornamenti sostituiscono la notifica precedente
                        Notif.post(ctx, ("b" + n.source + n.title).hashCode(), Notif.CH_ALERT, "⚠️ Circolazione · $hit",
                            n.title + "\n" + n.text.take(400) + "\nAggiornato: " + Fmt.time(System.currentTimeMillis()),
                            Notif.openApp(ctx, null, 5003, "news"))
                        Haptic.alert(ctx, Haptic.Kind.ALERT)
                    }
                    com.binario.treni.data.Notice.Kind.WORKS -> if (store.routeAlerts && hit != null) {
                        Notif.post(ctx, ("w" + n.title).hashCode(), Notif.CH_ALERT, "🚧 Lavori/modifiche · $hit",
                            n.title + "\n" + n.text.take(400), Notif.openApp(ctx, null, 5004, "news"))
                        Haptic.alert(ctx, Haptic.Kind.ALERT)
                    }
                    else -> {}
                }
            }
        } catch (_: Exception) {
        }

        // 3) Treni preferiti soppressi oggi
        if (store.routeAlerts) {
            store.favTrains().forEach { r ->
                try {
                    val st = Api.status(r)
                    val key = "cancel:${st.number}:${st.date}"
                    if (st.cancelled && key !in seen) {
                        newSeen += key
                        Notif.post(ctx, 6000 + (st.number.toIntOrNull() ?: 0) % 1000, Notif.CH_ALERT,
                            "⚠️ ${st.title} " + com.binario.treni.data.I18n.tr("soppresso", "cancelled"), "${st.origin} → ${st.destination} · ${Fmt.time(st.depTime)}",
                            Notif.openApp(ctx, st.ref, 6000))
                        Haptic.alert(ctx, Haptic.Kind.ALERT, "${st.title} ${st.origin} → ${st.destination} " +
                            com.binario.treni.data.I18n.tr("è soppresso.", "is cancelled."))
                    }
                } catch (_: Exception) {
                }
            }
        }
        // 4) Treno abituale: avvisi automatici senza premere "Segui"
        if (store.habitAlerts) {
            try {
                HabitAlerts.check(ctx, store)
            } catch (_: Exception) {
            }
        }
        store.addSeenNews(newSeen)
        store.newsSeeded = true
        // Registro "Quanto sei green": ritardi del giorno
        try {
            com.binario.treni.data.GreenCalc.autoLog(ctx)
        } catch (_: Exception) {
        }
        // Feedback rimasti in coda senza rete
        try {
            com.binario.treni.data.Feedback.flush(applicationContext)
        } catch (_: Exception) {
        }
        // Puntualità rete FerrovieNord: TrovaTreno non la pubblica, l'app raccoglie gli arrivi da ViaggiaTreno
        try {
            com.binario.treni.data.FnStats.collect(applicationContext)
        } catch (_: Exception) {
        }
        // Puntualità FFS: le FFS pubblicano solo il giorno precedente, quindi lo raccogliamo ogni giorno (3 richieste piccole)
        try {
            com.binario.treni.data.SwissStats.collect(applicationContext)
        } catch (_: Exception) {
        }
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<StrikeWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("alerts", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}

/**
 * Avvisi sul treno che prendi di solito: nei 45 minuti prima della partenza controlla ritardo, soppressione e
 * cambio di binario e, se il treno è soppresso o ha più di 15 minuti di ritardo, propone subito le alternative.
 * Una sola notifica per ogni novità (stesso id: gli aggiornamenti sostituiscono la notifica precedente).
 */
object HabitAlerts {
    fun check(ctx: Context, store: Store) {
        val now = System.currentTimeMillis()
        val due = com.binario.treni.data.Habits.dueForAlerts(store.habits(), now)
        val state = store.habitAlertState()
        val today = Fmt.midnight(now)
        state.keys().asSequence().toList().forEach { k -> if (state.optJSONObject(k)?.optLong("day") != today) state.remove(k) }
        val tracked = store.tracked()
        val en = com.binario.treni.data.I18n.en
        fun t(itText: String, enText: String) = com.binario.treni.data.I18n.tr(itText, enText)
        due.forEach { h ->
            // Se lo stai già seguendo, gli avvisi arrivano dalla notifica fissa
            if (tracked != null && com.binario.treni.data.Habits.digits(tracked.number) == com.binario.treni.data.Habits.digits(h.number)) return@forEach
            val live = try {
                com.binario.treni.data.NextTrain.live(h, now)
            } catch (_: Exception) {
                return@forEach
            }
            if (!live.found || live.departed) return@forEach
            val prev = state.optJSONObject(h.key) ?: JSONObject().put("day", today)
            val news = mutableListOf<String>()
            if (live.cancelled && !prev.optBoolean("cancel")) {
                news += t("È soppresso.", "It is cancelled.")
                prev.put("cancel", true)
            }
            val lastDelay = prev.optInt("delay", 0)
            if (!live.cancelled) {
                if (live.delay >= 5 && kotlin.math.abs(live.delay - lastDelay) >= 5) {
                    news += t("Ritardo previsto: ${live.delay} minuti, parte alle ", "Expected delay: ${live.delay} minutes, leaves at ") +
                        Fmt.time(live.dep + live.delay * 60_000L) + "."
                    prev.put("delay", live.delay)
                } else if (live.delay < 5 && lastDelay >= 5) {
                    news += t("Di nuovo in orario.", "Back on time.")
                    prev.put("delay", live.delay)
                }
                if (live.platformChanged && prev.optString("plat") != live.platform) {
                    news += t("Cambio binario: parte dal ${live.platform} invece del ${live.schedPlatform}.",
                        "Platform change: leaves from ${live.platform} instead of ${live.schedPlatform}.")
                    prev.put("plat", live.platform)
                }
            }
            state.put(h.key, prev)
            if (news.isEmpty()) return@forEach
            val text = StringBuilder(news.joinToString("\n"))
            if (live.needsAlternative) {
                val alts = com.binario.treni.data.NextTrain.alternatives(live, now)
                if (alts.isNotEmpty()) {
                    text.append("\n\n").append(t("Alternative:", "Alternatives:"))
                    alts.forEach { a -> text.append("\n• ").append(Fmt.time(a.dep)).append(" ").append(a.title).append(" · ").append(a.detail) }
                } else {
                    text.append("\n\n").append(t("Nessuna alternativa trovata a breve: apri l'app per altre soluzioni.",
                        "No alternative found soon: open the app for more options."))
                }
            }
            val title = "🚆 ${h.title} " + t("delle", "at") + " ${Fmt.time(live.dep)} · ${h.board.name}"
            Notif.post(ctx, 7000 + kotlin.math.abs(h.key.hashCode()) % 1000, Notif.CH_ALERT, title, text.toString(),
                Notif.openApp(ctx, live.ref, 7000))
            Haptic.alert(ctx, Haptic.Kind.ALERT, title.removePrefix("🚆 ") + ". " + news.joinToString(" "))
        }
        store.setHabitAlertState(state)
    }
}

/**
 * Ogni settimana riscarica gli elenchi ufficiali dei punti vendita (rivendite autorizzate e biglietterie Trenord
 * con orari), solo con rete disponibile. Lo stato "aperto/chiuso" viene invece letto dal vivo quando si apre la schermata.
 */
class SellersWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        com.binario.treni.data.TicketSellers.refreshAll(applicationContext)
        // L'Alto Adige solo se è già stato consultato (evita di calcolare posizioni che non servono)
        if (com.binario.treni.data.TicketSellers.hasAltoAdige(applicationContext)) {
            try { com.binario.treni.data.TicketSellers.refreshAltoAdige(applicationContext) } catch (_: Exception) { }
        }
        Result.success()
    } catch (e: Exception) {
        Result.retry()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<SellersWorker>(7, TimeUnit.DAYS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.UNMETERED).setRequiresBatteryNotLow(true).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("ticket_sellers", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

/**
 * Ogni 15 minuti (con rete; Android può ritardare) controlla se è uscita una nuova versione di Binario e mostra una notifica con popup; toccandola
 * si apre l'app con la finestra di aggiornamento. Se non aggiorni, la ripete dopo 24 ore, al massimo 3 volte in tutto.
 * Nella Home dell'app resta comunque l'avviso arancione finché non si aggiorna.
 */
class UpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        // Avvisi sul mio viaggio (esci di casa, ultimo treno, coincidenza a rischio): fuori dalle finestre non fa richieste
        try { TripAlerts.run(ctx) } catch (_: Exception) {}
        // Avvisi RFI sulle linee e sui treni preferiti: una volta a settimana
        try {
            if (com.binario.treni.data.RfiNotices.due(ctx)) {
                val st = Store(ctx)
                val fresh = com.binario.treni.data.RfiNotices.refresh(ctx, st.favLines(), st.favTrains())
                if (fresh.isNotEmpty()) {
                    Notif.createChannels(ctx)
                    fresh.take(3).forEach { n ->
                        Notif.post(ctx, 9000 + (n.id.hashCode() and 0x1ff), Notif.CH_ALERT,
                            "⚠ " + com.binario.treni.data.tx("Avviso RFI sulla tua tratta"), n.title, Notif.openApp(ctx, req = 9000 + (n.id.hashCode() and 0x1ff), screen = "trains"))
                    }
                }
            }
        } catch (_: Exception) {
        }
        val (r, reached) = try { com.binario.treni.data.Updater.checkReached(ctx) } catch (e: Exception) { null to false }
        if (!reached) return Result.success()
        if (r != null) {
            val store = Store(ctx)
            val now = System.currentTimeMillis()
            val first = store.notifiedUpdate != r.versionCode
            val again = !first && store.notifiedUpdateCount < 3 && now - store.notifiedUpdateAt > 24 * 3600_000L
            if (first || again) {
                Notif.createChannels(ctx)
                Notif.post(
                    ctx, 4242, Notif.CH_UPDATE,
                    com.binario.treni.data.tx("È uscita una nuova versione") + " · " + r.versionName,
                    com.binario.treni.data.tx("Tocca per scaricare e installare"),
                    Notif.openApp(ctx, req = 4242, screen = "update"),
                )
                if (Notif.canPost(ctx)) {
                    store.notifiedUpdateCount = if (first) 1 else store.notifiedUpdateCount + 1
                    store.notifiedUpdateAt = now
                    store.notifiedUpdate = r.versionCode
                }
            }
        }
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<UpdateWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("app_update", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
