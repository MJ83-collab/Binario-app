package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainsMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Colore del pallino in base al ritardo (stesse fasce di Treniamo; in modalità daltonici usa la palette sicura). */
internal fun dotColor(d: TrainsMap.Dot): Int = delayColor(d.delay, d.known)

/** Colore per ritardo, uguale a quello dei pallini della mappa dei treni (e della mappa della scheda del treno). */
internal fun delayColor(delay: Int, known: Boolean): Int {
    val cb = com.binario.treni.data.ColorBlind
    return when {
        !known -> 0xFF9AA0AE.toInt()
        delay <= 0 -> if (cb.on) cb.ok.toInt() else 0xFF43A047.toInt()
        delay <= 5 -> 0xFFE6B422.toInt()
        delay <= 14 -> if (cb.on) cb.late.toInt() else 0xFFF57C00.toInt()
        else -> if (cb.on) 0xFF6A1B00.toInt() else 0xFFE53935.toInt()
    }
}

/** Legenda dei colori del ritardo, piccola, da mettere sopra una mappa. */
@Composable
internal fun DelayLegend(modifier: Modifier = Modifier) {
    Column(modifier.padding(8.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xCC111318)).padding(horizontal = 10.dp, vertical = 6.dp)) {
        LEGEND.forEach { (c, label) ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 1.dp)) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(Color(c)))
                Spacer(Modifier.width(6.dp))
                Text(I18n.tr(label.first, label.second), color = Color.White, fontSize = 10.sp)
            }
        }
    }
}

private val LEGEND = listOf(
    0xFF43A047.toInt() to ("In orario" to "On time"),
    0xFFE6B422.toInt() to ("1–5 min di ritardo" to "1–5 min late"),
    0xFFF57C00.toInt() to ("6–14 min di ritardo" to "6–14 min late"),
    0xFFE53935.toInt() to ("15+ min di ritardo" to "15+ min late"),
    0xFF9AA0AE.toInt() to ("Ritardo n.d." to "Delay n.a."),
)

/** Voce nelle Statistiche che apre la mappa dei treni. */
@Composable
fun TrainsMapEntryCard(onOpen: () -> Unit) {
    WhiteCard(onClick = onOpen) {
        CardTitle(I18n.tr("Mappa dei treni", "Train map"))
        Text(
            I18n.tr("Treni in partenza dai principali nodi d'Italia, Svizzera e Germania, colorati per ritardo", "Trains departing soon from the main hubs of Italy, Switzerland and Germany, coloured by delay"),
            color = Muted, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainsMapScreen(store: com.binario.treni.data.Store, onBack: () -> Unit, onTrain: (TrainRef) -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var baseDots by remember { mutableStateOf<List<TrainsMap.Dot>?>(null) }
    var positions by remember { mutableStateOf<Map<Int, Pair<Double, Double>>>(emptyMap()) }
    var trenordLive by remember { mutableStateOf<Map<Int, Triple<Double, Double, Pair<Int, Boolean>>>>(emptyMap()) }
    var refineJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var cmd by remember { mutableStateOf<MapCmd?>(null) }
    var cmdId by remember { mutableStateOf(0) }
    var noLocation by remember { mutableStateOf(false) }
    val dots: List<TrainsMap.Dot>? = baseDots?.mapIndexed { i, d ->
        trenordLive[i]?.let { d.copy(lat = it.first, lon = it.second, delay = it.third.first, known = it.third.second, refined = true) }
            ?: positions[i]?.let { d.copy(lat = it.first, lon = it.second, refined = true) } ?: d
    }
    var countries by remember { mutableStateOf(store.mapCountries) }
    var selected by remember { mutableStateOf<TrainsMap.Dot?>(null) }
    var loading by remember { mutableStateOf(true) }
    var rails by remember { mutableStateOf(false) }

    fun load(force: Boolean) {
        loading = true
        refineJob?.cancel()
        scope.launch {
            val list = withContext(Dispatchers.IO) {
                val main = runCatching { TrainsMap.load(force) }.getOrDefault(emptyList())
                val live = runCatching { TrainsMap.loadLive(force) }.getOrDefault(emptyList())
                // Dove arrivano i treni in marcia da Transitous (DE, AT, CH, FR) i campioni dei tabelloni non servono
                val covered = live.map { it.country }.toSet()
                // Trenord e FerrovieNord dalle fonti Trenord (orario ufficiale); i loro treni non si ripetono dai tabelloni
                val tn = runCatching { TrainsMap.trenordRuns() }.getOrDefault(emptyList())
                val tnNumbers = tn.mapNotNull { Regex("(\\d+)$").find(it.title)?.value }.toSet()
                main.filter { it.country !in covered && !(it.country == "IT" && Regex("(\\d+)$").find(it.title)?.value in tnNumbers) } + tn + live
            }
            positions = emptyMap(); trenordLive = emptyMap()
            baseDots = list
            loading = false
            // Poi i treni italiani si spostano sulla loro tratta, a gruppi
            refineJob = launch {
                launch { runCatching { TrainsMap.refineTrenord(list) { m -> trenordLive = m } } }
                runCatching { TrainsMap.refine(list, store) { m -> positions = m } }
            }
        }
    }

    fun goToMe() {
        val lm = ctx.getSystemService(android.content.Context.LOCATION_SERVICE) as android.location.LocationManager
        val loc = try {
            listOf("gps", "network", "passive").mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
        } catch (_: SecurityException) { null }
        if (loc == null) noLocation = true else { noLocation = false; cmd = MapCmd(++cmdId, "me", loc.latitude, loc.longitude) }
    }
    val perm = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) goToMe() else noLocation = true
    }
    fun nearMe() {
        val ok = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
            androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (ok) goToMe() else perm.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    LaunchedEffect(Unit) { load(false) }

    val shown = dots?.filter { it.country in countries } ?: emptyList()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(I18n.tr("Mappa dei treni", "Train map"), onBack = onBack, actions = {
            IconButton({ load(true) }) { Icon(Icons.Filled.Refresh, I18n.tr("Aggiorna", "Refresh")) }
        })
        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("IT" to I18n.tr("Italia", "Italy"), "CH" to I18n.tr("Svizzera", "Switzerland"), "DE" to I18n.tr("Germania", "Germany"),
                "AT" to I18n.tr("Austria", "Austria"), "FR" to I18n.tr("Francia", "France"),
                "FI" to I18n.tr("Finlandia (GPS)", "Finland (GPS)"), "NO" to I18n.tr("Norvegia (GPS)", "Norway (GPS)")).forEach { (code, name) ->
                FilterChip(
                    selected = code in countries,
                    onClick = { countries = if (code in countries) countries - code else countries + code; store.mapCountries = countries; selected = null },
                    label = { Text(name) },
                )
            }
            FilterChip(selected = rails, onClick = { rails = !rails }, label = { Text(I18n.tr("Binari", "Tracks")) })
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            TrainDotsMap(shown.map { MapDot(it.lat, it.lon, dotColor(it)) }, Modifier.fillMaxSize(), rails, cmd) { i -> selected = shown.getOrNull(i) }
            // Contatore e pulsanti sopra la mappa
            Column(Modifier.align(Alignment.TopStart).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xCC111318)).padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(Color(0xFF43A047)))
                    Spacer(Modifier.width(8.dp))
                    Text(shown.size.toString() + " " + I18n.tr("treni in viaggio o in partenza", "trains running or about to depart"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Row(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xCC111318)).clickable { nearMe() }.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.MyLocation, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(I18n.tr("Vicino a me", "Near me"), color = Color.White, fontSize = 13.sp)
                }
                if (noLocation) Text(I18n.tr("Posizione non disponibile", "Location unavailable"), color = Color.White, fontSize = 11.sp,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xCC111318)).padding(horizontal = 8.dp, vertical = 4.dp))
            }
            // Zoom
            Column(Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xDDFFFFFF))) {
                Text("+", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Black, modifier = Modifier.clickable { cmd = MapCmd(++cmdId, "in") }.padding(horizontal = 16.dp, vertical = 6.dp))
                Text("−", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Black, modifier = Modifier.clickable { cmd = MapCmd(++cmdId, "out") }.padding(horizontal = 16.dp, vertical = 6.dp))
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter), color = Green)
            // Legenda
            Column(
                Modifier.align(Alignment.BottomStart).padding(8.dp).clip(RoundedCornerShape(8.dp))
                    .background(Color(0xCC111318)).padding(horizontal = 10.dp, vertical = 8.dp),
            ) {
                LEGEND.forEach { (c, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 1.dp)) {
                        Box(Modifier.size(11.dp).clip(CircleShape).background(Color(c)))
                        Spacer(Modifier.width(7.dp))
                        Text(I18n.tr(label.first, label.second), color = Color.White, fontSize = 11.sp)
                    }
                }
                Text(I18n.tr("Treni mostrati", "Trains shown") + ": " + shown.size, color = Color(0xFFBBBBBB), fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
            }
        }
        val s = selected
        // Dettagli del treno toccato: numero, impresa, ritardo e prossima fermata dalla scheda del treno
        var detail by remember { mutableStateOf<com.binario.treni.data.TrainStatus?>(null) }
        var detailLoading by remember { mutableStateOf(false) }
        LaunchedEffect(s) {
            detail = null
            val r = s?.ref ?: return@LaunchedEffect
            detailLoading = true
            detail = withContext(Dispatchers.IO) { runCatching { com.binario.treni.data.Api.status(r) }.getOrNull() }
            detailLoading = false
        }
        if (s != null) {
            val d = detail
            WhiteCard {
                Row(Modifier.fillMaxWidth().clickable(enabled = s.ref != null) { s.ref?.let(onTrain) }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(14.dp).clip(CircleShape).background(Color(if (d != null && !d.cancelled) dotColor(s.copy(delay = d.delay, known = d.departed || s.known)) else dotColor(s))))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        val head = if (d != null) d.title.ifBlank { s.title } else s.title
                        val to = if (d != null) d.destination.ifBlank { s.dest } else s.dest
                        Text(head + (if (to.isNotBlank()) " → " + to else ""), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2)
                        val op = d?.operator?.takeIf { it.isNotBlank() } ?: s.hub
                        Text((if (op.isNotBlank()) op + " · " else I18n.tr("Posizione GPS", "GPS position") + " · ") + Fmt.time(s.time) + (if (s.known) "  ·  " + (if (s.delay > 0) "+" else "") + s.delay + " min" else ""), color = Muted, fontSize = 12.sp)
                        if (d != null) {
                            val dl = when {
                                d.cancelled -> I18n.tr("Soppresso", "Cancelled")
                                d.delay > 0 -> "+" + d.delay + " min"
                                d.departed || s.known -> I18n.tr("In orario", "On time")
                                else -> I18n.tr("Ritardo n.d.", "Delay n.a.")
                            }
                            val nx = d.nextStop
                            Text(dl + (if (nx != null) "  ·  " + I18n.tr("Prossima fermata", "Next stop") + ": " + nx.name + " " + Fmt.time(if (nx.schedArr > 0) nx.schedArr else nx.schedDep) else ""),
                                color = Muted, fontSize = 12.sp, maxLines = 2)
                        } else if (detailLoading) {
                            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 4.dp), color = Green)
                        }
                    }
                    if (s.ref != null) Text(I18n.tr("Apri treno", "Open train") + " ›", color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        // Le note sulle fonti stanno chiuse: la mappa occupa tutto lo spazio (come in Treniamo)
        var showInfo by remember { mutableStateOf(false) }
        Row(
            Modifier.fillMaxWidth().clickable { showInfo = !showInfo }.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Info, null, tint = Muted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(I18n.tr("Info e fonti", "Info and sources"), color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Icon(if (showInfo) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp, null, tint = Muted)
        }
        if (showInfo) Column(Modifier.fillMaxWidth().heightIn(max = 240.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
            Text(
                I18n.tr("Lombardia: treni Trenord e FerrovieNord dall'orario ufficiale Trenord (Open Data Regione Lombardia), con il ritardo dal servizio live di Trenord.", "Lombardy: Trenord and FerrovieNord trains from Trenord's official timetable (Regione Lombardia Open Data), with the delay from Trenord's live service."),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
            )
            Text(
                I18n.tr(
                    "Germania, Austria, Svizzera e Francia: treni in marcia disposti sulla linea dagli orari e dal tempo reale pubblicati dalle aziende (Transitous); dove non c'è tempo reale la posizione segue l'orario.",
                    "Germany, Austria, Switzerland and France: running trains placed on the line from the timetable and the realtime data the companies publish (Transitous); where there is no realtime the position follows the timetable.",
                ),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
            )
            Text(
                I18n.tr(
                    "Ogni pallino è un treno in partenza da un nodo nella prossima ora. In Italia la posizione è stimata lungo la tratta dall'orario e dall'ultima fermata (poco dopo l'apertura i pallini si spostano sulla linea); altrove resta attorno al nodo: non è GPS. È un campione, non tutta la rete. Finlandia e Norvegia mostrano la posizione GPS reale (Digitraffic, Entur). Fonti: ViaggiaTreno, FFS (transport.opendata.ch), Transitous. Binari: © OpenStreetMap contributors, stile CC-BY-SA 2.0 OpenRailwayMap.",
                    "Each dot is a train departing from a hub in the next hour. In Italy the position is estimated along the route from the timetable and the last stop (shortly after opening the dots move onto the line); elsewhere it stays around the hub: not GPS. It is a sample, not the whole network. Finland and Norway show the real GPS position (Digitraffic, Entur). Sources: ViaggiaTreno, SBB (transport.opendata.ch), Transitous. Tracks: © OpenStreetMap contributors, style CC-BY-SA 2.0 OpenRailwayMap.",
                ),
                color = Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            )
        }
    }
}
