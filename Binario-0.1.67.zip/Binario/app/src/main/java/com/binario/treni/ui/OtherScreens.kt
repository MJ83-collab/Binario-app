package com.binario.treni.ui

import com.binario.treni.data.tx
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.text.style.TextDecoration
import com.binario.treni.data.ALL_CATEGORIES
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.NewsItem
import com.binario.treni.data.Notice
import com.binario.treni.data.Sources
import com.binario.treni.data.Strike
import com.binario.treni.data.SavedSearch
import com.binario.treni.service.Reminders
import com.binario.treni.service.TrackingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Scheda "Biglietti": acquisto e gestione sui siti ufficiali delle compagnie. */
@Composable
fun TicketsScreen(onBack: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Biglietti"), onBack)
        SectionHeader(tx("Acquista"))
        SimpleRow(Icons.Filled.ShoppingCart, "Trenitalia", tx("Frecce, Intercity e Regionali")) { openUrl(ctx, "https://www.lefrecce.it") }
        SimpleRow(Icons.Filled.ShoppingCart, "Italo", tx("Alta velocità NTV")) { openUrl(ctx, "https://www.italotreno.com") }
        SimpleRow(Icons.Filled.ShoppingCart, "Trenord", tx("Regionali Lombardia e Malpensa Express")) { openUrl(ctx, "https://www.trenord.it") }
        SectionHeader(tx("I miei biglietti"))
        SimpleRow(Icons.Filled.ConfirmationNumber, tx("Area personale Trenitalia"), tx("Biglietti, abbonamenti e QR code")) {
            openUrl(ctx, "https://www.lefrecce.it/Channels.Website.WEB/#/user-area/")
        }
        SimpleRow(Icons.Filled.EditCalendar, tx("Cambio prenotazione Trenitalia"), tx("Modifica data, ora o classe")) {
            openUrl(ctx, "https://www.lefrecce.it")
        }
        SimpleRow(Icons.Filled.ConfirmationNumber, tx("I miei viaggi Italo"), "") { openUrl(ctx, "https://www.italotreno.com") }
        Text(
            tx("L'acquisto avviene sul sito ufficiale della compagnia: l'acquisto diretto nell'app e la sincronizzazione ") +
                tx("dei biglietti richiedono un accordo commerciale con Trenitalia, Italo e Trenord."),
            style = MaterialTheme.typography.bodySmall, color = Color.Gray, modifier = Modifier.padding(16.dp),
        )
    }
}

/** Scheda "Altro": menu con notizie espandibili, come nell'app di riferimento. */
@Composable
fun MoreScreen(vm: MainViewModel, go: (String) -> Unit) {
    val ctx = LocalContext.current
    var tracked by remember { mutableStateOf(vm.store.tracked()) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Altro"))
        // Menu semplice: poche sezioni per argomento, e una sezione "Per azienda" che raccoglie tutto ciò che riguarda
        // una sola impresa (Trenord, FerrovieNord, Trenitalia, Italo, TILO). I sottomenu si aprono toccando la freccia.
        var open by remember { mutableStateOf<String?>(null) }
        fun toggle(k: String) { open = if (open == k) null else k }
        MenuRow(Icons.Filled.Map, com.binario.treni.data.I18n.tr("Mappa dei treni", "Train map"), tx("Pallini colorati per ritardo, zoom e «Vicino a me»")) { go("trainsmap") }

        // Schede nell'ordine scelto (modalità sviluppatore → Disposizione dell'app)
        val moreCards = remember { com.binario.treni.data.DevLayout.visible(ctx, com.binario.treni.data.DevLayout.MORE) }
        moreCards.forEach { card ->
            when (card) {
                "alpha" -> {
                Text(tx("App non ufficiale: non affiliata, sponsorizzata né approvata da Trenitalia, RFI, Italo, Trenord o altre aziende di trasporto. I dati provengono da fonti pubbliche."), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                if (IS_ALPHA) WhiteCard(onClick = { go("feedback?bug=true") }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("ALPHA", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            modifier = Modifier.background(Color(0xFFEF6C00), androidx.compose.foundation.shape.RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tx("Versione") + " " + APP_VERSION + " · " + tx("in prova"), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(tx("Alcune funzioni possono avere errori o cambiare. Tocca qui per segnalare un problema."), color = Muted, fontSize = 13.sp)
                        }
                    }
                }
                }
                "companies" -> {
                WhiteCard {
                    CardTitle(tx("Per azienda"))
                    MenuGroup(open == "trenord", { toggle("trenord") }, Icons.Filled.Train, "Trenord", tx("Linee, Malpensa Express, area STIBM, avvisi")) {
                        MenuRow(null, tx("Linee Trenord e FerrovieNord")) { go("lines") }
                        MenuRow(null, tx("Malpensa Express · tariffe"), tx("Prezzi da ogni stazione, linee, classi e limitazioni")) { go("malpensa?from=") }
                        MenuRow(null, tx("Area STIBM · Milano e Monza Brianza"), tx("Zone, prezzi e stazioni del biglietto integrato")) { go("stibm?name=") }
                        MenuRow(null, tx("Abbonamenti e biglietti Trenord")) { go("fares") }
                        MenuRow(null, tx("Avvisi Trenord"), "trenord.it") { openUrl(ctx, "https://www.trenord.it/news/trenord-informa/avvisi/") }
                        MenuRow(null, tx("Circolazione in tempo reale"), "trenord.it") { openUrl(ctx, "https://www.trenord.it/linee-e-orari/circolazione/tempo-reale/") }
                    }
                    MenuGroup(open == "fn", { toggle("fn") }, Icons.Filled.Train, "FerrovieNord", com.binario.treni.data.I18n.tr("Rete, ascensori fuori servizio, accessibilità, defibrillatori", "Network, lifts out of service, accessibility, defibrillators")) {
                        MenuRow(null, com.binario.treni.data.I18n.tr("Info rete FERROVIENORD", "FERROVIENORD network info"),
                            com.binario.treni.data.I18n.tr("Ascensori e scale mobili fuori servizio, accessibilità, assistenza, DAE, documenti", "Lifts and escalators out of service, accessibility, assistance, AEDs, documents")) { go("fn") }
                        MenuRow(null, tx("Linee della rete FerrovieNord")) { go("lines") }
                        MenuRow(null, tx("Puntualità FerrovieNord")) { go("stats") }
                        MenuRow(null, tx("Sito FerrovieNord"), "ferrovienord.it") { openUrl(ctx, "https://www.ferrovienord.it") }
                    }
                    MenuGroup(open == "trenitalia", { toggle("trenitalia") }, Icons.Filled.Train, "Trenitalia", tx("Infomobilità, treni garantiti, biglietti")) {
                        MenuRow(null, tx("Notizie infomobilità"), "trenitalia.com") { openUrl(ctx, Sources.TRENITALIA_INFO_URL) }
                        MenuRow(null, tx("Treni garantiti in caso di sciopero")) { go("guaranteed") }
                        MenuRow(null, tx("Biglietti"), "trenitalia.com") { go("tickets") }
                    }
                    MenuGroup(open == "italo", { toggle("italo") }, Icons.Filled.Train, "Italo", tx("Treni in tempo reale, contatti")) {
                        MenuRow(null, tx("Cerca un treno Italo per numero")) { go("capotreno") }
                        MenuRow(null, tx("Contatti e assistenza"), "italotreno.com") { openUrl(ctx, "https://www.italotreno.com/it/contatti-supporto") }
                    }
                    MenuGroup(open == "tilo", { toggle("tilo") }, Icons.Filled.Public, tx("TILO e Svizzera"), tx("Ticino–Lombardia, tariffe transfrontaliere")) {
                        MenuRow(null, tx("TILO · Ticino e Lombardia"), tx("Linee, tariffe transfrontaliere, servizi")) { go("tilo") }
                        MenuRow(null, tx("Confronta itinerari"), tx("Es. Varese → Como via Mendrisio o via Milano")) { go("compare") }
                        MenuRow(null, tx("Avvisi TILO"), "tilo.ch") { openUrl(ctx, "https://www.tilo.ch/avvisi.html") }
                    }
                    MenuRow(Icons.Filled.Public, tx("Treni in Germania"), tx("ICE, regionali, S-Bahn, Deutschlandticket, diritti e aziende")) { go("germany") }
                    MenuRow(Icons.Filled.Public, tx("Treni in Austria"), "ÖBB, Westbahn…") { go("austria") }
                    MenuRow(Icons.Filled.Public, tx("Treni in Francia"), "TGV, TER, Intercités…") { go("france") }
                    MenuRow(Icons.Filled.Apartment, tx("Tutte le imprese ferroviarie"), tx("Italia, Svizzera e Germania: siti, biglietti, dati")) { go("railways") }
                }
                }
                "station" -> {
                WhiteCard {
                    CardTitle(tx("In stazione e strumenti"))
                    // «Servizi in stazione» (WC, rivendite, bus sostitutivi, taxi, defibrillatori) è ora nella schermata Stazioni vicine
                    MenuRow(Icons.Filled.Route, tx("Tutte le linee"), tx("Trenord, TILO, FerrovieNord, Svizzera")) { go("lines") }
                    MenuRow(Icons.Filled.CompareArrows, tx("Confronta itinerari")) { go("compare") }
                    MenuRow(Icons.Filled.Eco, tx("Quanto sei green"), tx("Quanto risparmi in CO₂, carburante, pedaggi e tempo")) { go("green") }
                }
                }
                "a11y" -> {
                WhiteCard {
                    CardTitle(tx("Accessibilità"))
                    A11yQuickCard(vm.store, inSettings = true, onAssistance = { go("assistance") }, onExplore = { go("explore") })
                    MenuRow(Icons.Filled.Vibration, tx("Avvisi per persone sorde"),
                        if (vm.store.deafMode) tx("Attivi: vibrazione e flash") else tx("Disattivati")) { go("settings") }
                    MenuRow(Icons.Filled.Tune, tx("Tutte le opzioni di accessibilità")) { go("settings") }
                }
                }
                "app" -> {
                WhiteCard {
                    CardTitle(tx("App"))
                    MenuRow(Icons.Filled.Settings, tx("Impostazioni")) { go("settings") }
                    MenuRow(Icons.Filled.Widgets, "Widget") { go("widgets") }
                    MenuRow(Icons.Filled.Share, tx("Condividi Binario"), tx("Condivisione? Quando sarà il momento…")) { toast(ctx, tx("Condivisione? Quando sarà il momento…")) }
                    MenuRow(Icons.Filled.Feedback, tx("Feedback e segnala un bug"), tx("Scrivi allo sviluppatore: idee, suggerimenti, problemi")) { go("feedback?bug=false") }
                    MenuRow(Icons.Filled.QuestionMark, tx("Aiuto e FAQ")) { go("help") }
                    MenuGroup(open == "info", { toggle("info") }, Icons.Filled.Info, tx("Informazioni sull'app"), tx("Novità, correzioni, stato dei servizi, privacy")) {
                        MenuRow(
                            null, tx("Cerca aggiornamenti"),
                            if (ManualUpdate.checking) tx("Controllo in corso…") else tx("Versione") + " " + APP_VERSION,
                        ) { if (!ManualUpdate.checking) ManualUpdate.request++ }
                        MenuRow(null, "Changelog", tx("Novità di ogni versione")) { go("changelog") }
                        MenuRow(null, tx("Report correzioni"), tx("Problemi risolti in ogni versione")) { go("fixes") }
                        MenuRow(null, tx("Stato dei servizi"), tx("Controlla che tutte le fonti di dati rispondano")) { go("health") }
                        MenuRow(null, tx("Privacy e permessi")) { go("privacy") }
                        MenuRow(null, tx("Note legali"), tx("Versione") + " " + APP_VERSION) { go("legal") }
                    }
                }
                }
            }
        }
        Text(
            "Binario $APP_VERSION · " + tx(CREDIT), color = Muted, fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth().padding(20.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

/** Opzioni avanzate di ricerca: massimo cambi e categorie escluse. */
@Composable
fun AdvancedScreen(vm: MainViewModel, onBack: () -> Unit) {
    var max by remember { mutableIntStateOf(vm.maxChanges) }
    var ex by remember { mutableStateOf(vm.excluded) }
    var menu by remember { mutableStateOf(false) }
    fun label(m: Int) = when (m) {
        -1 -> tx("non definito")
        0 -> tx("nessun cambio (solo diretti)")
        else -> "$m"
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Opzioni avanzate"), onBack) {
            IconButton({ vm.saveAdvanced(max, ex); onBack() }) { Icon(Icons.Filled.Check, tx("Salva")) }
        }
        WhiteCard {
            CardTitle(tx("Max Cambi"))
            Box {
                Row(Modifier.fillMaxWidth().clickable { menu = true }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx("Max Cambi"), color = Muted, fontSize = 13.sp)
                        Text(label(max), fontSize = 17.sp)
                    }
                    Icon(Icons.Filled.ArrowDropDown, null, tint = Muted)
                }
                DropdownMenu(menu, { menu = false }) {
                    listOf(-1, 0, 1, 2, 3).forEach { m -> DropdownMenuItem({ Text(label(m)) }, { max = m; menu = false }) }
                }
            }
        }
        WhiteCard {
            CardTitle(tx("Escludi categorie"))
            Column(Modifier.padding(vertical = 8.dp)) {
                ALL_CATEGORIES.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { c ->
                            val off = c in ex
                            Box(
                                Modifier.weight(1f).clickable { ex = if (off) ex - c else ex + c }.padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    c, fontSize = 17.sp,
                                    color = if (off) Color(0xFFBDBDBD) else categoryColor(c),
                                    textDecoration = if (off) TextDecoration.LineThrough else null,
                                )
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Text(tx("Tocca una categoria per escluderla (barrata) o includerla."), color = Muted, fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            }
        }
    }
}

/** Impostazioni generali, notifiche, mappe, accessibilità, backup. */
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onThemeChange: (String) -> Unit, onLegal: () -> Unit = {}, onDev: () -> Unit = {}) {
    val ctx = LocalContext.current
    val store = vm.store
    var start by remember { mutableStateOf(store.startScreen) }
    var theme by remember { mutableStateOf(store.theme) }
    var kbd by remember { mutableStateOf(store.openKeyboard) }
    var buy by remember { mutableStateOf(store.showBuy) }
    var maps by remember { mutableStateOf(store.mapsEnabled) }
    var strikes by remember { mutableStateOf(store.strikeAlerts) }
    var strikesRoute by remember { mutableStateOf(store.strikeRouteOnly) }
    var routes by remember { mutableStateOf(store.routeAlerts) }
    var deaf by remember { mutableStateOf(store.deafMode) }
    var flash by remember { mutableStateOf(store.flashAlerts) }
    var blindLevel by remember { mutableStateOf(store.blindLevel) }
    val blind = blindLevel != "off"
    var stopsVoice by remember { mutableStateOf(store.announceStops) }
    var rate by remember { mutableStateOf(store.speechRate) }
    var changes by remember { mutableStateOf(store.changeAlerts) }
    var habitLearn by remember { mutableStateOf(store.habitLearning) }
    var habitAlerts by remember { mutableStateOf(store.habitAlerts) }
    var habitList by remember { mutableStateOf(store.habits()) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(tx("application/json"))) { uri ->
        if (uri != null) exportTo(ctx, uri, store)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFrom(ctx, uri, store)
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Impostazioni"), onBack)
        WhiteCard {
            CardTitle(tx("Generale"))
            ChoiceSetting(tx("Schermata all'avvio"), start, listOf("search" to tx("Cerca Orario"), "trains" to tx("Treni"), "stations" to tx("Stazioni"), "quick" to tx("Rapido"),
                "voice" to tx("Assistente vocale (microfono subito attivo)"))) {
                start = it; store.startScreen = it
            }
            ChoiceSetting(tx("Lingua"), com.binario.treni.data.I18n.lang, listOf("it" to "🇮🇹 Italiano", "en" to "🇬🇧 English", "zh" to "🇨🇳 中文", "de" to "🇩🇪 Deutsch", "fr" to "🇫🇷 Français", "es" to "🇪🇸 Español", "ja" to "🇯🇵 日本語")) {
                com.binario.treni.data.I18n.lang = it; store.lang = it
            }
            // Paese per emergenze: numero da chiamare, app di emergenza (AREU, Rega, nora) e mappe dei defibrillatori
            var emCountry by remember { mutableStateOf(com.binario.treni.data.Emergency.setting(ctx)) }
            ChoiceSetting(tx("Paese per emergenze e defibrillatori"), emCountry, listOf(
                "auto" to tx("Automatico (rete mobile)") + " · " + com.binario.treni.data.Emergency.fromNetwork(ctx).let { it.flag + " " + it.label },
                "it" to "🇮🇹 " + tx("Italia") + " · 112",
                "ch" to "🇨🇭 " + tx("Svizzera") + " · 144",
                "de" to "🇩🇪 " + tx("Germania") + " · 112",
            )) { emCountry = it; com.binario.treni.data.Emergency.setSetting(ctx, it) }
            ChoiceSetting(tx("Tema"), theme, listOf("system" to tx("Come il sistema"), "light" to tx("Verde chiaro"), "dark" to tx("Scuro"))) {
                theme = it; store.theme = it; onThemeChange(it)
            }
            ChoiceSetting(tx("Stile dell'app"), if (com.binario.treni.data.AppStyle.vintage) "vintage" else "classic",
                listOf("classic" to tx("Tradizionale"), "vintage" to tx("Vintage (tabellone a palette)"))) {
                store.boardStyle = it; com.binario.treni.data.AppStyle.vintage = it == "vintage"
            }
        }
        WhiteCard {
            CardTitle(tx("Cerca e Acquista"))
            SwitchSetting(tx("Apri tastiera in scelta stazione"), kbd) { kbd = it; store.openKeyboard = it }
            SwitchSetting(tx("Mostra pulsante Acquisto"), buy) { buy = it; store.showBuy = it }
        }
        WhiteCard {
            CardTitle(tx("Notifiche"))
            SwitchSetting(tx("Notifica scioperi"), strikes) { strikes = it; store.strikeAlerts = it }
            if (strikes) {
                val r = remember { com.binario.treni.data.RouteNews.defaultRoute(store, ctx) }
                SwitchSetting(tx("Solo scioperi della mia tratta"), strikesRoute,
                    if (r.from != null && r.to != null) r.label + (if (r.complete) " · " + tx("nei miei orari") else "") + " · " + tx("si cambia in Notizie › La mia tratta e orari")
                    else tx("Nessuna tratta scelta: imposta la tua tratta in Notizie › La mia tratta e orari. Intanto ricevi gli scioperi nazionali e della tua regione.")) {
                    strikesRoute = it; store.strikeRouteOnly = it
                }
                StrikeMuteSetting(store)
            }
            SwitchSetting(tx("Avvisi interruzioni su tratte, linee e treni preferiti"), routes) { routes = it; store.routeAlerts = it }
            SwitchSetting(tx("Treno seguito: avvisa se cambia binario o aumenta il ritardo"), changes) { changes = it; store.changeAlerts = it }
        }
        WhiteCard {
            CardTitle(tx("Il tuo prossimo treno"))
            SwitchSetting(tx("Impara i treni che prendo spesso"), habitLearn,
                tx("Dal tabellone, dalle soluzioni, da Segui e dai preferiti. Resta solo sul telefono.")) {
                habitLearn = it; store.habitLearning = it
            }
            SwitchSetting(tx("Avvisami da solo sul treno abituale"), habitAlerts,
                tx("Nei 45 minuti prima della partenza: ritardo, soppressione, cambio binario e alternative pronte")) {
                habitAlerts = it; store.habitAlerts = it
            }
            habitList.forEach { h ->
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(h.title + " · " + h.timeText, fontSize = 15.sp)
                        Text(h.board.name + (h.alight?.let { " → " + it.name } ?: "") + " · " + h.total + "×", color = Muted, fontSize = 12.sp)
                    }
                    IconButton({ store.removeHabit(h.key); habitList = store.habits() }) { Icon(Icons.Filled.Close, tx("Dimentica")) }
                }
            }
            if (habitList.isEmpty()) Text(tx("Ancora nessun treno abituale: compare dopo averlo aperto almeno due volte lo stesso giorno della settimana."),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        WhiteCard {
            CardTitle(tx("Accessibilità"))
            SwitchSetting(tx("Avvisi per persone sorde o ipoudenti"), deaf,
                tx("Vibrazione forte con schema diverso per ogni avviso: sveglia fermata (3 lunghe ripetute), promemoria (3 brevi ×2), interruzioni (2 lunghe)")) {
                deaf = it; store.deafMode = it
                if (it) com.binario.treni.service.Haptic.alert(ctx, com.binario.treni.service.Haptic.Kind.REMINDER)
            }
            if (deaf) SwitchSetting(tx("Lampeggio del flash negli avvisi"), flash) { flash = it; store.flashAlerts = it }
            ChoiceSetting(tx("Avvisi vocali per persone non vedenti o ipovedenti"), blindLevel, listOf(
                "off" to tx("Disattivati"),
                "stop" to tx("Solo fermata imminente"),
                "all" to tx("Tutti: binario, partenza, cambi, ritardi, fermate"),
            )) {
                blindLevel = it; store.blindLevel = it
                when (it) {
                    "all" -> com.binario.treni.service.Speech.say(ctx,
                        tx("Avvisi vocali attivi. Ti dirò il binario, la partenza e la fermata dove scendere."),
                        com.binario.treni.service.Speech.Sound.PLATFORM, force = true)
                    "stop" -> com.binario.treni.service.Speech.say(ctx,
                        tx("Ti avviserò con la voce solo quando la tua fermata è imminente."),
                        com.binario.treni.service.Speech.Sound.IMMINENT, force = true)
                }
            }
            Text(tx("La voce del telefono dice dove prendere il treno (binario), quando parte, i cambi di binario e i ritardi, e avvisa con un suono insistente quando la tua fermata è imminente."),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
            if (blindLevel == "all") SwitchSetting(tx("Annuncia ogni fermata del treno seguito"), stopsVoice) { stopsVoice = it; store.announceStops = it }
            if (blind) {
                ChoiceSetting(tx("Velocità della voce"), rate.toString(), listOf("0.8" to tx("Lenta"), "1.0" to tx("Normale"), "1.2" to tx("Veloce"))) {
                    rate = it.toFloat(); store.speechRate = rate
                    com.binario.treni.service.Speech.say(ctx, tx("Prova della voce."), null, force = true)
                }
                Text(tx("Prova i suoni: ognuno ha un significato diverso."), color = Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
                    listOf(
                        com.binario.treni.service.Speech.Sound.PLATFORM to tx("Binario"),
                        com.binario.treni.service.Speech.Sound.DEPART to tx("Partenza"),
                        com.binario.treni.service.Speech.Sound.IMMINENT to tx("Fermata imminente"),
                        com.binario.treni.service.Speech.Sound.ALERT to tx("Problema"),
                    ).forEach { (snd, label) ->
                        OutlinedButton({ com.binario.treni.service.Speech.say(ctx, label, snd, force = true) }, Modifier.padding(end = 6.dp)) { Text(label) }
                    }
                }
                Text(
                    tx("Per chiedere a voce: tieni premuta l'icona di Binario e scegli «Chiedi a voce» (puoi trascinarla sulla Home), " +
                        "oppure aggiungi il riquadro «Binario · Chiedi a voce» nelle Impostazioni rapide. Con l'assistente del telefono di' «Apri Binario». " +
                        "Funziona anche con TalkBack."),
                    color = Muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp),
                )
            }
            // Interruttori rapidi sì/no (gli stessi della Home)
            A11yQuickCard(store, inSettings = true, voiceKey = blindLevel) { blindLevel = it }
            var homeCard by remember { mutableStateOf(store.homeA11y) }
            SwitchSetting(tx("Mostra queste opzioni anche nella pagina Rapido"), homeCard) { homeCard = it; store.homeA11y = it }
            ChoiceSetting(tx("Colori per daltonici"), com.binario.treni.data.ColorBlind.mode, listOf(
                "off" to tx("Disattivato"),
                "redgreen" to tx("Rosso-verde (protanopia, deuteranopia)"),
                "tritan" to tx("Blu-giallo (tritanopia)"),
            )) {
                com.binario.treni.data.ColorBlind.mode = it; store.colorBlind = it
                com.binario.treni.widget.Widgets.refreshAll(ctx)
            }
            if (com.binario.treni.data.ColorBlind.on) Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("✓ " + tx("In orario"), color = OnTime, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(12.dp))
                Text("▲ +7'", color = LateRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(12.dp))
                listOf(com.binario.treni.data.Crowd.Level.LOW, com.binario.treni.data.Crowd.Level.MEDIUM, com.binario.treni.data.Crowd.Level.HIGH).forEach {
                    Text(it.symbol + " ", color = Color(it.color), fontSize = 16.sp)
                }
            }
        }
        WhiteCard {
            CardTitle(com.binario.treni.data.I18n.tr("Orologio e smartwatch", "Watch and smartwatch"))
            var watchOn by remember { mutableStateOf(store.watchStatus) }
            SwitchSetting(
                com.binario.treni.data.I18n.tr("Stato del treno seguito anche sull'orologio", "Followed train status on the watch too"), watchOn,
                com.binario.treni.data.I18n.tr(
                    "Invia una notifica normale (non fissa) quando cambiano ritardo, binario o prossima fermata, così Mi Band, Wear OS e gli altri orologi la mostrano.",
                    "Sends a normal (not pinned) notification when the delay, platform or next stop changes, so Mi Band, Wear OS and other watches show it.",
                ),
            ) { watchOn = it; store.watchStatus = it }
            OutlinedButton(
                {
                    com.binario.treni.service.Notif.createChannels(ctx)
                    com.binario.treni.service.Notif.post(
                        ctx, 9001, com.binario.treni.service.Notif.CH_ALERT, "🚆 Binario",
                        com.binario.treni.data.I18n.tr("Prova: se la vedi sull'orologio, è tutto a posto.", "Test: if you see this on your watch, all is well."),
                        com.binario.treni.service.Notif.openApp(ctx),
                    )
                },
                Modifier.padding(horizontal = 16.dp),
            ) { Text(com.binario.treni.data.I18n.tr("Invia notifica di prova", "Send a test notification")) }
            Text(
                com.binario.treni.data.I18n.tr(
                    "Binario non parla direttamente con l'orologio: le notifiche (avvisi, scioperi, cambi binario, ritardi, promemoria) arrivano al polso tramite l'app dell'orologio. " +
                        "Mi Band: in Mi Fitness o Zepp Life apri il dispositivo › Notifiche e promemoria › Avvisi delle app e attiva Binario. " +
                        "Wear OS: arrivano da sole (controlla nell'app Wear OS › Notifiche). In entrambi i casi imposta Binario su «nessuna restrizione» nella batteria. " +
                        "La notifica fissa del treno (con «Smetti di seguire») di solito non viene inoltrata: per questo ci sono gli avvisi separati qui sopra.",
                    "Binario does not talk to the watch directly: notifications (alerts, strikes, platform changes, delays, reminders) reach your wrist through the watch's own app. " +
                        "Mi Band: in Mi Fitness or Zepp Life open your device › Notifications and reminders › App alerts and turn on Binario. " +
                        "Wear OS: they arrive on their own (check in the Wear OS app › Notifications). In both cases set Binario to «no restrictions» in battery settings. " +
                        "The pinned train notification (with «Stop following») is usually not forwarded: that is why the separate alerts above exist.",
                ),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp),
            )
        }
        WhiteCard {
            CardTitle(tx("Posizione e Mappe"))
            SwitchSetting(tx("Disattiva Mappe"), !maps) { maps = !it; store.mapsEnabled = !it }
        }
        WhiteCard {
            CardTitle("Backup")
            MenuRow(null, tx("Esporta dati")) { exportLauncher.launch("binario-backup.json") }
            MenuRow(null, tx("Importa dati")) { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }
        }
        WhiteCard {
            CardTitle(tx("Legale"))
            MenuRow(Icons.Filled.Gavel, tx("Note legali"), tx("Versione") + " " + APP_VERSION) { onLegal() }
            Text(com.binario.treni.data.I18n.tr5(PRIVACY_TEXT, PRIVACY_TEXT_EN, PRIVACY_TEXT_ZH, PRIVACY_TEXT_DE, PRIVACY_TEXT_FR, PRIVACY_TEXT_ES, PRIVACY_TEXT_JA), fontSize = 13.sp, color = Muted, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        // Modalità sviluppatore: 7 tocchi su "Versione App", poi la password
        var taps by remember { mutableIntStateOf(0) }
        var askPassword by remember { mutableStateOf(false) }
        var devOn by remember { mutableStateOf(com.binario.treni.data.DevLayout.unlocked(ctx)) }
        if (askPassword) DevPasswordDialog(onDismiss = { askPassword = false }) {
            askPassword = false; devOn = true
            toast(ctx, "Modalità sviluppatore attiva")
            onDev()
        }
        WhiteCard(onClick = {
            if (!devOn) {
                taps++
                when {
                    taps >= 7 -> { taps = 0; askPassword = true }
                    taps >= 4 -> toast(ctx, "Ancora ${7 - taps} tocchi…")
                }
            }
        }) {
            CardTitle(tx("Versione App"))
            Text(APP_VERSION, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp))
            Text(tx(CREDIT), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
            if (devOn) MenuRow(Icons.Filled.DeveloperMode, "Modalità sviluppatore", "Disposizione dell'app: trascina e riordina") { onDev() }
        }
        Spacer(Modifier.height(16.dp))
    }
}

private fun exportTo(ctx: android.content.Context, uri: android.net.Uri, store: com.binario.treni.data.Store) {
    try {
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(store.exportJson().toByteArray()) }
        toast(ctx, tx("Backup salvato"))
    } catch (e: Exception) {
        toast(ctx, tx("Errore nel salvataggio"))
    }
}

private fun importFrom(ctx: android.content.Context, uri: android.net.Uri, store: com.binario.treni.data.Store) {
    try {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() } ?: ""
        toast(ctx, if (store.importJson(text)) tx("Dati importati") else tx("File non valido"))
    } catch (e: Exception) {
        toast(ctx, tx("File non valido"))
    }
}

@Composable
private fun SwitchSetting(title: String, value: Boolean, sub: String = "", onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 12.sp)
        }
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Green))
    }
}

/**
 * Silenzia le notifiche di sciopero per un tempo scelto dall'utente (1 ora … 1 mese, oppure fino a un giorno e un'ora).
 * Gli scioperi arrivati nel frattempo restano visibili in Notizie, ma non arrivano come notifica.
 */
@Composable
fun StrikeMuteSetting(store: com.binario.treni.data.Store) {
    val ctx = LocalContext.current
    var until by remember { mutableLongStateOf(store.strikeMuteUntil) }
    var open by remember { mutableStateOf(false) }
    val now = System.currentTimeMillis()
    val muted = until > now
    fun set(v: Long) { until = v; store.strikeMuteUntil = v }
    Row(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (muted) Icons.Filled.NotificationsOff else Icons.Filled.NotificationsActive, null, tint = if (muted) Color(0xFFEF6C00) else Green)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(tx("Silenzia gli avvisi di sciopero"), fontSize = 16.sp)
            Text(if (muted) tx("Silenziati fino al") + " " + Fmt.dayTime(until) else tx("Attivi · tocca per silenziarli per un po'"),
                color = if (muted) Color(0xFFEF6C00) else Muted, fontSize = 12.sp)
        }
        if (muted) TextButton({ set(0L) }) { Text(tx("Riattiva"), color = Green) }
    }
    if (open) {
        val h = 3_600_000L
        val options = listOf(
            tx("1 ora") to h, tx("3 ore") to 3 * h, tx("8 ore") to 8 * h, tx("1 giorno") to 24 * h,
            tx("3 giorni") to 72 * h, tx("1 settimana") to 7 * 24 * h, tx("1 mese") to 30 * 24 * h,
        )
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(tx("Silenzia gli avvisi di sciopero")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(tx("Per quanto tempo? Gli scioperi restano visibili in Notizie."), color = Muted, fontSize = 13.sp)
                    options.forEach { (label, d) ->
                        Text(label, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { set(System.currentTimeMillis() + d); open = false }.padding(vertical = 12.dp))
                    }
                    Text(tx("Fino a un giorno e un'ora…"), fontSize = 16.sp, color = Green, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth().clickable {
                            open = false
                            val c = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, 1) }
                            android.app.DatePickerDialog(ctx, { _, y, m, d ->
                                android.app.TimePickerDialog(ctx, { _, hh, mm ->
                                    val t = java.util.Calendar.getInstance().apply { set(y, m, d, hh, mm, 0); set(java.util.Calendar.MILLISECOND, 0) }.timeInMillis
                                    if (t > System.currentTimeMillis()) set(t) else toast(ctx, tx("Orario già passato"))
                                }, 8, 0, true).show()
                            }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).apply {
                                datePicker.minDate = System.currentTimeMillis() - 1000
                            }.show()
                        }.padding(vertical = 12.dp))
                }
            },
            confirmButton = { TextButton({ open = false }) { Text(tx("Chiudi"), color = Green) } },
        )
    }
}

@Composable
private fun ChoiceSetting(title: String, value: String, options: List<Pair<String, String>>, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Muted, fontSize = 13.sp)
                Text(options.firstOrNull { it.first == value }?.second ?: value, fontSize = 17.sp)
            }
            Icon(Icons.Filled.ArrowDropDown, null, tint = Muted)
        }
        DropdownMenu(open, { open = false }) {
            options.forEach { (k, v) -> DropdownMenuItem({ Text(v) }, { onChange(k); open = false }) }
        }
    }
}

const val APP_VERSION = "0.1.67-alpha"

/** Build in fase alpha: funzioni in prova, possono esserci errori. */
const val IS_ALPHA = true
const val CREDIT = "App creata da Marco Jannino"

const val HELP_TEXT = """Come cerco un orario?
Nella scheda Cerca scegli partenza e arrivo, data e ora, poi tocca Cerca. Tocca il nome di un treno (es. "TI FR 9627") per vedere ritardi, fermate e binari.

Come vedo il tabellone di una fermata?
Nella scheda del treno tocca una fermata e scegli "Partenze e arrivi da qui".

Come funziona la sveglia?
Nella scheda del treno tocca la fermata dove scendi e scegli "Svegliami prima di questa fermata". L'allarme suona quando il treno lascia la fermata precedente (o 4 minuti prima dell'arrivo previsto). Attiva "Avvisi per persone sorde" nelle Impostazioni per vibrazione forte e flash.

Come aggiungo una linea?
Scheda Treni → Linee preferite → Aggiungi, es. S5 con capolinea Varese e Treviglio.

Come configuro un widget?
Aggiungilo dalla Home e scegli cosa mostrare. Per cambiarlo, tocca il titolo del widget.

Come scarico l'orario per usarlo senza rete?
Cerca la tratta e nei risultati tocca l'icona PDF: scegli il giorno e se includere il ritorno. Il file si salva in Download/Binario e si apre anche offline. Inoltre l'app ricorda da sola gli ultimi orari di ogni tratta cercata.

Come dico all'app dove salgo?
Apri il treno, tocca la fermata dove sali e scegli "Salgo qui": binario, orario e avvisi (anche vocali) si riferiscono a quella fermata.

Come uso l'app senza vedere lo schermo?
In Impostazioni → Accessibilità scegli gli avvisi vocali (tutti o solo fermata imminente). Per chiedere a voce tieni premuta l'icona di Binario e scegli "Chiedi a voce", oppure usa il riquadro nelle Impostazioni rapide.

Perché un treno non ha prezzo o affollamento?
I prezzi arrivano da Trenitalia; l'affollamento solo da Trenord, quando disponibile.

Dove vedo i treni sulla mappa?
Apri «Mappa dei treni» dal menu (☰): parte con la sola Italia, poi puoi aggiungere altri paesi e l'app ricorda la scelta. Tocca un pallino per numero, azienda, ritardo e prossima fermata.

Dove trovo condizioni e tariffe di un'azienda?
Menu (☰) › Condizioni di trasporto › Condizioni e tariffe per azienda: apri l'azienda e tocca il link ufficiale. Sono indicati fonte e data di verifica.

Come invio un feedback?
Menu (☰) › Invia un feedback."""

const val CHANGELOG_TEXT = """0.1.67-alpha
• Corretto il link «pagina ufficiale della linea» di Trenord (dava «Access Denied»); verificati i link delle pagine linee TILO e delle direttrici Trenord. Registro novità e Report correzioni ripartiti da zero.

0.1.66-alpha
• Se l'invio del feedback non riesce, compare il pulsante «Invia via email» (indirizzo letto dal file di configurazione, non scritto nell'app).
"""

@Composable
fun SavedScreen(vm: MainViewModel, onBack: () -> Unit, onOpen: () -> Unit) {
    var list by remember { mutableStateOf(vm.store.savedSearches()) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Orari salvati offline"), onBack)
        if (list.isEmpty()) MessageBox(tx("Dopo una ricerca tocca l'icona di download per salvare gli orari."))
        LazyColumn {
            items(list, key = { it.key }) { s: SavedSearch ->
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.openSaved(s); onOpen() }.padding(start = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                            Text(s.title, fontWeight = FontWeight.Medium)
                            Text("${s.solutions.size} " + com.binario.treni.data.I18n.tr("soluzioni · salvato il ", "solutions · saved on ") + Fmt.dayTime(s.savedAt), color = Color.Gray, fontSize = 13.sp)
                        }
                        IconButton({ vm.store.deleteSaved(s.key); list = vm.store.savedSearches() }) {
                            Icon(Icons.Filled.Delete, tx("Elimina"), tint = Color.Gray)
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun RemindersScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(vm.store.reminders().sortedBy { it.at }) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Notifiche programmate"), onBack)
        if (list.isEmpty()) MessageBox(tx("Nessuna notifica. Usa \"Avvisami\" su un treno o una soluzione."))
        LazyColumn {
            items(list, key = { it.id }) { r ->
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Alarm, null, tint = Green)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                            Text(r.label, fontWeight = FontWeight.Medium)
                            Text(
                                com.binario.treni.data.I18n.tr("Avviso alle ", "Reminder at ") + Fmt.dayTime(r.at) + " · " + (if (r.arrival) com.binario.treni.data.I18n.tr("arrivo", "arrival") else com.binario.treni.data.I18n.tr("partenza", "departure")) + " " + Fmt.time(r.eventTime),
                                color = Color.Gray, fontSize = 13.sp,
                            )
                        }
                        IconButton({ Reminders.cancel(ctx, r.id); list = vm.store.reminders().sortedBy { it.at } }) {
                            Icon(Icons.Filled.Delete, tx("Elimina"), tint = Color.Gray)
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

/** Ultimi dati delle notizie in memoria: riaprendo la schermata si vedono subito, poi si aggiornano. */
object NewsCache {
    var strikes: List<Strike>? = null
    var notices: List<Notice>? = null
    var at: Long = 0L
    val details = HashMap<String, String>()
}

/** Scioperi (fonte ufficiale MIT) e comunicati delle aziende: circolazione, lavori, avvisi. Si aggiorna da sola ogni 5 minuti. */
@Composable
fun NewsScreen(onBack: () -> Unit, onGuaranteed: () -> Unit = {}) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var strikes by remember { mutableStateOf(NewsCache.strikes) }
    var strikesFailed by remember { mutableStateOf(false) }
    var notices by remember { mutableStateOf(NewsCache.notices) }
    var updatedAt by remember { mutableStateOf(NewsCache.at) }
    var refreshing by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<Notice?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val store = remember { com.binario.treni.data.Store(ctx) }
    var filter by remember { mutableStateOf(store.newsFilter) }
    var route by remember { mutableStateOf(com.binario.treni.data.RouteNews.defaultRoute(store, ctx)) }
    var editRoute by remember { mutableStateOf(false) }
    // Aggiornamento automatico: subito (se i dati hanno più di 2 minuti) e poi ogni 5 minuti finché la schermata è aperta
    val fg = rememberForeground()
    LaunchedEffect(Unit) {
        if (System.currentTimeMillis() - NewsCache.at > 2 * 60_000L) tick++
        while (true) {
            kotlinx.coroutines.delay(5 * 60_000L)
            waitForeground(fg)
            tick++
        }
    }
    LaunchedEffect(tick) {
        if (tick == 0) return@LaunchedEffect
        refreshing = true
        coroutineScope {
            launch {
                try {
                    val l = withContext(Dispatchers.IO) { Sources.railStrikes() }
                    strikes = l; NewsCache.strikes = l; strikesFailed = false
                } catch (e: Exception) {
                    if (strikes == null) strikesFailed = true
                }
            }
            launch {
                val l = withContext(Dispatchers.IO) { Sources.allNotices() }
                if (l.isNotEmpty() || notices == null) { notices = l; NewsCache.notices = l }
            }
        }
        NewsCache.at = System.currentTimeMillis()
        updatedAt = NewsCache.at
        refreshing = false
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Notizie"), onBack) { IconButton({ tick++ }, enabled = !refreshing) { Icon(Icons.Filled.Refresh, tx("Aggiorna ora")) } }
        GreenTabs(listOf(tx("Scioperi"), tx("Circolazione"), tx("Lavori"), tx("Tutti")), tab) { tab = it }
        if (refreshing) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (updatedAt > 0) tx("Aggiornato alle") + " " + Fmt.time(updatedAt) + " · " + tx("si aggiorna da solo ogni 5 minuti o trascinando giù")
                else tx("Caricamento…"),
                color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f),
            )
            TextButton({ tick++ }, enabled = !refreshing) { Text(tx("Aggiorna ora"), color = Green) }
        }
        NewsFilterBar(filter, route, onFilter = { f ->
            filter = f; store.newsFilter = f
            if (f == "route" && !route.complete) editRoute = true
        }, onEdit = { editRoute = true }, onRegions = { g ->
            route = route.copy(regions = g); store.setMyRoute(route)
        })
        val rn = com.binario.treni.data.RouteNews
        fun keepStrike(st: Strike): Boolean = when (filter) {
            "region" -> rn.inRegion(st, route.regions)
            "route" -> route.complete && rn.affectsRoute(st, route)
            else -> true
        }
        fun keepNotice(n: Notice): Boolean = when (filter) {
            "region" -> rn.noticeInRegion(n, route.regions)
            "route" -> route.complete && rn.noticeForRoute(n, route)
            else -> true
        }
        PullRefresh(refreshing, { tick++ }) { LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 6.dp)) {
            if (tab == 0) {
                // Silenzia le notifiche di sciopero per un tempo scelto (anche da Impostazioni › Notifiche)
                if (store.strikeAlerts) item { WhiteCard { StrikeMuteSetting(store) } }
                val l = strikes?.filter { keepStrike(it) }
                when {
                    strikesFailed -> item { MessageBox(tx("Osservatorio scioperi non raggiungibile in questo momento")) }
                    l == null -> item { LoadingBox() }
                    l.isEmpty() -> item {
                        MessageBox(when (filter) {
                            "route" -> tx("Nessuno sciopero proclamato tocca la tua tratta nei tuoi orari") + " (" + route.label + ")"
                            "region" -> tx("Nessuno sciopero proclamato nella tua regione") + " (" + route.regions.joinToString() + ")"
                            else -> tx("Nessuno sciopero ferroviario proclamato")
                        })
                    }
                    else -> items(l) { st -> StrikeCard(st, if (filter == "route" && route.complete) rn.affectedTrips(st, route) else emptyList()) }
                }
                // Germania: notizie sugli scioperi dei treni (non c'è un calendario ufficiale)
                item { GermanStrikesCard() }
                item {
                    WhiteCard(onClick = onGuaranteed) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.EventAvailable, null, tint = Green)
                            Spacer(Modifier.width(12.dp))
                            Text(tx("Treni garantiti: elenchi ufficiali aggiornati"), Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            Icon(Icons.Filled.ChevronRight, null, tint = Muted)
                        }
                    }
                }
                // Comunicati delle aziende sugli scioperi (treni garantiti ecc.)
                val comm = notices.orEmpty().filter { it.kind == Notice.Kind.STRIKE && keepNotice(it) }
                if (comm.isNotEmpty()) {
                    item { SectionHeader(tx("Comunicati delle aziende")) }
                    items(comm) { n -> NoticeCard(n) { open = n } }
                }
            } else {
                val l = notices
                val kind = when (tab) {
                    1 -> Notice.Kind.BLOCKED
                    2 -> Notice.Kind.WORKS
                    else -> null
                }
                when {
                    l == null -> item { LoadingBox() }
                    else -> {
                        val f = (if (kind == null) l else l.filter { it.kind == kind }).filter { keepNotice(it) }
                        if (f.isEmpty()) item {
                            MessageBox(
                                (if (tab == 1) tx("Nessuna anomalia di circolazione segnalata") else tx("Nessun avviso")) +
                                    (if (filter == "region") " (" + route.regions.joinToString() + ")" else ""),
                            )
                        }
                        items(f) { n -> NoticeCard(n) { open = n } }
                    }
                }
                item {
                    Column(Modifier.padding(horizontal = 8.dp)) {
                        SectionHeader(tx("Siti ufficiali"))
                        TextButton({ openUrl(ctx, "https://www.trenord.it/linee-e-orari/circolazione/tempo-reale/") }) { Text(tx("Trenord · circolazione in tempo reale"), color = Green) }
                        TextButton({ openUrl(ctx, Sources.TRENITALIA_INFO_URL) }) { Text(tx("Trenitalia · notizie infomobilità"), color = Green) }
                        TextButton({ openUrl(ctx, "https://www.ferrovienord.it") }) { Text("FerrovieNord", color = Green) }
                        TextButton({ openUrl(ctx, "https://www.tilo.ch/avvisi.html") }) { Text(tx("TILO · avvisi"), color = Green) }
                    }
                }
            }
        } }
    }
    open?.let { n -> NoticeDialog(n) { open = null } }
    if (editRoute) MyRouteDialog(route, onDismiss = { editRoute = false }) { r ->
        route = r; store.setMyRoute(r); editRoute = false
    }
}

/** Dettaglio di un comunicato: testo completo letto dalla pagina della fonte, con link diretto. */
@Composable
private fun NoticeDialog(n: Notice, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var full by remember(n.url, n.title) { mutableStateOf(NewsCache.details[n.url + n.title]) }
    var loading by remember(n.url, n.title) { mutableStateOf(false) }
    LaunchedEffect(n.url, n.title) {
        // Il testo dell'elenco è già completo per Trenitalia; per gli altri leggiamo la pagina del comunicato
        if (full == null && n.text.length < 400 && n.url.isNotBlank() && !n.url.endsWith(".pdf", true) &&
            n.url != Sources.TRENITALIA_INFO_URL
        ) {
            loading = true
            val t = withContext(Dispatchers.IO) { runCatching { Sources.noticeDetail(n.url) }.getOrDefault("") }
            if (t.isNotBlank()) { full = t; NewsCache.details[n.url + n.title] = t }
            loading = false
        }
    }
    val body = full?.takeIf { it.length > n.text.length } ?: n.text
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(n.title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("${n.kind.label} · ${n.date.ifBlank { tx("data non indicata") }}", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                if (body.isNotBlank()) Text(body, lineHeight = 20.sp)
                else if (!loading) Text(tx("Il testo completo è disponibile sul sito della fonte."), color = Muted)
                Spacer(Modifier.height(12.dp))
                SourceLink(n.source, n.url)
            }
        },
        confirmButton = { TextButton({ openUrl(ctx, n.url); onClose() }) { Text(tx("Apri la fonte"), color = Green) } },
        dismissButton = {
            TextButton({ shareText(ctx, n.title + (if (n.date.isNotBlank()) " (" + n.date + ")" else "") + "\n" + body.take(800) + "\n" + tx("Fonte") + ": " + n.url) }) {
                Text(tx("Condividi"))
            }
        },
    )
}

/** "Fonte: nome · sito ↗", toccabile: apre il link diretto. */
@Composable
fun SourceLink(name: String, url: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    if (url.isBlank()) return
    val site = Regex("^https?://(?:www\\.)?([^/]+)").find(url)?.groupValues?.get(1) ?: url
    Row(
        modifier.clickable { openUrl(ctx, url) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Link, null, tint = Green, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(tx("Fonte") + ": " + (if (name.isNotBlank() && !site.contains(name.substringBefore(" ").lowercase())) "$name · " else "") + site,
            color = Green, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StrikeCard(s: Strike, trips: List<com.binario.treni.data.RouteNews.Trip> = emptyList()) {
    val ctx = LocalContext.current
    val national = s.relevance.contains("nazional", true)
    WhiteCard(onClick = {
        shareText(ctx, "${s.title}\n${tx("Orari")}: ${s.modality}\n${tx("Chi")}: ${s.company}\n${tx("Dove")}: ${s.region}\n" +
            tx("Fonte") + ": " + s.url)
    }) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Warning, null, tint = LateRed, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(tx("Sciopero") + " " + s.start + (if (s.end.isNotBlank() && s.end != s.start) " → ${s.end}" else ""),
                    fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(s.relevance.uppercase(), color = if (national) LateRed else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            StrikeLine(tx("Orari"), s.modality)
            StrikeLine(tx("Chi"), s.company)
            StrikeLine(tx("Dove"), s.region + if (s.province.isNotBlank() && s.province != "Tutte") " (${s.province})" else "")
            StrikeLine(tx("Settore"), s.sector)
            StrikeLine(tx("Sindacati"), s.unions)
            if (s.note.isNotBlank()) StrikeLine(tx("Note"), s.note)
            if (trips.isNotEmpty()) {
                Text("🚆 " + tx("I tuoi treni durante lo sciopero"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LateRed,
                    modifier = Modifier.padding(top = 8.dp))
                trips.forEach { t -> Text("• " + com.binario.treni.data.RouteNews.describe(t), fontSize = 14.sp) }
                Text(tx("Nelle fasce garantite (feriali 6–9 e 18–21) i treni regionali circolano. Fuori fascia controlla l'elenco dei treni garantiti della tua impresa."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
            SourceLink(s.sourceName, s.url, Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun StrikeLine(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.padding(top = 3.dp)) {
        Text("$label: ", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 14.sp)
    }
}

@Composable
private fun NoticeCard(n: Notice, onClick: () -> Unit) {
    WhiteCard(onClick = onClick) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val col = when (n.kind) {
                    Notice.Kind.STRIKE, Notice.Kind.BLOCKED -> LateRed
                    Notice.Kind.WORKS -> Color(0xFFEF6C00)
                    Notice.Kind.OTHER -> Muted
                }
                Text(n.kind.label.uppercase(), color = col, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(n.date, color = Muted, fontSize = 12.sp)
            }
            Text(n.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.padding(top = 2.dp))
            if (n.text.isNotBlank()) Text(n.text.take(220) + if (n.text.length > 220) "…" else "", color = Muted, fontSize = 13.sp)
            SourceLink(n.source, n.url, Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun InfoScreen(title: String, body: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        GreenTopBar(title, onBack)
        Text(body, modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp), lineHeight = 22.sp)
    }
}

/** Report delle correzioni: per ogni versione, i problemi trovati e come sono stati risolti. */
const val CHANGELOG_TEXT_EN = """0.1.67-alpha
• Fixed the Trenord “official line page” link (it showed “Access Denied”); checked the TILO line pages and Trenord route links. Changelog and Fixes report restarted from scratch.

0.1.66-alpha
• If sending feedback fails, an “Send by email” button appears (address read from the configuration file, not written in the app).
"""

const val FIXES_TEXT = """2.4 · IN LAVORAZIONE
• Correzioni in corso: verranno elencate qui al rilascio
"""

const val WIDGETS_TEXT = """Tieni premuto su uno spazio vuoto della schermata Home → Widget → Binario, poi scegli cosa mostrare. Tocca il titolo del widget per cambiarlo.

• Tragitto / Linea: i prossimi treni di una tratta o di una linea preferita (es. S5), con ritardo e binario.
• Treno: l'andamento di un treno fermata per fermata.
• Stazione: le partenze da una stazione a scelta.
• Preferiti: lo stato di tutti i treni preferiti in un colpo solo.

Tocca una riga per aprire il treno o il tabellone.

Tocca ⟳ sul widget per aggiornarlo; si aggiorna da solo ogni 30 minuti."""

const val PRIVACY_TEXT = """Informativa sulla privacy (GDPR) · aggiornata a novembre 2026

Titolare del trattamento: Marco Jannino, sviluppatore indipendente di Binario. Contatto: «Feedback e segnala un bug» nell'app.

In breve
• Nessun account, nessuna pubblicità, nessuno strumento di statistiche o tracciamento. Binario non ha un proprio server e non riceve i tuoi dati.
• Preferiti, ricerche recenti, treni abituali, promemoria, impostazioni e registro «green» restano solo sul telefono. Si cancellano disinstallando l'app o dalle impostazioni di Android.

Servizi esterni
Per mostrare orari, ritardi e mappe l'app contatta direttamente i servizi pubblici: ViaggiaTreno (RFI/Trenitalia), LeFrecce, Italo, Trenord, FerrovieNord, TILO, FFS/SBB, DB, Transitous, TrovaTreno, Osservatorio scioperi del MIT, OpenStreetMap (mappe, Overpass, Nominatim, OSRM) e simili. Come qualsiasi sito web, ricevono il tuo indirizzo IP e i dati della richiesta (ad esempio stazione o numero del treno) e li trattano secondo le proprie informative. Binario non li invia a nessun altro.

Posizione
Solo se concedi il permesso e solo nelle schermate che la usano (stazioni vicine, rivendite, servizi). Per cercare i luoghi vicini le coordinate sono inviate ai server di OpenStreetMap (Overpass), che ricevono anche il tuo IP. Binario non le salva e non usa la posizione in background.

Feedback
Se invii «Feedback e segnala un bug», nome, email e messaggio (e, se lo scegli, versione dell'app e modello del telefono) arrivano a un modulo Google dello sviluppatore e servono solo per risponderti; Google tratta quei dati per conto dello sviluppatore. L'indirizzo del modulo è letto da un file pubblico su GitHub. Senza rete il messaggio resta sul telefono e parte appena possibile. Viene conservato finché serve a gestire la richiesta: puoi chiederne la cancellazione.

Aggiornamenti
L'app controlla su GitHub se esiste una versione nuova (all'apertura e circa ogni ora in background, con una notifica se c'è) e, se accetti, scarica da lì l'APK (GitHub riceve il tuo IP). Per installarlo Android chiede il permesso «installa app sconosciute».

Voce
Gli avvisi vocali usano la sintesi vocale del telefono, senza inviare dati. Le domande a voce passano dal riconoscimento vocale del telefono (di solito Google): Binario non chiede il permesso del microfono.

Permessi
• Notifiche: notifica fissa del treno, promemoria e avvisi scioperi (programmati sul telefono, senza server di notifiche).
• Servizio in primo piano, blocco stand-by e ottimizzazione batteria: per aggiornare il treno seguito senza che l'app venga sospesa.
• Esecuzione all'avvio, sveglie e promemoria: per riattivare e consegnare in orario le notifiche programmate.
• Posizione: stazioni e servizi vicini, mappa.
• Installa app sconosciute: solo per aggiornare Binario.
• Vibrazione.

Base giuridica e diritti
Il solo trattamento fatto dallo sviluppatore (il feedback) si basa sul tuo consenso, cioè sull'invio del messaggio. Hai diritto di accesso, rettifica, cancellazione, limitazione, opposizione e portabilità (artt. 15-22 GDPR): scrivi dall'app. Puoi presentare reclamo al Garante per la protezione dei dati personali (garanteprivacy.it). Per i dati trattati dai servizi esterni rivolgiti a loro.

Questa app non è affiliata a Trenitalia, RFI, Italo o Trenord."""

const val WIDGETS_TEXT_EN = """Long-press an empty area of the Home screen → Widgets → Binario, then choose what to show. Tap the widget title to change it.

• Route / Line: next trains on a route or favourite line (e.g. S5), with delay and platform.
• Train: a train's progress stop by stop.
• Station: departures from a station of your choice.
• Favourites: the status of all your favourite trains at a glance.

Tap a row to open the train or the departure board."""

const val HELP_TEXT_EN = """How do I search a timetable?
In the Search tab choose origin and destination, date and time, then tap Search. Tap a train name (e.g. "TI FR 9627") to see delays, stops and platforms.

How do I see the departure board of a stop?
In the train view tap a stop and choose "Departures and arrivals from here".

How does the wake-up alarm work?
In the train view tap the stop where you get off and choose "Wake me before this stop". The alarm rings when the train leaves the previous stop (or 4 minutes before the expected arrival). Turn on "Alerts for deaf or hard-of-hearing people" in Settings for strong vibration and flash.

How do I add a line?
Trains tab → Favourite lines → Add, e.g. S5 with termini Varese and Treviglio.

How do I set up a widget?
Add it from the Home screen and choose what to show. To change it, tap the widget title.

Can I ask questions?
Yes: open the train assistant (speech-bubble icon in Search) and ask e.g. "delay train 2070" or "trains from Varese to Milano".

Where do I see trains on the map?
Open “Train map” from the menu (☰): it starts with Italy only, then you can add other countries and the app remembers your choice. Tap a dot for number, operator, delay and next stop.

Where do I find a company's conditions and fares?
Menu (☰) › Conditions of carriage › Conditions and fares by company: open the company and tap the official link. Source and check date are shown.

How do I send feedback?
Menu (☰) › Send feedback."""

const val PRIVACY_TEXT_EN = """Privacy notice (GDPR) · updated November 2026

Data controller: Marco Jannino, independent developer of Binario. Contact: "Feedback and report a bug" in the app.

In short
• No account, no ads, no analytics or tracking tools. Binario has no server of its own and does not receive your data.
• Favourites, recent searches, usual trains, reminders, settings and the green log stay on your phone only. They are deleted by uninstalling the app or from Android settings.

External services
To show timetables, delays and maps the app contacts public services directly: ViaggiaTreno (RFI/Trenitalia), LeFrecce, Italo, Trenord, FerrovieNord, TILO, SBB, DB, Transitous, TrovaTreno, the Ministry's strike observatory, OpenStreetMap (maps, Overpass, Nominatim, OSRM) and similar. Like any website, they receive your IP address and the request data (e.g. station or train number) and handle them under their own policies. Binario sends them to no one else.

Location
Only if you grant permission and only on the screens that use it (nearby stations, ticket sellers, services). To find nearby places the coordinates are sent to OpenStreetMap servers (Overpass), which also receive your IP. Binario does not store them and does not use location in the background.

Feedback
If you send "Feedback and report a bug", name, email and message (and, if you choose, app version and phone model) go to a Google form owned by the developer and are used only to reply to you; Google processes that data on the developer's behalf. The form address is read from a public file on GitHub. Without a network the message stays on the phone and is sent as soon as possible. It is kept as long as needed to handle your request: you can ask for deletion.

Updates
The app checks GitHub for a new version (on opening and about every hour in the background, with a notification if there is one) and, if you accept, downloads the APK from there (GitHub receives your IP). To install it Android asks for the "install unknown apps" permission.

Voice
Spoken alerts use the phone's text-to-speech, sending no data. Voice questions go through the phone's speech recognition (usually Google): Binario does not ask for microphone permission.

Permissions
• Notifications: ongoing train notification, reminders and strike alerts (scheduled on the phone, no push server).
• Foreground service, wake lock and battery optimisation: to keep the followed train updated without the app being suspended.
• Run at startup, alarms and reminders: to restore and deliver scheduled notifications on time.
• Location: nearby stations and services, map.
• Install unknown apps: only to update Binario.
• Vibration.

Legal basis and rights
The only processing done by the developer (feedback) is based on your consent, i.e. sending the message. You have the right of access, rectification, erasure, restriction, objection and portability (Arts. 15-22 GDPR): write from the app. You can lodge a complaint with the Italian data protection authority (garanteprivacy.it). For data handled by external services, contact them.

This app is not affiliated with Trenitalia, RFI, Italo or Trenord."""

/** Note legali (italiano). La versione e l'autore sono inseriti dove la pagina viene mostrata. */
const val LEGAL_TEXT = """1. Chi siamo
Binario è un'app indipendente e gratuita, creata da Marco Jannino. Non è affiliata, sponsorizzata o approvata da Trenitalia, RFI, Gruppo FS, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB, né da altre aziende di trasporto o enti citati.

2. Marchi
Nomi, marchi e loghi delle aziende citate appartengono ai rispettivi titolari e sono usati solo per indicare la fonte delle informazioni o il servizio a cui si riferiscono. L'app non usa loghi ufficiali delle aziende.

3. Dati e affidabilità
Orari, ritardi, binari, soppressioni, prezzi, scioperi, avvisi, accessibilità, affollamento e statistiche provengono da fonti pubbliche di terze parti e sono mostrati "così come sono", senza garanzia di correttezza, completezza o aggiornamento. Possono contenere errori o ritardi di aggiornamento.
Fanno sempre fede le informazioni ufficiali delle aziende: tabelloni e annunci in stazione, personale, siti e app ufficiali.

4. Stime
Affollamento indicato con "≈", calcoli "Quanto sei green" (CO₂, carburante, pedaggi, tempi con traffico), confronto itinerari e tariffe transfrontaliere indicative sono stime a scopo informativo e non costituiscono offerta né garanzia di prezzo o di tempo di viaggio.

5. Biglietti e acquisti
L'app non vende biglietti né gestisce pagamenti. I pulsanti di acquisto aprono i siti ufficiali delle aziende, le cui condizioni di vendita e di trasporto si applicano integralmente. Condizioni, tariffe e diritti dei passeggeri di ogni azienda sono raccolti come link alle sue pagine ufficiali in «Condizioni di trasporto».

6. Limitazione di responsabilità
Nei limiti consentiti dalla legge, l'autore non è responsabile per danni diretti o indiretti derivanti dall'uso dell'app o dall'affidamento sulle sue informazioni, inclusi treni persi, coincidenze mancate, spese, sanzioni o disagi. Notifiche, promemoria e sveglia fermata possono non arrivare (risparmio energetico, assenza di rete, impostazioni del telefono): non usarli come unico sistema di allerta.
I diritti dei passeggeri (rimborsi, indennizzi, assistenza) vanno esercitati nei confronti dell'azienda di trasporto, secondo il Regolamento UE 2021/782 e le sue condizioni.

7. Privacy (GDPR)
L'app non richiede registrazione, non ha pubblicità, non ha strumenti di statistiche o tracciamento e non ha un proprio server: l'autore non riceve né vende dati personali. Preferiti, impostazioni, promemoria e registro "green" restano solo sul telefono e si cancellano disinstallando l'app.
Per funzionare l'app contatta direttamente i servizi delle fonti indicate: come per qualsiasi sito web, questi ricevono l'indirizzo IP e i dati della richiesta (es. stazione o numero di treno), secondo le loro informative.
La posizione si usa solo con il tuo permesso e solo nelle schermate che la richiedono (stazioni vicine, rivendite, servizi). Per trovare i luoghi vicini le coordinate sono inviate ai server di OpenStreetMap (Overpass); l'app non le salva e non le usa in background.
Il feedback inviato dall'app passa da un modulo Google dello sviluppatore, e gli aggiornamenti dell'app da GitHub. Dettagli, base giuridica e diritti: «Privacy e permessi».

8. Fonti dei dati (citate)
Tutte le informazioni provengono da fonti pubblicamente accessibili e consultabili gratuitamente da chiunque, senza registrazione, abbonamento o accordo commerciale. L'app non acquista dati, non usa servizi a pagamento e non rivende nulla: si limita a mostrare, citandone la fonte, ciò che le aziende e gli enti pubblicano.
• Orari, ritardi, binari previsti e reali: ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Soluzioni di viaggio e prezzi: LeFrecce – Trenitalia (lefrecce.it)
• Scioperi: Osservatorio sugli scioperi nei trasporti – Ministero delle Infrastrutture e dei Trasporti (scioperi.mit.gov.it)
• Avvisi, linee, affollamento, condizioni di trasporto: Trenord (trenord.it)
• Stato degli impianti e notizie: FerrovieNord (ferrovienord.it)
• Ascensori e accessibilità stazioni, Sala Blu: RFI (rfi.it)
• Orari dei bus sostitutivi Trenord: Open Data Regione Lombardia, feed GTFS ufficiale di Trenord, licenza CC BY 4.0 (dati.lombardia.it); se non è disponibile, in alternativa Transitous
• Orari regionali e locali di altre aziende e bus sostitutivi di altre aziende: Transitous (transitous.org), che raccoglie i feed GTFS pubblicati dalle aziende
• Treni Italo: italotreno.com
• Treni e servizi in Germania: Deutsche Bahn (bahn.de)
• Treni e servizi transfrontalieri: TILO (tilo.ch)
• Orario svizzero e affollamento previsto: transport.opendata.ch / opentransportdata.swiss (FFS/SBB)
• Tariffe Arcobaleno: Comunità tariffale Ticino e Moesano (arcobaleno.ch)
• Condizioni di trasporto, tariffe e diritti: pagine ufficiali di ogni azienda (vedi «Condizioni di trasporto»)
• Diritti dei passeggeri: Regolamento (UE) 2021/782 (eur-lex.europa.eu)
• Statistiche di puntualità: TrovaTreno.it – open data, licenza CC BY 4.0
• Prezzi carburanti: open data Ministero delle Imprese e del Made in Italy (mimit.gov.it), licenza IODL 2.0
• Mappe, rivendite, obliteratrici, ascensori: © OpenStreetMap contributors (openstreetmap.org), licenza ODbL
• Percorsi stradali: OSRM (project-osrm.org) su dati OpenStreetMap
• Software: osmdroid e componenti Android/Jetpack, licenza Apache 2.0

9. Gratuità e uso delle fonti
Binario è gratuita, senza pubblicità, senza acquisti in-app e senza scopo di lucro. Le fonti sono consultate come farebbe un normale utente dal proprio telefono, con richieste limitate e su azione dell'utente o a intervalli moderati; i contenuti restano di proprietà dei rispettivi titolari. Le pagine ufficiali sono mostrate integre nel lettore integrato o aprendo il sito originale.
Se un'azienda o un titolare di dati chiede di modificare o non mostrare più un contenuto, la funzione relativa verrà rimossa.

10. Contatti e segnalazioni
Per segnalazioni, richieste di rimozione o correzioni: contatta l'autore, Marco Jannino.
Per reclami sul servizio ferroviario rivolgiti all'azienda di trasporto interessata.

11. Modifiche
Queste note possono essere aggiornate con le nuove versioni dell'app. La versione in uso è indicata in alto. Ultimo aggiornamento: novembre 2026."""

const val LEGAL_TEXT_EN = """1. About
Binario is an independent, free app created by Marco Jannino. It is not affiliated with, sponsored or endorsed by Trenitalia, RFI, FS Group, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB, or any other transport company or body mentioned.

2. Trademarks
Company names and trademarks belong to their respective owners and are used only to identify the source of information or the service referred to. The app does not use official company logos.

3. Data and reliability
Timetables, delays, platforms, cancellations, fares, strikes, notices, accessibility, crowding and statistics come from public third-party sources and are provided "as is", without any warranty of accuracy, completeness or timeliness.
Official information always prevails: station boards and announcements, staff, official websites and apps.

4. Estimates
Crowding marked "≈", "How green are you" figures (CO₂, fuel, tolls, traffic times), route comparisons and indicative cross-border fares are estimates for information only and are not an offer or a guarantee of price or travel time.

5. Tickets and purchases
The app does not sell tickets or handle payments. Buy buttons open the operators' official websites, whose sales and carriage conditions fully apply. Each company's conditions, fares and passenger rights are collected as links to its official pages in "Conditions of carriage".

6. Limitation of liability
To the extent permitted by law, the author is not liable for any direct or indirect damage arising from the use of the app or reliance on its information, including missed trains or connections, costs, fines or inconvenience. Notifications, reminders and stop alarms may not arrive (battery saving, no network, phone settings): do not rely on them as your only alert.
Passenger rights (refunds, compensation, assistance) must be claimed from the transport operator under EU Regulation 2021/782 and its conditions.

7. Privacy (GDPR)
The app requires no registration, shows no ads, has no analytics or tracking tools and has no server of its own: the author neither receives nor sells personal data. Favourites, settings, reminders and the green log stay on your phone and are deleted when you uninstall the app.
To work, the app contacts the listed sources directly: like any website, they receive your IP address and the request data (e.g. station or train number), under their own privacy policies.
Location is used only with your permission and only on the screens that need it (nearby stations, ticket sellers, services). To find nearby places the coordinates are sent to OpenStreetMap servers (Overpass); the app does not store them or use them in the background.
Feedback sent from the app goes through a Google form owned by the developer, and app updates come from GitHub. Details, legal basis and rights: "Privacy & permissions".

8. Data sources (cited)
All information comes from publicly accessible sources that anyone can consult free of charge, without registration, subscription or commercial agreement. The app does not buy data, does not use paid services and resells nothing: it only shows, citing the source, what companies and public bodies publish.
• Timetables, delays, scheduled and actual platforms: ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Journey solutions and fares: LeFrecce – Trenitalia (lefrecce.it)
• Strikes: Transport Strike Observatory – Italian Ministry of Infrastructure and Transport (scioperi.mit.gov.it)
• Notices, lines, crowding, conditions of carriage: Trenord (trenord.it)
• Facility status and news: FerrovieNord (ferrovienord.it)
• Elevators and station accessibility, Sala Blu: RFI (rfi.it)
• Trenord replacement-bus timetables: Lombardy Region open data, official Trenord GTFS feed, CC BY 4.0 licence (dati.lombardia.it); if unavailable, Transitous as a fallback
• Regional and local timetables and replacement buses of other companies: Transitous (transitous.org), which collects the GTFS feeds published by the companies
• Italo trains: italotreno.com
• Trains and services in Germany: Deutsche Bahn (bahn.de)
• Cross-border trains and services: TILO (tilo.ch)
• Swiss timetable and expected crowding: transport.opendata.ch / opentransportdata.swiss (SBB)
• Arcobaleno fares: Ticino and Moesano fare network (arcobaleno.ch)
• Conditions of carriage, fares and rights: official pages of each company (see "Conditions of carriage")
• Passenger rights: Regulation (EU) 2021/782 (eur-lex.europa.eu)
• Punctuality statistics: TrovaTreno.it – open data, CC BY 4.0 licence
• Fuel prices: Italian Ministry of Enterprises and Made in Italy open data (mimit.gov.it), IODL 2.0 licence
• Maps, ticket sellers, validators, elevators: © OpenStreetMap contributors (openstreetmap.org), ODbL licence
• Road routes: OSRM (project-osrm.org) on OpenStreetMap data
• Software: osmdroid and Android/Jetpack components, Apache 2.0 licence

9. Free of charge and use of sources
Binario is free, ad-free, with no in-app purchases and non-profit. Sources are queried as a normal user would from their own phone, with limited requests, on user action or at moderate intervals; content remains the property of its owners. Official pages are shown unaltered in the built-in reader or by opening the original site.
If a company or data owner asks to change or stop showing some content, the related feature will be removed.

10. Contact
For reports, removal requests or corrections: contact the author, Marco Jannino.
For complaints about rail services, contact the transport operator concerned.

11. Changes
These notes may be updated with new app versions. The version in use is shown at the top. Last updated: November 2026."""

/** Pagina "Note legali": versione e autore in alto, poi il testo. */
@Composable
fun LegalScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        GreenTopBar(tx("Note legali"), onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("Binario · " + tx("versione") + " " + APP_VERSION, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(tx(CREDIT), color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Text(com.binario.treni.data.I18n.tr5(LEGAL_TEXT, LEGAL_TEXT_EN, LEGAL_TEXT_ZH, LEGAL_TEXT_DE, LEGAL_TEXT_FR, LEGAL_TEXT_ES, LEGAL_TEXT_JA), lineHeight = 21.sp, fontSize = 14.sp)
        }
    }
}

/** Avviso al primo avvio (e dopo aggiornamenti delle note): va accettato per usare l'app. */
@Composable
fun LegalConsent(store: com.binario.treni.data.Store, onOpenLegal: () -> Unit, onAccepted: () -> Unit = {}) {
    var accepted by remember { mutableStateOf(store.legalAccepted == LEGAL_VERSION) }
    if (accepted) return
    AlertDialog(
        onDismissRequest = {},
        title = { Text(tx("Prima di iniziare")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Binario " + APP_VERSION + " · " + tx(CREDIT), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(tx("Binario è un'app indipendente, non affiliata a Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO o SBB. I dati provengono da fonti pubbliche e possono contenere errori: fanno sempre fede tabelloni, annunci e canali ufficiali. Affollamento, costi e tempi stimati sono indicativi. Tutte le fonti sono pubbliche, gratuite e citate nelle note legali. L'app è gratuita, senza pubblicità, non vende biglietti e non raccoglie dati personali."))
                TextButton(onOpenLegal) { Text(tx("Leggi le note legali complete"), color = Green) }
            }
        },
        confirmButton = {
            Button({ store.legalAccepted = LEGAL_VERSION; accepted = true; onAccepted() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Text(tx("Ho capito e accetto"))
            }
        },
    )
}

const val LEGAL_VERSION = 3

/** Voce di menu che apre un sottomenu (freccia giù/su), con le voci rientrate. */
/**
 * Voci del Capotreno nella scheda Treni (sotto "Il mio Capotreno"): il tuo viaggio, notizie e scioperi, biglietti e prezzi.
 * Prima erano in "Altro".
 */
@Composable
fun CapotrenoMenuCard(vm: MainViewModel, go: (String) -> Unit) {
    val ctx = LocalContext.current
    var tracked by remember { mutableStateOf(vm.store.tracked()) }
    var open by remember { mutableStateOf<String?>(null) }
    fun toggle(k: String) { open = if (open == k) null else k }
    WhiteCard {
        tracked?.let { t ->
            MenuRow(Icons.Filled.Train, tx("Treno seguito") + ": " + t.label, tx("Apri lo stato in tempo reale")) {
                go("train?num=${android.net.Uri.encode(t.number)}&orig=${android.net.Uri.encode(t.originCode)}&date=${t.date}")
            }
            MenuRow(Icons.Filled.NotificationsOff, tx("Smetti di seguire") + " ${t.label}") { TrackingService.stop(ctx); tracked = null }
        }
        SubHeading(tx("Il tuo viaggio"))
        MenuRow(Icons.Filled.Mic, tx("Chiedi a voce"), tx("Assistente: treni, ritardi, binari, scioperi")) { go("bot?voice=true") }
        MenuRow(Icons.Filled.Luggage, tx("Oggetti smarriti"), tx("Cosa fare e chi contattare: Trenord, Trenitalia, Italo, FFS")) { go("lost") }
        MenuRow(Icons.Filled.Notifications, tx("Allarmi e orari salvati"), tx("Notifiche programmate, sveglie, orari offline")) { toggle("trip") }
        if (open == "trip") Column(Modifier.padding(start = 24.dp)) {
            MenuRow(Icons.Filled.Alarm, tx("Allarmi")) { go("reminders") }
            MenuRow(Icons.Filled.DownloadForOffline, tx("Orari salvati offline"), tx("Anche i PDF scaricati sono in Download/Binario")) { go("saved") }
        }
        SubHeading(tx("Notizie e scioperi"))
        MenuRow(Icons.Filled.Campaign, tx("Scioperi, circolazione e lavori"), tx("Anche solo per la tua tratta e i tuoi orari")) { go("news") }
        MenuRow(Icons.Filled.EventBusy, tx("Treni garantiti in caso di sciopero")) { go("guaranteed") }
        MenuRow(Icons.Filled.Map, com.binario.treni.data.I18n.tr("Mappa dei treni", "Train map"), tx("Pallini colorati per ritardo, zoom e «Vicino a me»")) { go("trainsmap") }
        MenuRow(Icons.Filled.Insights, tx("Puntualità"), tx("Regionali con regionali, alta velocità con alta velocità")) { go("stats") }
        SubHeading(tx("Biglietti e prezzi"))
        MenuRow(Icons.Filled.ConfirmationNumber, tx("Biglietti"), tx("Siti ufficiali di acquisto e area personale")) { go("tickets") }
        MenuRow(Icons.Filled.Euro, tx("Quanto costa il tuo abbonamento"), tx("Da A a B: abbonamenti e biglietti, anche verso la Svizzera")) { go("fares") }
        MenuRow(Icons.Filled.Storefront, tx("Punti vendita"), com.binario.treni.data.I18n.tr("Biglietterie, emettitrici, rivenditori · vicino o per provincia", "Ticket offices, machines, resellers · nearby or by province")) { go("sellers?id=&name=") }
        MenuRow(Icons.Filled.Gavel, tx("Diritti e rimborsi"), tx("Condizioni di trasporto, ritardi, indennizzi")) { go("conditions") }
        MenuRow(Icons.Filled.Pets, tx("Viaggiare con animali"), tx("Cani, gatti e trasportini: regole e prezzi per impresa")) { go("animals") }
    }

}

/** Sottotitolo dentro una scheda del menu (es. "Notizie e scioperi" dentro "Il mio Capotreno"). */
@Composable
private fun SubHeading(text: String) {
    Text(text, color = Green, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 2.dp))
}

@Composable
private fun MenuGroup(
    expanded: Boolean, onToggle: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String,
    content: @Composable () -> Unit,
) {
    MenuRow(icon, title, sub, trailing = {
        Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, if (expanded) tx("Chiudi") else tx("Apri"), tint = Muted)
    }, onClick = onToggle)
    if (expanded) Column(Modifier.padding(start = 24.dp)) { content() }
}

/** Testi lunghi in cinese (semplificato). Le note legali restano in inglese con un avviso: fa fede il testo originale. */
const val WIDGETS_TEXT_ZH = """长按主屏幕空白处 → 小组件 → Binario，然后选择要显示的内容。点击小组件标题可更改。

• 路线 / 线路：某条路线或常用线路（例如 S5）的下一班列车，含延误和站台。
• 列车：一趟列车逐站的运行情况。
• 车站：您所选车站的出发班次。
• 收藏：一眼看到所有收藏列车的状态。

点击一行可打开列车或时刻牌。"""

const val HELP_TEXT_ZH = """如何查询时刻表？
在“搜索”页选择出发地和目的地、日期和时间，然后点击“搜索”。点击列车名称（例如 "TI FR 9627"）可查看延误、停靠站和站台。

如何查看某一站的时刻牌？
在列车页面点击一个停靠站，选择“从这里出发和到达”。

到站闹钟如何使用？
在列车页面点击您下车的车站，选择“在此站前叫醒我”。列车离开前一站时（或预计到达前4分钟）闹钟会响。在设置中开启“聋人或听障人士提醒”可获得强振动和闪光。

如何添加线路？
“列车”页 → 常用线路 → 添加，例如 S5，终点站 Varese 和 Treviglio。

如何设置小组件？
在主屏幕添加并选择要显示的内容。要更改，请点击小组件标题。

可以提问吗？
可以：打开列车助手（搜索页中的对话气泡图标），例如问 "delay train 2070" 或 "trains from Varese to Milano"。助手目前能理解意大利语和英语的问题；车次也可以直接输入。

在哪里查看地图上的列车？
在菜单（☰）中打开“列车地图”：默认只显示意大利，之后可添加其他国家，应用会记住你的选择。点按圆点可查看车次、公司、晚点和下一站。

在哪里查看公司的条件和票价？
菜单（☰）› 运输条件 › 各公司条件与票价：打开公司后点按官方链接。会显示来源和核对日期。

如何发送反馈？
菜单（☰）› 发送反馈。"""

const val PRIVACY_TEXT_ZH = """隐私声明（GDPR）· 2026 年 11 月更新

数据控制者：Marco Jannino，Binario 的独立开发者。联系方式：应用内的“反馈与报告错误”。

简述
• 无账号、无广告、无统计或跟踪工具。Binario 没有自己的服务器，不会接收你的数据。
• 收藏、最近搜索、常乘列车、提醒、设置和“绿色”记录只保存在手机上，卸载应用或在 Android 设置中即可删除。

外部服务
为显示时刻表、晚点和地图，应用会直接连接公共服务：ViaggiaTreno（RFI/Trenitalia）、LeFrecce、Italo、Trenord、FerrovieNord、TILO、SBB、DB、Transitous、TrovaTreno、意大利交通部罢工观测站、OpenStreetMap（地图、Overpass、Nominatim、OSRM）等。与任何网站一样，它们会收到你的 IP 地址和请求数据（如车站或车次），并按各自的政策处理。Binario 不会把这些数据发给其他任何人。

位置
仅在你授权后，且仅在使用位置的页面（附近车站、售票点、服务）。为查找附近地点，坐标会发送到 OpenStreetMap 服务器（Overpass），对方也会收到你的 IP。Binario 不保存坐标，也不在后台使用位置。

反馈
如果你发送“反馈与报告错误”，姓名、邮箱和消息（以及你选择时的应用版本和手机型号）会发到开发者的 Google 表单，仅用于回复你；Google 代开发者处理这些数据。表单地址从 GitHub 上的公开文件读取。没有网络时消息保留在手机上，并在可能时尽快发送。信息保留至处理完你的请求为止，你可以要求删除。

更新
应用会在 GitHub 上检查新版本（打开时以及后台大约每小时一次，有新版本时发出通知），若你同意，则从那里下载 APK（GitHub 会收到你的 IP）。安装时 Android 会请求“安装未知应用”权限。

语音
语音提醒使用手机的语音合成，不发送数据。语音提问通过手机的语音识别（通常是 Google）：Binario 不请求麦克风权限。

权限
• 通知：列车常驻通知、提醒和罢工提醒（在手机上定时，没有推送服务器）。
• 前台服务、唤醒锁和电池优化：让被关注的列车保持更新而不被系统挂起。
• 开机启动、闹钟和提醒：恢复并按时发送定时通知。
• 位置：附近车站和服务、地图。
• 安装未知应用：仅用于更新 Binario。
• 振动。

法律依据与权利
开发者唯一进行的处理（反馈）基于你的同意，即发送消息。你有权访问、更正、删除、限制处理、反对和数据可携带（GDPR 第 15–22 条）：请在应用内联系。你可以向意大利数据保护机构（garanteprivacy.it）投诉。对于外部服务处理的数据，请直接联系对方。

本应用与 Trenitalia、RFI、Italo、Trenord 无任何关联。"""

const val LEGAL_NOTE_ZH = "法律声明暂无中文版本，以下为英文原文，以原文为准。\n\n"

const val CHANGELOG_TEXT_ZH = """0.1.67-alpha
• 修复了 Trenord“线路官方页面”链接（之前显示“Access Denied”）；已检查 TILO 线路页面和 Trenord 干线链接。更新日志和修复报告已从头开始。

0.1.66-alpha
• 如果反馈发送失败，会出现“通过电子邮件发送”按钮（地址从配置文件读取，不写在应用中）。
"""
