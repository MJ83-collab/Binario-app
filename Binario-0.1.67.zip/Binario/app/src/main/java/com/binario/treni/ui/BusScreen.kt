package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DirectionsBus
import androidx.compose.material.icons.outlined.DirectionsRailway
import androidx.compose.material.icons.outlined.Train
import androidx.compose.material.icons.outlined.Tram
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.Osm
import com.binario.treni.data.ReplacementBus
import com.binario.treni.data.Station
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

private fun tr(a: String, b: String) = I18n.tr(a, b)

private fun busGroup(op: String) = when {
    op.contains("Trenord", true) || op.contains("FerrovieNord", true) -> "trenord"
    op.contains("Trenitalia", true) -> "trenitalia"
    op.contains("TILO", true) || op.contains("FFS", true) -> "ffs"
    else -> "other"
}

/**
 * Bus sostitutivi in partenza da una stazione, in stile Trenord: dove si prende il bus (fermata e mappa), orario,
 * direzione, azienda e fonte di ogni corsa. Dati: orari ufficiali GTFS delle aziende via Transitous e tabellone ViaggiaTreno;
 * in fondo le pagine ufficiali di Trenord, RFI/Trenitalia, TILO e FFS.
 */
@Composable
fun BusScreen(vm: MainViewModel, initial: Station?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var station by remember { mutableStateOf(initial) }
    var center by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var buses by remember { mutableStateOf<List<ReplacementBus.Bus>?>(null) }
    var feedNotice by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf(tr("Cerco la stazione…", "Finding the station…")) }
    var errors by remember { mutableStateOf(0) }
    var showList by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    val groups = remember { mutableStateListOf<String>() }

    // Stazione: quella scelta, altrimenti la più vicina a me
    LaunchedEffect(station?.id) {
        val st = station
        if (st != null) {
            center = withContext(Dispatchers.IO) { Api.stationCoord(vm.store, st.id) }
            return@LaunchedEffect
        }
        if (!hasLocation(ctx)) { status = tr("Cerca una stazione o una città qui sopra.", "Search a station or town above."); return@LaunchedEffect }
        val l = currentLocation(ctx) ?: run { status = tr("Posizione non disponibile: cerca una stazione.", "Location not available: search a station."); return@LaunchedEffect }
        val near = withContext(Dispatchers.IO) {
            runCatching {
                Api.allStations(ctx).minByOrNull { g ->
                    val d = FloatArray(1); android.location.Location.distanceBetween(l.latitude, l.longitude, g.lat, g.lon, d); d[0]
                }
            }.getOrNull()
        }
        if (near != null) { station = near.station; center = near.lat to near.lon } else status = tr("Nessuna stazione trovata.", "No station found.")
    }
    LaunchedEffect(searching) {
        if (!searching) return@LaunchedEffect
        val q = query.trim()
        val found = withContext(Dispatchers.IO) {
            runCatching {
                val p = Osm.geocode(q, center).firstOrNull() ?: return@runCatching null
                Api.allStations(ctx).minByOrNull { g ->
                    val d = FloatArray(1); android.location.Location.distanceBetween(p.lat, p.lon, g.lat, g.lon, d); d[0]
                }
            }.getOrNull()
        }
        if (found != null) { station = found.station; center = found.lat to found.lon; query = "" }
        else status = tr("Luogo non trovato: prova con il nome della stazione.", "Place not found: try the station name.")
        searching = false
    }
    LaunchedEffect(station?.id, center, retry) {
        val st = station ?: return@LaunchedEffect
        val c = center
        buses = null
        status = tr("Cerco i bus sostitutivi a", "Looking for replacement buses at") + " ${st.name}…"
        var err = 0
        val got = withContext(Dispatchers.IO) {
            coroutineScope {
                val gtfs = async {
                    if (c == null) emptyList() else try { ReplacementBus.fromGtfs(c.first, c.second, st.id) } catch (e: Exception) { err++; emptyList() }
                }
                val board = async { try { ReplacementBus.fromBoard(st) } catch (e: Exception) { err++; emptyList() } }
                val g = gtfs.await()
                // Stessa corsa nei due elenchi (stessa ora e direzione simile): tengo quella con la fermata
                val b = board.await().filter { x -> g.none { y -> Math.abs(y.time - x.time) < 3 * 60_000L } }
                (g + b).sortedBy { it.time }
            }
        }
        errors = err
        feedNotice = withContext(Dispatchers.IO) { runCatching { com.binario.treni.data.TrenordGtfs.expiryNotice() }.getOrNull() }
        buses = got
    }

    val all = buses.orEmpty()
    val shown = all.filter { groups.isEmpty() || busGroup(it.operator) in groups }
    val counts = listOf("trenord", "trenitalia", "ffs", "other").associateWith { k -> all.count { busGroup(it.operator) == k } }
    val mapPts = shown.filter { !it.lat.isNaN() && !it.lon.isNaN() }.distinctBy { "${it.lat}|${it.lon}" }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tr("Bus sostitutivi", "Replacement buses") + (station?.let { " · ${it.name}" } ?: ""), onBack)
        TrenordSearchField(query, { query = it }, { if (query.isNotBlank()) searching = true }, placeholder = tr("Inserisci città o stazione", "Enter town or station"))
        TrenordChoiceGrid(
            listOf(
                TrenordChoice("trenord", "Trenord", Icons.Outlined.Train),
                TrenordChoice("trenitalia", "Trenitalia", Icons.Outlined.DirectionsRailway),
                TrenordChoice("ffs", "TILO / FFS", Icons.Outlined.Tram),
                TrenordChoice("other", tr("Altre aziende", "Other operators"), Icons.Outlined.DirectionsBus),
            ),
            isSelected = { it in groups }, counts = if (buses != null) counts else emptyMap(),
        ) { k -> if (k in groups) groups.remove(k) else groups.add(k) }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val b = buses
            when {
                b == null -> MessageBox(status)
                !showList && vm.store.mapsEnabled && mapPts.isNotEmpty() -> OsmMap(
                    mapPts.map { x ->
                        MapPoint(x.lat, x.lon, x.stopName.ifBlank { tr("Fermata bus sostitutivo", "Replacement bus stop") },
                            x.operator + " · " + shown.filter { it.lat == x.lat && it.lon == x.lon }.take(3).joinToString(", ") { Fmt.time(it.time) } +
                                "\n" + tr("Tocca di nuovo per le indicazioni", "Tap again for directions"),
                            glyph = "bus",
                        ) { openUrl(ctx, "https://www.google.com/maps/dir/?api=1&destination=${x.lat},${x.lon}&travelmode=walking") }
                    },
                    drawLine = false, modifier = Modifier.fillMaxSize(),
                    target = center?.let { MapPoint(it.first, it.second, station?.name.orEmpty(), tr("Stazione", "Station")) },
                    selected = -1,
                )
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                    item {
                        Text(tr("Bus sostitutivi nelle prossime 6 ore", "Replacement buses in the next 6 hours") + " · ${shown.size}",
                            fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 4.dp))
                        feedNotice?.let { n ->
                            Text(n, color = androidx.compose.ui.graphics.Color(0xFFEF6C00), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                        }
                        if (shown.isEmpty()) MessageBox(
                            if (errors >= 2) tr("I servizi orari non rispondono: riprova o guarda le pagine ufficiali qui sotto.", "Timetable services are not responding: retry or check the official pages below.")
                            else tr("Nessun bus sostitutivo previsto qui nelle prossime ore secondo gli orari ufficiali. In caso di guasti improvvisi i bus possono non essere ancora negli orari: controlla le pagine ufficiali e gli annunci in stazione.",
                                "No replacement buses scheduled here in the next hours according to official timetables. After sudden disruptions buses may not be in the timetables yet: check the official pages and station announcements."),
                        )
                        if (errors > 0) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            OutlinedButton({ retry++ }) { Text(tr("Riprova", "Retry"), color = Green) }
                        }
                    }
                    items(shown) { x -> BusCard(x, center) }
                    item {
                        SectionHeader(tr("Pagine ufficiali", "Official pages"))
                        ReplacementBus.officialPages().forEach { (name, url) -> SourceLink(name, url, Modifier.padding(horizontal = 16.dp, vertical = 2.dp)) }
                        Text(tr("Fonti: orari ufficiali GTFS di Trenord dagli Open Data della Regione Lombardia (in alternativa Transitous); Trenitalia e FFS tramite Transitous (transitous.org); bus nel tabellone da ViaggiaTreno (RFI). Ogni corsa indica la sua fonte. Gli orari sono programmati: in caso di disagi segui gli annunci in stazione.",
                            "Sources: official Trenord GTFS timetable from Lombardy Region open data (Transitous as a fallback); Trenitalia and SBB via Transitous (transitous.org); buses on the board from ViaggiaTreno (RFI). Each trip shows its source. Times are scheduled: during disruption follow station announcements."),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
                    }
                }
            }
            if (vm.store.mapsEnabled && b != null && mapPts.isNotEmpty()) {
                ShowListButton(showList, Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)) { showList = !showList }
            }
        }
    }
}

@Composable
private fun BusCard(x: ReplacementBus.Bus, station: Pair<Double, Double>?) {
    val ctx = LocalContext.current
    WhiteCard {
        Column(Modifier.padding(start = 12.dp, end = 14.dp, top = 12.dp, bottom = 6.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(Fmt.time(x.time), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Green, modifier = Modifier.width(72.dp))
                Column(Modifier.weight(1f)) {
                    Text(x.headsign.ifBlank { x.line }, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(x.operator + " · " + x.line, color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    if (x.delay > 0) Text("+${x.delay}′", color = LateRed, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
            Column(Modifier.padding(start = 72.dp, top = 4.dp)) {
                if (x.stopName.isNotBlank()) {
                    val d = if (station != null && !x.lat.isNaN()) {
                        val r = FloatArray(1); android.location.Location.distanceBetween(station.first, station.second, x.lat, x.lon, r); r[0].toInt()
                    } else null
                    Text(tr("Si prende a: ", "Board at: ") + x.stopName + (d?.let { " · " + (if (it < 1000) "$it m" else String.format("%.1f km", it / 1000.0)) + tr(" dalla stazione", " from the station") } ?: ""),
                        fontSize = 14.sp)
                }
                if (x.bay.isNotBlank()) Text(tr("Stallo / binario: ", "Bay / platform: ") + x.bay, fontSize = 14.sp)
                Text(if (x.realTime) tr("Tempo reale", "Real time") else tr("Orario programmato", "Scheduled time"), color = Muted, fontSize = 12.sp)
                Text(tr("Fonte: ", "Source: ") + x.source, color = Muted, fontSize = 11.sp)
                if (!x.lat.isNaN() && !x.lon.isNaN()) TrenordLink(tr("Ottieni indicazioni per la fermata", "Directions to the stop")) {
                    openUrl(ctx, "https://www.google.com/maps/dir/?api=1&destination=${x.lat},${x.lon}&travelmode=walking")
                }
            }
        }
    }
}
