package com.binario.treni.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n
import com.binario.treni.data.Store

private fun tr(a: String, b: String) = I18n.tr(a, b)

/**
 * Risparmio batteria: alcuni telefoni fermano anche il servizio che segue il treno.
 * Alla prima volta che si segue un treno l'app propone di escluderla dall'ottimizzazione batteria.
 */
object BatteryHelp {
    /** Da mostrare: impostato da TrackingService.start quando serve. */
    var pending by mutableStateOf(false)

    fun ignoring(ctx: Context): Boolean = try {
        ctx.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(ctx.packageName) == true
    } catch (_: Exception) {
        true
    }

    /** Da chiamare quando si inizia a seguire un treno: chiede una volta sola (e di nuovo se l'utente aveva rimandato). */
    fun maybeAsk(ctx: Context) {
        val s = Store(ctx)
        if (!ignoring(ctx) && !s.batteryAsked) pending = true
    }

    /** Apre la richiesta di sistema; se il telefono non la supporta, l'elenco dell'ottimizzazione o i dettagli dell'app. */
    fun request(ctx: Context) {
        val pkg = ctx.packageName
        val tries = listOf(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")),
        )
        for (i in tries) {
            try {
                ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return
            } catch (_: Exception) {
            }
        }
    }

    /** Consiglio specifico per marca: dove si trova l'opzione su quel telefono. */
    fun brandHint(): String {
        val m = Build.MANUFACTURER.lowercase()
        return when {
            "xiaomi" in m || "redmi" in m || "poco" in m -> tr("Su Xiaomi: Impostazioni → App → Binario → Risparmio batteria → Nessuna restrizione, e attiva anche \"Avvio automatico\".",
                "On Xiaomi: Settings → Apps → Binario → Battery saver → No restrictions, and also enable \"Autostart\".")
            "oppo" in m || "realme" in m || "oneplus" in m -> tr("Su Oppo, Realme e OnePlus: Impostazioni → App → Binario → Utilizzo batteria → consenti l'attività in background e l'avvio automatico.",
                "On Oppo, Realme and OnePlus: Settings → Apps → Binario → Battery usage → allow background activity and auto launch.")
            "huawei" in m || "honor" in m -> tr("Su Huawei e Honor: Impostazioni → Batteria → Avvio app → Binario → gestione manuale, con tutte e tre le opzioni attive.",
                "On Huawei and Honor: Settings → Battery → App launch → Binario → manage manually, with all three options on.")
            "samsung" in m -> tr("Su Samsung: Impostazioni → App → Binario → Batteria → Senza restrizioni, e togli Binario dalle \"App in sospensione\".",
                "On Samsung: Settings → Apps → Binario → Battery → Unrestricted, and remove Binario from \"Sleeping apps\".")
            "vivo" in m || "iqoo" in m -> tr("Su Vivo: Impostazioni → Batteria → Consumo energetico in background → consenti a Binario.",
                "On Vivo: Settings → Battery → Background power consumption → allow Binario.")
            else -> tr("Se il treno seguito si ferma da solo: Impostazioni → App → Binario → Batteria → Senza restrizioni.",
                "If the followed train stops by itself: Settings → Apps → Binario → Battery → Unrestricted.")
        }
    }
}

@Composable
fun BatteryDialog() {
    if (!BatteryHelp.pending) return
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    fun close() { BatteryHelp.pending = false; store.batteryAsked = true }
    AlertDialog(
        onDismissRequest = { close() },
        icon = { Icon(Icons.Filled.BatteryAlert, null, tint = Green) },
        title = { Text(tr("Avvisi anche con l'app chiusa", "Alerts even with the app closed")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(tr("Il treno è seguito anche con Binario chiuso. Alcuni telefoni però, per risparmiare batteria, fermano gli avvisi dopo un po'. Per non perdere binario, ritardi e sveglia, consenti a Binario di funzionare senza restrizioni di batteria: il consumo resta basso e si ferma da solo all'arrivo.",
                    "The train is followed even with Binario closed. Some phones, however, stop the alerts after a while to save battery. To avoid missing platform, delays and the wake-up alarm, allow Binario to run without battery restrictions: consumption stays low and it stops by itself on arrival."))
                Spacer(Modifier.height(8.dp))
                Text(BatteryHelp.brandHint(), color = Muted, fontSize = 13.sp)
                TextButton({ openUrl(ctx, "https://dontkillmyapp.com/" + Build.MANUFACTURER.lowercase()) }) {
                    Text(tr("Guida per il tuo telefono", "Guide for your phone"), color = Green)
                }
            }
        },
        confirmButton = {
            Button({ close(); BatteryHelp.request(ctx) }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr("Consenti", "Allow")) }
        },
        dismissButton = { TextButton({ close() }) { Text(tr("Non ora", "Not now")) } },
    )
}
