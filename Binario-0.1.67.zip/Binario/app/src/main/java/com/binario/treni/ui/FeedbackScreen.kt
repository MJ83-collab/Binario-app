package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Feedback
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "Feedback e segnala un bug": nome e cognome, email, tipo di messaggio e testo. */
@Composable
fun FeedbackScreen(onBack: () -> Unit, initialBug: Boolean = false) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(Feedback.lastName(ctx)) }
    var email by remember { mutableStateOf(Feedback.lastEmail(ctx)) }
    var bug by remember { mutableStateOf(initialBug) }
    var text by remember { mutableStateOf("") }
    var withTech by remember { mutableStateOf(true) }
    var sending by remember { mutableStateOf(false) }
    var tried by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    var mailTo by remember { mutableStateOf("") }
    var mailBody by remember { mutableStateOf("") }
    var blocked by remember { mutableStateOf<String?>(null) }
    val openedAt = remember { System.currentTimeMillis() }

    // ---- Feedback a voce (persone non vedenti): domande lette ad alta voce e risposte dettate ----
    var voiceStep by remember { mutableStateOf<String?>(null) } // type, name, email, text, confirm
    var listenTick by remember { mutableIntStateOf(0) }
    fun say(t: String) = com.binario.treni.service.Speech.say(ctx, t, com.binario.treni.service.Speech.Sound.INFO, force = true)
    fun ask(step: String, prompt: String) {
        voiceStep = step
        say(prompt)
        listenTick++
    }
    fun next(after: String) {
        when (after) {
            "type" -> if (name.trim().length >= 3) next("name") else ask("name", tx("Come ti chiami? Dimmi nome e cognome."))
            "name" -> if (Feedback.validEmail(email)) next("email") else ask("email", tx("Qual è la tua email? Per esempio: mario punto rossi chiocciola gmail punto com."))
            "email" -> ask("text", if (bug) tx("Descrivi il problema: cosa stavi facendo e cosa è successo.") else tx("Dimmi il tuo suggerimento."))
            "text" -> ask("confirm", tx("Ho capito") + ": " + text + ". " + tx("Dico invia, correggi oppure annulla?"))
        }
    }
    /** Email dettata: "mario punto rossi chiocciola gmail punto com" → mario.rossi@gmail.com */
    fun spokenEmail(s: String): String = s.lowercase()
        .replace(Regex("\\b(chiocciola|at)\\b"), "@").replace(Regex("\\b(punto|dot)\\b"), ".")
        .replace(Regex("\\b(trattino basso|underscore)\\b"), "_").replace(Regex("\\b(trattino|meno|dash)\\b"), "-")
        .replace(" ", "")
    val voice = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
    ) { res ->
        val heard = res.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim()
        val step = voiceStep ?: return@rememberLauncherForActivityResult
        if (heard.isNullOrBlank()) { say(tx("Non ho sentito. Tocca di nuovo \"Feedback a voce\" per riprovare.")); voiceStep = null; return@rememberLauncherForActivityResult }
        val low = heard.lowercase()
        if (Regex("\\b(annulla|stop|esci|cancel)\\b").containsMatchIn(low)) { say(tx("Annullato.")); voiceStep = null; return@rememberLauncherForActivityResult }
        when (step) {
            "type" -> { bug = listOf("problema", "bug", "errore", "non funziona", "segnal").any { it in low }; say(if (bug) tx("Segnalazione di un problema.") else tx("Suggerimento.")); next("type") }
            "name" -> { name = heard.split(" ").joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }; next("name") }
            "email" -> {
                val e = spokenEmail(heard)
                if (Feedback.validEmail(e)) { email = e; say(tx("Email") + ": " + e.replace(".", " punto ").replace("@", " chiocciola ")); next("email") }
                else ask("email", tx("Non ho capito l'email. Ripetila lentamente, dicendo chiocciola e punto."))
            }
            "text" -> { text = heard; next("text") }
            "confirm" -> when {
                "sì" in low || Regex("\\b(invia|si|ok|conferma|send|yes)\\b").containsMatchIn(low) -> { voiceStep = "send"; listenTick = -1 }
                Regex("\\b(correggi|modifica|ripeti|no)\\b").containsMatchIn(low) -> next("email")
                else -> ask("confirm", tx("Dico invia, correggi oppure annulla?"))
            }
        }
    }
    LaunchedEffect(listenTick) {
        val step = voiceStep ?: return@LaunchedEffect
        if (listenTick <= 0 || step == "send") return@LaunchedEffect
        // Aspetta che la voce finisca la domanda, poi apre il microfono
        kotlinx.coroutines.delay(1800L + 60L * when (step) { "confirm" -> text.length + 60; else -> 60 })
        try {
            voice.launch(
                android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, com.binario.treni.data.I18n.speechTag),
            )
        } catch (_: Exception) {
            say(tx("Il riconoscimento vocale non è disponibile su questo telefono."))
            voiceStep = null
        }
    }
    // Primo ingresso con l'opzione parlata attiva: propone subito il feedback a voce
    LaunchedEffect(Unit) {
        if (com.binario.treni.data.Store(ctx).blindMode) say(tx("Feedback e segnalazioni. Tocca il pulsante \"Feedback a voce\" in alto per dettare il messaggio."))
    }

    val nameOk = name.trim().length >= 3
    val emailOk = Feedback.validEmail(email)
    val textOk = text.trim().length >= 10

    fun submit(spoken: Boolean) {
        tried = true
        if (!nameOk || !emailOk || !textOk || sending) {
            if (spoken) say(when {
                !nameOk -> tx("Manca il nome.")
                !emailOk -> tx("Manca un'email valida.")
                else -> tx("Il messaggio è troppo corto.")
            })
            return
        }
        val b = Feedback.check(ctx, text, openedAt)
        blocked = Feedback.blockText(b).takeIf { b != Feedback.Block.OK }
        if (blocked != null) { if (spoken) say(blocked ?: ""); return }
        sending = true
        result = null
        Feedback.remember(ctx, name, email)
        val report = Feedback.Report(
            name.trim(), email.trim(), if (bug) "Bug" else "Suggerimento", text.trim(),
            if (withTech) Feedback.techInfo(ctx) else "", System.currentTimeMillis(),
        )
        scope.launch {
            val ok = withContext(Dispatchers.IO) { Feedback.send(ctx.applicationContext, report) }
            sending = false
            if (!ok) {
                mailTo = withContext(Dispatchers.IO) { Feedback.fallbackTo(ctx.applicationContext) }
                mailBody = report.message + (if (report.tech.isNotBlank()) "\n\n" + report.tech else "")
            } else mailTo = ""
            result = if (ok) tx("Grazie! Messaggio inviato.") else tx("Nessuna connessione: il messaggio è salvato e partirà da solo appena possibile.")
            say(result ?: "")
            text = ""
            tried = false
        }
    }
    // Conferma a voce "invia"
    LaunchedEffect(voiceStep) {
        if (voiceStep == "send") { voiceStep = null; submit(true) }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Feedback e segnala un bug"), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(
                tx("Suggerimenti, idee o qualcosa che non funziona? Scrivilo qui: il messaggio arriva direttamente allo sviluppatore."),
                fontSize = 14.sp,
            )
            Button(
                { ask("type", tx("Feedback a voce. Dopo il segnale, dimmi: è un suggerimento o vuoi segnalare un problema? Puoi dire annulla in qualsiasi momento.")) },
                Modifier.fillMaxWidth().padding(top = 12.dp).height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green),
            ) {
                androidx.compose.material3.Icon(Icons.Filled.Mic, null)
                Spacer(Modifier.width(8.dp))
                Text(tx("Feedback a voce"), fontSize = 17.sp)
            }
            Text(tx("Per chi non vede o preferisce parlare: l'app fa le domande ad alta voce e tu rispondi a voce."), color = Muted, fontSize = 12.sp)
            Row(Modifier.padding(vertical = 12.dp)) {
                FilterChip(!bug, { bug = false }, label = { Text(tx("Suggerimento")) }, modifier = Modifier.padding(end = 8.dp))
                FilterChip(bug, { bug = true }, label = { Text(tx("Segnala un bug")) })
            }
            OutlinedTextField(
                name, { name = it }, Modifier.fillMaxWidth(),
                label = { Text(tx("Nome e cognome")) }, singleLine = true,
                isError = tried && !nameOk,
                supportingText = { if (tried && !nameOk) Text(tx("Scrivi nome e cognome")) },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            )
            OutlinedTextField(
                email, { email = it }, Modifier.fillMaxWidth(),
                label = { Text(tx("Email")) }, singleLine = true,
                isError = tried && !emailOk,
                supportingText = { Text(if (tried && !emailOk) tx("Email non valida") else tx("Serve solo per risponderti")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            )
            OutlinedTextField(
                text, { text = it }, Modifier.fillMaxWidth().heightIn(min = 180.dp),
                label = { Text(if (bug) tx("Descrivi il problema") else tx("Il tuo feedback")) },
                placeholder = {
                    Text(
                        if (bug) tx("Cosa stavi facendo, cosa è successo e cosa ti aspettavi (es. stazione, numero del treno, ora).")
                        else tx("Cosa ti piace, cosa miglioreresti, cosa manca."),
                        color = Muted,
                    )
                },
                isError = tried && !textOk,
                supportingText = { if (tried && !textOk) Text(tx("Scrivi almeno qualche parola")) },
                minLines = 6,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                trailingIcon = {
                    IconButton({ ask("text", if (bug) tx("Descrivi il problema.") else tx("Dimmi il tuo suggerimento.")) }) {
                        androidx.compose.material3.Icon(Icons.Filled.Mic, tx("Detta il messaggio"), tint = Green)
                    }
                },
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(withTech, { withTech = it }, colors = CheckboxDefaults.colors(checkedColor = Green))
                Column {
                    Text(tx("Allega i dati tecnici"), fontSize = 14.sp)
                    Text(tx("Versione dell'app, modello del telefono e versione di Android: aiutano a trovare il problema."), color = Muted, fontSize = 12.sp)
                }
            }
            blocked?.let {
                Text(it, color = LateRed, fontWeight = FontWeight.Medium, modifier = Modifier.padding(vertical = 10.dp))
            }
            result?.let {
                Text(it, color = Green, fontWeight = FontWeight.Medium, modifier = Modifier.padding(vertical = 10.dp))
            }
            if (mailTo.isNotEmpty()) {
                OutlinedButton(
                    onClick = {
                        try {
                            ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:")).apply {
                                putExtra(android.content.Intent.EXTRA_EMAIL, arrayOf(mailTo))
                                putExtra(android.content.Intent.EXTRA_SUBJECT, "Binario - " + (if (bug) "Bug" else "Suggerimento"))
                                putExtra(android.content.Intent.EXTRA_TEXT, mailBody)
                            })
                        } catch (_: Exception) { toast(ctx, tx("Nessuna app email")) }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(46.dp),
                ) { Text(tx("Invia via email"), fontSize = 15.sp) }
            }
            Button(
                onClick = { submit(false) },
                enabled = !sending,
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(50.dp),
            ) { Text(if (sending) tx("Invio…") else tx("Invia"), fontSize = 17.sp) }
            Text(
                tx("Nome ed email servono solo per risponderti e non vengono usati per altro. Il messaggio non contiene posizione, viaggi o preferiti."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp),
            )
        }
    }
}
