package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap

/**
 * Linea / direttrice di un treno e linee che passano da una stazione.
 * Fonte: orari ufficiali GTFS delle aziende tramite Transitous (MOTIS), verificati il 30/10/2026:
 *  - Trenord: linea (S1, S9, RE13, R…), direttrice ("Alessandria-Pavia-Milano"), colore e link alla pagina della linea
 *    su trenord.it ("le-nostre-linee/<direttrice>/?code=RE_13"); vale anche per i treni TILO (S10, S40, S50…).
 *  - Svizzera (opentransportdata.swiss): linea (S10, RE80, IC2…), senza nome della direttrice; per TILO c'è la pagina tilo.ch.
 *  - Germania (DELFI): linea (RE7, RB55, S4…).
 *  - Trenitalia: solo la categoria (FR, IC, RV): nessuna direttrice; nella scheda stazione compaiono per categoria e tratta.
 * La fermata Transitous unisce tutte le fonti della stazione: chiedendo Milano Centrale arrivano anche i Trenord.
 */
object TrainLines {
    private const val BASE = "https://api.transitous.org/api/"

    data class RailLine(
        /** Codice della linea: "S9", "RE13", "RE80". */
        val code: String,
        /** Direttrice: "Saronno – Seregno – Milano – Albairate" (vuota se la fonte non la dà). */
        val name: String,
        /** Pagina ufficiale della linea (vuota se non nota). */
        val url: String,
        /** Colore della linea (ARGB) o null. */
        val color: Long?,
        /** Impresa: "Trenord", "SBB", "DB Regio"… */
        val operator: String,
        /** Capolinea della corsa (per le linee senza direttrice). */
        val ends: String = "",
    ) {
        val label: String get() = name.ifBlank { ends }
    }

    /** Pagine ufficiali TILO per le linee senza link nell'orario. */
    private val TILO_PAGES = setOf("RE80", "S10", "S20", "S30", "S40", "S50", "S90")

    private val RAIL_MODES = "RAIL,HIGHSPEED_RAIL,LONG_DISTANCE,NIGHT_RAIL,REGIONAL_FAST_RAIL,REGIONAL_RAIL,SUBURBAN"
    private val utc = TimeZone.getTimeZone("UTC")

    private val stopCache = ConcurrentHashMap<String, String>()
    private val trainCache = ConcurrentHashMap<String, Pair<Long, RailLine?>>()
    private val stationCache = ConcurrentHashMap<String, Pair<Long, List<RailLine>>>()

    private fun get(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("User-Agent", "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun JSONObject.str(k: String): String = if (!has(k) || isNull(k)) "" else optString(k)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun iso(t: Long) = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = utc }.format(Date(t))

    private fun stopTimes(stopId: String, time: Long, n: Int): JSONArray? = try {
        JSONObject(get(BASE + "v5/stoptimes?stopId=" + enc(stopId) + "&time=" + enc(iso(time)) + "&n=" + n + "&mode=" + RAIL_MODES))
            .optJSONArray("stopTimes")
    } catch (_: Exception) {
        null
    }

    /** Fermata Transitous di una stazione dell'app (cache). */
    private fun stopIdFor(id: String, name: String): String? {
        val key = id.ifBlank { name }
        stopCache[key]?.let { return it }
        val found: String? = when {
            GermanyLive.isTransitous(id) -> id.drop(2)
            LocalRail.isLocal(id) -> id.removePrefix(LocalRail.PREFIX)
            Regex("^S\\d{5}$").matches(id) -> {
                // Stazioni RFI: fermata Trenitalia (unisce anche Trenord e le altre fonti); stazioni solo FerrovieNord: Trenord
                val t = "it-trenitalia_" + id.drop(1) + ":station"
                if (stopTimes(t, System.currentTimeMillis(), 1) != null) t else "it-Lombardia-Trenord_$id"
            }
            else -> geocode(name)
        }
        if (found != null) stopCache[key] = found
        return found
    }

    /** Stazione cercata per nome (Svizzera e casi senza codice). */
    private fun geocode(name: String): String? = try {
        val clean = name.substringBefore(" (").trim()
        val a = JSONArray(get(BASE + "v1/geocode?type=STOP&text=" + enc(clean)))
        val rail = setOf("RAIL", "HIGHSPEED_RAIL", "LONG_DISTANCE", "NIGHT_RAIL", "REGIONAL_FAST_RAIL", "REGIONAL_RAIL", "SUBURBAN")
        (0 until a.length()).map { a.getJSONObject(it) }.firstOrNull { o ->
            val m = o.optJSONArray("modes")
            m != null && (0 until m.length()).any { m.optString(it) in rail }
        }?.str("id")
    } catch (_: Exception) {
        null
    }

    private fun digits(s: String) = s.filter { it.isDigit() }.trimStart('0')

    /** Linea dalla corsa, se la fonte ne indica una vera (non solo la categoria "FR", "IC", "RV"). */
    private fun lineOf(o: JSONObject, trainDigits: String = ""): RailLine? {
        val code = o.str("routeShortName").trim()
        val d = digits(code)
        if (code.isBlank() || d.isEmpty() || (trainDigits.isNotEmpty() && d == trainDigits)) return null
        // "RE_8 - 2830" o "ICE 610": il numero del treno non è la linea
        if (code.contains(' ') && Regex("\\d{3,}").containsMatchIn(code)) return null
        val long = o.str("routeLongName").trim()
        val name = if (long.isBlank() || long.equals(code, true)) "" else long.replace(Regex("\\s*-\\s*"), " – ")
        var url = o.str("routeUrl").trim().substringBefore("&utm_").substringBefore("?utm_")
        // Il feed dà "http://…/?" : il sito (Akamai) rifiuta http e il "?" vuoto ("Access Denied"). Forma ufficiale: https + ?code=
        if (url.startsWith("http://")) url = "https://" + url.removePrefix("http://")
        url = url.trimEnd('?', '&')
        if (url.contains("trenord.it/") && url.contains("le-nostre-linee/") && !url.contains("?")) url = "$url?code=${code.trim().replace(' ', '_')}"
        val op = GermanyLive.legOperator(o.str("agencyName"))
        if (url.isBlank() && code.uppercase() in TILO_PAGES && (op == "SBB" || op == "TILO" || op == "Trenord")) {
            url = "https://www.tilo.ch/collegamenti/${code.uppercase()}.html"
        }
        val color = o.str("routeColor").takeIf { Regex("^[0-9a-fA-F]{6}$").matches(it) }?.let { 0xFF000000L or it.toLong(16) }
        val ends = listOf(o.optJSONObject("tripFrom")?.str("name").orEmpty(), o.optJSONObject("tripTo")?.str("name").orEmpty())
            .filter { it.isNotBlank() }.joinToString(" – ")
        return RailLine(code, name, url, color, op, ends)
    }

    /** Fra due voci della stessa linea tiene quella con più informazioni (Trenord: direttrice e link). */
    private fun better(a: RailLine, b: RailLine): RailLine {
        fun score(l: RailLine) = (if (l.name.isNotBlank()) 2 else 0) + (if (l.url.isNotBlank()) 2 else 0) + (if (l.color != null) 1 else 0)
        return if (score(b) > score(a)) b.copy(ends = b.ends.ifBlank { a.ends }) else a
    }

    /**
     * Linea del treno: si cercano le partenze dalla prima fermata all'orario del treno e si riconosce la corsa dal numero.
     * Null se la fonte non indica una linea (es. Frecciarossa, Intercity, regionali Trenitalia).
     */
    fun forTrain(st: TrainStatus): RailLine? {
        val num = digits(Api.trainDigits(st.number))
        if (num.isEmpty()) return null
        val key = st.originCode + "|" + num + "|" + (st.depTime / 86_400_000L)
        trainCache[key]?.let { (at, l) -> if (System.currentTimeMillis() - at < 6 * 3600_000L) return l }
        // Prima fermata con orario di partenza (poi, se serve, la seconda: alcune fonti non hanno il capolinea estero)
        val candidates = st.stops.filter { it.schedDep > 0 }.take(2)
        var found: RailLine? = null
        for (s in candidates) {
            val stop = stopIdFor(s.id, s.name) ?: continue
            val a = stopTimes(stop, s.schedDep - 3 * 60_000L, 60) ?: continue
            val matches = (0 until a.length()).map { a.getJSONObject(it) }.filter { o ->
                val trip = o.str("tripShortName")
                Regex("\\d+").findAll(trip).any { m -> m.value.trimStart('0') == num } ||
                    Regex("\\d+").findAll(o.str("displayName")).any { m -> m.value.trimStart('0') == num }
            }
            found = matches.mapNotNull { lineOf(it, num) }.reduceOrNull { x, y -> better(x, y) }
            if (found != null || matches.isNotEmpty()) break
        }
        trainCache[key] = System.currentTimeMillis() to found
        return found
    }

    /** Linee ferroviarie che passano dalla stazione (partenze delle prossime ore). */
    fun forStation(station: Station): List<RailLine> {
        stationCache[station.id]?.let { (at, l) -> if (System.currentTimeMillis() - at < 6 * 3600_000L) return l }
        val stop = stopIdFor(station.id, station.name) ?: return emptyList()
        val a = stopTimes(stop, System.currentTimeMillis(), 400) ?: return emptyList()
        val byCode = LinkedHashMap<String, RailLine>()
        // Servizi senza linea nell'orario (Frecce, EC/IC, regionali e RV Trenitalia, es. Milano – Domodossola, Milano – Arona):
        // si indicano per categoria e tratta (capolinea della corsa), uno per impresa + categoria + tratta
        val services = LinkedHashMap<String, RailLine>()
        (0 until a.length()).map { a.getJSONObject(it) }.forEach { o ->
            val l = lineOf(o)
            if (l != null) {
                val k = l.code.uppercase()
                byCode[k] = byCode[k]?.let { better(it, l) } ?: l
                return@forEach
            }
            val cat = (o.str("routeShortName").ifBlank { o.str("displayName") }).trim().takeWhile { it.isLetter() }.uppercase()
            val from = o.optJSONObject("tripFrom")?.str("name").orEmpty().trim()
            val to = (o.optJSONObject("tripTo")?.str("name").orEmpty().ifBlank { o.str("headsign") }).trim()
            if (cat.isBlank() || cat.length > 4 || to.isBlank()) return@forEach
            val op = GermanyLive.legOperator(o.str("agencyName"))
            val ends = listOf(from, to).filter { it.isNotBlank() }.joinToString(" – ")
            services.putIfAbsent("$op|$cat|$ends", RailLine(cat, "", "", null, op, ends))
        }
        val out = byCode.values.sortedWith(
            compareBy<RailLine>({ it.code.takeWhile { c -> c.isLetter() }.uppercase() }, { digits(it.code).toIntOrNull() ?: 0 }),
        ) + services.values.sortedWith(compareBy<RailLine>({ it.code }, { it.ends })).take(40)
        stationCache[station.id] = System.currentTimeMillis() to out
        return out
    }
}
