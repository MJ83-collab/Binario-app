package com.binario.treni.ui

import com.binario.treni.data.tx
import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.binario.treni.data.Api
import com.binario.treni.data.BoardItem
import com.binario.treni.data.Fmt
import com.binario.treni.data.Osm
import com.binario.treni.data.TicketSellers
import com.binario.treni.data.OsmPlace
import com.binario.treni.data.StationOverview
import com.binario.treni.data.StationTransport
import com.binario.treni.data.Sources
import com.binario.treni.data.StationIssue
import com.binario.treni.data.Station
import com.binario.treni.data.TrainRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** Scheda "Stazioni": cerca tabellone, stazioni preferite, vicine e mappa. */
@Composable
fun StationsHome(vm: MainViewModel, onBoard: (Station) -> Unit, onNearby: () -> Unit, onSellers: () -> Unit = {}, onToilets: () -> Unit = {}, onTaxi: () -> Unit = {}, onExplore: () -> Unit = {}, onBus: () -> Unit = {}, onDae: () -> Unit = {}) {
    var picking by remember { mutableStateOf(false) }
    var favs by remember { mutableStateOf(vm.store.favStations()) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Stazioni"))
        LazyColumn {
            item {
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(
                        Modifier.fillMaxWidth().clickable { picking = true }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Search, null, tint = Green)
                        Spacer(Modifier.width(14.dp))
                        Text(tx("Cerca una stazione per il tabellone"), color = Color.Gray)
                    }
                }
                HorizontalDivider()
                SimpleRow(Icons.Filled.NearMe, tx("Stazioni vicine e mappa"), tx("Usa la tua posizione")) { onNearby() }
                SimpleRow(Icons.Filled.ConfirmationNumber, tx("Rivendite e biglietterie vicine"), tx("Rivendite autorizzate, biglietterie, emettitrici, contactless")) { onSellers() }
                SimpleRow(Icons.Filled.Wc, tx("WC vicini"), tx("Gratuiti o a pagamento, accessibili, orari")) { onToilets() }
                SimpleRow(Icons.Filled.DirectionsBus, com.binario.treni.data.I18n.tr("Bus sostitutivi", "Replacement buses"),
                    com.binario.treni.data.I18n.tr("Dove si prende il bus quando il treno non passa · Trenord, Trenitalia, TILO", "Where to catch the bus when trains don't run · Trenord, Trenitalia, TILO")) { onBus() }
                SimpleRow(Icons.Filled.MonitorHeart, com.binario.treni.data.I18n.tr("Defibrillatori (DAE)", "Defibrillators (AED)"),
                    com.binario.treni.data.I18n.tr("Il più vicino a te · chiama il 112", "The nearest to you · call 112")) { onDae() }
                SimpleRow(Icons.Filled.LocalTaxi, tx("Taxi vicini"), tx("Posteggi taxi, radio taxi da chiamare, app")) { onTaxi() }
                SimpleRow(Icons.Filled.Explore, tx("Esplora a voce"), tx("Dove sono, binari, ascensori, servizi; guida verso un punto")) { onExplore() }
            }
            item { SectionHeader(tx("Stazioni preferite")) }
            if (favs.isEmpty()) item { MessageBox(tx("Apri un tabellone e tocca ★ per salvare la stazione.")) }
            items(favs, key = { it.id }) { s ->
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(
                        Modifier.fillMaxWidth().clickable { onBoard(s) }.padding(start = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Place, null, tint = Green)
                        Spacer(Modifier.width(14.dp))
                        Text(s.name, Modifier.weight(1f))
                        IconButton({ vm.store.toggleFavStation(s); favs = vm.store.favStations() }) {
                            Icon(Icons.Filled.Star, tx("Rimuovi"), tint = Green)
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
    if (picking) StationPickerDialog(tx("Tabellone stazione"), { picking = false }) { picking = false; onBoard(it) }
}

/** Tabellone partenze/arrivi in tempo reale. */
@Composable
fun BoardScreen(
    vm: MainViewModel, station: Station, onBack: () -> Unit, onTrain: (TrainRef) -> Unit, onSellers: (Station) -> Unit = {},
    onToilets: (Station) -> Unit = {}, onStibm: (Station) -> Unit = {}, onTaxi: (Station) -> Unit = {},
    onBus: (Station) -> Unit = {},
) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val vintage = com.binario.treni.data.AppStyle.vintage
    var board by remember { mutableStateOf<List<BoardItem>?>(null) }
    var error by remember { mutableStateOf(false) }
    var fav by remember { mutableStateOf(vm.store.isFavStation(station)) }
    var tick by remember { mutableIntStateOf(0) }

    var hours by remember { mutableIntStateOf(6) }
    var loadingMore by remember { mutableStateOf(false) }
    var pulling by remember { mutableStateOf(false) }
    val fg = rememberForeground()
    LaunchedEffect(tab, tick, hours) {
        if (tab == 2) return@LaunchedEffect
        if (board == null) loadingMore = false
        while (true) {
            try {
                // Subito i prossimi 90 minuti, poi tutti i treni delle ore successive
                if (board == null) board = withContext(Dispatchers.IO) { if (tab == 0) Api.departures(station) else Api.arrivals(station) }
                loadingMore = true
                board = withContext(Dispatchers.IO) { Api.boardAhead(station, tab == 0, hours = hours) }
                loadingMore = false
                error = false
            } catch (e: Exception) {
                loadingMore = false
                if (board == null) error = true
            }
            pulling = false
            delay(60_000)
            waitForeground(fg)
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(station.name, onBack) {
            IconButton({ com.binario.treni.data.Api.clearCache(); tick++ }) { Icon(Icons.Filled.Refresh, tx("Aggiorna")) }
            IconButton({ fav = vm.store.toggleFavStation(station) }) {
                Icon(if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder, tx("Preferita"))
            }
            BarOverflow(
                listOf(
                    BarAction(Icons.Filled.ConfirmationNumber, tx("Rivendite")) { onSellers(station) },
                    BarAction(Icons.Filled.Wc, tx("WC")) { onToilets(station) },
                    BarAction(Icons.Filled.LocalTaxi, tx("Taxi")) { onTaxi(station) },
                    BarAction(Icons.Filled.DirectionsBus, com.binario.treni.data.I18n.tr("Bus sostitutivi", "Replacement buses")) { onBus(station) },
                    BarAction(Icons.Filled.Share, tx("Condividi")) {
                        val l = board.orEmpty().take(10)
                        shareText(ctx, (if (tab == 0) tx("Partenze da ") else tx("Arrivi a ")) + station.name + "\n" +
                            l.joinToString("\n") { b -> "${Fmt.time(b.time)} ${b.title} ${b.otherEnd}" + (if (b.delay > 0) " +${b.delay}'" else "") +
                                (if (b.platformText.isNotBlank()) " bin. ${b.platformText}" else "") })
                    },
                ),
            )
        }
        GreenTabs(listOf(tx("Partenze"), tx("Arrivi"), tx("Stazione")), tab) { if (it != tab) { board = null; hours = 6 }; tab = it }
        if (tab != 2) StationPunctualityLine(station)
        // Area STIBM (Milano e Monza Brianza): zona tariffaria della stazione, tocca per tariffe e regole
        val stibm = remember(station.name) { com.binario.treni.data.Stibm.find(station.name) }
        if (tab != 2 && stibm != null) {
            Row(
                Modifier.fillMaxWidth().clickable { onStibm(station) }.background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.ConfirmationNumber, null, tint = Green, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    (if (stibm.interchangeOnly) tx("Fuori area STIBM (solo interscambio)") else tx("Area STIBM")) + " · " + tx("zona") + " " + stibm.zoneLabel +
                        " · " + tx("tariffe"),
                    fontSize = 13.sp, color = Green,
                )
            }
        }
        if (tab != 2 && com.binario.treni.data.GermanyLive.isAbroad(station.id)) {
            Text(tx("Austria e Francia: orari ufficiali con ritardi e binari in tempo reale quando pubblicati (Transitous)."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        if (tab != 2 && com.binario.treni.data.GermanyLive.isGerman(station.id)) {
            Text(tx("Germania: orari ufficiali DELFI con ritardi e binari in tempo reale quando pubblicati (Transitous)."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        if (tab != 2 && com.binario.treni.data.LocalRail.isLocal(station.id)) {
            Text(tx("Orari programmati dell'azienda (Transitous): i ritardi compaiono solo se l'azienda li pubblica."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        // Precarica in silenzio i servizi della stazione (scheda "Stazione"): quando la apri sono già pronti
        LaunchedEffect(station.id) {
            delay(1500)
            withContext(Dispatchers.IO) {
                runCatching {
                    Api.stationCoord(vm.store, station.id)?.let { c ->
                        Osm.stationOverview(c.first, c.second)
                        Osm.stationTransport(c.first, c.second)
                    }
                }
            }
        }
        // Rete FERROVIENORD: ascensori e scale mobili fuori servizio in questa stazione (fonte ferrovienord.it)
        val fnStation = remember(station.id) { com.binario.treni.data.FnNetwork.isFn(station.id) }
        var outages by remember(station.id) { mutableStateOf<List<com.binario.treni.data.FerrovieNord.Outage>>(emptyList()) }
        LaunchedEffect(station.id) {
            if (!fnStation) return@LaunchedEffect
            outages = withContext(Dispatchers.IO) {
                runCatching { com.binario.treni.data.FerrovieNord.outagesAt(station.name, com.binario.treni.data.FerrovieNord.outages()) }.getOrDefault(emptyList())
            }
        }
        if (outages.isNotEmpty()) Column(
            Modifier.fillMaxWidth().clickable { openUrl(ctx, com.binario.treni.data.FerrovieNord.OUTAGES_URL) }
                .background(Color(0xFFFFF3E0)).padding(horizontal = 16.dp, vertical = 6.dp),
        ) {
            outages.forEach { o ->
                Text("♿ " + o.text, fontSize = 13.sp, color = Color(0xFF8A3B00), fontWeight = FontWeight.Medium)
            }
            Text(com.binario.treni.data.I18n.tr("FERROVIENORD · fonte: ferrovienord.it (comunicazioni accessibilità stazioni). Assistenza: 800 210 955",
                "FERROVIENORD · source: ferrovienord.it (station accessibility notices). Assistance: 800 210 955"), fontSize = 11.sp, color = Color(0xFF8A3B00))
        }
        val l = board
        if (tab == 2) AccessibilityPanel(vm, station)
        else PullRefresh(pulling, { pulling = true; error = false; com.binario.treni.data.Api.clearCache(); tick++ }) { when {
            error -> PullableMessage(
                if (tab == 1 && (com.binario.treni.data.SwissLive.isSwiss(station.id) || com.binario.treni.data.LocalRail.isLocal(station.id)))
                    tx("Per questa stazione sono disponibili solo le partenze")
                else tx("Tabellone non disponibile") + "\n" + tx("Trascina giù per riprovare"),
            )
            l == null -> LoadingBox()
            l.isEmpty() -> PullableMessage(tx("Nessun treno nelle prossime ore"))
            else -> LazyColumn(
                Modifier.fillMaxSize().then(if (vintage) Modifier.background(VintageColors.board) else Modifier),
                contentPadding = PaddingValues(vertical = 4.dp),
            ) {
                if (vintage) item { VintageHeader() }
                items(l) { b ->
                    if (vintage) VintageBoardRow(b, departures = tab == 0) { onTrain(b.ref) }
                    else BoardRow(b, departures = tab == 0) { onTrain(b.ref) }
                }
                item {
                    Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                        if (loadingMore) CircularProgressIndicator(color = Green)
                        else if (hours < 24) OutlinedButton({ hours += 6 }) {
                            Text(com.binario.treni.data.I18n.tr("Mostra treni successivi (+6 ore)", "Show later trains (+6 hours)"), color = Green)
                        }
                    }
                }
            }
        } }
    }
}

@Composable
private fun BoardRow(b: BoardItem, departures: Boolean, onClick: () -> Unit) {
    WhiteCard(onClick = onClick) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(60.dp)) {
                Text(Fmt.time(b.time), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                DelayText(b.delay, b.inStation || b.delay != 0)
            }
            Column(Modifier.weight(1f)) {
                Text((if (departures) "" else tx("da ")) + b.otherEnd, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TrainTitle(b.category, b.number, 14, operator = b.operator)
                    Spacer(Modifier.width(6.dp))
                    CrowdBadge(
                        com.binario.treni.data.Crowd.estimate(
                            b.time, b.category,
                            if (departures) "" else b.otherEnd, if (departures) b.otherEnd else "",
                        ),
                    )
                }
            }
            PlatformPair(b.schedPlatform, b.realPlatform)
        }
    }
}

/** Accessibilità: fuori servizio (FerrovieNord, RFI), binari e ascensori (OpenStreetMap), assistenza. */
@Composable
private fun AccessibilityPanel(vm: MainViewModel, station: Station) {
    val ctx = LocalContext.current
    var issues by remember { mutableStateOf<List<StationIssue>?>(null) }
    var failed by remember { mutableStateOf<List<String>>(emptyList()) }
    var rfiLive by remember { mutableStateOf<List<StationIssue>?>(null) }
    var overview by remember { mutableStateOf<StationOverview?>(null) }
    var osmFailed by remember { mutableStateOf(false) }
    var osmTick by remember { mutableIntStateOf(0) }
    var coord by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var fnLive by remember { mutableStateOf<List<StationIssue>?>(null) }
    var usedTracks by remember { mutableStateOf<List<String>>(emptyList()) }
    var transport by remember { mutableStateOf<StationTransport?>(null) }
    var transportFailed by remember { mutableStateOf(false) }
    // Bus, metro, tram, taxi e bici vicino alla stazione (dopo aver ottenuto le coordinate)
    LaunchedEffect(coord, osmTick) {
        val c = coord ?: return@LaunchedEffect
        transportFailed = false
        transport = try {
            withContext(Dispatchers.IO) { Osm.stationTransport(c.first, c.second) }
        } catch (e: Exception) {
            transportFailed = true; null
        }
    }
    // Binari effettivamente usati dai treni delle prossime ore (ViaggiaTreno): utile se OpenStreetMap non li indica
    LaunchedEffect(station.id) {
        usedTracks = try {
            withContext(Dispatchers.IO) {
                (Api.boardAhead(station, true, hours = 6) + Api.boardAhead(station, false, hours = 3))
                    .flatMap { listOf(it.schedPlatform, it.realPlatform) }
                    .flatMap { Osm.trackRefs(it) }
                    .distinct()
                    .sortedWith(compareBy({ it.filter { c -> c.isDigit() }.take(3).toIntOrNull() ?: 999 }, { it }))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    LaunchedEffect(station.id) {
        val (l, f) = withContext(Dispatchers.IO) { Sources.issuesFor(station.name) }
        issues = l; failed = f
    }
    LaunchedEffect(station.id, osmTick) {
        osmFailed = false
        try {
            val c = withContext(Dispatchers.IO) { Api.stationCoord(vm.store, station.id) }
            coord = c
            if (c == null) osmFailed = true
            else overview = withContext(Dispatchers.IO) {
                val o = Osm.stationOverview(c.first, c.second)
                // Rivendite autorizzate e biglietterie con orari dagli elenchi ufficiali (Trenord), non tutte le tabaccherie
                val official = try {
                    // Elenco della settimana senza rileggere il sito (più veloce): lo stato aperto/chiuso è in "Punti vendita"
                    TicketSellers.trenordNear(ctx.applicationContext, c.first, c.second, 500, live = false).map { (s, d) -> TicketSellers.toPlace(s, d) }
                        .distinctBy { "${it.kind}|${it.name.lowercase()}|${Math.round(it.lat * 2000)}|${Math.round(it.lon * 2000)}" }
                } catch (e: Exception) {
                    emptyList()
                }
                val offices = official.filter { it.kind == OsmPlace.Kind.TICKET_OFFICE && it.distance <= 350 }
                o.copy(
                    resellers = official.filter { it.kind == OsmPlace.Kind.RESELLER },
                    ticketOffices = offices + o.ticketOffices.filter { p ->
                        offices.none { q -> Math.abs(q.lat - p.lat) < 0.0006 && Math.abs(q.lon - p.lon) < 0.0008 }
                    },
                )
            }
        } catch (e: Exception) {
            osmFailed = true
        }
    }
    // Le tabelle RFI e FerrovieNord si riempiono via JavaScript: le leggiamo con un WebView invisibile
    JsTableReader(RFI_ACCESS_URL, station.name) { rows ->
        rfiLive = rows.filter { it.size >= 2 }.map { r -> StationIssue("RFI", r[0], platformIn(r[1]), r[1], "", r.getOrElse(2) { "" }) }
    }
    // FerrovieNord: la tabella è HTML semplice, la leggiamo direttamente (prima serviva un secondo WebView invisibile, lento)
    LaunchedEffect(station.id) {
        fnLive = withContext(Dispatchers.IO) {
            runCatching {
                com.binario.treni.data.FerrovieNord.outagesAt(station.name, com.binario.treni.data.FerrovieNord.outages())
                    .map { o -> StationIssue("FerrovieNord", o.station, o.platform, o.item, o.since, o.until) }
            }.getOrDefault(emptyList())
        }
    }

    LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
        item {
            StationSummaryCard(vm, overview, osmFailed, coord, usedTracks, onRetry = { osmTick++ })
        }
        com.binario.treni.data.SbbStations.find(station)?.let { page -> item { SbbServicesCard(page) } }
        if (com.binario.treni.data.GermanyLive.isGerman(station.id)) item { DbStationCard(station) }
        // Linee e direttrici che passano dalla stazione
        item { StationLinesCard(station) }
        item { TransportCard(transport, transportFailed || (osmFailed && coord == null), coord) { osmTick++ } }
        item {
            WhiteCard {
                CardTitle(tx("Ascensori e scale fuori servizio"))
                Column(Modifier.padding(16.dp)) {
                    val all = (issues.orEmpty() + rfiLive.orEmpty() + fnLive.orEmpty()).distinctBy { it.source + it.platform + it.device + it.until }
                    when {
                        issues == null && rfiLive == null && fnLive == null -> Text(tx("Controllo FerrovieNord e RFI…"), color = Muted)
                        all.isEmpty() -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.CheckCircle, null, tint = Green)
                            Spacer(Modifier.width(10.dp))
                            Text(tx("Nessun impianto fuori servizio segnalato per questa stazione."))
                        }
                        else -> all.forEach { a ->
                            Row(Modifier.padding(vertical = 6.dp)) {
                                Icon(Icons.Filled.Elevator, null, tint = LateRed)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    if (a.platform.isNotBlank()) Text(com.binario.treni.data.I18n.tr("Binario ", "Platform ") + a.platform, fontWeight = FontWeight.Bold)
                                    Text(a.device, fontWeight = FontWeight.Medium)
                                    val dates = listOfNotNull(
                                        a.since.takeIf { it.isNotBlank() }?.let { "dal $it" },
                                        a.until.takeIf { it.isNotBlank() }?.let { "ripristino previsto $it" },
                                    ).joinToString(" · ")
                                    if (dates.isNotBlank()) Text(dates, color = Muted, fontSize = 13.sp)
                                    SourceLink(a.source, if (a.source == "RFI") RFI_ACCESS_URL else FN_ACCESS_URL)
                                }
                            }
                        }
                    }
                    if (failed.isNotEmpty()) Text(com.binario.treni.data.I18n.tr("Non raggiungibile ora: ", "Not reachable now: ") + failed.joinToString(), color = Muted, fontSize = 12.sp)
                    SourceLink(tx("Elenco completo FerrovieNord"), FN_ACCESS_URL)
                    SourceLink(tx("Pagina Accessibilità RFI"), RFI_ACCESS_URL)
                }
            }
        }
        item {
            WhiteCard {
                CardTitle(tx("Assistenza"))
                MenuRow(Icons.Filled.Phone, tx("Trenord · 800 210 955"), tx("Tutti i giorni 8:15–19:45 · prenota almeno 24 ore prima")) {
                    dial(ctx, "800210955")
                }
                MenuRow(Icons.Filled.Email, "assistenza.prm@trenord.it", tx("Informazioni e prenotazioni (risposte nei giorni feriali)")) {
                    mail(ctx, "assistenza.prm@trenord.it")
                }
                MenuRow(Icons.Filled.ReportProblem, "senzabarriere@trenord.it", tx("Segnala problemi tra treno e stazione")) {
                    mail(ctx, "senzabarriere@trenord.it")
                }
                MenuRow(Icons.Filled.SupportAgent, tx("RFI Sala Blu · 800 90 60 60"), tx("Da cellulare +39 02 32 32 32 · 6:45–21:30")) {
                    dial(ctx, "800906060")
                }
                MenuRow(Icons.Filled.Map, tx("Mappa manutenzioni FerrovieNord"), "") {
                    openUrl(ctx, "https://maps.manutenzionefn.it")
                }
                MenuRow(Icons.Filled.Accessible, tx("Infoaccessibilità RFI"), tx("Percorsi senza gradini, marciapiedi a 55 cm")) {
                    openUrl(ctx, "https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/infoaccessibilita.html")
                }
            }
        }
    }
}

const val RFI_ACCESS_URL = "https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/stato-ascensori-e-rampe-di-accesso-ai-binari.html"
const val FN_ACCESS_URL = "https://www.ferrovienord.it/comunicazioni-accessibilita-stazioni/"

private fun platformIn(text: String): String =
    Regex("binari?o?\\s*([0-9]+(?:\\s*[-e/]\\s*[0-9]+)*)", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1) ?: ""

/**
 * Legge una tabella che il sito riempie via JavaScript (RFI, FerrovieNord) con un WebView invisibile
 * e restituisce le righe che riguardano la stazione. Riprova qualche volta se la tabella non è ancora pronta.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun JsTableReader(url: String, station: String, onResult: (List<List<String>>) -> Unit) {
    val words = remember(station) { station.lowercase().replace(Regex("[^a-zà-ù0-9 ]"), " ").split(" ").filter { it.length > 2 } }
    androidx.compose.ui.viewinterop.AndroidView(
        modifier = Modifier.size(1.dp),
        factory = { c ->
            android.webkit.WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                var tries = 0
                var done = false
                val script = "(function(){return Array.from(document.querySelectorAll('tr')).map(function(r){return Array.from(r.cells).map(function(x){return x.innerText.trim();});});})()"
                fun read(v: android.webkit.WebView) {
                    if (done) return
                    v.evaluateJavascript(script) { res ->
                        try {
                            val a = org.json.JSONArray(res)
                            val rows = (0 until a.length()).map { i ->
                                val r = a.getJSONArray(i); (0 until r.length()).map { r.getString(it) }
                            }.filter { it.size >= 2 && it[0].isNotBlank() && !it[0].equals("NOME STAZIONE", true) && !it[0].equals("IMPIANTO", true) }
                            if (rows.isEmpty() && tries++ < 3) {
                                v.postDelayed({ read(v) }, 3000)
                            } else {
                                done = true
                                onResult(rows.filter { r -> words.isNotEmpty() && words.all { w -> r[0].lowercase().contains(w) } })
                            }
                        } catch (e: Exception) {
                            done = true
                            onResult(emptyList())
                        }
                    }
                }
                webViewClient = object : android.webkit.WebViewClient() {
                    override fun onPageFinished(view: android.webkit.WebView, url: String?) {
                        view.postDelayed({ read(view) }, 2500)
                    }
                }
                loadUrl(url)
            }
        },
        onRelease = { it.destroy() },
    )
}

/** Riepilogo chiaro della stazione: binari, ascensori per binario, biglietterie, self-service, obliteratrici, rivendite. */
@Composable
private fun StationSummaryCard(
    vm: MainViewModel, o: StationOverview?, failed: Boolean, coord: Pair<Double, Double>?, usedTracks: List<String>, onRetry: () -> Unit,
) {
    WhiteCard {
        CardTitle(tx("Riepilogo stazione"))
        Column(Modifier.padding(16.dp)) {
            when {
                failed && o == null -> {
                    if (usedTracks.isNotEmpty()) SummaryRow(Icons.Filled.Train, tx("Binari in uso"), "${usedTracks.size} (${usedTracks.joinToString(", ")})")
                    Text(tx("Dati OpenStreetMap non raggiungibili in questo momento (provati 3 server Overpass e Postpass)."), color = Muted)
                    TextButton(onRetry) { Text(tx("Riprova"), color = Green) }
                    coord?.let { c ->
                        GoogleMapsButtons(c.first, c.second, listOf(tx("Biglietteria") to "biglietteria stazione",
                            tx("Tabacchi") to "tabaccheria", tx("WC") to "bagni pubblici"))
                    }
                }
                o == null -> {
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                    Text(tx("Carico i servizi della stazione…"), color = Muted, modifier = Modifier.padding(top = 6.dp))
                }
                else -> {
                    when {
                        o.tracks.isNotEmpty() -> SummaryRow(Icons.Filled.Train, tx("Binari"), "${o.tracks.size} (${o.tracks.joinToString(", ")})")
                        usedTracks.isNotEmpty() -> SummaryRow(Icons.Filled.Train, tx("Binari in uso"),
                            "${usedTracks.size} (${usedTracks.joinToString(", ")}) · " + tx("dai treni di oggi"))
                        else -> SummaryRow(Icons.Filled.Train, tx("Binari"), tx("non mappati"))
                    }
                    SummaryRow(Icons.Filled.Elevator, tx("Ascensori"),
                        if (o.elevators == 0) tx("nessuno mappato") else o.elevators.toString() +
                            (if (o.escalators > 0) " · " + tx("scale mobili") + " ${o.escalators}" else "") +
                            (if (o.ramps > 0) " · " + tx("rampe") + " ${o.ramps}" else ""))
                    SummaryRow(Icons.Filled.Storefront, tx("Biglietteria"),
                        if (o.ticketOffices.isEmpty()) tx("non presente / non mappata")
                        else o.ticketOffices.map { p -> p.hours.ifBlank { tx("presente") } }.distinct().joinToString(" · "))
                    SummaryRow(Icons.Filled.PointOfSale, tx("Self-service"),
                        if (o.machines.isEmpty()) tx("non mappate")
                        else "${o.machines.size}" + (if (o.contactlessMachines > 0) " · " + tx("contactless") + " ${o.contactlessMachines}" else ""))
                    SummaryRow(Icons.Filled.ConfirmationNumber, tx("Obliteratrici"),
                        if (o.validators.isEmpty()) tx("non mappate") else "${o.validators.size}" +
                            (if (o.validators.any { it.contactless }) " · " + tx("contactless") else ""))
                    SummaryRow(Icons.Filled.LocalConvenienceStore, tx("Rivendite autorizzate"),
                        when {
                            o.resellers.isNotEmpty() -> "${o.resellers.size} · " + tx("la più vicina") + ": " + o.resellers.first().name +
                                " (${o.resellers.first().distance} m" + (o.resellers.first().tags["x_status"]?.let { ", $it" } ?: "") + ")"
                            TicketSellers.inLombardy(o.lat, o.lon) -> tx("nessuna entro 500 m")
                            else -> tx("vedi la mappa ufficiale Trenitalia in Rivendite")
                        })
                    // WC: gratuiti o a pagamento, accessibili, orari
                    if (o.toiletList.isEmpty()) {
                        SummaryRow(Icons.Filled.Wc, tx("WC"), tx("non mappati"))
                    } else {
                        SummaryRow(Icons.Filled.Wc, tx("WC"), o.toiletList.take(3).joinToString("\n") { w ->
                            listOfNotNull(
                                w.feeText,
                                if (w.wheelchair == "yes") tx("♿ accessibile") else null,
                                w.hours.takeIf { it.isNotBlank() }?.let { tx("orari") + " " + it },
                                if (w.distance > 40) "${w.distance} m" else null,
                            ).joinToString(" · ")
                        })
                    }
                    when (o.wheelchair) {
                        "yes" -> SummaryRow(Icons.Filled.Accessible, tx("Accessibilità"), tx("stazione accessibile in carrozzina"))
                        "limited" -> SummaryRow(Icons.Filled.Accessible, tx("Accessibilità"), tx("accesso limitato"))
                        "no" -> SummaryRow(Icons.Filled.Accessible, tx("Accessibilità"), tx("non accessibile in carrozzina"))
                    }
                    if (o.platforms.isNotEmpty()) {
                        Text(tx("Ascensori per binario"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
                        o.platforms.forEach { p ->
                            Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                PlatformBox(p.platform.replace(";", "-"), true)
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    listOfNotNull(
                                        if (p.elevators > 0) tx("🛗 ascensore") + (if (p.elevators > 1) " ×${p.elevators}" else "") else tx("nessun ascensore mappato"),
                                        if (p.ramps > 0) tx("rampa") else null,
                                        when (p.wheelchair) {
                                            "yes" -> tx("♿ accessibile")
                                            "limited" -> tx("♿ accesso limitato")
                                            "no" -> tx("non accessibile in carrozzina")
                                            else -> null
                                        },
                                    ).joinToString(" · "),
                                )
                            }
                        }
                    }
                    val c = coord
                    val pins = (o.ticketOffices + o.machines + o.validators).map {
                        MapPoint(it.lat, it.lon, it.kind.label, if (it.contactless) tx("contactless") else "")
                    }
                    if (vm.store.mapsEnabled && c != null && pins.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        OsmMap(pins, drawLine = false, modifier = Modifier.fillMaxWidth().height(220.dp),
                            target = MapPoint(c.first, c.second, tx("Stazione")))
                    }
                    SourceLink(Osm.lastSource.ifBlank { "OpenStreetMap" }, o.sourceUrl, Modifier.padding(top = 8.dp))
                    coord?.let { c ->
                        GoogleMapsButtons(c.first, c.second, listOf(tx("Tabacchi") to "tabaccheria", tx("WC") to "bagni pubblici"))
                    }
                    Text(tx("Dati dei volontari OpenStreetMap: possono essere incompleti. I guasti di oggi sono nel riquadro sotto."),
                        color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

/** Come proseguire: metro, tram, bus (con le linee), taxi e bici vicino alla stazione. */
@Composable
private fun TransportCard(t: StationTransport?, failed: Boolean, coord: Pair<Double, Double>?, onRetry: () -> Unit) {
    val ctx = LocalContext.current
    WhiteCard {
        CardTitle(tx("Bus, metro, tram e taxi"))
        Column(Modifier.padding(16.dp)) {
            when {
                t == null && failed -> {
                    Text(tx("Dati OpenStreetMap non raggiungibili in questo momento (provati 3 server Overpass e Postpass)."), color = Muted)
                    TextButton(onRetry) { Text(tx("Riprova"), color = Green) }
                }
                t == null -> {
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                    Text(tx("Cerco fermate e posteggi taxi vicini…"), color = Muted, modifier = Modifier.padding(top = 6.dp))
                }
                t.isEmpty -> Text(tx("Nessuna fermata di bus, metro, tram o taxi mappata entro 400 m."), color = Muted)
                else -> {
                    TransportGroup(Icons.Filled.Subway, tx("Metropolitana"), t.metro)
                    TransportGroup(Icons.Filled.Tram, tx("Tram"), t.tram)
                    TransportGroup(Icons.Filled.DirectionsBus, tx("Bus"), t.bus)
                    TransportGroup(Icons.Filled.LocalTaxi, tx("Taxi"), t.taxi)
                    TransportGroup(Icons.Filled.PedalBike, tx("Bici in condivisione"), t.bikes)
                }
            }
            if (coord != null) {
                Text(tx("Cerca su Google Maps:"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                GoogleMapsButtons(coord.first, coord.second, listOf(tx("Fermate bus") to "fermata autobus",
                    tx("Metro") to "metropolitana", tx("Taxi") to "taxi"))
            }
            if (t != null) SourceLink("OpenStreetMap", t.sourceUrl)
            Text(tx("Linee e fermate dai dati OpenStreetMap: per orari e percorsi dei bus consulta l'azienda di trasporto locale."),
                color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun TransportGroup(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, list: List<com.binario.treni.data.TransitStop>) {
    if (list.isEmpty()) return
    Row(Modifier.padding(top = 8.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, fontWeight = FontWeight.Bold)
    }
    list.forEach { s ->
        Column(Modifier.padding(start = 32.dp, bottom = 4.dp)) {
            Text(s.name + " · ${s.distance} m", fontSize = 15.sp)
            if (s.lines.isNotEmpty()) Text(tx("Linee") + ": " + s.lines.joinToString(", "), color = Muted, fontSize = 13.sp)
            if (s.extra.isNotBlank()) Text(s.extra, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SummaryRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(120.dp))
        Text(value, modifier = Modifier.weight(1f))
    }
}

fun dial(ctx: Context, number: String) {
    try {
        ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:$number")))
    } catch (_: Exception) {
    }
}

fun mail(ctx: Context, to: String) {
    try {
        ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:$to")))
    } catch (_: Exception) {
        toast(ctx, tx("Nessuna app email"))
    }
}

/** Stazioni vicine alla posizione attuale, in lista o su mappa. */
@Composable
fun NearbyScreen(onBack: () -> Unit, onBoard: (Station) -> Unit, go: (String) -> Unit = {}) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasLocation(ctx)) }
    var loc by remember { mutableStateOf<Location?>(null) }
    var near by remember { mutableStateOf<List<Pair<Api.GeoStation, Float>>?>(null) }
    var status by remember { mutableStateOf(tx("Ricerca della posizione…")) }
    var tab by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r.values.any { it }
    }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    LaunchedEffect(granted) {
        if (!granted) {
            status = tx("Serve il permesso di posizione per trovare le stazioni vicine."); return@LaunchedEffect
        }
        val l = currentLocation(ctx)
        if (l == null) {
            status = tx("Posizione non disponibile. Attiva il GPS e riprova."); return@LaunchedEffect
        }
        loc = l
        status = tx("Caricamento elenco stazioni (solo la prima volta)…")
        near = try {
            withContext(Dispatchers.IO) {
                // In Germania: stazioni tedesche dagli orari ufficiali DELFI (l'elenco italiano non le contiene)
                val de = if (com.binario.treni.data.GermanyLive.inGermany(l.latitude, l.longitude))
                    com.binario.treni.data.GermanyLive.nearby(l.latitude, l.longitude).map { (st, la, lo) -> Api.GeoStation(st, la, lo) }
                else emptyList()
                (de + runCatching { Api.allStations(ctx) }.getOrDefault(emptyList())).map { g ->
                    val d = FloatArray(1)
                    Location.distanceBetween(l.latitude, l.longitude, g.lat, g.lon, d)
                    g to d[0]
                }.sortedBy { it.second }.take(25).also { if (it.isEmpty()) throw java.io.IOException("empty") }
            }
        } catch (e: Exception) {
            status = tx("Elenco stazioni non disponibile"); null
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Stazioni vicine"), onBack)
        Box(Modifier.fillMaxWidth().background(Green).padding(horizontal = 16.dp, vertical = 8.dp)) {
            Segmented(listOf(tx("Elenco"), tx("Mappa")), tab) { tab = it }
        }
        // Servizi in stazione (prima erano in Altro): sempre visibili, anche senza GPS
        Text(tx("Servizi in stazione"), color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 2.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp)) {
            listOf(
                Triple(Icons.Filled.Wc, tx("WC vicini"), "toilets?id=&name="),
                Triple(Icons.Filled.ConfirmationNumber, tx("Rivendite e biglietterie vicine"), "sellers?id=&name="),
                Triple(Icons.Filled.DirectionsBus, com.binario.treni.data.I18n.tr("Bus sostitutivi", "Replacement buses"), "rbus?id=&name="),
                Triple(Icons.Filled.LocalTaxi, tx("Taxi vicini"), "taxi?id=&name="),
                Triple(Icons.Filled.MonitorHeart, com.binario.treni.data.I18n.tr("Defibrillatori (DAE)", "Defibrillators (AED)"), "dae?id=&name="),
            ).forEach { (icon, label, route) ->
                AssistChip(onClick = { go(route) }, label = { Text(label, fontSize = 13.sp) },
                    leadingIcon = { Icon(icon, null, tint = Green, modifier = Modifier.size(18.dp)) },
                    modifier = Modifier.padding(end = 6.dp))
            }
        }
        val n = near
        if (n == null) {
            MessageBox(status)
            if (!granted) Button(
                { launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) },
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                modifier = Modifier.align(Alignment.CenterHorizontally),
            ) { Text(tx("Concedi permesso")) }
        } else if (tab == 0) {
            LazyColumn {
                items(n) { (g, d) ->
                    SimpleRow(Icons.Filled.Place, g.station.name, if (d < 1000) "${d.toInt()} m" else String.format("%.1f km", d / 1000)) {
                        onBoard(g.station)
                    }
                }
            }
        } else {
            var picked by remember { mutableStateOf<Pair<Api.GeoStation, Float>?>(null) }
            Box(Modifier.fillMaxSize()) {
                OsmMap(
                    n.map { (g, d) -> MapPoint(g.lat, g.lon, g.station.name, com.binario.treni.data.I18n.tr("Tocca di nuovo per tabellone e servizi", "Tap again for the board and services")) { picked = g to d } },
                    drawLine = false, modifier = Modifier.fillMaxSize(),
                    me = loc?.let { it.latitude to it.longitude },
                    googleQuery = "stazione ferroviaria",
                )
                picked?.let { (g, d) ->
                    val args = "?id=" + android.net.Uri.encode(g.station.id) + "&name=" + android.net.Uri.encode(g.station.name)
                    Surface(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(8.dp),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), shadowElevation = 6.dp,
                        color = MaterialTheme.colorScheme.surface,
                    ) {
                        Column(Modifier.padding(vertical = 8.dp)) {
                            Text(g.station.name + " · " + (if (d < 1000) "${d.toInt()} m" else String.format("%.1f km", d / 1000)),
                                fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 14.dp))
                            Text(com.binario.treni.data.I18n.tr("Servizi vicino a questa stazione", "Services near this station"), color = Muted, fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp))
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp)) {
                                listOf(
                                    Triple(Icons.Filled.Train, com.binario.treni.data.I18n.tr("Tabellone", "Board"), ""),
                                    Triple(Icons.Filled.Wc, tx("WC vicini"), "toilets$args"),
                                    Triple(Icons.Filled.ConfirmationNumber, tx("Rivendite e biglietterie vicine"), "sellers$args"),
                                    Triple(Icons.Filled.DirectionsBus, com.binario.treni.data.I18n.tr("Bus sostitutivi", "Replacement buses"), "rbus$args"),
                                    Triple(Icons.Filled.LocalTaxi, tx("Taxi vicini"), "taxi$args"),
                                    Triple(Icons.Filled.MonitorHeart, com.binario.treni.data.I18n.tr("Defibrillatori (DAE)", "Defibrillators (AED)"), "dae$args"),
                                ).forEach { (icon, label, route) ->
                                    AssistChip(onClick = { if (route.isEmpty()) onBoard(g.station) else go(route) }, label = { Text(label, fontSize = 13.sp) },
                                        leadingIcon = { Icon(icon, null, tint = Green, modifier = Modifier.size(18.dp)) },
                                        modifier = Modifier.padding(end = 6.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

internal fun hasLocation(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
internal suspend fun currentLocation(ctx: Context): Location? {
    val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
    val providers = lm.getProviders(true)
    val last = providers.mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
        .maxByOrNull { it.time }
    if (last != null && System.currentTimeMillis() - last.time < 30 * 60_000L) return last
    val provider = when {
        providers.contains(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
        providers.contains(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
        else -> return last
    }
    val fresh = withTimeoutOrNull(15_000) {
        suspendCancellableCoroutine<Location?> { cont ->
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    lm.removeUpdates(this)
                    if (cont.isActive) cont.resume(location)
                }

                // Necessari su Android 8–10, dove questi metodi non hanno un'implementazione predefinita.
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
            cont.invokeOnCancellation { lm.removeUpdates(listener) }
        }
    }
    return fresh ?: last
}

/**
 * Stazione in Germania: servizi, ascensori e accessibilità sulla pagina ufficiale bahnhof.de (DB InfraGO)
 * e l'assistenza DB per persone con disabilità (Mobilitätsservice-Zentrale).
 */
@Composable
private fun DbStationCard(station: Station) {
    val ctx = LocalContext.current
    val de = com.binario.treni.data.GermanyLive
    WhiteCard {
        CardTitle(tx("Servizi in stazione (Germania)"))
        MenuRow(Icons.Filled.Store, tx("Servizi, negozi, DB Lounge e mappa"), "bahnhof.de") { openUrl(ctx, de.bahnhofUrl(station.name)) }
        MenuRow(Icons.Filled.Elevator, tx("Ascensori con stato in tempo reale"), "bahnhof.de") { openUrl(ctx, de.bahnhofUrl(station.name, "aufzuege")) }
        MenuRow(Icons.Filled.Accessible, tx("Accessibilità della stazione"), "bahnhof.de") { openUrl(ctx, de.bahnhofUrl(station.name, "ausstattung-barrierefreiheit")) }
        MenuRow(Icons.Filled.Phone, tx("Assistenza per persone con disabilità (DB)"),
            "MSZ " + de.MSZ_LABEL + " · " + tx("lun–ven 6–22, sab–dom e festivi 8–20")) {
            try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:" + de.MSZ_PHONE))) } catch (_: Exception) { }
        }
        MenuRow(Icons.Filled.EditNote, tx("Prenota l'assistenza online (entro le 20 del giorno prima)"), "msz.bahnhof.de") { openUrl(ctx, de.MSZ_FORM) }
    }
}

/** Servizi FFS e negozi della stazione dal sito sbb.ch: aperto/chiuso adesso, posizione e orari di oggi. */
@Composable
private fun SbbServicesCard(page: com.binario.treni.data.SbbStations.Page) {
    val ctx = LocalContext.current
    val sbb = com.binario.treni.data.SbbStations
    var list by remember(page.slug) { mutableStateOf<List<com.binario.treni.data.SbbStations.Service>?>(null) }
    var failed by remember(page.slug) { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var showShops by remember { mutableStateOf(false) }
    val hours = remember(page.slug) { mutableStateMapOf<String, String>() }
    LaunchedEffect(page.slug, tick) {
        failed = false
        list = try {
            withContext(Dispatchers.IO) { sbb.services(page) }
        } catch (e: Exception) {
            failed = true; null
        }
        // Orari di oggi dei servizi FFS (una pagina breve per servizio, in parallelo)
        val services = list.orEmpty().filter { it.sbb }
        val found = withContext(Dispatchers.IO) {
            coroutineScope {
                services.map { s ->
                    async { s.path to runCatching { sbb.hours(s) }.getOrDefault("") }
                }.map { it.await() }
            }
        }
        found.forEach { (k, h) -> if (h.isNotBlank()) hours[k] = h }
    }
    WhiteCard {
        CardTitle(tx("Servizi FFS in stazione"))
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
            val l = list
            when {
                failed -> Text(tx("Servizi FFS non raggiungibili ora.") + " " + tx("Tocca per riprovare"), color = Muted, fontSize = 13.sp,
                    modifier = Modifier.clickable { tick++ })
                l == null -> Text(tx("Leggo i servizi dal sito FFS…"), color = Muted, fontSize = 13.sp)
                else -> {
                    val services = l.filter { it.sbb }
                    val shops = l.filter { !it.sbb }
                    services.forEach { s -> SbbServiceRow(s, hours[s.path]) { openUrl(ctx, s.url) } }
                    if (shops.isNotEmpty()) {
                        TextButton({ showShops = !showShops }) {
                            Text(
                                (if (showShops) tx("Nascondi negozi e ristoro") else tx("Negozi e ristoro")) +
                                    " (" + shops.count { it.open } + " " + tx("aperti") + " / " + shops.size + ")",
                                color = Green,
                            )
                        }
                        if (showShops) shops.sortedByDescending { it.open }.forEach { s -> SbbServiceRow(s, null) { openUrl(ctx, s.url) } }
                    }
                }
            }
            Text(tx("Aperto/chiuso e orari: sito FFS, aggiornati ogni 5 minuti. Tutti i dati sono senza garanzia."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            SourceLink(tx("Pagina della stazione su sbb.ch"), sbb.pageUrl(page))
        }
    }
}

@Composable
private fun SbbServiceRow(s: com.binario.treni.data.SbbStations.Service, hours: String?, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(s.name, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            val sub = listOfNotNull(s.location.ifBlank { null }, hours?.ifBlank { null }).joinToString(" · ")
            if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text(if (s.open) tx("Aperto") else tx("Chiuso"), color = if (s.open) Green else Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}
