package com.binario.treni.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n

/**
 * Elementi grafici in stile sito Trenord (biglietterie.trenord.it/punti-vendita), usati da Punti vendita e WC:
 * casella "Inserisci città o stazione", pulsanti grandi a due colonne con bordo verde (pieni quando scelti)
 * e il pulsante verde "Mostra elenco" / "Mostra mappa" sopra la mappa.
 */

/** Una voce della griglia: chiave, testo, icona. */
data class TrenordChoice(val key: String, val label: String, val icon: ImageVector)

/** Casella di ricerca bianca con bordo grigio chiaro e angoli arrotondati; "Cerca" sulla tastiera conferma. */
@Composable
fun TrenordSearchField(
    value: String,
    onChange: (String) -> Unit,
    onSubmit: () -> Unit,
    placeholder: String = I18n.tr("Inserisci città o stazione", "Enter town or station"),
    onMyLocation: (() -> Unit)? = null,
) {
    val focus = LocalFocusManager.current
    OutlinedTextField(
        value, onChange, singleLine = true,
        placeholder = { Text(placeholder, color = Muted, fontSize = 17.sp) },
        leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (value.isNotEmpty()) IconButton({ onChange(""); onSubmit() }) { Icon(Icons.Filled.Close, I18n.tr("Cancella", "Clear")) }
                if (onMyLocation != null) IconButton(onMyLocation) {
                    Icon(Icons.Filled.MyLocation, I18n.tr("Vicino a me", "Near me"), tint = Green)
                }
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus(); onSubmit() }),
        shape = RoundedCornerShape(8.dp),
        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFFCFCFCF), focusedBorderColor = Green),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

/** Griglia a due colonne di pulsanti grandi (bordo verde, pieni di verde quando scelti), come sul sito Trenord. */
@Composable
fun TrenordChoiceGrid(choices: List<TrenordChoice>, isSelected: (String) -> Boolean, counts: Map<String, Int> = emptyMap(), onClick: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        choices.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { ch ->
                    val sel = isSelected(ch.key)
                    val fg = if (sel) Color.White else MaterialTheme.colorScheme.onSurface
                    Surface(
                        onClick = { onClick(ch.key) },
                        modifier = Modifier.weight(1f).fillMaxHeight().semantics { role = Role.Tab; selected = sel },
                        shape = RoundedCornerShape(14.dp),
                        color = if (sel) Green else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(2.dp, Green),
                    ) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(ch.icon, null, tint = fg, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(ch.label, color = fg, fontWeight = FontWeight.Bold, fontSize = 17.sp, lineHeight = 20.sp)
                                counts[ch.key]?.let { n -> Text("$n", color = if (sel) Color(0xDDFFFFFF) else Muted, fontSize = 12.sp) }
                            }
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

/** Pulsante verde a pillola "Mostra elenco" / "Mostra mappa", da mettere in basso al centro. */
@Composable
fun ShowListButton(showingList: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick, modifier = modifier, shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.White),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
        contentPadding = PaddingValues(horizontal = 22.dp, vertical = 12.dp),
    ) {
        Icon(if (showingList) Icons.Filled.Map else Icons.Filled.FormatListBulleted, null, Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(if (showingList) I18n.tr("Mostra mappa", "Show map") else I18n.tr("Mostra elenco", "Show list"),
            fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

/** Link rosso in corsivo come sul sito Trenord ("Ottieni indicazioni", "Visita la pagina"). */
@Composable
fun TrenordLink(text: String, onClick: () -> Unit) {
    Text(
        text, color = Color(0xFFC8102E), fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(4.dp)).clickable(onClick = onClick).padding(vertical = 8.dp, horizontal = 2.dp),
    )
}

/** Titolo con triangolino verde, come i nomi delle schede sul sito Trenord. */
@Composable
fun TrenordName(text: String, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.Top) {
        Icon(androidx.compose.material.icons.Icons.Filled.PlayArrow, null, tint = Green, modifier = Modifier.size(20.dp).padding(top = 2.dp))
        Spacer(Modifier.width(4.dp))
        Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}
