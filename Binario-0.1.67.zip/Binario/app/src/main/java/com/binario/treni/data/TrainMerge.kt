package com.binario.treni.data

import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Unisce le fonti disponibili per lo stesso treno, fermata per fermata, per qualsiasi treno e paese.
 *
 * Fonti (una per «tipo»):
 *  - IT = Italia: ViaggiaTreno + servizio live di Trenord (già unite nella base italiana; vale anche per la rete FerrovieNord);
 *  - CH = Svizzera: orario e tempo reale delle FFS (transport.opendata.ch);
 *  - TR = Transitous (orari ufficiali e tempo reale di Germania, Austria, Francia e altri paesi, anche Italia e Svizzera).
 * La base è la fonte con cui è stata aperta la scheda del treno; le altre si cercano da sole (numero del treno oppure ora e destinazione)
 * e si usano solo se confermate: devono avere almeno una fermata in comune con lo stesso orario (±3 min) e nessuna in conflitto.
 *
 * Per ogni fermata comanda la fonte del territorio: stazione svizzera (UIC 85…) → FFS; stazione italiana (codice ViaggiaTreno) →
 * Italia (Trenord/ViaggiaTreno); altrove → Transitous. Poi vengono la base e le altre. Dove la fonte principale non ha un dato
 * (orario effettivo, orario programmato, binario) lo prende dalla successiva. Le fermate che la base non elenca si aggiungono
 * (svizzere dalle FFS, italiane da ViaggiaTreno/Trenord, le altre da Transitous solo prima della prima o dopo l'ultima fermata della base).
 *
 * TrovaTreno non è una fonte live: l'app ne legge solo le statistiche mensili di puntualità. Italo e le ferrovie locali restano a fonte singola.
 * Gli abbinamenti si ricordano 10 minuti; se una fonte non risponde o non è confermata si usano quelle che ci sono (nessun errore).
 */
object TrainMerge {
    private const val IT = "IT"
    private const val CH = "CH"
    private const val TR = "TR"

    private class Match(val tr: TrainRef?, val ch: TrainRef?, val itRefs: List<TrainRef>, val at: Long)

    private val matches = ConcurrentHashMap<String, Match>()
    private val pool = Executors.newFixedThreadPool(6) { r -> Thread(r, "train-merge").apply { isDaemon = true } }

    private val CH_BOX = doubleArrayOf(45.80, 47.85, 5.95, 10.55)    // lat min, lat max, lon min, lon max
    private val IT_BOX = doubleArrayOf(36.50, 47.10, 6.60, 18.60)

    /**
     * Nome di fermata confrontabile tra fonti diverse: senza accenti, punteggiatura, suffisso del paese «(CH)» e sigla della rete
     * FerrovieNord («Milano Cadorna FN» = «Milano Cadorna»).
     */
    private fun norm(n: String): String = java.text.Normalizer.normalize(n.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .replace(Regex("\\((ch|de|at|fr)\\)"), " ")
        .replace(Regex("\\bf\\.\\s?n\\.?"), " fn ")
        .replace(Regex("\\b(fn|ferrovienord|ferrovie nord)\\b"), " ")
        .replace(Regex("[^a-z0-9]+"), "")
    private fun isItalianId(id: String) = Regex("^S\\d{5}$").matches(id)
    private fun inBox(c: Pair<Double, Double>?, b: DoubleArray) = c != null && c.first in b[0]..b[1] && c.second in b[2]..b[3]

    private fun coordOf(s: TrainStop): Pair<Double, Double>? =
        GermanyLive.coords[s.id] ?: SwissLive.coords[s.id] ?: FnNetwork.coord(s.id)

    /** Tipo di fonte della scheda aperta; null = nessuna unione (Italo, ferrovie locali). */
    private fun kindOf(st: TrainStatus): String? {
        val o = st.originCode
        return when {
            SwissLive.isSwiss(o) -> CH
            GermanyLive.isTransitousRef(o) -> TR
            o.startsWith(LocalRail.PREFIX + "|") || o.startsWith(ItaloLive.PREFIX + "|") -> null
            else -> IT
        }
    }

    private fun label(kind: String, st: TrainStatus): String = when (kind) {
        IT -> if (TrainAliases.isTrenordRun(st)) "Trenord" else "ViaggiaTreno"
        CH -> "FFS"
        else -> "Transitous"
    }

    fun merge(base: TrainStatus): TrainStatus {
        val bk = kindOf(base) ?: return base
        if (base.stops.size < 2 || base.cancelled) return base
        val key = bk + "|" + base.number + "|" + base.date
        val now = System.currentTimeMillis()
        var m = matches[key]
        val first = base.stops.first()
        val last = base.stops.last()
        if (m == null || now - m.at > 10 * 60_000L) m = findMatches(base, bk, first, last, now).also { matches[key] = it }
        val mt: Match = m ?: return base

        val fT = mt.tr?.let { r -> pool.submit(Callable<TrainStatus?> { GermanyLive.status(r) }) }
        val fC = mt.ch?.let { r -> pool.submit(Callable<TrainStatus?> { SwissLive.status(r) }) }
        val fI = if (mt.itRefs.isEmpty()) null else pool.submit(Callable<TrainStatus?> {
            for (r in mt.itRefs) {
                val s = try { Api.statusBasic(r) } catch (_: Exception) { null } ?: continue
                if (confirmed(base, s)) return@Callable s
            }
            null
        })
        fun <T> await(f: java.util.concurrent.Future<T?>?, sec: Long): T? = try { f?.get(sec, TimeUnit.SECONDS) } catch (_: Exception) { null }
        val others = HashMap<String, TrainStatus>()
        await(fT, 10)?.takeIf { confirmed(base, it) }?.let { others[TR] = it }
        await(fC, 10)?.takeIf { confirmed(base, it) }?.let { others[CH] = it }
        await(fI, 12)?.let { others[IT] = it }
        if (others.isEmpty()) return base
        return try { combine(base, bk, others) } catch (_: Exception) { base }
    }

    /** Cerca le altre fonti per questo treno (solo dove ha senso per i paesi toccati). */
    private fun findMatches(base: TrainStatus, bk: String, first: TrainStop, last: TrainStop, now: Long): Match {
        val sched = if (first.schedDep > 0) first.schedDep else base.depTime
        val n = base.stops.size
        val coords = base.stops.map { it to coordOf(it) }
        // Transitous: ha quasi tutti i paesi
        val fTr = if (bk == TR) null else pool.submit(Callable<TrainRef?> {
            GermanyLive.findTripRef(base.number, first.name, if (bk == IT) FnNetwork.coord(first.id) else coordOf(first), sched, last.name,
                country = if (bk == IT) "IT" else null)
        })
        // FFS: solo se il treno tocca la Svizzera (fermate in territorio svizzero, oppure treno italiano: si prova con le fermate vicine ai capolinea)
        val chCand: List<TrainStop> = when (bk) {
            CH -> emptyList()
            IT -> (base.stops.filter { !isItalianId(it.id) } + listOfNotNull(base.stops.getOrNull(0), base.stops.getOrNull(1),
                base.stops.getOrNull(n - 2), base.stops.getOrNull(n - 1))).distinctBy { norm(it.name) }.take(5)
            else -> coords.filter { inBox(it.second, CH_BOX) }.map { it.first }.take(4)
        }
        val fCh = if (chCand.isEmpty()) null else pool.submit(Callable<TrainRef?> {
            for (f in chCand) {
                val t = if (f.schedDep > 0) f.schedDep else f.schedArr
                if (t <= 0) continue
                SwissLive.findRef(base.number, f.name, t, last.name)?.let { return@Callable it }
            }
            null
        })
        // Italia: se il treno tocca l'Italia (fermate con coordinate in Italia). I numeri uguali di treni diversi si scartano dopo, per confronto delle fermate.
        val itRefs = if (bk == IT || coords.none { inBox(it.second, IT_BOX) }) emptyList()
        else try { Api.trainLookup(base.number).take(3) } catch (_: Exception) { emptyList() }
        val tr = try { fTr?.get(10, TimeUnit.SECONDS) } catch (_: Exception) { null }
        val ch = try { fCh?.get(15, TimeUnit.SECONDS) } catch (_: Exception) { null }
        return Match(tr, ch, itRefs, now)
    }

    /** L'altra fonte descrive davvero lo stesso treno: almeno una fermata in comune con lo stesso orario (±3 min) e nessuna fermata in comune con orario molto diverso. */
    private fun confirmed(base: TrainStatus, other: TrainStatus): Boolean {
        fun t(s: TrainStop) = if (s.schedDep > 0) s.schedDep else s.schedArr
        val o = other.stops.associateBy { norm(it.name) }
        var same = 0
        for (b in base.stops) {
            val x = o[norm(b.name)] ?: continue
            val tb = t(b); val tx = t(x)
            if (tb <= 0 || tx <= 0) continue
            val d = Math.abs(tb - tx)
            if (d <= 3 * 60_000L) same++ else if (d > 10 * 60_000L && d < 20 * 3_600_000L) return false
        }
        return same >= 1
    }

    private fun hasReal(s: TrainStop) = s.realArr > 0 || s.realDep > 0

    private fun combine(base: TrainStatus, bk: String, others: Map<String, TrainStatus>): TrainStatus {
        val all: Map<String, TrainStatus> = others + (bk to base)
        val byName: Map<String, Map<String, TrainStop>> = all.mapValues { (_, st) -> st.stops.associateBy { norm(it.name) } }
        val labels: Map<String, String> = all.mapValues { (k, st) -> label(k, st) }
        fun isChStop(s: TrainStop?) = s != null && s.id.startsWith(SwissLive.PREFIX + "85")
        fun isItStop(s: TrainStop?) = s != null && isItalianId(s.id)

        /** Fonte che comanda sulla fermata [name], secondo il territorio. */
        fun authority(name: String): String? {
            val k = norm(name)
            if (isChStop(byName[CH]?.get(k))) return CH
            if (isItStop(byName[IT]?.get(k))) return IT
            return null
        }

        val used = LinkedHashSet<String>()
        val order = listOf(bk, TR, CH, IT).distinct()

        fun prioFor(name: String): List<Pair<String, TrainStop>> {
            val k = norm(name)
            val auth = authority(name)
            val kinds = listOfNotNull(auth) + (if (auth == null) listOf(TR) else emptyList()) + order
            return kinds.distinct().mapNotNull { kk -> byName[kk]?.get(k)?.let { kk to it } }
        }

        val merged = ArrayList<TrainStop>()
        for (b in base.stops) merged += pick(prioFor(b.name), labels, used)

        // Fermate che la base non elenca
        val have = base.stops.map { norm(it.name) }.toMutableSet()
        fun tOf(s: TrainStop) = s.schedDep.takeIf { it > 0 } ?: s.schedArr
        val bFirst = tOf(base.stops.first()); val bLast = tOf(base.stops.last())
        fun insert(s: TrainStop) {
            val t = tOf(s)
            val idx = merged.indexOfFirst { x -> tOf(x) > t }
            if (idx < 0) merged += s else merged.add(idx, s)
        }
        for ((kk, st) in all) {
            if (kk == bk) continue
            for (x in st.stops) {
                val nk = norm(x.name)
                if (nk in have) continue
                val t = tOf(x)
                if (t <= 0) continue
                val ok = when (kk) {
                    CH -> isChStop(x)                                  // tratta svizzera
                    IT -> isItStop(x)                                  // tratta italiana
                    else -> t < bFirst || t > bLast                    // Transitous: solo fuori dal tratto della base
                }
                if (!ok) continue
                have += nk
                insert(pick(prioFor(x.name).ifEmpty { listOf(kk to x) }, labels, used))
            }
        }

        val stops = merged.toList()
        val lastPassed = stops.lastOrNull { it.passed }
        val delay = lastPassed?.delay ?: base.delay
        val srcOrder = (listOf(IT, CH, TR).map { labels[it] } + listOf(labels[bk])).filterNotNull().filter { it in used }.distinct()
        val info = (base.info.takeIf { it.isNotBlank() }?.let { it + "\n" } ?: "") + I18n.tr("Fonti", "Sources") + ": " + srcOrder.joinToString(" · ")
        val srcOfLast = lastPassed?.src.orEmpty()
        return base.copy(
            stops = stops,
            origin = stops.first().name, destination = stops.last().name,
            delay = delay,
            lastStation = if (lastPassed != null && srcOfLast != labels[bk]) lastPassed.name else base.lastStation,
            lastTime = if (lastPassed != null && srcOfLast != labels[bk]) maxOf(lastPassed.realDep, lastPassed.realArr) else base.lastTime,
            info = info,
            sources = srcOrder,
        )
    }

    /** Sceglie la fonte principale per la fermata (la prima, in ordine di priorità, con un rilevamento; altrimenti con un ritardo; altrimenti la prima) e completa i campi vuoti con le successive. */
    private fun pick(prio: List<Pair<String, TrainStop>>, labels: Map<String, String>, used: MutableSet<String>): TrainStop {
        val primary = prio.firstOrNull { hasReal(it.second) } ?: prio.firstOrNull { it.second.delay != 0 } ?: prio.first()
        var s = primary.second
        val lbl = labels[primary.first].orEmpty()
        used += lbl
        if (s.schedArr == 0L) prio.firstOrNull { it.second.schedArr > 0 }?.let { s = s.copy(schedArr = it.second.schedArr) }
        if (s.schedDep == 0L) prio.firstOrNull { it.second.schedDep > 0 }?.let { s = s.copy(schedDep = it.second.schedDep) }
        if (s.platform.isBlank() && s.schedPlatform.isBlank() && s.realPlatform.isBlank()) {
            prio.firstOrNull { it.second.platform.isNotBlank() || it.second.schedPlatform.isNotBlank() }?.let { o ->
                s = s.copy(platform = o.second.platform, schedPlatform = o.second.schedPlatform, realPlatform = o.second.realPlatform,
                    platformChanged = o.second.platformChanged, platformConfirmed = o.second.platformConfirmed)
                used += labels[o.first].orEmpty()
            }
        }
        return s.copy(src = lbl)
    }
}
