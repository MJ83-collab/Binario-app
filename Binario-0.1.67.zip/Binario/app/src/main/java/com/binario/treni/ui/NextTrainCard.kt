package com.binario.treni.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Fmt
import com.binario.treni.data.Habit
import com.binario.treni.data.Habits
import com.binario.treni.data.NextTrain
import com.binario.treni.data.Station
import com.binario.treni.data.TrainRef
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * "Il tuo prossimo treno": all'apertura mostra subito il treno che prendi di solito a quest'ora, con ritardo e
 * binario, e se è soppresso o in forte ritardo le alternative già pronte. Compare solo dopo che l'app ha visto
 * lo stesso treno almeno due volte nello stesso giorno della settimana (o tre volte nei feriali).
 */
@Composable
fun NextTrainCard(vm: MainViewModel, onTrain: (TrainRef) -> Unit, onRoute: (Station, Station?) -> Unit) {
    val ctx = LocalContext.current
    var habit by remember { mutableStateOf<Habit?>(Habits.next(vm.store.habits(), System.currentTimeMillis())) }
    val h = habit ?: return
    // Se lo stai già seguendo c'è già la scheda "Viaggio in corso"
    val tracked = remember { vm.store.tracked() }
    if (tracked != null && Habits.digits(tracked.number) == Habits.digits(h.number)) return
    var live by remember(h.key) { mutableStateOf<NextTrain.Live?>(null) }
    var alts by remember(h.key) { mutableStateOf<List<NextTrain.Alt>?>(null) }
    var loading by remember(h.key) { mutableStateOf(true) }
    val fg = rememberForeground()
    LaunchedEffect(h.key) {
        while (true) {
            loading = true
            val l = try {
                withContext(Dispatchers.IO) { NextTrain.live(h) }
            } catch (_: Exception) {
                null
            }
            live = l
            alts = if (l != null && l.needsAlternative) withContext(Dispatchers.IO) { NextTrain.alternatives(l) } else null
            loading = false
            delay(60_000L)
            waitForeground(fg)
        }
    }
    val l = live
    WhiteCard(onClick = { onTrain(l?.ref ?: TrainRef(h.number, h.originCode, 0L, h.title)) }) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Schedule, null, tint = Green)
                Spacer(Modifier.width(8.dp))
                Text(tx("Il tuo prossimo treno"), color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton({ vm.store.removeHabit(h.key); habit = null; toast(ctx, tx("Non te lo proporrò più")) }) {
                    Text(tx("Non è il mio"), color = Muted, fontSize = 12.sp)
                }
            }
            val dep = l?.dep ?: Habits.todayAt(h, System.currentTimeMillis())
            Text(h.title + " · " + Fmt.time(dep), fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text(
                h.board.name + (h.alight?.let { " → " + it.name } ?: l?.destination?.takeIf { it.isNotBlank() }?.let { " · " + tx("per") + " " + it } ?: ""),
                fontSize = 14.sp,
            )
            when {
                l == null && loading -> Text(tx("Aggiornamento…"), color = Muted, fontSize = 13.sp)
                l == null -> Text(tx("Impossibile caricare i dati del treno"), color = Muted, fontSize = 13.sp)
                else -> {
                    val bad = l.cancelled || l.delay >= 5
                    Text(
                        l.stateText() + (if (!l.cancelled && l.delay > 0 && l.found) " · " + tx("parte alle") + " " + Fmt.time(l.dep + l.delay * 60_000L) else ""),
                        color = if (bad) LateRed else if (l.found) Green else Muted, fontWeight = FontWeight.Medium,
                    )
                    if (l.platformText.isNotBlank() && !l.cancelled) {
                        Text(
                            tx("Binario") + " " + l.platformText + (if (l.platformChanged) " · " + tx("cambiato!") else ""),
                            color = if (l.platformChanged) LateRed else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (l.platformChanged) FontWeight.Bold else FontWeight.Normal, fontSize = 15.sp,
                        )
                    }
                }
            }
            val a = alts
            if (l != null && l.needsAlternative) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AltRoute, null, tint = Green, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (l.cancelled) tx("Alternative") else tx("Partono prima"), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                when {
                    a == null -> Text(tx("Cerco alternative…"), color = Muted, fontSize = 13.sp)
                    a.isEmpty() -> Text(tx("Nessuna alternativa a breve."), color = Muted, fontSize = 13.sp)
                    else -> a.forEach { x ->
                        Surface(
                            onClick = { x.ref?.let(onTrain) ?: onRoute(h.board, h.alight) },
                            color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(Modifier.padding(vertical = 6.dp)) {
                                Text(Fmt.time(x.dep) + "  " + x.title + (if (x.operator.isNotBlank() && !x.title.contains(x.operator, true)) " · " + x.operator else ""),
                                    fontWeight = FontWeight.Medium, fontSize = 15.sp)
                                Text(x.detail, color = Muted, fontSize = 13.sp)
                            }
                        }
                    }
                }
                TextButton({ onRoute(h.board, h.alight) }) { Text(tx("Tutte le soluzioni"), color = Green) }
            }
        }
    }
}
