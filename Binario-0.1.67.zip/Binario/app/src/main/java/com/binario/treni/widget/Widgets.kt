package com.binario.treni.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import com.binario.treni.MainActivity
import com.binario.treni.R
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.SearchFilter
import com.binario.treni.data.Store
import com.binario.treni.data.TrainRef
import com.binario.treni.data.WidgetConfig

enum class WidgetType { ROUTE, TRAIN, STATION, FAV }

/** Base comune: intestazione verde con titolo e ⟳, elenco righe caricate da [WidgetService]. */
abstract class BaseWidget : AppWidgetProvider() {
    abstract val type: WidgetType

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { Widgets.update(ctx, mgr, it, type) }
        mgr.notifyAppWidgetViewDataChanged(ids, R.id.w_list)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == Widgets.ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, javaClass))
            // Segnale immediato: l'utente vede che il tocco è arrivato
            try {
                android.widget.Toast.makeText(ctx, I18n.tr("Aggiorno il widget…", "Refreshing widget…"), android.widget.Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
            }
            ids.forEach { id ->
                val rv = RemoteViews(ctx.packageName, R.layout.widget)
                Widgets.applyHeader(rv)
                rv.setTextViewText(R.id.w_time, I18n.tr("aggiorno…", "refreshing…"))
                try { mgr.partiallyUpdateAppWidget(id, rv) } catch (_: Exception) { }
                // Nuovo collegamento all'elenco: alcuni launcher ignorano la sola richiesta di ricaricare
                Widgets.update(ctx, mgr, id, type, force = true)
            }
            mgr.notifyAppWidgetViewDataChanged(ids, R.id.w_list)
        }
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        val s = Store(ctx)
        ids.forEach { s.removeWidgetConfig(it); WidgetCache.clear(ctx, it) }
    }
}

class RouteWidget : BaseWidget() { override val type = WidgetType.ROUTE }
class TrainWidget : BaseWidget() { override val type = WidgetType.TRAIN }
class StationWidget : BaseWidget() { override val type = WidgetType.STATION }
class FavoritesWidget : BaseWidget() { override val type = WidgetType.FAV }

object Widgets {
    const val ACTION_REFRESH = "com.binario.treni.WIDGET_REFRESH"
    const val EXTRA_TYPE = "w_type"

    private val classes = mapOf(
        WidgetType.ROUTE to RouteWidget::class.java,
        WidgetType.TRAIN to TrainWidget::class.java,
        WidgetType.STATION to StationWidget::class.java,
        WidgetType.FAV to FavoritesWidget::class.java,
    )

    private val vintageClasses = mapOf(
        WidgetType.ROUTE to VintageRouteWidget::class.java,
        WidgetType.TRAIN to VintageTrainWidget::class.java,
        WidgetType.STATION to VintageStationWidget::class.java,
        WidgetType.FAV to VintageFavoritesWidget::class.java,
    )

    fun vintageClassOf(type: WidgetType): Class<*> = vintageClasses.getValue(type)

    fun typeOf(ctx: Context, id: Int): WidgetType {
        val cls = AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id)?.provider?.className ?: return WidgetType.FAV
        return classes.entries.firstOrNull { it.value.name == cls }?.key
            ?: vintageClasses.entries.firstOrNull { it.value.name == cls }?.key ?: WidgetType.FAV
    }

    fun isVintage(ctx: Context, id: Int): Boolean {
        val cls = AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id)?.provider?.className ?: return false
        return vintageClasses.values.any { it.name == cls }
    }

    fun title(ctx: Context, id: Int, type: WidgetType): String {
        val c = Store(ctx).widgetConfig(id)
        return when (type) {
            WidgetType.FAV -> "Preferiti"
            else -> c?.title?.ifBlank { null } ?: com.binario.treni.data.I18n.tr("Tocca per configurare", "Tap to set up")
        }
    }

    /** Disegna l'intestazione e collega l'elenco al servizio dati. */
    fun update(ctx: Context, mgr: AppWidgetManager, id: Int, type: WidgetType, force: Boolean = false) {
        if (isVintage(ctx, id)) {
            VintageRender.renderAll(ctx, intArrayOf(id), type, fetch = true) { }
            return
        }
        val rv = RemoteViews(ctx.packageName, R.layout.widget)
        applyHeader(rv)
        rv.setTextViewText(R.id.w_title, title(ctx, id, type))
        // L'ora viene aggiornata dal servizio quando i dati arrivano davvero (WidgetCache.stamp)
        val at = WidgetCache.load(ctx, id).second
        rv.setTextViewText(R.id.w_time, if (force) I18n.tr("aggiorno…", "refreshing…") else if (at > 0) Fmt.time(at) else "…")

        val svc = Intent(ctx, WidgetService::class.java)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putExtra(EXTRA_TYPE, type.name)
        // Con "force" l'indirizzo cambia: il launcher crea un elenco nuovo e ricarica davvero i dati
        if (force) svc.putExtra("nonce", System.currentTimeMillis())
        svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
        rv.setRemoteAdapter(R.id.w_list, svc)
        rv.setEmptyView(R.id.w_list, R.id.w_empty)

        // ⟳ aggiorna i widget di questo tipo
        val cls = classes.getValue(type)
        val refresh = PendingIntent.getBroadcast(ctx, cls.name.hashCode(), Intent(ctx, cls).setAction(ACTION_REFRESH),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        // ⟳ e anche l'ora: area di tocco più grande
        rv.setOnClickPendingIntent(R.id.w_refresh, refresh)
        rv.setOnClickPendingIntent(R.id.w_time, refresh)
        // Titolo: riconfigura (o apre l'app per i preferiti)
        val titleIntent = if (type == WidgetType.FAV) {
            Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_SCREEN, "trains")
        } else {
            Intent(ctx, WidgetConfigActivity::class.java)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .setAction("reconfigure_$id")
        }
        rv.setOnClickPendingIntent(R.id.w_title, PendingIntent.getActivity(ctx, 7000 + id, titleIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        rv.setOnClickPendingIntent(R.id.w_empty, PendingIntent.getActivity(ctx, 8000 + id, titleIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))

        // Tocco su una riga: apre il treno o il tabellone (i dati arrivano da fillInIntent)
        val template = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        rv.setPendingIntentTemplate(R.id.w_list, PendingIntent.getActivity(ctx, 9000 + id, template,
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))

        mgr.updateAppWidget(id, rv)
    }

    /** Aggiorna subito tutti i widget presenti sulla Home. */
    /** Intestazione del widget con il colore dell'app (blu o verde acqua in modalità daltonici). */
    fun applyHeader(rv: RemoteViews) {
        val bg = when (com.binario.treni.data.ColorBlind.mode) {
            "redgreen" -> R.drawable.widget_header_blue
            "tritan" -> R.drawable.widget_header_teal
            else -> R.drawable.widget_header
        }
        rv.setInt(R.id.w_header, "setBackgroundResource", bg)
    }

    /** Aggiornamento "al volo" (sblocco, apertura app): ricarica solo i widget con dati più vecchi di [minAgeMs]. */
    @Volatile private var lastStale = 0L

    fun refreshStale(ctx: Context, minAgeMs: Long = 90_000L) {
        // Sblocco, schermo acceso e apertura app possono scattare insieme: una sola passata ogni 20 secondi
        val t0 = System.currentTimeMillis()
        if (t0 - lastStale < 20_000L) return
        lastStale = t0
        try {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val now = System.currentTimeMillis()
            classes.forEach { (type, cls) ->
                val ids = mgr.getAppWidgetIds(ComponentName(app, cls)).filter { now - WidgetCache.stamp(app, it) > minAgeMs }
                if (ids.isNotEmpty()) {
                    ids.forEach { update(app, mgr, it, type, force = true) }
                    mgr.notifyAppWidgetViewDataChanged(ids.toIntArray(), R.id.w_list)
                }
            }
            vintageClasses.forEach { (type, cls) ->
                val ids = mgr.getAppWidgetIds(ComponentName(app, cls)).filter { now - WidgetCache.stamp(app, it) > minAgeMs }
                if (ids.isNotEmpty()) VintageRender.renderAll(app, ids.toIntArray(), type, fetch = true) { }
            }
        } catch (_: Exception) {
        }
    }

    private var unlockReceiver: android.content.BroadcastReceiver? = null

    /** Registra l'ascolto di sblocco/accensione schermo (non si può dichiarare nel manifest). */
    fun listenForUnlock(ctx: Context) {
        if (unlockReceiver != null) return
        val app = ctx.applicationContext
        val r = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { refreshStale(c) }
        }
        try {
            val f = android.content.IntentFilter().apply {
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            if (android.os.Build.VERSION.SDK_INT >= 33) app.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED) else app.registerReceiver(r, f)
            unlockReceiver = r
        } catch (_: Exception) {
        }
    }

    fun refreshAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        classes.forEach { (type, cls) ->
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isNotEmpty()) {
                ids.forEach { update(ctx, mgr, it, type) }
                mgr.notifyAppWidgetViewDataChanged(ids, R.id.w_list)
            }
        }
        vintageClasses.forEach { (type, cls) ->
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isNotEmpty()) VintageRender.renderAll(ctx, ids, type, fetch = false) { }
        }
    }
}

/** Una riga del widget. */
data class WRow(
    val time: String,
    val delay: String = "",
    val delayRed: Boolean = true,
    val main: String,
    val sub: String = "",
    val platform: String = "",
    val platformConfirmed: Boolean = false,
    val train: TrainRef? = null,
    val stationId: String = "",
    val stationName: String = "",
)

class WidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        Factory(applicationContext, intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0),
            WidgetType.valueOf(intent.getStringExtra(Widgets.EXTRA_TYPE) ?: "FAV"))

    class Factory(private val ctx: Context, private val id: Int, private val type: WidgetType) : RemoteViewsFactory {
        private var rows: List<WRow> = emptyList()

        override fun onCreate() {}
        override fun onDestroy() {}
        override fun getCount() = rows.size
        // Durante l'aggiornamento Android mantiene le righe precedenti: nessuno sfarfallio.
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = position.toLong()
        override fun hasStableIds() = false

        override fun onDataSetChanged() {
            // Due tentativi: ViaggiaTreno a volte risponde con errori momentanei.
            var fresh: List<WRow>? = null
            for (attempt in 0 until 2) {
                fresh = try { load() } catch (e: Exception) { null }
                if (fresh != null) break
                try { Thread.sleep(1500L * (attempt + 1)) } catch (_: InterruptedException) { break }
            }
            val ok = fresh
            rows = if (ok != null) {
                if (ok.isNotEmpty()) WidgetCache.save(ctx, id, ok)
                WidgetCache.stamp(ctx, id, type, System.currentTimeMillis(), offline = false)
                ok.ifEmpty {
                    if (Store(ctx).widgetConfig(id) == null && type != WidgetType.FAV) {
                        listOf(WRow("", main = I18n.tr("Tocca il titolo per scegliere cosa mostrare", "Tap the title to choose what to show")))
                    } else {
                        listOf(WRow("", main = I18n.tr("Nessun treno nelle prossime ore", "No trains in the next hours"),
                            sub = I18n.tr("Tocca ⟳ per aggiornare", "Tap ⟳ to refresh")))
                    }
                }
            } else {
                // Niente rete o servizio momentaneamente giù: teniamo gli ultimi dati validi invece di svuotare il widget.
                val (cached, at) = WidgetCache.load(ctx, id)
                if (cached.isNotEmpty()) {
                    WidgetCache.stamp(ctx, id, type, at, offline = true)
                    listOf(WRow("", main = I18n.tr("Dati delle ${Fmt.time(at)} (connessione assente)", "Data from ${Fmt.time(at)} (offline)"),
                        sub = I18n.tr("Si aggiorna da solo appena possibile · ⟳ per riprovare", "Refreshes automatically · ⟳ to retry"))) + cached
                } else {
                    WidgetCache.stampText(ctx, id, "⚠ " + I18n.tr("non aggiornato", "not updated"))
                    listOf(WRow("", main = I18n.tr("Servizio dati momentaneamente non raggiungibile", "Data service temporarily unreachable"),
                        sub = I18n.tr("Tocca ⟳ per riprovare", "Tap ⟳ to retry")))
                }
            }
        }

        /** Righe del widget (usate anche dai widget vintage, che le disegnano a palette). */
        fun loadRows(): List<WRow> = load()

        private fun delayOf(d: Int) = when {
            d > 0 -> "+$d'"
            d < 0 -> "$d'"
            else -> ""
        }

        private fun load(): List<WRow> {
            val store = Store(ctx)
            val cfg: WidgetConfig? = store.widgetConfig(id)
            return when (type) {
                WidgetType.STATION -> {
                    val st = cfg?.station ?: return emptyList()
                    // Di notte il tabellone è vuoto: cerchiamo in avanti fino ai primi treni del mattino
                    val now = System.currentTimeMillis()
                    var list = Api.boardAhead(st, true, now, hours = 4)
                    var tries = 0
                    if (list.isEmpty()) {
                        list = Api.boardAhead(st, true, now, hours = 9); tries = 1
                    }
                    val rows = list.take(40).map { b ->
                        WRow(Fmt.time(b.time), delayOf(b.delay), true, b.otherEnd, "${b.operator} ${b.title}".trim(), b.platformText, b.realPlatform.isNotBlank(), b.ref)
                    }
                    when {
                        rows.isEmpty() -> listOf(WRow("", main = I18n.tr("Nessuna partenza nelle prossime ore", "No departures in the next hours"),
                            sub = I18n.tr("Il widget si aggiorna da solo; tocca ⟳ per riprovare", "The widget refreshes itself; tap ⟳ to retry")))
                        tries > 0 -> listOf(WRow("", main = I18n.tr("Prime partenze", "First departures"),
                            sub = I18n.tr("Nessun treno ora: ecco i primi in programma", "No trains now: here are the first scheduled"))) + rows
                        else -> rows
                    }
                }
                WidgetType.ROUTE -> {
                    val t = cfg?.tratta ?: return emptyList()
                    val now = System.currentTimeMillis()
                    Api.solutions(t.from, t.to, now - 10 * 60_000L, SearchFilter.ALL, store.maxChanges, store.excluded)
                        .take(20).mapIndexed { i, s ->
                            val first = s.legs.firstOrNull()
                            var delay = ""
                            var plat = ""
                            var ref: TrainRef? = first?.let { TrainRef(it.number, label = it.title) }
                            // Ritardo e binario reali per le prime corse
                            if (first != null && i < 4 && s.dep - now < 3 * 3600_000L) {
                                try {
                                    val st = Api.status(TrainRef(first.number))
                                    delay = delayOf(st.delay)
                                    plat = st.stops.firstOrNull { it.name.equals(t.from.name, true) }?.platformText ?: ""
                                    ref = st.ref
                                } catch (_: Exception) {
                                }
                            }
                            WRow(Fmt.time(s.dep), delay, true, "→ ${Fmt.time(s.arr)}  ${t.to.name}",
                                s.legs.joinToString(" + ") { l ->
                                    "${l.operatorLabel} ${l.category} ${com.binario.treni.data.Operators.cleanNumber(l.number)}".trim()
                                } + (if (s.duration.isNotBlank()) " · ${s.duration}" else ""),
                                plat, plat.isNotBlank(), ref)
                        }
                }
                WidgetType.TRAIN -> {
                    val r = cfg?.train ?: return emptyList()
                    val st = Api.status(r)
                    val head = WRow("", "", true, st.stateText(),
                        if (st.lastStation.isNotBlank()) "(${Fmt.time(st.lastTime)}) ${st.lastStation}" else "${st.origin} → ${st.destination}",
                        train = st.ref)
                    listOf(head) + st.stops.map { s ->
                        val sched = if (s.schedDep > 0) s.schedDep else s.schedArr
                        val real = if (s.realDep > 0) s.realDep else s.realArr
                        WRow(Fmt.time(sched), if (real > 0) Fmt.time(real) else "", real > sched + 60_000,
                            s.name, if (s.passed) "Effettivo ${Fmt.time(real)}" else "Programmato",
                            s.platformText, s.realPlatform.isNotBlank(), stationId = s.id, stationName = s.name)
                    }
                }
                WidgetType.FAV -> {
                    val cached = WidgetCache.load(ctx, id).first
                    store.favTrains().map { r ->
                        val st = try {
                            Api.status(r)
                        } catch (e: Exception) {
                            try { Thread.sleep(800) } catch (_: InterruptedException) { }
                            try { Api.status(r) } catch (e2: Exception) { null }
                        }
                        if (st != null) {
                            WRow(Fmt.time(st.depTime), if (st.cancelled) "SOPP" else delayOf(st.delay), true,
                                "${st.operator} ${st.title}".trim(), "${st.origin} → ${st.destination}", train = st.ref)
                        } else {
                            // Ultimo stato noto di questo treno, se c'è; altrimenti una riga neutra
                            cached.firstOrNull { it.train?.number == r.number }
                                ?.let { c ->
                                    val mark = I18n.tr(" · non aggiornato", " · not updated")
                                    c.copy(sub = c.sub.removeSuffix(mark) + mark)
                                }
                                ?: WRow("", main = r.label, sub = I18n.tr("Stato non ancora disponibile", "Status not available yet"), train = r)
                        }
                    }
                }
            }
        }

        override fun getViewAt(position: Int): RemoteViews {
            val r = rows.getOrNull(position) ?: return RemoteViews(ctx.packageName, R.layout.widget_row)
            val v = RemoteViews(ctx.packageName, R.layout.widget_row)
            v.setTextViewText(R.id.r_time, r.time)
            v.setTextViewText(R.id.r_delay, (if (com.binario.treni.data.ColorBlind.on && r.delay.isNotBlank()) (if (r.delayRed) "▲ " else "✓ ") else "") + r.delay)
            v.setTextColor(R.id.r_delay, if (r.delayRed) com.binario.treni.data.ColorBlind.late.toInt() else com.binario.treni.data.ColorBlind.ok.toInt())
            v.setViewVisibility(R.id.r_delay, if (r.delay.isBlank()) View.GONE else View.VISIBLE)
            v.setTextViewText(R.id.r_main, r.main)
            v.setTextViewText(R.id.r_sub, r.sub)
            v.setViewVisibility(R.id.r_sub, if (r.sub.isBlank()) View.GONE else View.VISIBLE)
            v.setTextViewText(R.id.r_plat, r.platform)
            v.setViewVisibility(R.id.r_plat, if (r.platform.isBlank()) View.GONE else View.VISIBLE)
            val changed = r.platform.contains("→")
            v.setInt(R.id.r_plat, "setBackgroundResource", when {
                changed -> R.drawable.plat_changed
                r.platformConfirmed -> R.drawable.plat_real
                else -> R.drawable.plat_sched
            })
            v.setTextColor(R.id.r_plat, when {
                changed -> com.binario.treni.data.ColorBlind.late.toInt()
                r.platformConfirmed -> 0xFF1565C0.toInt()
                else -> 0xFF555555.toInt()
            })
            val fill = Intent()
            when {
                r.train != null -> fill.putExtra(MainActivity.EXTRA_TRAIN, r.train.toJson().toString())
                r.stationId.isNotBlank() -> fill.putExtra(MainActivity.EXTRA_STATION,
                    com.binario.treni.data.Station(r.stationName, r.stationId).toJson().toString())
            }
            v.setOnClickFillInIntent(R.id.r_root, fill)
            return v
        }
    }
}

/** Ultimi dati validi di ogni widget, per non mostrare "dati non disponibili" a ogni errore di rete momentaneo. */
object WidgetCache {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("widget_cache", Context.MODE_PRIVATE)

    fun save(ctx: Context, id: Int, rows: List<WRow>) {
        val a = org.json.JSONArray()
        rows.take(60).forEach { r ->
            a.put(org.json.JSONObject()
                .put("t", r.time).put("d", r.delay).put("dr", r.delayRed).put("m", r.main).put("s", r.sub)
                .put("p", r.platform).put("pc", r.platformConfirmed)
                .put("tr", r.train?.toJson()?.toString() ?: "")
                .put("si", r.stationId).put("sn", r.stationName))
        }
        prefs(ctx).edit().putString("rows_$id", a.toString()).putLong("at_$id", System.currentTimeMillis()).apply()
    }

    /** Solo l'ora dell'ultimo aggiornamento (senza leggere le righe). */
    fun stamp(ctx: Context, id: Int): Long = prefs(ctx).getLong("at_$id", 0L)

    fun load(ctx: Context, id: Int): Pair<List<WRow>, Long> {
        val p = prefs(ctx)
        val at = p.getLong("at_$id", 0L)
        val rows = try {
            val a = org.json.JSONArray(p.getString("rows_$id", "[]"))
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val tr = o.optString("tr")
                WRow(o.optString("t"), o.optString("d"), o.optBoolean("dr", true), o.optString("m"), o.optString("s"),
                    o.optString("p"), o.optBoolean("pc"),
                    if (tr.isNotBlank()) TrainRef.from(org.json.JSONObject(tr)) else null,
                    o.optString("si"), o.optString("sn"))
            }
        } catch (e: Exception) {
            emptyList()
        }
        // Dati troppo vecchi (oltre 6 ore) non servono più
        return if (at > 0 && System.currentTimeMillis() - at < 6 * 3600_000L) rows to at else emptyList<WRow>() to 0L
    }

    fun clear(ctx: Context, id: Int) {
        prefs(ctx).edit().remove("rows_$id").remove("at_$id").apply()
    }

    fun stampText(ctx: Context, id: Int, text: String) {
        try {
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            Widgets.applyHeader(rv)
            rv.setTextViewText(R.id.w_time, text)
            AppWidgetManager.getInstance(ctx).partiallyUpdateAppWidget(id, rv)
        } catch (_: Exception) {
        }
    }

    /** Aggiorna solo l'ora nell'intestazione: è l'ora dei dati mostrati, non dell'ultimo tentativo. */
    fun stamp(ctx: Context, id: Int, type: WidgetType, at: Long, offline: Boolean) {
        try {
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            Widgets.applyHeader(rv)
            rv.setTextViewText(R.id.w_time, (if (offline) "⚠ " else "") + Fmt.time(at))
            AppWidgetManager.getInstance(ctx).partiallyUpdateAppWidget(id, rv)
        } catch (_: Exception) {
        }
    }
}
