package com.binario.treni.data

import android.content.Context
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Avvisi ai viaggiatori di RFI (modifiche programmate alla circolazione) sulle tratte e linee preferite.
 * Fonte: feed RSS pubblico di RFI «Infomobilità – avvisi ai viaggiatori» (tutte le regioni). Una volta a settimana l'app legge il feed,
 * tiene gli avvisi che nominano una linea preferita (entrambi i capolinea o il nome della linea) o un treno preferito (numero),
 * manda una notifica per ogni avviso nuovo e li toglie da sola quando il periodo indicato è finito.
 */
object RfiNotices {
    const val FEED = "https://www.rfi.it/content/rfi/it/news-e-media/infomobilita.rss.notices.xml"
    private const val WEEK = 7 * 24 * 3600_000L
    private val rome = TimeZone.getTimeZone("Europe/Rome")

    data class Notice(val id: String, val title: String, val link: String, val from: String, val to: String)

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("binario_rfi", Context.MODE_PRIVATE)

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date())

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").replace(Regex("[^a-z0-9]+"), " ").trim()

    private class Item(val title: String, val desc: String, val link: String, val pub: Long)

    private fun fetch(): List<Item> {
        val c = (URL(FEED).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("User-Agent", "Binario/0.1.64 (contact: binario.appmail@gmail.com; Android app com.binario.treni)")
        }
        try {
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            val p = Xml.newPullParser()
            p.setInput(c.inputStream, null)
            val out = ArrayList<Item>()
            var t = ""; var d = ""; var l = ""; var pub = 0L
            var inItem = false
            var tag = ""
            val df = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US)
            while (p.next() != XmlPullParser.END_DOCUMENT) {
                when (p.eventType) {
                    XmlPullParser.START_TAG -> {
                        tag = p.name
                        if (tag == "item") { inItem = true; t = ""; d = ""; l = ""; pub = 0L }
                    }
                    XmlPullParser.TEXT, XmlPullParser.CDSECT -> if (inItem) {
                        val x = p.text.orEmpty()
                        when (tag) {
                            "title" -> t += x
                            "description" -> d += x
                            "link" -> l += x.trim()
                            "pubDate" -> pub = try { df.parse(x.trim())?.time ?: 0L } catch (_: Exception) { 0L }
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (p.name == "item") { inItem = false; out += Item(t.trim(), d.replace(Regex("<[^>]+>"), " ").trim(), l, pub) }
                        tag = ""
                    }
                }
            }
            return out
        } finally {
            c.disconnect()
        }
    }

    private val MONTHS = listOf("gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre")

    /** Fine del periodo: la data più lontana citata nel testo; se non c'è, 14 giorni dalla pubblicazione. */
    private fun endOf(text: String, pub: Long): String {
        val base = Calendar.getInstance(rome).apply { timeInMillis = if (pub > 0) pub else System.currentTimeMillis() }
        var best: Calendar? = null
        val re = Regex("(\\d{1,2})\\s+(" + MONTHS.joinToString("|") + ")(?:\\s+(\\d{4}))?", RegexOption.IGNORE_CASE)
        for (m in re.findAll(text)) {
            val day = m.groupValues[1].toInt()
            val mon = MONTHS.indexOf(m.groupValues[2].lowercase())
            var year = m.groupValues[3].toIntOrNull() ?: base.get(Calendar.YEAR)
            if (m.groupValues[3].isEmpty() && mon < base.get(Calendar.MONTH) - 1) year += 1
            val c = Calendar.getInstance(rome).apply { clear(); set(year, mon, day) }
            if (best == null || c.after(best)) best = c
        }
        val e = best ?: base.apply { add(Calendar.DAY_OF_MONTH, 14) }
        return "%04d-%02d-%02d".format(e.get(Calendar.YEAR), e.get(Calendar.MONTH) + 1, e.get(Calendar.DAY_OF_MONTH))
    }

    private val GENERIC = setOf("centrale", "porta", "nuova", "stazione", "fs", "citta", "nord", "sud", "hbf", "c le", "p ta")

    private fun stationIn(text: String, name: String): Boolean {
        val n = norm(name.substringBefore(" ("))
        if (n.isBlank()) return false
        if (" $n " in text) return true
        val toks = n.split(" ").filter { it.length > 2 && it !in GENERIC }
        return toks.isNotEmpty() && toks.all { " $it " in text }
    }

    private fun matches(text: String, lines: List<Linea>, trains: List<TrainRef>): Boolean {
        val t = " " + norm(text) + " "
        for (l in lines) {
            if (stationIn(t, l.a.name) && stationIn(t, l.b.name)) return true
            val code = norm(l.name)
            if (code.length >= 2 && code.length <= 4 && " $code " in t && l.operator.isNotBlank() && norm(l.operator).split(" ").first() in t) return true
        }
        for (r in trains) {
            val n = Api.trainDigits(r.number).trimStart('0')
            if (n.length >= 3 && " $n " in t) return true
        }
        return false
    }

    private fun load(ctx: Context): MutableList<Notice> {
        val a = try { JSONArray(prefs(ctx).getString("active", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until a.length()).map { a.getJSONObject(it) }.map { Notice(it.getString("id"), it.getString("title"), it.getString("link"), it.getString("from"), it.getString("to")) }.toMutableList()
    }

    private fun save(ctx: Context, l: List<Notice>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("link", it.link).put("from", it.from).put("to", it.to)) }
        prefs(ctx).edit().putString("active", a.toString()).apply()
    }

    /** Avvisi ancora validi: quelli con il periodo finito vengono tolti. */
    fun active(ctx: Context): List<Notice> {
        val all = load(ctx)
        val keep = all.filter { it.to >= today() }
        if (keep.size != all.size) save(ctx, keep)
        return keep
    }

    fun due(ctx: Context): Boolean = System.currentTimeMillis() - prefs(ctx).getLong("last", 0L) >= WEEK

    /**
     * Legge il feed (al massimo una volta a settimana, salvo [force]) e restituisce gli avvisi NUOVI sulle tratte preferite.
     * Se la rete non risponde non cambia nulla e si riprova al giro successivo.
     */
    fun refresh(ctx: Context, lines: List<Linea>, trains: List<TrainRef>, force: Boolean = false): List<Notice> {
        if (!force && !due(ctx)) return emptyList()
        if (lines.isEmpty() && trains.isEmpty()) { prefs(ctx).edit().putLong("last", System.currentTimeMillis()).apply(); return emptyList() }
        val items = try { fetch() } catch (_: Exception) { return emptyList() }
        val known = load(ctx).associateBy { it.id }.toMutableMap()
        val fresh = ArrayList<Notice>()
        for (it in items) {
            if (it.link.isBlank() || !matches(it.title + " " + it.desc, lines, trains)) continue
            val n = Notice(it.link, it.title, it.link, SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date(if (it.pub > 0) it.pub else System.currentTimeMillis())), endOf(it.title + " " + it.desc, it.pub))
            if (n.to < today()) continue
            if (n.id !in known) fresh += n
            known[n.id] = n
        }
        save(ctx, known.values.filter { it.to >= today() }.sortedBy { it.to })
        prefs(ctx).edit().putLong("last", System.currentTimeMillis()).apply()
        return fresh
    }
}
