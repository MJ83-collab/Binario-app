package com.binario.treni

import com.binario.treni.data.Health
import org.junit.Assert.fail
import org.junit.Assume.assumeTrue
import org.junit.Test

/**
 * Controllo delle fonti VERE, attivo solo nel controllo giornaliero su GitHub (variabile BINARIO_CANARY=1).
 * - Fonte che risponde ma con formato cambiato → il controllo fallisce e GitHub manda un'email: va aggiornato il lettore.
 * - Fonte irraggiungibile o in errore → solo segnalata (di solito è un problema temporaneo del servizio esterno).
 */
class LiveSourcesTest {
    @Test
    fun sourcesStillHaveTheExpectedFormat() {
        assumeTrue(System.getenv("BINARIO_CANARY") == "1")
        val results = Health.runAll()
        results.forEach { r -> println((if (r.ok) "OK   " else "KO   ") + r.check.name + " · " + r.millis + " ms · " + r.detail) }
        val changed = results.filter { !it.ok && it.detail.contains("formato") }
        if (changed.isNotEmpty()) fail("Formato cambiato: " + changed.joinToString { it.check.name })
    }
}
