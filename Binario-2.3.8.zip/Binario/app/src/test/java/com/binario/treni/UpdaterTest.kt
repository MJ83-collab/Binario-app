package com.binario.treni

import com.binario.treni.data.Updater
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class UpdaterTest {
    private fun release(name: String, url: String = "https://github.com/MJ83-collab/Binario-app/releases/download/v2.4/$name", pre: Boolean = false) =
        """{"tag_name":"v2.4","prerelease":$pre,"draft":false,"body":"• Novità","assets":[
           {"name":"notes.txt","browser_download_url":"https://example.org/notes.txt","size":10},
           {"name":"$name","browser_download_url":"$url","size":1234567}]}"""

    @Test
    fun readsVersionFromAssetName() {
        val r = Updater.parse(release("Binario-2.4-9.apk"))!!
        assertEquals("2.4", r.versionName)
        assertEquals(9L, r.versionCode)
        assertEquals(1234567L, r.size)
        assertEquals("• Novità", r.notes)
    }

    @Test
    fun ignoresUnsafeOrPrerelease() {
        assertNull(Updater.parse(release("Binario-2.4-9.apk", url = "http://example.org/x.apk")))
        assertNull(Updater.parse(release("Binario-2.4-9.apk", pre = true)))
        assertNull(Updater.parse(release("Binario-2.4.apk")))
    }
}
