package com.binario.treni

import com.binario.treni.data.TrenordFares
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TrenordFaresTest {
    @Test
    fun bandsAreConsistent() {
        // Le fasce coprono 1–180 km senza buchi e il prezzo di 2ª classe le identifica in modo univoco
        var next = 1
        TrenordFares.BANDS.forEach { b -> assertEquals(next, b.minKm); next = b.maxKm + 1 }
        assertEquals(181, next)
        assertEquals(TrenordFares.BANDS.size, TrenordFares.BANDS.map { it.ord2 }.distinct().size)
        assertEquals("41–50 km", TrenordFares.bandBySecondClassPrice(5.40)?.label)
        assertEquals(91.00, TrenordFares.bandByKm(45)!!.month2, 0.001)
        assertNull(TrenordFares.bandBySecondClassPrice(5.55))
    }

    @Test
    fun trenocitta() {
        assertEquals("Milano", TrenordFares.trenocittaCity("MILANO CADORNA"))
        assertEquals("Varese", TrenordFares.trenocittaCity("VARESE NORD"))
        assertNull(TrenordFares.trenocittaCity("SARONNO"))
        val b = TrenordFares.bandByKm(3)!!
        assertEquals(57.00, TrenordFares.trenocitta(b, "Milano")!!.second, 0.001)
    }
}
