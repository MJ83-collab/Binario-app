package com.binario.treni

import com.binario.treni.data.FnStats
import com.binario.treni.data.Stats
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test

class FnStatsTest {
    private val now = 1_792_080_000_000L // 15/10/2026 17:20 circa
    private val cadorna = FnStats.STATIONS.first { it.id == "S01066" }
    private val varese = FnStats.STATIONS.first { it.id == "S01738" }

    @Test
    fun linesFromRoute() {
        assertEquals(FnStats.Line.VARESE, FnStats.Line.of("LAVENO MOMBELLO LAGO", "Milano Cadorna"))
        assertEquals(FnStats.Line.VARESE, FnStats.Line.of("MILANO CADORNA", "Varese Nord"))
        assertEquals(FnStats.Line.COMO, FnStats.Line.of("COMO LAGO", "Saronno"))
        assertEquals(FnStats.Line.NOVARA, FnStats.Line.of("NOVARA NORD", "Milano Cadorna"))
        assertEquals(FnStats.Line.MALPENSA, FnStats.Line.of("MALPENSA AEROPORTO TERMINAL 2", "Busto Arsizio Nord"))
        assertEquals(FnStats.Line.ASSO, FnStats.Line.of("ASSO", "Milano Cadorna"))
        assertEquals(FnStats.Line.ISEO, FnStats.Line.of("BRESCIA", "Edolo"))
        // "CASSOLNOVO" contiene "ASSO" ma non è la linea di Asso
        assertEquals(FnStats.Line.OTHER, FnStats.Line.of("CASSOLNOVO", "Saronno"))
        assertEquals(FnStats.Line.OTHER, FnStats.Line.of("ALBAIRATE VERMEZZO", "Saronno"))
    }

    @Test
    fun countsArrivedTrainsOnce() {
        val st = JSONObject()
        val items = listOf(
            FnStats.Obs("12058", "VARESE NORD", now - 30 * 60_000L, 4, false), // arrivato, in orario
            FnStats.Obs("58", "LAVENO MOMBELLO LAGO", now - 40 * 60_000L, 12, false), // arrivato, in ritardo
            FnStats.Obs("10060", "VARESE NORD", now - 50 * 60_000L, 0, true), // soppresso
            FnStats.Obs("12062", "VARESE NORD", now + 20 * 60_000L, 0, false), // non ancora arrivato
            FnStats.Obs("66", "LAVENO MOMBELLO LAGO", now - 3 * 60_000L, 5, false), // arriverà tra 2 minuti
        )
        assertEquals(3, FnStats.ingest(st, cadorna, items, now))
        // Una seconda lettura dello stesso tabellone non conta di nuovo
        assertEquals(0, FnStats.ingest(st, cadorna, items, now))
        val s = FnStats.summarize(st)!!
        assertEquals(2, s.total.observed)
        assertEquals(1, s.total.onTime)
        assertEquals(1, s.total.cancelled)
        assertEquals(50.0, s.total.percent, 0.01)
        assertEquals("S01066", s.stations.single().key.removePrefix(FnStats.PREFIX))
        assertEquals(listOf(FnStats.PREFIX + "VARESE"), s.lines.map { it.key })
        assertEquals(setOf("12058", "58", "10060"), s.trains.map { it.key }.toSet())
        assertEquals(1, s.trains.first { it.key == "10060" }.cancelled)
        // Lo stesso treno in un'altra stazione è un altro arrivo
        assertEquals(1, FnStats.ingest(st, varese, listOf(FnStats.Obs("12058", "MILANO CADORNA", now - 30 * 60_000L, 7, false)), now))
    }

    @Test
    fun trovaTrenoCityOnlyNames() {
        assertEquals("Milano Porta Garibaldi", Stats.stationName("Milano", "milano-porta-garibaldi"))
        assertEquals("Milano Repubblica", Stats.stationName("Milano Repubblica", "milano-repubblica"))
        assertEquals("Varese", Stats.stationName("Varese", "varese"))
    }
}
