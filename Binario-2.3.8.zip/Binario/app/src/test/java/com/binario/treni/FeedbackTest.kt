package com.binario.treni

import com.binario.treni.data.Feedback
import com.binario.treni.data.Feedback.Block
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FeedbackTest {
    private val now = 1_800_000_000_000L
    private val opened = now - 60_000L
    private val good = "Il tabellone di Varese Nord non si aggiorna dopo le 18."

    @Test
    fun antiSpam() {
        assertEquals(Block.OK, Feedback.check(good, opened, now, emptyList(), 0))
        assertEquals(Block.TOO_FAST, Feedback.check(good, now - 2_000L, now, emptyList(), 0))
        assertEquals(Block.TOO_SOON, Feedback.check(good, opened, now, listOf(now - 60_000L), 0))
        assertEquals(Block.TOO_MANY, Feedback.check(good, opened, now, listOf(now - 3_600_000L, now - 7_200_000L, now - 10_800_000L), 0))
        assertEquals(Block.OK, Feedback.check(good, opened, now, listOf(now - 90_000_000L, now - 95_000_000L, now - 99_000_000L), 0))
        assertEquals(Block.NONSENSE, Feedback.check("asdasdasdasdasd", opened, now, emptyList(), 0))
        assertEquals(Block.NONSENSE, Feedback.check("!!!!!!!!!!!!!!!!", opened, now, emptyList(), 0))
        assertEquals(Block.LINKS, Feedback.check("guarda https://a.it https://b.it https://c.it ciao a tutti", opened, now, emptyList(), 0))
        assertEquals(Block.TOO_LONG, Feedback.check("parola ".repeat(700), opened, now, emptyList(), 0))
    }

    @Test
    fun formConfigAndBody() {
        val cfg = Feedback.parseConfig(
            """{"formUrl":"https://docs.google.com/forms/d/e/ABC/formResponse","name":"entry.1","email":"entry.2","kind":"entry.3","message":"entry.4","tech":"entry.5","key":"entry.6"}""",
        )!!
        val body = Feedback.body(cfg, Feedback.Report("Mario Rossi", "m@r.it", "Bug", "Non va", "Binario 2.3.2", 0L))
        assertTrue(body.contains("entry.1=Mario+Rossi"))
        assertTrue(body.contains("entry.6=" + Feedback.FORM_KEY))
        // Solo moduli Google
        assertNull(Feedback.parseConfig("""{"formUrl":"https://evil.example/formResponse","name":"entry.1","email":"entry.2","kind":"entry.3","message":"entry.4"}"""))
        // Modulo con solo nome, email, messaggio e chiave: tipo e dati tecnici finiscono nel messaggio
        val short = Feedback.parseConfig(
            """{"formUrl":"https://docs.google.com/forms/d/e/ABC/formResponse","name":"entry.1","email":"entry.2","message":"entry.4","key":"entry.6"}""",
        )!!
        val b2 = java.net.URLDecoder.decode(Feedback.body(short, Feedback.Report("Mario Rossi", "m@r.it", "Bug", "Non va", "Binario 2.3.2", 0L)), "UTF-8")
        assertTrue(b2.contains("entry.4=[Bug] Non va\n\n— Binario 2.3.2"))
        assertTrue(!b2.contains("entry.3"))
        assertTrue(Feedback.validEmail("mario.rossi@gmail.com"))
        assertTrue(!Feedback.validEmail("mario@"))
    }
}
