package com.binario.treni

import com.binario.treni.data.MalpensaFares
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MalpensaFaresTest {
    @Test
    fun stationsFromViaggiaTreno() {
        assertEquals(15.0, MalpensaFares.forStation("MILANO CADORNA").single().single, 0.001)
        assertEquals("Busto Arsizio FN", MalpensaFares.forStation("BUSTO ARSIZIO NORD").single().name)
        assertEquals("Busto Arsizio FS", MalpensaFares.forStation("BUSTO ARSIZIO").single().name)
        assertEquals(2, MalpensaFares.forStation("GALLARATE").size)
        assertEquals("Ferno-Lonate Pozzolo", MalpensaFares.forStation("FERNO-LONATE POZZOLO").single().name)
        assertEquals("Gaggiolo", MalpensaFares.forStation("CANTELLO-GAGGIOLO").single().name)
        assertTrue(MalpensaFares.forStation("VARESE NORD").isEmpty())
        assertTrue(MalpensaFares.forStation("COMO LAGO").isEmpty())
        assertTrue(MalpensaFares.isMalpensa("MALPENSA AEROPORTO TERMINAL 2"))
    }
}
