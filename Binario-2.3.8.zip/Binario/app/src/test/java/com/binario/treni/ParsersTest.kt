package com.binario.treni

import com.binario.treni.data.Operators
import com.binario.treni.data.OsmPlace
import com.binario.treni.data.Railways
import com.binario.treni.data.Stats
import com.binario.treni.data.TicketSellers
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Test dei "lettori" di dati su copie salvate delle pagine reali (ottobre 2026).
 * Girano a ogni compilazione: se una modifica al codice rompe un lettore, la build si ferma qui
 * invece di produrre un'app con funzioni vuote.
 */
class ParsersTest {
    @Test
    fun operatorFromTrainName() {
        assertEquals("Trenord", Operators.fromText("SU", "S50 TRENORD 25592"))
        assertEquals("TILO", Operators.fromText("RE", "SBB / SU S50 TRENORD 25591"))
        assertEquals("Trenitalia", Operators.fromText("FR", "9627"))
        assertEquals("Italo", Operators.fromText("ITA", "9925"))
        assertEquals("Trenord", Operators.fromClientCode(63, "REG", "REG 2159"))
        assertEquals("Tper", Operators.fromClientCode(18, "REG", "REG 2451"))
        assertEquals("Trenitalia", Operators.fromClientCode(2, "REG", "REG 2018"))
    }

    @Test
    fun cleanNumberRemovesOperator() {
        assertEquals("S50 25592", Operators.cleanNumber("S50 TRENORD 25592"))
        assertEquals("SU S50 25591", Operators.cleanNumber("SBB / SU S50 TRENORD 25591"))
    }

    @Test
    fun railwayRegistryMatchesSwissOperators() {
        assertEquals("sob", Railways.match("SOB-sob")?.id)
        assertEquals("bls", Railways.match("BLS-bls")?.id)
        assertEquals("eav", Railways.match("Eav srl - Divisione Ferrovia")?.id)
    }

    @Test
    fun otherOperatorsAreSplit() {
        assertEquals("tper", Stats.classifyOther("BOLOGNA CENTRALE", "17400"))
        assertEquals("fdg", Stats.classifyOther("LUCERA", "401"))
        assertEquals("eav", Stats.classifyOther("PIEDIMONTE MATESE", "7857"))
        assertEquals("bls", Stats.classifyOther("BERN", "4269"))
        assertEquals("estero", Stats.classifyOther("WIEN HAUPTBAHNHOF", "131"))
        assertEquals("altro", Stats.classifyOther("BORGO VALSUGANA EST", "16918"))
    }

    private val trenordCard = """<div><a class="Link trenord-red-text" href="https://www.google.com/maps/dir/?api=1&amp;destination=45.8247642,8.7639661" target="_blank"><div class="flex-row province-page-item-name mt-0"><div><svg></svg></div><div><h3 class="capitalize" style="display:inline">tabaccheria buzzi</h3><div class="province-page-item-city"><div><p>Stazione più vicina: <span class="capitalize">morosolo casciago</span></p><p>Distanza:  1300 metri</p></div><div class="text-lg"><p class="inline-block"><span class="text-red-600 text-bold-status">Aperto</span> - Chiude alle: 19:30</p></div></div></div></div></a></div>"""

    @Test
    fun trenordResellers() {
        val l = TicketSellers.parseProvince(trenordCard + trenordCard.replace("buzzi", "bar le due isole").replace("45.8247642", "45.7368039"), "varese")
        assertEquals(2, l.size)
        assertEquals("Tabaccheria Buzzi", l[0].name)
        assertEquals("Morosolo Casciago", l[0].nearStation)
        assertEquals(45.8247642, l[0].lat, 1e-7)
        assertEquals("Aperto - Chiude alle: 19:30", l[0].status)
        assertEquals(OsmPlace.Kind.RESELLER, l[0].kind)
    }

    @Test
    fun trenordTicketOfficeHours() {
        val html = """<title>Biglietteria VARESE | Trenord</title><a href="https://www.google.com/maps/dir/?api=1&amp;destination=45.8159,8.8329">x</a>
            <div>Aperto - Chiude alle: 20:00</div><p>Piazzale Trieste, 1, Varese, 21100, Lombardia</p>
            <table><tr><td>lunedì</td><td>6:00 - 20:00</td></tr><tr><td>martedì</td><td>6:00 - 20:00</td></tr><tr><td>mercoledì</td><td>6:00 - 20:00</td></tr>
            <tr><td>giovedì</td><td>6:00 - 20:00</td></tr><tr><td>venerdì</td><td>6:00 - 20:00</td></tr><tr><td>sabato</td><td>6:00 - 20:00</td></tr>
            <tr><td>domenica</td><td>Chiuso</td></tr></table>"""
        val s = TicketSellers.parseOffice(html, "https://biglietterie.trenord.it/it/punti-vendita-va/biglietteria-varese")!!
        assertEquals("Biglietteria Varese", s.name)
        assertEquals("Lun–Sab 6:00–20:00 · Dom chiuso", s.hours)
        assertEquals("Piazzale Trieste, 1, Varese, 21100, Lombardia", s.address)
        assertEquals("varese", s.province)
    }

    @Test
    fun altoAdigeOutlets() {
        val html = """<span class="AccordionCMS__labelText">Bolzano</span>
            <h2>Tabaccheria Gruber</h2>
            <p><strong>Indirizzo:</strong> Via Piave 24/C, 39100 Bolzano </p>
            <p><strong>Orario d’apertura:  </strong><br/> Lunedì – sabato: ore 5:30-19:00 </p>
            <p>CHIUSO: domenica </p><p><strong>Telefono:</strong> +39 0471973654</p>
            <p><strong>Servizi:</strong></p><ul> <li>Biglietti singoli  </li> <li>Biglietto giornaliero urbano</li> </ul><h2> </h2>
            <span class="AccordionCMS__labelText">Chiusa</span>
            <h2>Tabaccheria Pancheri</h2>
            <p><strong>Orario d’apertura: </strong><br/> Lunedì – venerdì: ore 7:00-12:30</p>"""
        val l = TicketSellers.parseAltoAdige(html)
        assertEquals(2, l.size)
        assertEquals("Bolzano", l[0].town)
        assertEquals("Via Piave 24/C, 39100 Bolzano", l[0].address)
        assertTrue(l[0].hours.startsWith("Lunedì – sabato: 5:30-19:00"))
        assertTrue(l[0].hours.contains("CHIUSO: domenica"))
        assertEquals("Biglietti singoli · Biglietto giornaliero urbano", l[0].services)
        assertEquals("Chiusa", l[1].town)
        assertEquals("", l[1].address)
    }
}
