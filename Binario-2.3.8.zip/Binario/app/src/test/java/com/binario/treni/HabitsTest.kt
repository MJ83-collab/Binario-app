package com.binario.treni

import com.binario.treni.data.Habit
import com.binario.treni.data.Habits
import com.binario.treni.data.Station
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class HabitsTest {
    private val rome = TimeZone.getTimeZone("Europe/Rome")

    /** 2026-10-12 è un lunedì. */
    private fun at(day: Int, h: Int, m: Int): Long = Calendar.getInstance(rome).apply {
        clear(); set(2026, Calendar.OCTOBER, day, h, m)
    }.timeInMillis

    private val varese = Station("Varese", "S01205")
    private val milano = Station("Milano Porta Garibaldi", "S01645")
    private fun seed(number: String = "2034", minute: Int = 7 * 60 + 42) =
        Habit(number, "R", "Trenord", "S01205", varese, milano, minute, List(7) { 0 }, 0L)

    @Test
    fun weekdayIsMondayZero() {
        assertEquals(0, Habits.weekday(at(12, 9, 0)))
        assertEquals(6, Habits.weekday(at(18, 9, 0)))
    }

    @Test
    fun countsOncePerDay() {
        var l = Habits.record(emptyList(), seed(), at(12, 7, 30))
        l = Habits.record(l, seed(), at(12, 18, 0))
        assertEquals(1, l.single().total)
        l = Habits.record(l, seed(), at(19, 7, 30))
        assertEquals(2, l.single().days[0])
    }

    @Test
    fun nextNeedsRepetition() {
        var l = Habits.record(emptyList(), seed(), at(12, 7, 30))
        assertNull(Habits.next(l, at(19, 7, 0)))
        l = Habits.record(l, seed(), at(19, 7, 30))
        // Lunedì successivo alle 7:00: il treno delle 7:42 è il prossimo
        assertNotNull(Habits.next(l, at(26, 7, 0)))
        // Troppo tardi (partito da più di 5 minuti) o troppo presto (oltre 3 ore)
        assertNull(Habits.next(l, at(26, 7, 50)))
        assertNull(Habits.next(l, at(26, 4, 0)))
        // Di sabato non lo propone
        assertNull(Habits.next(l, at(24, 7, 0)))
    }

    @Test
    fun weekdaysTogether() {
        var l = Habits.record(emptyList(), seed(), at(12, 7, 0))
        l = Habits.record(l, seed(), at(13, 7, 0))
        l = Habits.record(l, seed(), at(14, 7, 0))
        // Tre feriali diversi: lo propone anche il giovedì
        assertEquals("2034", Habits.next(l, at(15, 7, 0))?.number)
        assertEquals(1, Habits.dueForAlerts(l, at(15, 7, 10)).size)
        assertEquals(0, Habits.dueForAlerts(l, at(15, 6, 0)).size)
    }

    @Test
    fun forgetsOldAndKeepsJson() {
        var l = Habits.record(emptyList(), seed("1111"), at(1, 7, 0))
        l = Habits.record(l, seed("2222"), at(12, 7, 0))
        l = Habits.record(l, seed("3333"), at(1, 7, 0).plus(80L * 86_400_000L))
        assertEquals(listOf("3333"), l.map { it.number })
        val back = Habits.parse(Habits.toText(l))
        assertEquals(l, back)
        assertEquals("Trenord R 2034", seed().title)
    }
}
