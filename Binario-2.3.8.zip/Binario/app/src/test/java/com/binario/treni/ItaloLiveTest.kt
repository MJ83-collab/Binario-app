package com.binario.treni

import com.binario.treni.data.ItaloLive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ItaloLiveTest {
    @Test fun stationCodes() {
        assertEquals("MC_", ItaloLive.codeFor("MILANO CENTRALE"))
        assertEquals("SMN", ItaloLive.codeFor("FIRENZE S.M.N."))
        assertEquals("BC_", ItaloLive.codeFor("BOLOGNA C.LE"))
        assertEquals("AAV", ItaloLive.codeFor("REGGIO EMILIA AV MEDIOPADANA"))
        assertEquals("OUE", ItaloLive.codeFor("TORINO PORTA SUSA"))
        assertEquals("TOP", ItaloLive.codeFor("TORINO P.NUOVA"))
        assertEquals("VSL", ItaloLive.codeFor("VENEZIA S.LUCIA"))
        assertEquals("RRO", ItaloLive.codeFor("RHO FIERA MILANO"))
        assertEquals("RMT", ItaloLive.codeFor("ROMA TERMINI"))
        assertNull(ItaloLive.codeFor("REGGIO EMILIA"))
        assertNull(ItaloLive.codeFor("VARESE"))
        assertNull(ItaloLive.codeFor("MILANO PORTA GARIBALDI"))
    }

    @Test fun italoNumbers() {
        assertTrue(ItaloLive.looksItalo("9920"))
        assertTrue(ItaloLive.looksItalo("ITA 8983"))
        assertFalse(ItaloLive.looksItalo("2070"))
        assertFalse(ItaloLive.looksItalo("25592"))
    }
}
