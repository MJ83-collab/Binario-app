package com.binario.treni

import com.binario.treni.data.Stibm
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StibmTest {
    @Test
    fun officialExamples() {
        // Esempi dalla pagina Tariffe di Trenord
        assertEquals("Mi4–Mi5", Stibm.fare(4, 5, false).label) // Monza → Arcore
        assertEquals("Mi3–Mi6", Stibm.fare(6, 3, false).label) // Gessate → Vimodrone
        assertEquals("Mi1–Mi6", Stibm.fare(3, 6, true).label) // Pero → Gessate passando da Milano
        assertEquals("Mi1–Mi7", Stibm.fare(4, 7, true).label) // Monza → Abbiategrasso
        assertEquals("Mi1–Mi3", Stibm.fare(1, 1, false).label) // dentro Milano
        assertEquals("Mi5–Mi6", Stibm.fare(5, 5, false).label) // Desio → Lissone: minimo 2 zone
        assertEquals(1.70, Stibm.fare(4, 5, false).prices!!.single, 0.001)
        assertEquals(2.20, Stibm.fare(1, 1, false).prices!!.single, 0.001)
        assertEquals(255, Stibm.fare(1, 9, false).prices!!.minutes)
    }

    @Test
    fun namesFromViaggiaTreno() {
        assertEquals(1, Stibm.find("MILANO PORTA GARIBALDI")?.zone)
        assertEquals(3, Stibm.find("SAN DONATO MILANESE")?.zone)
        assertEquals(3, Stibm.find("RHO FIERA MILANO")?.zone)
        assertEquals(1, Stibm.find("MILANO BOVISA POLITECNICO")?.zone)
        assertEquals(6, Stibm.find("CARATE-CALO'")?.zone)
        assertTrue(Stibm.find("SARONNO")!!.interchangeOnly)
        assertNull(Stibm.find("VARESE NORD"))
        assertEquals(99, Stibm.STATIONS.size)
    }

    @Test
    fun throughMilanoGuess() {
        val monza = 45.5845 to 9.2735
        val abbiategrasso = 45.3986 to 8.9180
        val arcore = 45.6268 to 9.3212
        assertTrue(Stibm.likelyThroughMilano(monza, abbiategrasso))
        assertFalse(Stibm.likelyThroughMilano(monza, arcore))
    }
}
