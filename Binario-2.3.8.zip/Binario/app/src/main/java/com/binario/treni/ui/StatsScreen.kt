package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n
import com.binario.treni.data.MonthStats
import com.binario.treni.data.PunctRow
import com.binario.treni.data.Station
import com.binario.treni.data.Stats
import com.binario.treni.data.Segment
import com.binario.treni.data.TrainRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

private fun tr(a: String, b: String) = I18n.tr(a, b)
private fun pct(v: Double) = String.format(Locale.ITALY, "%.1f%%", v)
private fun mins(v: Double) = String.format(Locale.ITALY, "%.1f min", v)
private fun num(v: Int) = String.format(Locale.ITALY, "%,d", v)

fun punctColor(p: Double): Color = when {
    p >= 90 -> OnTime
    p >= 80 -> Color(com.binario.treni.data.Crowd.Level.MEDIUM.color)
    else -> LateRed
}

/** Sezione "Puntualità": statistiche mensili da TrovaTreno.it per operatore, stazione e treno. */
@Composable
fun StatsScreen(vm: MainViewModel, onBack: () -> Unit, onTrain: (TrainRef) -> Unit, onStation: (Station) -> Unit) {
    val ctx = LocalContext.current
    var months by remember { mutableStateOf<List<String>?>(null) }
    var month by remember { mutableStateOf<String?>(null) }
    var data by remember { mutableStateOf<MonthStats?>(null) }
    var prev by remember { mutableStateOf<MonthStats?>(null) }
    var failed by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var worstFirst by remember { mutableStateOf(true) }
    var network by remember { mutableStateOf("") } // "", "passante", "fn"
    var fn by remember { mutableStateOf<com.binario.treni.data.FnStats.Summary?>(null) }
    LaunchedEffect(Unit) { fn = withContext(Dispatchers.IO) { com.binario.treni.data.FnStats.summary(ctx) } }

    LaunchedEffect(Unit) {
        val l = withContext(Dispatchers.IO) { Stats.availableMonths(ctx) }
        months = l
        if (l.isEmpty()) failed = true else month = l.first()
    }
    LaunchedEffect(month) {
        val m = month ?: return@LaunchedEffect
        data = null; failed = false
        try {
            data = withContext(Dispatchers.IO) { Stats.load(ctx, m) }
            val idx = months.orEmpty().indexOf(m)
            prev = months.orEmpty().getOrNull(idx + 1)?.let { pm -> withContext(Dispatchers.IO) { runCatching { Stats.load(ctx, pm) }.getOrNull() } }
        } catch (e: Exception) {
            failed = true
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tr("Puntualità", "Punctuality"), onBack)
        GreenTabs(listOf(tr("Riepilogo", "Overview"), tr("Stazioni", "Stations"), tr("Treni", "Trains")), tab) { tab = it; network = "" }
        months?.let { ms ->
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp)) {
                ms.forEach { m ->
                    FilterChip(m == month, { month = m }, label = { Text(Stats.monthLabel(m)) }, modifier = Modifier.padding(end = 6.dp))
                }
            }
        }
        val d = data
        when {
            failed -> MessageBox(tr("Statistiche non disponibili al momento.", "Statistics not available right now."))
            d == null -> LoadingBox()
            tab == 0 -> Overview(vm, d, prev, onTrain, onStation)
            else -> {
                OutlinedTextField(
                    query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    placeholder = { Text(if (tab == 1) tr("Cerca stazione", "Search station") else tr("Numero treno o destinazione", "Train number or destination")) },
                    leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
                )
                Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(worstFirst, { worstFirst = true }, label = { Text(tr("Meno puntuali", "Least punctual")) }, modifier = Modifier.padding(end = 6.dp))
                    FilterChip(!worstFirst, { worstFirst = false }, label = { Text(tr("Più puntuali", "Most punctual")) })
                }
                if (tab == 2) {
                    Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(network == "fn", { network = if (network == "fn") "" else "fn" }, label = { Text(tr("Rete FerrovieNord", "FerrovieNord network")) })
                    }
                }
                if (tab == 1) {
                    Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(network == "passante", { network = if (network == "passante") "" else "passante" },
                            label = { Text(tr("Passante di Milano", "Milan Passante")) }, modifier = Modifier.padding(end = 6.dp))
                        FilterChip(network == "fn", { network = if (network == "fn") "" else "fn" }, label = { Text(tr("Rete FerrovieNord", "FerrovieNord network")) })
                    }
                }
                val fnRows = fn?.let { f -> f.stations.map { it.copy(extra = tr("raccolti dall'app · ", "collected by the app · ") + f.days + tr(" giorni", " days")) } }.orEmpty()
                val src = if (tab == 1) d.stations + fnRows else d.trains + fn?.trains.orEmpty()
                val q = query.trim()
                val qSlug = q.lowercase().replace(' ', '-')
                val list = src.filter { r ->
                    val isFn = r.key.startsWith(com.binario.treni.data.FnStats.PREFIX)
                    val fnTrain = tab == 2 && r.extra.contains("Trenord · ") && r.extra.contains("FN")
                    (r.observed >= 20 || isFn && r.observed >= 5 || fnTrain && r.observed + r.cancelled >= 3) &&
                        (q.isBlank() || r.name.contains(q, true) || r.key.contains(q, true) || r.extra.contains(q, true) || r.extra.contains(qSlug, true)) &&
                        when (network) {
                            "passante" -> r.extra in Stats.PASSANTE_SLUGS || r.key == com.binario.treni.data.FnStats.PREFIX + "S01642"
                            "fn" -> isFn || fnTrain
                            else -> true
                        }
                }
                    .sortedWith(if (worstFirst) compareBy<PunctRow>({ it.percent }, { -it.avgDelay }) else compareByDescending<PunctRow> { it.percent }.thenBy { it.avgDelay })
                    .take(100)
                LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
                    if (list.isEmpty()) item {
                        MessageBox(
                            if (tab == 1 && (q.isNotBlank() || network == "fn")) {
                                tr("Nessun dato per questa stazione. TrovaTreno non pubblica la rete FerrovieNord (Cadorna, Saronno, Varese Nord, Como Lago, " +
                                    "Novara Nord, Malpensa…): per quelle stazioni l'app raccoglie da sola gli arrivi da ViaggiaTreno e i dati compaiono qui dopo qualche ora.",
                                    "No data for this station. TrovaTreno does not publish the FerrovieNord network: for those stations the app collects " +
                                        "arrivals from ViaggiaTreno by itself and data appears here after a few hours.")
                            } else tr("Nessun risultato", "No results"),
                        )
                    }
                    items(list, key = { it.key + it.extra }) { r ->
                        PunctCard(r, onClick = {
                            if (tab == 1) onStation(Station(r.name, r.key.substringAfter('_')))
                            else onTrain(TrainRef(r.key, label = r.name))
                        })
                    }
                    item { SourceNote() }
                }
            }
        }
    }
}

@Composable
private fun Overview(vm: MainViewModel, d: MonthStats, prev: MonthStats?, onTrain: (TrainRef) -> Unit, onStation: (Station) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
        item {
            WhiteCard {
                Column(Modifier.padding(16.dp)) {
                    Text(Stats.monthLabel(d.month), color = Muted)
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(pct(d.percent), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = punctColor(d.percent))
                        Spacer(Modifier.width(8.dp))
                        Text(tr("in orario (entro 5 min)", "on time (within 5 min)"), modifier = Modifier.padding(bottom = 6.dp))
                    }
                    prev?.let { p ->
                        val diff = d.percent - p.percent
                        Text(
                            (if (diff >= 0) "▲ +" else "▼ ") + String.format(Locale.ITALY, "%.1f", diff) + tr(" punti rispetto a ", " points vs ") + Stats.monthLabel(p.month),
                            color = if (diff >= 0) Green else LateRed, fontSize = 14.sp,
                        )
                    }
                    Row(Modifier.padding(top = 10.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(num(d.totalObserved), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(tr("arrivi osservati", "arrivals observed"), color = Muted, fontSize = 12.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(num(d.totalCancelled), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = LateRed)
                            Text(tr("corse soppresse", "cancelled runs"), color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        // Confronto tra servizi dello stesso tipo (regionali con regionali, alta velocità con alta velocità)
        val segs = d.bySegment()
        Segment.entries.forEach { seg ->
            val rows = segs[seg].orEmpty()
            if (rows.isEmpty()) return@forEach
            item {
                WhiteCard {
                    CardTitle(seg.label)
                    Column(Modifier.padding(16.dp)) {
                        rows.forEach { o ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(o.name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                Text(pct(o.percent), color = punctColor(o.percent), fontWeight = FontWeight.Bold)
                            }
                            Bar(o.percent)
                            Text(tr("Ritardo medio ", "Average delay ") + mins(o.avgDelay) + " · " + num(o.observed) + tr(" arrivi", " arrivals") +
                                " · " + num(o.cancelled) + tr(" soppressi", " cancelled") + " · " + o.extra + tr(" treni", " trains"),
                                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
                        }
                    }
                }
            }
        }
        item {
            Text(tr("Ogni riquadro confronta solo servizi dello stesso tipo. Calcolato sui treni con almeno 30 arrivi osservati nel mese; " +
                "le corse senza categoria non sono incluse. Le imprese regionali diverse da Trenord e Trenitalia (Tper, EAV, Ferrovie del Gargano, " +
                "TUA, BLS…) sono riconosciute da percorso e numero del treno; sono incluse solo quelle con treni sulla rete RFI seguiti da ViaggiaTreno.",
                "Each box compares only services of the same kind. Based on trains with at least 30 observed arrivals in the month; " +
                    "runs without a category are not included. Regional operators other than Trenord and Trenitalia (Tper, EAV, Ferrovie del Gargano, " +
                    "TUA, BLS…) are identified by route and train number; only those running on the RFI network tracked by ViaggiaTreno are included."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        // Rete FerrovieNord: TrovaTreno non la pubblica, la raccoglie l'app
        item { FnCard() }
        // Svizzera: dati aperti FFS raccolti giorno per giorno (soglia FFS: meno di 3 minuti)
        item { SwissCard() }
        // I tuoi treni e stazioni preferiti
        val favTrains = vm.store.favTrains().flatMap { f -> d.train(f.number) }
        val linesTrains = listOfNotNull(
            com.binario.treni.data.GreenCalc.profile(vm.getApplication<android.app.Application>())?.trainOut,
            com.binario.treni.data.GreenCalc.profile(vm.getApplication<android.app.Application>())?.trainBack,
        ).filter { it.isNotBlank() }.flatMap { d.train(it) }
        val mine = (favTrains + linesTrains).distinctBy { it.key + it.extra }
        if (mine.isNotEmpty()) {
            item { SectionHeader(tr("I tuoi treni", "Your trains")) }
            items(mine) { r -> PunctCard(r) { onTrain(TrainRef(r.key, label = r.name)) } }
        }
        val myStations = vm.store.favStations().mapNotNull { s -> d.station(s.id, s.name)?.let { it to s } }
        if (myStations.isNotEmpty()) {
            item { SectionHeader(tr("Le tue stazioni", "Your stations")) }
            items(myStations) { (r, s) -> PunctCard(r) { onStation(s) } }
        }
        item { SourceNote() }
    }
}

@Composable
private fun Bar0(p: Double) = Bar(p)

/** Puntualità FFS (Svizzera): media degli ultimi giorni raccolti dai dati aperti Ist-Daten SBB. */
@Composable
private fun SwissCard() {
    val ctx = LocalContext.current
    var sum by remember { mutableStateOf(com.binario.treni.data.SwissStats.summary(ctx)) }
    var loading by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        loading = true
        withContext(Dispatchers.IO) { runCatching { com.binario.treni.data.SwissStats.collect(ctx.applicationContext) } }
        sum = com.binario.treni.data.SwissStats.summary(ctx)
        loading = false
    }
    WhiteCard {
        CardTitle(tr("Svizzera · FFS", "Switzerland · SBB"))
        Column(Modifier.padding(16.dp)) {
            val s = sum
            when {
                s == null && loading -> LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                s == null -> Text(tr("Dati FFS non raggiungibili al momento.", "SBB data not reachable right now."), color = Muted)
                else -> {
                    listOf(Segment.REGIONAL, Segment.INTERCITY).mapNotNull { s.rows[it] }.forEach { o ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(o.name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            Text(pct(o.percent), color = punctColor(o.percent), fontWeight = FontWeight.Bold)
                        }
                        Bar0(o.percent)
                        Text(num(o.observed) + tr(" arrivi alle fermate", " stop arrivals") + " · " + num(o.cancelled) + tr(" fermate soppresse", " cancelled stops"),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
                    }
                    Text(
                        (if (s.days == 1) tr("Dati del ", "Data for ") + s.last else tr("Media di ", "Average of ") + s.days + tr(" giorni (", " days (") + s.first + " → " + s.last + ")") + ". " +
                            tr("Per le FFS è puntuale un treno con meno di 3 minuti di ritardo (in Italia la soglia è 5 minuti), quindi il confronto con l'Italia è prudente. " +
                                "Le FFS pubblicano solo il giorno precedente: l'app ne raccoglie uno al giorno.",
                                "SBB counts a train as punctual under 3 minutes late (5 in Italy), so the comparison with Italy is conservative. " +
                                    "SBB publishes only the previous day: the app collects one per day."),
                        color = Muted, fontSize = 12.sp,
                    )
                    SourceLink(com.binario.treni.data.SwissStats.SOURCE, com.binario.treni.data.SwissStats.SOURCE_URL, Modifier.padding(top = 6.dp))
                    Text(tr("Perché mancano BLS, SOB, Ferrovia Retica e le altre imprese svizzere", "Why BLS, SOB, Rhaetian Railway and the other Swiss companies are missing"),
                        fontWeight = FontWeight.Medium, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                    Text(
                        tr("I loro orari effettivi esistono come dati aperti (opentransportdata.swiss, \"Ist-Daten\"), ma solo come un unico file al giorno " +
                            "con tutti i mezzi pubblici svizzeri: centinaia di MB, da scaricare ogni giorno. Sul telefono consumerebbe troppi dati e batteria, " +
                            "e non esiste un servizio che restituisca solo i conteggi per impresa come fanno le FFS. Si potranno aggiungere in futuro se " +
                            "nascerà un servizio di questo tipo, oppure con un piccolo server che scarica il file e prepara i totali per l'app.",
                            "Their actual times exist as open data (opentransportdata.swiss, \"Ist-Daten\"), but only as a single daily file with all Swiss " +
                                "public transport: hundreds of MB, to be downloaded every day. On a phone that would use too much data and battery, and there is " +
                                "no service returning per-company totals as SBB does. They can be added in future if such a service appears, or with a small " +
                                "server that downloads the file and prepares the totals for the app."),
                        color = Muted, fontSize = 12.sp,
                    )
                }
            }
        }
    }
}

/** Puntualità della rete FerrovieNord, raccolta dall'app da ViaggiaTreno (TrovaTreno non la pubblica). */
@Composable
private fun FnCard() {
    val ctx = LocalContext.current
    var sum by remember { mutableStateOf(com.binario.treni.data.FnStats.summary(ctx)) }
    var on by remember { mutableStateOf(com.binario.treni.data.FnStats.enabled(ctx)) }
    var loading by remember { mutableStateOf(false) }
    LaunchedEffect(on) {
        if (!on) return@LaunchedEffect
        loading = true
        withContext(Dispatchers.IO) { runCatching { com.binario.treni.data.FnStats.collect(ctx.applicationContext, force = true) } }
        sum = com.binario.treni.data.FnStats.summary(ctx)
        loading = false
    }
    WhiteCard {
        CardTitle(tr("Rete FerrovieNord · Trenord", "FerrovieNord network · Trenord"))
        Column(Modifier.padding(16.dp)) {
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(bottom = 8.dp), color = Green)
            val s = sum
            if (s == null || s.total.observed == 0) {
                Text(tr("Raccolta appena iniziata: i primi dati compaiono dopo qualche ora, quelli affidabili dopo un paio di settimane.",
                    "Collection just started: first data after a few hours, reliable figures after a couple of weeks."), color = Muted, fontSize = 13.sp)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(s.total.name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    Text(pct(s.total.percent), color = punctColor(s.total.percent), fontWeight = FontWeight.Bold)
                }
                Bar0(s.total.percent)
                s.lines.forEach { o ->
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(o.name, Modifier.weight(1f), fontSize = 14.sp)
                        Text(pct(o.percent), color = punctColor(o.percent), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Bar0(o.percent)
                    Text(tr("Ritardo medio ", "Avg delay ") + mins(o.avgDelay) + " · " + num(o.observed) + tr(" arrivi", " arrivals") +
                        (if (o.cancelled > 0) " · " + num(o.cancelled) + tr(" soppressi", " cancelled") else ""), color = Muted, fontSize = 12.sp)
                }
                Text(
                    (if (s.days == 1) tr("Dati di oggi", "Today's data") else tr("Ultimi ", "Last ") + s.days + tr(" giorni raccolti (", " days collected (") + s.first + " → " + s.last + ")") +
                        ". " + tr("Le stazioni sono nella scheda Stazioni (filtro Rete FerrovieNord).", "Stations are in the Stations tab (FerrovieNord filter)."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
                )
            }
            Text(
                tr("TrovaTreno non pubblica la rete FerrovieNord (Milano Cadorna, Saronno, Varese Nord, Como Lago, Novara Nord, Malpensa, Asso, Brescia–Iseo–Edolo). " +
                    "L'app legge da sola gli arrivi da ViaggiaTreno, che segue questa rete in tempo reale: ogni 80 minuti con il Wi-Fi, ogni 3 ore con i dati mobili " +
                    "(circa 0,3 MB). Puntuale = entro 5 minuti. I numeri dipendono da quando il telefono è acceso e collegato.",
                    "TrovaTreno does not publish the FerrovieNord network. The app reads arrivals from ViaggiaTreno by itself: every 80 minutes on Wi-Fi, " +
                        "every 3 hours on mobile data (about 0.3 MB). On time = within 5 minutes. Figures depend on when the phone is on and connected."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Raccolta attiva", "Collection on"), Modifier.weight(1f), fontSize = 14.sp)
                Switch(on, { on = it; com.binario.treni.data.FnStats.setEnabled(ctx, it) }, colors = SwitchDefaults.colors(checkedTrackColor = Green))
            }
        }
    }
}

@Composable
private fun Bar(p: Double) {
    Box(Modifier.fillMaxWidth().padding(vertical = 4.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0x1F000000))) {
        Box(Modifier.fillMaxWidth((p / 100.0).toFloat().coerceIn(0f, 1f)).fillMaxHeight().background(punctColor(p)))
    }
}

@Composable
fun PunctCard(r: PunctRow, onClick: () -> Unit) {
    WhiteCard(onClick = onClick) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    if (r.extra.contains("→") || r.key.startsWith(com.binario.treni.data.FnStats.PREFIX)) Text(r.extra, color = Muted, fontSize = 13.sp)
                }
                Text(pct(r.percent), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = punctColor(r.percent))
            }
            Bar(r.percent)
            Text(
                tr("Ritardo medio ", "Avg delay ") + mins(r.avgDelay) + " · " + num(r.observed) + tr(" corse", " runs") +
                    (if (r.cancelled > 0) " · " + num(r.cancelled) + tr(" soppresse", " cancelled") else "") +
                    (if (r.severe > 0) " · " + num(r.severe) + tr(" ritardi gravi", " severe delays") else ""),
                color = Muted, fontSize = 12.sp,
            )
        }
    }
}

/** Puntualità del mese più recente per un treno: usata nella scheda del treno. */
@Composable
fun TrainPunctuality(number: String, fnNetwork: Boolean = false) {
    val ctx = LocalContext.current
    var row by remember(number) { mutableStateOf<Pair<String, PunctRow>?>(null) }
    LaunchedEffect(number) {
        row = withContext(Dispatchers.IO) {
            // Treni della rete FerrovieNord: TrovaTreno non li ha (lo stesso numero può essere un altro treno), usiamo i dati raccolti dall'app
            if (fnNetwork) {
                com.binario.treni.data.FnStats.summary(ctx)?.trains?.firstOrNull { it.key == com.binario.treni.data.Habits.digits(number) && it.observed + it.cancelled >= 3 }
                    ?.let { return@withContext tr("ultimi giorni (raccolti dall'app)", "recent days (collected by the app)") to it }
                return@withContext null
            }
            try {
                val m = Stats.availableMonths(ctx).firstOrNull() ?: return@withContext null
                Stats.load(ctx, m).train(number).maxByOrNull { it.observed }?.let { m to it }
            } catch (e: Exception) {
                null
            }
        }
    }
    row?.let { (m, r) ->
        WhiteCard {
            CardTitle(tr("Puntualità", "Punctuality") + " · " + (if (fnNetwork) m else Stats.monthLabel(m)))
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(pct(r.percent), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = punctColor(r.percent))
                    Spacer(Modifier.width(10.dp))
                    Text(tr("in orario (entro 5 min)", "on time (within 5 min)"))
                }
                Bar(r.percent)
                Text(tr("Ritardo medio ", "Avg delay ") + mins(r.avgDelay) + " · " + num(r.observed) + tr(" corse osservate", " runs observed") +
                    (if (r.cancelled > 0) " · " + num(r.cancelled) + tr(" soppresse", " cancelled") else ""), color = Muted, fontSize = 12.sp)
                Text(if (fnNetwork) com.binario.treni.data.FnStats.SOURCE else Stats.SOURCE, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

/** Riga di puntualità per una stazione, mostrata nel tabellone. */
@Composable
fun StationPunctualityLine(station: Station) {
    val ctx = LocalContext.current
    var row by remember(station.id) { mutableStateOf<PunctRow?>(null) }
    LaunchedEffect(station.id) {
        row = withContext(Dispatchers.IO) {
            (try {
                Stats.availableMonths(ctx).firstOrNull()?.let { m -> Stats.load(ctx, m).station(station.id, station.name) }
            } catch (e: Exception) {
                null
            }) ?: com.binario.treni.data.FnStats.summary(ctx)?.stations?.firstOrNull { it.key == com.binario.treni.data.FnStats.PREFIX + station.id && it.observed >= 20 }
        }
    }
    row?.let { r ->
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Insights, null, tint = punctColor(r.percent), modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text((if (r.key.startsWith(com.binario.treni.data.FnStats.PREFIX)) tr("Puntualità ultimi giorni (rete FN): ", "Recent punctuality (FN network): ")
                else tr("Puntualità mese scorso: ", "Last month punctuality: ")) + pct(r.percent) + " · " + tr("ritardo medio ", "avg delay ") + mins(r.avgDelay),
                fontSize = 13.sp)
        }
    }
}

@Composable
private fun SourceNote() {
    val ctx = LocalContext.current
    TextButton({ openUrl(ctx, "https://www.trovatreno.it/puntualita-archivio") }, Modifier.padding(horizontal = 8.dp)) {
        Text(tr("Fonte: ", "Source: ") + Stats.SOURCE + tr(". Puntuale = arrivo entro 5 minuti.", ". On time = arrival within 5 minutes."),
            color = Green, fontSize = 12.sp)
    }
}
