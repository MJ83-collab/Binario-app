package com.binario.treni.ui

import android.Manifest
import android.location.Location
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.I18n
import com.binario.treni.data.Station
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.TrainStop
import com.binario.treni.data.delayText
import com.binario.treni.service.TrackingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun tr(a: String, b: String) = I18n.tr(a, b)

/** Un treno proposto: dal numero (TrainRef) o da un tabellone (con la stazione dove salgo già nota). */
private data class Choice(val ref: TrainRef, val title: String, val sub: String, val boarding: Station? = null)

private data class Bubble(val mine: Boolean, val text: String)

private enum class Step { CONSENT, MODE, NUMBER, NEAR, STATION, TIME, CHOOSE, BOARD, ALIGHT, FOLLOWING }

/**
 * "Il mio Capotreno": come il servizio WhatsApp di Trenord ma dentro l'app e per tutti i treni
 * (Trenord, Trenitalia, FerrovieNord, Italo, TILO e FFS…). Autorizza → cerca il treno (numero, posizione o
 * stazione e orario) → ricevi gli aggiornamenti prima, durante e dopo il viaggio, senza registrazione.
 */
@Composable
fun CapotrenoScreen(vm: MainViewModel, onBack: () -> Unit, onTrain: (TrainRef) -> Unit, onConditions: () -> Unit) {
    val ctx = LocalContext.current
    val store = vm.store
    val scope = rememberCoroutineScope()
    val chat = remember { mutableStateListOf<Bubble>() }
    var step by remember { mutableStateOf(Step.CONSENT) }
    var busy by remember { mutableStateOf(false) }
    var number by remember { mutableStateOf("") }
    var choices by remember { mutableStateOf<List<Choice>>(emptyList()) }
    var near by remember { mutableStateOf<List<Pair<Station, Float>>>(emptyList()) }
    var station by remember { mutableStateOf<Station?>(null) }
    var picking by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<TrainStatus?>(null) }
    var nearTick by remember { mutableIntStateOf(0) }
    var boarding by remember { mutableStateOf<TrainStop?>(null) }
    var followed by remember { mutableStateOf(store.tracked()) }
    var live by remember { mutableStateOf<TrainStatus?>(null) }
    val list = rememberLazyListState()

    fun bot(text: String) { chat += Bubble(false, text) }
    fun me(text: String) { chat += Bubble(true, text) }

    fun askMode() {
        step = Step.MODE
        bot(tr("Come cerco il tuo treno? Scrivi il numero, oppure trovo la stazione più vicina a te, oppure scegli stazione e orario.",
            "How shall I find your train? Type its number, or I find the station nearest to you, or pick a station and time."))
    }

    LaunchedEffect(Unit) {
        val t = store.tracked()
        bot(tr("Ciao, sono il tuo Capotreno! 🚆 Ti tengo aggiornato sul tuo treno prima, durante e dopo il viaggio: binario, ritardi, " +
            "cambi di binario, soppressioni, prossime fermate e arrivo. Funziona con tutti i treni: Trenord, Trenitalia, FerrovieNord, Italo, TILO e FFS.",
            "Hi, I'm your Conductor! 🚆 I keep you posted about your train before, during and after the trip: platform, delays, " +
                "platform changes, cancellations, next stops and arrival. It works with all trains: Trenord, Trenitalia, FerrovieNord, Italo, TILO and SBB."))
        when {
            t != null -> {
                step = Step.FOLLOWING
                bot(tr("Stai già seguendo ${t.label}. Ecco come va:", "You are already following ${t.label}. Here is how it's going:"))
            }
            store.capotrenoOk -> askMode()
            else -> bot(tr("Non serve registrarsi e i dati restano sul telefono. Per mandarti gli avvisi mi serve il permesso per le notifiche: tocca Autorizza.",
                "No sign-up needed and your data stays on the phone. To send you alerts I need permission for notifications: tap Allow."))
        }
    }
    LaunchedEffect(chat.size, step, choices.size) { if (chat.isNotEmpty()) list.animateScrollToItem(list.layoutInfo.totalItemsCount.coerceAtLeast(1) - 1) }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) bot(tr("Senza notifiche ti posso aggiornare solo qui nell'app. Puoi attivarle quando vuoi dalle impostazioni del telefono.",
            "Without notifications I can only update you here in the app. You can turn them on any time in the phone settings."))
    }

    // ---- Ricerca ----
    fun showChoices(found: List<Choice>, empty: String) {
        choices = found
        if (found.isEmpty()) { bot(empty); return }
        step = Step.CHOOSE
        bot(if (found.size == 1) tr("Ho trovato questo treno: è il tuo?", "I found this train: is it yours?")
            else tr("Ho trovato ${found.size} treni: quale è il tuo?", "I found ${found.size} trains: which one is yours?"))
    }

    fun searchNumber() {
        val n = number.trim()
        if (n.isBlank() || busy) return
        me(tr("Treno $n", "Train $n"))
        busy = true
        scope.launch {
            val refs = withContext(Dispatchers.IO) { runCatching { Api.trainLookup(n) }.getOrNull() }
            busy = false
            if (refs == null) { bot(tr("Non riesco a collegarmi. Controlla la connessione e riprova.", "I can't connect. Check your connection and try again.")); return@launch }
            showChoices(refs.map { Choice(it, it.label.ifBlank { it.number }, "") },
                tr("Non trovo il treno $n oggi. Controlla il numero (lo trovi sul biglietto o sul tabellone) o cercalo per stazione.",
                    "I can't find train $n today. Check the number (it's on your ticket or the board) or search by station."))
        }
    }

    fun loadBoard(st: Station, time: Long) {
        busy = true
        scope.launch {
            val items = withContext(Dispatchers.IO) { runCatching { Api.departures(st, time) }.getOrNull() }
            busy = false
            if (items == null) { bot(tr("Il tabellone di ${st.name} non risponde. Riprova tra poco.", "The ${st.name} board isn't responding. Try again shortly.")); return@launch }
            val from = time - 10 * 60_000L
            showChoices(
                items.filter { it.time + it.delay * 60_000L >= from }.take(15).map { b ->
                    Choice(b.ref, b.title + " → " + b.otherEnd,
                        Fmt.time(b.time) + (if (b.delay > 0) " +${b.delay}'" else "") + (if (b.platformText.isNotBlank()) " · " + tr("bin. ", "plat. ") + b.platformText else "") +
                            (if (b.operator.isNotBlank()) " · " + b.operator else ""), st)
                },
                tr("Non vedo partenze da ${st.name} in quell'orario.", "I see no departures from ${st.name} at that time."),
            )
        }
    }

    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) { near = emptyList(); nearTick++ }
        else { bot(tr("Senza posizione non trovo la stazione vicina: scegli tu la stazione.", "Without location I can't find the nearby station: pick the station yourself.")); step = Step.STATION }
    }
    LaunchedEffect(nearTick) {
        if (nearTick == 0 || step != Step.NEAR) return@LaunchedEffect
        if (!hasLocation(ctx)) { locPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)); return@LaunchedEffect }
        busy = true
        val l = currentLocation(ctx)
        if (l == null) {
            busy = false
            bot(tr("Non trovo la tua posizione. Attiva la localizzazione o scegli la stazione.", "I can't find your location. Turn on location or pick the station."))
            step = Step.STATION; return@LaunchedEffect
        }
        val n = withContext(Dispatchers.IO) {
            runCatching {
                Api.allStations(ctx).map { g ->
                    val d = FloatArray(1)
                    Location.distanceBetween(l.latitude, l.longitude, g.lat, g.lon, d)
                    g.station to d[0]
                }.sortedBy { it.second }.take(4)
            }.getOrDefault(emptyList())
        }
        busy = false
        near = n
        val first = n.firstOrNull()
        if (first == null) { bot(tr("Elenco stazioni non disponibile, riprova.", "Station list unavailable, try again.")); return@LaunchedEffect }
        bot(tr("La stazione più vicina è ${first.first.name} (${dist(first.second)}). Ecco i prossimi treni in partenza:",
            "The nearest station is ${first.first.name} (${dist(first.second)}). Here are the next departures:"))
        loadBoard(first.first, System.currentTimeMillis())
    }

    // ---- Scelta del treno e delle fermate ----
    fun pick(c: Choice) {
        me(c.title)
        busy = true
        scope.launch {
            val st = withContext(Dispatchers.IO) { runCatching { Api.status(c.ref) }.getOrNull() }
            busy = false
            if (st == null) { bot(tr("Non riesco a leggere i dati di questo treno ora. Riprova tra poco.", "I can't read this train's data right now. Try again shortly.")); return@launch }
            status = st
            choices = emptyList()
            bot(st.title + " " + st.origin + " → " + st.destination + ". " + st.stateText() + ".")
            val b = c.boarding?.let { s -> st.stops.firstOrNull { it.id == s.id || it.name.equals(s.name, true) } }
            if (b != null) {
                boarding = b
                step = Step.ALIGHT
                bot(tr("Sali a ${b.name}. Dove scendi? Ti avviso prima della fermata.", "You board at ${b.name}. Where do you get off? I'll warn you before the stop."))
            } else {
                step = Step.BOARD
                bot(tr("Dove sali?", "Where do you board?"))
            }
        }
    }

    fun start(alight: TrainStop?) {
        val st = status ?: return
        val b = boarding
        if (Build.VERSION.SDK_INT >= 33 && !com.binario.treni.service.Notif.canPost(ctx)) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        TrackingService.start(ctx, st.ref, b?.station)
        if (alight != null) TrackingService.startWake(ctx, st.ref, alight.station)
        followed = st.ref
        live = st
        step = Step.FOLLOWING
        val sb = StringBuilder(tr("Perfetto, seguo il ${st.title} per te. ", "Great, I'm following ${st.title} for you. "))
        sb.append(tr("Ti avviso quando viene indicato o cambia il binario, se il ritardo aumenta, se il treno è soppresso",
            "I'll alert you when the platform is announced or changes, if the delay grows, if the train is cancelled"))
        if (alight != null) sb.append(tr(", poco prima di ${alight.name} con la sveglia", ", and shortly before ${alight.name} with the alarm"))
        sb.append(tr(", e all'arrivo ti mando il riepilogo. Trovi tutto anche nella notifica fissa.",
            ", and on arrival I'll send you a summary. Everything is in the ongoing notification too."))
        bot(sb.toString())
    }

    // Aggiornamento dal vivo mentre si segue un treno
    LaunchedEffect(followed, step) {
        val ref = followed ?: return@LaunchedEffect
        if (step != Step.FOLLOWING) return@LaunchedEffect
        while (true) {
            live = withContext(Dispatchers.IO) { runCatching { Api.status(ref) }.getOrNull() } ?: live
            if (store.tracked() == null && followed != null) {
                followed = null
                bot(tr("Viaggio concluso: non sto più seguendo il treno. Vuoi seguirne un altro?", "Trip completed: I'm no longer following the train. Want to follow another one?"))
                askMode()
                break
            }
            delay(60_000L)
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tr("Il mio Capotreno", "My Conductor"), onBack)
        LazyColumn(Modifier.weight(1f), state = list, contentPadding = PaddingValues(10.dp)) {
            items(chat) { m -> ChatBubble(m) }
            if (step == Step.FOLLOWING) item {
                val l = live
                val ref = followed
                if (ref != null) LiveCard(l, ref, store.boardingStation(), store.wakeTarget(), onOpen = { onTrain(ref) }) {
                    TrackingService.stop(ctx)
                    followed = null
                    me(tr("Smetti di seguire", "Stop following"))
                    bot(tr("Ok, non ti mando più aggiornamenti su questo treno.", "OK, no more updates on this train."))
                    askMode()
                }
            }
            if (step == Step.CHOOSE) items(choices) { c ->
                WhiteCard(onClick = { if (!busy) pick(c) }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(c.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        if (c.sub.isNotBlank()) Text(c.sub, color = Muted, fontSize = 13.sp)
                    }
                }
            }
            if (step == Step.BOARD || step == Step.ALIGHT) item {
                val st = status
                if (st != null) {
                    val bIdx = boarding?.let { b -> st.stops.indexOfFirst { it.id == b.id } } ?: -1
                    val stops = if (step == Step.BOARD) st.stops.dropLast(1).filter { !it.passed } else st.stops.drop(bIdx + 1)
                    Column {
                        stops.forEach { s ->
                            val t = if (step == Step.BOARD) (if (s.schedDep > 0) s.schedDep else s.schedArr) else (if (s.schedArr > 0) s.schedArr else s.schedDep)
                            OutlinedButton(
                                {
                                    me(s.name)
                                    if (step == Step.BOARD) {
                                        boarding = s; step = Step.ALIGHT
                                        bot(tr("Dove scendi? Ti avviso prima della fermata.", "Where do you get off? I'll warn you before the stop."))
                                    } else start(s)
                                },
                                Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            ) {
                                Text(s.name, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                                Text(Fmt.time(t), color = Muted)
                            }
                        }
                        if (step == Step.ALIGHT) TextButton({ me(tr("Fino al capolinea", "To the terminus")); start(null) }) {
                            Text(tr("Non serve la sveglia: seguo fino al capolinea", "No alarm needed: follow to the terminus"), color = Green)
                        }
                    }
                }
            }
            if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(8.dp), color = Green) }
        }

        // ---- Barra delle azioni (come i pulsanti rapidi della chat) ----
        Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(8.dp)) {
            when (step) {
                Step.CONSENT -> Button(
                    {
                        store.capotrenoOk = true
                        store.changeAlerts = true
                        me(tr("Autorizza", "Allow"))
                        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                        askMode()
                    },
                    Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green),
                ) { Text(tr("Autorizza", "Allow")) }
                Step.NUMBER -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { NumberField(number, { number = it }) { searchNumber() } }
                    Button({ searchNumber() }, Modifier.padding(start = 6.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tr("Cerca", "Search")) }
                }
                Step.TIME -> Row(Modifier.horizontalScroll(rememberScrollState())) {
                    val st = station
                    listOf(0 to tr("Adesso", "Now"), 30 to "+30 min", 60 to tr("+1 ora", "+1 hour"), 120 to tr("+2 ore", "+2 hours"), 180 to tr("+3 ore", "+3 hours")).forEach { (m, label) ->
                        AssistChip({
                            if (st != null) { me(label); loadBoard(st, System.currentTimeMillis() + m * 60_000L) }
                        }, label = { Text(label) }, modifier = Modifier.padding(end = 6.dp))
                    }
                    AssistChip({
                        val c = java.util.Calendar.getInstance()
                        android.app.TimePickerDialog(ctx, { _, h, min ->
                            val t = java.util.Calendar.getInstance().apply {
                                set(java.util.Calendar.HOUR_OF_DAY, h); set(java.util.Calendar.MINUTE, min); set(java.util.Calendar.SECOND, 0)
                                if (timeInMillis < System.currentTimeMillis() - 30 * 60_000L) add(java.util.Calendar.DAY_OF_YEAR, 1)
                            }.timeInMillis
                            if (st != null) { me(Fmt.time(t)); loadBoard(st, t) }
                        }, c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), true).show()
                    }, label = { Text(tr("Scegli l'ora", "Pick time")) })
                }
                else -> {}
            }
            if (step == Step.NEAR && near.size > 1) Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 4.dp)) {
                near.drop(1).forEach { (s, d) ->
                    AssistChip({ me(s.name); loadBoard(s, System.currentTimeMillis()) }, label = { Text(s.name + " · " + dist(d), fontSize = 12.sp) },
                        modifier = Modifier.padding(end = 6.dp))
                }
            }
            if (step != Step.CONSENT && !(step == Step.FOLLOWING && followed != null)) Row(Modifier.horizontalScroll(rememberScrollState())) {
                ModeChip("🔢 " + tr("Numero del treno", "Train number")) { step = Step.NUMBER; choices = emptyList() }
                ModeChip("📍 " + tr("Vicino a me", "Near me")) { me(tr("Vicino a me", "Near me")); choices = emptyList(); near = emptyList(); step = Step.NEAR; nearTick++ }
                ModeChip("🕒 " + tr("Stazione e orario", "Station and time")) { choices = emptyList(); picking = true }
            }
            if (step == Step.FOLLOWING && followed != null) Row(Modifier.horizontalScroll(rememberScrollState())) {
                ModeChip(tr("Segui un altro treno", "Follow another train")) { askMode() }
                ModeChip(tr("Ritardo? I tuoi diritti", "Delayed? Your rights")) { onConditions() }
            }
        }
    }

    if (picking) {
        StationPickerDialog(tr("Da quale stazione parti?", "Which station do you leave from?"), { picking = false }) { s ->
            picking = false
            station = s
            me(s.name)
            step = Step.TIME
            bot(tr("A che ora parti da ${s.name}?", "What time do you leave ${s.name}?"))
        }
    }
}

private fun dist(m: Float): String = if (m < 1000) "${m.toInt()} m" else String.format(java.util.Locale.ITALY, "%.1f km", m / 1000)

@Composable
private fun ModeChip(label: String, onClick: () -> Unit) {
    AssistChip(onClick, label = { Text(label, fontSize = 13.sp) }, modifier = Modifier.padding(end = 6.dp))
}

@Composable
private fun ChatBubble(m: Bubble) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(14.dp))
                .background(if (m.mine) Green else MaterialTheme.colorScheme.surface).padding(12.dp),
        ) {
            if (!m.mine) Text(tr("Il mio Capotreno", "My Conductor"), color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(m.text, color = if (m.mine) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
        }
    }
}

/** Scheda dal vivo del treno seguito: stato, dove salgo, prossima fermata, dove scendo. */
@Composable
private fun LiveCard(st: TrainStatus?, ref: TrainRef, board: Station?, wake: Station?, onOpen: () -> Unit, onStop: () -> Unit) {
    WhiteCard {
        Column(Modifier.padding(14.dp)) {
            Text(st?.let { it.title + " · " + it.origin + " → " + it.destination } ?: ref.label, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (st == null) {
                Text(tr("Aggiornamento in corso…", "Updating…"), color = Muted, fontSize = 13.sp)
            } else {
                Text(st.stateText(), color = if (st.cancelled || st.delay > 5) LateRed else OnTime, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                val b = board?.let { s -> st.stops.firstOrNull { it.id == s.id || it.name.equals(s.name, true) } }
                if (b != null && !b.passed) {
                    val at = (if (b.schedDep > 0) b.schedDep else b.schedArr) + st.delay * 60_000L
                    Text("🚉 " + tr("Sali a ${b.name} alle ${Fmt.time(at)}", "Board at ${b.name} at ${Fmt.time(at)}") +
                        (if (b.platformText.isNotBlank()) " · " + tr("binario ", "platform ") + b.platformText else " · " + tr("binario non ancora indicato", "platform not yet announced")),
                        fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                }
                st.nextStop?.let { n ->
                    if (st.departed) Text("➡️ " + tr("Prossima fermata: ", "Next stop: ") + n.name + " " +
                        Fmt.time((if (n.schedArr > 0) n.schedArr else n.schedDep) + st.delay * 60_000L) +
                        (if (n.platformText.isNotBlank()) " · " + tr("bin. ", "plat. ") + n.platformText else ""), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                }
                val w = wake?.let { s -> st.stops.firstOrNull { it.id == s.id || it.name.equals(s.name, true) } }
                if (w != null) Text("⏰ " + tr("Scendi a ${w.name} verso le ", "You get off at ${w.name} around ") +
                    Fmt.time((if (w.schedArr > 0) w.schedArr else w.schedDep) + st.delay * 60_000L), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                if (st.lastStation.isNotBlank() && st.departed) Text(tr("Ultimo rilevamento: ", "Last seen: ") + st.lastStation + " " + Fmt.time(st.lastTime) +
                    (if (st.delay != 0) " (" + delayText(st.delay) + ")" else ""), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
            Row(Modifier.padding(top = 6.dp)) {
                TextButton(onOpen) { Text(tr("Apri il treno", "Open train"), color = Green) }
                TextButton(onStop) { Text(tr("Smetti di seguire", "Stop following"), color = LateRed) }
            }
        }
    }
}
