package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject

/** Stazione nel formato ViaggiaTreno (id tipo "S01700"). */
data class Station(val name: String, val id: String) {
    val num: Int get() = id.removePrefix("S").trimStart('0').toIntOrNull() ?: 0
    /** Id usato da LeFrecce (Trenitalia) per la ricerca soluzioni. */
    val lefrecceId: Long get() = 830000000L + num

    fun toJson(): JSONObject = JSONObject().put("name", name).put("id", id)

    companion object {
        fun from(o: JSONObject) = Station(o.optString("name"), o.optString("id"))
    }
}

/** Tratta Partenza → Arrivo (per recenti e preferiti). */
data class Tratta(val from: Station, val to: Station) {
    val key: String get() = from.id + ">" + to.id
    val label: String get() = "${from.name} → ${to.name}"
    val reversed: Tratta get() = Tratta(to, from)
    fun toJson(): JSONObject = JSONObject().put("from", from.toJson()).put("to", to.toJson())

    companion object {
        fun from(o: JSONObject) = Tratta(Station.from(o.getJSONObject("from")), Station.from(o.getJSONObject("to")))
    }
}

/** Linea preferita, es. "S5" Varese ⇄ Treviglio. */
data class Linea(
    val name: String,
    val a: Station,
    val b: Station,
    /** Pagina ufficiale della linea (es. Trenord, TILO), se nota. */
    val url: String = "",
    /** Azienda (Trenord, TILO, FerrovieNord, SBB, Trenitalia…). */
    val operator: String = "",
    /** Percorso descrittivo, es. "Alessandria – Pavia – Milano". */
    val route: String = "",
) {
    val key: String get() = "$name|${a.id}|${b.id}"
    val label: String get() = "$name ${a.name} – ${b.name}".trim()
    fun direction(back: Boolean): Tratta = if (back) Tratta(b, a) else Tratta(a, b)
    fun toJson(): JSONObject = JSONObject().put("n", name).put("a", a.toJson()).put("b", b.toJson())
        .put("u", url).put("op", operator).put("r", route)

    companion object {
        fun from(o: JSONObject) = Linea(
            o.optString("n"), Station.from(o.getJSONObject("a")), Station.from(o.getJSONObject("b")),
            o.optString("u"), o.optString("op"), o.optString("r"),
        )
    }
}

/** Riferimento a una corsa: numero + stazione d'origine + data (mezzanotte, ms). date = 0 → da risolvere. */
data class TrainRef(val number: String, val originCode: String = "", val date: Long = 0L, val label: String = number) {
    val key: String get() = "$number/$originCode"
    fun toJson(): JSONObject = JSONObject().put("n", number).put("o", originCode).put("d", date).put("l", label)

    companion object {
        fun from(o: JSONObject) = TrainRef(o.optString("n"), o.optString("o"), o.optLong("d"), o.optString("l", o.optString("n")))
    }
}

data class Leg(
    val number: String,
    val category: String,
    val from: String = "",
    val to: String = "",
    val dep: Long = 0L,
    val arr: Long = 0L,
) {
    val title: String get() = "$category $number".trim()
    fun toJson(): JSONObject = JSONObject().put("n", number).put("c", category).put("f", from).put("t", to).put("d", dep).put("a", arr)

    companion object {
        fun from(o: JSONObject) = Leg(o.optString("n"), o.optString("c"), o.optString("f"), o.optString("t"), o.optLong("d"), o.optLong("a"))
    }
}

data class Solution(
    val from: String,
    val to: String,
    val dep: Long,
    val arr: Long,
    val duration: String,
    val price: Double?,
    val legs: List<Leg>,
    val source: String = "trenitalia.com",
) {
    val changes: Int get() = (legs.size - 1).coerceAtLeast(0)

    fun toJson(): JSONObject {
        val a = JSONArray()
        legs.forEach { a.put(it.toJson()) }
        return JSONObject().put("from", from).put("to", to).put("dep", dep).put("arr", arr)
            .put("dur", duration).put("price", price ?: -1.0).put("legs", a).put("src", source)
    }

    companion object {
        fun from(o: JSONObject): Solution {
            val a = o.optJSONArray("legs") ?: JSONArray()
            val p = o.optDouble("price", -1.0)
            return Solution(
                o.optString("from"), o.optString("to"), o.optLong("dep"), o.optLong("arr"), o.optString("dur"),
                if (p < 0) null else p,
                (0 until a.length()).map { Leg.from(a.getJSONObject(it)) },
                o.optString("src", "trenitalia.com"),
            )
        }
    }
}

data class SavedSearch(val key: String, val title: String, val savedAt: Long, val solutions: List<Solution>) {
    fun toJson(): JSONObject {
        val a = JSONArray()
        solutions.forEach { a.put(it.toJson()) }
        return JSONObject().put("k", key).put("t", title).put("s", savedAt).put("sol", a)
    }

    companion object {
        fun from(o: JSONObject): SavedSearch {
            val a = o.optJSONArray("sol") ?: JSONArray()
            return SavedSearch(o.optString("k"), o.optString("t"), o.optLong("s"), (0 until a.length()).map { Solution.from(a.getJSONObject(it)) })
        }
    }
}

/** Riga del tabellone partenze/arrivi. */
data class BoardItem(
    val number: String,
    val category: String,
    val otherEnd: String,
    val time: Long,
    val delay: Int,
    val platform: String,
    val platformConfirmed: Boolean,
    val originCode: String,
    val departureDate: Long,
    val inStation: Boolean,
    /** Binario previsto (programmato) e binario reale (effettivo, vuoto finché non confermato). */
    val schedPlatform: String = "",
    val realPlatform: String = "",
    /** Impresa che effettua il servizio (Trenord, Trenitalia, Tper…). */
    val operator: String = "",
) {
    val platformText: String get() = platformLabel(schedPlatform, realPlatform)
    val title: String get() = "$category $number".trim()
    val ref: TrainRef get() = TrainRef(number, originCode, departureDate, title)
}

data class TrainStop(
    val name: String,
    val id: String,
    val schedArr: Long,
    val schedDep: Long,
    val realArr: Long,
    val realDep: Long,
    val delay: Int,
    val platform: String,
    val platformChanged: Boolean,
    val platformConfirmed: Boolean,
    /** Binario previsto (programmato) e binario reale (effettivo). */
    val schedPlatform: String = "",
    val realPlatform: String = "",
) {
    val platformText: String get() = platformLabel(schedPlatform, realPlatform)
    val passed: Boolean get() = realArr > 0 || realDep > 0
    val station: Station get() = Station(name, id)
}

data class TrainStatus(
    val number: String,
    val category: String,
    val origin: String,
    val destination: String,
    val originCode: String,
    val date: Long,
    val delay: Int,
    val lastStation: String,
    val lastTime: Long,
    val cancelled: Boolean,
    val stops: List<TrainStop>,
    val info: String = "",
    /** Impresa che effettua il servizio (Trenord, Trenitalia, Tper…). */
    val operator: String = "",
) {
    val title: String get() = "$category $number".trim()
    val ref: TrainRef get() = TrainRef(number, originCode, date, title)
    val depTime: Long get() = stops.firstOrNull()?.schedDep ?: 0L
    val arrTime: Long get() = stops.lastOrNull()?.schedArr ?: 0L
    val departed: Boolean get() = stops.any { it.passed }
    val arrived: Boolean get() = (stops.lastOrNull()?.realArr ?: 0L) > 0L
    val nextStop: TrainStop? get() = stops.firstOrNull { !it.passed }

    fun stateText(): String = when {
        cancelled -> I18n.tr("Treno soppresso", "Train cancelled")
        arrived -> I18n.tr("Arrivato", "Arrived") + delayText(delay, true)
        !departed -> I18n.tr("Non ancora partito", "Not departed yet") + (if (delay != 0) delayText(delay, true) else "")
        else -> delayText(delay).replaceFirstChar { it.uppercase() }
    }

    /** Testo breve per notifiche. */
    fun summary(): String {
        val sb = StringBuilder(stateText())
        if (lastStation.isNotBlank() && departed) sb.append("\nUltimo rilevamento: ").append(lastStation).append(" ").append(Fmt.time(lastTime))
        nextStop?.let { s ->
            sb.append("\nProssima: ").append(s.name).append(" ").append(Fmt.time(if (s.schedArr > 0) s.schedArr else s.schedDep))
            if (s.platformText.isNotBlank()) sb.append(I18n.tr(" · bin. ", " · plat. ")).append(s.platformText)
        }
        return sb.toString()
    }

    fun shareText(): String = buildString {
        append("🚆 ").append(title).append(" ").append(origin).append(" → ").append(destination).append("\n")
        append(summary())
    }
}

data class NewsItem(val title: String, val text: String, val date: Long)

enum class SearchFilter(private val itLabel: String) {
    BEST("Migliori soluzioni"),
    FRECCE("Alta velocità"),
    REGIONAL("Regionali"),
    ALL("Tutte le soluzioni"),
    ;

    val label: String get() = tx(itLabel)
}

data class Reminder(
    val id: Int,
    val number: String,
    val originCode: String,
    val at: Long,
    val eventTime: Long,
    val label: String,
    val arrival: Boolean,
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("n", number).put("o", originCode).put("at", at)
        .put("ev", eventTime).put("l", label).put("arr", arrival)

    companion object {
        fun from(o: JSONObject) = Reminder(o.optInt("id"), o.optString("n"), o.optString("o"), o.optLong("at"), o.optLong("ev"), o.optString("l"), o.optBoolean("arr"))
    }
}

/** Cosa mostra una singola istanza di widget. */
data class WidgetConfig(
    val station: Station? = null,
    val tratta: Tratta? = null,
    val train: TrainRef? = null,
    val title: String = "",
) {
    fun toJson(): JSONObject = JSONObject().apply {
        station?.let { put("s", it.toJson()) }
        tratta?.let { put("t", it.toJson()) }
        train?.let { put("tr", it.toJson()) }
        put("title", title)
    }

    companion object {
        fun from(o: JSONObject) = WidgetConfig(
            o.optJSONObject("s")?.let { Station.from(it) },
            o.optJSONObject("t")?.let { Tratta.from(it) },
            o.optJSONObject("tr")?.let { TrainRef.from(it) },
            o.optString("title"),
        )
    }
}

/** Categorie escludibili nelle opzioni avanzate, con il loro colore. */
val ALL_CATEGORIES = listOf("FA", "FR", "FB", "ITA", "BUS", "REG", "RV", "MET", "S", "D", "SFM", "IC", "ICN", "EC", "EN", "RE")

fun delayText(d: Int, withSep: Boolean = false): String {
    val s = when {
        d > 0 -> I18n.tr("$d min in ritardo", "$d min late")
        d < 0 -> I18n.tr("${-d} min in anticipo", "${-d} min early")
        else -> I18n.tr("in orario", "on time")
    }
    return if (withSep) " · $s" else s
}

/** "3" se previsto e reale coincidono (o c'è solo uno dei due), "3→5" se il binario reale è cambiato. */
fun platformLabel(sched: String, real: String): String = when {
    real.isNotBlank() && sched.isNotBlank() && real != sched -> "$sched→$real"
    real.isNotBlank() -> real
    else -> sched
}
