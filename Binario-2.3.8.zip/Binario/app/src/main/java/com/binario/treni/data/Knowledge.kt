package com.binario.treni.data

import java.text.Normalizer

/**
 * Base di conoscenza dell'assistente: risposte alle domande più comuni dei viaggiatori, sempre con la fonte ufficiale.
 * Il riconoscimento è tollerante: ignora accenti e maiuscole, accetta plurali e coniugazioni (radici delle parole)
 * e piccoli errori di battitura nelle parole lunghe.
 */
object Knowledge {
    data class Entry(
        val id: String,
        /** Ogni gruppo di radici deve comparire tutto nella domanda. "=parola" = parola esatta. */
        val triggers: List<List<String>>,
        val itText: String,
        val enText: String,
        val source: String = "",
        val url: String = "",
    ) {
        val text: String get() = I18n.tr(itText, enText)
    }

    /** Minuscole, senza accenti né punteggiatura. */
    fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    /** La radice compare tra le parole? Prefisso esatto, oppure un errore di battitura per radici di almeno 6 lettere. */
    fun hasStem(words: List<String>, stem: String): Boolean {
        if (stem.startsWith("=")) return words.contains(stem.substring(1))
        return words.any { w ->
            w.startsWith(stem) || (stem.length >= 6 && w.length >= stem.length - 1 && lev(w.take(stem.length), stem) <= 1)
        }
    }

    /** Punteggio di una voce: la lunghezza delle radici del gruppo più specifico trovato (0 = nessun gruppo completo). */
    fun score(e: Entry, words: List<String>): Int =
        e.triggers.filter { g -> g.all { hasStem(words, it) } }
            .maxOfOrNull { g -> g.sumOf { if (it.startsWith("=")) it.length + 1 else it.length } + (g.size - 1) * 3 } ?: 0

    /** La voce più pertinente, se il punteggio è sufficiente. */
    fun find(question: String, minScore: Int = 4): Entry? {
        val words = normalize(question).split(" ").filter { it.isNotBlank() }
        return entries.map { it to score(it, words) }.filter { it.second >= minScore }.maxByOrNull { it.second }?.first
    }

    /** Argomenti suggeriti quando la domanda non è chiara. */
    val topics: List<String> get() = listOf(
        I18n.tr("rimborso per ritardo", "delay compensation"), I18n.tr("bici sul treno", "bikes on trains"),
        I18n.tr("bambini", "children"), I18n.tr("assistenza disabili", "disability assistance"),
        I18n.tr("oggetti smarriti", "lost property"), I18n.tr("convalida biglietto", "ticket validation"),
        I18n.tr("bus e taxi a Varese", "bus and taxi at Varese"), I18n.tr("WC a Saronno", "toilets at Saronno"),
    )

    private const val TI_INDENNIZZO = "https://www.trenitalia.com/it/informazioni/indennizzo-per-ritardodeltreno.html"
    private const val TI_RIMBORSO = "https://www.trenitalia.com/it/informazioni/richiesta-di-rimborso.html"
    private const val TN_RIMBORSI = "https://www.trenord.it/assistenza/servizi/rimborsi-e-indennizzi/"
    private const val TI_DIRITTI = "https://www.trenitalia.com/it/informazioni/la-guida-del-viaggiatore/regolamento-ue-782-2021-diritti-e-obblighi-dei-passeggeri.html"

    val entries: List<Entry> = listOf(
        Entry("ritardo_rimborso",
            listOf(listOf("rimbors", "ritard"), listOf("indenn"), listOf("risarc"), listOf("compens"), listOf("refund", "delay"),
                listOf("compensation"), listOf("bonus", "ritard"), listOf("soldi", "ritard")),
            "Rimborso per ritardo (Regolamento UE 2021/782):\n• da 60 a 119 minuti di ritardo all'arrivo: indennizzo del 25% del biglietto\n• da 120 minuti: 50%\n" +
                "• Frecce Trenitalia: indennizzo anche tra 30 e 59 minuti, secondo le condizioni Trenitalia\n" +
                "• abbonati: regole proprie (Trenord riconosce bonus sugli abbonamenti in base alla puntualità della linea)\n" +
                "Se il ritardo previsto supera i 60 minuti puoi anche rinunciare al viaggio con rimborso completo o farti riprogrammare il viaggio. " +
                "Nella scheda del treno l'app ti mostra se hai diritto all'indennizzo.",
            "Delay compensation (EU Regulation 2021/782):\n• 60–119 minutes late on arrival: 25% of the ticket\n• 120 minutes or more: 50%\n" +
                "• Trenitalia Frecce: compensation also for 30–59 minutes, under Trenitalia's conditions\n" +
                "• season tickets: own rules (Trenord gives season-ticket bonuses based on line punctuality)\n" +
                "If the expected delay exceeds 60 minutes you can also give up the trip with a full refund or be re-routed. " +
                "The train screen shows whether you are entitled to compensation.",
            "Trenitalia · indennità per ritardo", TI_INDENNIZZO),
        Entry("rimborso_biglietto",
            listOf(listOf("rimbors", "bigliett"), listOf("rinunci"), listOf("annull", "bigliett"), listOf("cambi", "bigliett"),
                listOf("modific", "bigliett"), listOf("refund", "ticket"), listOf("cancel", "ticket"), listOf("change", "ticket")),
            "Rimborso o cambio del biglietto: dipende dall'offerta acquistata (le offerte economiche spesso non sono rimborsabili). " +
                "Trenitalia: richiesta dal sito o dall'app con codice del biglietto (PNR). Trenord: dalla pagina rimborsi. " +
                "Se il treno è soppresso o ha più di 60 minuti di ritardo previsto il rimborso è sempre dovuto.",
            "Ticket refund or change: it depends on the fare (cheap offers are often non-refundable). " +
                "Trenitalia: request on the website or app with the ticket code (PNR). Trenord: from the refunds page. " +
                "If the train is cancelled or expected more than 60 minutes late a refund is always due.",
            "Trenitalia · richiesta di rimborso", TI_RIMBORSO),
        Entry("convalida",
            listOf(listOf("convalid"), listOf("obliter"), listOf("timbr"), listOf("validat"), listOf("stamp", "ticket"), listOf("valid", "bigliett")),
            "Convalida: i biglietti regionali cartacei senza data e ora vanno convalidati prima di salire (obliteratrice in stazione). " +
                "I biglietti digitali acquistati online o in app riportano già il treno o il giorno: controlla sul biglietto se serve il check-in. " +
                "Le obliteratrici più vicine sono in Stazioni → scheda della stazione → Riepilogo, o in Altro → Rivendite vicine.",
            "Validation: paper regional tickets without date and time must be validated before boarding (validating machine in the station). " +
                "Digital tickets bought online or in the app already show the train or the day: check on the ticket whether check-in is needed. " +
                "The nearest validators are in Stations → station → Overview, or More → Nearby resellers.",
            "Trenord · condizioni di trasporto", "https://www.trenord.it/assistenza/informazioni-utili/condizioni-di-trasporto/"),
        Entry("multa",
            listOf(listOf("mult"), listOf("sanzion"), listOf("senza", "bigliett"), listOf("controllor"), listOf("without", "ticket"), listOf("=fined")),
            "Senza un biglietto valido si paga il biglietto più una sanzione; importi e modalità di pagamento (ridotti se paghi subito o entro pochi giorni) " +
                "sono nelle condizioni di trasporto dell'azienda. Se l'emettitrice era guasta segnalalo subito al capotreno.",
            "Without a valid ticket you pay the fare plus a fine; amounts and how to pay (reduced if you pay at once or within a few days) " +
                "are in the operator's conditions of carriage. If the ticket machine was broken, tell the conductor straight away.",
            "Trenord · sanzioni", "https://www.trenord.it/assistenza/servizi/sanzioni/"),
        Entry("bici",
            listOf(listOf("bici"), listOf("biciclett"), listOf("monopattin"), listOf("bike"), listOf("bicycle"), listOf("scooter")),
            "Bici e monopattini:\n• Trenord (Lombardia): bici tradizionali, pieghevoli, elettriche e monopattini viaggiano gratis su tutti i treni, senza limiti di orario, se c'è spazio\n" +
                "• Trenitalia Regionale: in genere sui treni con il simbolo della bici, con supplemento\n• Frecce e Italo: di norma solo bici pieghevoli chiuse in sacca\n" +
                "• TILO: in Ticino valgono le regole FFS, in Lombardia quelle Trenord",
            "Bikes and scooters:\n• Trenord (Lombardy): regular, folding, electric bikes and scooters travel free on all trains, at any time, space permitting\n" +
                "• Trenitalia Regional: usually on trains with the bike symbol, with a supplement\n• Frecce and Italo: normally only folded bikes in a bag\n" +
                "• TILO: SBB rules in Ticino, Trenord rules in Lombardy",
            "Trenord · trasporto biciclette", "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/trasporto-biciclette/"),
        Entry("animali",
            listOf(listOf("animal"), listOf("=cane"), listOf("=cani"), listOf("=gatto"), listOf("=gatti"), listOf("=dog"), listOf("=dogs"), listOf("=cat"), listOf("=pet"), listOf("=pets")),
            "Animali: quelli piccoli nel trasportino viaggiano in genere gratis; i cani più grandi viaggiano al guinzaglio e con museruola, " +
                "spesso con un biglietto ridotto. I cani guida per persone non vedenti viaggiano sempre gratis. Le regole esatte cambiano tra Trenord, Trenitalia e Italo.",
            "Pets: small animals in a carrier usually travel free; larger dogs travel on a leash with a muzzle, often with a reduced ticket. " +
                "Guide dogs for blind people always travel free. Exact rules differ between Trenord, Trenitalia and Italo.",
            "Trenord · trasporto animali", "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/trasporto-animali/"),
        Entry("bambini",
            listOf(listOf("bambin"), listOf("ragazz"), listOf("figli"), listOf("neonat"), listOf("child"), listOf("=kids"), listOf("infant")),
            "Bambini e ragazzi:\n• Regionali in Lombardia: gratis sotto i 4 anni senza posto a sedere, sconto 50% da 4 a 14 anni non compiuti\n" +
                "• Treni nazionali Trenitalia: gratis sotto i 4 anni senza posto, 50% sull'offerta Base da 4 a 15 anni non compiuti\n" +
                "• Altre regioni e Italo hanno regole proprie",
            "Children:\n• Regional trains in Lombardy: free under 4 without a seat, 50% off from 4 to under 14\n" +
                "• Trenitalia national trains: free under 4 without a seat, 50% off the Base fare from 4 to under 15\n" +
                "• Other regions and Italo have their own rules",
            "Trenord · ragazzi e bambini", "https://www.trenord.it/biglietti/agevolazioni-e-supplementi/ragazzi-e-bambini-in-treno/"),
        Entry("disabili",
            listOf(listOf("disabil"), listOf("carrozzin"), listOf("sedia", "rotell"), listOf("sala", "blu"), listOf("mobilita", "ridott"),
                listOf("wheelchair"), listOf("disab"), listOf("=prm"), listOf("accompagn", "assist")),
            "Assistenza per persone con disabilità o mobilità ridotta:\n• RFI Sala Blu (stazioni RFI): 800 90 60 60, da cellulare +39 02 32 32 32\n" +
                "• Trenord: 800 210 955 (tutti i giorni 8:15–19:45) o +39 02 72 49 49 49; prenota preferibilmente 48 ore prima\n" +
                "• FFS (Ticino): 0800 007 102\nNella scheda della stazione trovi ascensori per binario e guasti in corso.",
            "Assistance for people with disabilities or reduced mobility:\n• RFI Sala Blu (RFI stations): 800 90 60 60, from mobiles +39 02 32 32 32\n" +
                "• Trenord: 800 210 955 (daily 8:15–19:45) or +39 02 72 49 49 49; book preferably 48 hours ahead\n" +
                "• SBB (Ticino): 0800 007 102\nThe station screen shows lifts per platform and current faults.",
            "RFI · Sale Blu", "https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/le-informazioni-sull-assistenza-delle-sale-blu-in-un-click.html"),
        Entry("smarriti",
            listOf(listOf("smarrit"), listOf("=perso"), listOf("=persa"), listOf("dimentic"), listOf("=lost"), listOf("oggett", "trov")),
            "Oggetti smarriti: Trenord e FFS gestiscono quelli persi sui loro treni e stazioni (per i TILO transfrontalieri segnala a entrambi); " +
                "Trenitalia ha un servizio di ricerca online. Tieni pronti numero del treno, giorno e descrizione dell'oggetto.",
            "Lost property: Trenord and SBB handle items lost on their trains and stations (for cross-border TILO trains report to both); " +
                "Trenitalia has an online search service. Have the train number, day and a description ready.",
            "Trenord · oggetti smarriti", "https://www.trenord.it/assistenza/servizi/oggetti-smarriti/"),
        Entry("sciopero_rimborso",
            listOf(listOf("sciopero", "rimbors"), listOf("scioper", "bigliett"), listOf("strike", "refund")),
            "Sciopero e biglietti: Trenord rimborsa su richiesta entro 30 giorni dallo sciopero. Trenitalia rimborsa dalla proclamazione: " +
                "per Frecce e Intercity fino all'ora di partenza, per i regionali fino alle 24 del giorno prima. " +
                "Nelle fasce garantite (feriali 6–9 e 18–21) circolano i treni dell'elenco ufficiale.",
            "Strikes and tickets: Trenord refunds on request within 30 days of the strike. Trenitalia refunds from the announcement: " +
                "Frecce and Intercity up to departure time, regional trains until midnight of the day before. " +
                "In the guaranteed time bands (weekdays 6–9 and 18–21) the trains on the official list run.",
            "Trenord · in caso di sciopero", "https://www.trenord.it/assistenza/informazioni-utili/in-caso-di-sciopero/"),
        Entry("soppresso",
            listOf(listOf("soppress"), listOf("cancellat"), listOf("cancelled"), listOf("treno", "salt")),
            "Treno soppresso: hai diritto al rimborso completo oppure a viaggiare con il primo treno utile per la stessa destinazione. " +
                "Spesso viene attivato un bus sostitutivo: lo trovi nei comunicati (Altro → Scioperi, circolazione e lavori). " +
                "Per sapere se un treno è soppresso dimmi il suo numero.",
            "Cancelled train: you are entitled to a full refund or to travel on the first available train to the same destination. " +
                "A replacement bus is often provided: see the notices (More → Strikes, traffic and works). Tell me the train number to check it.",
            "Trenitalia · diritti dei passeggeri", TI_DIRITTI),
        Entry("coincidenza",
            listOf(listOf("coinciden", "pers"), listOf("=perso", "coinciden"), listOf("missed", "connection"), listOf("cambio", "pers")),
            "Coincidenza persa per ritardo: con un unico biglietto hai diritto a proseguire con il primo treno utile senza pagare di più. " +
                "Nelle soluzioni con cambio l'app mostra i minuti per il cambio e avvisa \"coincidenza a rischio\" se il primo treno è in ritardo.",
            "Missed connection because of a delay: with a single ticket you can continue on the first available train at no extra cost. " +
                "For journeys with a change the app shows the minutes to change and warns \"connection at risk\" if the first train is late.",
            "Trenitalia · diritti dei passeggeri", TI_DIRITTI),
        Entry("bagagli",
            listOf(listOf("bagagl"), listOf("valig"), listOf("luggage"), listOf("baggage"), listOf("suitcase")),
            "Bagagli: sui treni si viaggia con i propri bagagli negli appositi spazi, senza costi per l'uso normale; " +
                "devono restare sotto il tuo controllo e non bloccare corridoi e porte. Le grandi stazioni hanno spesso un deposito bagagli a pagamento.",
            "Luggage: you travel with your own bags in the luggage spaces at no cost for normal use; " +
                "they must stay under your control and not block aisles and doors. Large stations often have a paid left-luggage office.",
            "Trenitalia · condizioni di trasporto", "https://www.trenitalia.com/it/informazioni/condizioni-generali-di-trasporto.html"),
        Entry("acquisto",
            listOf(listOf("dove", "compr"), listOf("acquist", "bigliett"), listOf("compr", "bigliett"), listOf("buy", "ticket"), listOf("where", "ticket"), listOf("=pago", "bigliett")),
            "Biglietti: sui siti e nelle app ufficiali (Trenitalia, Trenord, Italo), alle biglietterie e alle emettitrici in stazione, " +
                "nelle rivendite autorizzate (tabaccherie, edicole). In Altro → Rivendite vicine trovi biglietterie, emettitrici (anche contactless) e rivendite intorno a te.",
            "Tickets: on the official websites and apps (Trenitalia, Trenord, Italo), at ticket offices and machines in the station, " +
                "and at authorised resellers (tobacconists, newsagents). More → Nearby resellers shows ticket offices, machines (also contactless) and resellers near you.",
            "Trenord · dove acquistare", "https://www.trenord.it/biglietti/dove-acquistare/acquista-online/"),
        Entry("abbonamenti",
            listOf(listOf("abbonament"), listOf("season", "ticket"), listOf("=io", "viaggio"), listOf("mensil"), listOf("annual")),
            "Abbonamenti: Trenord offre mensili e annuali e gli abbonamenti integrati Io Viaggio (treno + mezzi pubblici in Lombardia). " +
                "Trenitalia ha abbonamenti regionali e per le Frecce. Gli abbonati hanno regole di rimborso e bonus per i ritardi proprie.",
            "Season tickets: Trenord offers monthly and annual tickets and the integrated Io Viaggio passes (train + public transport in Lombardy). " +
                "Trenitalia has regional and Frecce passes. Season-ticket holders have their own refund and delay-bonus rules.",
            "Trenord · abbonamenti", "https://www.trenord.it/biglietti/titoli-di-viaggio/abbonamenti/"),
        Entry("malpensa",
            listOf(listOf("malpensa"), listOf("aeroport"), listOf("airport"), listOf("linate"), listOf("orio")),
            "Aeroporti:\n• Malpensa: Malpensa Express da Milano Cadorna e da Milano Centrale, fermate T1 e T2\n" +
                "• Linate: metropolitana M4 (non c'è il treno)\n• Orio al Serio (Bergamo): bus dalla stazione di Bergamo\n" +
                "Chiedimi per esempio \"treni da Milano Cadorna a Malpensa\".",
            "Airports:\n• Malpensa: Malpensa Express from Milano Cadorna and Milano Centrale, stops T1 and T2\n" +
                "• Linate: metro line M4 (no train)\n• Orio al Serio (Bergamo): bus from Bergamo station\n" +
                "Ask me for example \"trains from Milano Cadorna to Malpensa\".",
            "Trenord · Malpensa Express", "https://www.trenord.it/biglietti/titoli-di-viaggio/malpensa-express/"),
        Entry("svizzera",
            listOf(listOf("svizzer"), listOf("ticino"), listOf("lugano"), listOf("transfrontalier"), listOf("arcobaleno"), listOf("switzerland"), listOf("=chf"), listOf("=tilo")),
            "Svizzera e TILO: per i viaggi tra Lombardia e Ticino servono biglietti transfrontalieri (Arcobaleno in CHF o Trenord in euro). " +
                "Linee TILO, tariffe e servizi sono in Altro → TILO; per un tragitto chiedimi \"treni da Como a Lugano\".",
            "Switzerland and TILO: trips between Lombardy and Ticino need cross-border tickets (Arcobaleno in CHF or Trenord in euros). " +
                "TILO lines, fares and services are in More → TILO; for a route ask \"trains from Como to Lugano\".",
            "TILO · titoli di trasporto", "https://www.tilo.ch/servizi/titoli-di-trasporto.html"),
        Entry("contatti",
            listOf(listOf("numero", "telefon"), listOf("call", "center"), listOf("contatt"), listOf("phone", "number"), listOf("customer", "service"),
                listOf("assistenza", "client"), listOf("reclam"), listOf("complaint")),
            "Contatti:\n• Trenitalia: 892021 (call center)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (assistenza disabili): 800 90 60 60\n" +
                "Per i reclami usa i moduli sui siti ufficiali.",
            "Contacts:\n• Trenitalia: 892021 (call centre)\n• Trenord: +39 02 72 49 49 49\n• Italo: 892020\n• RFI Sala Blu (disability assistance): 800 90 60 60\n" +
                "For complaints use the forms on the official websites.",
            "Trenitalia · call center", "https://www.trenitalia.com/it/informazioni/i-nostri-call-center.html"),
        Entry("diritti",
            listOf(listOf("diritt"), listOf("=rights"), listOf("regolament"), listOf("=782")),
            "I tuoi diritti (Regolamento UE 2021/782): informazioni sul viaggio, rimborso o riprogrammazione se il ritardo previsto supera 60 minuti, " +
                "indennizzo del 25% (60–119 minuti) o 50% (da 120), assistenza (bevande, pasti, alloggio se necessario), assistenza gratuita per persone con disabilità.",
            "Your rights (EU Regulation 2021/782): travel information, refund or re-routing if the expected delay exceeds 60 minutes, " +
                "compensation of 25% (60–119 minutes) or 50% (120+), assistance (drinks, meals, accommodation if needed), free assistance for people with disabilities.",
            "Trenitalia · Regolamento UE 2021/782", TI_DIRITTI),
        Entry("binario_spiegazione",
            listOf(listOf("binario", "previst"), listOf("binario", "real"), listOf("binario", "blu"), listOf("binario", "ross"), listOf("platform", "change")),
            "Binari nell'app: il binario previsto è quello dell'orario; quello reale (in blu) è confermato dalla stazione. " +
                "Se cambia lo vedi evidenziato in rosso (es. 3 → 5) e, se segui il treno, ricevi una notifica e l'avviso vocale.",
            "Platforms in the app: the scheduled platform comes from the timetable; the actual one (blue) is confirmed by the station. " +
                "A change is shown in red (e.g. 3 → 5) and, if you follow the train, you get a notification and a voice alert.",
        ),
        // ---- Uso dell'app ----
        Entry("app_sveglia",
            listOf(listOf("svegli"), listOf("=alarm"), listOf("wake"), listOf("avvis", "scend"), listOf("dove", "scend")),
            "Sveglia per la fermata: apri il treno, tocca la fermata dove scendi e scegli \"Svegliami prima di questa fermata\". " +
                "Suona quando il treno lascia la fermata precedente (o 4 minuti prima); con gli avvisi vocali senti anche la voce.",
            "Stop alarm: open the train, tap the stop where you get off and choose \"Wake me before this stop\". " +
                "It rings when the train leaves the previous stop (or 4 minutes before); with voice alerts you also hear the voice."),
        Entry("app_salgo",
            listOf(listOf("salgo"), listOf("dove", "sal"), listOf("=board"), listOf("boarding")),
            "Dove salgo: apri il treno, tocca la fermata dove sali e scegli \"Salgo qui\". Binario, orario e avvisi si riferiscono a quella fermata.",
            "Where I board: open the train, tap the stop where you get on and choose \"I board here\". Platform, time and alerts refer to that stop."),
        Entry("app_offline",
            listOf(listOf("=pdf"), listOf("offline"), listOf("senza", "rete"), listOf("senza", "internet"), listOf("scaric", "orari"), listOf("download"), listOf("stamp")),
            "Orari senza rete: cerca la tratta e nei risultati tocca l'icona PDF per scaricare l'orario del giorno (andata e ritorno) in Download/Binario. " +
                "L'app ricorda anche da sola gli ultimi orari di ogni tratta cercata.",
            "Timetables offline: search the route and tap the PDF icon in the results to download the day's timetable (outbound and return) to Download/Binario. " +
                "The app also remembers the latest times of every route you searched."),
        Entry("app_voce",
            listOf(listOf("=voce"), listOf("vocal"), listOf("vedent"), listOf("ciec"), listOf("=blind"), listOf("talkback"), listOf("ipovedent")),
            "Avvisi vocali: in Impostazioni → Accessibilità scegli \"Tutti\" o \"Solo fermata imminente\". " +
                "Per chiedere a voce tocca il microfono qui sotto, oppure tieni premuta l'icona di Binario e scegli \"Chiedi a voce\".",
            "Voice alerts: in Settings → Accessibility choose \"All\" or \"Only upcoming stop\". " +
                "To ask by voice tap the microphone below, or long-press the Binario icon and choose \"Ask by voice\"."),
        Entry("app_sordi",
            listOf(listOf("=sordo"), listOf("=sorda"), listOf("=sordi"), listOf("ipoudent"), listOf("=deaf"), listOf("vibraz"), listOf("=flash")),
            "Avvisi per persone sorde: in Impostazioni → Accessibilità attiva vibrazione forte (uno schema per ogni avviso) e lampeggio del flash.",
            "Alerts for deaf people: in Settings → Accessibility turn on strong vibration (one pattern per alert) and the flashlight."),
        Entry("app_widget",
            listOf(listOf("widget")),
            "Widget: tieni premuto su uno spazio vuoto della Home → Widget → Binario. Ci sono Tragitto, Treno, Stazione e Preferiti; tocca il titolo per cambiarlo.",
            "Widgets: long-press an empty spot on the Home screen → Widgets → Binario. There are Route, Train, Station and Favourites; tap the title to change it."),
        Entry("app_segui",
            listOf(listOf("segui"), listOf("=follow"), listOf("notifica", "fiss"), listOf("tracking")),
            "Seguire un treno: apri il treno e tocca \"Segui\": una notifica fissa si aggiorna ogni minuto e avvisa di cambi di binario e ritardi.",
            "Following a train: open the train and tap \"Follow\": a pinned notification updates every minute and warns of platform changes and delays."),
        Entry("puntualita",
            listOf(listOf("puntualit"), listOf("punctual"), listOf("statistic")),
            "Puntualità: in Altro → Puntualità trovi le statistiche mensili, con regionali confrontati con regionali e alta velocità a parte, " +
                "e la puntualità di ogni stazione e treno (dati TrovaTreno.it).",
            "Punctuality: More → Punctuality has monthly statistics, with regional trains compared with regional ones and high speed separately, " +
                "plus every station and train (TrovaTreno.it data)."),
    )
}
