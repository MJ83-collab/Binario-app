package com.binario.treni.data

import java.util.Calendar
import java.util.TimeZone

/**
 * Tariffe Trenord (tariffa regionale Lombardia) per fascia chilometrica: biglietti e abbonamenti.
 * Fonte: tariffario Trenord in vigore dal 1 ottobre 2026 (identico per queste tabelle a quello del 1 settembre 2026).
 */
object TrenordFares {
    const val VALID_FROM = "01/10/2026"
    const val SOURCE_PDF = "https://www.trenord.it/fileadmin/contenuti/TRENORD/3-News/Trenord_Informa/Avvisi/2026/AvvisoA4Trenord_2026_179_Tariffario_01_ottobre.pdf"
    const val SOURCE_PAGE = "https://www.trenord.it/biglietti/titoli-di-viaggio/abbonamenti/"

    data class Band(
        val minKm: Int, val maxKm: Int,
        // Biglietto ordinario: adulti, ragazzi 4-14, anziani; carnet 10 viaggi (1ª e 2ª classe)
        val ord1: Double, val ord2: Double, val kid1: Double, val kid2: Double, val senior1: Double, val senior2: Double,
        val carnet1: Double, val carnet2: Double,
        // Abbonamenti settimanale, mensile, annuale (1ª e 2ª classe)
        val week1: Double, val week2: Double, val month1: Double, val month2: Double, val year1: Double, val year2: Double,
    ) {
        val label: String get() = "$minKm–$maxKm km"
    }

    val BANDS: List<Band> = listOf(
        Band(1, 5, 2.40, 1.60, 1.20, 0.80, 2.40, 1.60, 22.00, 14.50, 13.00, 8.50, 45.00, 30.00, 430.00, 287.00),
        Band(6, 10, 3.00, 2.00, 1.50, 1.00, 2.40, 1.60, 28.00, 18.50, 16.50, 11.00, 57.00, 38.00, 550.00, 367.00),
        Band(11, 15, 3.70, 2.50, 2.00, 1.30, 3.00, 2.00, 34.50, 23.00, 20.00, 13.00, 70.00, 46.50, 667.00, 445.00),
        Band(16, 20, 4.30, 2.90, 2.30, 1.50, 3.40, 2.30, 39.50, 26.00, 23.00, 15.00, 80.00, 53.00, 766.00, 511.00),
        Band(21, 25, 4.90, 3.30, 2.60, 1.70, 3.90, 2.60, 45.50, 30.00, 26.00, 17.50, 91.00, 61.00, 877.00, 585.00),
        Band(26, 30, 5.60, 3.80, 2.90, 1.90, 4.50, 3.00, 52.00, 34.50, 29.00, 19.50, 101.00, 68.00, 974.00, 649.00),
        Band(31, 35, 6.20, 4.10, 3.20, 2.10, 5.00, 3.30, 57.00, 38.00, 32.00, 21.50, 112.00, 75.00, 1073.00, 715.00),
        Band(36, 40, 6.90, 4.60, 3.50, 2.30, 5.50, 3.70, 63.00, 42.00, 34.50, 23.00, 121.00, 80.00, 1159.00, 773.00),
        Band(41, 50, 8.20, 5.40, 4.10, 2.70, 6.60, 4.30, 75.00, 50.00, 39.00, 26.00, 137.00, 91.00, 1316.00, 877.00),
        Band(51, 60, 9.50, 6.30, 4.80, 3.20, 7.60, 5.00, 87.00, 58.00, 43.50, 29.00, 151.00, 101.00, 1454.00, 969.00),
        Band(61, 70, 10.50, 6.90, 5.30, 3.50, 8.40, 5.50, 96.00, 64.00, 46.00, 30.50, 161.00, 107.00, 1541.00, 1028.00),
        Band(71, 80, 11.50, 7.70, 5.90, 3.90, 9.20, 6.20, 106.00, 71.00, 48.00, 32.00, 168.00, 112.00, 1611.00, 1074.00),
        Band(81, 90, 12.50, 8.40, 6.30, 4.20, 10.00, 6.70, 115.00, 77.00, 49.50, 33.00, 172.00, 115.00, 1656.00, 1104.00),
        Band(91, 100, 13.50, 9.00, 6.80, 4.50, 11.00, 7.20, 125.00, 83.00, 51.00, 33.50, 177.00, 118.00, 1699.00, 1133.00),
        Band(101, 120, 15.50, 10.50, 8.00, 5.30, 12.50, 8.40, 144.00, 96.00, 53.00, 35.00, 185.00, 123.00, 1774.00, 1183.00),
        Band(121, 140, 17.50, 12.00, 9.00, 6.00, 14.00, 9.60, 163.00, 109.00, 55.00, 36.50, 193.00, 129.00, 1851.00, 1234.00),
        Band(141, 160, 20.00, 13.00, 10.00, 6.50, 16.00, 10.50, 182.00, 122.00, 58.00, 38.50, 202.00, 135.00, 1944.00, 1296.00),
        Band(161, 180, 22.00, 14.50, 11.00, 7.30, 17.50, 11.50, 201.00, 134.00, 60.00, 40.00, 210.00, 140.00, 2017.00, 1345.00),
    )

    /** Trenocittà mensile (treno + mezzi urbani della città di arrivo), 2ª e 1ª classe, per città e fascia. */
    val TRENOCITTA_CITIES = listOf("Bergamo", "Brescia", "Como", "Cremona", "Lecco", "Lodi", "Mantova", "Milano", "Monza", "Pavia", "Sondrio", "Varese")

    /** Per ogni fascia (stesso ordine di [BANDS]) e città: (1ª classe, 2ª classe). */
    private val TRENOCITTA: List<List<Pair<Double, Double>>> = listOf(
        "70,55,72,57,73,58,70,55,72,57,69,54,78,63,72,57,73,58,70,55,68,53,73,58",
        "82,63,84,65,85,66,82,63,84,65,81,62,90,71,84,65,85,66,82,63,80,61,85,66",
        "95,72,97,74,98,75,95,71,97,73,94,71,103,79,97,74,98,75,95,71,93,70,98,74",
        "105,78,107,80,108,81,105,78,107,80,104,77,113,86,107,80,108,81,105,78,103,76,108,81",
        "116,86,118,88,119,89,116,86,118,88,115,85,124,94,118,88,119,89,116,86,114,84,119,89",
        "126,93,128,95,129,96,126,93,128,95,125,92,134,101,128,95,129,96,126,93,124,91,129,96",
        "137,100,139,102,140,103,137,100,139,102,136,99,145,108,139,102,140,103,137,100,135,98,140,103",
        "146,105,148,107,149,108,146,105,148,107,145,104,154,113,148,107,149,108,146,105,144,103,149,108",
        "162,116,164,118,165,119,162,116,164,118,161,115,170,124,164,118,165,119,162,116,160,114,165,119",
        "176,126,178,128,179,129,176,126,178,128,175,125,184,134,178,128,179,129,176,126,174,124,179,129",
        "186,132,188,134,189,135,186,132,188,134,185,131,194,140,188,134,189,135,186,132,184,130,189,135",
        "193,137,195,139,196,140,193,137,195,139,192,136,201,145,195,139,196,140,193,137,191,135,196,140",
        "197,140,199,142,200,143,197,140,199,142,196,139,205,148,199,142,200,143,197,140,195,138,200,143",
        "202,143,204,145,205,146,202,143,204,145,201,142,210,151,204,145,205,146,202,143,200,141,205,146",
        "210,148,212,150,213,151,210,148,212,150,209,147,218,156,212,150,213,151,210,148,208,146,213,151",
        "218,154,220,156,221,157,218,154,220,156,217,153,226,162,220,156,221,157,218,154,216,152,221,157",
        "227,160,229,162,230,163,227,160,229,162,226,159,235,168,229,162,230,163,227,160,225,158,230,163",
        "235,165,237,167,238,168,235,165,237,167,234,164,243,173,237,167,238,168,235,165,233,163,238,168",
    ).map { row -> row.split(',').map { it.toDouble() }.chunked(2).map { (a, b) -> a to b } }

    fun trenocitta(band: Band, city: String): Pair<Double, Double>? {
        val i = BANDS.indexOf(band)
        val c = TRENOCITTA_CITIES.indexOfFirst { it.equals(city, true) }
        if (i < 0 || c < 0) return null
        return TRENOCITTA[i][c]
    }

    /** Città Trenocittà di una stazione (es. "MILANO CENTRALE" → Milano, "VARESE NORD" → Varese). */
    fun trenocittaCity(stationName: String): String? {
        val n = stationName.uppercase()
        return TRENOCITTA_CITIES.firstOrNull { c -> n == c.uppercase() || n.startsWith(c.uppercase() + " ") }
    }

    /** Io Viaggio Ovunque in Lombardia (tutti i treni e mezzi pubblici della regione). */
    val IVOL = listOf("1 giorno" to 18.00, "2 giorni" to 30.00, "3 giorni" to 35.50, "7 giorni" to 47.50,
        "Mensile" to 118.00, "Trimestrale" to 341.00, "Annuale" to 1137.00)

    /** Io Viaggio Ovunque in Provincia, mensile. */
    val IVOP = listOf("Como, Lecco, Lodi, Sondrio, Varese" to 83.00, "Cremona, Mantova, Pavia" to 89.00, "Bergamo, Brescia" to 95.00)

    /** Supplemento prima classe (dal tariffario 01/10/2026). */
    const val FIRST_CLASS_TRIP = 2.80
    const val FIRST_CLASS_MONTH_IVOL = 42.00
    const val FIRST_CLASS_YEAR_IVOL = 420.00

    fun bandByKm(km: Int): Band? = BANDS.firstOrNull { km in it.minKm..it.maxKm }

    /** Il prezzo del biglietto ordinario di 2ª classe identifica la fascia (i valori sono tutti diversi). */
    fun bandBySecondClassPrice(price: Double): Band? = BANDS.firstOrNull { Math.abs(it.ord2 - price) < 0.005 }

    data class Lookup(val band: Band, val exact: Boolean, val note: String)

    /**
     * Fascia chilometrica tra due stazioni: dal prezzo del biglietto regionale (LeFrecce vende i regionali lombardi
     * alla stessa tariffa) e, se non disponibile, stimata dalla distanza in linea d'aria (+25% per il percorso dei binari).
     */
    fun lookup(store: Store, from: Station, to: Station): Lookup? {
        val morning = Calendar.getInstance(TimeZone.getTimeZone("Europe/Rome")).apply {
            add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 8); set(Calendar.MINUTE, 0)
        }.timeInMillis
        try {
            val sols = Api.solutions(from, to, morning, SearchFilter.REGIONAL)
            val prices = sols.mapNotNull { it.price }.mapNotNull { bandBySecondClassPrice(it) }
            prices.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key?.let {
                return Lookup(it, true, I18n.tr("Fascia dal prezzo ufficiale del biglietto regionale", "Band from the official regional ticket price"))
            }
        } catch (_: Exception) {
        }
        val a = Api.stationCoord(store, from.id) ?: return null
        val b = Api.stationCoord(store, to.id) ?: return null
        val km = (crowKm(a, b) * 1.25).toInt().coerceAtLeast(1)
        val band = bandByKm(km) ?: return null
        return Lookup(band, false, I18n.tr("Fascia stimata dalla distanza (circa $km km): verifica in biglietteria o sull'app Trenord", "Band estimated from distance (about $km km): check at the ticket office or in the Trenord app"))
    }

    fun crowKm(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
        val r = 6371.0
        val dLat = Math.toRadians(b.first - a.first)
        val dLon = Math.toRadians(b.second - a.second)
        val h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(a.first)) * Math.cos(Math.toRadians(b.first)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
        return r * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h))
    }
}
