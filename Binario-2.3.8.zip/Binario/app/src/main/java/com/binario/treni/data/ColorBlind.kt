package com.binario.treni.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Modalità per daltonici. Usa la palette Okabe-Ito (sicura per le forme più comuni di daltonismo)
 * e aggiunge simboli, così l'informazione non dipende mai solo dal colore.
 *  - "off": colori normali
 *  - "redgreen": protanopia / deuteranopia (rosso-verde, la forma più diffusa)
 *  - "tritan": tritanopia (blu-giallo)
 */
object ColorBlind {
    var mode by mutableStateOf("off")
    val on: Boolean get() = mode != "off"

    /** Ritardo / soppressione / binario cambiato. */
    val late: Long get() = when (mode) {
        "redgreen" -> 0xFFD55E00 // arancio vermiglio
        "tritan" -> 0xFFD32F2F
        else -> 0xFFD32F2F
    }

    /** In orario / in anticipo. */
    val ok: Long get() = when (mode) {
        "redgreen" -> 0xFF0072B2 // blu
        "tritan" -> 0xFF007A5E // verde acqua scuro
        else -> 0xFF4F9447
    }

    fun crowd(l: Crowd.Level): Long = when (mode) {
        "redgreen" -> when (l) {
            Crowd.Level.LOW -> 0xFF0072B2
            Crowd.Level.MEDIUM -> 0xFFE69F00
            Crowd.Level.HIGH -> 0xFF6A1B00
        }
        "tritan" -> when (l) {
            Crowd.Level.LOW -> 0xFF007A5E
            Crowd.Level.MEDIUM -> 0xFFCC79A7
            Crowd.Level.HIGH -> 0xFFD32F2F
        }
        else -> when (l) {
            Crowd.Level.LOW -> 0xFF2E7D32
            Crowd.Level.MEDIUM -> 0xFFF9A825
            Crowd.Level.HIGH -> 0xFFD32F2F
        }
    }

    /** Simbolo di livello (vuoto / metà / pieno), mostrato sempre in modalità daltonici. */
    fun crowdSymbol(l: Crowd.Level): String = when (l) {
        Crowd.Level.LOW -> "○"
        Crowd.Level.MEDIUM -> "◐"
        Crowd.Level.HIGH -> "●"
    }

    /** Prefisso testuale per il ritardo. */
    fun delaySymbol(delay: Int, cancelled: Boolean): String = if (!on) "" else when {
        cancelled -> "✕ "
        delay > 0 -> "▲ "
        else -> "✓ "
    }
}
