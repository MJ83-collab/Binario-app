package com.binario.treni.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.LifecycleEventObserver
import com.binario.treni.data.Updater
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Un solo controllo per ogni avvio dell'app (non a ogni rotazione dello schermo). */
private var checkedThisRun = false

/**
 * All'avvio controlla se è uscita una nuova versione. Se sì chiede se aggiornare; con "Aggiorna" la scarica da sola
 * e apre l'installazione di Android (che chiede la conferma finale).
 */
@Composable
fun UpdateDialog() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var release by remember { mutableStateOf<Updater.Release?>(null) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var apk by remember { mutableStateOf<File?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var needsPermission by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (checkedThisRun) return@LaunchedEffect
        checkedThisRun = true
        release = withContext(Dispatchers.IO) { Updater.check(ctx.applicationContext) }
    }

    fun tryInstall() {
        val f = apk ?: return
        if (!Updater.canInstall(ctx)) {
            needsPermission = true
            Updater.openInstallPermission(ctx)
        } else {
            needsPermission = false
            Updater.install(ctx, f)
        }
    }

    // Tornando dalle impostazioni con il permesso concesso, l'installazione parte da sola
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME && needsPermission && apk != null && Updater.canInstall(ctx)) tryInstall()
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val r = release ?: return
    fun start() {
        error = null
        progress = 0f
        scope.launch {
            try {
                val f = withContext(Dispatchers.IO) { Updater.download(ctx.applicationContext, r) { p -> progress = p } }
                apk = f
                progress = null
                tryInstall()
            } catch (e: Exception) {
                progress = null
                error = tx("Download non riuscito. Controlla la connessione e riprova.")
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (progress == null) release = null },
        title = { Text(tx("È uscita una nuova versione") + " · " + r.versionName) },
        text = {
            Column {
                when {
                    progress != null -> {
                        Text(tx("Scarico l'aggiornamento…"))
                        LinearProgressIndicator(progress = { progress ?: 0f }, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), color = Green)
                        Text("${((progress ?: 0f) * 100).toInt()}%", color = Muted, fontSize = 13.sp)
                    }
                    apk != null -> Text(
                        if (needsPermission) tx("Per installare l'aggiornamento consenti a Binario di installare app (lo chiede Android una sola volta), poi torna qui.")
                        else tx("Aggiornamento scaricato. Conferma l'installazione nella finestra di Android: preferiti e impostazioni restano."),
                    )
                    else -> {
                        Text(tx("Vuoi aggiornare Binario? L'app scarica la nuova versione da sola; preferiti e impostazioni restano."))
                        if (r.notes.isNotBlank()) {
                            Text(tx("Novità"), modifier = Modifier.padding(top = 10.dp), fontSize = 14.sp, color = Green)
                            Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                                Text(r.notes.take(3000), fontSize = 13.sp)
                            }
                        }
                    }
                }
                error?.let { Text(it, color = LateRed, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        },
        confirmButton = {
            when {
                progress != null -> {}
                apk != null -> Button({ tryInstall() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Text(if (needsPermission && !Updater.canInstall(ctx)) tx("Consenti") else tx("Installa"))
                }
                else -> Button({ start() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Text(if (error != null) tx("Riprova") else tx("Aggiorna"))
                }
            }
        },
        dismissButton = {
            if (progress == null) TextButton({ release = null }) { Text(tx("Più tardi")) }
        },
    )
}
