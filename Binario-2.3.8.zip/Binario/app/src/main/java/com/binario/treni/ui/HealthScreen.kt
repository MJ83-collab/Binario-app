package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Fmt
import com.binario.treni.data.Health
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Stato dei servizi: un semaforo per ogni fonte di dati, con il tempo di risposta.
 * Se qualcosa non funziona si capisce subito se è l'app o la fonte esterna.
 */
@Composable
fun HealthScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var results by remember { mutableStateOf<List<Health.Result>?>(null) }
    var at by remember { mutableLongStateOf(0L) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        results = null
        results = withContext(Dispatchers.IO) { Health.runAll() }
        at = System.currentTimeMillis()
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Stato dei servizi"), onBack) {
            IconButton({ tick++ }) { Icon(Icons.Filled.Refresh, tx("Ricontrolla")) }
            results?.let { r ->
                IconButton({
                    shareText(ctx, "Binario $APP_VERSION · " + tx("Stato dei servizi") + " " + Fmt.time(at) + "\n" +
                        r.joinToString("\n") { x -> (if (x.ok) "✅ " else "❌ ") + x.check.name + " · " + x.millis + " ms · " + x.detail })
                }) { Icon(Icons.Filled.Share, tx("Condividi")) }
            }
        }
        val r = results
        if (r == null) {
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
            MessageBox(tx("Controllo tutte le fonti di dati…"))
            return@Column
        }
        val bad = r.count { !it.ok }
        Text(
            if (bad == 0) tx("Tutte le fonti rispondono correttamente.") else "$bad " + tx("fonti con problemi: le funzioni collegate usano le riserve o gli ultimi dati salvati."),
            fontWeight = FontWeight.Medium, modifier = Modifier.padding(16.dp),
            color = if (bad == 0) Green else com.binario.treni.data.ColorBlind.late.let { Color(it.toInt()) },
        )
        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
            Health.Area.entries.forEach { area ->
                val list = r.filter { it.check.area == area }
                if (list.isEmpty()) return@forEach
                item { SectionHeader(tx(area.itLabel)) }
                items(list) { x ->
                    WhiteCard {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(14.dp).clip(CircleShape).background(if (x.ok) Green else com.binario.treni.data.ColorBlind.late.let { Color(it.toInt()) }))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(x.check.name, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                                Text(if (x.ok) tx("Funziona") else x.detail, color = Muted, fontSize = 13.sp)
                            }
                            Text("${x.millis} ms", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
            item {
                Text(tx("Controllato alle") + " " + Fmt.time(at) + ". " +
                    tx("Le fonti sono servizi pubblici esterni: se una è giù l'app prova le alternative (altri server, dati salvati, Google Maps)."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
            }
        }
    }
}

/** Dopo una chiusura improvvisa: propone di inviare il dettaglio tecnico (per email, WhatsApp…) o di ignorarlo. */
@Composable
fun CrashReportDialog() {
    val ctx = LocalContext.current
    val file = remember { java.io.File(ctx.filesDir, "crash.txt") }
    var report by remember { mutableStateOf(if (file.exists()) runCatching { file.readText() }.getOrNull() else null) }
    val r = report ?: return
    AlertDialog(
        onDismissRequest = { file.delete(); report = null },
        title = { Text(tx("L'app si è chiusa in modo inatteso")) },
        text = {
            Text(tx("Vuoi inviare la segnalazione allo sviluppatore? Contiene solo il dettaglio tecnico dell'errore, il modello del telefono " +
                "e la versione di Android: nessun dato personale, posizione o viaggio."))
        },
        confirmButton = {
            Button({ shareText(ctx, tx("Segnalazione errore Binario") + "\n\n" + r); file.delete(); report = null },
                colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tx("Invia segnalazione")) }
        },
        dismissButton = { TextButton({ file.delete(); report = null }) { Text(tx("Ignora")) } },
    )
}
