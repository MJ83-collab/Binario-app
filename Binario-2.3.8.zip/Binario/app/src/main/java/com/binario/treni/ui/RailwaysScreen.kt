package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Railways
import com.binario.treni.data.tx

/**
 * Tutte le imprese ferroviarie passeggeri di Italia e Svizzera (e quelle estere che vi entrano), con area servita,
 * sito, dove comprare i biglietti e da dove l'app prende tempo reale e puntualità.
 */
@Composable
fun RailwaysScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var country by remember { mutableStateOf<Railways.Country?>(null) }
    var query by remember { mutableStateOf("") }
    val q = query.trim()
    val list = Railways.all.filter { r ->
        (country == null || r.country == country) &&
            (q.isBlank() || r.name.contains(q, true) || r.area.contains(q, true))
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Imprese ferroviarie"), onBack)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            placeholder = { Text(tx("Cerca impresa o regione")) }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
            FilterChip(country == null, { country = null }, label = { Text(tx("Tutte") + " (${Railways.all.size})") }, modifier = Modifier.padding(end = 6.dp))
            Railways.Country.entries.forEach { c ->
                FilterChip(country == c, { country = if (country == c) null else c },
                    label = { Text(com.binario.treni.data.I18n.tr(c.itLabel, c.enLabel)) }, modifier = Modifier.padding(end = 6.dp))
            }
        }
        LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
            items(list) { r ->
                WhiteCard {
                    Column(Modifier.padding(14.dp)) {
                        Text(r.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(r.kindLabel + " · " + r.countryLabel, color = Green, fontSize = 13.sp)
                        Text(r.area, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
                        Text(r.liveLabel, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        Text(tx("Puntualità") + ": " + r.punctuality.ifBlank {
                            if (r.country == Railways.Country.CH) tx("non ancora inclusa (dati solo in file giornalieri troppo pesanti per il telefono: vedi nota in Puntualità)")
                            else tx("nessun dato pubblico")
                        }, color = Muted, fontSize = 13.sp)
                        Row {
                            TextButton({ openUrl(ctx, r.site) }) { Text(tx("Sito"), color = Green) }
                            if (r.tickets.isNotBlank()) TextButton({ openUrl(ctx, r.tickets) }) { Text(tx("Dove comprare"), color = Green) }
                        }
                    }
                }
            }
            item {
                Text(
                    tx("Il tempo reale dei treni sulla rete RFI arriva da ViaggiaTreno; quello di tutte le imprese svizzere dall'orario ufficiale svizzero. " +
                        "Per EAV, ARST, Trentino Trasporti e Cotral l'app mostra gli orari programmati (Transitous). Le altre ferrovie con rete propria pubblicano orari e tempo reale solo su sito e app."),
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp),
                )
            }
        }
    }
}
