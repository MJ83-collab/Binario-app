package com.binario.treni.data

import java.util.Calendar
import java.util.TimeZone

/**
 * Affollamento di un treno, con la stessa scala a colori dell'app Trenord:
 * verde = molti posti liberi, giallo = carico moderato (cerca bene i posti), rosso = pieno / solo in piedi.
 */
data class Crowd(val level: Level, val source: Source, val percent: Int? = null, val firstClass: Level? = null) {
    enum class Level(private val itText: String, private val enText: String, private val baseColor: Long) {
        LOW("Molti posti liberi", "Plenty of seats", 0xFF2E7D32),
        MEDIUM("Carico moderato: cerca bene i posti", "Moderately busy: look for seats", 0xFFF9A825),
        HIGH("Molto affollato", "Very crowded", 0xFFD32F2F),
        ;

        val label: String get() = I18n.tr(itText, enText)
        /** Colore secondo la modalità daltonici attiva. */
        val color: Long get() = ColorBlind.crowd(this)
        val symbol: String get() = ColorBlind.crowdSymbol(this)
    }

    enum class Source(private val itText: String, private val enText: String) {
        TRENORD("Trenord (sensori o storico dei giorni precedenti)", "Trenord (sensors or previous days' history)"),
        SBB("Previsione SBB", "SBB forecast"),
        ESTIMATE("Stima Binario per fascia oraria", "Binario estimate by time of day"),
        ;

        val label: String get() = I18n.tr(itText, enText)
    }

    companion object {
        fun fromPercent(p: Int, source: Source = Source.TRENORD) = Crowd(
            when {
                p < 40 -> Level.LOW
                p < 75 -> Level.MEDIUM
                else -> Level.HIGH
            },
            source, p,
        )

        /** Livelli SBB/transport.opendata.ch: 1 basso, 2 medio, 3 alto. */
        fun fromSbb(second: Int?, first: Int?): Crowd? {
            fun lv(v: Int?) = when (v) {
                1 -> Level.LOW
                2 -> Level.MEDIUM
                3 -> Level.HIGH
                else -> null
            }
            val l2 = lv(second) ?: return null
            return Crowd(l2, Source.SBB, null, lv(first))
        }

        /**
         * Stima indicativa quando non c'è un dato ufficiale: giorni feriali nelle ore di punta,
         * più alta per i treni da/verso Milano e per i suburbani/regionali. È dichiarata come stima nell'app.
         */
        fun estimate(time: Long, category: String, origin: String, destination: String): Crowd {
            if (time <= 0) return Crowd(Level.LOW, Source.ESTIMATE)
            val c = Calendar.getInstance(TimeZone.getTimeZone("Europe/Rome")).apply { timeInMillis = time }
            val dow = c.get(Calendar.DAY_OF_WEEK)
            val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            val weekday = dow in Calendar.MONDAY..Calendar.FRIDAY
            val morning = m in (6 * 60 + 45)..(9 * 60 + 15)
            val evening = m in (16 * 60 + 45)..(19 * 60 + 30)
            val cat = category.uppercase()
            val regional = cat.startsWith("S") || cat.startsWith("R") || cat.startsWith("REG") || cat.startsWith("RE")
            val toMilano = destination.contains("MILANO", true)
            val fromMilano = origin.contains("MILANO", true)
            val level = when {
                !weekday -> Level.LOW
                morning && regional && toMilano -> Level.HIGH
                evening && regional && fromMilano -> Level.HIGH
                (morning || evening) && regional -> Level.MEDIUM
                (morning || evening) -> Level.MEDIUM
                else -> Level.LOW
            }
            return Crowd(level, Source.ESTIMATE)
        }
    }
}
