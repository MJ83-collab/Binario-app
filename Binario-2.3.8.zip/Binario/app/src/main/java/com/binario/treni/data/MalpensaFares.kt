package com.binario.treni.data

/**
 * Tariffa aeroportuale Malpensa Express (da/per Malpensa Aeroporto T1 e T2), dal tariffario Trenord in vigore
 * dal 1 ottobre 2026 (uguale a quello del 1 settembre 2026), più le regole delle pagine ufficiali Trenord e
 * malpensaexpress.it. Per viaggiare da o verso l'aeroporto serve sempre la tariffa aeroportuale.
 */
object MalpensaFares {
    const val PAGE = "https://www.malpensaexpress.it/biglietti/biglietti-e-tariffe/biglietti/"
    const val SUBS_PAGE = "https://www.malpensaexpress.it/biglietti/biglietti-e-tariffe/abbonamenti/"
    const val LINES_PAGE = "https://www.trenord.it/linee-e-orari/il-nostro-servizio/malpensa-express/"

    data class Origin(
        val name: String,
        /** Percorso o linea, es. "via Terminal 2". */
        val via: String,
        val single: Double, val singleKid: Double,
        /** Andata e ritorno in giornata (solo dove previsto). */
        val returnDay: Double?, val returnDayKid: Double?,
        val week1: Double, val week2: Double, val month1: Double, val month2: Double, val year1: Double, val year2: Double,
        /** Parole per riconoscere la stazione nei nomi di ViaggiaTreno. */
        val keys: List<String>,
    )

    val ORIGINS: List<Origin> = listOf(
        Origin("Milano", "Cadorna, Centrale, Porta Garibaldi, Bovisa", 15.0, 7.5, 25.0, 12.5, 39.0, 26.0, 137.0, 91.0, 1316.0, 877.0, listOf("MILANO")),
        Origin("Saronno", "", 9.0, 4.5, 14.5, 7.0, 29.0, 19.5, 101.0, 68.0, 974.0, 649.0, listOf("SARONNO")),
        Origin("Rescaldina", "", 7.0, 3.5, 11.0, 5.5, 26.0, 17.5, 91.0, 61.0, 877.0, 585.0, listOf("RESCALDINA")),
        Origin("Castellanza", "", 6.0, 3.0, 9.5, 5.0, 23.0, 15.0, 80.0, 53.0, 766.0, 511.0, listOf("CASTELLANZA")),
        Origin("Busto Arsizio FN", "Busto Arsizio Nord", 5.0, 2.5, 8.0, 4.0, 20.0, 13.0, 70.0, 46.5, 667.0, 445.0, listOf("BUSTO ARSIZIO NORD", "BUSTO ARSIZIO FN")),
        Origin("Ferno-Lonate Pozzolo", "", 4.0, 2.0, 6.5, 3.0, 13.0, 8.5, 45.0, 30.0, 430.0, 287.0, listOf("FERNO")),
        Origin("Gallarate", "via Terminal 2", 4.0, 2.0, 6.5, 3.0, 16.5, 11.0, 57.0, 38.0, 550.0, 367.0, listOf("GALLARATE")),
        Origin("Gallarate", "via Busto Arsizio", 7.0, 3.5, null, null, 26.0, 17.5, 91.0, 61.0, 877.0, 585.0, listOf("GALLARATE")),
        Origin("Busto Arsizio FS", "Busto Arsizio (RFI)", 5.0, 2.5, null, null, 20.0, 13.0, 70.0, 46.5, 667.0, 445.0, listOf("BUSTO ARSIZIO")),
        Origin("Varese", "Varese FS", 15.0, 7.5, null, null, 39.0, 26.0, 137.0, 91.0, 1316.0, 877.0, listOf("VARESE")),
        Origin("Induno Olona", "", 15.0, 7.5, null, null, 39.0, 26.0, 137.0, 91.0, 1316.0, 877.0, listOf("INDUNO")),
        Origin("Arcisate", "", 15.0, 7.5, null, null, 39.0, 26.0, 137.0, 91.0, 1316.0, 877.0, listOf("ARCISATE")),
        Origin("Gaggiolo", "Cantello-Gaggiolo", 16.0, 8.0, null, null, 43.5, 29.0, 151.0, 101.0, 1454.0, 969.0, listOf("GAGGIOLO", "CANTELLO GAGGIOLO")),
    )

    const val FAMILY = 36.0
    const val RETURN_30_DAYS = 25.0
    const val RETURN_30_DAYS_KID = 12.5
    const val TRANSFER_T1_T2 = 2.0
    const val TRANSFER_T1_T2_KID = 1.0

    fun isMalpensa(name: String) = name.uppercase().contains("MALPENSA")

    /** Tariffe aeroportuali per una stazione (Gallarate ne ha due, a seconda del percorso). */
    fun forStation(name: String): List<Origin> {
        val n = name.uppercase().replace('-', ' ').replace(Regex("\\s+"), " ").trim()
        // Vince la parola più lunga: "BUSTO ARSIZIO NORD" non deve prendere anche la tariffa di Busto Arsizio FS
        val matches = ORIGINS.mapNotNull { o -> o.keys.filter { k -> n == k || n.startsWith("$k ") }.maxOfOrNull { it.length }?.let { o to it } }
        val best = matches.maxOfOrNull { it.second } ?: return emptyList()
        return matches.filter { it.second == best }.map { it.first }.filter { o -> !(o.name == "Varese" && n.contains("NORD")) }
    }

    /** Linee e limitazioni, dalle pagine ufficiali. */
    val LINES: List<Pair<String, String>> = listOf(
        "Milano Cadorna ⇄ Malpensa" to "Partenze da Cadorna ai minuti 27 e 57 (dalle 4.27 alle 00.20), 37 minuti. Ferma a Milano Bovisa, Saronno, Busto Arsizio Nord. Solo PRIMA classe.",
        "Milano Centrale ⇄ Malpensa" to "Partenze da Centrale ai minuti 25 e 55 (dalle 5.25 alle 23.25), 51 minuti. Fermano a Porta Garibaldi, Bovisa, Saronno, Busto Arsizio; le corse del minuto 25 anche a Rescaldina, Castellanza e Ferno-Lonate Pozzolo. Prima e seconda classe, ma la seconda classe è solo per i viaggi che NON partono o arrivano all'aeroporto.",
    )

    val RULES: List<String> = listOf(
        "Da o per Malpensa Terminal 1 e 2 serve sempre un biglietto a tariffa aeroportuale: abbonamenti regionali, Io Viaggio Ovunque (Lombardia o provincia di Varese) e STIBM valgono sui treni Malpensa Express solo tra le altre stazioni.",
        "Il biglietto per Malpensa vale per entrambi i terminal.",
        "Corsa semplice: valida nel giorno scelto fino a fine servizio, nessuna convalida; la data si può cambiare fino a 3 volte entro il giorno prima.",
        "Andata e ritorno: in giornata nelle biglietterie e alle emettitrici; entro 30 giorni solo online e da app (Milano ⇄ Malpensa, 25 € invece di 30 €), si cambia solo la data del ritorno.",
        "Malpensa Family 36 €: 2 adulti e 2 ragazzi da 4 a 17 anni, tra una stazione di Milano e l'aeroporto. Sotto i 4 anni si viaggia gratis.",
        "Ragazzi: tariffa ridotta dai 4 ai 13 anni.",
        "Il biglietto Malpensa Express da/per Milano vale anche su tutti i treni tra le stazioni dell'area di Milano.",
        "Nelle tratte urbane (Cadorna–Domodossola–Bovisa e Centrale–Porta Garibaldi–Bovisa) valgono anche i biglietti Trenord e STIBM urbani. STIBM vale solo in 2ª classe, sui treni da/per Milano Centrale anche fino a Rescaldina (Mi1–Mi7).",
        "Abbonamenti Malpensa Express: settimanale (si compra dal giovedì prima, si attiva entro 5 giorni), mensile (dal 22 del mese prima, entro 15 giorni), annuale (entro 30 giorni); su tessera Io Viaggio o Phone Pass.",
        "Bici e cane gratis come bagaglio con carta d'imbarco; senza carta d'imbarco il cane paga il supplemento animali.",
        "Transfer tra Terminal 1 e Terminal 2: 2 € adulti, 1 € ragazzi.",
    )
}
