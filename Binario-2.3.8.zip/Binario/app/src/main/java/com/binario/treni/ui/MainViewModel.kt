package com.binario.treni.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.SavedSearch
import com.binario.treni.data.SearchFilter
import com.binario.treni.data.Solution
import com.binario.treni.data.Station
import com.binario.treni.data.Store
import com.binario.treni.data.Tratta
import com.binario.treni.data.TrainStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val store = Store(app)

    // Parametri di ricerca
    var from by mutableStateOf<Station?>(null)
    var to by mutableStateOf<Station?>(null)
    var roundTrip by mutableStateOf(false)
    var date by mutableStateOf(roundToQuarter(System.currentTimeMillis()))
    var returnDate by mutableStateOf(roundToQuarter(System.currentTimeMillis() + 3 * 3600_000L))
    var filter by mutableStateOf(SearchFilter.BEST)
    var maxChanges by mutableStateOf(store.maxChanges)
    var excluded by mutableStateOf(store.excluded)

    // Risultati
    var results by mutableStateOf<List<Solution>>(emptyList())
    var returnResults by mutableStateOf<List<Solution>>(emptyList())
    var loading by mutableStateOf(false)
    var loadingMore by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var offlineTitle by mutableStateOf<String?>(null)
    /** Avviso quando, senza rete, mostriamo gli ultimi orari salvati della tratta. */
    var staleNote by mutableStateOf<String?>(null)

    /** Treno da mostrare sulla mappa del tragitto. */
    var mapTrain by mutableStateOf<TrainStatus?>(null)

    fun saveAdvanced(max: Int, ex: Set<String>) {
        maxChanges = max; excluded = ex
        store.maxChanges = max; store.excluded = ex
    }

    /** Da dove si è aperto l'ultimo treno (tabellone o soluzioni): serve a imparare i treni abituali. */
    var tripBoard: Station? = null
    var tripAlight: Station? = null

    /** Linea da mostrare nella schermata linea. */
    var currentLine by mutableStateOf<com.binario.treni.data.Linea?>(null)

    fun swap() {
        val f = from; from = to; to = f
    }

    fun search() {
        val f = from ?: return
        val t = to ?: return
        store.addRecent(Tratta(f, t))
        offlineTitle = null
        loading = true
        error = null
        results = emptyList()
        returnResults = emptyList()
        staleNote = null
        viewModelScope.launch {
            try {
                results = withContext(Dispatchers.IO) { Api.solutions(f, t, date, filter, maxChanges, excluded) }
                if (roundTrip) {
                    returnResults = withContext(Dispatchers.IO) { Api.solutions(t, f, returnDate, filter, maxChanges, excluded) }
                }
                // Copia automatica degli ultimi orari della tratta, per quando manca la rete
                if (results.isNotEmpty()) withContext(Dispatchers.IO) { store.cacheResults(Tratta(f, t).key, results) }
                if (results.isEmpty()) error = "Nessuna soluzione trovata per l'orario scelto."
            } catch (e: Exception) {
                // Senza rete: ultimi orari scaricati per la stessa tratta (dalle soluzioni successive all'ora scelta)
                val cached = withContext(Dispatchers.IO) { store.cachedResults(Tratta(f, t).key) }
                val useful = cached?.second?.filter { it.dep >= date - 30 * 60_000L }.orEmpty()
                if (cached != null && useful.isNotEmpty()) {
                    results = useful
                    staleNote = com.binario.treni.data.I18n.tr(
                        "Connessione assente: orari scaricati alle ${Fmt.time(cached.first)} del ${Fmt.day(cached.first)}. Ritardi non aggiornati.",
                        "Offline: timetable downloaded at ${Fmt.time(cached.first)} on ${Fmt.day(cached.first)}. Delays not updated.")
                } else {
                    error = "Impossibile contattare il server. Controlla la connessione." +
                        (e.message?.takeIf { it.isNotBlank() }?.let { "\n($it)" } ?: "")
                }
            }
            loading = false
        }
    }

    /** Carica le soluzioni successive all'ultima mostrata. */
    fun loadMore(returnLeg: Boolean) {
        val list = if (returnLeg) returnResults else results
        val last = list.lastOrNull() ?: return
        val f = (if (returnLeg) to else from) ?: return
        val t = (if (returnLeg) from else to) ?: return
        loadingMore = true
        viewModelScope.launch {
            try {
                val more = withContext(Dispatchers.IO) { Api.solutions(f, t, last.dep + 60_000, filter, maxChanges, excluded) }
                val merged = (list + more).distinctBy { it.dep.toString() + it.legs.joinToString { l -> l.number } }
                if (returnLeg) returnResults = merged else results = merged
            } catch (_: Exception) {
            }
            loadingMore = false
        }
    }

    fun saveOffline(): Boolean {
        val f = from ?: return false
        val t = to ?: return false
        if (results.isEmpty()) return false
        val key = "${f.id}>${t.id}@${Fmt.day(date)}"
        store.saveSearch(SavedSearch(key, "${f.name} → ${t.name} · ${Fmt.dayTime(date)}", System.currentTimeMillis(), results))
        return true
    }

    fun openSaved(s: SavedSearch) {
        offlineTitle = s.title
        results = s.solutions
        returnResults = emptyList()
        roundTrip = false
        error = null
        loading = false
    }

    companion object {
        fun roundToQuarter(ms: Long): Long {
            val q = 15 * 60_000L
            return ms - ms % q
        }
    }
}
