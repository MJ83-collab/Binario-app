package com.binario.treni.data

/**
 * Impresa ferroviaria che effettua il servizio di un treno.
 * - ViaggiaTreno la indica con "codiceCliente" (verificato sul tabellone di Milano Centrale del 15/10/2026):
 *   63 = Trenord, 2 = Trenitalia regionale, 18 = Trenitalia Tper, 1 = Trenitalia AV/EuroCity, 4 = Trenitalia Intercity.
 * - LeFrecce la scrive nel nome del treno ("S50 TRENORD 25592", "RE SBB 25591").
 */
object Operators {
    fun fromClientCode(code: Int, category: String, text: String = ""): String = when (code) {
        63 -> "Trenord"
        18 -> "Tper"
        1, 2, 4 -> fromText(category, text).takeIf { it != "" && it != "Trenitalia" } ?: "Trenitalia"
        64 -> "ÖBB"
        else -> fromText(category, text)
    }

    /** Impresa ricavata dal testo del treno; se non c'è indizio, Trenitalia per le categorie Trenitalia. */
    fun fromText(category: String, number: String): String {
        val t = " " + (category + " " + number).uppercase() + " "
        return when {
            t.contains("TILO") || (t.contains("TRENORD") && (t.contains(" SBB") || t.contains(" CFF") || t.contains(" FFS"))) -> "TILO"
            t.contains("TRENORD") || t.contains(" TN ") -> "Trenord"
            t.contains(" SBB") || t.contains(" CFF") || t.contains(" FFS") -> "SBB"
            t.contains("TPER") -> "Tper"
            t.contains("ITALO") || category.uppercase().startsWith("ITA") || t.contains(" NTV ") -> "Italo"
            t.contains(" OBB") || t.contains("ÖBB") -> "ÖBB"
            t.contains(" DB ") -> "DB"
            t.contains("TRENITALIA") -> "Trenitalia"
            // Tutte le altre imprese di Italia e Svizzera (registro in Railways)
            Railways.match(category + " " + number) != null -> Railways.match(category + " " + number)!!.short
            category.isBlank() -> ""
            else -> "Trenitalia"
        }
    }

    private val WORDS = Regex("\\b(TRENORD|TRENITALIA|SBB|CFF|FFS|TILO|TPER|ITALO|NTV|ÖBB|OBB|BLS|SOB|RHB|EAV|FSE|SAD|TUA|THURBO|ZB|MGB|FART|FLP|TPF|MOB|ARENAWAYS)\\b", RegexOption.IGNORE_CASE)

    /** Toglie dal numero il nome dell'impresa (già mostrato a parte): "SBB / SU S50 TRENORD 25591" → "SU S50 25591". */
    fun cleanNumber(number: String): String =
        number.split("/").map { WORDS.replace(it, " ").replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotBlank() }.distinct().joinToString(" / ").ifBlank { number }
}
