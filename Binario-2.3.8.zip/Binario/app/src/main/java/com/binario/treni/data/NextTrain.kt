package com.binario.treni.data

import kotlin.math.abs

/**
 * Stato in tempo reale del treno abituale di oggi e, se è soppresso o in forte ritardo, le alternative pronte
 * (anche di altre imprese: Trenord, Trenitalia, Italo, FFS/TILO…).
 */
object NextTrain {
    data class Live(
        val habit: Habit,
        /** Partenza programmata dalla stazione di salita. */
        val dep: Long,
        val found: Boolean,
        val ref: TrainRef?,
        val status: TrainStatus?,
        val delay: Int,
        val cancelled: Boolean,
        val platform: String,
        val schedPlatform: String,
        val departed: Boolean,
        val destination: String,
    ) {
        val platformChanged: Boolean get() = platform.isNotBlank() && schedPlatform.isNotBlank() && platform != schedPlatform
        val platformText: String get() = platformLabel(schedPlatform, platform)
        val needsAlternative: Boolean get() = found && !departed && (cancelled || delay > 15)

        fun stateText(): String = when {
            !found -> I18n.tr("Dati in tempo reale non ancora disponibili", "Live data not yet available")
            cancelled -> I18n.tr("Soppresso", "Cancelled")
            departed -> I18n.tr("Partito", "Departed") + delayText(delay, true)
            else -> delayText(delay).replaceFirstChar { it.uppercase() }
        }
    }

    data class Alt(val title: String, val operator: String, val dep: Long, val arr: Long, val detail: String, val ref: TrainRef?)

    fun live(h: Habit, now: Long = System.currentTimeMillis()): Live {
        val dep = Habits.todayAt(h, now)
        val digits = Habits.digits(h.number)
        val item = try {
            Api.departures(h.board, dep - 20 * 60_000L).firstOrNull { Habits.digits(it.number) == digits && abs(it.time - dep) < 3 * 3600_000L }
        } catch (e: Exception) {
            null
        }
        val ref = item?.ref ?: if (h.originCode.startsWith("S")) TrainRef(digits, h.originCode, Fmt.midnight(now), h.title) else null
        val st = ref?.let { r -> runCatching { Api.status(r) }.getOrNull() }
        val stop = st?.stops?.let { l -> l.firstOrNull { it.id == h.board.id } ?: l.firstOrNull { it.name.equals(h.board.name, true) } }
        val departed = stop?.let { it.realDep > 0 } ?: (st?.departed == true && stop == null)
        val delay = when {
            stop != null && stop.passed -> stop.delay
            item != null -> maxOf(item.delay, st?.delay ?: 0)
            else -> st?.delay ?: 0
        }
        return Live(
            habit = h, dep = stop?.schedDep?.takeIf { it > 0 } ?: item?.time ?: dep,
            found = st != null || item != null, ref = st?.ref ?: ref, status = st, delay = delay,
            cancelled = st?.cancelled == true,
            platform = stop?.realPlatform?.ifBlank { null } ?: item?.realPlatform.orEmpty(),
            schedPlatform = stop?.schedPlatform?.ifBlank { null } ?: item?.schedPlatform.orEmpty(),
            departed = departed, destination = st?.destination ?: item?.otherEnd.orEmpty(),
        )
    }

    /**
     * Fino a 3 alternative: soluzioni verso la stazione dove scendi (o il capolinea del treno) e, dal tabellone,
     * gli altri treni per la stessa destinazione. Se il treno è solo in ritardo, solo quelle che partono prima di lui.
     */
    fun alternatives(live: Live, now: Long = System.currentTimeMillis()): List<Alt> {
        val h = live.habit
        val digits = Habits.digits(h.number)
        val latest = if (live.cancelled) Long.MAX_VALUE else live.dep + live.delay * 60_000L - 2 * 60_000L
        val out = mutableListOf<Alt>()
        val target = h.alight ?: live.status?.stops?.lastOrNull()?.station?.takeIf { it.id.isNotBlank() && it.id != h.board.id }
        if (target != null) {
            try {
                Api.solutions(h.board, target, now, SearchFilter.ALL).filter { s ->
                    s.dep >= now - 60_000L && s.dep < latest && s.legs.none { Habits.digits(it.number) == digits }
                }.take(3).forEach { s ->
                    val first = s.legs.firstOrNull()
                    out += Alt(
                        title = s.legs.joinToString(" + ") { it.title },
                        operator = first?.let { Operators.fromText(it.category, it.number) }.orEmpty(),
                        dep = s.dep, arr = s.arr,
                        detail = target.name + " " + Fmt.time(s.arr) +
                            (if (s.changes > 0) " · " + s.changes + I18n.tr(" cambi", " changes") else " · " + I18n.tr("diretto", "direct")),
                        ref = first?.let { TrainRef(it.number, label = it.title) },
                    )
                }
            } catch (_: Exception) {
            }
        }
        if (live.destination.isNotBlank()) {
            try {
                Api.departures(h.board, now).filter { b ->
                    b.time >= now - 60_000L && b.time < latest && Habits.digits(b.number) != digits &&
                        b.otherEnd.equals(live.destination, true)
                }.take(3).forEach { b ->
                    out += Alt(
                        title = b.title, operator = b.operator, dep = b.time + b.delay * 60_000L, arr = 0L,
                        detail = I18n.tr("per", "to") + " " + b.otherEnd + delayText(b.delay, true) +
                            (if (b.platformText.isNotBlank()) I18n.tr(" · bin. ", " · plat. ") + b.platformText else ""),
                        ref = b.ref,
                    )
                }
            } catch (_: Exception) {
            }
        }
        return out.distinctBy { Habits.digits(it.title) }.sortedBy { it.dep }.take(3)
    }
}
