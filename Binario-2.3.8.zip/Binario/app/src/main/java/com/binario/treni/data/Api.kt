package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object Fmt {
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")
    fun time(ms: Long): String = if (ms <= 0) "--:--" else SimpleDateFormat("HH:mm", Locale.ITALY).apply { timeZone = rome }.format(Date(ms))
    fun day(ms: Long): String = SimpleDateFormat("dd MMM", Locale.ITALY).apply { timeZone = rome }.format(Date(ms))
    fun dayLong(ms: Long): String = SimpleDateFormat("EEEE d MMMM", Locale.ITALY).apply { timeZone = rome }.format(Date(ms))
        .replaceFirstChar { it.uppercase() }
    fun dayTime(ms: Long): String = SimpleDateFormat("dd MMM HH:mm", Locale.ITALY).apply { timeZone = rome }.format(Date(ms))
    fun price(p: Double?): String = if (p == null) "" else String.format(Locale.ITALY, "%.2f €", p)
    fun duration(dep: Long, arr: Long): String {
        if (dep <= 0 || arr <= dep) return ""
        val m = ((arr - dep) / 60000).toInt()
        return "${m / 60}h ${"%02d".format(m % 60)}m"
    }

    fun midnight(ms: Long = System.currentTimeMillis()): Long = Calendar.getInstance(rome).apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}

/**
 * Client per i dati pubblici:
 *  - ViaggiaTreno (RFI/Trenitalia): stazioni, tabelloni, andamento treni in tempo reale.
 *  - LeFrecce (Trenitalia): soluzioni di viaggio con prezzi.
 * Sono API non ufficiali: possono cambiare senza preavviso, per questo il parsing è difensivo.
 */
object Api {
    private const val VT = "http://www.viaggiatreno.it/infomobilita/resteasy/viaggiatreno/"
    private const val LF = "https://www.lefrecce.it/Channels.Website.BFF.WEB/website/"
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")

    // ---------------- HTTP ----------------

    private fun open(url: String): HttpURLConnection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Binario/1.0")
        setRequestProperty("Accept-Language", "it-IT")
    }

    /** GET con un secondo tentativo in caso di errore di rete o del server (5xx): ViaggiaTreno a volte "singhiozza". */
    private fun get(url: String): String {
        var last: IOException? = null
        for (attempt in 0 until 2) {
            try {
                return getOnce(url)
            } catch (e: IOException) {
                last = e
                if (e.message?.startsWith("HTTP 4") == true) break
                try { Thread.sleep(700) } catch (_: InterruptedException) { break }
            }
        }
        throw last ?: IOException("Errore di rete")
    }

    private fun getOnce(url: String): String {
        val c = open(url)
        try {
            // Se un sito rifiuta l'app (403), riprova presentandosi come il browser del telefono
            if (c.responseCode == 403) {
                c.disconnect()
                val b = open(url).apply { setRequestProperty("User-Agent", BROWSER_UA) }
                try {
                    if (b.responseCode !in 200..299) throw IOException("HTTP ${b.responseCode}")
                    return b.inputStream.bufferedReader().use { it.readText() }
                } finally {
                    b.disconnect()
                }
            }
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun post(url: String, body: String): String {
        val c = open(url)
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    // ---------------- LeFrecce: sessione (token CSRF + cookie) ----------------

    private const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36"
    private var lfToken: String? = null
    private var lfCookie: String? = null
    private var lfAuthAt = 0L

    /** LeFrecce richiede prima POST whitelist/enabled: restituisce un token CSRF e i cookie di sessione. */
    @Synchronized
    private fun lfAuth(force: Boolean = false) {
        if (!force && lfAuthAt > 0 && System.currentTimeMillis() - lfAuthAt < 10 * 60_000) return
        val c = (URL(LF + "whitelist/enabled").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 20000
            requestMethod = "POST"; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", BROWSER_UA)
            setRequestProperty("Accept-Language", "it-IT")
        }
        try {
            c.outputStream.use { it.write("{}".toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IOException("LeFrecce whitelist HTTP $code")
            val token = try {
                val o = JSONObject(text)
                o.optString("token").ifBlank { o.optString("csrfToken") }
            } catch (_: Exception) {
                text.trim().takeIf { it.isNotEmpty() && it.length < 500 }.orEmpty()
            }
            val cookies = c.headerFields.entries
                .filter { it.key != null && it.key.equals("Set-Cookie", true) }
                .flatMap { it.value }
                .map { it.substringBefore(';').trim() }
                .filter { it.isNotEmpty() }
            lfToken = token.ifBlank { null }
            lfCookie = cookies.joinToString("; ").ifBlank { null }
            lfAuthAt = System.currentTimeMillis()
        } finally {
            c.disconnect()
        }
    }

    /** POST a LeFrecce con token e cookie; se la sessione è scaduta (401/403) la rinnova una volta. 400 = nessuna soluzione. */
    private fun lfPost(path: String, body: String, retry: Boolean = true): String? {
        lfAuth()
        val c = (URL(LF + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 25000
            requestMethod = "POST"; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", BROWSER_UA)
            setRequestProperty("Accept-Language", "it-IT")
            lfToken?.let { setRequestProperty("x-csrf-token", it) }
            lfCookie?.let { setRequestProperty("Cookie", it) }
        }
        try {
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            if ((code == 401 || code == 403 || code == 419) && retry) {
                c.disconnect()
                lfAuth(force = true)
                return lfPost(path, body, retry = false)
            }
            if (code == 400) return null
            if (code !in 200..299) throw IOException("LeFrecce HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun vtDate(ms: Long): String =
        SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT'Z", Locale.US).apply { timeZone = rome }.format(Date(ms))

    private fun JSONObject.s(k: String): String = if (!has(k) || isNull(k)) "" else optString(k).trim()
    private fun JSONObject.l(k: String): Long = if (!has(k) || isNull(k)) 0L else optLong(k)
    private fun JSONObject.i(k: String): Int = if (!has(k) || isNull(k)) 0 else optInt(k)

    private fun parseIso(s: String): Long {
        if (s.isBlank()) return 0L
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSS", "yyyy-MM-dd'T'HH:mm:ss",
        )
        for (p in patterns) {
            try {
                val f = SimpleDateFormat(p, Locale.US)
                if (!p.contains("XXX")) f.timeZone = rome
                return f.parse(s)?.time ?: continue
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    // ---------------- Stazioni ----------------

    /** Stazioni italiane (ViaggiaTreno) e, in coda, stazioni svizzere dall'orario ufficiale svizzero. */
    fun searchStations(q: String): List<Station> {
        var vtError: Exception? = null
        val ita = try {
            get(VT + "autocompletaStazione/" + enc(q.trim())).lines().mapNotNull { line ->
                val p = line.split("|")
                if (p.size >= 2 && p[1].isNotBlank()) Station(p[0].trim(), p[1].trim()) else null
            }
        } catch (e: Exception) {
            vtError = e; emptyList()
        }
        // Svizzera e ferrovie a rete propria in parallelo, per non rallentare la ricerca
        var ch: List<Station> = emptyList()
        var local: List<Station> = emptyList()
        if (q.trim().length >= 3) {
            val t1 = Thread { ch = SwissLive.searchStations(q) }.apply { start() }
            val t2 = Thread { local = LocalRail.searchStations(q) }.apply { start() }
            t1.join(8000); t2.join(8000)
        }
        // Fermate della rete FerrovieNord che ViaggiaTreno a volte non trova per nome (stessi codici)
        val fn = FnNetwork.search(q).filter { f -> ita.none { it.id == f.id } }
        if (ita.isEmpty() && ch.isEmpty() && local.isEmpty() && fn.isEmpty()) vtError?.let { throw it }
        return ita + fn + local + ch
    }

    fun departures(st: Station, time: Long = System.currentTimeMillis()): List<BoardItem> =
        when {
            SwissLive.isSwiss(st.id) -> SwissLive.departures(st, time)
            LocalRail.isLocal(st.id) -> LocalRail.departures(st, time)
            else -> withItalo(st, time, board("partenze", st, time, departures = true))
        }

    /** Aggiunge le partenze Italo (che ViaggiaTreno non mostra) se la stazione è servita da Italo e si guarda "adesso". */
    private fun withItalo(st: Station, time: Long, vt: List<BoardItem>): List<BoardItem> {
        if (Math.abs(time - System.currentTimeMillis()) > 30 * 60_000L || ItaloLive.codeFor(st.name) == null) return vt
        val have = vt.mapTo(HashSet()) { trainDigits(it.number) }
        val until = (vt.maxOfOrNull { it.time } ?: (time + 90 * 60_000L)).coerceAtLeast(time + 60 * 60_000L)
        val extra = ItaloLive.departures(st).filter { b -> b.number !in have && b.time + b.delay * 60_000L >= time - 5 * 60_000L && b.time <= until }
        return if (extra.isEmpty()) vt else (vt + extra).sortedBy { b -> b.time }
    }

    /**
     * Tutti i prossimi treni: ViaggiaTreno restituisce circa 90 minuti per richiesta,
     * quindi uniamo più finestre consecutive (default 12 ore) togliendo i doppioni.
     */
    fun boardAhead(st: Station, departures: Boolean, from: Long = System.currentTimeMillis(), hours: Int = 12): List<BoardItem> {
        val out = LinkedHashMap<String, BoardItem>()
        var t = from
        val end = from + hours * 3600_000L
        var failures = 0
        while (t < end && failures < 2) {
            val part = try {
                if (departures) departures(st, t) else arrivals(st, t)
            } catch (e: Exception) {
                failures++; emptyList()
            }
            part.forEach { b -> out.putIfAbsent(b.number + "|" + b.originCode + "|" + b.time, b) }
            // la finestra successiva parte dall'ultimo treno trovato (o +80 minuti se vuota)
            val last = part.maxOfOrNull { it.time } ?: 0L
            t = if (last > t + 20 * 60_000L) last else t + 80 * 60_000L
        }
        return out.values.filter { it.time >= from - 10 * 60_000L }.sortedBy { it.time }
    }

    fun arrivals(st: Station, time: Long = System.currentTimeMillis()): List<BoardItem> =
        if (SwissLive.isSwiss(st.id) || LocalRail.isLocal(st.id)) throw IOException(I18n.tr("Per questa stazione sono disponibili solo le partenze", "Only departures are available for this station"))
        else board("arrivi", st, time, departures = false)

    /** Tabellone grezzo di ViaggiaTreno ("partenze" o "arrivi"), per le statistiche raccolte dall'app. */
    fun rawBoard(kind: String, stationId: String, time: Long): JSONArray = JSONArray(get(VT + kind + "/" + stationId + "/" + enc(vtDate(time))))

    private fun board(kind: String, st: Station, time: Long, departures: Boolean): List<BoardItem> {
        val a = JSONArray(get(VT + kind + "/" + st.id + "/" + enc(vtDate(time))))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val comp = o.s("compNumeroTreno")
            val cat = comp.split(" ").firstOrNull()?.takeIf { comp.contains(" ") } ?: o.s("categoria")
            val suffix = if (departures) "Partenza" else "Arrivo"
            val eff = o.s("binarioEffettivo${suffix}Descrizione")
            val prog = o.s("binarioProgrammato${suffix}Descrizione")
            BoardItem(
                number = o.s("numeroTreno"),
                category = cat,
                otherEnd = if (departures) o.s("destinazione") else o.s("origine"),
                time = if (departures) o.l("orarioPartenza") else o.l("orarioArrivo"),
                delay = o.i("ritardo"),
                platform = eff.ifBlank { prog },
                platformConfirmed = eff.isNotBlank(),
                originCode = o.s("codOrigine"),
                departureDate = o.l("dataPartenzaTreno"),
                inStation = o.optBoolean("inStazione"),
                schedPlatform = prog,
                realPlatform = eff,
                operator = Operators.fromClientCode(o.i("codiceCliente"), cat, comp),
            )
        }
    }

    // ---------------- Treni ----------------

    /** Cerca un treno per numero. Può restituire più corse con lo stesso numero (origini diverse). */
    /**
     * Solo il numero del treno: LeFrecce per i regionali dà "S50 TRENORD 25592" o "RE SBB 25591",
     * mentre ViaggiaTreno vuole "25592". Prende l'ultimo gruppo di cifre (da 2 a 6).
     */
    fun trainDigits(n: String): String =
        Regex("\\d{2,6}").findAll(n).lastOrNull()?.value ?: n.trim()

    /** Cerca un treno per numero su ViaggiaTreno e, per i numeri tipo Italo (8xxx, 9xxx), anche su Italo. */
    fun trainLookup(number: String): List<TrainRef> {
        val vt = try {
            vtLookup(number)
        } catch (e: IOException) {
            if (!ItaloLive.looksItalo(number)) throw e
            emptyList()
        }
        return if (ItaloLive.looksItalo(number)) vt + ItaloLive.lookup(number) else vt
    }

    private fun vtLookup(number: String): List<TrainRef> =
        get(VT + "cercaNumeroTrenoTrenoAutocomplete/" + enc(trainDigits(number))).lines().mapNotNull { line ->
            val p = line.split("|")
            if (p.size < 2) return@mapNotNull null
            val parts = p[1].split("-")
            if (parts.size < 2) return@mapNotNull null
            val date = parts.getOrNull(2)?.toLongOrNull() ?: Fmt.midnight()
            TrainRef(parts[0].trim(), parts[1].trim(), date, p[0].trim())
        }

    /** Completa un riferimento senza data/origine (es. preferiti) con la corsa di oggi. */
    fun resolve(ref: TrainRef): TrainRef {
        if (ref.originCode.isNotBlank() && ref.date > 0) return ref.copy(number = trainDigits(ref.number))
        val list = trainLookup(ref.number)
        val match = list.firstOrNull { it.originCode == ref.originCode } ?: list.firstOrNull()
            ?: throw IOException("Treno ${ref.number} non trovato")
        return match.copy(label = ref.label.ifBlank { match.label })
    }

    fun status(ref: TrainRef): TrainStatus {
        if (ref.originCode.startsWith(SwissLive.PREFIX + "|")) return SwissLive.status(ref)
        if (ref.originCode.startsWith(LocalRail.PREFIX + "|")) return LocalRail.status(ref)
        if (ItaloLive.isItalo(ref)) return ItaloLive.status(ref)
        val r = resolve(ref)
        val o = JSONObject(get(VT + "andamentoTreno/" + r.originCode + "/" + r.number + "/" + r.date))
        val f = o.optJSONArray("fermate") ?: JSONArray()
        val stops = (0 until f.length()).map { i ->
            val s = f.getJSONObject(i)
            val effP = s.s("binarioEffettivoPartenzaDescrizione")
            val effA = s.s("binarioEffettivoArrivoDescrizione")
            val progP = s.s("binarioProgrammatoPartenzaDescrizione")
            val progA = s.s("binarioProgrammatoArrivoDescrizione")
            val eff = effP.ifBlank { effA }
            val prog = progP.ifBlank { progA }
            TrainStop(
                name = s.s("stazione"),
                id = s.s("id"),
                schedArr = s.l("arrivo_teorico"),
                schedDep = s.l("partenza_teorica"),
                realArr = s.l("arrivoReale"),
                realDep = s.l("partenzaReale"),
                delay = s.i("ritardo"),
                platform = eff.ifBlank { prog },
                platformChanged = eff.isNotBlank() && prog.isNotBlank() && eff != prog,
                platformConfirmed = eff.isNotBlank(),
                schedPlatform = prog,
                realPlatform = eff,
            )
        }
        val comp = o.s("compNumeroTreno")
        return TrainStatus(
            number = o.s("numeroTreno").ifBlank { r.number },
            category = o.s("categoria").ifBlank { comp.split(" ").firstOrNull() ?: "" },
            origin = o.s("origine"),
            destination = o.s("destinazione"),
            originCode = r.originCode,
            date = r.date,
            delay = o.i("ritardo"),
            lastStation = o.s("stazioneUltimoRilevamento").takeIf { it != "--" } ?: "",
            lastTime = o.l("oraUltimoRilevamento"),
            cancelled = o.optBoolean("trenoSoppresso") || o.i("provvedimento") == 1,
            stops = stops,
            info = listOf(o.s("subTitle"), o.s("compProvvedimento"))
                .filter { it.isNotBlank() && it != "null" }.joinToString("\n"),
            operator = Operators.fromClientCode(o.i("codiceCliente"), o.s("categoria"), comp),
        )
    }

    // ---------------- Soluzioni di viaggio ----------------

    /**
     * Soluzioni di viaggio. maxChanges = -1 → nessun limite. excluded = categorie da escludere (es. "FR", "BUS").
     */
    fun solutions(
        from: Station, to: Station, time: Long, filter: SearchFilter,
        maxChanges: Int = -1, excluded: Set<String> = emptySet(),
    ): List<Solution> {
        // Da o per la Svizzera: orario ufficiale svizzero (comprende FFS, TILO, BLS, SOB e i treni lombardi)
        if (SwissLive.isSwiss(from.id) || SwissLive.isSwiss(to.id)) return SwissLive.solutions(from, to, time)
        // Con una ferrovia a rete propria (EAV, ARST, Ferrotramviaria…): orari ufficiali raccolti da Transitous
        if (LocalRail.isLocal(from.id) || LocalRail.isLocal(to.id)) return LocalRail.solutions(from, to, time)
        val directOnly = maxChanges == 0
        var lfError: Exception? = null
        val primary = try {
            lefrecce(from, to, time, filter, directOnly)
        } catch (e: Exception) {
            lfError = e
            emptyList()
        }
        // Riserva 1: orari ufficiali GTFS (Trenord, anche rete FerrovieNord) tramite Transitous
        val gtfs = if (primary.isEmpty()) {
            try {
                LocalRail.solutions(from, to, time)
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()
        // Riserva 2: il vecchio servizio ViaggiaTreno (oggi spesso non disponibile).
        val list = primary.ifEmpty { gtfs }.ifEmpty {
            try {
                viaggiaTrenoSolutions(from, to, time, filter, directOnly)
            } catch (e: Exception) {
                lfError?.let { throw IOException(it.message ?: "LeFrecce non raggiungibile", it) }
                emptyList()
            }
        }
        return list.filter { sol ->
            (maxChanges < 0 || sol.changes <= maxChanges) &&
                sol.legs.none { l -> excluded.any { ex -> l.category.equals(ex, true) } }
        }
    }

    private val lfIds = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun norm(n: String) = n.lowercase(Locale.ITALY).replace(Regex("[^a-z0-9àèéìòù]+"), " ").trim()

    /**
     * Id LeFrecce della stazione. Per le stazioni RFI è 830000000 + codice ViaggiaTreno, ma per la rete FerrovieNord
     * (Milano Cadorna, Saronno, Varese Nord, Como Lago, Novara Nord, Malpensa…) è diverso (es. Varese Nord 830025251):
     * lo cerchiamo per nome e lo teniamo in memoria.
     */
    fun lfId(st: Station): Long {
        lfIds[st.id]?.let { return it }
        val guess = st.lefrecceId
        val found = try {
            val a = JSONArray(get(LF + "locations/search?name=" + enc(st.name) + "&limit=10"))
            val list = (0 until a.length()).map { a.getJSONObject(it) }
            list.firstOrNull { it.optLong("id") == guess }?.optLong("id")
                ?: list.firstOrNull { norm(it.optString("name")) == norm(st.name) }?.optLong("id")
                ?: list.firstOrNull { !it.optBoolean("multistation") }?.optLong("id")
        } catch (e: Exception) {
            null
        }
        val id = found?.takeIf { it > 0 } ?: guess
        if (found != null) lfIds[st.id] = id
        return id
    }

    private fun lefrecce(from: Station, to: Station, time: Long, filter: SearchFilter, directOnly: Boolean): List<Solution> {
        val t = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).apply { timeZone = rome }.format(Date(time))
        val body = JSONObject()
            .put("departureLocationId", lfId(from))
            .put("arrivalLocationId", lfId(to))
            .put("departureTime", t)
            .put("adults", 1)
            .put("children", 0)
            .put(
                "criteria", JSONObject()
                    .put("frecceOnly", filter == SearchFilter.FRECCE)
                    .put("regionalOnly", filter == SearchFilter.REGIONAL)
                    .put("intercityOnly", false)
                    .put("noChanges", directOnly)
                    .put("order", "DEPARTURE_DATE")
                    .put("limit", if (filter == SearchFilter.ALL) 30 else 10)
                    .put("offset", 0),
            )
            .put("advancedSearchRequest", JSONObject().put("bestFare", false).put("bikeFilter", false))
        val text = lfPost("ticket/solutions", body.toString()) ?: return emptyList()
        val root = JSONObject(text)
        val arr = root.optJSONArray("solutions") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val wrap = arr.optJSONObject(i) ?: return@mapNotNull null
            val s = wrap.optJSONObject("solution") ?: wrap
            val dep = parseIso(s.s("departureTime"))
            val arrT = parseIso(s.s("arrivalTime"))
            val nodes = s.optJSONArray("nodes") ?: wrap.optJSONArray("nodes")
            val trains = s.optJSONArray("trains") ?: JSONArray()
            val legs = if (nodes != null && nodes.length() > 0) {
                (0 until nodes.length()).map { k ->
                    val n = nodes.getJSONObject(k)
                    val tr = n.optJSONObject("train") ?: JSONObject()
                    Leg(
                        number = tr.s("description").ifBlank { tr.s("name") },
                        category = tr.s("acronym").ifBlank { tr.s("trainCategory") },
                        from = n.s("origin"), to = n.s("destination"),
                        dep = parseIso(n.s("departureTime")), arr = parseIso(n.s("arrivalTime")),
                    )
                }
            } else {
                (0 until trains.length()).map { k ->
                    val tr = trains.getJSONObject(k)
                    Leg(
                        number = tr.s("description").ifBlank { tr.s("name") },
                        category = tr.s("acronym").ifBlank { tr.s("trainCategory") },
                    )
                }
            }.map { l ->
                // Un treno senza tratte intermedie copre l'intero viaggio
                if (l.from.isBlank() && trains.length() == 1) l.copy(from = s.s("origin"), to = s.s("destination"), dep = dep, arr = arrT) else l
            }
            val priceObj = s.optJSONObject("price")
            val price = priceObj?.optDouble("amount")?.takeIf { !it.isNaN() }
            Solution(
                from = s.s("origin").ifBlank { from.name },
                to = s.s("destination").ifBlank { to.name },
                dep = dep, arr = arrT,
                duration = s.s("duration").ifBlank { Fmt.duration(dep, arrT) },
                price = price,
                legs = legs,
            )
        }
            // Lo stesso treno a volte arriva due volte (es. TILO: "RE SBB 25591" e "S50 TRENORD 25591"):
            // diventa una sola riga con entrambe le sigle e il numero una volta: "RE SBB / SU S50 TRENORD 25591"
            .groupBy { sol -> "${sol.dep}|${sol.arr}|" + sol.legs.joinToString(",") { trainDigits(it.number) } }
            .values.map { same -> if (same.size == 1) same[0] else mergeSame(same) }
    }

    /** Unisce soluzioni identiche che differiscono solo per la sigla del treno. */
    private fun mergeSame(same: List<Solution>): Solution {
        val first = same[0]
        val legs = first.legs.mapIndexed { i, leg ->
            val titles = same.mapNotNull { it.legs.getOrNull(i)?.title }.distinct()
            if (titles.size < 2) return@mapIndexed leg
            val digits = trainDigits(leg.number)
            val names = titles.map { it.removeSuffix(digits).trim() }.filter { it.isNotBlank() }.distinct()
            val merged = names.joinToString(" / ") + " " + digits
            leg.copy(number = merged.removePrefix(leg.category).trim())
        }
        return first.copy(legs = legs, price = same.mapNotNull { it.price }.minOrNull() ?: first.price)
    }

    private fun viaggiaTrenoSolutions(from: Station, to: Station, time: Long, filter: SearchFilter, directOnly: Boolean): List<Solution> {
        val t = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = rome }.format(Date(time))
        val root = JSONObject(get(VT + "soluzioniViaggioNew/${from.num}/${to.num}/$t"))
        val arr = root.optJSONArray("soluzioni") ?: return emptyList()
        val high = setOf("FR", "FA", "FB", "ITA", "EC", "IC")
        val reg = setOf("REG", "RV", "R", "S", "MET")
        return (0 until arr.length()).mapNotNull { i ->
            val s = arr.getJSONObject(i)
            val v = s.optJSONArray("vehicles") ?: return@mapNotNull null
            val legs = (0 until v.length()).map { k ->
                val x = v.getJSONObject(k)
                Leg(
                    number = x.s("numeroTreno"),
                    category = x.s("categoriaDescrizione").ifBlank { x.s("categoria") },
                    from = x.s("origine"), to = x.s("destinazione"),
                    dep = parseIso(x.s("orarioPartenza")), arr = parseIso(x.s("orarioArrivo")),
                )
            }
            if (legs.isEmpty()) return@mapNotNull null
            Solution(from.name, to.name, legs.first().dep, legs.last().arr,
                s.s("durata").ifBlank { Fmt.duration(legs.first().dep, legs.last().arr) }, null, legs)
        }.filter { sol ->
            val cats = sol.legs.map { it.category.uppercase() }
            when (filter) {
                SearchFilter.FRECCE -> cats.all { c -> high.any { c.startsWith(it) } }
                SearchFilter.REGIONAL -> cats.all { c -> reg.any { c.startsWith(it) } }
                else -> true
            } && (!directOnly || sol.legs.size == 1)
        }
    }

    // ---------------- Trenord: affollamento ----------------

    /**
     * Percentuale di affollamento stimata da Trenord (0–100), se disponibile.
     * Servizio non documentato: in caso di errore restituisce null e l'app mostra il link al sito Trenord.
     */
    fun trenordCrowding(number: String): Int? = try {
        val day = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = rome }.format(Date())
        val body = get("https://admin.trenord.it/store-management-api/mia/train/" + enc(number) + "?journey_date=" + day)
        findCrowding(if (body.trim().startsWith("[")) JSONArray(body) else JSONObject(body))
    } catch (e: Exception) {
        null
    }

    private fun findCrowding(x: Any?): Int? {
        when (x) {
            is JSONObject -> {
                x.optJSONObject("crowding")?.let { c ->
                    val p = c.optDouble("percentage")
                    if (!p.isNaN()) return p.toInt().coerceIn(0, 100)
                }
                for (k in x.keys()) findCrowding(x.opt(k))?.let { return it }
            }
            is JSONArray -> for (i in 0 until x.length()) findCrowding(x.opt(i))?.let { return it }
        }
        return null
    }

    // ---------------- Coordinate stazioni / mappa ----------------

    fun stationCoord(store: Store, id: String): Pair<Double, Double>? {
        store.coord(id)?.let { return it }
        if (SwissLive.isSwiss(id)) return SwissLive.coord(id)?.also { store.setCoord(id, it) }
        if (LocalRail.isLocal(id)) return LocalRail.coord(id)?.also { store.setCoord(id, it) }
        // Rete FerrovieNord: ViaggiaTreno non ha le coordinate di Varese Nord, Como Lago, Novara Nord…
        FnNetwork.coord(id)?.let { return it }
        return try {
            val reg = get(VT + "regione/$id").trim()
            val o = JSONObject(get(VT + "dettaglioStazione/$id/$reg"))
            val lat = o.optDouble("lat"); val lon = o.optDouble("lon")
            if (lat.isNaN() || lon.isNaN() || lat == 0.0) null else (lat to lon).also { store.setCoord(id, it) }
        } catch (e: Exception) {
            null
        }
    }

    data class GeoStation(val station: Station, val lat: Double, val lon: Double)

    /** Elenco completo stazioni con coordinate (scaricato una volta e salvato in memoria). */
    fun allStations(ctx: Context): List<GeoStation> {
        val f = File(ctx.filesDir, "stations.json")
        val text = if (f.exists() && f.length() > 1000) f.readText() else {
            val out = JSONArray()
            val seen = HashSet<String>()
            for (reg in 0..22) {
                try {
                    val a = JSONArray(get(VT + "elencoStazioni/$reg"))
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        val id = o.s("codiceStazione")
                        if (id.isBlank() || !seen.add(id)) continue
                        val name = o.optJSONObject("localita")?.s("nomeLungo")?.ifBlank { null } ?: o.s("nomeCitta")
                        out.put(JSONObject().put("id", id).put("name", name).put("lat", o.optDouble("lat")).put("lon", o.optDouble("lon")))
                    }
                } catch (_: Exception) {
                }
            }
            if (out.length() == 0) throw IOException("Elenco stazioni non disponibile")
            out.toString().also { f.writeText(it) }
        }
        val a = JSONArray(text)
        val base = (0 until a.length()).mapNotNull { i ->
            val o = a.getJSONObject(i)
            val lat = o.optDouble("lat"); val lon = o.optDouble("lon")
            if (lat.isNaN() || lon.isNaN() || lat == 0.0) null
            else GeoStation(Station(o.optString("name"), o.optString("id")), lat, lon)
        }
        // Più le stazioni della rete FerrovieNord che l'elenco di ViaggiaTreno non contiene
        FnNetwork.ensure(ctx)
        val have = base.mapTo(HashSet()) { it.station.id }
        return base + FnNetwork.stations.filter { it.station.id !in have }
    }

    // ---------------- Accessibilità (RFI) ----------------

    data class AccessIssue(val station: String, val change: String, val endDate: String)

    /**
     * Variazioni di accessibilità (ascensori/rampe fuori servizio > 24h) pubblicate da RFI.
     * La pagina è una tabella HTML: la leggiamo e filtriamo per stazione.
     */
    fun rfiAccessIssues(stationName: String): List<AccessIssue> {
        val html = get("https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/stato-ascensori-e-rampe-di-accesso-ai-binari.html")
        val row = Regex("<tr[^>]*>(.*?)</tr>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val cell = Regex("<t[dh][^>]*>(.*?)</t[dh]>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val tag = Regex("<[^>]+>")
        val key = stationName.lowercase().replace(Regex("[^a-z0-9 ]"), " ").split(" ").filter { it.length > 2 }
        return row.findAll(html).mapNotNull { m ->
            val cells = cell.findAll(m.groupValues[1]).map {
                tag.replace(it.groupValues[1], " ").replace("&nbsp;", " ").replace(Regex("\\s+"), " ").trim()
            }.toList()
            if (cells.size < 2 || cells[0].equals("NOME STAZIONE", true)) null
            else AccessIssue(cells[0], cells[1], cells.getOrElse(2) { "" })
        }.filter { a -> key.isNotEmpty() && key.all { a.station.lowercase().contains(it) } }.toList()
    }

    // ---------------- News / infomobilità ----------------

    fun news(): List<NewsItem> {
        val a = JSONArray(get(VT + "news/0/it"))
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            NewsItem(o.s("titolo"), o.s("testo"), o.l("data"))
        }
    }
}
