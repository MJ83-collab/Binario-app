package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Puntualità dei treni FFS/SBB dai dati aperti "Ist-Daten SBB" (data.sbb.ch): orari effettivi di ogni fermata
 * del giorno precedente. Le FFS pubblicano solo l'ultimo giorno, quindi l'app raccoglie un giorno alla volta
 * e calcola la media degli ultimi 30 giorni raccolti.
 * Nota: per le FFS "puntuale" = meno di 3 minuti di ritardo (in Italia la soglia usata è 5 minuti).
 */
object SwissStats {
    private const val API = "https://data.sbb.ch/api/explore/v2.1/catalog/datasets/ist-daten-sbb/records"
    const val SOURCE = "FFS/SBB · open data Ist-Daten (data.sbb.ch)"
    const val SOURCE_URL = "https://data.sbb.ch/explore/dataset/ist-daten-sbb/"
    private const val PREF = "swiss_punct"

    /** S-Bahn, regionali, RegioExpress, TER francesi e treni panoramici. */
    private val REGIONAL = setOf("S", "R", "RE", "RB", "TER", "PE", "SN")

    /** InterRegio, InterCity, EuroCity, ICE, Railjet, TGV, Nightjet. */
    private val LONG = setOf("IC", "IR", "EC", "ICE", "NJ", "RJ", "RJX", "TGV", "EN")

    private fun query(select: String, where: String): JSONArray {
        val url = API + "?select=" + URLEncoder.encode(select, "UTF-8") + "&group_by=verkehrsmittel_text&limit=100&where=" +
            URLEncoder.encode(where, "UTF-8")
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 20000
            setRequestProperty("User-Agent", "Binario/2.3 (Android; com.binario.treni)")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optJSONArray("results") ?: JSONArray()
        } finally {
            c.disconnect()
        }
    }

    private fun counts(a: JSONArray): Map<String, Int> =
        (0 until a.length()).associate { i -> a.getJSONObject(i).let { it.optString("verkehrsmittel_text") to it.optInt("n") } }

    /** Scarica i conteggi dell'ultimo giorno pubblicato, se non sono già stati salvati. Restituisce true se ha aggiunto un giorno. */
    fun collect(ctx: Context): Boolean {
        val prefs = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE)
        // Al massimo un controllo ogni 3 ore (il lavoro in background gira ogni 15 minuti)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong(PREF + "_at", 0L) < 3 * 3600_000L) return false
        prefs.edit().putLong(PREF + "_at", now).apply()
        val store = try { JSONObject(prefs.getString(PREF, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val dayRows = query("verkehrsmittel_text, count(*) as n, max(betriebstag) as d", "an_prognose_status=\"REAL\" and faellt_aus_tf=false")
        val day = (0 until dayRows.length()).map { dayRows.getJSONObject(it).optString("d").take(10) }.maxOrNull() ?: return false
        if (day.isBlank() || store.has(day)) return false
        val obs = counts(dayRows)
        val onTime = counts(query("verkehrsmittel_text, count(*) as n",
            "an_prognose_status=\"REAL\" and faellt_aus_tf=false and ankunftsverspatung=\"false\""))
        val cancelled = counts(query("verkehrsmittel_text, count(*) as n", "faellt_aus_tf=true"))
        val o = JSONObject()
        (obs.keys + cancelled.keys).forEach { k ->
            o.put(k, JSONArray().put(obs[k] ?: 0).put(onTime[k] ?: 0).put(cancelled[k] ?: 0))
        }
        store.put(day, o)
        // Si tengono gli ultimi 40 giorni
        val keys = store.keys().asSequence().toList().sorted()
        keys.dropLast(40).forEach { store.remove(it) }
        prefs.edit().putString(PREF, store.toString()).apply()
        return true
    }

    data class Summary(val days: Int, val first: String, val last: String, val rows: Map<Segment, PunctRow>)

    /** Media degli ultimi [maxDays] giorni raccolti, per regionali e lunga percorrenza. */
    fun summary(ctx: Context, maxDays: Int = 30): Summary? {
        val store = try {
            JSONObject(ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).getString(PREF, "{}") ?: "{}")
        } catch (e: Exception) {
            return null
        }
        val days = store.keys().asSequence().toList().sorted().takeLast(maxDays)
        if (days.isEmpty()) return null
        val acc = HashMap<Segment, IntArray>()
        days.forEach { d ->
            val o = store.getJSONObject(d)
            o.keys().forEach { k ->
                val seg = when (k) {
                    in REGIONAL -> Segment.REGIONAL
                    in LONG -> Segment.INTERCITY
                    else -> null
                } ?: return@forEach
                val a = o.getJSONArray(k)
                val t = acc.getOrPut(seg) { IntArray(3) }
                t[0] += a.optInt(0); t[1] += a.optInt(1); t[2] += a.optInt(2)
            }
        }
        val rows = acc.mapValues { (seg, t) ->
            val name = if (seg == Segment.REGIONAL) I18n.tr("FFS · S-Bahn e regionali", "SBB · S-Bahn and regional")
            else I18n.tr("FFS · InterRegio, InterCity, EuroCity", "SBB · InterRegio, InterCity, EuroCity")
            PunctRow("sbb", name, "", if (t[0] == 0) 0.0 else t[1] * 100.0 / t[0], 0.0, t[0] + t[2], t[2], t[1], operator = "sbb")
        }
        return Summary(days.size, days.first(), days.last(), rows)
    }
}
