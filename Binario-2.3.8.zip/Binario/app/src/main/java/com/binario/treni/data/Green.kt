package com.binario.treni.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Profilo del pendolare per il calcolo "Quanto sei green". */
data class GreenProfile(
    val from: Station,
    val to: Station,
    val trainOut: String = "",
    val trainBack: String = "",
    val days: Set<Int> = setOf(2, 3, 4, 5, 6), // Calendar.MONDAY..FRIDAY
    val fuel: String = "benzina", // benzina, gasolio, gpl, metano, elettrica
    val consumption: Double = 6.5, // l/100 km (o kWh/100 km per elettrica)
    val parking: Double = 0.0, // € al giorno
    val trainMonthly: Double = 0.0, // € abbonamento mensile
    val passengers: Int = 1,
) {
    fun toJson(): JSONObject = JSONObject().put("from", from.toJson()).put("to", to.toJson())
        .put("to_", trainOut).put("tb", trainBack).put("days", JSONArray(days.toList()))
        .put("fuel", fuel).put("cons", consumption).put("park", parking).put("pass", trainMonthly).put("pp", passengers)

    companion object {
        fun from(o: JSONObject): GreenProfile {
            val d = o.optJSONArray("days")
            return GreenProfile(
                Station.from(o.getJSONObject("from")), Station.from(o.getJSONObject("to")),
                o.optString("to_"), o.optString("tb"),
                if (d == null) setOf(2, 3, 4, 5, 6) else (0 until d.length()).map { d.getInt(it) }.toSet(),
                o.optString("fuel", "benzina"), o.optDouble("cons", 6.5), o.optDouble("park", 0.0),
                o.optDouble("pass", 0.0), o.optInt("pp", 1),
            )
        }
    }
}

/** Una giornata registrata. */
data class GreenDay(val date: String, val delayOut: Int?, val delayBack: Int?) {
    fun toJson(): JSONObject = JSONObject().put("d", date).put("o", delayOut ?: -999).put("b", delayBack ?: -999)

    companion object {
        fun from(o: JSONObject) = GreenDay(
            o.optString("d"),
            o.optInt("o", -999).takeIf { it != -999 },
            o.optInt("b", -999).takeIf { it != -999 },
        )
    }
}

/** Dati del percorso in auto (OSRM) e in treno. */
data class RoadInfo(val km: Double, val minutes: Int, val tollKm: Double)

data class GreenResult(
    val trainKm: Double,
    val car: RoadInfo,
    val carMinutesTraffic: Int,
    val trainMinutes: Int,
    val avgDelay: Double,
    val co2CarKg: Double,
    val co2TrainKg: Double,
    val fuelEuro: Double,
    val tollEuro: Double,
    val parkingEuro: Double,
    val trainEuro: Double,
    val fuelPrice: Double,
    val fuelPriceSource: String,
) {
    val co2SavedKg: Double get() = co2CarKg - co2TrainKg
    val carEuro: Double get() = fuelEuro + tollEuro + parkingEuro
    val savedEuro: Double get() = carEuro - trainEuro
}

/**
 * Calcoli "green". Fattori di emissione (stime, fonte ISPRA/EEA):
 * auto media a benzina ~ 2,31 kg CO₂ per litro, gasolio ~ 2,65 kg/l, GPL ~ 1,64 kg/l, metano ~ 2,75 kg/kg,
 * auto elettrica ~ 0,26 kg/kWh (mix elettrico italiano); treno regionale ~ 0,035 kg CO₂ per passeggero-km.
 */
object GreenCalc {
    private const val TRAIN_KG_PER_PKM = 0.035
    private val CO2_PER_UNIT = mapOf("benzina" to 2.31, "gasolio" to 2.65, "gpl" to 1.64, "metano" to 2.75, "elettrica" to 0.26)
    private val FALLBACK_PRICE = mapOf("benzina" to 1.80, "gasolio" to 1.70, "gpl" to 0.72, "metano" to 1.40, "elettrica" to 0.60)

    /** Pedaggio medio autostradale per km (classe A, stima). */
    const val TOLL_EURO_PER_KM = 0.075

    /** Fattore traffico nelle ore di punta (stima, l'orario svizzero/OSRM non ha il traffico in tempo reale). */
    const val RUSH_FACTOR = 1.35

    private fun get(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 60000
            setRequestProperty("User-Agent", "Binario/2.3 (Android)")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun haversineKm(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
        val r = 6371.0
        val dLat = Math.toRadians(b.first - a.first)
        val dLon = Math.toRadians(b.second - a.second)
        val h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(Math.toRadians(a.first)) * Math.cos(Math.toRadians(b.first)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
        return r * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h))
    }

    /** Percorso stradale da OpenStreetMap (servizio OSRM): km, minuti senza traffico, km su tratti a pedaggio. */
    fun road(a: Pair<Double, Double>, b: Pair<Double, Double>): RoadInfo {
        val url = "https://router.project-osrm.org/route/v1/driving/${a.second},${a.first};${b.second},${b.first}?overview=false&steps=true"
        val o = JSONObject(get(url))
        val route = o.optJSONArray("routes")?.optJSONObject(0) ?: throw IOException("Percorso non trovato")
        var toll = 0.0
        route.optJSONArray("legs")?.let { legs ->
            for (i in 0 until legs.length()) {
                val steps = legs.getJSONObject(i).optJSONArray("steps") ?: continue
                for (k in 0 until steps.length()) {
                    val st = steps.getJSONObject(k)
                    val inter = st.optJSONArray("intersections")
                    var isToll = false
                    if (inter != null) for (j in 0 until inter.length()) {
                        val cl = inter.getJSONObject(j).optJSONArray("classes") ?: continue
                        for (q in 0 until cl.length()) if (cl.optString(q) == "toll") isToll = true
                    }
                    if (isToll) toll += st.optDouble("distance", 0.0) / 1000.0
                }
            }
        }
        return RoadInfo(route.optDouble("distance") / 1000.0, (route.optDouble("duration") / 60.0).toInt(), toll)
    }

    /**
     * Prezzo medio nazionale "self" del carburante dal file open data del Ministero (MIMIT, aggiornato ogni mattina).
     * Il file è grande: lo leggiamo una volta al giorno e salviamo il risultato.
     */
    fun fuelPrice(ctx: Context, fuel: String): Pair<Double, String> {
        if (fuel == "elettrica") return (FALLBACK_PRICE["elettrica"] ?: 0.6) to "Stima ricarica domestica/pubblica"
        val p = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE)
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val cached = p.getString("fuel_$fuel", null)
        if (cached != null && cached.startsWith(today)) {
            cached.substringAfter('|').toDoubleOrNull()?.let { return it to "Prezzo medio self, MIMIT (oggi)" }
        }
        return try {
            val csv = get("https://www.mimit.gov.it/images/exportCSV/prezzo_alle_8.csv")
            val key = when (fuel) {
                "gasolio" -> "gasolio"
                "gpl" -> "gpl"
                "metano" -> "metano"
                else -> "benzina"
            }
            var sum = 0.0; var n = 0
            csv.lineSequence().drop(2).forEach { line ->
                val c = line.split('|', ';')
                if (c.size >= 4) {
                    val desc = c[1].lowercase()
                    val price = c[2].replace(',', '.').toDoubleOrNull()
                    val self = c[3].trim() == "1"
                    val match = if (key == "benzina") desc == "benzina" else desc.startsWith(key)
                    if (match && self && price != null && price in 0.3..4.0) {
                        sum += price; n++
                    }
                }
            }
            if (n < 50) throw IOException("Dati insufficienti")
            val avg = sum / n
            p.edit().putString("fuel_$fuel", "$today|$avg").apply()
            avg to "Prezzo medio self, MIMIT (oggi, $n impianti)"
        } catch (e: Exception) {
            val old = cached?.substringAfter('|')?.toDoubleOrNull()
            if (old != null) old to "Prezzo medio MIMIT (ultimo disponibile)"
            else (FALLBACK_PRICE[fuel] ?: 1.8) to "Stima (dati MIMIT non raggiungibili)"
        }
    }

    /** Calcolo per un giorno di andata e ritorno. */
    fun compute(ctx: Context, store: Store, pr: GreenProfile, log: List<GreenDay>): GreenResult {
        val a = Api.stationCoord(store, pr.from.id) ?: throw IOException("Coordinate di ${pr.from.name} non disponibili")
        val b = Api.stationCoord(store, pr.to.id) ?: throw IOException("Coordinate di ${pr.to.name} non disponibili")
        val trainKm = haversineKm(a, b) * 1.25 // i binari non vanno in linea retta
        val road = try {
            road(a, b)
        } catch (e: Exception) {
            val km = haversineKm(a, b) * 1.3
            RoadInfo(km, (km / 50.0 * 60).toInt(), 0.0)
        }
        // Tempo treno: dalla prossima soluzione, altrimenti stima a 55 km/h
        val trainMin = try {
            Api.solutions(pr.from, pr.to, System.currentTimeMillis(), SearchFilter.BEST).firstOrNull()?.let { ((it.arr - it.dep) / 60000).toInt() }
        } catch (e: Exception) {
            null
        } ?: (trainKm / 55.0 * 60).toInt()
        val delays = log.flatMap { listOfNotNull(it.delayOut, it.delayBack) }
        val avgDelay = if (delays.isEmpty()) 0.0 else delays.average()

        val (price, src) = fuelPrice(ctx, pr.fuel)
        val dayKm = road.km * 2
        val units = dayKm * pr.consumption / 100.0
        val pp = pr.passengers.coerceAtLeast(1)
        val co2Car = units * (CO2_PER_UNIT[pr.fuel] ?: 2.31) / pp
        val co2Train = trainKm * 2 * TRAIN_KG_PER_PKM
        val fuelEuro = units * price / pp
        val toll = road.tollKm * 2 * TOLL_EURO_PER_KM / pp
        val workDays = (pr.days.size * 52.0 / 12.0).coerceAtLeast(1.0)
        val trainDay = if (pr.trainMonthly > 0) pr.trainMonthly / workDays else 0.0
        return GreenResult(
            trainKm, road, (road.minutes * RUSH_FACTOR).toInt(), trainMin, avgDelay,
            co2Car, co2Train, fuelEuro, toll, pr.parking / pp, trainDay, price, src,
        )
    }

    // ---------------- Registro giornaliero ----------------

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE)

    fun profile(ctx: Context): GreenProfile? = prefs(ctx).getString("green_profile", null)?.let {
        try {
            GreenProfile.from(JSONObject(it))
        } catch (e: Exception) {
            null
        }
    }

    fun saveProfile(ctx: Context, p: GreenProfile) {
        prefs(ctx).edit().putString("green_profile", p.toJson().toString()).apply()
    }

    fun log(ctx: Context): List<GreenDay> = try {
        val a = JSONArray(prefs(ctx).getString("green_log", "[]"))
        (0 until a.length()).map { GreenDay.from(a.getJSONObject(it)) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun saveLog(ctx: Context, l: List<GreenDay>) {
        val a = JSONArray()
        l.takeLast(800).forEach { a.put(it.toJson()) }
        prefs(ctx).edit().putString("green_log", a.toString()).apply()
    }

    fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("Europe/Rome") }.format(Date())

    fun setDay(ctx: Context, day: GreenDay) = saveLog(ctx, log(ctx).filter { it.date != day.date } + day)
    fun removeDay(ctx: Context, date: String) = saveLog(ctx, log(ctx).filter { it.date != date })

    /** Ritardo all'arrivo (minuti) di un treno oggi, dall'andamento ViaggiaTreno. */
    private fun arrivalDelay(number: String, stationName: String): Int? = try {
        if (number.isBlank()) null else {
            val st = Api.status(TrainRef(number))
            val stop = st.stops.firstOrNull { it.name.equals(stationName, true) } ?: st.stops.lastOrNull()
            if (stop == null) st.delay else if (stop.realArr > 0 && stop.schedArr > 0) ((stop.realArr - stop.schedArr) / 60000).toInt() else stop.delay
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Registrazione automatica: nei giorni di viaggio, dopo le 21, salva i ritardi di andata e ritorno.
     * Chiamata dal controllo periodico in background.
     */
    fun autoLog(ctx: Context) {
        val pr = profile(ctx) ?: return
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Europe/Rome"))
        if (cal.get(Calendar.DAY_OF_WEEK) !in pr.days || cal.get(Calendar.HOUR_OF_DAY) < 21) return
        val key = todayKey()
        if (log(ctx).any { it.date == key }) return
        setDay(ctx, GreenDay(key, arrivalDelay(pr.trainOut, pr.to.name), arrivalDelay(pr.trainBack, pr.from.name)))
    }
}
