package com.binario.treni.ui

import android.content.Intent
import android.speech.RecognizerIntent
import android.view.accessibility.AccessibilityManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.I18n
import com.binario.treni.data.Store
import com.binario.treni.data.tx
import com.binario.treni.service.Haptic
import com.binario.treni.service.Speech
import kotlinx.coroutines.delay

/**
 * Primo avvio: propone gli avvisi accessibili.
 * - Persone sorde o ipoudenti: domanda a video (con vibrazione di prova).
 * - Persone non vedenti o ipovedenti: la domanda viene anche letta ad alta voce; si può rispondere toccando
 *   i pulsanti (letti da TalkBack) oppure a voce: "sì", "solo fermata", "no".
 * Se TalkBack è attivo, la domanda per non vedenti viene fatta per prima e il microfono si apre da solo.
 */
@Composable
fun AccessibilityWelcome(store: Store) {
    if (store.a11yAsked) return
    val ctx = LocalContext.current
    val talkBack = remember {
        val am = ctx.getSystemService(AccessibilityManager::class.java)
        am != null && am.isEnabled && am.isTouchExplorationEnabled
    }
    // Ordine delle domande: con TalkBack prima quella vocale
    val steps = remember { if (talkBack) listOf("blind", "deaf") else listOf("deaf", "blind") }
    var step by remember { mutableIntStateOf(0) }
    fun next() {
        if (step + 1 >= steps.size) store.a11yAsked = true
        step++
    }
    if (step >= steps.size) return

    when (steps[step]) {
        "deaf" -> AlertDialog(
            onDismissRequest = {},
            icon = { Icon(Icons.Filled.Vibration, null, tint = Green) },
            title = { Text(tx("Avvisi per persone sorde o ipoudenti")) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(tx("Vuoi attivare questa funzione?"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(tx("Vibrazione forte con uno schema diverso per ogni avviso (sveglia fermata, promemoria, interruzioni) e lampeggio del flash. Si può cambiare in qualsiasi momento in Impostazioni → Accessibilità."))
                    TextButton({ store.deafMode = true; Haptic.alert(ctx, Haptic.Kind.REMINDER); store.deafMode = false }) {
                        Text(tx("Prova la vibrazione"), color = Green)
                    }
                }
            },
            confirmButton = {
                Button({ store.deafMode = true; store.flashAlerts = true; next() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Text(tx("Sì, attiva"))
                }
            },
            dismissButton = { TextButton({ store.deafMode = false; next() }) { Text(tx("No, grazie")) } },
        )
        "blind" -> BlindQuestion(talkBack) { level ->
            store.blindLevel = level
            when (level) {
                "all" -> Speech.say(ctx, tx("Avvisi vocali attivi. Ti dirò il binario, la partenza e la fermata dove scendere."),
                    Speech.Sound.PLATFORM, force = true)
                "stop" -> Speech.say(ctx, tx("Ti avviserò con la voce solo quando la tua fermata è imminente."),
                    Speech.Sound.IMMINENT, force = true)
                else -> Speech.stop()
            }
            next()
        }
    }
}

@Composable
private fun BlindQuestion(talkBack: Boolean, onAnswer: (String) -> Unit) {
    val ctx = LocalContext.current
    val question = tx("Avvisi vocali per persone non vedenti o ipovedenti. Vuoi attivare questa funzione? " +
        "Puoi scegliere: sì, per tutti gli avvisi vocali su binario, partenza e fermate; " +
        "solo fermata, per essere avvisato solo quando la tua fermata è imminente; oppure no.")
    var heard by remember { mutableStateOf<String?>(null) }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val t = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.lowercase()?.trim()
        heard = t
        val level = when {
            t == null -> null
            listOf("fermata", "solo", "stop", "only").any { t.contains(it) } -> "stop"
            Regex("\\b(sì|si|tutti|tutto|attiva|yes|all)\\b").containsMatchIn(t) -> "all"
            Regex("\\b(no|non|niente|nessuno)\\b").containsMatchIn(t) -> "off"
            else -> null
        }
        if (level != null) onAnswer(level)
        else Speech.say(ctx, tx("Non ho capito. Rispondi sì, solo fermata, oppure no. Oppure tocca uno dei pulsanti."), Speech.Sound.INFO, force = true)
    }
    fun listen() {
        try {
            voice.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (I18n.en) "en-GB" else "it-IT")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, tx("Di' sì, solo fermata oppure no")),
            )
        } catch (_: Exception) {
        }
    }
    // La domanda viene letta ad alta voce; con TalkBack si apre poi il microfono per rispondere
    LaunchedEffect(Unit) {
        Speech.say(ctx, question, Speech.Sound.INFO, force = true)
        if (talkBack) {
            delay(2500L + question.length * 60L)
            listen()
        }
    }
    AlertDialog(
        onDismissRequest = {},
        icon = { Icon(Icons.Filled.RecordVoiceOver, null, tint = Green) },
        title = { Text(tx("Avvisi vocali per persone non vedenti")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(tx("Vuoi attivare questa funzione?"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(8.dp))
                Text(tx("La voce del telefono ti dice il binario, quando parte il treno, i cambi di binario e i ritardi, e con un suono insistente ti avvisa quando la tua fermata è imminente."))
                Spacer(Modifier.height(12.dp))
                Button({ onAnswer("all") }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Text(tx("Sì, tutti gli avvisi vocali"))
                }
                OutlinedButton({ onAnswer("stop") }, Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Text(tx("Solo fermata imminente"))
                }
                OutlinedButton({ onAnswer("off") }, Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Text(tx("No, grazie"))
                }
                OutlinedButton({ Speech.stop(); listen() }, Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Icon(Icons.Filled.Mic, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(tx("Rispondi a voce"))
                }
                TextButton({ Speech.stop(); Speech.say(ctx, question, Speech.Sound.INFO, force = true) }, Modifier.align(Alignment.CenterHorizontally)) {
                    Text(tx("Riascolta la domanda"), color = Green)
                }
                heard?.let { Text(tx("Ho sentito") + ": “$it”", color = Muted, fontSize = 13.sp) }
            }
        },
        confirmButton = {},
    )
}
