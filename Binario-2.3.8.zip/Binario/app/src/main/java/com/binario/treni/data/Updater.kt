package com.binario.treni.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Aggiornamenti dell'app. Ogni compilazione su GitHub pubblica l'APK firmato come "release" nel repository
 * pubblico [REPO] (il codice resta privato). All'avvio l'app legge l'ultima release e, se ha un numero di build
 * più alto di quello installato, propone di aggiornare: scarica l'APK e apre l'installazione di Android.
 * Android accetta l'aggiornamento solo se l'APK è firmato con la stessa chiave dell'app installata.
 */
object Updater {
    const val REPO = "MJ83-collab/Binario-app"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"
    const val PAGE = "https://github.com/$REPO/releases/latest"

    data class Release(val versionName: String, val versionCode: Long, val url: String, val size: Long, val notes: String)

    /** Nome dell'APK pubblicato: Binario-2.4-9.apk (versione e numero di build). */
    private val ASSET = Regex("""^Binario-(.+)-(\d+)\.apk$""")

    /** Legge la risposta di GitHub (logica pura, usata anche nei test). */
    fun parse(json: String): Release? {
        val o = JSONObject(json)
        if (o.optBoolean("draft") || o.optBoolean("prerelease")) return null
        val assets = o.optJSONArray("assets") ?: return null
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            val m = ASSET.find(a.optString("name")) ?: continue
            val url = a.optString("browser_download_url")
            if (!url.startsWith("https://")) continue
            return Release(m.groupValues[1], m.groupValues[2].toLong(), url, a.optLong("size"), o.optString("body").trim())
        }
        return null
    }

    fun installedCode(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (e: Exception) {
        Long.MAX_VALUE
    }

    /** La release più recente, se è più nuova di quella installata; altrimenti null (anche senza rete). */
    fun check(ctx: Context): Release? = try {
        val c = (URL(API).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 10000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "Binario-Android")
        }
        try {
            if (c.responseCode != 200) null
            else parse(c.inputStream.bufferedReader().use { it.readText() })?.takeIf { it.versionCode > installedCode(ctx) }
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }

    /** Scarica l'APK nella memoria dell'app, con l'avanzamento da 0 a 1. */
    fun download(ctx: Context, r: Release, progress: (Float) -> Unit): File {
        val dir = File(ctx.filesDir, "updates").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, "Binario-${r.versionName}-${r.versionCode}.apk")
        var url = r.url
        var conn: HttpURLConnection
        var hops = 0
        // GitHub reindirizza il download verso il proprio server dei file
        while (true) {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000; readTimeout = 30000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "Binario-Android")
            }
            val code = conn.responseCode
            if (code in 300..399 && hops < 5) {
                val next = conn.getHeaderField("Location") ?: throw IOException("Download non riuscito")
                conn.disconnect()
                if (!next.startsWith("https://")) throw IOException("Download non sicuro")
                url = next; hops++
                continue
            }
            if (code !in 200..299) throw IOException("HTTP $code")
            break
        }
        try {
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: r.size
            conn.inputStream.use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) progress((done.toFloat() / total).coerceIn(0f, 1f))
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
        if (r.size > 0 && out.length() != r.size) {
            out.delete()
            throw IOException(I18n.tr("Download incompleto", "Incomplete download"))
        }
        return out
    }

    /** Android 8+: l'utente deve consentire a Binario di installare app (una volta sola). */
    fun canInstall(ctx: Context): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ctx.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    fun install(ctx: Context, apk: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}
