package com.binario.treni.data

import java.util.Locale

/**
 * Area STIBM (Sistema Tariffario Integrato del Bacino di Mobilità di Milano e Monza Brianza): con un solo biglietto
 * si viaggia su treni Trenord e Trenitalia regionali, metro, tram e bus. Il prezzo dipende dal numero di zone
 * (Mi1…Mi9) tra partenza e arrivo, non dal mezzo.
 * Fonti: Trenord, "Area STIBM – aree coinvolte" (elenco stazioni), "Tariffe" e tariffario in vigore dal 01/10/2026.
 */
object Stibm {
    const val PAGE = "https://www.trenord.it/biglietti/titoli-di-viaggio/biglietti-integrati-stibm/aree-coinvolte/"
    const val RULES = "https://www.trenord.it/biglietti/titoli-di-viaggio/biglietti-integrati-stibm/regole-di-utilizzo/"
    const val TARIFFS = "https://www.trenord.it/biglietti/titoli-di-viaggio/biglietti-integrati-stibm/tariffe/"
    const val TARIFF_PDF = "https://www.trenord.it/fileadmin/contenuti/TRENORD/3-News/Trenord_Informa/Avvisi/2026/AvvisoA4Trenord_2026_179_Tariffario_01_ottobre.pdf"
    const val MAP_IMAGE = "https://www.trenord.it/fileadmin/contenuti/TRENORD/1-Biglietti_e_abbonamenti/Titoli_di_viaggio/STIMB/Aree_coinvolte/mappa_stibm_comp.jpg"
    const val PRICES_FROM = "01/10/2026"

    /** Zona 1 = città di Milano (biglietto minimo Mi1–Mi3). */
    data class StibmStation(val name: String, val comune: String, val prov: String, val zone: Int, val suspended: Boolean = false, val interchangeOnly: Boolean = false) {
        val zoneLabel: String get() = if (zone == 1) "Mi1–Mi3" else "Mi$zone"
    }

    private fun s(n: String, c: String, p: String, z: Int, susp: Boolean = false) = StibmStation(n, c, p, z, susp)

    /** Stazioni ferroviarie nell'area STIBM (elenco ufficiale Trenord). */
    val STATIONS: List<StibmStation> = listOf(
        s("Abbiategrasso", "Abbiategrasso", "MI", 7), s("Albairate-Vermezzo", "Albairate", "MI", 6), s("Arcore", "Arcore", "MB", 5),
        s("Besana", "Besana in Brianza", "MB", 7), s("Biassono-Lesmo Parco", "Biassono", "MB", 5), s("Bollate Centro", "Bollate", "MI", 3),
        s("Bollate Nord", "Bollate", "MI", 3), s("Borgolombardo", "San Giuliano Milanese", "MI", 4),
        s("Bovisio Masciago-Mombello", "Bovisio-Masciago", "MB", 5), s("Buttafava", "Arcore", "MB", 5),
        s("Camnago-Lentate", "Lentate sul Seveso", "MB", 6), s("Canegrate", "Canegrate", "MI", 7), s("Carate-Calò", "Carate Brianza", "MB", 6),
        s("Carnate Usmate", "Carnate", "MB", 6), s("Cassano d'Adda", "Cassano d'Adda", "MI", 7), s("Castano Primo", "Castano Primo", "MI", 9),
        s("Ceriano Laghetto-Groane", "Ceriano Laghetto", "MB", 6, true), s("Ceriano Laghetto-Solaro", "Solaro", "MB", 5),
        s("Cesano Boscone", "Cesano Boscone", "MI", 3), s("Cesano Maderno", "Cesano Maderno", "MB", 5),
        s("Cesano Maderno-Groane", "Cesano Maderno", "MB", 5), s("Cesate", "Cesate", "MI", 5),
        s("Corbetta-S. Stefano Ticino", "Corbetta", "MI", 6), s("Cormano-Cusano Milanino", "Cormano", "MI", 3), s("Corsico", "Corsico", "MI", 3),
        s("Desio", "Desio", "MB", 5), s("Gaggiano", "Gaggiano", "MI", 5), s("Garbagnate Milanese", "Garbagnate Milanese", "MI", 4),
        s("Garbagnate Parco Groane", "Garbagnate Milanese", "MI", 4), s("Legnano", "Legnano", "MI", 7), s("Lesmo", "Lesmo", "MB", 6),
        s("Lido di Turbigo", "Turbigo", "MI", 9, true), s("Lissone-Muggiò", "Lissone", "MB", 5), s("Locate Triulzi", "Locate di Triulzi", "MI", 4),
        s("Macherio Sovico", "Macherio", "MB", 5), s("Macherio-Canonica", "Macherio", "MB", 5), s("Magenta", "Magenta", "MI", 7),
        s("Meda", "Meda", "MB", 6), s("Melegnano", "Melegnano", "MI", 5), s("Melzo", "Melzo", "MI", 5),
        s("Milano Affori", "Milano", "MI", 1), s("Milano Bovisa", "Milano", "MI", 1), s("Milano Bruzzano", "Milano", "MI", 1),
        s("Milano Cadorna", "Milano", "MI", 1), s("Milano Centrale", "Milano", "MI", 1), s("Milano Certosa", "Milano", "MI", 1),
        s("Milano Dateo", "Milano", "MI", 1), s("Milano Domodossola", "Milano", "MI", 1), s("Milano Forlanini", "Milano", "MI", 1),
        s("Milano Greco Pirelli", "Milano", "MI", 1), s("Milano Lambrate", "Milano", "MI", 1), s("Milano Lancetti", "Milano", "MI", 1),
        s("Milano Porta Garibaldi", "Milano", "MI", 1), s("Milano Porta Garibaldi Passante", "Milano", "MI", 1),
        s("Milano Porta Genova", "Milano", "MI", 1), s("Milano Porta Romana", "Milano", "MI", 1), s("Milano Porta Venezia", "Milano", "MI", 1),
        s("Milano Porta Vittoria", "Milano", "MI", 1), s("Milano Quarto Oggiaro", "Milano", "MI", 1), s("Milano Repubblica", "Milano", "MI", 1),
        s("Milano Rogoredo", "Milano", "MI", 1), s("Milano Romolo", "Milano", "MI", 1), s("Milano San Cristoforo", "Milano", "MI", 1),
        s("Milano Villapizzone", "Milano", "MI", 1), s("Monza", "Monza", "MB", 4), s("Monza Sobborghi", "Monza", "MB", 4),
        s("Novate Milanese", "Novate Milanese", "MI", 3), s("Paderno Dugnano", "Paderno Dugnano", "MI", 4),
        s("Palazzolo Milanese", "Paderno Dugnano", "MI", 4), s("Parabiago", "Parabiago", "MI", 6), s("Pieve Emanuele", "Pieve Emanuele", "MI", 4),
        s("Pioltello Limito", "Pioltello", "MI", 4), s("Pozzuolo Martesana", "Pozzuolo Martesana", "MI", 6),
        s("Pregnana Milanese", "Pregnana Milanese", "MI", 5), s("Renate-Veduggio", "Renate", "MB", 8), s("Rescaldina", "Rescaldina", "MI", 7),
        s("Rho", "Rho", "MI", 4), s("Rho Fiera Milano", "Rho", "MI", 3), s("San Donato Milanese", "San Donato Milanese", "MI", 3),
        s("San Giuliano Milanese", "San Giuliano Milanese", "MI", 4), s("San Zenone al Lambro", "San Zenone al Lambro", "MI", 6),
        s("Segrate", "Segrate", "MI", 3), s("Seregno", "Seregno", "MB", 6), s("Sesto San Giovanni", "Sesto San Giovanni", "MI", 3),
        s("Seveso", "Seveso", "MB", 6), s("Seveso-Baruccana", "Seveso", "MB", 6), s("Tavazzano", "Tavazzano con Villanesco", "LO", 7),
        s("Trecella", "Pozzuolo Martesana", "MI", 6), s("Trezzano sul Naviglio", "Trezzano sul Naviglio", "MI", 4),
        s("Triuggio-Ponte Albiate", "Triuggio", "MB", 6), s("Turbigo", "Turbigo", "MI", 9), s("Vanzaghello-Magnago", "Vanzaghello", "MI", 9),
        s("Vanzago Pogliano", "Vanzago", "MI", 5), s("Varedo", "Varedo", "MB", 5), s("Vignate", "Vignate", "MI", 5),
        s("Villa Raverio", "Besana in Brianza", "MB", 7), s("Villamaggiore", "Lacchiarella", "MI", 5), s("Villasanta", "Villasanta", "MB", 5),
        s("Vittuone Arluno", "Vittuone", "MI", 5),
    )

    /** Fuori area STIBM: fermata intermedia ammessa solo per cambiare treno o bus (stazioni ferroviarie). */
    val INTERCHANGE: List<StibmStation> = listOf(
        StibmStation("Busto Arsizio", "Busto Arsizio", "VA", 8, interchangeOnly = true),
        StibmStation("Caronno Pertusella", "Caronno Pertusella", "VA", 5, interchangeOnly = true),
        StibmStation("Castellanza", "Castellanza", "VA", 7, interchangeOnly = true),
        StibmStation("Saronno", "Saronno", "VA", 6, interchangeOnly = true),
        StibmStation("Cantù", "Cantù", "CO", 8, interchangeOnly = true),
        StibmStation("Mariano Comense", "Mariano Comense", "CO", 7, interchangeOnly = true),
        StibmStation("Rovellasca", "Rovellasca", "CO", 7, interchangeOnly = true),
        StibmStation("Treviglio", "Treviglio", "BG", 8, interchangeOnly = true),
        StibmStation("Paderno d'Adda", "Paderno d'Adda", "LC", 8, interchangeOnly = true),
    )

    /** Prezzi per numero di zone (tariffario dal 01/10/2026). */
    data class Prices(
        val zones: Int, val minutes: Int, val single: Double, val daily: Double, val threeDays: Double, val carnet10: Double,
        val weekly: Double, val monthly: Double, val yearly: Double, val monthlyReduced: Double, val yearlyReduced: Double, val yearlyIsee: Double,
    )

    val PRICES: Map<Int, Prices> = listOf(
        Prices(2, 75, 1.70, 5.90, 12.50, 15.00, 15.00, 40.00, 368.00, 30.00, 276.00, 55.00),
        Prices(3, 90, 2.20, 7.60, 15.50, 19.50, 18.50, 50.00, 460.00, 37.50, 345.00, 69.00),
        Prices(4, 105, 2.60, 9.10, 18.50, 23.00, 22.00, 60.00, 552.00, 45.00, 414.00, 83.00),
        Prices(5, 135, 3.00, 10.50, 22.00, 27.00, 26.00, 70.00, 644.00, 53.00, 483.00, 97.00),
        Prices(6, 165, 3.50, 12.00, 25.00, 31.00, 29.50, 77.00, 682.00, 58.00, 512.00, 102.00),
        Prices(7, 195, 3.90, 13.50, 28.00, 35.00, 33.00, 82.00, 712.00, 62.00, 534.00, 107.00),
        Prices(8, 225, 4.30, 15.00, 31.00, 38.50, 37.00, 88.00, 738.00, 66.00, 554.00, 111.00),
        Prices(9, 255, 4.80, 16.50, 34.50, 43.00, 40.50, 89.00, 761.00, 67.00, 571.00, 114.00),
    ).associateBy { it.zones }

    // ---------------- Riconoscimento delle stazioni ----------------

    /** "MILANO P.TA GARIBALDI", "S. DONATO MILANESE", "Carate-Calò" → forma confrontabile. */
    fun norm(n: String): String = n.uppercase(Locale.ITALY)
        .replace("À", "A").replace("È", "E").replace("É", "E").replace("Ì", "I").replace("Ò", "O").replace("Ù", "U")
        .replace(Regex("""\bP\.?\s*TA\b"""), "PORTA").replace(Regex("""\bS\.\s*"""), "SAN ")
        .replace(Regex("[^A-Z0-9]+"), " ").trim()

    /** Stazione STIBM (o di solo interscambio) con questo nome, anche scritto come su ViaggiaTreno. */
    fun find(name: String): StibmStation? {
        val n = norm(name)
        if (n.isBlank()) return null
        val all = STATIONS + INTERCHANGE
        all.firstOrNull { norm(it.name) == n }?.let { return it }
        // "MILANO BOVISA POLITECNICO", "RHO FIERA", "MILANO BRUZZANO PARCO NORD"…
        return all.filter { st -> val k = norm(st.name); n.startsWith("$k ") || k.startsWith("$n ") }.maxByOrNull { it.name.length }
    }

    // ---------------- Calcolo delle zone ----------------

    /** Tariffa da zona [from] a zona [to] (es. 1..6 = Mi1–Mi6) e numero di zone da pagare. */
    data class Fare(val from: Int, val to: Int) {
        val zones: Int get() = to - from + 1
        val label: String get() = "Mi$from–Mi$to"
        val prices: Prices? get() = PRICES[zones]
    }

    /**
     * Regole Trenord: a Milano minimo Mi1–Mi3; tra località fuori Milano le zone tra le due; se il viaggio
     * attraversa Milano serve sempre anche Mi1 (Mi1 fino alla zona più lontana); minimo 2 zone anche nella stessa zona.
     */
    fun fare(a: Int, b: Int, throughMilano: Boolean): Fare {
        val hi = maxOf(a, b)
        val lo = minOf(a, b)
        return when {
            lo == 1 || throughMilano -> Fare(1, maxOf(3, hi))
            lo == hi -> if (hi >= 9) Fare(8, 9) else Fare(lo, lo + 1)
            else -> Fare(lo, hi)
        }
    }

    /** Milano (Duomo) per stimare se un viaggio passa dalla città. */
    private const val MI_LAT = 45.4642
    private const val MI_LON = 9.1900

    /**
     * Stima se tra due località fuori Milano si passa dalla città: le due stazioni stanno in direzioni molto diverse
     * rispetto a Milano (oltre 100°). È una stima: l'utente può sempre cambiarla.
     */
    fun likelyThroughMilano(a: Pair<Double, Double>?, b: Pair<Double, Double>?): Boolean {
        if (a == null || b == null) return false
        fun bearing(p: Pair<Double, Double>) = Math.toDegrees(Math.atan2(p.second - MI_LON, p.first - MI_LAT))
        var d = Math.abs(bearing(a) - bearing(b))
        if (d > 180) d = 360 - d
        return d > 100
    }

    fun eur(v: Double): String = String.format(Locale.ITALY, "%.2f €", v)
}
