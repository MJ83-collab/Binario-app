package com.binario.treni.ui

import com.binario.treni.data.tx
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.Leg
import com.binario.treni.data.Reminder
import com.binario.treni.data.Solution
import com.binario.treni.data.TrainRef
import com.binario.treni.data.TrainStatus
import com.binario.treni.data.Tratta
import com.binario.treni.service.Reminders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ResultsScreen(vm: MainViewModel, onBack: () -> Unit, onTrain: (TrainRef) -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val f0 = vm.from
    val t0 = vm.to
    val tratta = if (f0 != null && t0 != null) Tratta(f0, t0) else null
    var fav by remember { mutableStateOf(tratta?.let { vm.store.isFavRoute(it) } ?: false) }
    val offline = vm.offlineTitle != null
    val list = if (tab == 0) vm.results else vm.returnResults
    var pdf by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(if (offline) tx("Salvato offline") else tx("Soluzioni"), onBack) {
            if (!offline) IconButton({ vm.search() }) { Icon(Icons.Filled.Refresh, tx("Aggiorna")) }
            if (!offline && tratta != null) {
                IconButton({ fav = vm.store.toggleFavRoute(tratta) }) {
                    Icon(if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder, tx("Preferito"))
                }
                IconButton({ pdf = true }) { Icon(Icons.Filled.PictureAsPdf, tx("Scarica l'orario del giorno in PDF")) }
                IconButton({ toast(ctx, if (vm.saveOffline()) tx("Orari salvati per la consultazione offline") else tx("Niente da salvare")) }) {
                    Icon(Icons.Filled.DownloadForOffline, tx("Salva offline"))
                }
            }
            IconButton({
                val text = buildString {
                    append(vm.offlineTitle ?: tratta?.label ?: "").append("\n")
                    list.take(8).forEach { s -> append(solutionLine(s)).append("\n") }
                }
                shareText(ctx, text)
            }) { Icon(Icons.Filled.Share, tx("Condividi orari")) }
        }
        if (vm.roundTrip && !offline) GreenTabs(listOf(tx("Andata"), tx("Ritorno")), tab) { tab = it }
        // Senza rete: si mostrano gli ultimi orari scaricati per questa tratta
        vm.staleNote?.let { n ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CloudOff, null, tint = Color(0xFFEF6C00), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(n, color = Color(0xFFEF6C00), fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton({ vm.search() }) { Text(tx("Riprova"), color = Green) }
            }
        }
        if (pdf && tratta != null) PdfTimetableDialog(tratta.from, tratta.to, vm.date, vm.store) { pdf = false }
        PullRefresh(vm.loading, { if (!offline) vm.search() }) { when {
            vm.loading -> LoadingBox()
            list.isEmpty() -> PullableMessage(vm.error ?: tx("Nessuna soluzione"))
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 6.dp)) {
                item {
                    Text(
                        (vm.offlineTitle ?: Fmt.dayLong(list.first().dep)) + if (offline) "" else " · " + vm.filter.label,
                        color = Muted, modifier = Modifier.padding(start = 16.dp, top = 6.dp, bottom = 4.dp),
                    )
                }
                items(list) { s -> SolutionCard(vm, s, onTrain) }
                if (!offline) item {
                    Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                        if (vm.loadingMore) CircularProgressIndicator(color = Green)
                        else OutlinedButton({ vm.loadMore(tab == 1) }) { Text(tx("Soluzioni successive"), color = Green) }
                    }
                }
            }
        } }
    }
}

private fun solutionLine(s: Solution) =
    "${Fmt.time(s.dep)} → ${Fmt.time(s.arr)}  ${s.legs.joinToString(" + ") { it.title }}  ${Fmt.price(s.price)}".trim()

/** Dati in tempo reale di un treno della soluzione (ritardo e binari). */
private data class LegLive(
    val delay: Int, val depSched: String, val depReal: String, val arrSched: String, val arrReal: String,
    val ref: TrainRef, val cancelled: Boolean,
)

private fun liveFor(leg: Leg, st: TrainStatus): LegLive {
    val a = st.stops.firstOrNull { it.name.equals(leg.from, true) }
    val b = st.stops.firstOrNull { it.name.equals(leg.to, true) }
    return LegLive(st.delay, a?.schedPlatform ?: "", a?.realPlatform ?: "", b?.schedPlatform ?: "", b?.realPlatform ?: "", st.ref, st.cancelled)
}

@Composable
private fun SolutionCard(vm: MainViewModel, s: Solution, onTrain: (TrainRef) -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var reminder by remember { mutableStateOf(false) }
    val live = remember(s) { mutableStateMapOf<Int, LegLive>() }

    // Ritardi e binari reali solo per i treni vicini all'orario attuale
    LaunchedEffect(s) {
        val now = System.currentTimeMillis()
        if (s.dep in (now - 3 * 3600_000L)..(now + 4 * 3600_000L)) {
            s.legs.take(3).forEachIndexed { i, l ->
                try {
                    val st = withContext(Dispatchers.IO) { Api.status(TrainRef(l.number)) }
                    live[i] = liveFor(l.withEnds(s, i), st)
                } catch (_: Exception) {
                }
            }
        }
    }

    WhiteCard {
        Column(Modifier.padding(start = 14.dp, end = 6.dp, top = 10.dp)) {
            s.legs.forEachIndexed { i, raw ->
                val l = raw.withEnds(s, i)
                val lv = live[i]
                // Tempo per il cambio (come Trainline): tiene conto del ritardo attuale del treno precedente
                if (i > 0) {
                    val prev = s.legs[i - 1].withEnds(s, i - 1)
                    if (prev.arr > 0 && l.dep > 0) {
                        val prevDelay = live[i - 1]?.delay?.coerceAtLeast(0) ?: 0
                        val planned = ((l.dep - prev.arr) / 60_000L).toInt()
                        val real = planned - prevDelay
                        val (txt, col) = when {
                            real < 0 -> (tx("Coincidenza a rischio: il treno precedente ha") + " $prevDelay " + tx("min di ritardo")) to LateRed
                            real < 5 -> (tx("Cambio breve") + ": $real min" + (if (l.from.isNotBlank()) " " + tx("a") + " ${l.from}" else "")) to Color(0xFFEF6C00)
                            else -> (tx("Cambio") + ": $real min" + (if (l.from.isNotBlank()) " " + tx("a") + " ${l.from}" else "") +
                                (if (prevDelay > 0) " (" + tx("previsti") + " $planned)" else "")) to Muted
                        }
                        Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.TransferWithinAStation, null, tint = col, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(txt, color = col, fontSize = 13.sp, fontWeight = if (col == Muted) FontWeight.Normal else FontWeight.Bold)
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TrainTitle(l.category, l.number, 17) { onTrain(lv?.ref ?: TrainRef(l.number, label = l.title)) }
                    Spacer(Modifier.width(8.dp))
                    CrowdBadge(com.binario.treni.data.Crowd.estimate(l.dep, l.category, s.from, s.to))
                    Spacer(Modifier.weight(1f))
                    if (i == 0) Box {
                        IconButton({ menu = true }, Modifier.size(32.dp)) { Icon(Icons.Filled.MoreVert, tx("Altro"), tint = Muted) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text(tx("Condividi")) }, { menu = false; shareText(ctx, "${s.from} → ${s.to}\n" + solutionLine(s)) })
                            DropdownMenuItem({ Text(tx("Aggiungi al calendario")) }, {
                                menu = false
                                addToCalendar(ctx, "Treno ${s.legs.joinToString(" + ") { it.title }}", s.dep, s.arr, s.from, "${s.from} → ${s.to}")
                            })
                            DropdownMenuItem({ Text(tx("Avvisami (notifica programmata)")) }, { menu = false; reminder = true })
                        }
                    }
                }
                Row(Modifier.padding(end = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        StopLine(true, l.dep, l.from, lv?.depSched ?: "", lv?.depReal ?: "")
                        StopLine(false, l.arr, l.to, lv?.arrSched ?: "", lv?.arrReal ?: "")
                    }
                    Box(Modifier.width(56.dp), contentAlignment = Alignment.Center) {
                        if (lv != null) DelayBadge(lv.delay, lv.cancelled, showZero = true)
                    }
                }
            }
        }
        HorizontalDivider(color = Color(0x14000000))
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (s.price != null) {
                        Text(Fmt.price(s.price), fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Spacer(Modifier.width(14.dp))
                    }
                    Icon(Icons.Outlined.Timer, null, tint = Color(0xFF555555), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(s.duration.ifBlank { Fmt.duration(s.dep, s.arr) }, fontSize = 16.sp)
                    if (s.changes > 0) Text("  · ${s.changes} camb${if (s.changes == 1) "io" else "i"}", color = Muted, fontSize = 14.sp)
                }
                Text(buySource(s.legs.firstOrNull()?.category ?: ""), color = Green, fontSize = 14.sp)
            }
            IconButton({ shareText(ctx, "${s.from} → ${s.to}\n" + solutionLine(s)) }) { Icon(Icons.Filled.Share, tx("Condividi"), tint = Color(0xFF555555)) }
            if (vm.store.showBuy) IconButton({ openUrl(ctx, buyUrl(s.legs.firstOrNull()?.category ?: "")) }) {
                Icon(Icons.Filled.ShoppingCart, tx("Acquista"), tint = Color(0xFF555555))
            }
        }
    }

    if (reminder) {
        ReminderDialog({ reminder = false }) { min, arrival ->
            val leg = if (arrival) s.legs.lastOrNull() else s.legs.firstOrNull()
            val ev = if (arrival) s.arr else s.dep
            val at = ev - min * 60_000L
            if (leg == null || at < System.currentTimeMillis()) {
                toast(ctx, tx("Orario già passato"))
            } else {
                Reminders.add(
                    ctx,
                    Reminder((System.currentTimeMillis() % 1_000_000).toInt(), leg.number, "", at, ev, "${leg.title} ${s.from} → ${s.to}", arrival),
                )
                toast(ctx, "Ti avviserò alle ${Fmt.time(at)}")
            }
            reminder = false
        }
    }
}

/** Completa una tratta senza dettagli con gli estremi della soluzione. */
private fun Leg.withEnds(s: Solution, i: Int): Leg {
    if (from.isNotBlank()) return this
    val first = i == 0
    val last = i == s.legs.size - 1
    return copy(
        from = if (first) s.from else "",
        to = if (last) s.to else "",
        dep = if (first) s.dep else 0L,
        arr = if (last) s.arr else 0L,
    )
}

@Composable
private fun StopLine(departure: Boolean, time: Long, name: String, schedPlat: String, realPlat: String) {
    if (name.isBlank() && time <= 0) return
    Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (departure) Icons.Filled.RadioButtonChecked else Icons.Outlined.RadioButtonUnchecked, null,
            tint = Color(0xFF616161), modifier = Modifier.size(16.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(Fmt.time(time), fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.width(8.dp))
        Text(name, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        PlatformPair(schedPlat, realPlat, compact = true)
    }
}
