package com.binario.treni.service

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import com.binario.treni.data.I18n
import com.binario.treni.data.Store
import java.util.Locale

/**
 * Avvisi per persone non vedenti o ipovedenti: un suono riconoscibile seguito da una frase detta dalla voce
 * del telefono (sintesi vocale di Android). Ogni tipo di avviso ha il suo suono, così si capisce
 * di cosa si tratta ancora prima che la voce parli.
 */
object Speech {
    enum class Sound {
        /** Informazione (inizio monitoraggio, risposta dell'assistente): un "din" breve. */
        INFO,
        /** Binario o promemoria di partenza: due toni ascendenti. */
        PLATFORM,
        /** Partenza a breve: tre bip. */
        DEPART,
        /** Fermata imminente: bip rapidi e insistenti, volume sveglia. */
        IMMINENT,
        /** Problema (cambio binario, ritardo, soppressione): tono basso. */
        ALERT,
    }

    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val queue = mutableListOf<String>()
    private val main = Handler(Looper.getMainLooper())
    private var counter = 0

    /** Pulizia del testo per la voce: simboli e abbreviazioni diventano parole. */
    fun forVoice(text: String): String {
        val en = I18n.en
        var t = text
            .replace("→", if (en) " to " else " per ")
            .replace("←", if (en) " from " else " da ")
            .replace("•", ". ").replace("·", ", ").replace("⏰", "").replace("✓", "")
            .replace("⚠️", "").replace("🚫", "").replace("🚧", "").replace("🛗", "").replace("♿", "")
        t = Regex("\\+(\\d+)'").replace(t) { m -> if (en) "${m.groupValues[1]} minutes late" else "${m.groupValues[1]} minuti di ritardo" }
        t = Regex("(-\\d+)'").replace(t) { m -> if (en) "${m.groupValues[1].drop(1)} minutes early" else "${m.groupValues[1].drop(1)} minuti di anticipo" }
        t = Regex("\\bbin\\.\\s*", RegexOption.IGNORE_CASE).replace(t, if (en) "platform " else "binario ")
        t = Regex("\\bplat\\.\\s*", RegexOption.IGNORE_CASE).replace(t, "platform ")
        t = t.replace(" min ", if (en) " minutes " else " minuti ")
        // Sigle dei treni lette per esteso
        t = Regex("\\bREG\\b").replace(t, if (en) "regional" else "regionale")
        t = Regex("\\bRV\\b").replace(t, if (en) "fast regional" else "regionale veloce")
        t = Regex("\\bFR\\b").replace(t, "Frecciarossa")
        t = Regex("\\bFA\\b").replace(t, "Frecciargento")
        t = Regex("\\bFB\\b").replace(t, "Frecciabianca")
        t = Regex("\\bIC\\b").replace(t, "Intercity")
        t = Regex("\\bEC\\b").replace(t, "Eurocity")
        t = Regex("\\s+").replace(t, " ")
        return t.trim()
    }

    private fun ensure(ctx: Context) {
        if (tts != null) return
        val app = ctx.applicationContext
        main.post {
            if (tts != null) return@post
            tts = TextToSpeech(app) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val t = tts ?: return@TextToSpeech
                    t.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build(),
                    )
                    val loc = if (I18n.en) Locale.UK else Locale.ITALY
                    if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) t.language = loc
                    ready = true
                    val pending = synchronized(queue) { queue.toList().also { queue.clear() } }
                    pending.forEach { speakNow(app, it) }
                } else {
                    tts = null
                }
            }
        }
    }

    private fun speakNow(ctx: Context, text: String) {
        val t = tts ?: return
        try {
            t.setSpeechRate(Store(ctx).speechRate)
            t.speak(text, TextToSpeech.QUEUE_ADD, Bundle(), "binario-" + (counter++))
        } catch (_: Exception) {
        }
    }

    /**
     * Suono + frase. Parla solo se la modalità non vedenti è attiva, a meno di [force]
     * (per esempio le risposte all'assistente quando la domanda è stata fatta a voce).
     */
    fun say(ctx: Context, text: String, sound: Sound? = Sound.INFO, force: Boolean = false, times: Int = 1, essential: Boolean = false) {
        if (!force) {
            // "Solo fermata imminente": parla solo per gli avvisi essenziali (fermata dove scendere)
            when (Store(ctx).blindLevel) {
                "off" -> return
                "stop" -> if (!essential) return
            }
        }
        val app = ctx.applicationContext
        val spoken = forVoice(text)
        ensure(app)
        Thread {
            val n = times.coerceIn(1, 3)
            for (i in 0 until n) {
                if (sound != null) play(sound)
                if (ready) main.post { speakNow(app, spoken) } else synchronized(queue) { queue += spoken }
                // Tra una ripetizione e l'altra lasciamo il tempo di finire la frase
                if (i < n - 1) try { Thread.sleep(2500L + spoken.length * 70L) } catch (_: InterruptedException) { }
            }
        }.start()
    }

    /** Interrompe la voce (per esempio quando si chiude l'assistente). */
    fun stop() {
        try { tts?.stop() } catch (_: Exception) { }
    }

    /** Suoni generati dal telefono: non servono file audio. Blocca il thread per la durata del suono. */
    fun play(sound: Sound) {
        val stream = if (sound == Sound.IMMINENT) AudioManager.STREAM_ALARM else AudioManager.STREAM_NOTIFICATION
        val tg = try { ToneGenerator(stream, 100) } catch (e: Exception) { return }
        try {
            when (sound) {
                Sound.INFO -> { tg.startTone(ToneGenerator.TONE_PROP_PROMPT, 250); Thread.sleep(350) }
                Sound.PLATFORM -> { tg.startTone(ToneGenerator.TONE_PROP_ACK, 400); Thread.sleep(500) }
                Sound.DEPART -> repeat(3) { tg.startTone(ToneGenerator.TONE_PROP_BEEP, 180); Thread.sleep(320) }
                Sound.IMMINENT -> repeat(8) { tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 140); Thread.sleep(230) }
                Sound.ALERT -> { tg.startTone(ToneGenerator.TONE_SUP_ERROR, 700); Thread.sleep(800) }
            }
            Thread.sleep(150)
        } catch (_: Exception) {
        } finally {
            tg.release()
        }
    }
}
