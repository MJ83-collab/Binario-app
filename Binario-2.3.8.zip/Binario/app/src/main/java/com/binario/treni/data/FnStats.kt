package com.binario.treni.data

import android.content.Context
import android.net.ConnectivityManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Puntualità della rete FerrovieNord (treni Trenord da/per Milano Cadorna, Saronno, Varese Nord, Como Lago,
 * Novara Nord, Malpensa, Asso, Brescia–Iseo–Edolo). TrovaTreno non pubblica questa rete, quindi l'app raccoglie
 * da sola gli arrivi da ViaggiaTreno (che la segue in tempo reale) e calcola la media degli ultimi 30 giorni.
 * Puntuale = arrivo entro 5 minuti, come nei dati TrovaTreno.
 */
object FnStats {
    const val SOURCE = "Raccolti dall'app da ViaggiaTreno (rete FerrovieNord)"
    const val PREFIX = "FN_"
    private const val FILE = "fn_punct.json"
    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")

    /** Stazioni osservate (codici ViaggiaTreno). */
    val STATIONS: List<Station> = listOf(
        Station("Milano Cadorna", "S01066"),
        Station("Milano Bovisa Politecnico", "S01642"),
        Station("Saronno", "S01933"),
        Station("Busto Arsizio Nord", "S01137"),
        Station("Varese Nord", "S01738"),
        Station("Laveno Mombello Lago", "S01747"),
        Station("Como Lago", "S01765"),
        Station("Novara Nord", "S00023"),
        Station("Malpensa Aeroporto T1", "S01139"),
        Station("Seveso", "S01925"),
        Station("Asso", "S01101"),
        Station("Iseo", "S01021"),
        Station("Edolo", "S01002"),
    )

    fun isFnStation(id: String) = STATIONS.any { it.id == id }

    enum class Line(val itLabel: String, val enLabel: String, val keys: List<String>) {
        MALPENSA("Malpensa Express", "Malpensa Express", listOf("MALPENSA")),
        VARESE("Milano – Saronno – Varese – Laveno", "Milan – Saronno – Varese – Laveno",
            listOf("VARESE NORD", "CASBENO", "LAVENO", "CASTRONNO", "TRADATE", "MALNATE")),
        COMO("Milano – Saronno – Como", "Milan – Saronno – Como", listOf("COMO LAGO", "COMO BORGHI", "(FNM)", "GRANDATE", "FINO MORNASCO", "LOMAZZO")),
        NOVARA("Milano – Saronno – Novara", "Milan – Saronno – Novara", listOf("NOVARA NORD", "TURBIGO", "CASTANO", "VANZAGHELLO", "BUSTO ARSIZIO NORD")),
        ASSO("Milano – Seveso – Asso", "Milan – Seveso – Asso", listOf("ASSO", "CANZO", "ERBA", "MERONE", "INVERIGO", "CAMNAGO", "SEVESO", "MEDA")),
        ISEO("Brescia – Iseo – Edolo", "Brescia – Iseo – Edolo", listOf("ISEO", "EDOLO", "PISOGNE", "BRENO", "DARFO", "BORNATO")),
        OTHER("Altri treni (linee S e Passante)", "Other trains (S lines and Passante)", emptyList()),
        ;

        val label: String get() = I18n.tr(itLabel, enLabel)

        companion object {
            /** La linea si riconosce dall'altro capolinea del treno; se non basta, dalla stazione osservata. */
            fun of(otherEnd: String, station: String): Line {
                fun pad(x: String) = " " + x.uppercase().replace(Regex("[^A-Z0-9()]+"), " ") + " "
                val a = pad(otherEnd)
                val b = pad(station)
                fun hit(t: String, l: Line) = l.keys.any { k -> t.contains(" $k ") }
                entries.filter { it != OTHER }.firstOrNull { l -> hit(a, l) }?.let { return it }
                if (a.contains(" MILANO ") || a.contains(" SARONNO ") || a.contains(" BRESCIA ")) {
                    entries.filter { it != OTHER }.firstOrNull { l -> hit(b, l) }?.let { return it }
                }
                return OTHER
            }
        }
    }

    /** Un arrivo letto dal tabellone. */
    data class Obs(val number: String, val otherEnd: String, val sched: Long, val delay: Int, val cancelled: Boolean)

    private fun day(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date(ms))

    /** Conta gli arrivi già avvenuti, una volta sola per treno e stazione. Logica pura: usata anche nei test. */
    fun ingest(state: JSONObject, station: Station, items: List<Obs>, now: Long): Int {
        val days = state.optJSONObject("days") ?: JSONObject().also { state.put("days", it) }
        val seen = state.optJSONObject("seen") ?: JSONObject().also { state.put("seen", it) }
        var added = 0
        items.forEach { o ->
            if (o.sched <= 0 || o.sched < now - 4 * 3600_000L) return@forEach
            val arrived = o.sched + o.delay * 60_000L <= now - 2 * 60_000L
            if (!arrived) return@forEach
            val d = day(o.sched)
            val seenToday = seen.optJSONArray(d) ?: JSONArray().also { seen.put(d, it) }
            val key = Habits.digits(o.number) + "@" + station.id
            if ((0 until seenToday.length()).any { seenToday.optString(it) == key }) return@forEach
            seenToday.put(key)
            val dd = days.optJSONObject(d) ?: JSONObject().also { days.put(d, it) }
            fun bump(group: String, k: String) {
                val g = dd.optJSONObject(group) ?: JSONObject().also { dd.put(group, it) }
                val a = g.optJSONArray(k) ?: JSONArray(listOf(0, 0, 0, 0, 0)).also { g.put(k, it) }
                // [arrivi, in orario, soppressi, minuti di ritardo totali, ritardi gravi (≥15)]
                if (o.cancelled) {
                    a.put(2, a.optInt(2) + 1)
                } else {
                    a.put(0, a.optInt(0) + 1)
                    if (o.delay <= 5) a.put(1, a.optInt(1) + 1)
                    a.put(3, a.optInt(3) + o.delay.coerceAtLeast(0))
                    if (o.delay >= 15) a.put(4, a.optInt(4) + 1)
                }
            }
            val line = Line.of(o.otherEnd, station.name)
            (state.optJSONObject("names") ?: JSONObject().also { state.put("names", it) }).put(station.id, station.name)
            bump("st", station.id)
            bump("ln", line.name)
            // Per ogni treno teniamo l'osservazione più a valle del giorno (la stazione con l'orario più tardo)
            val trains = state.optJSONObject("trains") ?: JSONObject().also { state.put("trains", it) }
            val num = Habits.digits(o.number)
            val t = trains.optJSONObject(num) ?: JSONObject().also { trains.put(num, it) }
            val td = t.optJSONObject("d") ?: JSONObject().also { t.put("d", it) }
            val prev = td.optJSONArray(d)
            if (prev == null || prev.optLong(0) <= o.sched) {
                td.put(d, JSONArray(listOf(o.sched, o.delay, if (o.cancelled) 1 else 0)))
                t.put("to", station.name)
                t.put("ln", line.name)
            }
            added++
        }
        // Treni: 31 giorni
        state.optJSONObject("trains")?.let { trains ->
            val cutoff = days.keys().asSequence().toList().sorted().dropLast(31).lastOrNull()
            if (cutoff != null) {
                trains.keys().asSequence().toList().forEach { n ->
                    val td = trains.optJSONObject(n)?.optJSONObject("d") ?: return@forEach
                    td.keys().asSequence().toList().filter { it <= cutoff }.forEach { td.remove(it) }
                    if (td.length() == 0) trains.remove(n)
                }
            }
        }
        // Si tengono 40 giorni
        days.keys().asSequence().toList().sorted().dropLast(40).forEach { days.remove(it) }
        seen.keys().asSequence().toList().sorted().dropLast(2).forEach { seen.remove(it) }
        return added
    }

    data class Summary(
        val days: Int, val first: String, val last: String, val total: PunctRow,
        val stations: List<PunctRow>, val lines: List<PunctRow>, val trains: List<PunctRow> = emptyList(),
    )

    /** Puntualità per treno (una osservazione al giorno: la più a valle). */
    fun trainRows(state: JSONObject): List<PunctRow> {
        val trains = state.optJSONObject("trains") ?: return emptyList()
        return trains.keys().asSequence().toList().mapNotNull { n ->
            val t = trains.optJSONObject(n) ?: return@mapNotNull null
            val td = t.optJSONObject("d") ?: return@mapNotNull null
            val acc = IntArray(5)
            td.keys().forEach { d ->
                val a = td.getJSONArray(d)
                val delay = a.optInt(1)
                if (a.optInt(2) == 1) {
                    acc[2]++
                } else {
                    acc[0]++
                    if (delay <= 5) acc[1]++
                    acc[3] += delay.coerceAtLeast(0)
                    if (delay >= 15) acc[4]++
                }
            }
            if (acc[0] + acc[2] == 0) return@mapNotNull null
            PunctRow(
                n, "REG $n", "Trenord · " + I18n.tr("rete FN", "FN network") + " → " + t.optString("to"),
                if (acc[0] == 0) 0.0 else acc[1] * 100.0 / acc[0], if (acc[0] == 0) 0.0 else acc[3].toDouble() / acc[0],
                acc[0], acc[2], acc[1], acc[4], category = "REG", operator = "trenord",
            )
        }
    }

    fun summarize(state: JSONObject, maxDays: Int = 30): Summary? {
        val days = state.optJSONObject("days") ?: return null
        val keys = days.keys().asSequence().toList().sorted().takeLast(maxDays)
        if (keys.isEmpty()) return null
        val st = HashMap<String, IntArray>()
        val ln = HashMap<String, IntArray>()
        keys.forEach { d ->
            val o = days.getJSONObject(d)
            listOf("st" to st, "ln" to ln).forEach { (g, acc) ->
                val gg = o.optJSONObject(g) ?: return@forEach
                gg.keys().forEach { k ->
                    val a = gg.getJSONArray(k)
                    val t = acc.getOrPut(k) { IntArray(5) }
                    for (i in 0 until 5) t[i] += a.optInt(i)
                }
            }
        }
        fun row(key: String, name: String, t: IntArray) = PunctRow(
            PREFIX + key, name, "", if (t[0] == 0) 0.0 else t[1] * 100.0 / t[0], if (t[0] == 0) 0.0 else t[3].toDouble() / t[0],
            t[0], t[2], t[1], t[4], operator = "trenord",
        )
        val names = state.optJSONObject("names")
        val stations = st.mapNotNull { (k, t) ->
            (STATIONS.firstOrNull { it.id == k }?.name ?: names?.optString(k)?.takeIf { it.isNotBlank() })?.let { row(k, it, t) }
        }.filter { it.observed > 0 }
        val lines = ln.mapNotNull { (k, t) -> runCatching { Line.valueOf(k) }.getOrNull()?.let { row(k, it.label, t) } }
            .filter { it.observed > 0 }.sortedBy { r -> Line.entries.indexOfFirst { PREFIX + it.name == r.key } }
        // Il totale somma gli arrivi in tutte le stazioni osservate (come le FFS: arrivi alle fermate)
        val tot = IntArray(5)
        ln.values.forEach { t -> for (i in 0 until 5) tot[i] += t[i] }
        return Summary(keys.size, keys.first(), keys.last(), row("all", I18n.tr("Rete FerrovieNord", "FerrovieNord network"), tot), stations, lines, trainRows(state))
    }

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)

    private fun load(ctx: Context): JSONObject = try {
        JSONObject(file(ctx).readText())
    } catch (e: Exception) {
        JSONObject()
    }

    fun summary(ctx: Context): Summary? = summarize(load(ctx))

    fun enabled(ctx: Context): Boolean = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).getBoolean("set_fn_stats", true)
    fun setEnabled(ctx: Context, v: Boolean) = ctx.getSharedPreferences("binario", Context.MODE_PRIVATE).edit().putBoolean("set_fn_stats", v).apply()

    /**
     * Legge gli arrivi degli ultimi 90 minuti nelle stazioni osservate. Al massimo ogni 80 minuti con Wi-Fi e ogni
     * 3 ore con i dati mobili (circa 0,3 MB per giro). Restituisce il numero di arrivi aggiunti.
     */
    fun collect(ctx: Context, force: Boolean = false): Int {
        if (!enabled(ctx)) return 0
        val state = load(ctx)
        val now = System.currentTimeMillis()
        val metered = try {
            (ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
        } catch (e: Exception) {
            true
        }
        val last = state.optLong("at", 0L)
        val every = if (metered) 3 * 3600_000L else 80 * 60_000L
        if (!force && now - last < every) return 0
        if (force && now - last < 10 * 60_000L) return 0
        state.put("at", now)
        // Se l'ultimo giro è vecchio (telefono spento o in risparmio energetico) leggiamo anche la finestra precedente
        val starts = if (last > 0 && now - last > 170 * 60_000L) listOf(now - 180 * 60_000L, now - 90 * 60_000L) else listOf(now - 90 * 60_000L)
        var added = 0
        // Anche le stazioni FerrovieNord preferite dall'utente (al massimo 5 in più)
        val extra = try {
            FnNetwork.ensure(ctx)
            Store(ctx).favStations().filter { f -> FnNetwork.isFn(f.id) && STATIONS.none { it.id == f.id } }.take(5)
        } catch (e: Exception) {
            emptyList()
        }
        (STATIONS + extra).forEach { st ->
            starts.forEach { t ->
                try {
                    val a = Api.rawBoard("arrivi", st.id, t)
                    val items = (0 until a.length()).mapNotNull { i ->
                        val o = a.optJSONObject(i) ?: return@mapNotNull null
                        Obs(
                            number = o.optString("numeroTreno"),
                            otherEnd = o.optString("origine"),
                            sched = o.optLong("orarioArrivo"),
                            delay = if (o.isNull("ritardo")) 0 else o.optInt("ritardo"),
                            cancelled = o.optInt("provvedimento") == 1 || o.optBoolean("trenoSoppresso"),
                        )
                    }
                    added += ingest(state, st, items, now)
                } catch (_: Exception) {
                }
            }
        }
        try {
            file(ctx).writeText(state.toString())
        } catch (_: Exception) {
        }
        return added
    }
}
