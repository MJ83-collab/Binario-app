package com.binario.treni.data

import android.content.Context
import org.json.JSONArray

/**
 * Stazioni della rete FerrovieNord (e altre fermate Trenord) che l'elenco stazioni di ViaggiaTreno non contiene,
 * anche se ViaggiaTreno ne segue i treni in tempo reale: Varese Nord, Como Lago, Novara Nord, Laveno Lago,
 * Saronno Sud, Brescia–Iseo–Edolo… I codici sono gli stessi di ViaggiaTreno (es. Varese Nord = S01738), presi
 * dall'orario ufficiale Trenord (GTFS). Servono per "Stazioni vicine", mappe, rivendite, WC e ricerca.
 */
object FnNetwork {
    @Volatile
    var stations: List<Api.GeoStation> = emptyList()
        private set

    fun ensure(ctx: Context) {
        if (stations.isNotEmpty()) return
        stations = try {
            val a = JSONArray(ctx.applicationContext.assets.open("fn_stations.json").bufferedReader().use { it.readText() })
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Api.GeoStation(Station(o.getString("name"), o.getString("id")), o.getDouble("lat"), o.getDouble("lon"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun coord(id: String): Pair<Double, Double>? = stations.firstOrNull { it.station.id == id }?.let { it.lat to it.lon }

    /** Stazione della rete FerrovieNord (dall'elenco o tra quelle osservate per la puntualità). */
    fun isFn(id: String): Boolean = FnStats.isFnStation(id) || stations.any { it.station.id == id }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()

    fun search(q: String): List<Station> {
        val n = norm(q)
        if (n.length < 2) return emptyList()
        return stations.map { it.station }.filter { norm(it.name).contains(n) }
            .sortedBy { if (norm(it.name).startsWith(n)) 0 else 1 }.take(6)
    }
}
