package com.binario.treni.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/**
 * Un treno che l'utente prende spesso: stesso numero, stessa stazione di salita, più o meno alla stessa ora.
 * Tutto resta sul telefono: nessun dato di viaggio esce dall'app.
 */
data class Habit(
    val number: String,
    val category: String,
    val operator: String,
    /** Codice di origine ViaggiaTreno ("S01700"): stabile tra un giorno e l'altro. Per Svizzera e ferrovie locali resta vuoto. */
    val originCode: String,
    val board: Station,
    val alight: Station?,
    /** Partenza dalla stazione di salita, in minuti dalla mezzanotte. */
    val minute: Int,
    /** Quante volte è stato usato per ogni giorno della settimana (0 = lunedì … 6 = domenica). */
    val days: List<Int>,
    /** Ultimo giorno d'uso (mezzanotte, ms). */
    val lastDay: Long,
) {
    val key: String get() = Habits.digits(number) + "@" + board.id
    val title: String get() = listOf(operator.takeIf { it.isNotBlank() && !category.contains(it, true) }, category, Habits.digits(number))
        .filterNotNull().filter { it.isNotBlank() }.joinToString(" ")
    val timeText: String get() = "%d:%02d".format(minute / 60, minute % 60)
    val total: Int get() = days.sum()

    fun toJson(): JSONObject = JSONObject().put("n", number).put("c", category).put("op", operator).put("o", originCode)
        .put("b", board.toJson()).put("a", alight?.toJson()).put("m", minute).put("d", JSONArray(days)).put("l", lastDay)

    companion object {
        fun from(o: JSONObject): Habit {
            val d = o.optJSONArray("d") ?: JSONArray()
            return Habit(
                o.optString("n"), o.optString("c"), o.optString("op"), o.optString("o"),
                Station.from(o.getJSONObject("b")), o.optJSONObject("a")?.let { Station.from(it) },
                o.optInt("m"), (0 until 7).map { d.optInt(it) }, o.optLong("l"),
            )
        }
    }
}

/** Logica pura delle abitudini (senza Android: la usano anche i test). */
object Habits {
    /** Solo il numero (come Api.trainDigits, ripetuto qui per non dipendere dalla rete nei test). */
    fun digits(n: String): String = Regex("\\d{2,6}").findAll(n).lastOrNull()?.value ?: n.trim()

    private val rome: TimeZone = TimeZone.getTimeZone("Europe/Rome")
    private const val DAY = 86_400_000L

    /** Giorno della settimana a Roma, 0 = lunedì … 6 = domenica. */
    fun weekday(ms: Long): Int = Calendar.getInstance(rome).apply { timeInMillis = ms }.get(Calendar.DAY_OF_WEEK).let { (it + 5) % 7 }

    fun minuteOfDay(ms: Long): Int = Calendar.getInstance(rome).apply { timeInMillis = ms }.let {
        it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE)
    }

    fun midnight(ms: Long): Long = Calendar.getInstance(rome).apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Istante di oggi (a Roma) all'ora dell'abitudine. */
    fun todayAt(h: Habit, now: Long): Long = midnight(now) + h.minute * 60_000L

    /**
     * Registra un uso. Conta al massimo una volta al giorno per treno e stazione; aggiorna l'ora (gli orari
     * cambiano col cambio orario) e, se nota, la stazione di discesa. Le abitudini ferme da 60 giorni si dimenticano.
     */
    fun record(list: List<Habit>, h: Habit, now: Long): List<Habit> {
        val today = midnight(now)
        val wd = weekday(now)
        val old = list.firstOrNull { it.key == h.key }
        val merged = if (old == null) {
            h.copy(days = List(7) { if (it == wd) 1 else 0 }, lastDay = today)
        } else {
            val days = if (old.lastDay == today) old.days else old.days.mapIndexed { i, c -> if (i == wd) c + 1 else c }
            old.copy(
                category = h.category.ifBlank { old.category }, operator = h.operator.ifBlank { old.operator },
                originCode = h.originCode.ifBlank { old.originCode }, minute = h.minute,
                alight = h.alight ?: old.alight, board = h.board, days = days, lastDay = today,
            )
        }
        return (list.filter { it.key != h.key && today - it.lastDay < 60 * DAY } + merged)
            .sortedByDescending { it.lastDay }.take(40)
    }

    /**
     * Quanto è probabile che l'utente prenda questo treno oggi: almeno 2 volte nello stesso giorno della
     * settimana, oppure (nei feriali) almeno 3 volte tra lunedì e venerdì.
     */
    fun likelyToday(h: Habit, now: Long): Boolean {
        val wd = weekday(now)
        if (h.days.getOrElse(wd) { 0 } >= 2) return true
        return wd <= 4 && h.days.take(5).sum() >= 3
    }

    /** Il prossimo treno abituale: da 5 minuti fa alle prossime 3 ore, il più vicino. */
    fun next(list: List<Habit>, now: Long, aheadMin: Int = 180): Habit? {
        val m = minuteOfDay(now)
        return list.filter { likelyToday(it, now) && it.minute in (m - 5)..(m + aheadMin) }.minByOrNull { it.minute }
    }

    /** Treni abituali da controllare per gli avvisi: partono tra 0 e 45 minuti (o sono appena partiti). */
    fun dueForAlerts(list: List<Habit>, now: Long): List<Habit> {
        val m = minuteOfDay(now)
        return list.filter { likelyToday(it, now) && it.minute in (m - 2)..(m + 45) }
    }

    fun parse(text: String?): List<Habit> = try {
        val a = JSONArray(text ?: "[]")
        (0 until a.length()).mapNotNull { i -> runCatching { Habit.from(a.getJSONObject(i)) }.getOrNull() }
    } catch (e: Exception) {
        emptyList()
    }

    fun toText(list: List<Habit>): String = JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()
}
