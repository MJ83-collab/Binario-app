package com.binario.treni.ui

import android.annotation.SuppressLint
import com.binario.treni.data.tx
import android.Manifest
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.binario.treni.data.Api
import com.binario.treni.data.Osm
import com.binario.treni.data.OsmPlace
import com.binario.treni.data.Station
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.async
import com.binario.treni.data.Fmt
import com.binario.treni.data.TicketSellers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

private fun iconFor(k: OsmPlace.Kind): ImageVector = when (k) {
    OsmPlace.Kind.TICKET_OFFICE -> Icons.Filled.Storefront
    OsmPlace.Kind.TICKET_MACHINE -> Icons.Filled.ConfirmationNumber
    OsmPlace.Kind.VALIDATOR -> Icons.Filled.Nfc
    OsmPlace.Kind.RESELLER -> Icons.Filled.LocalConvenienceStore
    else -> Icons.Filled.Place
}

/**
 * Rivendite, biglietterie, emettitrici e obliteratrici vicino a una stazione (o alla posizione attuale),
 * con distanza, mappa e indicazione di pagamento contactless quando mappato.
 */
@Composable
fun SellersScreen(vm: MainViewModel, station: Station?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var center by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var places by remember { mutableStateOf<List<OsmPlace>?>(null) }
    var status by remember { mutableStateOf(tx("Ricerca della posizione…")) }
    var tab by remember { mutableIntStateOf(0) }
    var filter by remember { mutableStateOf<OsmPlace.Kind?>(null) }
    var onlyContactless by remember { mutableStateOf(false) }
    var radius by remember { mutableIntStateOf(800) }
    var retry by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    var osmDown by remember { mutableStateOf(false) }
    var pulling by remember { mutableStateOf(false) }
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED,
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> granted = r.values.any { it } }

    LaunchedEffect(station?.id, granted) {
        if (station != null) {
            center = withContext(Dispatchers.IO) { Api.stationCoord(vm.store, station.id) }
            if (center == null) status = tx("Coordinate della stazione non disponibili")
        } else if (granted) {
            val l = lastLocation(ctx)
            if (l != null) center = l.latitude to l.longitude else status = tx("Posizione non disponibile: apri prima la mappa o attiva il GPS.")
        } else {
            launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            status = tx("Serve il permesso di posizione")
        }
    }
    LaunchedEffect(center, radius, retry) {
        val c = center ?: return@LaunchedEffect
        if (!pulling) places = null
        failed = false; osmDown = false
        status = tx("Cerco i punti vendita entro") + " $radius m…"
        places = withContext(Dispatchers.IO) {
            coroutineScope {
                // Elenchi ufficiali (Trenord, FFS) e OpenStreetMap in parallelo: se uno non risponde restano gli altri
                // Lavori indipendenti: se uno resta appeso non blocca la schermata
                val official = kotlinx.coroutines.CoroutineScope(Dispatchers.IO).async {
                    val trenord: List<OsmPlace> = try {
                        TicketSellers.trenordNear(ctx.applicationContext, c.first, c.second, radius) { msg -> status = msg }
                            .map { (s, d) -> TicketSellers.toPlace(s, d) }
                    } catch (e: Exception) {
                        emptyList()
                    }
                    val bz: List<OsmPlace> = try {
                        TicketSellers.altoAdigeNear(ctx.applicationContext, c.first, c.second, radius) { msg -> status = msg }
                            .map { (s, d) -> TicketSellers.toPlace(s, d) }
                    } catch (e: Exception) {
                        emptyList()
                    }
                    val sbb: List<OsmPlace> = try {
                        TicketSellers.sbbMachines(c.first, c.second, radius).map { (s, d) -> TicketSellers.toPlace(s, d) }
                    } catch (e: Exception) {
                        emptyList()
                    }
                    trenord + bz + sbb
                }
                val osm = kotlinx.coroutines.CoroutineScope(Dispatchers.IO).async {
                    try {
                        Osm.ticketPlaces(c.first, c.second, radius)
                    } catch (e: Exception) {
                        osmDown = true; emptyList()
                    }
                }
                // Mai più di 30 secondi di attesa: quello che è arrivato si mostra, il resto si riprova con "Riprova"
                val deadline = System.currentTimeMillis() + 30_000
                val o = withTimeoutOrNull(30_000) { official.await() } ?: emptyList()
                val osmList = withTimeoutOrNull((deadline - System.currentTimeMillis()).coerceAtLeast(1_000)) { osm.await() }
                    ?: run { osmDown = true; emptyList() }
                // Un punto OpenStreetMap a meno di 40 m da uno ufficiale dello stesso tipo è lo stesso punto
                val extra = osmList.filter { p ->
                    o.none { q -> q.kind == p.kind && Math.abs(q.lat - p.lat) < 0.0004 && Math.abs(q.lon - p.lon) < 0.0005 }
                }
                (o + extra).sortedBy { it.distance }
            }
        }
        if (places.isNullOrEmpty() && osmDown) {
            failed = true
            status = tx("Nessun punto vendita trovato e i server OpenStreetMap non rispondono. Usa la mappa ufficiale Trenitalia o riprova.")
        }
        pulling = false
    }
    val gmaps = listOf(tx("Biglietterie") to "biglietteria treni", tx("Punti Mooney") to "Mooney punto vendita", "PuntoLIS" to "PuntoLIS Lottomatica")

    val shown = places.orEmpty().filter { (filter == null || it.kind == filter) && (!onlyContactless || it.contactless) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(if (station != null) "Rivendite · ${station.name}" else tx("Rivendite vicine"), onBack)
        if (vm.store.mapsEnabled) GreenTabs(listOf(tx("Elenco"), tx("Mappa")), tab) { tab = it }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp)) {
            FilterChip(filter == null, { filter = null }, label = { Text(tx("Tutto")) }, modifier = Modifier.padding(end = 6.dp))
            listOf(OsmPlace.Kind.TICKET_OFFICE, OsmPlace.Kind.TICKET_MACHINE, OsmPlace.Kind.VALIDATOR, OsmPlace.Kind.RESELLER).forEach { k ->
                FilterChip(filter == k, { filter = if (filter == k) null else k }, label = { Text(k.label) },
                    leadingIcon = { Icon(iconFor(k), null, Modifier.size(16.dp)) }, modifier = Modifier.padding(end = 6.dp))
            }
            FilterChip(onlyContactless, { onlyContactless = !onlyContactless }, label = { Text(tx("Contactless")) },
                leadingIcon = { Icon(Icons.Filled.Contactless, null, Modifier.size(16.dp)) })
        }
        val p = places
        if (failed || p == null) when {
            p == null || failed -> Column {
                MessageBox(status)
                val c = center
                if (failed && c != null) Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    OutlinedButton({ retry++ }) { Text(tx("Riprova"), color = Green) }
                    TrenitaliaMapButton()
                    Text(tx("Cerca su Google Maps:"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    GoogleMapsButtons(c.first, c.second, gmaps)
                }
            }
        } else if (tab == 1 && vm.store.mapsEnabled) OsmMap(
                shown.map { MapPoint(it.lat, it.lon, "${it.kind.label}: ${it.name}", "${it.distance} m" + (if (it.contactless) tx(" · contactless") else "")) },
                drawLine = false, modifier = Modifier.fillMaxSize(),
                me = if (station == null) center else null,
                googleQuery = "biglietteria treni",
            )
        else PullRefresh(pulling, { pulling = true; retry++ }) {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 4.dp)) {
                if (shown.isEmpty()) item {
                    MessageBox(tx("Nessun punto vendita entro") + " $radius m.")
                    if (radius < 2000) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        OutlinedButton({ radius = 2000 }) { Text(tx("Cerca entro 2 km"), color = Green) }
                    }
                }
                items(shown) { s -> PlaceRow(s) }
                item {
                    center?.let { c ->
                        Column(Modifier.padding(horizontal = 8.dp)) {
                            Text(tx("Non trovi quello che cerchi? Cerca su Google Maps:"), color = Muted, fontSize = 13.sp,
                                modifier = Modifier.padding(start = 8.dp, top = 8.dp))
                            GoogleMapsButtons(c.first, c.second, gmaps)
                        }
                    }
                    Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        TrenitaliaMapButton()
                    }
                    val upd = TicketSellers.updatedAt(ctx)
                    Text(
                        tx("Fonti") + ": " +
                            listOfNotNull(
                                tx("rivendite autorizzate e biglietterie Trenord") + (if (upd > 0) " (" + tx("elenco del") + " " + Fmt.day(upd) + ", " + tx("si aggiorna ogni settimana; aperto/chiuso letto ora") + ")" else ""),
                                tx("punti vendita altoadigemobilità (Alto Adige)"),
                                tx("biglietterie automatiche FFS (dati aperti data.sbb.ch)"),
                                tx("biglietterie, emettitrici e obliteratrici da") + " " + Osm.lastSource.ifBlank { "OpenStreetMap" },
                            ).joinToString("; ") + ". " +
                            tx("Nel resto d'Italia i biglietti regionali Trenitalia si comprano nei punti PuntoLIS e Mooney: li mostra la mappa ufficiale Trenitalia."),
                        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp),
                    )
                    SourceLink("Trenord · punti vendita", TicketSellers.TRENORD_SITE, Modifier.padding(horizontal = 16.dp))
                    SourceLink("Trenitalia · punti vendita", TicketSellers.TRENITALIA_INFO, Modifier.padding(horizontal = 16.dp))
                    SourceLink("altoadigemobilità · punti vendita", TicketSellers.BZ_SITE, Modifier.padding(horizontal = 16.dp))
                    SourceLink("FFS · billetautomat", TicketSellers.SBB_DATA, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
        }
    }
}

/** Mappa ufficiale Trenitalia dei punti vendita (tutta Italia, con raggio da 350 m a 5 km e filtro "Altri punti vendita"). */
@Composable
private fun TrenitaliaMapButton() {
    val ctx = LocalContext.current
    OutlinedButton({ openUrl(ctx, TicketSellers.TRENITALIA_MAP) }) {
        Icon(Icons.Filled.Map, null, Modifier.size(18.dp), tint = Green)
        Spacer(Modifier.width(6.dp))
        Text(tx("Mappa ufficiale Trenitalia (tutta Italia)"), color = Green)
    }
}

@Composable
private fun PlaceRow(s: OsmPlace) {
    val ctx = LocalContext.current
    WhiteCard(onClick = {
        openUrl(ctx, "geo:${s.lat},${s.lon}?q=${s.lat},${s.lon}(${android.net.Uri.encode(s.name)})")
    }) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(iconFor(s.kind), null, tint = Green, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.name, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                Text(s.kind.label + (if (s.operator.isNotBlank() && s.operator != s.name) " · ${s.operator}" else "") +
                    (if (s.tags["x_official"] == "yes") " ✓" else ""), color = Muted, fontSize = 13.sp)
                s.tags["x_status"]?.let { st ->
                    Text(st, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                        color = if (st.startsWith("Aperto", true)) Green else com.binario.treni.data.ColorBlind.late.let { Color(it.toInt()) })
                }
                s.tags["x_near"]?.let { Text(tx("Stazione più vicina") + ": $it", color = Muted, fontSize = 13.sp) }
                s.tags["x_address"]?.let { Text(it, color = Muted, fontSize = 13.sp) }
                s.tags["x_services"]?.let { Text(tx("Vende") + ": $it", color = Muted, fontSize = 12.sp, maxLines = 2) }
                val badges = listOfNotNull(
                    if (s.contactless) tx("📶 contactless") else if (s.cards) tx("💳 carte") else null,
                    if (s.wheelchair == "yes") "♿" else null,
                    s.hours.takeIf { it.isNotBlank() }?.let { "🕒 $it" },
                )
                if (badges.isNotEmpty()) Text(badges.joinToString("  "), fontSize = 13.sp, color = Color(0xFF555555))
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(if (s.distance < 1000) "${s.distance} m" else String.format("%.1f km", s.distance / 1000.0), fontWeight = FontWeight.Bold)
                Text("${(s.distance / 80).coerceAtLeast(1)} min a piedi", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@SuppressLint("MissingPermission")
private fun lastLocation(ctx: android.content.Context): android.location.Location? = try {
    val lm = ctx.getSystemService(LocationManager::class.java)
    lm?.getProviders(true)?.mapNotNull { p ->
        try {
            lm.getLastKnownLocation(p)
        } catch (e: SecurityException) {
            null
        }
    }?.maxByOrNull { it.time }
} catch (e: Exception) {
    null
}
