package com.binario.treni.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.Icon
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

data class MapPoint(val lat: Double, val lon: Double, val title: String, val snippet: String = "", val onClick: (() -> Unit)? = null)

/**
 * Tessere della mappa. CARTO dal 2026 chiede una chiave a pagamento (mostrava "API KEY REQUIRED"),
 * quindi usiamo le tessere ufficiali di OpenStreetMap; se non rispondono passiamo a OpenStreetMap France.
 * Nessuna chiave necessaria; l'app si identifica con il proprio nome come chiede la policy OSM.
 */
private val OsmStandard: OnlineTileSourceBase = XYTileSource(
    "OsmStandard", 0, 19, 256, ".png",
    arrayOf("https://tile.openstreetmap.org/"),
    "© OpenStreetMap contributors",
)
private val OsmFrance: OnlineTileSourceBase = XYTileSource(
    "OsmFrance", 0, 19, 256, ".png",
    arrayOf(
        "https://a.tile.openstreetmap.fr/osmfr/",
        "https://b.tile.openstreetmap.fr/osmfr/",
        "https://c.tile.openstreetmap.fr/osmfr/",
    ),
    "© OpenStreetMap contributors · OSM France",
)

/** Sorgente scelta dopo la prova (null = non ancora provata). */
@Volatile private var chosenSource: OnlineTileSourceBase? = null

/** Prova una tessera: risponde con un'immagine PNG? */
private fun tileWorks(url: String): Boolean = try {
    val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
        connectTimeout = 6000; readTimeout = 8000
        setRequestProperty("User-Agent", org.osmdroid.config.Configuration.getInstance().userAgentValue)
    }
    try {
        c.responseCode == 200 && (c.contentType ?: "").startsWith("image")
    } finally {
        c.disconnect()
    }
} catch (e: Exception) {
    false
}

private fun pickSource(map: MapView) {
    chosenSource?.let { if (map.tileProvider.tileSource.name() != it.name()) map.setTileSource(it); return }
    Thread {
        val src = when {
            tileWorks("https://tile.openstreetmap.org/6/33/23.png") -> OsmStandard
            tileWorks("https://a.tile.openstreetmap.fr/osmfr/6/33/23.png") -> OsmFrance
            else -> OsmStandard
        }
        chosenSource = src
        map.post { if (map.tileProvider.tileSource.name() != src.name()) map.setTileSource(src) }
    }.start()
}

/** Apre Google Maps sul punto (o sul centro dei punti), con una ricerca facoltativa. */
fun openGoogleMapsAt(ctx: android.content.Context, lat: Double, lon: Double, query: String?) {
    if (!query.isNullOrBlank()) {
        googleMaps(ctx, lat, lon, query)
        return
    }
    val url = "https://www.google.com/maps/search/?api=1&query=$lat,$lon"
    try {
        ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            .setPackage("com.google.android.apps.maps"))
    } catch (e: Exception) {
        openUrl(ctx, url)
    }
}

/** Mappa OpenStreetMap (nessuna chiave API necessaria). */
@Composable
fun OsmMap(
    points: List<MapPoint>,
    drawLine: Boolean,
    modifier: Modifier = Modifier,
    me: Pair<Double, Double>? = null,
    googleQuery: String? = null,
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Box(modifier.clipToBounds()) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            MapView(c).apply {
                setTileSource(chosenSource ?: OsmStandard)
                pickSource(this)
                setTilesScaledToDpi(true)
                setMultiTouchControls(true)
                setMinZoomLevel(4.0)
                setMaxZoomLevel(19.0)
                controller.setZoom(6.0)
                controller.setCenter(GeoPoint(42.5, 12.5))
            }
        },
        update = update@{ map ->
            // Ridisegna e ricentra solo se i punti sono cambiati (evita ricaricamenti a ogni aggiornamento dello schermo)
            val sig = points.joinToString("|") { "${it.lat},${it.lon},${it.title}" } + "|" + me + "|" + drawLine
            if (map.tag == sig) return@update
            map.tag = sig
            map.overlays.clear()
            val gps = points.map { GeoPoint(it.lat, it.lon) }
            if (drawLine && gps.size > 1) {
                map.overlays.add(Polyline(map).apply {
                    setPoints(gps)
                    outlinePaint.color = android.graphics.Color.rgb(46, 158, 68)
                    outlinePaint.strokeWidth = 10f
                })
            }
            points.forEachIndexed { i, p ->
                map.overlays.add(Marker(map).apply {
                    position = gps[i]
                    title = p.title
                    snippet = p.snippet
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    if (p.onClick != null) setOnMarkerClickListener { m, _ ->
                        if (m.isInfoWindowShown) p.onClick?.invoke() else m.showInfoWindow()
                        true
                    }
                })
            }
            if (me != null) {
                map.overlays.add(Marker(map).apply {
                    position = GeoPoint(me.first, me.second)
                    title = com.binario.treni.data.tx("La tua posizione")
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                })
            }
            map.overlays.add(org.osmdroid.views.overlay.CopyrightOverlay(map.context))
            val all = gps + listOfNotNull(me?.let { GeoPoint(it.first, it.second) })
            if (all.size > 1) {
                map.post { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(all).increaseByScale(1.25f), false) }
            } else if (all.size == 1) {
                map.controller.setZoom(14.0); map.controller.setCenter(all[0])
            }
            map.invalidate()
        },
        onRelease = { it.onDetach() },
    )
    // Google Maps sempre a portata di tasto, anche se le tessere non si caricano
    val target = when {
        me != null -> me
        points.size == 1 -> points[0].lat to points[0].lon
        points.isNotEmpty() -> points.map { it.lat }.average() to points.map { it.lon }.average()
        else -> null
    }
    if (target != null) {
        SmallFloatingActionButton(
            onClick = { openGoogleMapsAt(ctx, target.first, target.second, googleQuery) },
            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
            containerColor = Color.White, contentColor = Green,
        ) {
            Row(Modifier.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Map, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Google Maps", fontSize = 13.sp)
            }
        }
    }
    }
}
