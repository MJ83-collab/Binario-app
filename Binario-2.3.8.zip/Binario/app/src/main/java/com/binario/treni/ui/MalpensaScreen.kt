package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.MalpensaFares
import com.binario.treni.data.Stibm
import com.binario.treni.data.TrenordFares
import com.binario.treni.data.tx

/** Tariffario Malpensa Express: prezzi da ogni stazione, differenze tra le due linee e limitazioni. */
@Composable
fun MalpensaScreen(onBack: () -> Unit, highlight: String? = null) {
    val ctx = LocalContext.current
    val focus = remember(highlight) { highlight?.let { MalpensaFares.forStation(it) }.orEmpty() }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Malpensa Express · tariffe"), onBack)
        LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
            item {
                WhiteCard {
                    Column(Modifier.padding(16.dp)) {
                        Text(tx("Da o per l'aeroporto di Malpensa (Terminal 1 e 2) serve la tariffa aeroportuale. Prezzi in vigore dal") + " " +
                            TrenordFares.VALID_FROM + ".", fontSize = 14.sp)
                        Row(Modifier.padding(top = 8.dp)) {
                            Highlight(tx("Milano ⇄ Malpensa"), Stibm.eur(15.0))
                            Spacer(Modifier.width(16.dp))
                            Highlight(tx("A/R"), Stibm.eur(25.0))
                            Spacer(Modifier.width(16.dp))
                            Highlight("Family", Stibm.eur(MalpensaFares.FAMILY))
                        }
                    }
                }
            }
            item {
                WhiteCard {
                    CardTitle(tx("Le due linee"))
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                        MalpensaFares.LINES.forEach { (t, d) ->
                            Text(t, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
                            Text(tx(d), fontSize = 13.sp)
                        }
                    }
                }
            }
            item { SectionHeader(tx("Prezzi da ogni stazione")) }
            val list = focus + MalpensaFares.ORIGINS.filter { it !in focus }
            items(list) { o ->
                WhiteCard {
                    Column(Modifier.padding(14.dp)) {
                        Text(o.name + " ⇄ Malpensa", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if (o in focus) Green else MaterialTheme.colorScheme.onSurface)
                        if (o.via.isNotBlank()) Text(tx(o.via), color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        MxpRow(tx("Corsa semplice adulti / ragazzi"), Stibm.eur(o.single) + " / " + Stibm.eur(o.singleKid))
                        if (o.returnDay != null && o.returnDayKid != null) {
                            MxpRow(tx("Andata e ritorno in giornata"), Stibm.eur(o.returnDay) + " / " + Stibm.eur(o.returnDayKid))
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                            Spacer(Modifier.weight(1f))
                            Text(tx("2ª cl."), color = Muted, fontSize = 12.sp, modifier = Modifier.width(78.dp))
                            Text(tx("1ª cl."), color = Muted, fontSize = 12.sp, modifier = Modifier.width(78.dp))
                        }
                        Mxp2(tx("Abbonamento settimanale"), o.week2, o.week1)
                        Mxp2(tx("Abbonamento mensile"), o.month2, o.month1)
                        Mxp2(tx("Abbonamento annuale"), o.year2, o.year1)
                    }
                }
            }
            item {
                WhiteCard {
                    CardTitle(tx("Altri biglietti"))
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                        MxpRow(tx("A/R entro 30 giorni (solo online), adulti / ragazzi"), Stibm.eur(MalpensaFares.RETURN_30_DAYS) + " / " + Stibm.eur(MalpensaFares.RETURN_30_DAYS_KID))
                        MxpRow(tx("Malpensa Family (2 adulti + 2 ragazzi 4–17)"), Stibm.eur(MalpensaFares.FAMILY))
                        MxpRow(tx("Transfer Terminal 1 ⇄ Terminal 2, adulti / ragazzi"), Stibm.eur(MalpensaFares.TRANSFER_T1_T2) + " / " + Stibm.eur(MalpensaFares.TRANSFER_T1_T2_KID))
                    }
                }
            }
            item {
                WhiteCard {
                    CardTitle(tx("Regole e limitazioni"))
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                        MalpensaFares.RULES.forEach { r -> Text("• " + tx(r), fontSize = 13.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                        Text(tx("Nota: la pagina abbonamenti di malpensaexpress.it indica prezzi \"a partire da\" più bassi (25 € settimanale, 87 € mensile, 840 € annuale): qui ci sono quelli del tariffario Trenord in vigore."),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            item {
                Row(Modifier.padding(horizontal = 8.dp)) {
                    TextButton({ openUrl(ctx, MalpensaFares.PAGE) }) { Text("malpensaexpress.it", color = Green) }
                    TextButton({ openUrl(ctx, TrenordFares.SOURCE_PDF) }) { Text(tx("Tariffario ufficiale"), color = Green) }
                    TextButton({ openUrl(ctx, MalpensaFares.LINES_PAGE) }) { Text(tx("Linee"), color = Green) }
                }
            }
        }
    }
}

@Composable
private fun Highlight(label: String, value: String) {
    Column {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Green)
        Text(label, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun MxpRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun Mxp2(label: String, second: Double, first: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(Stibm.eur(second), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.width(78.dp))
        Text(Stibm.eur(first), color = Muted, fontSize = 14.sp, modifier = Modifier.width(78.dp))
    }
}
