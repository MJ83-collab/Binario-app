package com.binario.treni.ui

import com.binario.treni.data.tx
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.LocalOffer
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Fmt
import com.binario.treni.data.SearchFilter
import com.binario.treni.data.Tratta
import java.util.Calendar
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    vm: MainViewModel, onSearch: () -> Unit, onAdvanced: () -> Unit, onBot: () -> Unit = {},
    go: (String) -> Unit = {}, onTrain: (com.binario.treni.data.TrainRef) -> Unit = {},
) {
    val ctx = LocalContext.current
    var picking by remember { mutableStateOf<Int?>(null) } // 0 = partenza, 1 = arrivo
    var dateDialog by remember { mutableStateOf<Int?>(null) } // 0 andata, 1 ritorno
    var timeDialog by remember { mutableStateOf<Int?>(null) }
    var filterDialog by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    val routes = remember(refresh) { vm.store.recentAndFav() }

    fun go() {
        if (vm.from == null || vm.to == null) {
            toast(ctx, tx("Scegli stazione di partenza e di arrivo")); return
        }
        if (vm.from?.id == vm.to?.id) {
            toast(ctx, tx("Partenza e arrivo coincidono")); return
        }
        vm.search()
        onSearch()
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Cerca orario")) {
            IconButton(onBot) { Icon(Icons.Filled.Forum, tx("Assistente treni")) }
            LanguageFlags(vm)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            // ---- Intestazione verde con i campi stazione ----
            item {
                Row(
                    Modifier.fillMaxWidth().background(Green).padding(start = 12.dp, end = 12.dp, bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        StationField(vm.from?.name, tx("Partenza")) { picking = 0 }
                        Spacer(Modifier.height(6.dp))
                        StationField(vm.to?.name, tx("Arrivo")) { picking = 1 }
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(
                        Modifier.width(48.dp).height(98.dp).clip(RoundedCornerShape(6.dp)).background(GreenField)
                            .clickable { vm.swap() },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.SwapVert, tx("Inverti"), tint = Color.White) }
                }
            }
            // ---- Opzioni ----
            item {
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Column {
                        OptionRow(Icons.Filled.SyncAlt, tx("Andata e Ritorno"), onClick = { vm.roundTrip = !vm.roundTrip }) {
                            Switch(
                                checked = vm.roundTrip, onCheckedChange = { vm.roundTrip = it },
                                colors = SwitchDefaults.colors(checkedTrackColor = Green),
                            )
                        }
                        HorizontalDivider(Modifier.padding(start = 56.dp))
                        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                            Spacer(Modifier.width(16.dp))
                            Icon(Icons.Filled.CalendarToday, null, tint = Color.Gray, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(18.dp))
                            DateTimeText(vm.date, true, { dateDialog = 0 }, { timeDialog = 0 })
                            Box(Modifier.padding(horizontal = 10.dp).width(1.dp).height(28.dp).background(Color(0x22000000)))
                            DateTimeText(vm.returnDate, vm.roundTrip, { if (vm.roundTrip) dateDialog = 1 }, { if (vm.roundTrip) timeDialog = 1 })
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = {
                                vm.date = MainViewModel.roundToQuarter(System.currentTimeMillis())
                                vm.returnDate = vm.date + 3 * 3600_000L
                            }) { Icon(Icons.Filled.Update, tx("Adesso"), tint = Green) }
                        }
                        HorizontalDivider(Modifier.padding(start = 56.dp))
                        OptionRow(Icons.Outlined.LocalOffer, vm.filter.label, onClick = { filterDialog = true })
                        HorizontalDivider(Modifier.padding(start = 56.dp))
                        OptionRow(
                            Icons.Outlined.Settings,
                            tx("Opzioni avanzate") + advancedSummary(vm.maxChanges, vm.excluded),
                            onClick = onAdvanced,
                        )
                        Button(
                            onClick = { go() },
                            colors = ButtonDefaults.buttonColors(containerColor = Green),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth().padding(12.dp).height(50.dp),
                        ) { Text(tx("Cerca"), fontSize = 18.sp) }
                    }
                }
            }
            // ---- Viaggio in corso (come la "live journey" delle app di viaggio) ----
            item { LiveTripCard(vm, onTrain) }
            item {
                NextTrainCard(vm, onTrain) { b, a ->
                    vm.from = b
                    if (a != null) vm.to = a
                    vm.date = MainViewModel.roundToQuarter(System.currentTimeMillis())
                    if (a != null) { go() } else { picking = 1 }
                }
            }
            // ---- Azioni rapide ----
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 8.dp)) {
                    QuickAction(Icons.Filled.Mic, tx("Chiedi a voce")) { go("bot?voice=true") }
                    QuickAction(Icons.Filled.NearMe, tx("Stazioni vicine")) { go("nearby") }
                    QuickAction(Icons.Filled.Campaign, tx("Scioperi e notizie")) { go("news") }
                    QuickAction(Icons.Filled.DownloadForOffline, tx("Orari offline")) { go("saved") }
                    QuickAction(Icons.Filled.Alarm, tx("Allarmi")) { go("reminders") }
                }
            }
            // ---- Recenti e preferite ----
            if (routes.isNotEmpty()) item { SectionHeader(tx("Recenti e preferite")) }
            items(routes, key = { it.first.key }) { (r, fav) ->
                RouteRow(r, fav,
                    onStar = { vm.store.toggleFavRoute(r); refresh++ },
                    onSearch = { vm.from = r.from; vm.to = r.to; go() },
                    onFill = { vm.from = r.from; vm.to = r.to },
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    // ---- Dialog ----
    picking?.let { which ->
        StationPickerDialog(if (which == 0) tx("Stazione di partenza") else tx("Stazione di arrivo"), { picking = null }) { s ->
            if (which == 0) vm.from = s else vm.to = s
            picking = null
        }
    }
    dateDialog?.let { which ->
        val current = if (which == 0) vm.date else vm.returnDate
        val st = rememberDatePickerState(initialSelectedDateMillis = toUtcMidnight(current))
        DatePickerDialog(
            onDismissRequest = { dateDialog = null },
            confirmButton = {
                TextButton({
                    st.selectedDateMillis?.let { utc ->
                        val v = withDate(current, utc)
                        if (which == 0) vm.date = v else vm.returnDate = v
                        if (which == 0 && vm.returnDate < vm.date) vm.returnDate = vm.date + 3 * 3600_000L
                    }
                    dateDialog = null
                }) { Text("OK", color = Green) }
            },
            dismissButton = { TextButton({ dateDialog = null }) { Text(tx("Annulla")) } },
        ) { DatePicker(st) }
    }
    timeDialog?.let { which ->
        val current = if (which == 0) vm.date else vm.returnDate
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Europe/Rome")).apply { timeInMillis = current }
        val st = rememberTimePickerState(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true)
        AlertDialog(
            onDismissRequest = { timeDialog = null },
            confirmButton = {
                TextButton({
                    cal.set(Calendar.HOUR_OF_DAY, st.hour); cal.set(Calendar.MINUTE, st.minute)
                    if (which == 0) vm.date = cal.timeInMillis else vm.returnDate = cal.timeInMillis
                    timeDialog = null
                }) { Text("OK", color = Green) }
            },
            dismissButton = { TextButton({ timeDialog = null }) { Text(tx("Annulla")) } },
            text = { TimePicker(st) },
        )
    }
    if (filterDialog) {
        AlertDialog(
            onDismissRequest = { filterDialog = false },
            title = { Text(tx("Tipo di soluzioni")) },
            text = {
                Column {
                    SearchFilter.entries.forEach { f ->
                        Row(
                            Modifier.fillMaxWidth().clickable { vm.filter = f; filterDialog = false },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(vm.filter == f, { vm.filter = f; filterDialog = false })
                            Text(f.label)
                        }
                    }
                }
            },
            confirmButton = {},
        )
    }
}

fun advancedSummary(max: Int, ex: Set<String>): String {
    val parts = mutableListOf<String>()
    if (max == 0) parts += tx("solo diretti") else if (max > 0) parts += "max $max cambi"
    if (ex.isNotEmpty()) parts += "escluse ${ex.size}"
    return if (parts.isEmpty()) "" else " · " + parts.joinToString(", ")
}

@Composable
fun StationField(value: String?, hint: String, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(6.dp)).background(GreenField)
            .clickable(onClick = onClick).padding(horizontal = 12.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Text(value ?: hint, color = if (value == null) Color(0xCCFFFFFF) else Color.White, fontSize = 17.sp, maxLines = 1)
    }
}

@Composable
private fun OptionRow(icon: ImageVector, text: String, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().height(56.dp).clickable(onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Color.Gray, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun DateTimeText(ms: Long, enabled: Boolean, onDate: () -> Unit, onTime: () -> Unit) {
    val c = if (enabled) MaterialTheme.colorScheme.onSurface else Color.LightGray
    Row {
        Text(Fmt.day(ms), color = c, fontSize = 16.sp, modifier = Modifier.clickable(onClick = onDate).padding(vertical = 8.dp))
        Spacer(Modifier.width(6.dp))
        Text(Fmt.time(ms), color = c, fontSize = 16.sp, modifier = Modifier.clickable(onClick = onTime).padding(vertical = 8.dp))
    }
}

@Composable
private fun RouteRow(r: Tratta, fav: Boolean, onStar: () -> Unit, onSearch: () -> Unit, onFill: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onFill).padding(start = 16.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(r.from.name, fontSize = 15.sp)
                Text(r.to.name, fontSize = 15.sp)
            }
            IconButton(onClick = onStar) {
                Icon(if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder, tx("Preferito"), tint = Green)
            }
            IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, tx("Cerca"), tint = Green) }
        }
    }
    HorizontalDivider(Modifier.padding(start = 16.dp))
}

// ---- Utilità data: il DatePicker lavora in UTC ----
private val romeTz: TimeZone = TimeZone.getTimeZone("Europe/Rome")

fun toUtcMidnight(local: Long): Long {
    val l = Calendar.getInstance(romeTz).apply { timeInMillis = local }
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(l.get(Calendar.YEAR), l.get(Calendar.MONTH), l.get(Calendar.DAY_OF_MONTH))
    }.timeInMillis
}

fun withDate(local: Long, utcMidnight: Long): Long {
    val u = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utcMidnight }
    return Calendar.getInstance(romeTz).apply {
        timeInMillis = local
        set(u.get(Calendar.YEAR), u.get(Calendar.MONTH), u.get(Calendar.DAY_OF_MONTH))
    }.timeInMillis
}

/** Bandierine per scegliere la lingua: 🇮🇹 italiano, 🇬🇧 inglese. */
@Composable
fun LanguageFlags(vm: MainViewModel) {
    val current = com.binario.treni.data.I18n.lang
    listOf("it" to "🇮🇹", "en" to "🇬🇧").forEach { (code, flag) ->
        Box(
            Modifier.padding(horizontal = 2.dp).clip(RoundedCornerShape(6.dp))
                .background(if (current == code) Color(0x55FFFFFF) else Color.Transparent)
                .clickable {
                    com.binario.treni.data.I18n.lang = code
                    vm.store.lang = code
                }
                .padding(horizontal = 6.dp, vertical = 4.dp),
        ) { Text(flag, fontSize = 22.sp) }
    }
}


@Composable
private fun QuickAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(label, fontSize = 13.sp) },
        leadingIcon = { Icon(icon, null, tint = Green, modifier = Modifier.size(18.dp)) },
        modifier = Modifier.padding(end = 6.dp),
    )
}

/** Il treno che stai seguendo, aggiornato ogni minuto: stato, dove salire, prossima fermata e binario. */
@Composable
private fun LiveTripCard(vm: MainViewModel, onTrain: (com.binario.treni.data.TrainRef) -> Unit) {
    val ctx = LocalContext.current
    var ref by remember { mutableStateOf(vm.store.tracked()) }
    val r = ref ?: return
    var st by remember(r.key) { mutableStateOf<com.binario.treni.data.TrainStatus?>(null) }
    LaunchedEffect(r.key) {
        while (true) {
            try {
                st = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.binario.treni.data.Api.status(r) }
            } catch (_: Exception) {
            }
            kotlinx.coroutines.delay(60_000L)
        }
    }
    WhiteCard(onClick = { onTrain(st?.ref ?: r) }) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Train, null, tint = Green)
                Spacer(Modifier.width(8.dp))
                Text(tx("Viaggio in corso"), color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton({ com.binario.treni.service.TrackingService.stop(ctx); ref = null }) { Text(tx("Smetti"), color = Muted) }
            }
            val s = st
            if (s == null) {
                Text(r.label, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                Text(tx("Aggiornamento…"), color = Muted, fontSize = 13.sp)
            } else {
                Text("${s.title} · ${s.origin} → ${s.destination}", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                Text(s.stateText(), color = if (s.cancelled || s.delay >= 5) LateRed else Green, fontWeight = FontWeight.Medium)
                val board = vm.store.boardingStation()?.let { b -> s.stops.firstOrNull { it.id == b.id || it.name.equals(b.name, true) } }
                if (board != null && !board.passed) {
                    val p = board.realPlatform.ifBlank { board.schedPlatform }
                    Text(tx("Sali a") + " ${board.name} " + tx("alle") + " " +
                        com.binario.treni.data.Fmt.time((if (board.schedDep > 0) board.schedDep else board.schedArr) + s.delay * 60_000L) +
                        (if (p.isNotBlank()) " · " + tx("binario") + " $p" else ""), fontSize = 15.sp)
                } else s.nextStop?.let { n ->
                    val p = n.realPlatform.ifBlank { n.schedPlatform }
                    Text(tx("Prossima fermata") + ": ${n.name} " +
                        com.binario.treni.data.Fmt.time((if (n.schedArr > 0) n.schedArr else n.schedDep) + s.delay * 60_000L) +
                        (if (p.isNotBlank()) " · " + tx("binario") + " $p" else ""), fontSize = 15.sp)
                }
                vm.store.wakeTarget()?.let { w -> Text("⏰ " + tx("Sveglia prima di") + " ${w.name}", color = Muted, fontSize = 13.sp) }
            }
        }
    }
}
