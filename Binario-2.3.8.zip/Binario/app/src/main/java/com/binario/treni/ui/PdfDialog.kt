package com.binario.treni.ui

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Fmt
import com.binario.treni.data.Station
import com.binario.treni.data.Store
import com.binario.treni.data.TimetablePdf
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Scarica l'orario completo di un giorno in PDF (andata e ritorno), da consultare anche offline. */
@Composable
fun PdfTimetableDialog(from: Station, to: Station, initialDay: Long, store: Store, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val today = Fmt.midnight()
    val days = listOf(today, today + 86_400_000L, today + 2 * 86_400_000L)
    var day by remember { mutableLongStateOf(Fmt.midnight(initialDay).takeIf { it >= today } ?: today) }
    var withReturn by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        icon = { Icon(Icons.Filled.PictureAsPdf, null, tint = Green) },
        title = { Text(tx("Orario in PDF")) },
        text = {
            Column {
                Text("${from.name} → ${to.name}", fontSize = 16.sp)
                Text(tx("Tutte le corse del giorno, da salvare nel telefono e consultare anche senza connessione."), color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Row {
                    (days + listOf(Fmt.midnight(initialDay))).distinct().sorted().forEach { d ->
                        FilterChip(d == day, { day = d }, label = {
                            Text(when (d) {
                                today -> tx("Oggi")
                                today + 86_400_000L -> tx("Domani")
                                else -> Fmt.day(d)
                            })
                        }, modifier = Modifier.padding(end = 6.dp), enabled = !busy)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(withReturn, { withReturn = it }, enabled = !busy)
                    Text(tx("Includi il ritorno") + " (${to.name} → ${from.name})", fontSize = 14.sp)
                }
                if (busy) {
                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Green)
                    Text(progress, color = Muted, fontSize = 13.sp)
                }
                error?.let { Text(it, color = LateRed, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                result?.let {
                    Text(tx("Salvato in Download/Binario."), color = Green, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                    Row {
                        TextButton({ if (!TimetablePdf.open(ctx, it)) toast(ctx, tx("Nessuna app per aprire i PDF")) }) { Text(tx("Apri"), color = Green) }
                        TextButton({ TimetablePdf.share(ctx, it) }) { Text(tx("Condividi"), color = Green) }
                    }
                }
            }
        },
        confirmButton = {
            if (result == null) Button({
                busy = true; error = null
                scope.launch {
                    try {
                        val uri = withContext(Dispatchers.IO) {
                            TimetablePdf.create(ctx.applicationContext, from, to, day, withReturn, store) { p ->
                                scope.launch { progress = p }
                            }
                        }
                        result = uri
                        TimetablePdf.open(ctx, uri)
                    } catch (e: Exception) {
                        error = tx("Non è stato possibile creare l'orario") + (e.message?.let { ": $it" } ?: "")
                    }
                    busy = false
                }
            }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(tx("Scarica PDF")) }
        },
        dismissButton = { TextButton({ onDismiss() }, enabled = !busy) { Text(tx("Chiudi")) } },
    )
}
