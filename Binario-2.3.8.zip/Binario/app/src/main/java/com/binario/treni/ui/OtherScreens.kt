package com.binario.treni.ui

import com.binario.treni.data.tx
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.text.style.TextDecoration
import com.binario.treni.data.ALL_CATEGORIES
import com.binario.treni.data.Api
import com.binario.treni.data.Fmt
import com.binario.treni.data.NewsItem
import com.binario.treni.data.Notice
import com.binario.treni.data.Sources
import com.binario.treni.data.Strike
import com.binario.treni.data.SavedSearch
import com.binario.treni.service.Reminders
import com.binario.treni.service.TrackingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Scheda "Biglietti": acquisto e gestione sui siti ufficiali delle compagnie. */
@Composable
fun TicketsScreen(onBack: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Biglietti"), onBack)
        SectionHeader(tx("Acquista"))
        SimpleRow(Icons.Filled.ShoppingCart, "Trenitalia", tx("Frecce, Intercity e Regionali")) { openUrl(ctx, "https://www.lefrecce.it") }
        SimpleRow(Icons.Filled.ShoppingCart, "Italo", tx("Alta velocità NTV")) { openUrl(ctx, "https://www.italotreno.com") }
        SimpleRow(Icons.Filled.ShoppingCart, "Trenord", tx("Regionali Lombardia e Malpensa Express")) { openUrl(ctx, "https://www.trenord.it") }
        SectionHeader(tx("I miei biglietti"))
        SimpleRow(Icons.Filled.ConfirmationNumber, tx("Area personale Trenitalia"), tx("Biglietti, abbonamenti e QR code")) {
            openUrl(ctx, "https://www.lefrecce.it/Channels.Website.WEB/#/user-area/")
        }
        SimpleRow(Icons.Filled.EditCalendar, tx("Cambio prenotazione Trenitalia"), tx("Modifica data, ora o classe")) {
            openUrl(ctx, "https://www.lefrecce.it")
        }
        SimpleRow(Icons.Filled.ConfirmationNumber, tx("I miei viaggi Italo"), "") { openUrl(ctx, "https://www.italotreno.com") }
        Text(
            tx("L'acquisto avviene sul sito ufficiale della compagnia: l'acquisto diretto nell'app e la sincronizzazione ") +
                tx("dei biglietti richiedono un accordo commerciale con Trenitalia, Italo e Trenord."),
            style = MaterialTheme.typography.bodySmall, color = Color.Gray, modifier = Modifier.padding(16.dp),
        )
    }
}

/** Scheda "Altro": menu con notizie espandibili, come nell'app di riferimento. */
@Composable
fun MoreScreen(vm: MainViewModel, go: (String) -> Unit) {
    val ctx = LocalContext.current
    var newsOpen by remember { mutableStateOf(false) }
    var tracked by remember { mutableStateOf(vm.store.tracked()) }
    var sharing by remember { mutableStateOf(false) }
    if (sharing) ShareAppDialog { sharing = false }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Altro")) {
            IconButton({ sharing = true }) { Icon(Icons.Filled.Share, tx("Condividi Binario"), tint = Color.White) }
        }
        // Menu raggruppato per argomento, come nelle app di viaggio (SBB, Trainline, DB Navigator)
        WhiteCard {
            CardTitle(tx("Il tuo viaggio"))
            tracked?.let { t ->
                MenuRow(Icons.Filled.Train, tx("Treno seguito") + ": " + t.label, tx("Apri lo stato in tempo reale")) {
                    go("train?num=${android.net.Uri.encode(t.number)}&orig=${android.net.Uri.encode(t.originCode)}&date=${t.date}")
                }
                MenuRow(Icons.Filled.NotificationsOff, tx("Smetti di seguire") + " ${t.label}") { TrackingService.stop(ctx); tracked = null }
            }
            MenuRow(Icons.Filled.Mic, tx("Chiedi a voce"), tx("Assistente: treni, ritardi, binari, scioperi")) { go("bot?voice=true") }
            MenuRow(Icons.Filled.Notifications, tx("Allarmi"), tx("Notifiche programmate e sveglie")) { go("reminders") }
            MenuRow(Icons.Filled.DownloadForOffline, tx("Orari salvati offline"), tx("Anche i PDF scaricati sono in Download/Binario")) { go("saved") }
        }
        WhiteCard {
            CardTitle(tx("Informazioni"))
            MenuRow(Icons.Filled.Campaign, tx("Scioperi, circolazione e lavori"), tx("Fonti ufficiali, aggiornate ogni 5 minuti")) { go("news") }
            MenuRow(Icons.Filled.SupportAgent, tx("Il mio Capotreno"), tx("Segui il tuo treno: avvisi prima, durante e dopo il viaggio")) { go("capotreno") }
            MenuRow(Icons.Filled.EventBusy, tx("Treni garantiti in caso di sciopero")) { go("guaranteed") }
            MenuRow(Icons.Filled.Insights, tx("Puntualità"), tx("Regionali con regionali, alta velocità con alta velocità")) { go("stats") }
            MenuRow(Icons.Filled.Route, tx("Linee"), tx("Trenord, TILO, FerrovieNord, Svizzera")) { go("lines") }
            MenuRow(Icons.Filled.Train, tx("Imprese ferroviarie"), tx("Tutte le aziende di Italia e Svizzera: siti, biglietti, dati")) { go("railways") }
            MenuRow(Icons.Filled.Gavel, tx("Condizioni di trasporto, diritti e rimborsi")) { go("conditions") }
            MenuRow(Icons.Filled.Article, tx("Siti delle aziende"), trailing = {
                Icon(if (newsOpen) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown, null, tint = Muted)
            }) { newsOpen = !newsOpen }
            if (newsOpen) {
                MenuRow(null, "Trenitalia") { openUrl(ctx, "https://www.trenitalia.com/it/informazioni/Infomobilita/notizie-infomobilita.html") }
                MenuRow(null, "Trenord") { openUrl(ctx, "https://www.trenord.it/news/trenord-informa/avvisi/") }
                MenuRow(null, "Italo") { openUrl(ctx, "https://www.italotreno.com/it/contatti-supporto") }
                MenuRow(null, "FerrovieNord") { openUrl(ctx, "https://www.ferrovienord.it") }
                MenuRow(null, "TILO") { openUrl(ctx, "https://www.tilo.ch/avvisi.html") }
            }
        }
        WhiteCard {
            CardTitle(tx("In stazione e biglietti"))
            if (vm.store.mapsEnabled) MenuRow(Icons.Filled.Map, tx("Stazioni vicine sulla mappa")) { go("nearby") }
            MenuRow(Icons.Filled.Storefront, tx("Rivendite vicine"), tx("Biglietterie, emettitrici, obliteratrici, contactless")) { go("sellers?id=&name=") }
            MenuRow(Icons.Filled.Wc, tx("WC vicini"), tx("Gratuiti o a pagamento, accessibili, fasciatoio, orari")) { go("toilets?id=&name=") }
            MenuRow(Icons.Filled.ConfirmationNumber, tx("Biglietti"), tx("Siti ufficiali di acquisto e area personale")) { go("tickets") }
            MenuRow(Icons.Filled.Euro, tx("Quanto costa il tuo abbonamento"), tx("Trenord da A a B: settimanale, mensile, annuale, Trenocittà, biglietti")) { go("fares") }
            MenuRow(Icons.Filled.Flight, tx("Malpensa Express · tariffe"), tx("Prezzi da ogni stazione, linee, classi e limitazioni")) { go("malpensa?from=") }
            MenuRow(Icons.Filled.Map, tx("Area STIBM · Milano e Monza Brianza"), tx("Zone, prezzi e stazioni del biglietto integrato")) { go("stibm?name=") }
        }
        WhiteCard {
            CardTitle(tx("Strumenti"))
            MenuRow(Icons.Filled.CompareArrows, tx("Confronta itinerari"), tx("Es. Varese → Como via Mendrisio o via Milano")) { go("compare") }
            MenuRow(Icons.Filled.Eco, tx("Quanto sei green"), tx("Quanto risparmi in CO₂, carburante, pedaggi e tempo")) { go("green") }
            MenuRow(Icons.Filled.Public, tx("TILO · Ticino e Lombardia"), tx("Linee, tariffe transfrontaliere, servizi")) { go("tilo") }
        }
        WhiteCard {
            CardTitle(tx("Accessibilità"))
            val lvl = vm.store.blindLevel
            MenuRow(Icons.Filled.RecordVoiceOver, tx("Avvisi vocali per non vedenti"),
                when (lvl) { "all" -> tx("Attivi: tutti gli avvisi"); "stop" -> tx("Attivi: solo fermata imminente"); else -> tx("Disattivati") }) { go("settings") }
            MenuRow(Icons.Filled.Vibration, tx("Avvisi per persone sorde"),
                if (vm.store.deafMode) tx("Attivi: vibrazione e flash") else tx("Disattivati")) { go("settings") }
        }
        WhiteCard {
            CardTitle(tx("App"))
            MenuRow(Icons.Filled.Settings, tx("Impostazioni")) { go("settings") }
            MenuRow(Icons.Filled.Widgets, "Widget") { go("widgets") }
            MenuRow(Icons.Filled.Share, tx("Condividi Binario"), tx("Invia l'app ai tuoi contatti su WhatsApp, Telegram…")) { sharing = true }
            MenuRow(Icons.Filled.Feedback, tx("Feedback e segnala un bug"), tx("Scrivi allo sviluppatore: idee, suggerimenti, problemi")) { go("feedback?bug=false") }
            MenuRow(Icons.Filled.Email, tx("Aiuto e FAQ")) { go("help") }
            MenuRow(Icons.Filled.Info, "Changelog", tx("Novità di ogni versione")) { go("changelog") }
            MenuRow(Icons.Filled.BugReport, tx("Report correzioni"), tx("Problemi risolti in ogni versione")) { go("fixes") }
            MenuRow(Icons.Filled.MonitorHeart, tx("Stato dei servizi"), tx("Controlla che tutte le fonti di dati rispondano")) { go("health") }
            MenuRow(Icons.Filled.PrivacyTip, tx("Privacy e permessi")) { go("privacy") }
            MenuRow(Icons.Filled.Gavel, tx("Note legali"), tx("Versione") + " " + APP_VERSION) { go("legal") }
        }
        Text(
            "Binario $APP_VERSION · " + tx(CREDIT), color = Muted, fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth().padding(20.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

/** Opzioni avanzate di ricerca: massimo cambi e categorie escluse. */
@Composable
fun AdvancedScreen(vm: MainViewModel, onBack: () -> Unit) {
    var max by remember { mutableIntStateOf(vm.maxChanges) }
    var ex by remember { mutableStateOf(vm.excluded) }
    var menu by remember { mutableStateOf(false) }
    fun label(m: Int) = when (m) {
        -1 -> tx("non definito")
        0 -> tx("nessun cambio (solo diretti)")
        else -> "$m"
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Opzioni avanzate"), onBack) {
            IconButton({ vm.saveAdvanced(max, ex); onBack() }) { Icon(Icons.Filled.Check, tx("Salva")) }
        }
        WhiteCard {
            CardTitle(tx("Max Cambi"))
            Box {
                Row(Modifier.fillMaxWidth().clickable { menu = true }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tx("Max Cambi"), color = Muted, fontSize = 13.sp)
                        Text(label(max), fontSize = 17.sp)
                    }
                    Icon(Icons.Filled.ArrowDropDown, null, tint = Muted)
                }
                DropdownMenu(menu, { menu = false }) {
                    listOf(-1, 0, 1, 2, 3).forEach { m -> DropdownMenuItem({ Text(label(m)) }, { max = m; menu = false }) }
                }
            }
        }
        WhiteCard {
            CardTitle(tx("Escludi categorie"))
            Column(Modifier.padding(vertical = 8.dp)) {
                ALL_CATEGORIES.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { c ->
                            val off = c in ex
                            Box(
                                Modifier.weight(1f).clickable { ex = if (off) ex - c else ex + c }.padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    c, fontSize = 17.sp,
                                    color = if (off) Color(0xFFBDBDBD) else categoryColor(c),
                                    textDecoration = if (off) TextDecoration.LineThrough else null,
                                )
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Text(tx("Tocca una categoria per escluderla (barrata) o includerla."), color = Muted, fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            }
        }
    }
}

/** Impostazioni generali, notifiche, mappe, accessibilità, backup. */
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onThemeChange: (String) -> Unit, onLegal: () -> Unit = {}) {
    val ctx = LocalContext.current
    val store = vm.store
    var start by remember { mutableStateOf(store.startScreen) }
    var theme by remember { mutableStateOf(store.theme) }
    var kbd by remember { mutableStateOf(store.openKeyboard) }
    var buy by remember { mutableStateOf(store.showBuy) }
    var maps by remember { mutableStateOf(store.mapsEnabled) }
    var strikes by remember { mutableStateOf(store.strikeAlerts) }
    var routes by remember { mutableStateOf(store.routeAlerts) }
    var deaf by remember { mutableStateOf(store.deafMode) }
    var flash by remember { mutableStateOf(store.flashAlerts) }
    var blindLevel by remember { mutableStateOf(store.blindLevel) }
    val blind = blindLevel != "off"
    var stopsVoice by remember { mutableStateOf(store.announceStops) }
    var rate by remember { mutableStateOf(store.speechRate) }
    var changes by remember { mutableStateOf(store.changeAlerts) }
    var habitLearn by remember { mutableStateOf(store.habitLearning) }
    var habitAlerts by remember { mutableStateOf(store.habitAlerts) }
    var habitList by remember { mutableStateOf(store.habits()) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(tx("application/json"))) { uri ->
        if (uri != null) exportTo(ctx, uri, store)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importFrom(ctx, uri, store)
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        GreenTopBar(tx("Impostazioni"), onBack)
        WhiteCard {
            CardTitle(tx("Generale"))
            ChoiceSetting(tx("Schermata all'avvio"), start, listOf("search" to tx("Cerca Orario"), "trains" to tx("Treni"), "stations" to tx("Stazioni"),
                "voice" to tx("Assistente vocale (microfono subito attivo)"))) {
                start = it; store.startScreen = it
            }
            ChoiceSetting(tx("Lingua"), com.binario.treni.data.I18n.lang, listOf("it" to "🇮🇹 Italiano", "en" to "🇬🇧 English")) {
                com.binario.treni.data.I18n.lang = it; store.lang = it
            }
            ChoiceSetting(tx("Tema"), theme, listOf("system" to tx("Come il sistema"), "light" to tx("Verde chiaro"), "dark" to tx("Scuro"))) {
                theme = it; store.theme = it; onThemeChange(it)
            }
        }
        WhiteCard {
            CardTitle(tx("Cerca e Acquista"))
            SwitchSetting(tx("Apri tastiera in scelta stazione"), kbd) { kbd = it; store.openKeyboard = it }
            SwitchSetting(tx("Mostra pulsante Acquisto"), buy) { buy = it; store.showBuy = it }
        }
        WhiteCard {
            CardTitle(tx("Notifiche"))
            SwitchSetting(tx("Notifica scioperi"), strikes) { strikes = it; store.strikeAlerts = it }
            SwitchSetting(tx("Avvisi interruzioni su tratte, linee e treni preferiti"), routes) { routes = it; store.routeAlerts = it }
            SwitchSetting(tx("Treno seguito: avvisa se cambia binario o aumenta il ritardo"), changes) { changes = it; store.changeAlerts = it }
        }
        WhiteCard {
            CardTitle(tx("Il tuo prossimo treno"))
            SwitchSetting(tx("Impara i treni che prendo spesso"), habitLearn,
                tx("Dal tabellone, dalle soluzioni, da Segui e dai preferiti. Resta solo sul telefono.")) {
                habitLearn = it; store.habitLearning = it
            }
            SwitchSetting(tx("Avvisami da solo sul treno abituale"), habitAlerts,
                tx("Nei 45 minuti prima della partenza: ritardo, soppressione, cambio binario e alternative pronte")) {
                habitAlerts = it; store.habitAlerts = it
            }
            habitList.forEach { h ->
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(h.title + " · " + h.timeText, fontSize = 15.sp)
                        Text(h.board.name + (h.alight?.let { " → " + it.name } ?: "") + " · " + h.total + "×", color = Muted, fontSize = 12.sp)
                    }
                    IconButton({ store.removeHabit(h.key); habitList = store.habits() }) { Icon(Icons.Filled.Close, tx("Dimentica")) }
                }
            }
            if (habitList.isEmpty()) Text(tx("Ancora nessun treno abituale: compare dopo averlo aperto almeno due volte lo stesso giorno della settimana."),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        WhiteCard {
            CardTitle(tx("Accessibilità"))
            SwitchSetting(tx("Avvisi per persone sorde o ipoudenti"), deaf,
                tx("Vibrazione forte con schema diverso per ogni avviso: sveglia fermata (3 lunghe ripetute), promemoria (3 brevi ×2), interruzioni (2 lunghe)")) {
                deaf = it; store.deafMode = it
                if (it) com.binario.treni.service.Haptic.alert(ctx, com.binario.treni.service.Haptic.Kind.REMINDER)
            }
            if (deaf) SwitchSetting(tx("Lampeggio del flash negli avvisi"), flash) { flash = it; store.flashAlerts = it }
            ChoiceSetting(tx("Avvisi vocali per persone non vedenti o ipovedenti"), blindLevel, listOf(
                "off" to tx("Disattivati"),
                "stop" to tx("Solo fermata imminente"),
                "all" to tx("Tutti: binario, partenza, cambi, ritardi, fermate"),
            )) {
                blindLevel = it; store.blindLevel = it
                when (it) {
                    "all" -> com.binario.treni.service.Speech.say(ctx,
                        tx("Avvisi vocali attivi. Ti dirò il binario, la partenza e la fermata dove scendere."),
                        com.binario.treni.service.Speech.Sound.PLATFORM, force = true)
                    "stop" -> com.binario.treni.service.Speech.say(ctx,
                        tx("Ti avviserò con la voce solo quando la tua fermata è imminente."),
                        com.binario.treni.service.Speech.Sound.IMMINENT, force = true)
                }
            }
            Text(tx("La voce del telefono dice dove prendere il treno (binario), quando parte, i cambi di binario e i ritardi, e avvisa con un suono insistente quando la tua fermata è imminente."),
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
            if (blindLevel == "all") SwitchSetting(tx("Annuncia ogni fermata del treno seguito"), stopsVoice) { stopsVoice = it; store.announceStops = it }
            if (blind) {
                ChoiceSetting(tx("Velocità della voce"), rate.toString(), listOf("0.8" to tx("Lenta"), "1.0" to tx("Normale"), "1.2" to tx("Veloce"))) {
                    rate = it.toFloat(); store.speechRate = rate
                    com.binario.treni.service.Speech.say(ctx, tx("Prova della voce."), null, force = true)
                }
                Text(tx("Prova i suoni: ognuno ha un significato diverso."), color = Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
                    listOf(
                        com.binario.treni.service.Speech.Sound.PLATFORM to tx("Binario"),
                        com.binario.treni.service.Speech.Sound.DEPART to tx("Partenza"),
                        com.binario.treni.service.Speech.Sound.IMMINENT to tx("Fermata imminente"),
                        com.binario.treni.service.Speech.Sound.ALERT to tx("Problema"),
                    ).forEach { (snd, label) ->
                        OutlinedButton({ com.binario.treni.service.Speech.say(ctx, label, snd, force = true) }, Modifier.padding(end = 6.dp)) { Text(label) }
                    }
                }
                Text(
                    tx("Per chiedere a voce: tieni premuta l'icona di Binario e scegli «Chiedi a voce» (puoi trascinarla sulla Home), " +
                        "oppure aggiungi il riquadro «Binario · Chiedi a voce» nelle Impostazioni rapide. Con l'assistente del telefono di' «Apri Binario». " +
                        "Funziona anche con TalkBack."),
                    color = Muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp),
                )
            }
            ChoiceSetting(tx("Colori per daltonici"), com.binario.treni.data.ColorBlind.mode, listOf(
                "off" to tx("Disattivato"),
                "redgreen" to tx("Rosso-verde (protanopia, deuteranopia)"),
                "tritan" to tx("Blu-giallo (tritanopia)"),
            )) {
                com.binario.treni.data.ColorBlind.mode = it; store.colorBlind = it
                com.binario.treni.widget.Widgets.refreshAll(ctx)
            }
            if (com.binario.treni.data.ColorBlind.on) Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("✓ " + tx("In orario"), color = OnTime, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(12.dp))
                Text("▲ +7'", color = LateRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(12.dp))
                listOf(com.binario.treni.data.Crowd.Level.LOW, com.binario.treni.data.Crowd.Level.MEDIUM, com.binario.treni.data.Crowd.Level.HIGH).forEach {
                    Text(it.symbol + " ", color = Color(it.color), fontSize = 16.sp)
                }
            }
        }
        WhiteCard {
            CardTitle(tx("Posizione e Mappe"))
            SwitchSetting(tx("Disattiva Mappe"), !maps) { maps = !it; store.mapsEnabled = !it }
        }
        WhiteCard {
            CardTitle("Backup")
            MenuRow(null, tx("Esporta dati")) { exportLauncher.launch("binario-backup.json") }
            MenuRow(null, tx("Importa dati")) { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }
        }
        WhiteCard {
            CardTitle(tx("Legale"))
            MenuRow(Icons.Filled.Gavel, tx("Note legali"), tx("Versione") + " " + APP_VERSION) { onLegal() }
            Text(if (com.binario.treni.data.I18n.en) PRIVACY_TEXT_EN else PRIVACY_TEXT, fontSize = 13.sp, color = Muted, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        }
        WhiteCard {
            CardTitle(tx("Versione App"))
            Text(APP_VERSION, fontSize = 17.sp, modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp))
            Text(tx(CREDIT), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
        }
        Spacer(Modifier.height(16.dp))
    }
}

private fun exportTo(ctx: android.content.Context, uri: android.net.Uri, store: com.binario.treni.data.Store) {
    try {
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(store.exportJson().toByteArray()) }
        toast(ctx, tx("Backup salvato"))
    } catch (e: Exception) {
        toast(ctx, tx("Errore nel salvataggio"))
    }
}

private fun importFrom(ctx: android.content.Context, uri: android.net.Uri, store: com.binario.treni.data.Store) {
    try {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() } ?: ""
        toast(ctx, if (store.importJson(text)) tx("Dati importati") else tx("File non valido"))
    } catch (e: Exception) {
        toast(ctx, tx("File non valido"))
    }
}

@Composable
private fun SwitchSetting(title: String, value: Boolean, sub: String = "", onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (sub.isNotBlank()) Text(sub, color = Muted, fontSize = 12.sp)
        }
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Green))
    }
}

@Composable
private fun ChoiceSetting(title: String, value: String, options: List<Pair<String, String>>, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Muted, fontSize = 13.sp)
                Text(options.firstOrNull { it.first == value }?.second ?: value, fontSize = 17.sp)
            }
            Icon(Icons.Filled.ArrowDropDown, null, tint = Muted)
        }
        DropdownMenu(open, { open = false }) {
            options.forEach { (k, v) -> DropdownMenuItem({ Text(v) }, { onChange(k); open = false }) }
        }
    }
}

const val APP_VERSION = "2.3.8"
const val CREDIT = "App creata da Marco Jannino"

const val HELP_TEXT = """Come cerco un orario?
Nella scheda Cerca scegli partenza e arrivo, data e ora, poi tocca Cerca. Tocca il nome di un treno (es. "TI FR 9627") per vedere ritardi, fermate e binari.

Come vedo il tabellone di una fermata?
Nella scheda del treno tocca una fermata e scegli "Partenze e arrivi da qui".

Come funziona la sveglia?
Nella scheda del treno tocca la fermata dove scendi e scegli "Svegliami prima di questa fermata". L'allarme suona quando il treno lascia la fermata precedente (o 4 minuti prima dell'arrivo previsto). Attiva "Avvisi per persone sorde" nelle Impostazioni per vibrazione forte e flash.

Come aggiungo una linea?
Scheda Treni → Linee preferite → Aggiungi, es. S5 con capolinea Varese e Treviglio.

Come configuro un widget?
Aggiungilo dalla Home e scegli cosa mostrare. Per cambiarlo, tocca il titolo del widget.

Come scarico l'orario per usarlo senza rete?
Cerca la tratta e nei risultati tocca l'icona PDF: scegli il giorno e se includere il ritorno. Il file si salva in Download/Binario e si apre anche offline. Inoltre l'app ricorda da sola gli ultimi orari di ogni tratta cercata.

Come dico all'app dove salgo?
Apri il treno, tocca la fermata dove sali e scegli "Salgo qui": binario, orario e avvisi (anche vocali) si riferiscono a quella fermata.

Come uso l'app senza vedere lo schermo?
In Impostazioni → Accessibilità scegli gli avvisi vocali (tutti o solo fermata imminente). Per chiedere a voce tieni premuta l'icona di Binario e scegli "Chiedi a voce", oppure usa il riquadro nelle Impostazioni rapide.

Perché un treno non ha prezzo o affollamento?
I prezzi arrivano da Trenitalia; l'affollamento solo da Trenord, quando disponibile."""

const val CHANGELOG_TEXT = """2.4 · IN LAVORAZIONE
• Versione in preparazione: le novità verranno elencate qui al rilascio

2.3.8
• Nuovo "Il mio Capotreno" (scheda Treni e Altro): come il servizio WhatsApp di Trenord, ma dentro l'app e per tutti i treni. Autorizzi una volta, cerchi il treno per numero, dalla stazione più vicina a te o per stazione e orario, scegli dove sali e dove scendi: ricevi gli avvisi prima (binario, partenza), durante (cambi di binario, ritardo, prossima fermata, sveglia) e dopo il viaggio (riepilogo dell'arrivo con il ritardo e i diritti a rimborso). Nessuna registrazione
• Treni Italo in tempo reale: si trovano per numero, compaiono nei tabelloni delle stazioni servite da Italo e si possono seguire come gli altri
• Treno seguito: all'arrivo (al capolinea o alla fermata dove scendi) arriva il riepilogo e l'app smette da sola di seguirlo

2.3.7
• Nuovo tariffario Malpensa Express (Altro → Biglietti, e in "Quanto costa il tuo abbonamento" quando un capolinea è l'aeroporto): corsa semplice, andata e ritorno, abbonamenti in 1ª e 2ª classe da Milano, Saronno, Rescaldina, Castellanza, Busto Arsizio, Ferno, Gallarate, Varese, Induno, Arcisate e Gaggiolo; Family, A/R 30 giorni, transfer T1–T2; differenze tra la linea da Cadorna (solo 1ª classe) e da Centrale, e le regole su abbonamenti regionali, STIBM e Io Viaggio

2.3.6
• Nuovo "Quanto costa il tuo abbonamento" (Altro → Biglietti): da una stazione all'altra, la fascia chilometrica e i prezzi Trenord di abbonamento settimanale, mensile, annuale e Trenocittà, biglietto ordinario, ragazzi, senior e carnet, in 2ª e 1ª classe; più Io Viaggio Ovunque in Lombardia e in provincia. Se il viaggio è tutto nell'area STIBM lo segnala. Tariffe in vigore dal 01/10/2026
• Area STIBM: supplemento prima classe aggiornato al tariffario Trenord in vigore (2,80 € a viaggio, 31 € al mese, 310 € all'anno)

2.3.5
• Nuova sezione "Area STIBM" (Altro → Biglietti e nel tabellone delle stazioni coinvolte): calcolo delle zone e del prezzo tra due stazioni (ordinario con durata, carnet, giornaliero, 3 giorni, settimanale, mensile, annuale, under 26/over 65, ISEE), tutte le 99 stazioni con la loro zona Mi1…Mi9, le stazioni di solo interscambio e le regole principali, dai dati ufficiali Trenord (prezzi dal 01/10/2026)

2.3.4
• Rivendite più veloci: l'elenco completo delle rivendite autorizzate e delle biglietterie Trenord (con orari) viene preparato ogni settimana e scaricato in un solo file, invece di leggere decine di pagine del sito Trenord dal telefono

2.3.3
• Nuovo "Condividi Binario" (Altro, in alto e nel menu App): invia ai contatti di WhatsApp, Telegram o altre app un messaggio con il link che scarica sempre l'ultima versione

2.3.2
• Nuovo "Feedback e segnala un bug" (Altro → App): nome e cognome, email e testo, con i dati tecnici facoltativi. Il messaggio arriva direttamente allo sviluppatore; senza rete resta salvato e parte da solo appena possibile
• Protezione anti-spam per i feedback: al massimo 3 messaggi al giorno, almeno 3 minuti tra un invio e l'altro, niente messaggi ripetuti, testi senza senso o pieni di link; il modulo accetta solo i messaggi inviati dall'app

2.3.1
• Stato dei servizi: ViaggiaTreno risultava rosso ("HTTP 403") perché il controllo si presentava con un nome che il sito rifiuta. Ora usa lo stesso dell'app, e se un sito rifiuta l'app questa riprova da sola presentandosi come il browser del telefono
• Stato dei servizi: OpenStreetMap risultava rosso quando era giù solo il server principale. Ora prova anche i server di riserva, come fa l'app
• Stato dei servizi: Postpass risultava rosso per un errore nel controllo (la richiesta di prova era scritta male, non il servizio)

2.3
• Servizi in stazione, rivendite, bus e taxi più affidabili: l'app prova in automatico 3 server OpenStreetMap diversi (4 per le stazioni in Svizzera, con il server della comunità svizzera OSM.ch), poi una seconda fonte indipendente (Postpass di Geofabrik), poi gli ultimi dati scaricati
• Pulsanti "Cerca su Google Maps" per tabacchi, edicole, biglietterie, WC, fermate bus, metro e taxi: sempre disponibili, anche quando OpenStreetMap è irraggiungibile
• Sotto i dati compare la fonte che ha risposto (es. "OpenStreetMap · Overpass" o "Postpass")
• Rivendite: pulsante "Riprova" se la ricerca non va a buon fine
• Trascina giù per aggiornare: tieni il dito sull'elenco e tiralo verso il basso nel tabellone, nella scheda del treno, nelle notizie e nelle soluzioni
• Mappe: nuovo tasto "Google Maps" su ogni mappa, che apre la stessa zona in Google Maps
• Widget: anche l'ora nell'intestazione aggiorna, e mentre carica compare "aggiorno…"
• Rivendite: ora mostra solo i punti vendita ufficiali, non tutte le tabaccherie. In Lombardia: rivendite autorizzate Trenord (bar, tabaccherie, edicole, agenzie) con "aperto/chiuso adesso" e biglietterie con orari settimanali, elenco aggiornato ogni settimana. In Svizzera: biglietterie automatiche FFS. Nel resto d'Italia: mappa ufficiale Trenitalia dei punti PuntoLIS e Mooney
• Davanti al numero del treno compare l'impresa che fa il servizio: Trenord, Trenitalia, Tper, TILO, SBB, Italo
• Rivendite in Alto Adige: tutti i punti vendita ufficiali altoadigemobilità (tabaccherie, Infopoint, biglietterie, associazioni turistiche) con indirizzo, orari settimanali e cosa vendono, aggiornati ogni settimana
• Puntualità: il confronto tra treni regionali ora separa le imprese prima raggruppate in "altri operatori": Trenitalia Tper, EAV, Ferrovie del Gargano, TUA, BLS
• Nuova sezione "Imprese ferroviarie" (Altro → Informazioni): 41 imprese di treni passeggeri (20 italiane, 17 svizzere, 4 estere che entrano in Italia o Svizzera), regionali e lunga percorrenza, con area servita, sito, dove comprare i biglietti e da dove arrivano tempo reale e puntualità
• Il nome dell'impresa davanti al numero del treno riconosce anche EAV, FSE, Ferrotramviaria, BLS, SOB, Ferrovia Retica, Thurbo e le altre imprese svizzere
• Puntualità in Svizzera: i treni FFS (S-Bahn e regionali; InterRegio, InterCity ed EuroCity) dai dati aperti delle FFS, raccolti ogni giorno
• Svizzera in tempo reale: le stazioni svizzere compaiono nella ricerca con "(CH)"; tabellone delle partenze con binario, ritardo e impresa (FFS, TILO, BLS, SOB, Ferrovia Retica, Thurbo…); toccando un treno si vedono le fermate fino al capolinea, anche sulla mappa; le soluzioni da e per la Svizzera usano l'orario ufficiale svizzero
• Puntualità: nota che spiega perché le imprese svizzere diverse dalle FFS non sono ancora incluse e come si potranno aggiungere
• Ferrovie con rete propria: stazioni, partenze, fermate dei treni e soluzioni di viaggio di EAV (Circumvesuviana, Cumana, Circumflegrea), ARST (Sardegna), Trentino Trasporti (Trento–Malè) e Cotral (Roma–Lido, Roma–Viterbo), dagli orari ufficiali raccolti da Transitous. Sono orari programmati: i ritardi compaiono solo se l'azienda li pubblica
• Rete FerrovieNord: le soluzioni di viaggio da e per Milano Cadorna, Saronno, Varese Nord, Como Lago, Novara Nord, Malpensa ecc. ora usano il codice giusto di LeFrecce, con riserva sugli orari ufficiali Trenord (GTFS)
• Aggiornamenti automatici: a ogni avvio l'app controlla se è uscita una nuova versione e chiede se aggiornare; con "Aggiorna" la scarica da sola e apre l'installazione
• Rete FerrovieNord nelle stazioni: 103 stazioni (Varese Nord, Como Lago, Novara Nord, Laveno Lago, Saronno Sud, tutta la Brescia–Iseo–Edolo…) mancavano dall'elenco di ViaggiaTreno, quindi non comparivano in "Stazioni vicine" e senza posizione non funzionavano mappe, rivendite e WC. Ora ci sono, con gli stessi codici e il tempo reale di ViaggiaTreno
• Puntualità della rete FerrovieNord: TrovaTreno non la pubblica, quindi l'app raccoglie da sola gli arrivi da ViaggiaTreno e mostra la media per linea, per stazione e per treno (scheda Puntualità, tabellone e scheda del treno). Sono osservate anche le tue stazioni FN preferite
• Puntualità: nuovo filtro "Passante di Milano"; Porta Garibaldi e Centrale non compaiono più come semplice "Milano"
• Nuovo "Il tuo prossimo treno": aprendo l'app compare subito il treno che prendi di solito a quell'ora, con ritardo e binario (impara dal tabellone, dalle soluzioni, da Segui e dai preferiti; resta solo sul telefono)
• Avvisi automatici sul treno abituale, senza premere "Segui": nei 45 minuti prima della partenza notifica ritardo, soppressione e cambio binario
• Alternativa pronta: se il treno abituale è soppresso o ha più di 15 minuti di ritardo, propone subito gli altri treni (anche di altre imprese) che ti portano a destinazione
• Affidabilità: nuova schermata "Stato dei servizi" (Altro → App) con un semaforo per ogni fonte di dati e il tempo di risposta
• Affidabilità: se l'app si chiude in modo inatteso, al riavvio propone di inviare la segnalazione tecnica allo sviluppatore (nessun dato personale)
• Affidabilità: test automatici dei lettori di dati a ogni compilazione e controllo giornaliero delle fonti su GitHub, che avvisa se un sito cambia formato
• Nuova schermata "WC vicini" (Stazioni, Altro e icona nel tabellone): gratuiti o a pagamento con prezzo, accessibili, fasciatoio, solo clienti, orari, distanza a piedi, mappa e filtri; anche i bagni indicati sulla stazione o nei locali aperti a tutti

2.2
• Assistente più esperto: risponde su rimborsi per ritardo, rimborso e cambio biglietto, convalida, multe, bici, animali, bambini, assistenza disabili, oggetti smarriti, scioperi, treni soppressi, coincidenze perse, bagagli, abbonamenti, aeroporti, Svizzera, contatti, diritti dei passeggeri e uso dell'app, sempre con la fonte e il link
• Capisce meglio le domande: ignora accenti e maiuscole, accetta plurali, sinonimi e piccoli errori di battitura
• Nuove domande: "bus, metro e taxi a Milano Centrale", "WC a Saronno", "servizi a Varese"
• Stazione: nuovo riquadro "Bus, metro, tram e taxi" con fermate vicine, linee che ci passano, posteggi taxi e bici in condivisione
• Assistente: suggerimenti rapidi scorrevoli e pulsante "Apri la stazione"

2.1
• "Salgo qui": scegli la fermata dove sali; binario, orario, notifica e avvisi vocali si riferiscono a quella
• Primo avvio: proposta degli avvisi per persone sorde (a video) e per non vedenti (letta ad alta voce, risposta anche a voce), con l'opzione "solo fermata imminente"
• Puntualità corretta: regionali con regionali (Trenord, Trenitalia Regionale, altre imprese), alta velocità e Intercity in riquadri separati
• Orario del giorno in PDF (andata e ritorno), salvato in Download/Binario e consultabile offline
• Senza rete: vengono mostrati gli ultimi orari scaricati per la tratta, con l'ora di aggiornamento
• WC in stazione: gratuiti o a pagamento (con prezzo se indicato), accessibili, orari
• Cerca: scheda "Viaggio in corso" sempre aggiornata e azioni rapide (chiedi a voce, stazioni vicine, scioperi, orari offline, allarmi)
• Menu Altro riordinato per argomento: il tuo viaggio, informazioni, in stazione, strumenti, accessibilità, app

0.4
• Avvisi vocali per persone non vedenti o ipovedenti: la voce del telefono dice binario e orario di partenza, "parte tra 5 minuti", cambi di binario, ritardi, ogni fermata e, con un suono insistente, la fermata dove scendere
• Suoni diversi per ogni avviso (binario, partenza, fermata imminente, problema), da provare nelle Impostazioni
• Assistente a voce: microfono grande, risposta letta ad alta voce, "Segui con avvisi vocali"; nuove domande "dov'è il mio treno?" e "prossimo treno per Milano"
• Scorciatoie (tieni premuta l'icona): Chiedi a voce, Treno seguito, Scioperi e notizie; riquadro "Chiedi a voce" nelle Impostazioni rapide; avvio diretto sull'assistente vocale
• Per tutti: notifica di cambio binario e di aumento del ritardo del treno seguito
• Soluzioni con cambio: minuti per il cambio e avviso "coincidenza a rischio" se il primo treno è in ritardo
• Scheda del treno: rimborso per il ritardo (25% oltre 1 ora, 50% oltre 2 ore, Frecce da 30 minuti) con link per la richiesta

0.3
• Notizie: nuova fonte Trenitalia Infomobilità, testo completo del comunicato letto dalla pagina originale, fonte con link diretto su ogni notizia
• Notizie e scioperi si aggiornano da soli ogni 5 minuti, con il pulsante "Aggiorna ora" e l'ora dell'ultimo aggiornamento
• Scioperi più chiari: orari, chi, dove, settore, sindacati e fonte (Osservatorio scioperi MIT); inclusi gli scioperi generali
• Stazione: riepilogo con binari, ascensori per binario, biglietteria, self-service (contactless), obliteratrici, rivendite, servizi igienici
• Guasti ad ascensori e scale letti dal vivo anche da FerrovieNord, oltre che da RFI
• Widget: niente più "dati non disponibili" a ogni errore di rete momentaneo, restano gli ultimi dati validi con l'ora
• Mappe più veloci (server CARTO e memoria delle mappe sul telefono)
• OpenStreetMap: server di riserva quando il principale è sovraccarico
• Corretti i link non più validi (Italo, Trenitalia rimborsi, area riservata, treni garantiti)

0.2
• Ricerca soluzioni di nuovo funzionante: LeFrecce ora richiede una sessione con token, gestita in automatico
• In caso di errore viene mostrato il motivo

0.1
• Prima versione condivisa, con chiave di firma privata. Comprende tutte le funzioni elencate qui sotto.

Sviluppo (versioni interne)

2.9
• Modalità per daltonici (rosso-verde, blu-giallo) con simboli: ritardi, binari, affollamento, puntualità, widget
• Fonti dei dati citate con siti e licenze; app gratuita e senza scopo di lucro
• Note legali (affiliazione, marchi, dati, stime, responsabilità, privacy GDPR, fonti e licenze) con versione dell'app
• Avviso da accettare al primo avvio

2.8.1
• App creata da Marco Jannino: firma in Altro, Impostazioni e Privacy

2.8
• Tabellone con tutti i prossimi treni (6 ore, estendibile fino a 24 con "Mostra treni successivi")
• Widget Stazione con i treni delle prossime 4 ore (fino a 40); di notte mostra le prime partenze del mattino
• Widget Tragitto fino a 20 soluzioni

2.7
• Puntualità: statistiche mensili da TrovaTreno.it (open data) per operatore, stazione e treno, con classifiche e confronto col mese precedente
• Puntualità del treno nella scheda Info e della stazione nel tabellone

2.6
• Affollamento con i colori Trenord (verde, giallo, rosso) su scheda treno, soluzioni, tabellone, linee e confronto itinerari
• Fonti: Trenord (sensori/storico), previsione SBB per i treni svizzeri e TILO, stima per fascia oraria quando manca il dato ufficiale (indicata con ≈)

2.5
• Binario previsto e binario reale separati: scheda treno, tabellone, soluzioni, linee, mappa, widget, notifiche e assistente
• Binario cambiato evidenziato in rosso (es. 3 → 5)

2.4
• Linee: elenco completo Trenord estratto dal sito ufficiale, linee TILO e rete FerrovieNord
• Ogni linea: prossimi treni nelle due direzioni, stato, avvisi e stazioni dalla pagina ufficiale, ★ preferiti
• Svizzera: informazioni traffico SBB in tempo reale

2.3
• Versione inglese: bandierine 🇮🇹/🇬🇧 nella schermata Cerca (anche in Impostazioni → Lingua)
• Assistente treni: domande su ritardi, orari, tabelloni, scioperi, circolazione, ascensori
• Quanto sei green: CO₂, carburante (prezzi MIMIT), pedaggi, parcheggio e tempo auto vs treno, giornaliero e annuale, con registro automatico dei ritardi

2.2
• Condizioni di trasporto (Trenord, Trenitalia, Malpensa Express, TILO) e diritti UE 2021/782
• Sezione TILO: linee, servizi, tariffe transfrontaliere Arcobaleno
• Confronta itinerari: es. Varese → Como via Mendrisio o via Milano, con durata, cambi, costo e fattibilità
• Treni garantiti in caso di sciopero: elenchi ufficiali aggiornati dalle aziende
• Avvisi TILO tra i comunicati

2.1
• Scioperi dalla fonte ufficiale (Osservatorio scioperi del Ministero), solo settore ferroviario
• Comunicati delle aziende (Trenord, FerrovieNord, ViaggiaTreno): scioperi, lavori, circolazione
• Notifiche per circolazione bloccata o rallentata sulle tue tratte, aggiornate a ogni variazione
• Ascensori e scale fuori servizio per binario (FerrovieNord) e variazioni RFI
• Binari con ascensori e rampe (OpenStreetMap), contatti assistenza Trenord e Sala Blu
• Rivendite, biglietterie, emettitrici e obliteratrici vicine con mappa, distanza e contactless

2.0
• Nuova grafica: soluzioni con binari e ritardi, tragitto a pallini, schede Tragitto/Info/Mappa
• Widget configurabili uno per uno (stazione, tratta, linea, treno) con righe in tempo reale
• Linee preferite (es. S5 Varese – Treviglio) nelle due direzioni
• Tocca un treno per i dettagli, tocca una fermata per il tabellone
• Sveglia prima della fermata
• Avvisi su interruzioni e treni soppressi delle tratte preferite
• Avvisi accessibili per persone sorde: vibrazioni dedicate e flash
• Accessibilità stazioni: variazioni RFI di ascensori e rampe, Sale Blu
• Affollamento Trenord (quando disponibile)
• Impostazioni, opzioni avanzate (max cambi, escludi categorie), backup

1.1
• Widget aggiornati automaticamente, firma fissa per gli aggiornamenti

1.0
• Prima versione"""

@Composable
fun SavedScreen(vm: MainViewModel, onBack: () -> Unit, onOpen: () -> Unit) {
    var list by remember { mutableStateOf(vm.store.savedSearches()) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Orari salvati offline"), onBack)
        if (list.isEmpty()) MessageBox(tx("Dopo una ricerca tocca l'icona di download per salvare gli orari."))
        LazyColumn {
            items(list, key = { it.key }) { s: SavedSearch ->
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.openSaved(s); onOpen() }.padding(start = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                            Text(s.title, fontWeight = FontWeight.Medium)
                            Text("${s.solutions.size} soluzioni · salvato il ${Fmt.dayTime(s.savedAt)}", color = Color.Gray, fontSize = 13.sp)
                        }
                        IconButton({ vm.store.deleteSaved(s.key); list = vm.store.savedSearches() }) {
                            Icon(Icons.Filled.Delete, tx("Elimina"), tint = Color.Gray)
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun RemindersScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(vm.store.reminders().sortedBy { it.at }) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Notifiche programmate"), onBack)
        if (list.isEmpty()) MessageBox(tx("Nessuna notifica. Usa \"Avvisami\" su un treno o una soluzione."))
        LazyColumn {
            items(list, key = { it.id }) { r ->
                Surface(color = MaterialTheme.colorScheme.surface) {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Alarm, null, tint = Green)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f).padding(vertical = 12.dp)) {
                            Text(r.label, fontWeight = FontWeight.Medium)
                            Text(
                                "Avviso alle ${Fmt.dayTime(r.at)} · ${if (r.arrival) "arrivo" else "partenza"} ${Fmt.time(r.eventTime)}",
                                color = Color.Gray, fontSize = 13.sp,
                            )
                        }
                        IconButton({ Reminders.cancel(ctx, r.id); list = vm.store.reminders().sortedBy { it.at } }) {
                            Icon(Icons.Filled.Delete, tx("Elimina"), tint = Color.Gray)
                        }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

/** Ultimi dati delle notizie in memoria: riaprendo la schermata si vedono subito, poi si aggiornano. */
object NewsCache {
    var strikes: List<Strike>? = null
    var notices: List<Notice>? = null
    var at: Long = 0L
    val details = HashMap<String, String>()
}

/** Scioperi (fonte ufficiale MIT) e comunicati delle aziende: circolazione, lavori, avvisi. Si aggiorna da sola ogni 5 minuti. */
@Composable
fun NewsScreen(onBack: () -> Unit, onGuaranteed: () -> Unit = {}) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var strikes by remember { mutableStateOf(NewsCache.strikes) }
    var strikesFailed by remember { mutableStateOf(false) }
    var notices by remember { mutableStateOf(NewsCache.notices) }
    var updatedAt by remember { mutableStateOf(NewsCache.at) }
    var refreshing by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<Notice?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    // Aggiornamento automatico: subito (se i dati hanno più di 2 minuti) e poi ogni 5 minuti finché la schermata è aperta
    LaunchedEffect(Unit) {
        if (System.currentTimeMillis() - NewsCache.at > 2 * 60_000L) tick++
        while (true) {
            kotlinx.coroutines.delay(5 * 60_000L)
            tick++
        }
    }
    LaunchedEffect(tick) {
        if (tick == 0) return@LaunchedEffect
        refreshing = true
        coroutineScope {
            launch {
                try {
                    val l = withContext(Dispatchers.IO) { Sources.railStrikes() }
                    strikes = l; NewsCache.strikes = l; strikesFailed = false
                } catch (e: Exception) {
                    if (strikes == null) strikesFailed = true
                }
            }
            launch {
                val l = withContext(Dispatchers.IO) { Sources.allNotices() }
                if (l.isNotEmpty() || notices == null) { notices = l; NewsCache.notices = l }
            }
        }
        NewsCache.at = System.currentTimeMillis()
        updatedAt = NewsCache.at
        refreshing = false
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Notizie"), onBack) { IconButton({ tick++ }, enabled = !refreshing) { Icon(Icons.Filled.Refresh, tx("Aggiorna ora")) } }
        GreenTabs(listOf(tx("Scioperi"), tx("Circolazione"), tx("Lavori"), tx("Tutti")), tab) { tab = it }
        if (refreshing) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (updatedAt > 0) tx("Aggiornato alle") + " " + Fmt.time(updatedAt) + " · " + tx("si aggiorna da solo ogni 5 minuti o trascinando giù")
                else tx("Caricamento…"),
                color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f),
            )
            TextButton({ tick++ }, enabled = !refreshing) { Text(tx("Aggiorna ora"), color = Green) }
        }
        PullRefresh(refreshing, { tick++ }) { LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 6.dp)) {
            if (tab == 0) {
                val l = strikes
                when {
                    strikesFailed -> item { MessageBox(tx("Osservatorio scioperi non raggiungibile in questo momento")) }
                    l == null -> item { LoadingBox() }
                    l.isEmpty() -> item { MessageBox(tx("Nessuno sciopero ferroviario proclamato")) }
                    else -> items(l) { st -> StrikeCard(st) }
                }
                item {
                    WhiteCard(onClick = onGuaranteed) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.EventAvailable, null, tint = Green)
                            Spacer(Modifier.width(12.dp))
                            Text(tx("Treni garantiti: elenchi ufficiali aggiornati"), Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            Icon(Icons.Filled.ChevronRight, null, tint = Muted)
                        }
                    }
                }
                // Comunicati delle aziende sugli scioperi (treni garantiti ecc.)
                val comm = notices.orEmpty().filter { it.kind == Notice.Kind.STRIKE }
                if (comm.isNotEmpty()) {
                    item { SectionHeader(tx("Comunicati delle aziende")) }
                    items(comm) { n -> NoticeCard(n) { open = n } }
                }
            } else {
                val l = notices
                val kind = when (tab) {
                    1 -> Notice.Kind.BLOCKED
                    2 -> Notice.Kind.WORKS
                    else -> null
                }
                when {
                    l == null -> item { LoadingBox() }
                    else -> {
                        val f = if (kind == null) l else l.filter { it.kind == kind }
                        if (f.isEmpty()) item { MessageBox(if (tab == 1) tx("Nessuna anomalia di circolazione segnalata") else tx("Nessun avviso")) }
                        items(f) { n -> NoticeCard(n) { open = n } }
                    }
                }
                item {
                    Column(Modifier.padding(horizontal = 8.dp)) {
                        SectionHeader(tx("Siti ufficiali"))
                        TextButton({ openUrl(ctx, "https://www.trenord.it/linee-e-orari/circolazione/tempo-reale/") }) { Text(tx("Trenord · circolazione in tempo reale"), color = Green) }
                        TextButton({ openUrl(ctx, Sources.TRENITALIA_INFO_URL) }) { Text(tx("Trenitalia · notizie infomobilità"), color = Green) }
                        TextButton({ openUrl(ctx, "https://www.ferrovienord.it") }) { Text("FerrovieNord", color = Green) }
                        TextButton({ openUrl(ctx, "https://www.tilo.ch/avvisi.html") }) { Text(tx("TILO · avvisi"), color = Green) }
                    }
                }
            }
        } }
    }
    open?.let { n -> NoticeDialog(n) { open = null } }
}

/** Dettaglio di un comunicato: testo completo letto dalla pagina della fonte, con link diretto. */
@Composable
private fun NoticeDialog(n: Notice, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var full by remember(n.url, n.title) { mutableStateOf(NewsCache.details[n.url + n.title]) }
    var loading by remember(n.url, n.title) { mutableStateOf(false) }
    LaunchedEffect(n.url, n.title) {
        // Il testo dell'elenco è già completo per Trenitalia; per gli altri leggiamo la pagina del comunicato
        if (full == null && n.text.length < 400 && n.url.isNotBlank() && !n.url.endsWith(".pdf", true) &&
            n.url != Sources.TRENITALIA_INFO_URL
        ) {
            loading = true
            val t = withContext(Dispatchers.IO) { runCatching { Sources.noticeDetail(n.url) }.getOrDefault("") }
            if (t.isNotBlank()) { full = t; NewsCache.details[n.url + n.title] = t }
            loading = false
        }
    }
    val body = full?.takeIf { it.length > n.text.length } ?: n.text
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(n.title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("${n.kind.label} · ${n.date.ifBlank { tx("data non indicata") }}", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                if (body.isNotBlank()) Text(body, lineHeight = 20.sp)
                else if (!loading) Text(tx("Il testo completo è disponibile sul sito della fonte."), color = Muted)
                Spacer(Modifier.height(12.dp))
                SourceLink(n.source, n.url)
            }
        },
        confirmButton = { TextButton({ openUrl(ctx, n.url); onClose() }) { Text(tx("Apri la fonte"), color = Green) } },
        dismissButton = {
            TextButton({ shareText(ctx, n.title + (if (n.date.isNotBlank()) " (" + n.date + ")" else "") + "\n" + body.take(800) + "\n" + tx("Fonte") + ": " + n.url) }) {
                Text(tx("Condividi"))
            }
        },
    )
}

/** "Fonte: nome · sito ↗", toccabile: apre il link diretto. */
@Composable
fun SourceLink(name: String, url: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    if (url.isBlank()) return
    val site = Regex("^https?://(?:www\\.)?([^/]+)").find(url)?.groupValues?.get(1) ?: url
    Row(
        modifier.clickable { openUrl(ctx, url) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Link, null, tint = Green, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(tx("Fonte") + ": " + (if (name.isNotBlank() && !site.contains(name.substringBefore(" ").lowercase())) "$name · " else "") + site,
            color = Green, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StrikeCard(s: Strike) {
    val ctx = LocalContext.current
    val national = s.relevance.contains("nazional", true)
    WhiteCard(onClick = {
        shareText(ctx, "${s.title}\n${tx("Orari")}: ${s.modality}\n${tx("Chi")}: ${s.company}\n${tx("Dove")}: ${s.region}\n" +
            tx("Fonte") + ": " + s.url)
    }) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Warning, null, tint = LateRed, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(tx("Sciopero") + " " + s.start + (if (s.end.isNotBlank() && s.end != s.start) " → ${s.end}" else ""),
                    fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Text(s.relevance.uppercase(), color = if (national) LateRed else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            StrikeLine(tx("Orari"), s.modality)
            StrikeLine(tx("Chi"), s.company)
            StrikeLine(tx("Dove"), s.region + if (s.province.isNotBlank() && s.province != "Tutte") " (${s.province})" else "")
            StrikeLine(tx("Settore"), s.sector)
            StrikeLine(tx("Sindacati"), s.unions)
            if (s.note.isNotBlank()) StrikeLine(tx("Note"), s.note)
            SourceLink(s.sourceName, s.url, Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun StrikeLine(label: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.padding(top = 3.dp)) {
        Text("$label: ", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 14.sp)
    }
}

@Composable
private fun NoticeCard(n: Notice, onClick: () -> Unit) {
    WhiteCard(onClick = onClick) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val col = when (n.kind) {
                    Notice.Kind.STRIKE, Notice.Kind.BLOCKED -> LateRed
                    Notice.Kind.WORKS -> Color(0xFFEF6C00)
                    Notice.Kind.OTHER -> Muted
                }
                Text(n.kind.label.uppercase(), color = col, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(n.date, color = Muted, fontSize = 12.sp)
            }
            Text(n.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.padding(top = 2.dp))
            if (n.text.isNotBlank()) Text(n.text.take(220) + if (n.text.length > 220) "…" else "", color = Muted, fontSize = 13.sp)
            SourceLink(n.source, n.url, Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun InfoScreen(title: String, body: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        GreenTopBar(title, onBack)
        Text(body, modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp), lineHeight = 22.sp)
    }
}

/** Report delle correzioni: per ogni versione, i problemi trovati e come sono stati risolti. */
const val FIXES_TEXT = """2.4 · IN LAVORAZIONE
• Correzioni in corso: verranno elencate qui al rilascio

2.3.4
• Rivendite vicine restava ferma su "Cerco i punti vendita entro 800 m…". La prima volta l'app scaricava dal sito Trenord tutte le 12 province e le pagine di ogni biglietteria, e se intanto partiva l'aggiornamento settimanale aspettava anche quello. Ora usa un elenco già pronto (un solo file), altrimenti solo le province vicine; l'aggiornamento avviene in background e dopo 30 secondi al massimo la schermata mostra quello che è arrivato

2.3.1
• Stato dei servizi: ViaggiaTreno, OpenStreetMap e Postpass comparivano rossi anche quando funzionavano (nome dell'app rifiutato da ViaggiaTreno, solo il server principale di OpenStreetMap provato, richiesta di prova a Postpass sbagliata). Ora il controllo fa come l'app
• ViaggiaTreno: se il sito rifiuta la richiesta (errore 403) l'app riprova subito presentandosi come il browser del telefono

2.3
• Rivendite e riepilogo stazione: "Servizio mappe momentaneamente non raggiungibile". Tre dei quattro server usati erano stati chiusi e il quarto rifiutava le richieste (errore 406, nuove regole anti-abuso di Overpass). Ora l'app usa i 3 server attivi (più OSM.ch in Svizzera), si identifica come richiesto e, se non bastano, passa a Postpass e ai dati salvati. Google Maps resta come ultima possibilità, a portata di tasto
• Emettitrici self-service: venivano contati anche i parcometri ("parking tickets"). Ora sono esclusi
• Attese più brevi quando un server è lento: si passa al successivo dopo 8 secondi di connessione invece di 12
• Mappe coperte dalla scritta "API KEY REQUIRED": il servizio CARTO dal 2026 chiede una chiave a pagamento. Ora le mappe sono quelle ufficiali di OpenStreetMap, con riserva automatica su OpenStreetMap France
• Stazioni vicine: la mappa copriva il titolo in alto. Ora resta nei suoi bordi
• Widget: il tasto ⟳ spesso non aggiornava nulla (il telefono ignorava la richiesta) e non dava segni. Ora ricollega l'elenco e ricarica davvero, con "aggiorno…" e un avviso a schermo
• Treni regionali Trenord e TILO: toccandoli (dal widget o dalle soluzioni) compariva "Treno S50 TRENORD 25592 non trovato", e mancavano ritardo e binario in tempo reale. Il numero arrivava con linea e impresa attaccate; ora l'app usa solo il numero (25592)
• Impresa del treno: davanti al numero c'era sempre "TI" (Trenitalia), anche per i treni Trenord. Ora l'impresa è letta da ViaggiaTreno (codice impresa) o dal nome del treno
• Puntualità: Tper, EAV, Ferrovie del Gargano e altre imprese regionali finivano insieme in "Altri operatori", quindi non si potevano confrontare con Trenord e Trenitalia. Ora ognuna ha la sua riga (con almeno 100 arrivi osservati nel mese)
• WC: comparivano solo come una riga nel riepilogo della scheda "Stazione" e sparivano se OpenStreetMap non rispondeva. Ora hanno una schermata propria, raggiungibile anche dal tabellone, con Google Maps come riserva
• Rivendite: comparivano tutte le tabaccherie ed edicole di OpenStreetMap, anche quelle che non vendono biglietti. Ora solo i punti vendita autorizzati dagli elenchi ufficiali
• Rete FerrovieNord: le soluzioni da o per Varese Nord, Milano Cadorna, Saronno, Como Lago, Novara Nord e le altre stazioni FN non uscivano, perché l'app calcolava l'identificativo LeFrecce come per le stazioni RFI (Varese Nord ha invece 830025251). Ora lo cerca per nome, e se LeFrecce non risponde usa gli orari ufficiali Trenord
• Stazioni vicine, mappe, rivendite e WC: le stazioni FerrovieNord come Varese Nord, Como Lago o Novara Nord mancavano, perché non sono nell'elenco stazioni di ViaggiaTreno. Ora sono incluse
• Puntualità: cercando "Varese Nord" (o un'altra stazione FerrovieNord) compariva "Nessun risultato" senza spiegazione. TrovaTreno non pubblica questa rete: ora l'app raccoglie i dati da sola e lo spiega
• Puntualità: Milano Porta Garibaldi e Milano Centrale comparivano entrambe come "Milano", quindi non si trovavano cercando "Garibaldi". Ora hanno il nome completo
• Soluzioni e widget tratta: lo stesso treno TILO compariva due volte ("RE SBB 25591" e "S50 TRENORD 25591"). Ora compare una volta sola, con entrambe le sigle unite: "RE SBB / SU S50 TRENORD 25591"

2.2
• Assistente: alle domande generali (rimborsi, bici, bambini, assistenza…) rispondeva "Non ho capito". Ora ha una base di conoscenza con fonti ufficiali
• Assistente: bastava un accento o un errore di battitura ("rimborzo") per non capire. Ora la comprensione è tollerante
• Assistente: "bagni a Saronno" o "bus a Varese" venivano scambiati per nomi di stazione. Ora sono domande sui servizi, e parole come "bus" non scattano più dentro nomi come "Busto Arsizio"
• Assistente: le risposte non citavano la fonte. Ora c'è il link diretto sotto la risposta
• OpenStreetMap: le richieste ora si identificano con nome e versione dell'app, come chiesto dai server

2.1
• Puntualità: Trenord veniva confrontata con tutta Trenitalia (regionali + Frecce + Intercity). Ora il confronto è tra servizi dello stesso tipo, ricalcolato dai dati per treno
• Treno seguito: binario e "parte tra 5 minuti" si riferivano sempre alla stazione d'origine, anche salendo a metà percorso. Ora valgono per la fermata scelta con "Salgo qui"
• Ricerca senza rete: compariva solo un errore. Ora si vedono gli ultimi orari scaricati per la tratta, con l'ora dell'aggiornamento

0.4
• Assistente: non diceva da quale binario parte il treno né il binario nella stazione di partenza delle soluzioni. Corretto
• Nessuna notifica se cambiava il binario o aumentava il ritardo del treno seguito: aggiunta
• Le domande a voce non erano possibili: aggiunti microfono, scorciatoie e riquadro rapido

0.3
• Widget: mostravano "dati non disponibili" a ogni errore momentaneo di ViaggiaTreno e poi si ricaricavano. Ora riprovano da soli e, se serve, tengono gli ultimi dati validi con l'ora
• Notizie: la fonte ViaggiaTreno era ferma al 2019. Sostituita con "Notizie Infomobilità" di Trenitalia; ogni notizia ora cita la fonte con il link diretto
• Notizie non si aggiornavano da sole: ora ogni 5 minuti, più il pulsante "Aggiorna ora"
• Link non più validi: Italo assistenza e news, Trenitalia rimborsi, area riservata, treni garantiti (indirizzo cambiato). Corretti
• Mappe lente: le tessere venivano riscaricate ogni volta (cartella della cache non scrivibile) dai server OpenStreetMap, che limitano le app. Ora server CARTO e cache nel telefono; la mappa del treno carica le fermate in parallelo
• "Dati non disponibili" in rivendite e servizi di stazione: il server OpenStreetMap principale era sovraccarico. Aggiunti tre server di riserva
• Statistiche di puntualità bloccate per 24 ore se la prima apertura avveniva senza rete. Corretto
• Scioperi generali e plurisettoriali che fermano anche i treni non comparivano. Inclusi
• Guasti ad ascensori FerrovieNord non letti (la tabella si carica via JavaScript). Ora letti dal vivo come quelli RFI

0.2
• Ricerca soluzioni: "Impossibile contattare il server". LeFrecce ora richiede un token di sessione, che l'app non chiedeva; in più il servizio di riserva ViaggiaTreno è stato dismesso (errore 404). Aggiunta la sessione automatica
• Il messaggio di errore non diceva il motivo: ora lo indica tra parentesi

0.1
• Firma: la password della chiave era scritta in chiaro nel progetto (chiunque poteva firmare aggiornamenti). Nuova chiave privata, fuori dal progetto, letta dai segreti di GitHub
• Compilazione: errori con Kotlin 2.1 nell'elenco linee (tipo non dedotto) e nelle annotazioni SuppressLint di Rivendite e Stazioni. Corretti
• Build: la lettura della chiave in build.gradle.kts non compilava (riferimento java.util). Corretta
• Workflow GitHub: compilava lo zip con il numero più alto invece dell'ultimo caricato e non firmava l'APK. Riscritto, con messaggi chiari su chiave e password"""

const val WIDGETS_TEXT = """Tieni premuto su uno spazio vuoto della schermata Home → Widget → Binario, poi scegli cosa mostrare. Tocca il titolo del widget per cambiarlo.

• Tragitto / Linea: i prossimi treni di una tratta o di una linea preferita (es. S5), con ritardo e binario.
• Treno: l'andamento di un treno fermata per fermata.
• Stazione: le partenze da una stazione a scelta.
• Preferiti: lo stato di tutti i treni preferiti in un colpo solo.

Tocca una riga per aprire il treno o il tabellone.

Tocca ⟳ sul widget per aggiornarlo; si aggiorna da solo ogni 30 minuti."""

const val PRIVACY_TEXT = """App creata da Marco Jannino.

Binario non raccoglie dati personali e non ha pubblicità. Preferiti, ricerche, promemoria e treni abituali restano solo sul telefono. Se usi "Feedback e segnala un bug", nome, email e messaggio (e, se lo scegli, versione dell'app e modello del telefono) vengono inviati allo sviluppatore solo per risponderti.

I dati su orari, ritardi e stazioni vengono letti dai servizi pubblici ViaggiaTreno (RFI/Trenitalia) e LeFrecce. Le mappe usano OpenStreetMap.

Permessi:
• Notifiche: notifica fissa del treno, promemoria e avvisi scioperi.
• Servizio in primo piano / blocco stand-by: per aggiornare la notifica del treno seguito senza che l'app venga sospesa.
• Esecuzione all'avvio: per riattivare le notifiche programmate dopo il riavvio.
• Sveglie e promemoria: per far arrivare le notifiche programmate all'ora giusta.
• Posizione: per mostrare le stazioni vicine e la tua posizione sulla mappa (solo quando usi quella schermata).
• Vibrazione: per le notifiche.
• Voce: gli avvisi vocali usano la sintesi vocale del telefono, senza inviare dati. Le domande a voce passano dal riconoscimento vocale del telefono (di solito Google): Binario non chiede il permesso del microfono.

Questa app non è affiliata a Trenitalia, RFI, Italo o Trenord."""

const val WIDGETS_TEXT_EN = """Long-press an empty area of the Home screen → Widgets → Binario, then choose what to show. Tap the widget title to change it.

• Route / Line: next trains on a route or favourite line (e.g. S5), with delay and platform.
• Train: a train's progress stop by stop.
• Station: departures from a station of your choice.
• Favourites: the status of all your favourite trains at a glance.

Tap a row to open the train or the departure board."""

const val HELP_TEXT_EN = """How do I search a timetable?
In the Search tab choose origin and destination, date and time, then tap Search. Tap a train name (e.g. "TI FR 9627") to see delays, stops and platforms.

How do I see the departure board of a stop?
In the train view tap a stop and choose "Departures and arrivals from here".

How does the wake-up alarm work?
In the train view tap the stop where you get off and choose "Wake me before this stop". The alarm rings when the train leaves the previous stop (or 4 minutes before the expected arrival). Turn on "Alerts for deaf or hard-of-hearing people" in Settings for strong vibration and flash.

How do I add a line?
Trains tab → Favourite lines → Add, e.g. S5 with termini Varese and Treviglio.

How do I set up a widget?
Add it from the Home screen and choose what to show. To change it, tap the widget title.

Can I ask questions?
Yes: open the train assistant (speech-bubble icon in Search) and ask e.g. "delay train 2070" or "trains from Varese to Milano"."""

const val PRIVACY_TEXT_EN = """App created by Marco Jannino.

Binario collects no personal data and has no ads. Favourites, searches reminders and usual trains stay on your phone.

Timetables, delays and stations come from the public services ViaggiaTreno (RFI/Trenitalia) and LeFrecce; cross-border routes from the official Swiss timetable; maps and routes from OpenStreetMap; fuel prices from the Italian Ministry (MIMIT).

Permissions: notifications (followed train, reminders, alerts), foreground service (to keep the followed train updated), start at boot (to restore scheduled notifications), alarms, location (nearby stations and sellers, only while using those screens), vibration.

This app is not affiliated with Trenitalia, RFI, Italo, Trenord, TILO or FerrovieNord."""

/** Note legali (italiano). La versione e l'autore sono inseriti dove la pagina viene mostrata. */
const val LEGAL_TEXT = """1. Chi siamo
Binario è un'app indipendente e gratuita, creata da Marco Jannino. Non è affiliata, sponsorizzata o approvata da Trenitalia, RFI, Gruppo FS, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB, né da altre aziende di trasporto o enti citati.

2. Marchi
Nomi, marchi e loghi delle aziende citate appartengono ai rispettivi titolari e sono usati solo per indicare la fonte delle informazioni o il servizio a cui si riferiscono. L'app non usa loghi ufficiali delle aziende.

3. Dati e affidabilità
Orari, ritardi, binari, soppressioni, prezzi, scioperi, avvisi, accessibilità, affollamento e statistiche provengono da fonti pubbliche di terze parti e sono mostrati "così come sono", senza garanzia di correttezza, completezza o aggiornamento. Possono contenere errori o ritardi di aggiornamento.
Fanno sempre fede le informazioni ufficiali delle aziende: tabelloni e annunci in stazione, personale, siti e app ufficiali.

4. Stime
Affollamento indicato con "≈", calcoli "Quanto sei green" (CO₂, carburante, pedaggi, tempi con traffico), confronto itinerari e tariffe transfrontaliere indicative sono stime a scopo informativo e non costituiscono offerta né garanzia di prezzo o di tempo di viaggio.

5. Biglietti e acquisti
L'app non vende biglietti né gestisce pagamenti. I pulsanti di acquisto aprono i siti ufficiali delle aziende, le cui condizioni di vendita e di trasporto si applicano integralmente.

6. Limitazione di responsabilità
Nei limiti consentiti dalla legge, l'autore non è responsabile per danni diretti o indiretti derivanti dall'uso dell'app o dall'affidamento sulle sue informazioni, inclusi treni persi, coincidenze mancate, spese, sanzioni o disagi. Notifiche, promemoria e sveglia fermata possono non arrivare (risparmio energetico, assenza di rete, impostazioni del telefono): non usarli come unico sistema di allerta.
I diritti dei passeggeri (rimborsi, indennizzi, assistenza) vanno esercitati nei confronti dell'azienda di trasporto, secondo il Regolamento UE 2021/782 e le sue condizioni.

7. Privacy (GDPR)
L'app non richiede registrazione, non ha pubblicità e non raccoglie né vende dati personali. Preferiti, impostazioni, promemoria e registro "green" restano solo sul telefono e si cancellano disinstallando l'app.
Per funzionare l'app contatta direttamente i servizi delle fonti indicate: come per qualsiasi sito web, questi ricevono l'indirizzo IP e i dati della richiesta (es. stazione o numero di treno), secondo le loro informative.
La posizione è usata solo sul telefono e solo nelle schermate "Stazioni vicine" e "Rivendite", con il tuo permesso.

8. Fonti dei dati (citate)
Tutte le informazioni provengono da fonti pubblicamente accessibili e consultabili gratuitamente da chiunque, senza registrazione, abbonamento o accordo commerciale. L'app non acquista dati, non usa servizi a pagamento e non rivende nulla: si limita a mostrare, citandone la fonte, ciò che le aziende e gli enti pubblicano.
• Orari, ritardi, binari previsti e reali: ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Soluzioni di viaggio e prezzi: LeFrecce – Trenitalia (lefrecce.it)
• Scioperi: Osservatorio sugli scioperi nei trasporti – Ministero delle Infrastrutture e dei Trasporti (scioperi.mit.gov.it)
• Avvisi, linee, affollamento, condizioni di trasporto: Trenord (trenord.it)
• Stato degli impianti e notizie: FerrovieNord (ferrovienord.it)
• Ascensori e accessibilità stazioni, Sala Blu: RFI (rfi.it)
• Treni e servizi transfrontalieri: TILO (tilo.ch)
• Orario svizzero e affollamento previsto: transport.opendata.ch / opentransportdata.swiss (FFS/SBB)
• Tariffe Arcobaleno: Comunità tariffale Ticino e Moesano (arcobaleno.ch)
• Diritti dei passeggeri: Regolamento (UE) 2021/782 (eur-lex.europa.eu)
• Statistiche di puntualità: TrovaTreno.it – open data, licenza CC BY 4.0
• Prezzi carburanti: open data Ministero delle Imprese e del Made in Italy (mimit.gov.it), licenza IODL 2.0
• Mappe, rivendite, obliteratrici, ascensori: © OpenStreetMap contributors (openstreetmap.org), licenza ODbL
• Percorsi stradali: OSRM (project-osrm.org) su dati OpenStreetMap
• Software: osmdroid e componenti Android/Jetpack, licenza Apache 2.0

9. Gratuità e uso delle fonti
Binario è gratuita, senza pubblicità, senza acquisti in-app e senza scopo di lucro. Le fonti sono consultate come farebbe un normale utente dal proprio telefono, con richieste limitate e su azione dell'utente o a intervalli moderati; i contenuti restano di proprietà dei rispettivi titolari. Le pagine ufficiali sono mostrate integre nel lettore integrato o aprendo il sito originale.
Se un'azienda o un titolare di dati chiede di modificare o non mostrare più un contenuto, la funzione relativa verrà rimossa.

10. Contatti e segnalazioni
Per segnalazioni, richieste di rimozione o correzioni: contatta l'autore, Marco Jannino.
Per reclami sul servizio ferroviario rivolgiti all'azienda di trasporto interessata.

11. Modifiche
Queste note possono essere aggiornate con le nuove versioni dell'app. La versione in uso è indicata in alto."""

const val LEGAL_TEXT_EN = """1. About
Binario is an independent, free app created by Marco Jannino. It is not affiliated with, sponsored or endorsed by Trenitalia, RFI, FS Group, Italo-NTV, Trenord, FerrovieNord/FNM, TILO, SBB, or any other transport company or body mentioned.

2. Trademarks
Company names and trademarks belong to their respective owners and are used only to identify the source of information or the service referred to. The app does not use official company logos.

3. Data and reliability
Timetables, delays, platforms, cancellations, fares, strikes, notices, accessibility, crowding and statistics come from public third-party sources and are provided "as is", without any warranty of accuracy, completeness or timeliness.
Official information always prevails: station boards and announcements, staff, official websites and apps.

4. Estimates
Crowding marked "≈", "How green are you" figures (CO₂, fuel, tolls, traffic times), route comparisons and indicative cross-border fares are estimates for information only and are not an offer or a guarantee of price or travel time.

5. Tickets and purchases
The app does not sell tickets or handle payments. Buy buttons open the operators' official websites, whose sales and carriage conditions fully apply.

6. Limitation of liability
To the extent permitted by law, the author is not liable for any direct or indirect damage arising from the use of the app or reliance on its information, including missed trains or connections, costs, fines or inconvenience. Notifications, reminders and stop alarms may not arrive (battery saving, no network, phone settings): do not rely on them as your only alert.
Passenger rights (refunds, compensation, assistance) must be claimed from the transport operator under EU Regulation 2021/782 and its conditions.

7. Privacy (GDPR)
The app requires no registration, shows no ads and does not collect or sell personal data. Favourites, settings, reminders and the green log stay on your phone and are deleted when you uninstall the app.
To work, the app contacts the listed sources directly: like any website, they receive your IP address and the request data (e.g. station or train number), under their own privacy policies.
Location is used only on the phone, only in "Nearby stations" and "Ticket sellers", with your permission.

8. Data sources (cited)
All information comes from publicly accessible sources that anyone can consult free of charge, without registration, subscription or commercial agreement. The app does not buy data, does not use paid services and resells nothing: it only shows, citing the source, what companies and public bodies publish.
• Timetables, delays, scheduled and actual platforms: ViaggiaTreno – RFI / Trenitalia (viaggiatreno.it)
• Journey solutions and fares: LeFrecce – Trenitalia (lefrecce.it)
• Strikes: Transport Strike Observatory – Italian Ministry of Infrastructure and Transport (scioperi.mit.gov.it)
• Notices, lines, crowding, conditions of carriage: Trenord (trenord.it)
• Facility status and news: FerrovieNord (ferrovienord.it)
• Elevators and station accessibility, Sala Blu: RFI (rfi.it)
• Cross-border trains and services: TILO (tilo.ch)
• Swiss timetable and expected crowding: transport.opendata.ch / opentransportdata.swiss (SBB)
• Arcobaleno fares: Ticino and Moesano fare network (arcobaleno.ch)
• Passenger rights: Regulation (EU) 2021/782 (eur-lex.europa.eu)
• Punctuality statistics: TrovaTreno.it – open data, CC BY 4.0 licence
• Fuel prices: Italian Ministry of Enterprises and Made in Italy open data (mimit.gov.it), IODL 2.0 licence
• Maps, ticket sellers, validators, elevators: © OpenStreetMap contributors (openstreetmap.org), ODbL licence
• Road routes: OSRM (project-osrm.org) on OpenStreetMap data
• Software: osmdroid and Android/Jetpack components, Apache 2.0 licence

9. Free of charge and use of sources
Binario is free, ad-free, with no in-app purchases and non-profit. Sources are queried as a normal user would from their own phone, with limited requests, on user action or at moderate intervals; content remains the property of its owners. Official pages are shown unaltered in the built-in reader or by opening the original site.
If a company or data owner asks to change or stop showing some content, the related feature will be removed.

10. Contact
For reports, removal requests or corrections: contact the author, Marco Jannino.
For complaints about rail services, contact the transport operator concerned.

11. Changes
These notes may be updated with new app versions. The version in use is shown at the top."""

/** Pagina "Note legali": versione e autore in alto, poi il testo. */
@Composable
fun LegalScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        GreenTopBar(tx("Note legali"), onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("Binario · " + tx("versione") + " " + APP_VERSION, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(tx(CREDIT), color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Text(if (com.binario.treni.data.I18n.en) LEGAL_TEXT_EN else LEGAL_TEXT, lineHeight = 21.sp, fontSize = 14.sp)
        }
    }
}

/** Avviso al primo avvio (e dopo aggiornamenti delle note): va accettato per usare l'app. */
@Composable
fun LegalConsent(store: com.binario.treni.data.Store, onOpenLegal: () -> Unit, onAccepted: () -> Unit = {}) {
    var accepted by remember { mutableStateOf(store.legalAccepted == LEGAL_VERSION) }
    if (accepted) return
    AlertDialog(
        onDismissRequest = {},
        title = { Text(tx("Prima di iniziare")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Binario " + APP_VERSION + " · " + tx(CREDIT), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(tx("Binario è un'app indipendente, non affiliata a Trenitalia, RFI, Italo, Trenord, FerrovieNord, TILO o SBB. I dati provengono da fonti pubbliche e possono contenere errori: fanno sempre fede tabelloni, annunci e canali ufficiali. Affollamento, costi e tempi stimati sono indicativi. Tutte le fonti sono pubbliche, gratuite e citate nelle note legali. L'app è gratuita, senza pubblicità, non vende biglietti e non raccoglie dati personali."))
                TextButton(onOpenLegal) { Text(tx("Leggi le note legali complete"), color = Green) }
            }
        },
        confirmButton = {
            Button({ store.legalAccepted = LEGAL_VERSION; accepted = true; onAccepted() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Text(tx("Ho capito e accetto"))
            }
        },
    )
}

const val LEGAL_VERSION = 2
