package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Api
import com.binario.treni.data.FnNetwork
import com.binario.treni.data.Station
import com.binario.treni.data.Stibm
import com.binario.treni.data.Stibm.StibmStation
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

/** Colore per zona, dal centro (Mi1) verso l'esterno (Mi9). */
private fun zoneColor(z: Int): Color = when (z) {
    1 -> Color(0xFFD32F2F); 3 -> Color(0xFFF57C00); 4 -> Color(0xFFFBC02D); 5 -> Color(0xFF7CB342)
    6 -> Color(0xFF00897B); 7 -> Color(0xFF1E88E5); 8 -> Color(0xFF5E35B1); else -> Color(0xFF6D4C41)
}

@Composable
private fun ZoneBadge(st: StibmStation) {
    Box(
        Modifier.clip(RoundedCornerShape(6.dp)).background(zoneColor(st.zone)).padding(horizontal = 8.dp, vertical = 3.dp),
    ) { Text(st.zoneLabel, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

/**
 * Area STIBM: calcolo delle zone e del prezzo tra due stazioni, tutte le stazioni con la loro zona, regole e link
 * ufficiali Trenord. [start] = stazione da cui si arriva (es. dal tabellone).
 */
@Composable
fun StibmScreen(start: String?, onBack: () -> Unit, onBoard: (Station) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var from by remember { mutableStateOf(start?.let { Stibm.find(it) }) }
    var to by remember { mutableStateOf<StibmStation?>(null) }
    var picking by remember { mutableStateOf<Int?>(null) }
    var through by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var coords by remember { mutableStateOf<Map<String, Pair<Double, Double>>>(emptyMap()) }

    // Posizioni delle stazioni (solo se l'elenco stazioni è già sul telefono): servono a stimare se si passa da Milano
    LaunchedEffect(Unit) {
        coords = withContext(Dispatchers.IO) {
            try {
                FnNetwork.ensure(ctx)
                val out = HashMap<String, Pair<Double, Double>>()
                FnNetwork.stations.forEach { out[Stibm.norm(it.station.name)] = it.lat to it.lon }
                val f = File(ctx.filesDir, "stations.json")
                if (f.exists()) {
                    val a = JSONArray(f.readText())
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        out.putIfAbsent(Stibm.norm(o.optString("name")), o.optDouble("lat") to o.optDouble("lon"))
                    }
                }
                out
            } catch (e: Exception) {
                emptyMap()
            }
        }
    }
    fun coordOf(st: StibmStation?): Pair<Double, Double>? {
        st ?: return null
        val k = Stibm.norm(st.name)
        return coords[k] ?: coords.entries.firstOrNull { it.key.startsWith("$k ") || k.startsWith(it.key + " ") }?.value
    }
    LaunchedEffect(from, to, coords) {
        val a = from; val b = to
        if (a != null && b != null && a.zone != 1 && b.zone != 1) through = Stibm.likelyThroughMilano(coordOf(a), coordOf(b))
    }

    fun openBoard(st: StibmStation) {
        scope.launch {
            val found = withContext(Dispatchers.IO) {
                try {
                    Api.searchStations(st.name).firstOrNull { Stibm.find(it.name) == st } ?: Api.searchStations(st.name).firstOrNull()
                } catch (e: Exception) {
                    null
                }
            }
            if (found != null) onBoard(found) else toast(ctx, tx("Stazione non trovata"))
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Area STIBM"), onBack)
        LazyColumn(contentPadding = PaddingValues(vertical = 6.dp)) {
            item {
                WhiteCard {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            tx("Un solo biglietto per treni Trenord e Trenitalia regionali, metro, tram e bus nella Città Metropolitana di Milano, in provincia di Monza e Brianza e in alcuni comuni vicini. Il prezzo dipende dal numero di zone (Mi1…Mi9) tra partenza e arrivo, non dal mezzo."),
                            fontSize = 14.sp,
                        )
                    }
                }
            }
            // ---- Calcolo ----
            item {
                WhiteCard {
                    CardTitle(tx("Quanto costa"))
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                        PickRow(tx("Da"), from) { picking = 0 }
                        Spacer(Modifier.height(8.dp))
                        PickRow(tx("A"), to) { picking = 1 }
                        val a = from; val b = to
                        if (a != null && b != null) {
                            if (a.zone != 1 && b.zone != 1) {
                                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(tx("Il viaggio passa da Milano"), fontSize = 14.sp)
                                        Text(tx("In questo caso serve anche la zona Mi1"), color = Muted, fontSize = 12.sp)
                                    }
                                    Switch(through, { through = it }, colors = SwitchDefaults.colors(checkedTrackColor = Green))
                                }
                            }
                            val f = Stibm.fare(a.zone, b.zone, through)
                            val p = f.prices
                            HorizontalDivider(Modifier.padding(vertical = 10.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(f.label, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green)
                                Spacer(Modifier.width(8.dp))
                                Text("${f.zones} " + tx("zone"), modifier = Modifier.padding(bottom = 4.dp))
                            }
                            if (a.zone == b.zone && a.zone != 1 && !through) {
                                Text(tx("Stessa zona: si paga comunque la tariffa minima di 2 zone (va bene anche quella con la zona interna)."),
                                    color = Muted, fontSize = 12.sp)
                            }
                            if (a.interchangeOnly || b.interchangeOnly) {
                                Text(tx("Attenzione: questa stazione è fuori area STIBM. Vale solo per cambiare treno o bus, non come partenza o arrivo del biglietto STIBM."),
                                    color = LateRed, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                            if (p != null) {
                                Spacer(Modifier.height(8.dp))
                                PriceRow(tx("Biglietto ordinario") + " · ${p.minutes} " + tx("min"), p.single)
                                PriceRow(tx("Carnet 10 biglietti (sito e app Trenord)"), p.carnet10)
                                PriceRow(tx("Giornaliero (24 ore)"), p.daily)
                                PriceRow(tx("3 giorni"), p.threeDays)
                                PriceRow(tx("Settimanale (lun–dom)"), p.weekly)
                                PriceRow(tx("Mensile"), p.monthly)
                                PriceRow(tx("Annuale"), p.yearly)
                                PriceRow(tx("Mensile under 26 / over 65"), p.monthlyReduced)
                                PriceRow(tx("Annuale under 26 / over 65"), p.yearlyReduced)
                                PriceRow(tx("Annuale ISEE sotto 6.000 €"), p.yearlyIsee)
                                Text(tx("Prezzi in vigore dal") + " " + Stibm.PRICES_FROM + ". " +
                                    tx("Validi su treni Trenord e Trenitalia regionali in 2ª classe, metro, tram e bus."),
                                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                }
            }
            // ---- Regole ----
            item {
                WhiteCard {
                    CardTitle(tx("Regole principali"))
                    Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                        listOf(
                            tx("Convalida prima di partire e a ogni cambio di mezzo (tra due treni basta la prima convalida)."),
                            tx("Il biglietto ordinario vale 75 minuti per 2 zone, +15 minuti per zona fino a 4 zone, +30 minuti per zona da 5 zone in su; a Milano (Mi1–Mi3) vale 90 minuti. Nel tempo di validità i viaggi sono illimitati."),
                            tx("Tra località fuori Milano: le zone tra le due; se si attraversa Milano serve sempre anche Mi1. Minimo 2 zone."),
                            tx("Treni: solo 2ª classe. Supplemento prima classe: 2,80 € a viaggio, 31 € al mese, 310 € all'anno."),
                            tx("Malpensa Express: valido solo nella città di Milano (non nei 21 comuni della zona Mi3) e tra Milano e Rescaldina (Mi1–Mi7), solo sui treni da/per Milano Centrale."),
                            tx("Ragazzi under 14 gratis se accompagnati da un adulto pagante; da soli serve la tessera Under 14."),
                            tx("Fermate intermedie solo in stazioni dell'area STIBM; fuori area solo per cambiare mezzo (es. Saronno, Busto Arsizio, Treviglio)."),
                            tx("I biglietti non sono cedibili dopo la convalida. Abbonamenti su tessera Io Viaggio o ATM."),
                        ).forEach { r -> Text("• $r", fontSize = 13.sp, modifier = Modifier.padding(vertical = 3.dp)) }
                        Row(Modifier.padding(top = 4.dp)) {
                            TextButton({ openUrl(ctx, Stibm.MAP_IMAGE) }) { Text(tx("Mappa delle zone"), color = Green) }
                            TextButton({ openUrl(ctx, Stibm.TARIFF_PDF) }) { Text(tx("Tariffario"), color = Green) }
                            TextButton({ openUrl(ctx, Stibm.RULES) }) { Text(tx("Regole"), color = Green) }
                        }
                    }
                }
            }
            // ---- Stazioni ----
            item { SectionHeader(tx("Stazioni dell'area STIBM") + " (${Stibm.STATIONS.size})") }
            item {
                OutlinedTextField(
                    query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    placeholder = { Text(tx("Cerca stazione o comune")) }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
                )
            }
            val q = Stibm.norm(query)
            val list = (Stibm.STATIONS + Stibm.INTERCHANGE).filter { q.isBlank() || Stibm.norm(it.name).contains(q) || Stibm.norm(it.comune).contains(q) }
                .sortedWith(compareBy<StibmStation>({ it.interchangeOnly }, { it.zone }, { it.name }))
            items(list, key = { it.name + it.interchangeOnly }) { st ->
                Row(
                    Modifier.fillMaxWidth().clickable { openBoard(st) }.background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ZoneBadge(st)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(st.name + (if (st.suspended) " *" else ""), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(
                            st.comune + " (" + st.prov + ")" +
                                (if (st.interchangeOnly) " · " + tx("fuori area, solo interscambio") else "") +
                                (if (st.suspended) " · " + tx("servizio sospeso") else ""),
                            color = Muted, fontSize = 12.sp,
                        )
                    }
                    IconButton({ if (from == null) from = st else to = st }) { Icon(Icons.Filled.Calculate, tx("Usa per il calcolo"), tint = Green) }
                }
                HorizontalDivider()
            }
            item {
                TextButton({ openUrl(ctx, Stibm.PAGE) }, Modifier.padding(8.dp)) {
                    Text(tx("Fonte: Trenord, Area STIBM – aree coinvolte e tariffe"), color = Green, fontSize = 12.sp)
                }
            }
        }
    }

    picking?.let { which ->
        StibmPicker(onDismiss = { picking = null }) { st ->
            if (which == 0) from = st else to = st
            picking = null
        }
    }
}

@Composable
private fun PickRow(label: String, st: StibmStation?, onClick: () -> Unit) {
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Muted, modifier = Modifier.width(36.dp))
            if (st == null) Text(tx("Scegli la stazione"), color = Muted, modifier = Modifier.weight(1f))
            else {
                Text(st.name, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                ZoneBadge(st)
            }
        }
    }
}

@Composable
private fun PriceRow(label: String, value: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(Stibm.eur(value), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun StibmPicker(onDismiss: () -> Unit, onPick: (StibmStation) -> Unit) {
    var q by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx("Scegli la stazione")) },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text(tx("Cerca stazione o comune")) }, singleLine = true)
                val n = Stibm.norm(q)
                val list = (Stibm.STATIONS + Stibm.INTERCHANGE)
                    .filter { n.isBlank() || Stibm.norm(it.name).contains(n) || Stibm.norm(it.comune).contains(n) }.sortedBy { it.name }
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(list, key = { it.name + it.interchangeOnly }) { st ->
                        Row(Modifier.fillMaxWidth().clickable { onPick(st) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(st.name, modifier = Modifier.weight(1f))
                            ZoneBadge(st)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text(tx("Chiudi")) } },
    )
}
