package com.binario.treni.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.binario.treni.data.Feedback
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "Feedback e segnala un bug": nome e cognome, email, tipo di messaggio e testo. */
@Composable
fun FeedbackScreen(onBack: () -> Unit, initialBug: Boolean = false) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(Feedback.lastName(ctx)) }
    var email by remember { mutableStateOf(Feedback.lastEmail(ctx)) }
    var bug by remember { mutableStateOf(initialBug) }
    var text by remember { mutableStateOf("") }
    var withTech by remember { mutableStateOf(true) }
    var sending by remember { mutableStateOf(false) }
    var tried by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    var blocked by remember { mutableStateOf<String?>(null) }
    val openedAt = remember { System.currentTimeMillis() }

    val nameOk = name.trim().length >= 3
    val emailOk = Feedback.validEmail(email)
    val textOk = text.trim().length >= 10

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(tx("Feedback e segnala un bug"), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(
                tx("Suggerimenti, idee o qualcosa che non funziona? Scrivilo qui: il messaggio arriva direttamente allo sviluppatore."),
                fontSize = 14.sp,
            )
            Row(Modifier.padding(vertical = 12.dp)) {
                FilterChip(!bug, { bug = false }, label = { Text(tx("Suggerimento")) }, modifier = Modifier.padding(end = 8.dp))
                FilterChip(bug, { bug = true }, label = { Text(tx("Segnala un bug")) })
            }
            OutlinedTextField(
                name, { name = it }, Modifier.fillMaxWidth(),
                label = { Text(tx("Nome e cognome")) }, singleLine = true,
                isError = tried && !nameOk,
                supportingText = { if (tried && !nameOk) Text(tx("Scrivi nome e cognome")) },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            )
            OutlinedTextField(
                email, { email = it }, Modifier.fillMaxWidth(),
                label = { Text(tx("Email")) }, singleLine = true,
                isError = tried && !emailOk,
                supportingText = { Text(if (tried && !emailOk) tx("Email non valida") else tx("Serve solo per risponderti")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            )
            OutlinedTextField(
                text, { text = it }, Modifier.fillMaxWidth().heightIn(min = 180.dp),
                label = { Text(if (bug) tx("Descrivi il problema") else tx("Il tuo feedback")) },
                placeholder = {
                    Text(
                        if (bug) tx("Cosa stavi facendo, cosa è successo e cosa ti aspettavi (es. stazione, numero del treno, ora).")
                        else tx("Cosa ti piace, cosa miglioreresti, cosa manca."),
                        color = Muted,
                    )
                },
                isError = tried && !textOk,
                supportingText = { if (tried && !textOk) Text(tx("Scrivi almeno qualche parola")) },
                minLines = 6,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(withTech, { withTech = it }, colors = CheckboxDefaults.colors(checkedColor = Green))
                Column {
                    Text(tx("Allega i dati tecnici"), fontSize = 14.sp)
                    Text(tx("Versione dell'app, modello del telefono e versione di Android: aiutano a trovare il problema."), color = Muted, fontSize = 12.sp)
                }
            }
            blocked?.let {
                Text(it, color = LateRed, fontWeight = FontWeight.Medium, modifier = Modifier.padding(vertical = 10.dp))
            }
            result?.let {
                Text(it, color = Green, fontWeight = FontWeight.Medium, modifier = Modifier.padding(vertical = 10.dp))
            }
            Button(
                onClick = {
                    tried = true
                    if (!nameOk || !emailOk || !textOk || sending) return@Button
                    val b = Feedback.check(ctx, text, openedAt)
                    blocked = Feedback.blockText(b).takeIf { b != Feedback.Block.OK }
                    if (blocked != null) return@Button
                    sending = true
                    result = null
                    Feedback.remember(ctx, name, email)
                    val report = Feedback.Report(
                        name.trim(), email.trim(), if (bug) "Bug" else "Suggerimento", text.trim(),
                        if (withTech) Feedback.techInfo(ctx) else "", System.currentTimeMillis(),
                    )
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { Feedback.send(ctx.applicationContext, report) }
                        sending = false
                        result = if (ok) tx("Grazie! Messaggio inviato.") else tx("Nessuna connessione: il messaggio è salvato e partirà da solo appena possibile.")
                        text = ""
                        tried = false
                    }
                },
                enabled = !sending,
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(50.dp),
            ) { Text(if (sending) tx("Invio…") else tx("Invia"), fontSize = 17.sp) }
            Text(
                tx("Nome ed email servono solo per risponderti e non vengono usati per altro. Il messaggio non contiene posizione, viaggi o preferiti."),
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp),
            )
        }
    }
}
