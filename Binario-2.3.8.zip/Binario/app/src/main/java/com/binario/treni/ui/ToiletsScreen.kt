package com.binario.treni.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.binario.treni.data.Api
import com.binario.treni.data.Osm
import com.binario.treni.data.Station
import com.binario.treni.data.Toilet
import com.binario.treni.data.tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * WC vicino a una stazione (o alla posizione attuale): gratuiti o a pagamento con prezzo, accessibili in carrozzina,
 * fasciatoio, orari, distanza a piedi. Dati OpenStreetMap; Google Maps come riserva.
 */
@Composable
fun ToiletsScreen(vm: MainViewModel, station: Station?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var center by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var list by remember { mutableStateOf<List<Toilet>?>(null) }
    var status by remember { mutableStateOf(tx("Ricerca della posizione…")) }
    var failed by remember { mutableStateOf(false) }
    var radius by remember { mutableIntStateOf(800) }
    var retry by remember { mutableIntStateOf(0) }
    var pulling by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var onlyFree by remember { mutableStateOf(false) }
    var onlyAccessible by remember { mutableStateOf(false) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> granted = r.values.any { it } }

    LaunchedEffect(station?.id, granted) {
        if (station != null) {
            center = withContext(Dispatchers.IO) { Api.stationCoord(vm.store, station.id) }
            if (center == null) status = tx("Coordinate della stazione non disponibili")
        } else if (granted) {
            val l = lastKnown(ctx)
            if (l != null) center = l.latitude to l.longitude else status = tx("Posizione non disponibile: apri prima la mappa o attiva il GPS.")
        } else {
            launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            status = tx("Serve il permesso di posizione")
        }
    }
    LaunchedEffect(center, radius, retry) {
        val c = center ?: return@LaunchedEffect
        if (!pulling) list = null
        failed = false
        status = tx("Cerco i WC entro") + " $radius m…"
        list = try {
            withContext(Dispatchers.IO) { Osm.toilets(c.first, c.second, radius) }
        } catch (e: Exception) {
            failed = true
            status = tx("I server OpenStreetMap non rispondono. Riprova tra poco o cerca su Google Maps."); null
        }
        pulling = false
    }
    val shown = list.orEmpty().filter { (!onlyFree || it.fee == "no") && (!onlyAccessible || it.wheelchair == "yes") }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        GreenTopBar(if (station != null) "WC · ${station.name}" else tx("WC vicini"), onBack)
        if (vm.store.mapsEnabled) GreenTabs(listOf(tx("Elenco"), tx("Mappa")), tab) { tab = it }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp)) {
            FilterChip(onlyFree, { onlyFree = !onlyFree }, label = { Text(tx("Gratuiti")) }, modifier = Modifier.padding(end = 6.dp))
            FilterChip(onlyAccessible, { onlyAccessible = !onlyAccessible }, label = { Text(tx("Accessibili ♿")) }, modifier = Modifier.padding(end = 6.dp))
            if (radius < 2000) FilterChip(false, { radius = 2000 }, label = { Text(tx("Entro 2 km")) })
        }
        val l = list
        val c = center
        when {
            l == null -> Column {
                MessageBox(status)
                if (failed && c != null) Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    OutlinedButton({ retry++ }) { Text(tx("Riprova"), color = Green) }
                    GoogleMapsButtons(c.first, c.second, listOf(tx("Bagni pubblici") to "bagni pubblici"))
                }
            }
            tab == 1 && vm.store.mapsEnabled -> OsmMap(
                shown.map { MapPoint(it.lat, it.lon, it.name.ifBlank { "WC" }, it.feeText) },
                drawLine = false, modifier = Modifier.fillMaxSize(), me = if (station == null) c else null, googleQuery = "bagni pubblici",
            )
            else -> PullRefresh(pulling, { pulling = true; retry++ }) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 4.dp)) {
                    if (shown.isEmpty()) item { MessageBox(tx("Nessun WC mappato entro") + " $radius m.") }
                    items(shown) { w -> ToiletRow(w) }
                    item {
                        c?.let {
                            Column(Modifier.padding(horizontal = 8.dp)) {
                                Text(tx("Non trovi quello che cerchi? Cerca su Google Maps:"), color = Muted, fontSize = 13.sp,
                                    modifier = Modifier.padding(start = 8.dp, top = 8.dp))
                                GoogleMapsButtons(it.first, it.second, listOf(tx("Bagni pubblici") to "bagni pubblici"))
                            }
                        }
                        Text(tx("Fonte") + ": " + Osm.lastSource.ifBlank { "OpenStreetMap" } + ". " +
                            tx("Prezzi, orari e accessibilità sono indicati dai volontari OpenStreetMap: verifica sul posto."),
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ToiletRow(w: Toilet) {
    val ctx = LocalContext.current
    WhiteCard(onClick = { openUrl(ctx, "geo:${w.lat},${w.lon}?q=${w.lat},${w.lon}(WC)") }) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Wc, null, tint = Green, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(w.name.ifBlank { "WC" }, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                Text(w.feeText, color = if (w.fee == "no") Green else Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                val badges = listOfNotNull(
                    when (w.wheelchair) { "yes" -> tx("♿ accessibile"); "limited" -> tx("♿ in parte accessibile"); "no" -> tx("non accessibile in carrozzina"); else -> null },
                    if (w.changingTable) tx("🚼 fasciatoio") else null,
                    if (w.access == "customers") tx("solo clienti") else null,
                )
                if (badges.isNotEmpty()) Text(badges.joinToString(" · "), fontSize = 13.sp)
                if (w.hours.isNotBlank()) Text("🕒 " + w.hours, color = Muted, fontSize = 13.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(if (w.distance < 1000) "${w.distance} m" else String.format("%.1f km", w.distance / 1000.0), fontWeight = FontWeight.Bold)
                Text("${(w.distance / 80).coerceAtLeast(1)} " + tx("min a piedi"), color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@SuppressLint("MissingPermission")
private fun lastKnown(ctx: android.content.Context): android.location.Location? = try {
    val lm = ctx.getSystemService(LocationManager::class.java)
    lm?.getProviders(true)?.mapNotNull { p ->
        try {
            lm.getLastKnownLocation(p)
        } catch (e: SecurityException) {
            null
        }
    }?.maxByOrNull { it.time }
} catch (e: Exception) {
    null
}
