package com.binario.treni.data

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** Impianto (ascensore/scala/rampa) fuori servizio, con il binario se noto. */
data class StationIssue(
    val source: String,
    val station: String,
    val platform: String,
    val device: String,
    val since: String,
    val until: String,
)

/** Sciopero dalla tabella ufficiale dell'Osservatorio scioperi (MIT). */
data class Strike(
    val start: String,
    val end: String,
    val unions: String,
    val sector: String,
    val company: String,
    val modality: String,
    val relevance: String,
    val region: String,
    val province: String,
    val note: String,
    val url: String = Sources.MIT_URL,
) {
    val key: String get() = "strike:$start|$company|$modality".take(200)
    val sourceName: String get() = "Osservatorio scioperi MIT"
    val title: String get() = "Sciopero $start" + (if (end.isNotBlank() && end != start) "–$end" else "") + " · " + company.take(80)
}

/** Comunicato/avviso di un'azienda (Trenord, FerrovieNord, ViaggiaTreno…). */
data class Notice(
    val source: String,
    val title: String,
    val text: String,
    val date: String,
    val url: String,
) {
    val kind: Kind get() = classify(title + " " + text)

    /** Sito della fonte, da mostrare come "Fonte: trenitalia.com". */
    val site: String get() = Regex("^https?://(?:www\\.)?([^/]+)").find(url)?.groupValues?.get(1) ?: source

    /** Data in millisecondi per ordinare dal più recente (0 se sconosciuta). */
    val time: Long get() = Sources.parseItDate(date)

    enum class Kind(private val itLabel: String) {
        STRIKE("Sciopero"), BLOCKED("Circolazione"), WORKS("Lavori e modifiche"), OTHER("Avviso");

        val label: String get() = tx(itLabel)
    }

    companion object {
        fun classify(t: String): Kind {
            val s = t.lowercase()
            return when {
                "sciopero" in s || "scioperi" in s -> Kind.STRIKE
                // "Circolazione regolare": buona notizia, non un'anomalia
                "regolar" in s && listOf("sospes", "interrott", "bloccat", "rallentat", "guasto").none { it in s } -> Kind.OTHER
                listOf("sospes", "interrott", "bloccat", "rallentat", "guasto", "inconveniente", "ritardi", "circolazione", "ripres").any { it in s } -> Kind.BLOCKED
                listOf("lavori", "interruzion", "bus sostitutiv", "modific", "cantiere", "manutenzion", "variazion").any { it in s } -> Kind.WORKS
                else -> Kind.OTHER
            }
        }
    }
}

/**
 * Lettura dei siti ufficiali (pagine HTML/RSS pubbliche). Sono letture "di cortesia" di pagine web:
 * se un sito cambia impaginazione, la funzione restituisce una lista vuota invece di bloccare l'app.
 */
object Sources {
    const val MIT_URL = "https://scioperi.mit.gov.it/mit2/public/scioperi"
    const val TRENITALIA_INFO_URL = "https://www.trenitalia.com/it/informazioni/Infomobilita/notizie-infomobilita.html"
    const val TRENITALIA_GUARANTEED_URL = "https://www.trenitalia.com/it/informazioni/treni-garantiti-incasodisciopero.html"

    private val months = listOf("gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto",
        "settembre", "ottobre", "novembre", "dicembre")

    /** Capisce "14/10/2026", "14/10/2026 09:30", "31 agosto 2026". Restituisce 0 se non riconosce la data. */
    fun parseItDate(s: String): Long {
        val t = s.trim().lowercase()
        if (t.isBlank()) return 0L
        val rome = TimeZone.getTimeZone("Europe/Rome")
        Regex("(\\d{1,2})/(\\d{1,2})/(\\d{4})(?:\\s+(\\d{1,2})[:.](\\d{2}))?").find(t)?.let { m ->
            val c = java.util.Calendar.getInstance(rome)
            c.clear()
            c.set(m.groupValues[3].toInt(), m.groupValues[2].toInt() - 1, m.groupValues[1].toInt(),
                m.groupValues[4].toIntOrNull() ?: 0, m.groupValues[5].toIntOrNull() ?: 0)
            return c.timeInMillis
        }
        Regex("(\\d{1,2})\\s+([a-z]+)\\s+(\\d{4})").find(t)?.let { m ->
            val mo = months.indexOf(m.groupValues[2])
            if (mo >= 0) {
                val c = java.util.Calendar.getInstance(rome)
                c.clear()
                c.set(m.groupValues[3].toInt(), mo, m.groupValues[1].toInt())
                return c.timeInMillis
            }
        }
        return 0L
    }

    private val tag = Regex("<[^>]+>")
    private val ws = Regex("\\s+")
    private val rowRx = Regex("<tr[^>]*>(.*?)</tr>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    private val cellRx = Regex("<t[dh][^>]*>(.*?)</t[dh]>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))

    private fun fetch(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000; readTimeout = 25000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36")
            setRequestProperty("Accept-Language", "it-IT,it")
        }
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun clean(html: String): String = ws.replace(
        tag.replace(html, " ")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&#8217;", "'").replace("&#039;", "'")
            .replace("&quot;", "\"").replace("&agrave;", "à").replace("&egrave;", "è").replace("&eacute;", "é")
            .replace("&igrave;", "ì").replace("&ograve;", "ò").replace("&ugrave;", "ù").replace("&#8211;", "–")
            .replace("&rsquo;", "'").replace("&lsquo;", "'").replace("&ldquo;", "\"").replace("&rdquo;", "\"")
            .replace("&Egrave;", "È").replace("&Agrave;", "À").replace("&#224;", "à").replace("&#232;", "è").replace("&#233;", "é")
            .replace("&#242;", "ò").replace("&#249;", "ù").replace("&#236;", "ì").replace("&lt;", "<").replace("&gt;", ">"),
        " ",
    ).trim()

    private fun tableRows(html: String): List<List<String>> =
        rowRx.findAll(html).map { r -> cellRx.findAll(r.groupValues[1]).map { clean(it.groupValues[1]) }.toList() }.toList()

    private fun matchesStation(text: String, station: String): Boolean {
        val words = station.lowercase().replace(Regex("[^a-zà-ù0-9 ]"), " ").split(" ").filter { it.length > 2 }
        val t = text.lowercase()
        return words.isNotEmpty() && words.all { it in t }
    }

    // ---------------- Ascensori e scale fuori servizio ----------------

    /** FerrovieNord: tabella IMPIANTO / BANCHINA NON ACCESSIBILE / IMPIANTO ELEVATORE / INIZIO / RIPRISTINO. */
    fun ferrovieNordIssues(): List<StationIssue> =
        tableRows(fetch("https://www.ferrovienord.it/comunicazioni-accessibilita-stazioni/"))
            .filter { it.size >= 5 && it[0].isNotBlank() && !it[0].equals("IMPIANTO", true) }
            .map { c -> StationIssue("FerrovieNord", c[0], c[1], c[2], c[3], c[4]) }

    /** RFI: tabella NOME STAZIONE / VARIAZIONE ACCESSIBILITÀ / FINO AL. */
    fun rfiIssues(): List<StationIssue> =
        tableRows(fetch("https://www.rfi.it/it/stazioni/pagine-stazioni/accessibilita/stato-ascensori-e-rampe-di-accesso-ai-binari.html"))
            .filter { it.size >= 2 && it[0].isNotBlank() && !it[0].equals("NOME STAZIONE", true) }
            .map { c ->
                val change = c[1]
                val plat = Regex("binari?o?\\s*([0-9]+(?:\\s*[-e/]\\s*[0-9]+)*)", RegexOption.IGNORE_CASE).find(change)?.groupValues?.get(1) ?: ""
                StationIssue("RFI", c[0], plat, change, "", c.getOrElse(2) { "" })
            }

    /** Tutte le segnalazioni per una stazione, da entrambe le fonti (errori di una fonte ignorati). */
    fun issuesFor(station: String): Pair<List<StationIssue>, List<String>> {
        val out = mutableListOf<StationIssue>()
        val failed = mutableListOf<String>()
        try {
            out += ferrovieNordIssues().filter { matchesStation(it.station, station) }
        } catch (e: Exception) {
            failed += "FerrovieNord"
        }
        try {
            out += rfiIssues().filter { matchesStation(it.station, station) }
        } catch (e: Exception) {
            failed += "RFI"
        }
        return out to failed
    }

    // ---------------- Scioperi (Osservatorio MIT, fonte ufficiale) ----------------

    /** Scioperi del settore ferroviario dalla tabella pubblica del Ministero. */
    fun railStrikes(): List<Strike> {
        val rows = tableRows(fetch(MIT_URL))
        return rows.mapNotNull { r ->
            // La prima colonna è vuota: Inizio, Fine, Sindacati, Settore, Categoria, Modalità, Rilevanza, Note, Proclamazione, Regione, Provincia, Ricezione
            val c = if (r.size >= 13 && r[0].isBlank()) r.drop(1) else r
            if (c.size < 11 || !Regex("\\d{2}/\\d{2}/\\d{4}").matches(c[0])) return@mapNotNull null
            Strike(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[9], c[10], c[7])
        }.filter { st ->
            // Ferroviario, più scioperi generali e plurisettoriali che coinvolgono anche i treni
            val sec = st.sector.lowercase()
            (sec.contains("ferroviari") && !sec.contains("appalti")) || sec.contains("generale") ||
                (sec.contains("plurisettoriale") && (st.company + " " + st.note + " " + st.modality).contains("ferrovi", true)) ||
                sec.contains("plurisettoriale") && st.relevance.contains("nazional", true)
        }
            .distinctBy { it.key }
    }

    // ---------------- Comunicati delle aziende ----------------

    /** Avvisi Trenord (lavori, bus sostitutivi, scioperi, modifiche al servizio). */
    fun trenordNotices(): List<Notice> {
        val html = fetch("https://www.trenord.it/news/trenord-informa/avvisi/")
        val link = Regex("<a[^>]+href=\"((?:https://www\\.trenord\\.it)?/news/trenord-informa/avvisi/[a-z0-9-]+/)\"[^>]*>(.*?)</a>",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val date = Regex("(\\d{1,2}\\s+(?:gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre)\\s+\\d{4})", RegexOption.IGNORE_CASE)
        return link.findAll(html).mapNotNull { m ->
            val url = m.groupValues[1].let { if (it.startsWith("/")) "https://www.trenord.it$it" else it }
            val title = clean(m.groupValues[2])
            if (title.length < 6) return@mapNotNull null
            // Testo e data: cerchiamo subito dopo il link
            val after = html.substring(m.range.last.coerceAtMost(html.length - 1), (m.range.last + 1500).coerceAtMost(html.length))
            val d = date.find(after)?.value ?: ""
            val text = clean(after).take(300)
            Notice("Trenord", title, text, d, url)
        }.distinctBy { it.url }.toList()
    }

    /** Notizie FerrovieNord dal feed del sito (WordPress). */
    fun ferrovieNordNews(): List<Notice> = rss("https://www.ferrovienord.it/feed/", "FerrovieNord")

    /** Lettore RSS generico. */
    fun rss(url: String, source: String): List<Notice> {
        val xml = fetch(url)
        val item = Regex("<item>(.*?)</item>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        fun field(s: String, n: String): String {
            val m = Regex("<$n[^>]*>(.*?)</$n>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)).find(s) ?: return ""
            return clean(m.groupValues[1].replace("<![CDATA[", "").replace("]]>", ""))
        }
        return item.findAll(xml).map { m ->
            val s = m.groupValues[1]
            Notice(source, field(s, "title"), field(s, "description").take(500), shortDate(field(s, "pubDate")), field(s, "link"))
        }.filter { it.title.isNotBlank() }.toList()
    }

    private fun shortDate(rfc: String): String = try {
        val d = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US).parse(rfc)
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALY).apply { timeZone = TimeZone.getTimeZone("Europe/Rome") }.format(d!!)
    } catch (e: Exception) {
        rfc
    }

    /** Infomobilità ViaggiaTreno (circolazione in tempo reale su rete RFI). */
    fun viaggiaTrenoNotices(): List<Notice> = try {
        Api.news().filter { it.date > System.currentTimeMillis() - 3 * 86_400_000L }.map { n ->
            Notice("ViaggiaTreno", n.title, n.text, if (n.date > 0) Fmt.dayTime(n.date) else "", "https://www.viaggiatreno.it")
        }
    } catch (e: Exception) {
        emptyList()
    }

    /** Avvisi TILO (traffico, lavori, scioperi) dalla pagina avvisi. */
    fun tiloNotices(): List<Notice> {
        val html = fetch("https://www.tilo.ch/avvisi.html")
        val link = Regex("<a[^>]+href=\"((?:https://www\\.tilo\\.ch)?/avvisi/[^\"#?]+)\"[^>]*>(.*?)</a>",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        return link.findAll(html).mapNotNull { m ->
            val url = m.groupValues[1].let { if (it.startsWith("/")) "https://www.tilo.ch$it" else it }
            val title = clean(m.groupValues[2])
            // I file si chiamano AAMMGG_Titolo.html: ne ricaviamo la data
            val d = Regex("/avvisi/(\\d{2})(\\d{2})(\\d{2})_").find(url)?.let { "${it.groupValues[3]}/${it.groupValues[2]}/20${it.groupValues[1]}" } ?: ""
            if (title.length < 6) null else Notice("TILO", title, "", d, url)
        }.distinctBy { it.url }.toList()
    }

    /**
     * Trenitalia "Notizie Infomobilità": circolazione in tempo reale, scioperi, lavori, per regione.
     * Ogni notizia è un titolo (h2/h3) seguito da data, regione e testo.
     */
    fun trenitaliaInfomobility(): List<Notice> {
        val html = stripScripts(fetch(TRENITALIA_INFO_URL))
        val h = Regex("<h[23][^>]*>(.*?)</h[23]>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        val heads = h.findAll(html).toList()
        val dateRx = Regex("\\b(\\d{2}/\\d{2}/\\d{4})\\b")
        val regions = listOf("Abruzzo", "Basilicata", "Calabria", "Campania", "Emilia Romagna", "Emilia-Romagna", "Friuli Venezia Giulia",
            "Lazio", "Liguria", "Lombardia", "Marche", "Molise", "Piemonte", "Puglia", "Sardegna", "Sicilia", "Toscana",
            "Trentino Alto Adige", "Umbria", "Valle d'Aosta", "Veneto")
        return heads.mapIndexedNotNull { i, m ->
            val title = clean(m.groupValues[1])
            val end = if (i + 1 < heads.size) heads[i + 1].range.first else (m.range.last + 6000).coerceAtMost(html.length)
            val body = clean(html.substring(m.range.last + 1, end.coerceAtLeast(m.range.last + 1)))
            val d = dateRx.find(body.take(120))?.value ?: return@mapIndexedNotNull null
            if (title.length < 8) return@mapIndexedNotNull null
            var text = body.substringAfter(d).trim()
            val region = regions.firstOrNull { text.take(80).contains(it, true) }
            text = text.removePrefix("In evidenza").trim()
            if (region != null && text.startsWith(region, true)) text = text.substring(region.length).trim()
            // L'etichetta della notizia successiva (es. "ATTENZIONE", "Programmazione") resta in coda: la togliamo
            text = text.replace(Regex("\\s*(ATTENZIONE|Programmazione|Informazione|In evidenza)\\s*$"), "").trim()
            Notice("Trenitalia" + (region?.let { " · $it" } ?: ""), title, text.take(1500), d, TRENITALIA_INFO_URL)
        }.distinctBy { it.title + it.date }
    }

    private fun stripScripts(html: String): String =
        html.replace(Regex("<(script|style|noscript)[^>]*>.*?</\\1>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), " ")

    /**
     * Testo completo di un comunicato, letto dalla sua pagina: contenuto principale (main/article),
     * con paragrafi ed elenchi separati da a capo. Restituisce "" se la pagina non ha testo leggibile.
     */
    fun noticeDetail(url: String): String {
        if (url.endsWith(".pdf", true)) return ""
        val html = stripScripts(fetch(url))
        val main = Regex("<(main|article)[^>]*>(.*?)</\\1>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
            .findAll(html).maxByOrNull { it.value.length }?.groupValues?.get(2) ?: html
        val noChrome = main.replace(Regex("<(nav|header|footer|form|aside)[^>]*>.*?</\\1>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), " ")
        val blocks = Regex("<(p|li|h[1-6]|td)[^>]*>(.*?)</\\1>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
            .findAll(noChrome).map { (if (it.groupValues[1].lowercase() == "li") "• " else "") + clean(it.groupValues[2]) }
            .filter { it.length > 2 }
            .toList()
        val text = blocks.distinct().joinToString("\n")
        return text.take(6000)
    }

    /** Tutti i comunicati, dal più recente, fonte per fonte (una fonte che fallisce non blocca le altre). */
    fun allNotices(): List<Notice> {
        val out = mutableListOf<Notice>()
        try { out += trenitaliaInfomobility() } catch (_: Exception) { }
        out += viaggiaTrenoNotices()
        try { out += trenordNotices() } catch (_: Exception) { }
        try { out += ferrovieNordNews() } catch (_: Exception) { }
        try { out += tiloNotices() } catch (_: Exception) { }
        return out.sortedByDescending { it.time }
    }

    // ---------------- Treni garantiti in caso di sciopero ----------------

    /** Documento ufficiale (di solito PDF) con l'elenco dei treni garantiti. */
    data class GuaranteedDoc(val source: String, val title: String, val url: String, val page: String)

    private val pdfRx = Regex("<a[^>]+href=\"([^\"]+\\.pdf[^\"]*)\"[^>]*>(.*?)</a>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))

    private fun absolute(base: String, href: String): String = when {
        href.startsWith("http") -> href
        href.startsWith("//") -> "https:$href"
        href.startsWith("/") -> Regex("^(https?://[^/]+)").find(base)?.value + href
        else -> base.substringBeforeLast('/') + "/" + href
    }

    /** Estrae i PDF da una pagina, tenendo quelli che parlano di treni garantiti/sciopero (o tutti se [all]). */
    private fun pdfsOf(source: String, page: String, all: Boolean = false): List<GuaranteedDoc> {
        val html = fetch(page)
        return pdfRx.findAll(html).map { m ->
            val url = absolute(page, m.groupValues[1].replace("&amp;", "&"))
            val title = clean(m.groupValues[2]).ifBlank { url.substringAfterLast('/').substringBefore(".pdf").replace('-', ' ').replace('_', ' ') }
            GuaranteedDoc(source, title, url, page)
        }.filter { d ->
            all || listOf("garantit", "sciopero", "servizi minimi", "fasce").any { (d.title + " " + d.url).lowercase().contains(it) }
        }.distinctBy { it.url }.toList()
    }

    /**
     * Elenchi ufficiali dei treni garantiti, letti dalle pagine delle aziende:
     * Trenitalia (pagina treni garantiti) e i comunicati di sciopero di Trenord, TILO, FerrovieNord.
     */
    fun guaranteedDocs(): Pair<List<GuaranteedDoc>, List<String>> {
        val out = mutableListOf<GuaranteedDoc>()
        val failed = mutableListOf<String>()
        try {
            out += pdfsOf("Trenitalia", TRENITALIA_GUARANTEED_URL, all = true)
                .filter { it.url.contains("garantit", true) }
        } catch (e: Exception) {
            failed += "Trenitalia"
        }
        try {
            out += pdfsOf("Trenord", "https://www.trenord.it/assistenza/informazioni-utili/in-caso-di-sciopero/", all = true)
        } catch (_: Exception) {
        }
        try {
            trenordNotices().filter { it.kind == Notice.Kind.STRIKE }.take(4).forEach { n ->
                try {
                    out += pdfsOf("Trenord", n.url, all = true).map { it.copy(title = n.title + " · " + it.title) }
                } catch (_: Exception) {
                }
            }
        } catch (e: Exception) {
            failed += "Trenord"
        }
        try {
            tiloNotices().filter { it.kind == Notice.Kind.STRIKE }.take(3).forEach { n ->
                try {
                    out += pdfsOf("TILO", n.url, all = true).map { it.copy(title = n.title + " · " + it.title) }
                } catch (_: Exception) {
                }
            }
        } catch (e: Exception) {
            failed += "TILO"
        }
        return out.distinctBy { it.url } to failed
    }
}
