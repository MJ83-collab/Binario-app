package com.binario.treni.data

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Orario completo di una giornata per un tragitto (andata e, se richiesto, ritorno) in PDF,
 * salvato nella cartella Download del telefono: si consulta e si stampa anche senza rete.
 * I dati sono gli orari programmati di Trenitalia (LeFrecce), che comprendono anche i regionali.
 */
object TimetablePdf {
    private val rome = TimeZone.getTimeZone("Europe/Rome")

    /** Tutte le soluzioni del giorno [day] (dalle 00:00 alle 23:59), scaricate a blocchi. */
    fun dayTimetable(from: Station, to: Station, day: Long, store: Store, onProgress: (Int) -> Unit = {}): List<Solution> {
        val start = Fmt.midnight(day)
        val end = start + 24 * 3600_000L
        val out = LinkedHashMap<String, Solution>()
        var t = start
        var guard = 0
        while (t < end && guard < 25) {
            guard++
            val page = Api.solutions(from, to, t, SearchFilter.ALL, store.maxChanges, store.excluded)
                .filter { it.dep in start until end }
            if (page.isEmpty()) break
            var added = 0
            page.forEach { s ->
                val k = s.dep.toString() + s.legs.joinToString { it.number }
                if (out.put(k, s) == null) added++
            }
            onProgress(out.size)
            val last = page.maxOf { it.dep }
            if (added == 0 || last + 60_000L <= t) break
            t = last + 60_000L
        }
        return out.values.sortedBy { it.dep }
    }

    private class Writer(val ctx: Context, val doc: PdfDocument, val title: String, val subtitle: String) {
        val w = 595; val h = 842; val margin = 36f
        var page: PdfDocument.Page? = null
        var y = 0f
        var n = 0
        val green = Color.rgb(46, 158, 68)
        val text = Paint().apply { color = Color.BLACK; textSize = 10f; isAntiAlias = true }
        val bold = Paint(text).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val muted = Paint(text).apply { color = Color.rgb(110, 110, 110); textSize = 8f }
        val white = Paint(bold).apply { color = Color.WHITE; textSize = 15f }
        val whiteSmall = Paint(text).apply { color = Color.WHITE; textSize = 10f }
        val band = Paint().apply { color = green }
        val zebra = Paint().apply { color = Color.rgb(240, 246, 240) }
        // Colonne: partenza, arrivo, durata, treni, cambi, prezzo
        val cols = floatArrayOf(margin, margin + 52, margin + 104, margin + 160, margin + 420, margin + 470)

        fun newPage() {
            page?.let { finishPage(it) }
            n++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create())
            page = p
            val c = p.canvas
            c.drawRect(0f, 0f, w.toFloat(), 64f, band)
            c.drawText(title, margin, 30f, white)
            c.drawText(subtitle, margin, 50f, whiteSmall)
            y = 86f
        }

        private fun finishPage(p: PdfDocument.Page) {
            val c = p.canvas
            val gen = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ITALY).apply { timeZone = rome }.format(Date())
            c.drawText(I18n.tr("Binario · orari programmati da Trenitalia/LeFrecce, generati il $gen. Verifica ritardi e variazioni prima di partire.",
                "Binario · scheduled times from Trenitalia/LeFrecce, generated on $gen. Check delays and changes before travelling."),
                margin, h - 20f, muted)
            c.drawText(I18n.tr("Pagina", "Page") + " $n", w - margin - 40f, h - 20f, muted)
            doc.finishPage(p)
        }

        fun ensure(space: Float) {
            if (page == null || y + space > h - 40f) newPage()
        }

        fun section(label: String) {
            ensure(60f)
            val c = page!!.canvas
            c.drawText(label, margin, y, Paint(bold).apply { textSize = 13f; color = green })
            y += 18f
            val heads = listOf(I18n.tr("Partenza", "Departs"), I18n.tr("Arrivo", "Arrives"), I18n.tr("Durata", "Duration"),
                I18n.tr("Treni", "Trains"), I18n.tr("Cambi", "Changes"), I18n.tr("Da", "From"))
            heads.forEachIndexed { i, s -> c.drawText(s, cols[i], y, bold) }
            y += 6f
            c.drawLine(margin, y, w - margin, y, Paint().apply { color = green; strokeWidth = 1f })
            y += 12f
        }

        fun row(s: Solution, i: Int) {
            ensure(18f)
            val c = page!!.canvas
            if (i % 2 == 1) c.drawRect(margin - 4, y - 11f, w - margin + 4, y + 5f, zebra)
            c.drawText(Fmt.time(s.dep), cols[0], y, bold)
            c.drawText(Fmt.time(s.arr), cols[1], y, text)
            c.drawText(s.duration.ifBlank { Fmt.duration(s.dep, s.arr) }, cols[2], y, text)
            var trains = s.legs.joinToString(" + ") { it.title }
            while (text.measureText(trains) > cols[4] - cols[3] - 8 && trains.length > 4) trains = trains.dropLast(2)
            c.drawText(trains, cols[3], y, text)
            c.drawText(if (s.changes == 0) I18n.tr("diretto", "direct") else s.changes.toString(), cols[4], y, text)
            c.drawText(if (s.price != null) Fmt.price(s.price) else "–", cols[5], y, text)
            y += 16f
        }

        fun note(t: String) {
            ensure(16f)
            page!!.canvas.drawText(t, margin, y, muted)
            y += 14f
        }

        fun close() {
            page?.let { finishPage(it) }
            page = null
        }
    }

    /** Crea il PDF e lo salva in Download/Binario. Restituisce l'indirizzo del file da aprire o condividere. */
    fun create(ctx: Context, from: Station, to: Station, day: Long, withReturn: Boolean, store: Store, onProgress: (String) -> Unit = {}): Uri {
        onProgress(I18n.tr("Scarico l'andata…", "Downloading outbound…"))
        val out = dayTimetable(from, to, day, store) { n -> onProgress(I18n.tr("Andata: $n corse…", "Outbound: $n runs…")) }
        val back = if (withReturn) {
            onProgress(I18n.tr("Scarico il ritorno…", "Downloading return…"))
            dayTimetable(to, from, day, store) { n -> onProgress(I18n.tr("Ritorno: $n corse…", "Return: $n runs…")) }
        } else emptyList()
        if (out.isEmpty() && back.isEmpty()) throw java.io.IOException(I18n.tr("Nessuna corsa trovata per quel giorno", "No runs found for that day"))

        val dayLabel = Fmt.dayLong(day)
        val doc = PdfDocument()
        val wr = Writer(ctx, doc, "${from.name} ⇄ ${to.name}".take(60), I18n.tr("Orario del giorno", "Timetable for") + " " + dayLabel)
        wr.section("${from.name} → ${to.name} · ${out.size} " + I18n.tr("corse", "runs"))
        if (out.isEmpty()) wr.note(I18n.tr("Nessuna corsa trovata.", "No runs found."))
        out.forEachIndexed { i, s -> wr.row(s, i) }
        if (withReturn) {
            wr.y += 10f
            wr.section("${to.name} → ${from.name} · ${back.size} " + I18n.tr("corse", "runs"))
            if (back.isEmpty()) wr.note(I18n.tr("Nessuna corsa trovata.", "No runs found."))
            back.forEachIndexed { i, s -> wr.row(s, i) }
        }
        wr.close()

        // Copia anche nell'app, consultabile in "Orari salvati offline"
        try {
            store.saveSearch(SavedSearch("pdf:${from.id}>${to.id}:${Fmt.midnight(day)}", "${from.name} → ${to.name} · $dayLabel",
                System.currentTimeMillis(), out))
        } catch (_: Exception) {
        }

        val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = rome }.format(Date(day))
        val name = ("Orario_${from.name}_${to.name}_$stamp").replace(Regex("[^A-Za-z0-9_\\-]+"), "_") + ".pdf"
        return save(ctx, name) { os -> doc.writeTo(os) }.also { doc.close() }
    }

    private fun save(ctx: Context, name: String, write: (OutputStream) -> Unit): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Binario")
            }
            val r = ctx.contentResolver
            val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw java.io.IOException("Download non disponibile")
            r.openOutputStream(uri)?.use(write) ?: throw java.io.IOException("Impossibile scrivere il file")
            return uri
        }
        // Android 8–9: cartella Download dell'app, condivisa tramite FileProvider
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir, "Binario").apply { mkdirs() }
        val f = File(dir, name)
        f.outputStream().use(write)
        return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    }

    /** Apre il PDF con il visualizzatore del telefono. */
    fun open(ctx: Context, uri: Uri): Boolean = try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun share(ctx: Context, uri: Uri) {
        try {
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("application/pdf")
                .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    @Suppress("unused")
    private fun cal(): Calendar = Calendar.getInstance(rome)
}
