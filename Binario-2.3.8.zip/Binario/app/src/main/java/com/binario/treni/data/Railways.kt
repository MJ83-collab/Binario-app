package com.binario.treni.data

/**
 * Imprese ferroviarie che trasportano passeggeri in Italia e in Svizzera (solo treni), con le fonti dei dati
 * che l'app può usare per ciascuna. Siti verificati il 15/10/2026.
 */
object Railways {
    enum class Country(val itLabel: String, val enLabel: String) { IT("Italia", "Italy"), CH("Svizzera", "Switzerland"), INT("Internazionali", "International") }
    enum class Kind(val itLabel: String, val enLabel: String) {
        REGIONAL("Regionale", "Regional"), LONG("Lunga percorrenza", "Long distance"), BOTH("Regionale e lunga percorrenza", "Regional and long distance")
    }

    /** Copertura dei dati nell'app. */
    enum class Live(val itLabel: String, val enLabel: String) {
        VT("Tempo reale: ViaggiaTreno (rete RFI)", "Real time: ViaggiaTreno (RFI network)"),
        CH("Tempo reale: orario ufficiale svizzero", "Real time: official Swiss timetable"),
        OWN("Tempo reale solo su sito/app dell'azienda", "Real time only on the company's site/app"),
        GTFS("Orari programmati nell'app (Transitous); tempo reale solo su sito/app dell'azienda", "Scheduled times in the app (Transitous); real time only on the company's site/app"),
    }

    data class Railway(
        val id: String,
        val name: String,
        val country: Country,
        val kind: Kind,
        val area: String,
        val site: String,
        val live: Live,
        /** Fonte dei dati di puntualità usata dall'app, se c'è. */
        val punctuality: String = "",
        /** Dove comprare i biglietti (pagina ufficiale), se diversa dal sito. */
        val tickets: String = "",
        /** Parole che identificano l'impresa nel nome del treno o nel campo "operator". */
        val keys: List<String> = emptyList(),
    ) {
        /** Nome breve da mostrare davanti al numero del treno: "EAV", "FFS", "Ferrotramviaria". */
        val short: String get() = name.substringBefore(" (").substringBefore(" –").substringBefore(" /").trim()
        val countryLabel: String get() = I18n.tr(country.itLabel, country.enLabel)
        val kindLabel: String get() = I18n.tr(kind.itLabel, kind.enLabel)
        val liveLabel: String get() = I18n.tr(live.itLabel, live.enLabel)
    }

    val all: List<Railway> = listOf(
        // ---- Italia: lunga percorrenza ----
        Railway("trenitalia", "Trenitalia", Country.IT, Kind.BOTH, "Tutta Italia (Frecce, Intercity, Regionale)", "https://www.trenitalia.com",
            Live.VT, "TrovaTreno (ViaggiaTreno)", "https://www.trenitalia.com/it/informazioni/punti-vendita.html", listOf("TRENITALIA")),
        Railway("italo", "Italo (NTV)", Country.IT, Kind.LONG, "Alta velocità", "https://www.italotreno.com", Live.VT, "TrovaTreno", "", listOf("ITALO", "NTV")),
        // ---- Italia: regionali sulla rete RFI ----
        Railway("trenord", "Trenord", Country.IT, Kind.REGIONAL, "Lombardia: rete RFI e rete FerrovieNord (Milano Cadorna, Saronno, Varese Nord, Como Lago, Novara Nord, Malpensa Express, Asso, Brescia–Iseo–Edolo); anche Piacenza e Svizzera",
            "https://www.trenord.it",
            Live.VT, "TrovaTreno (rete RFI) + raccolta dell'app (rete FerrovieNord)", "https://biglietterie.trenord.it/it/punti-vendita", listOf("TRENORD", "FERROVIENORD", "FNM")),
        Railway("tper", "Trenitalia Tper", Country.IT, Kind.REGIONAL, "Emilia-Romagna", "https://www.tper.it", Live.VT, "TrovaTreno (stimata da percorso)",
            "https://www.trenitalia.com/it/informazioni/punti-vendita.html", listOf("TPER")),
        Railway("sad", "SAD Trasporto locale", Country.IT, Kind.REGIONAL, "Alto Adige (Val Pusteria, Val Venosta, Merano)", "https://www.suedtirolmobil.info",
            Live.VT, "", "https://www.suedtirolmobil.info/it/ticket/punti-vendita/punti-vendita-altoadigemobilita", listOf("SAD")),
        Railway("tua", "TUA Abruzzo", Country.IT, Kind.REGIONAL, "Abruzzo (ferrovia Sangritana e linee RFI)", "https://www.tuabruzzo.it", Live.VT,
            "TrovaTreno (stimata da percorso)", "", listOf("TUA", "SANGRITANA")),
        Railway("fdg", "Ferrovie del Gargano", Country.IT, Kind.REGIONAL, "Puglia (Foggia–Lucera, San Severo–Peschici)", "https://ferroviedelgargano.com",
            Live.VT, "TrovaTreno (stimata da percorso)", "", listOf("GARGANO", "FDG")),
        Railway("arenaways", "Arenaways", Country.IT, Kind.REGIONAL, "Piemonte, Lombardia (Torino–Malpensa)", "https://www.arenaways.com", Live.VT, "",
            "", listOf("ARENAWAYS")),
        // ---- Italia: ferrovie regionali su rete propria ----
        Railway("eav", "EAV – Ente Autonomo Volturno", Country.IT, Kind.REGIONAL, "Campania (Circumvesuviana, Cumana, Circumflegrea, Napoli–Piedimonte)",
            "https://www.eavsrl.it", Live.GTFS, "TrovaTreno (solo treni su rete RFI)", "", listOf("EAV", "CIRCUMVESUVIANA", "CUMANA", "CIRCUMFLEGREA")),
        Railway("fse", "Ferrovie del Sud Est", Country.IT, Kind.REGIONAL, "Puglia (Bari, Salento)", "https://www.fseonline.it", Live.OWN, "", "", listOf("FSE", "SUD EST")),
        Railway("ferrotramviaria", "Ferrotramviaria (Ferrovie del Nord Barese)", Country.IT, Kind.REGIONAL, "Puglia (Bari–Barletta, aeroporto di Bari)",
            "https://www.ferrotramviaria.com", Live.OWN, "", "", listOf("FERROTRAMVIARIA", "NORD BARESE", "FNB")),
        Railway("fal", "Ferrovie Appulo Lucane", Country.IT, Kind.REGIONAL, "Puglia e Basilicata (Bari–Matera–Potenza)", "https://ferrovieappulolucane.it",
            Live.OWN, "", "", listOf("APPULO", "FAL")),
        Railway("fdc", "Ferrovie della Calabria", Country.IT, Kind.REGIONAL, "Calabria (Cosenza–Catanzaro)", "https://web.ferroviedellacalabria.it", Live.OWN,
            "", "", listOf("CALABRIA", "FDC")),
        Railway("fce", "Ferrovia Circumetnea", Country.IT, Kind.REGIONAL, "Sicilia (Catania–Riposto, metro di Catania)", "https://www.circumetnea.it", Live.OWN,
            "", "", listOf("CIRCUMETNEA", "FCE")),
        Railway("arst", "ARST", Country.IT, Kind.REGIONAL, "Sardegna (ferrovie a scartamento ridotto)", "https://www.arst.sardegna.it", Live.GTFS, "", "",
            listOf("ARST")),
        Railway("cotral", "Cotral", Country.IT, Kind.REGIONAL, "Lazio (Roma–Lido, Roma–Civita Castellana–Viterbo)", "https://cotralspa.it", Live.GTFS, "", "",
            listOf("COTRAL")),
        Railway("busitalia", "Busitalia (ferrovia ex FCU)", Country.IT, Kind.REGIONAL, "Umbria (Sansepolcro–Perugia–Terni)", "https://www.fsbusitalia.it",
            Live.OWN, "", "https://www.fsbusitalia.it/it/umbria/dove-acquistare-biglietti-umbria/punti-vendita-servizi-bus.html", listOf("BUSITALIA", "FCU")),
        Railway("trentino", "Trentino Trasporti", Country.IT, Kind.REGIONAL, "Trentino (Trento–Malè–Mezzana)", "https://www.trentinotrasporti.it", Live.GTFS, "",
            "", listOf("TRENTINO TRASPORTI", "TT ")),
        Railway("fuc", "Ferrovie Udine Cividale", Country.IT, Kind.REGIONAL, "Friuli Venezia Giulia (Udine–Cividale, Micotra Udine–Villach)",
            "https://www.ferrovieudinecividale.it", Live.OWN, "", "", listOf("CIVIDALE", "FUC")),
        Railway("ssif", "SSIF – Ferrovia Vigezzina", Country.IT, Kind.REGIONAL, "Piemonte–Ticino (Domodossola–Locarno)", "https://www.vigezzinacentovalli.com",
            Live.CH, "", "", listOf("SSIF", "VIGEZZINA")),
        // ---- Svizzera ----
        Railway("sbb", "FFS / SBB / CFF", Country.CH, Kind.BOTH, "Tutta la Svizzera, anche verso Milano", "https://www.sbb.ch", Live.CH,
            "Dati aperti FFS (ist-daten), soglia 3 minuti", "https://www.sbb.ch/it", listOf("SBB", "FFS", "CFF")),
        Railway("tilo", "TILO", Country.CH, Kind.REGIONAL, "Ticino e Lombardia (S10, S30, S40, S50, RE80)", "https://www.tilo.ch", Live.CH, "", "", listOf("TILO")),
        Railway("bls", "BLS", Country.CH, Kind.REGIONAL, "Berna, Vallese, Lötschberg (anche Domodossola)", "https://www.bls.ch", Live.CH,
            "TrovaTreno (treni su rete RFI)", "", listOf("BLS")),
        Railway("sob", "Südostbahn (SOB)", Country.CH, Kind.BOTH, "Svizzera orientale, Treno Gottardo (Locarno–Basilea/Zurigo)", "https://www.sob.ch", Live.CH,
            "", "", listOf("SOB")),
        Railway("rhb", "Ferrovia Retica (RhB)", Country.CH, Kind.REGIONAL, "Grigioni, Bernina (fino a Tirano)", "https://www.rhb.ch", Live.CH, "", "", listOf("RHB", "RETICA")),
        Railway("mgb", "Matterhorn Gotthard Bahn", Country.CH, Kind.REGIONAL, "Vallese, Uri, Grigioni (Glacier Express)", "https://www.matterhorngotthardbahn.ch",
            Live.CH, "", "", listOf("MGB", "MATTERHORN")),
        Railway("zb", "Zentralbahn", Country.CH, Kind.REGIONAL, "Lucerna–Interlaken, Engelberg", "https://www.zentralbahn.ch", Live.CH, "", "", listOf("ZB", "ZENTRALBAHN")),
        Railway("thurbo", "Thurbo", Country.CH, Kind.REGIONAL, "Turgovia, San Gallo, Zurigo", "https://www.thurbo.ch", Live.CH, "", "", listOf("THURBO")),
        Railway("regionalps", "RegionAlps", Country.CH, Kind.REGIONAL, "Vallese (St-Gingolph–Briga)", "https://www.regionalps.ch", Live.CH, "", "", listOf("REGIONALPS", "RA ")),
        Railway("fart", "FART", Country.CH, Kind.REGIONAL, "Ticino (Locarno–Centovalli–Domodossola)", "https://www.fartiamo.ch", Live.CH, "", "", listOf("FART")),
        Railway("flp", "Ferrovie Luganesi (FLP)", Country.CH, Kind.REGIONAL, "Ticino (Lugano–Ponte Tresa)", "https://www.flpsa.ch", Live.CH, "", "", listOf("FLP")),
        Railway("tpf", "TPF", Country.CH, Kind.REGIONAL, "Friburgo", "https://www.tpf.ch", Live.CH, "", "", listOf("TPF")),
        Railway("mob", "MOB – Montreux Oberland Bernois", Country.CH, Kind.REGIONAL, "Montreux–Zweisimmen (GoldenPass)", "https://www.mob.ch", Live.CH, "", "",
            listOf("MOB", "GOLDENPASS")),
        Railway("ab", "Appenzeller Bahnen", Country.CH, Kind.REGIONAL, "Appenzello, San Gallo", "https://www.appenzellerbahnen.ch", Live.CH, "", "", listOf("APPENZELLER", "AB ")),
        Railway("aare", "Aare Seeland mobil", Country.CH, Kind.REGIONAL, "Berna, Soletta (Langenthal–Oensingen)", "https://www.asmobil.ch", Live.CH, "", "", listOf("ASM")),
        Railway("cj", "Chemins de fer du Jura", Country.CH, Kind.REGIONAL, "Giura", "https://www.les-cj.ch", Live.CH, "", "", listOf("CJ ")),
        Railway("travys", "Travys", Country.CH, Kind.REGIONAL, "Vaud (Yverdon–Ste-Croix, Vallée de Joux)", "https://www.travys.ch", Live.CH, "", "", listOf("TRAVYS")),
        // ---- Internazionali (treni che entrano in Italia o in Svizzera) ----
        Railway("oebb", "ÖBB", Country.INT, Kind.BOTH, "Austria; Brennero, Nightjet per Roma, Milano, Venezia", "https://www.oebb.at", Live.VT,
            "TrovaTreno (stimata da percorso)", "", listOf("ÖBB", "OBB", "OEBB", "NIGHTJET")),
        Railway("db", "Deutsche Bahn", Country.INT, Kind.LONG, "Germania; EC del Brennero con ÖBB", "https://www.bahn.de", Live.VT, "", "", listOf(" DB ", "DB FERNVERKEHR")),
        Railway("sncf", "SNCF", Country.INT, Kind.LONG, "Francia; TGV Parigi–Torino–Milano", "https://www.sncf-connect.com", Live.VT, "", "", listOf("SNCF", "TGV")),
        Railway("trenitaliafr", "Trenitalia France", Country.INT, Kind.LONG, "Frecciarossa Milano–Torino–Parigi", "https://www.trenitalia.com", Live.VT, "", "",
            listOf("TRENITALIA FRANCE")),
    )

    fun byId(id: String): Railway? = all.firstOrNull { it.id == id }

    /** Impresa riconosciuta da un testo (campo "operator" dell'orario svizzero o nome del treno). */
    fun match(text: String): Railway? {
        val t = " " + text.uppercase() + " "
        return all.firstOrNull { r -> r.keys.any { k -> t.contains(k.uppercase()) } }
    }
}
