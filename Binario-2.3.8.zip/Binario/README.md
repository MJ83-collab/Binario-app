# Binario — orari treni per Android

App Android nativa (Kotlin + Jetpack Compose) con orari, ritardi in tempo reale, tabelloni, notifiche e widget.
Dati: ViaggiaTreno (RFI/Trenitalia) e LeFrecce (soluzioni e prezzi Trenitalia). Mappe: OpenStreetMap, senza chiave API.

## Come ottenere l'APK

1. Installa **Android Studio** (versione Ladybug 2024.2 o più recente).
2. *File → Open* e scegli la cartella `Binario`. Attendi la sincronizzazione Gradle (scarica le librerie la prima volta).
3. Telefono collegato via USB con *Debug USB* attivo → premi **Run ▶**.
   Oppure *Build → Build App Bundle(s)/APK(s) → Build APK(s)* e copia `app/build/outputs/apk/debug/app-debug.apk` sul telefono.

Requisiti: Android 8.0 o superiore.

### Firma (solo per il proprietario)

L'APK da distribuire è la versione *release*, firmata con una chiave privata che **non** è nel progetto.
Metti `binario-release.jks` e `keystore.properties` nella cartella principale `Binario/` (sono esclusi da git),
poi *Build → Generate Signed App Bundle / APK* oppure da terminale `gradle assembleRelease`.
L'APK firmato è in `app/build/outputs/apk/release/app-release.apk`.
Su GitHub Actions servono i segreti `BINARIO_KEYSTORE_BASE64` e `BINARIO_KEYSTORE_PASSWORD`.
Senza la chiave nessuno può pubblicare un aggiornamento che si installi sopra la tua app: tienine una copia di sicurezza.

## Versione 2.3

Versione attuale. La **2.4 è in lavorazione**.
Le novità di ogni versione sono in *Altro → Changelog*; i problemi risolti in *Altro → Report correzioni* e nel file [FIXES.md](FIXES.md).

## Novità 2.0

Widget configurabili uno per uno, nuova grafica, linee preferite (es. S5), sveglia prima della fermata,
avvisi su interruzioni e soppressioni, avvisi accessibili per persone sorde (vibrazione + flash),
accessibilità stazioni (variazioni RFI ascensori/rampe, Sale Blu), affollamento Trenord quando disponibile,
impostazioni, opzioni avanzate e backup.

## Cosa c'è

**Orari** — partenza/arrivo, andata e ritorno, data e ora, filtri *Migliori soluzioni / Alta velocità / Regionali / Tutte*,
solo diretti, prezzi base, soluzioni successive, recenti e preferite, salvataggio offline, condivisione.

**Treni** — ricerca per numero (anche corse omonime), stato in tempo reale, ultimo rilevamento, fermate con orari
programmati/effettivi e binari (in blu se cambiati), linea del tragitto, mappa del percorso, aggiornamento ogni minuto,
treni preferiti con stato live.
Azioni: *Segui* (notifica fissa aggiornata ogni minuto), *Avvisami* (notifica programmata prima della partenza o dell'arrivo),
*Calendario*, *Condividi*, *Biglietto*.

**Stazioni** — tabellone partenze/arrivi in tempo reale, stazioni preferite, stazioni vicine con mappa.

**Biglietti** — collegamenti ai siti ufficiali Trenitalia, Italo, Trenord, area personale e cambio prenotazione.

**Altro** — orari salvati offline, notifiche programmate, news di infomobilità e calendario scioperi,
notifiche automatiche dei nuovi scioperi (controllo ogni 6 ore), guida widget, privacy e permessi.

**Widget** — Tragitto, Treno, Stazione, Preferiti (tieni premuto sulla Home → Widget → Binario).

Nessuna pubblicità: tutte le funzioni sono incluse.

## Limiti

- **Acquisto e sincronizzazione biglietti nell'app, QR abbonamento, messaggi pubblici tra utenti**: richiedono accordi
  commerciali con le compagnie o un server proprio. L'app apre i siti ufficiali.
- **Compagnie minori** (EAV, FSE, FAL, TPER, ecc.): compaiono solo quando i loro treni sono presenti su ViaggiaTreno.
  Italo è presente nelle stazioni RFI ma senza prezzi.
- ViaggiaTreno e LeFrecce sono servizi pubblici ma non documentati: se cambiano formato, va aggiornato `data/Api.kt`.
- L'app non è affiliata a Trenitalia, RFI, Italo o Trenord.

## Struttura

```
app/src/main/java/com/binario/treni/
  MainActivity.kt        navigazione e barra inferiore
  data/Api.kt            client ViaggiaTreno + LeFrecce
  data/Models.kt         modelli dati
  data/Store.kt          preferiti, recenti, offline, promemoria
  service/Services.kt    notifica fissa, promemoria, riavvio, avvisi scioperi
  widget/Widgets.kt      i quattro widget
  ui/                    schermate Compose
```
