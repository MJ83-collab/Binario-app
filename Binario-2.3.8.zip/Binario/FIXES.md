# Report correzioni

2.4 · IN LAVORAZIONE
• Correzioni in corso: verranno elencate qui al rilascio

2.3.4
• Rivendite vicine restava ferma su "Cerco i punti vendita entro 800 m…". La prima volta l'app scaricava dal sito Trenord tutte le 12 province e le pagine di ogni biglietteria, e se intanto partiva l'aggiornamento settimanale aspettava anche quello. Ora usa un elenco già pronto (un solo file), altrimenti solo le province vicine; l'aggiornamento avviene in background e dopo 30 secondi al massimo la schermata mostra quello che è arrivato

2.3.1
• Stato dei servizi: ViaggiaTreno, OpenStreetMap e Postpass comparivano rossi anche quando funzionavano (nome dell'app rifiutato da ViaggiaTreno, solo il server principale di OpenStreetMap provato, richiesta di prova a Postpass sbagliata). Ora il controllo fa come l'app
• ViaggiaTreno: se il sito rifiuta la richiesta (errore 403) l'app riprova subito presentandosi come il browser del telefono

2.3
• Rivendite e riepilogo stazione: "Servizio mappe momentaneamente non raggiungibile". Tre dei quattro server usati erano stati chiusi e il quarto rifiutava le richieste (errore 406, nuove regole anti-abuso di Overpass). Ora l'app usa i 3 server attivi (più OSM.ch in Svizzera), si identifica come richiesto e, se non bastano, passa a Postpass e ai dati salvati. Google Maps resta come ultima possibilità, a portata di tasto
• Emettitrici self-service: venivano contati anche i parcometri ("parking tickets"). Ora sono esclusi
• Attese più brevi quando un server è lento: si passa al successivo dopo 8 secondi di connessione invece di 12
• Mappe coperte dalla scritta "API KEY REQUIRED": il servizio CARTO dal 2026 chiede una chiave a pagamento. Ora le mappe sono quelle ufficiali di OpenStreetMap, con riserva automatica su OpenStreetMap France
• Stazioni vicine: la mappa copriva il titolo in alto. Ora resta nei suoi bordi
• Widget: il tasto ⟳ spesso non aggiornava nulla (il telefono ignorava la richiesta) e non dava segni. Ora ricollega l'elenco e ricarica davvero, con "aggiorno…" e un avviso a schermo
• Treni regionali Trenord e TILO: toccandoli (dal widget o dalle soluzioni) compariva "Treno S50 TRENORD 25592 non trovato", e mancavano ritardo e binario in tempo reale. Il numero arrivava con linea e impresa attaccate; ora l'app usa solo il numero (25592)
• Impresa del treno: davanti al numero c'era sempre "TI" (Trenitalia), anche per i treni Trenord. Ora l'impresa è letta da ViaggiaTreno (codice impresa) o dal nome del treno
• Puntualità: Tper, EAV, Ferrovie del Gargano e altre imprese regionali finivano insieme in "Altri operatori", quindi non si potevano confrontare con Trenord e Trenitalia. Ora ognuna ha la sua riga (con almeno 100 arrivi osservati nel mese)
• WC: comparivano solo come una riga nel riepilogo della scheda "Stazione" e sparivano se OpenStreetMap non rispondeva. Ora hanno una schermata propria, raggiungibile anche dal tabellone, con Google Maps come riserva
• Rivendite: comparivano tutte le tabaccherie ed edicole di OpenStreetMap, anche quelle che non vendono biglietti. Ora solo i punti vendita autorizzati dagli elenchi ufficiali
• Rete FerrovieNord: le soluzioni da o per Varese Nord, Milano Cadorna, Saronno, Como Lago, Novara Nord e le altre stazioni FN non uscivano, perché l'app calcolava l'identificativo LeFrecce come per le stazioni RFI (Varese Nord ha invece 830025251). Ora lo cerca per nome, e se LeFrecce non risponde usa gli orari ufficiali Trenord
• Stazioni vicine, mappe, rivendite e WC: le stazioni FerrovieNord come Varese Nord, Como Lago o Novara Nord mancavano, perché non sono nell'elenco stazioni di ViaggiaTreno. Ora sono incluse
• Puntualità: cercando "Varese Nord" (o un'altra stazione FerrovieNord) compariva "Nessun risultato" senza spiegazione. TrovaTreno non pubblica questa rete: ora l'app raccoglie i dati da sola e lo spiega
• Puntualità: Milano Porta Garibaldi e Milano Centrale comparivano entrambe come "Milano", quindi non si trovavano cercando "Garibaldi". Ora hanno il nome completo
• Soluzioni e widget tratta: lo stesso treno TILO compariva due volte ("RE SBB 25591" e "S50 TRENORD 25591"). Ora compare una volta sola, con entrambe le sigle unite: "RE SBB / SU S50 TRENORD 25591"

2.2
• Assistente: alle domande generali (rimborsi, bici, bambini, assistenza…) rispondeva "Non ho capito". Ora ha una base di conoscenza con fonti ufficiali
• Assistente: bastava un accento o un errore di battitura ("rimborzo") per non capire. Ora la comprensione è tollerante
• Assistente: "bagni a Saronno" o "bus a Varese" venivano scambiati per nomi di stazione. Ora sono domande sui servizi, e parole come "bus" non scattano più dentro nomi come "Busto Arsizio"
• Assistente: le risposte non citavano la fonte. Ora c'è il link diretto sotto la risposta
• OpenStreetMap: le richieste ora si identificano con nome e versione dell'app, come chiesto dai server

2.1
• Puntualità: Trenord veniva confrontata con tutta Trenitalia (regionali + Frecce + Intercity). Ora il confronto è tra servizi dello stesso tipo, ricalcolato dai dati per treno
• Treno seguito: binario e "parte tra 5 minuti" si riferivano sempre alla stazione d'origine, anche salendo a metà percorso. Ora valgono per la fermata scelta con "Salgo qui"
• Ricerca senza rete: compariva solo un errore. Ora si vedono gli ultimi orari scaricati per la tratta, con l'ora dell'aggiornamento

0.4
• Assistente: non diceva da quale binario parte il treno né il binario nella stazione di partenza delle soluzioni. Corretto
• Nessuna notifica se cambiava il binario o aumentava il ritardo del treno seguito: aggiunta
• Le domande a voce non erano possibili: aggiunti microfono, scorciatoie e riquadro rapido

0.3
• Widget: mostravano "dati non disponibili" a ogni errore momentaneo di ViaggiaTreno e poi si ricaricavano. Ora riprovano da soli e, se serve, tengono gli ultimi dati validi con l'ora
• Notizie: la fonte ViaggiaTreno era ferma al 2019. Sostituita con "Notizie Infomobilità" di Trenitalia; ogni notizia ora cita la fonte con il link diretto
• Notizie non si aggiornavano da sole: ora ogni 5 minuti, più il pulsante "Aggiorna ora"
• Link non più validi: Italo assistenza e news, Trenitalia rimborsi, area riservata, treni garantiti (indirizzo cambiato). Corretti
• Mappe lente: le tessere venivano riscaricate ogni volta (cartella della cache non scrivibile) dai server OpenStreetMap, che limitano le app. Ora server CARTO e cache nel telefono; la mappa del treno carica le fermate in parallelo
• "Dati non disponibili" in rivendite e servizi di stazione: il server OpenStreetMap principale era sovraccarico. Aggiunti tre server di riserva
• Statistiche di puntualità bloccate per 24 ore se la prima apertura avveniva senza rete. Corretto
• Scioperi generali e plurisettoriali che fermano anche i treni non comparivano. Inclusi
• Guasti ad ascensori FerrovieNord non letti (la tabella si carica via JavaScript). Ora letti dal vivo come quelli RFI

0.2
• Ricerca soluzioni: "Impossibile contattare il server". LeFrecce ora richiede un token di sessione, che l'app non chiedeva; in più il servizio di riserva ViaggiaTreno è stato dismesso (errore 404). Aggiunta la sessione automatica
• Il messaggio di errore non diceva il motivo: ora lo indica tra parentesi

0.1
• Firma: la password della chiave era scritta in chiaro nel progetto (chiunque poteva firmare aggiornamenti). Nuova chiave privata, fuori dal progetto, letta dai segreti di GitHub
• Compilazione: errori con Kotlin 2.1 nell'elenco linee (tipo non dedotto) e nelle annotazioni SuppressLint di Rivendite e Stazioni. Corretti
• Build: la lettura della chiave in build.gradle.kts non compilava (riferimento java.util). Corretta
• Workflow GitHub: compilava lo zip con il numero più alto invece dell'ultimo caricato e non firmava l'APK. Riscritto, con messaggi chiari su chiave e password
